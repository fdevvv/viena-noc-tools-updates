(() => {
  'use strict';
  if (location.hostname !== 'viena.telecentro.net.ar' || window.top !== window) return;
  const release=globalThis.VienaReleaseNotes;
  const HOST='viena-noc-release-announcement';
  if (!release || document.getElementById(HOST)) return;
  const channel=/\bDEV\b/i.test(chrome.runtime.getManifest().name)?'dev':'release';
  const key=`viena_release_news_seen_${channel}_v1`;
  let reading=false;
  async function start(){
    if(reading || document.getElementById(HOST)) return;
    reading=true;
    let timer;
    try {
      const stored=await Promise.race([
        chrome.storage.local.get([key,'viena_ui_theme_v1']),
        new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('timeout')),3000);})
      ]);
      if(stored[key]===release.version || document.getElementById(HOST)) return;
      await show(stored.viena_ui_theme_v1==='dark');
    } catch (_) { /* A failed announcement must never block VIENA. */ }
    finally { clearTimeout(timer);reading=false; }
  }
  function show(dark){
    return new Promise(resolve=>{
      const previous=document.activeElement;
      const host=document.createElement('div');host.id=HOST;
      const shadow=host.attachShadow({mode:'open'});
      const style=document.createElement('style');
      style.textContent=`
        :host{all:initial}*{box-sizing:border-box}
        dialog{--surface:#fff;--ink:#18324e;--muted:#52677c;--line:#d6e2ee;--soft:#f1f6fc;padding:0;border:1px solid var(--line);border-radius:20px;width:min(680px,calc(100vw - 28px));max-height:calc(100dvh - 28px);overflow:auto;background:var(--surface);color:var(--ink);box-shadow:0 24px 80px #071a3d55;font:16px/1.55 Arial,Helvetica,sans-serif}
        dialog.dark{--surface:#121e2c;--ink:#e1eaf4;--muted:#aabdd1;--line:#33465b;--soft:#1a2c40;color-scheme:dark}
        dialog::backdrop{background:#07172e88}header{padding:22px 26px;background:linear-gradient(120deg,#092e60,#164e89);color:#fff;display:flex;gap:16px;align-items:flex-start}header div{flex:1}.kicker{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#d0e2f7}h1{font-size:24px;line-height:1.25;margin:6px 0 0}button{font:inherit;cursor:pointer;border-radius:10px;min-height:44px;padding:9px 15px;border:1px solid var(--line);background:var(--soft);color:var(--ink)}button:focus-visible{outline:3px solid #4c9be8;outline-offset:3px}.close{background:transparent;color:white;border-color:#ffffff66;font-size:24px;line-height:1;padding:8px 12px}main{padding:24px 26px;touch-action:pan-y}.count{color:var(--muted);font-size:13px}h2{font-size:24px;line-height:1.3;margin:10px 0 14px}p{margin:0;min-height:125px;color:var(--muted)}.dots{display:flex;justify-content:center;gap:6px;padding:0 20px 18px}.dot{width:8px;height:8px;border-radius:50%;background:var(--line)}.dot.active{background:#3887d5}footer{border-top:1px solid var(--line);padding:18px 26px;display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between}button:disabled{opacity:.45;cursor:default}.primary{background:#165aa0;color:white;border-color:#165aa0}.next{margin-left:auto}@media(max-width:440px){header,main,footer{padding:18px}h1,h2{font-size:21px}p{min-height:0}footer button{padding:8px 11px;font-size:14px}}@media(prefers-reduced-motion:no-preference){dialog[open]{animation:appear .16s ease-out}@keyframes appear{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}`;
      style.textContent+=`
*{box-sizing:border-box}body{margin:0;background:#edf3f9;font:15px/1.5 Arial,Helvetica,sans-serif;color:#18324e}.background{padding:28px;opacity:.45}.background strong{display:block;background:#1976d2;color:white;padding:15px;border-radius:5px}.background p{background:white;padding:22px;border:1px solid #d6e2ee;border-radius:8px}.draft{position:fixed;bottom:10px;left:16px;font-size:12px;color:#52677c}
dialog{--surface:#fff;--ink:#18324e;--muted:#52677c;--line:#d6e2ee;--soft:#f1f6fc;padding:0;border:1px solid var(--line);border-radius:20px;width:min(680px,calc(100vw - 28px));max-height:calc(100dvh - 28px);overflow:auto;background:var(--surface);color:var(--ink);box-shadow:0 24px 80px #071a3d55;font:16px/1.5 Arial,Helvetica,sans-serif}dialog::backdrop{background:#07172e88}
header{padding:22px 26px;background:linear-gradient(120deg,#092e60,#164e89);color:#fff;display:flex;gap:16px;align-items:flex-start}header div{flex:1}.kicker{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#d0e2f7}h1{font-size:25px;line-height:1.25;margin:6px 0 0}button{font:inherit;cursor:pointer;border-radius:9px;min-height:42px;padding:9px 15px;border:1px solid var(--line);background:var(--soft);color:var(--ink)}button:focus-visible{outline:3px solid #4c9be8;outline-offset:3px}.close{background:transparent;color:white;border-color:#ffffff66;font-size:24px;line-height:1;padding:8px 12px}main{padding:20px 26px}.count{color:var(--muted);font-size:12px}h2{font-size:23px;line-height:1.3;margin:9px 0 10px}.copy{margin:0;color:var(--muted);min-height:68px;font-size:15px}.capture{margin:16px 0 8px;border:1px solid var(--line);border-radius:10px;overflow:hidden;position:relative;aspect-ratio:1.85;background:#f8fbff}.capture img{display:block;width:100%;height:100%;object-fit:cover;object-position:top}.capture.detail img{width:1100px;max-width:none;height:auto;position:absolute;right:-6px;top:-86px}.capture.result img{object-fit:contain}.caption{display:flex;justify-content:space-between;align-items:center;gap:8px;font-size:12px;color:var(--muted)}.zoom{border:0;background:transparent;color:#165aa0;padding:3px 0;min-height:28px;font-size:12px;white-space:nowrap}.tip{margin-top:12px;border:1px solid #c8def5;border-radius:8px;padding:10px 12px;background:#eef6ff;font-size:13px;color:#24547e}.dots{display:flex;justify-content:center;gap:7px;padding:0 20px 16px}.dot{width:8px;height:8px;border-radius:50%;background:var(--line)}.dot.active{background:#3887d5}footer{border-top:1px solid var(--line);padding:16px 26px;display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between}button:disabled{opacity:.45;cursor:default}.primary{background:#165aa0;color:white;border-color:#165aa0}.next{margin-left:auto}#photo{width:min(1320px,calc(100vw - 28px));padding:12px}#photo img{width:100%;display:block}#photo button{float:right;margin-bottom:8px}
@media(max-width:440px){header,main,footer{padding:16px}h1,h2{font-size:21px}.copy{font-size:14px;min-height:0}.capture{aspect-ratio:1.45}.capture.detail img{width:820px;top:-62px}.tip{font-size:12px}footer button{padding:8px 11px;font-size:14px}}
.sections{display:flex;gap:8px;padding:14px 26px 0}.sections button{flex:1;font-size:13px}.sections button.active{background:#165aa0;color:white;border-color:#165aa0}.included{margin:12px 26px 0;padding:10px 12px;border:1px solid #c8def5;border-radius:8px;background:#eef6ff;font-size:13px;color:#24547e}.summary{margin:12px 26px 0;font-size:13px;color:#52677c}.summary summary{cursor:pointer;color:#165aa0}.summary li{margin:7px 0}.capture[hidden],.caption[hidden],.summary[hidden]{display:none}.capture.library img{object-position:center bottom}.capture.editor img{object-position:center 75%}.dots{flex-wrap:wrap}@media(max-width:440px){.sections{padding:12px 16px 0}.sections button{padding:7px;font-size:12px}.included,.summary{margin-left:16px;margin-right:16px}}

:host{all:initial}.copy{min-height:0}.tip,.included{background:var(--soft);color:var(--ink);border-color:var(--line)}.summary{color:var(--muted)}.capture{background:var(--soft)}.zoom{color:var(--ink)}main{touch-action:pan-y}.photo{width:min(1320px,calc(100vw - 28px));padding:12px}.photo img{width:100%;display:block}.photo button{float:right;margin-bottom:8px}header button{flex-shrink:0}`;
      const dialog=document.createElement('dialog');dialog.className=dark?'dark':'';
      dialog.setAttribute('aria-labelledby','news-title');dialog.setAttribute('aria-describedby','news-text');
      const header=document.createElement('header'),heading=document.createElement('div');
      const kicker=document.createElement('div');kicker.className='kicker';kicker.textContent=`VIENA NOC Tools · v${release.version}`;
      const title=document.createElement('h1');title.id='news-title';title.textContent=release.title;heading.append(kicker,title);
      const close=document.createElement('button');close.type='button';close.className='close';close.textContent='×';close.setAttribute('aria-label','Cerrar novedades');header.append(heading,close);
      const main=document.createElement('main'),count=document.createElement('div'),slideTitle=document.createElement('h2'),text=document.createElement('p');
      count.className='count';text.id='news-text';text.className='copy';main.setAttribute('aria-live','polite');main.setAttribute('aria-atomic','true');main.append(count,slideTitle,text);
      const nav=document.createElement('nav');nav.className='sections';nav.setAttribute('aria-label','Novedades por versión');
      const section42=document.createElement('button'),section41=document.createElement('button');section42.type=section41.type='button';section42.textContent='Nuevo en la 1.3.42';section41.textContent='También incluido de la 1.3.41';nav.append(section42,section41);
      const included=document.createElement('div');included.className='included';included.textContent='¿Venís de la 1.3.40? Esta actualización también incluye todas las mejoras de la 1.3.41.';
      const summary=document.createElement('details');summary.className='summary';const summaryTitle=document.createElement('summary');summaryTitle.textContent='Ver el resumen completo de la 1.3.41';const list=document.createElement('ul');for(const note of release.previousNotes){const li=document.createElement('li');li.textContent=note;list.append(li)}summary.append(summaryTitle,list);
      const capture=document.createElement('figure'),img=document.createElement('img');capture.className='capture';capture.append(img);const caption=document.createElement('div');caption.className='caption';const captionText=document.createElement('span'),zoom=document.createElement('button');zoom.type='button';zoom.className='zoom';zoom.textContent='Ampliar imagen ↗';caption.append(captionText,zoom);const tip=document.createElement('div');tip.className='tip';main.append(capture,caption,tip);
      const photo=document.createElement('dialog');photo.className=dark?'photo dark':'photo';photo.setAttribute('aria-label','Imagen ampliada');const photoClose=document.createElement('button');photoClose.type='button';photoClose.textContent='Cerrar imagen';const photoImg=document.createElement('img');photo.append(photoClose,photoImg);
      const dots=document.createElement('div');dots.className='dots';dots.setAttribute('aria-hidden','true');
      release.slides.forEach(()=>{const dot=document.createElement('span');dot.className='dot';dots.append(dot);});
      const footer=document.createElement('footer');
      function button(label,cls=''){const b=document.createElement('button');b.type='button';b.textContent=label;b.className=cls;return b;}
      const prev=button('Anterior'),next=button('Siguiente','next'),done=button('Entendido','primary');footer.append(prev,next,done);
      dialog.append(header,nav,included,summary,main,dots,footer);shadow.append(style,dialog,photo);(document.body||document.documentElement).append(host);
      let index=0,closed=false,touchX=null;
      function render(){const slide=release.slides[index],legacy=index>=release.newSlideCount,offset=legacy?release.newSlideCount:0,total=legacy?release.slides.length-offset:release.newSlideCount;
        count.textContent=`${legacy?'Incluido desde la 1.3.41':'Nuevo en la 1.3.42'} · Novedad ${index-offset+1} de ${total}`;slideTitle.textContent=slide.title;text.textContent=slide.text;tip.textContent=slide.tip||'';tip.hidden=!slide.tip;
        const src=globalThis.VienaReleaseImages?.[slide.image];capture.className='capture '+(slide.kind||'result');capture.hidden=caption.hidden=!src;if(src){img.src=src;img.alt=slide.caption||slide.title}else img.removeAttribute('src');captionText.textContent=slide.caption||'';summary.hidden=!legacy;
        for(const [b,active] of [[section42,!legacy],[section41,legacy]]){b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active))}prev.disabled=index===0;next.disabled=index===release.slides.length-1;next.textContent=index===release.newSlideCount-1?'Ver también .41':'Siguiente';dots.replaceChildren(...Array.from({length:total},(_,i)=>{const d=document.createElement('span');d.className='dot'+(i===index-offset?' active':'');return d}));}
      section42.addEventListener('click',()=>{index=0;render()});section41.addEventListener('click',()=>{index=release.newSlideCount;render()});
      zoom.addEventListener('click',()=>{photoImg.src=img.src;photoImg.alt=img.alt;photo.showModal();photoClose.focus({preventScroll:true})});photoClose.addEventListener('click',()=>photo.close());photo.addEventListener('cancel',e=>{e.preventDefault();e.stopPropagation();photo.close()});photo.addEventListener('keydown',e=>{e.stopPropagation();if(e.key==='Escape'){e.preventDefault();photo.close()}});
      function move(delta){index=Math.max(0,Math.min(release.slides.length-1,index+delta));render();}
      function dismiss(){if(closed)return;closed=true;if(photo.open)photo.close();dialog.close();host.remove();if(previous?.isConnected)previous.focus({preventScroll:true});void chrome.storage.local.set({[key]:release.version}).catch(()=>{});resolve();}
      prev.addEventListener('click',()=>move(-1));next.addEventListener('click',()=>move(1));done.addEventListener('click',dismiss);close.addEventListener('click',dismiss);
      dialog.addEventListener('cancel',e=>{e.preventDefault();dismiss();});
      dialog.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();dismiss();}else if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();e.stopPropagation();move(e.key==='ArrowRight'?1:-1);}});
      main.addEventListener('touchstart',e=>{touchX=e.touches.length===1?e.touches[0].clientX:null;},{passive:true});
      main.addEventListener('touchend',e=>{if(touchX!==null&&e.changedTouches.length){const delta=e.changedTouches[0].clientX-touchX;if(Math.abs(delta)>50)move(delta<0?1:-1);}touchX=null;},{passive:true});
      render();dialog.showModal();next.focus({preventScroll:true});
    });
  }
  // One VIENA tab presents the announcement while the other tabs remain usable.
  if(navigator.locks?.request){void navigator.locks.request(`viena-news-${channel}`,{ifAvailable:true},lock=>lock?start():undefined).catch(()=>{});}
  else void start();
})();
