(function () {
    'use strict';
    const MANUAL_MOICA = location.hostname === 'moica2.telecentro.net.ar'
        && location.pathname === '/viewCrearTktManual.php';
    if (!MANUAL_MOICA || globalThis.__VIENA_MOICA_MANUAL_READINESS__) return;
    globalThis.__VIENA_MOICA_MANUAL_READINESS__ = true;
    const transitioning = new Set();
    let listening = false;
    // Only expose the count: URLs, request bodies and operator data stay in MOICA.
    document.addEventListener('viena:moica-request-status', () => {
        if (!listening && typeof globalThis.jQuery === 'function') {
            globalThis.jQuery(document).on('show.bs.modal hide.bs.modal', event => transitioning.add(event.target));
            globalThis.jQuery(document).on('shown.bs.modal hidden.bs.modal', event => transitioning.delete(event.target));
            listening = true;
        }
        for (const modal of transitioning) if (!modal.isConnected) transitioning.delete(modal);
        document.documentElement.setAttribute('data-viena-moica-modal-pending', String(transitioning.size));
        const active = globalThis.jQuery?.active;
        document.documentElement.setAttribute('data-viena-moica-ajax-active',
            Number.isInteger(active) && active >= 0 ? String(active) : 'unavailable');
    });
})();
