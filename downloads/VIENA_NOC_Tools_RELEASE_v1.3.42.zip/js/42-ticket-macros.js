(function () {
    'use strict';

    if (globalThis.__VIENA_TICKET_MACROS_V1__) return;
    globalThis.__VIENA_TICKET_MACROS_V1__ = true;

    const MANUAL_MOICA = globalThis.location?.hostname === 'moica2.telecentro.net.ar'
        && globalThis.location.pathname === '/viewCrearTktManual.php';
    const STORAGE_KEY = MANUAL_MOICA ? 'moica_manual_macros_v1' : 'viena_ticket_macros_v1';
    const MAX_MACROS = 50;
    const MAX_ACTIONS = 1000;
    const MAX_STORAGE_BYTES = 4 * 1024 * 1024;
    const SENSITIVE_NAME = /password|passwd|secret|token|authorization|otp|one.?time.?code/i;
    const UI_ATTRIBUTE = 'data-viena-macro-ui';
    const TEXT_NODE_TOKEN = '{{TICKET_NODE}}';
    const CMTS_NODE_TOKEN = '{{TICKET_NODE_CMTS}}';

    function escapeRegExp(value) {
        return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function replaceWholeIdentifier(text, value, token) {
        const escaped = escapeRegExp(value);
        return String(text).replace(
            new RegExp(`(^|[^A-Z0-9])${escaped}(?=$|[^A-Z0-9])`, 'ig'),
            (_match, prefix) => `${prefix}${token}`
        );
    }

    function tokenizeTicketValues(value, ticket = {}) {
        let result = String(value ?? '');
        const cmts = String(ticket.cmts || '').trim();
        const node = String(ticket.node || '').trim();
        // Resolve explicit labels first, even when Nodo and Nodo CMTS originally match.
        // Horizontal whitespace only: an empty label must never consume the next line.
        result = result.replace(
            /(\bNodo[ \t]+CMTS[ \t]*:[ \t]*)(?:[A-Z0-9][A-Z0-9_-]*)?/ig,
            (_match, label) => `${label}${CMTS_NODE_TOKEN}`
        );
        result = result.replace(
            /(\bNodo(?![ \t]+CMTS)[ \t]*:[ \t]*)(?:[A-Z0-9][A-Z0-9_-]*)?/ig,
            (_match, label) => `${label}${TEXT_NODE_TOKEN}`
        );
        if (cmts) result = replaceWholeIdentifier(result, cmts, CMTS_NODE_TOKEN);
        if (node) result = replaceWholeIdentifier(result, node, TEXT_NODE_TOKEN);
        return result;
    }

    function resolveTicketTemplate(value, ticket = {}) {
        let result = String(value ?? '');
        if (result.includes(CMTS_NODE_TOKEN)) {
            const cmts = String(ticket.cmts || '').trim();
            if (!cmts) return null;
            result = result.split(CMTS_NODE_TOKEN).join(cmts);
        }
        if (result.includes(TEXT_NODE_TOKEN)) {
            const node = String(ticket.node || '').trim();
            if (!node) return null;
            result = result.split(TEXT_NODE_TOKEN).join(node);
        }
        return result;
    }

    function resolveMacroTextarea(action, ticket = {}) {
        const template = action.valueTemplate ?? action.value ?? '';
        const lines = String(template).split('\n');
        const source = String(action.value ?? template).split('\n');
        const emptyLabel = /^([ \t]*(?:NODO[ \t]+CMTS|ZONA[ \t]+T[EÉ]CNICA|NODO)[ \t]*:[ \t]*)(\r?)$/i;
        for (let index = 0; index < source.length; index += 1) {
            const match = source[index].match(emptyLabel);
            if (!match) continue;
            const preferred = String(ticket.cmts || '').trim() || String(ticket.node || '').trim();
            if (!preferred) return null;
            // The original value identifies genuinely blank fields even in older
            // macros whose templates already contain a Nodo/Nodo CMTS token.
            lines[index] = `${match[1]}${preferred}${match[2]}`;
        }
        const preferred = String(ticket.cmts || '').trim() || String(ticket.node || '').trim();
        let missing = false;
        const text = lines.join('\n').replace(
            /(\bNODO[ \t]*:[ \t]*)(?:\{\{TICKET_NODE(?:_CMTS)?\}\}|[A-Z0-9][A-Z0-9_-]*)(?=[ \t]*(?:\r?$|[.,;/]|-[ \t]))/igm,
            (match, label) => {
                if (!preferred) { missing = true; return match; }
                return `${label}${preferred}`;
            }
        );
        return missing ? null : resolveTicketTemplate(text, ticket);
    }

    function shouldCollapseInputAction(previous, next) {
        return Boolean(previous && next
            && previous.type === next.type
            && (next.type === 'setValue' || next.type === 'setChecked')
            && previous.targetKey === next.targetKey);
    }

    function resolveNativeOption(select, saved) {
        const matches = Array.from(select.options).filter(option => !option.disabled
            && normalizeText(option.textContent) === saved.text);
        const exact = matches.filter(option => option.value === saved.value);
        if (exact.length === 1 || (MANUAL_MOICA && exact.length > 1)) return exact[0];
        if (MANUAL_MOICA && matches.length && new Set(matches.map(option => option.value)).size === 1) return matches[0];
        return matches.length === 1 ? matches[0] : null;
    }

    function isSensitiveInput(target) {
        if (!target) return false;
        const type = String(target.type || target.getAttribute?.('type') || '').toLowerCase();
        const autocomplete = String(target.autocomplete || target.getAttribute?.('autocomplete') || '');
        const name = `${target.name || ''} ${target.id || ''} ${target.getAttribute?.('aria-label') || ''}`;
        return type === 'password' || type === 'file' || SENSITIVE_NAME.test(`${name} ${autocomplete}`);
    }

    function normalizeText(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function cssEscape(value) {
        if (globalThis.CSS?.escape) return globalThis.CSS.escape(String(value));
        return String(value).replace(/[^a-zA-Z0-9_-]/g, character => `\\${character.codePointAt(0).toString(16)} `);
    }

    function selectorFor(element) {
        if (element.id) return `#${cssEscape(element.id)}`;
        const parts = [];
        let current = element;
        while (current && current.nodeType === 1 && parts.length < 7) {
            let part = String(current.localName || current.tagName || '').toLowerCase();
            if (!part) break;
            const classes = Array.from(current.classList || [])
                .filter(name => !/^v-(input--is|menu--|dialog--|ripple)/.test(name))
                .slice(0, 2);
            if (classes.length) part += classes.map(name => `.${cssEscape(name)}`).join('');
            const parent = current.parentElement;
            if (parent) {
                const siblings = Array.from(parent.children).filter(child => child.localName === current.localName);
                if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
            }
            parts.unshift(part);
            if (parent?.id) {
                parts.unshift(`#${cssEscape(parent.id)}`);
                break;
            }
            current = parent;
        }
        return parts.join(' > ');
    }

    function elementLabel(element) {
        const aria = element.getAttribute?.('aria-label');
        if (aria) return normalizeText(aria).slice(0, 180);
        const labels = Array.from(element.labels || []).map(label => normalizeText(label.textContent)).filter(Boolean);
        if (labels.length) return labels.join(' ').slice(0, 180);
        const field = element.closest?.('.v-input');
        const label = field?.querySelector('label');
        return normalizeText(label?.textContent).slice(0, 180);
    }

    function interactiveText(element) {
        if (!element.matches?.('button,a,[role="button"],[role="menuitem"],[role="option"],[role="tab"],label,.v-list-item__title,.v-list-item__content,.v-btn__content')) return '';
        return normalizeText(element.innerText || element.textContent).slice(0, 180);
    }

    function safeHtmlSnapshot(element) {
        if (!element.matches?.('button,a,input,textarea,select,[role="button"],[role="menuitem"],[role="option"],[role="tab"],label,[contenteditable="true"]')) return '';
        const clone = element.cloneNode(true);
        const controls = [
            ...(clone.matches?.('input,textarea,select,[contenteditable="true"]') ? [clone] : []),
            ...clone.querySelectorAll('input,textarea,select,[contenteditable="true"]')
        ];
        for (const field of controls) {
            if (field.matches('textarea,[contenteditable="true"]')) field.textContent = '';
            else {
                field.removeAttribute('value');
                field.removeAttribute('checked');
                field.removeAttribute('selected');
            }
            if (field.matches('select')) {
                for (const option of field.querySelectorAll('option')) option.removeAttribute('value');
            }
        }
        const html = clone.outerHTML || '';
        return html.length > 1200 ? `${html.slice(0, 1200)}…` : html;
    }

    function descriptorFor(element) {
        const ancestors = [];
        let parent = element.parentElement;
        while (parent && ancestors.length < 4) {
            ancestors.push({
                tag: String(parent.localName || '').toLowerCase(),
                id: String(parent.id || ''),
                role: String(parent.getAttribute?.('role') || ''),
                label: elementLabel(parent),
                text: interactiveText(parent),
                classes: Array.from(parent.classList || []).slice(0, 12)
            });
            parent = parent.parentElement;
        }
        const attributes = {};
        for (const attribute of Array.from(element.attributes || []).slice(0, 40)) {
            const name = String(attribute.name || '').toLowerCase();
            if (!name || name === 'value' || name === 'style' || name === 'srcdoc' || name.startsWith('on')) continue;
            attributes[name] = String(attribute.value || '').slice(0, 500);
        }
        const descriptor = {
            tag: String(element.localName || element.tagName || '').toLowerCase(),
            id: String(element.id || ''),
            name: String(element.getAttribute?.('name') || ''),
            role: String(element.getAttribute?.('role') || ''),
            type: String(element.getAttribute?.('type') || ''),
            ariaLabel: String(element.getAttribute?.('aria-label') || ''),
            title: String(element.getAttribute?.('title') || ''),
            placeholder: String(element.getAttribute?.('placeholder') || ''),
            label: elementLabel(element),
            text: interactiveText(element),
            classes: Array.from(element.classList || []).slice(0, 24),
            attributes,
            selector: selectorFor(element),
            html: safeHtmlSnapshot(element),
            ancestors
        };
        const menu = element.closest?.('.v-menu__content');
        if (menu && isRelatedEventMenu(menu) && element.closest?.('.v-list-item,[role="menuitem"]')) {
            descriptor.contextTarget = 'related-event';
        }
        return descriptor;
    }

    function isRelatedEventMenu(menu) {
        return normalizeText(menu.textContent).startsWith('Seleccione el evento');
    }

    function isRelatedEventDescriptor(descriptor) {
        if (descriptor.contextTarget) return descriptor.contextTarget === 'related-event';
        // Compatibility for recordings made before contextual event targets.
        return isOptionDescriptor(descriptor) && [descriptor, ...(descriptor.ancestors || [])]
            .some(item => /^\d+[A-Z]+\d+$/i.test(normalizeText(item.text)));
    }

    function templateDescriptor(descriptor, ticket) {
        if (descriptor.contextTarget === 'related-event') {
            const number = [descriptor, ...(descriptor.ancestors || [])]
                .map(item => normalizeText(item.text)).find(text => /^\d+[A-Z]+\d+$/i.test(text));
            if (number) descriptor = JSON.parse(replaceWholeIdentifier(JSON.stringify(descriptor), number, '{{RELATED_EVENT}}'));
        }
        return {
            ...descriptor,
            ariaLabel: tokenizeTicketValues(descriptor.ariaLabel, ticket),
            title: tokenizeTicketValues(descriptor.title, ticket),
            placeholder: tokenizeTicketValues(descriptor.placeholder, ticket),
            label: tokenizeTicketValues(descriptor.label, ticket),
            text: tokenizeTicketValues(descriptor.text, ticket),
            attributes: Object.fromEntries(Object.entries(descriptor.attributes || {}).map(([name, value]) => [
                name,
                name === 'id' || name === 'name' || name === 'type' || name === 'role'
                    ? value
                    : tokenizeTicketValues(value, ticket)
            ])),
            ancestors: (descriptor.ancestors || []).map(ancestor => ({
                ...ancestor,
                label: tokenizeTicketValues(ancestor.label, ticket),
                text: tokenizeTicketValues(ancestor.text, ticket)
            }))
        };
    }

    function renderDescriptor(descriptor, ticket) {
        return {
            ...descriptor,
            currentEvent: descriptor.contextTarget === 'related-event' ? ticket.relatedEvent || '' : '',
            ariaLabel: resolveTicketTemplate(descriptor.ariaLabel, ticket),
            title: resolveTicketTemplate(descriptor.title, ticket),
            placeholder: resolveTicketTemplate(descriptor.placeholder, ticket),
            label: resolveTicketTemplate(descriptor.label, ticket),
            text: resolveTicketTemplate(descriptor.text, ticket),
            attributes: Object.fromEntries(Object.entries(descriptor.attributes || {}).map(([name, value]) => [
                name,
                name === 'id' || name === 'name' || name === 'type' || name === 'role'
                    ? value
                    : resolveTicketTemplate(value, ticket)
            ])),
            ancestors: (descriptor.ancestors || []).map(ancestor => ({
                ...ancestor,
                label: resolveTicketTemplate(ancestor.label, ticket),
                text: resolveTicketTemplate(ancestor.text, ticket)
            }))
        };
    }

    function scoreCandidate(candidate, descriptor) {
        if (!candidate || String(candidate.localName || '').toLowerCase() !== descriptor.tag) return -1;
        for (const name of ['v-list-item__title', 'v-list-item__content', 'v-btn__content', 'v-input__slot']) {
            if (descriptor.classes?.includes(name) && !candidate.classList?.contains(name)) return -1;
        }
        const candidateRole = candidate.getAttribute('role') || '';
        const candidateName = candidate.getAttribute('name') || '';
        const candidateType = candidate.getAttribute('type') || '';
        const candidateLabel = elementLabel(candidate);
        const candidateText = interactiveText(candidate);
        if (descriptor.role && candidateRole && candidateRole !== descriptor.role) return -1;
        if (descriptor.name && candidateName && candidateName !== descriptor.name) return -1;
        if (descriptor.type && candidateType && candidateType !== descriptor.type) return -1;
        if (descriptor.label && candidateLabel && candidateLabel !== descriptor.label) return -1;
        if (descriptor.text && candidateText && candidateText !== descriptor.text) return -1;
        let score = 0;
        if (descriptor.id && !/^(input|list-item|list)-\d+(?:-\d+)?$/.test(descriptor.id) && candidate.id === descriptor.id) score += 12;
        if (descriptor.role && candidateRole === descriptor.role) score += 5;
        if (descriptor.name && candidateName === descriptor.name) score += 6;
        if (descriptor.type && candidateType === descriptor.type) score += 4;
        if (descriptor.ariaLabel && normalizeText(candidate.getAttribute('aria-label')) === normalizeText(descriptor.ariaLabel)) score += 8;
        if (descriptor.title && normalizeText(candidate.getAttribute('title')) === normalizeText(descriptor.title)) score += 5;
        if (descriptor.placeholder && normalizeText(candidate.getAttribute('placeholder')) === normalizeText(descriptor.placeholder)) score += 5;
        if (descriptor.label && candidateLabel === descriptor.label) score += 9;
        if (descriptor.text && candidateText === descriptor.text) score += 8;
        const sharedClasses = (descriptor.classes || []).filter(name => candidate.classList?.contains(name)).length;
        score += Math.min(sharedClasses, 3);
        let ancestor = candidate.parentElement;
        for (const expected of descriptor.ancestors || []) {
            if (!ancestor) break;
            // Older inner-content recordings identify the option by its parent's text.
            // Generated IDs change on remount, and classes alone tie all dropdown choices.
            const ancestorText = interactiveText(ancestor);
            if (expected.text && ancestorText && expected.text !== ancestorText) return -1;
            if (expected.text && ancestorText === expected.text) score += 8;
            if (expected.tag && String(ancestor.localName || '').toLowerCase() === expected.tag) score += 1;
            if (expected.id && ancestor.id === expected.id) score += 5;
            if (expected.role && ancestor.getAttribute('role') === expected.role) score += 3;
            if (expected.label && elementLabel(ancestor) === expected.label) score += 4;
            const sharedAncestorClasses = (expected.classes || []).filter(name => ancestor.classList?.contains(name)).length;
            score += Math.min(sharedAncestorClasses, 2);
            ancestor = ancestor.parentElement;
        }
        return score;
    }

    function targetKeyFor(element) {
        return element.id ? `id:${element.id}` : `css:${selectorFor(element)}`;
    }

    function uniqueBestCandidate(candidates, descriptor) {
        const ranked = candidates
            .map(element => ({ element, score: scoreCandidate(element, descriptor) }))
            .filter(item => item.score > 0)
            .sort((a, b) => b.score - a.score);
        if (!ranked.length || (ranked[1] && ranked[1].score === ranked[0].score)) return null;
        return ranked[0].element;
    }

    function replaceMacroStep(macro, index, targetKey, target) {
        const previousAction = macro.actions[index];
        if (!previousAction) throw new Error('El paso de la macro ya no existe.');
        const previousTarget = JSON.stringify(previousAction.target);
        const actions = macro.actions.map((action, position) => position >= index
            && action.targetKey === previousAction.targetKey
            && JSON.stringify(action.target) === previousTarget
            ? { ...action, targetKey, target } : action);
        return { ...macro, actions, corrections: [...(macro.corrections || []), {
            step: index + 1, correctedAt: new Date().toISOString(), previousAction
        }] };
    }

    function isOptionDescriptor(descriptor) {
        return [descriptor, ...(descriptor.ancestors || [])].some(item =>
            ['option', 'menuitem'].includes(item.role) || item.classes?.includes('v-list-item'));
    }

    function optionIdentity(descriptor) {
        return JSON.stringify({ tag: descriptor.tag, role: descriptor.role || '', label: descriptor.label || '',
            text: descriptor.text || descriptor.ancestors?.find(item => item.text)?.text || '' });
    }

    function addMacroStepAlternative(macro, index, target) {
        const previousAction = macro.actions[index];
        if (!previousAction) throw new Error('El paso de la macro ya no existe.');
        const previousTarget = JSON.stringify(previousAction.target);
        const actions = macro.actions.map((action, position) => {
            if (position < index || action.targetKey !== previousAction.targetKey
                || JSON.stringify(action.target) !== previousTarget) return action;
            const alternatives = [...(action.targetAlternatives || [])];
            if (optionIdentity(target) !== optionIdentity(action.target)
                && !alternatives.some(item => optionIdentity(item) === optionIdentity(target))) alternatives.push(target);
            return { ...action, targetAlternatives: alternatives };
        });
        return { ...macro, actions, corrections: [...(macro.corrections || []), {
            step: index + 1, correctedAt: new Date().toISOString(), kind: 'alternative', previousAction
        }] };
    }

    function isProblemStep(macro, index) {
        for (let position = index; position >= 0; position -= 1) {
            const descriptor = macro.actions[position].target;
            if (!descriptor || isOptionDescriptor(descriptor)) continue;
            const label = descriptor.label || descriptor.ancestors?.find(item => item.label)?.label;
            if (label) return normalizeText(label).toLowerCase() === 'problema';
        }
        return false;
    }

    function actionChoiceKey(action) {
        return `${action.targetKey}:${JSON.stringify(action.target)}`;
    }

    function moveOrganizedItem(items, id, direction, withinFolder = false) {
        const result = [...items];
        const index = result.findIndex(item => item.id === id);
        if (index < 0 || ![-1, 1].includes(direction)) return result;
        const indexes = result.map((item, position) => !withinFolder
            || (item.folderId || '') === (result[index].folderId || '') ? position : -1).filter(position => position >= 0);
        const next = indexes[indexes.indexOf(index) + direction];
        if (next !== undefined) [result[index], result[next]] = [result[next], result[index]];
        return result;
    }

    function applyOrganizationDrop(macros, folders, source, target) {
        const unchanged = { macros, folders };
        if (!source || !target) return unchanged;
        const isFolder = source.kind === 'folder';
        if ((!isFolder && source.kind !== 'macro') || (isFolder && target.kind !== 'folder')
            || (!isFolder && !['macro', 'group'].includes(target.kind))) return unchanged;
        const items = isFolder ? folders : macros;
        const item = items.find(entry => entry.id === source.id);
        if (!item) throw new Error('El elemento arrastrado ya no existe.');
        if (target.kind !== 'group' && source.id === target.id) return unchanged;
        const anchor = target.kind === 'group' ? null : items.find(entry => entry.id === target.id);
        if (target.kind !== 'group' && !anchor) throw new Error('El destino ya no existe.');
        const folderId = isFolder ? '' : target.kind === 'group' ? target.id : anchor.folderId || '';
        if (folderId && !folders.some(folder => folder.id === folderId)) throw new Error('La carpeta ya no existe.');
        const next = items.filter(entry => entry.id !== source.id);
        let index;
        if (anchor) index = next.findIndex(entry => entry.id === anchor.id) + (target.after ? 1 : 0);
        else {
            const last = next.reduce((position, entry, offset) => (entry.folderId || '') === folderId ? offset : position, -1);
            index = last < 0 ? next.length : last + 1;
        }
        next.splice(index, 0, isFolder || (item.folderId || '') === folderId ? item : { ...item, folderId });
        if (next.every((entry, offset) => entry === items[offset])) return unchanged;
        return isFolder ? { macros, folders: next } : { macros: next, folders };
    }

    function findActionTarget(action, ticket, dom = document) {
        const chosen = ticket.optionChoices?.get(actionChoiceKey(action));
        const descriptors = chosen ? [chosen] : [action.target, ...(action.targetAlternatives || [])];
        const matches = new Set(descriptors.map(item => findTarget(renderDescriptor(item, ticket), dom)).filter(Boolean));
        // Several learned options may coexist. Their order is not a ticket rule.
        return matches.size === 1 ? [...matches][0] : null;
    }

    globalThis.VienaTicketMacroCore = Object.freeze({
        tokenizeTicketValues,
        resolveTicketTemplate,
        resolveMacroTextarea,
        templateDescriptor,
        renderDescriptor,
        shouldCollapseInputAction,
        isSensitiveInput,
        selectorFor,
        descriptorFor,
        scoreCandidate,
        uniqueBestCandidate,
        findTarget,
        clickTarget,
        setNativeValue,
        playbackDelayMs,
        resolveNativeOption,
        replaceMacroStep,
        addMacroStepAlternative,
        findActionTarget,
        moveOrganizedItem,
        applyOrganizationDrop
    });

    if (typeof document === 'undefined' || !document.body || !globalThis.chrome?.storage?.local) return;

    const state = {
        button: null,
        menu: null,
        status: null,
        nameInput: null,
        recording: null,
        macros: [],
        folders: [],
        macroFilter: '',
        applyMacroFilter: null,
        organizing: false,
        pendingDelete: '',
        cancelPlayback: false,
        repair: null,
        playing: false,
        hidden: true
    };

    function visible(element) {
        return Boolean(element && (element.offsetWidth || element.offsetHeight || element.getClientRects().length));
    }

    function activeTicketDialog() {
        const candidates = Array.from(document.querySelectorAll('.v-dialog__content--active'))
            .filter(visible)
            .filter(dialog => /^TICKET\s*:/i.test(normalizeText(dialog.querySelector('.v-toolbar__title')?.textContent)));
        return candidates[candidates.length - 1] || null;
    }

    function labelledValue(root, labelText) {
        for (const label of Array.from(root.querySelectorAll('.v-text-field__slot > label, label'))) {
            if (label.closest(`[${UI_ATTRIBUTE}]`)) continue;
            if (normalizeText(label.textContent).toLowerCase() !== labelText.toLowerCase()) continue;
            const field = label.closest('.v-input') || label.parentElement;
            const input = field?.querySelector('input,textarea,select');
            if (input && (visible(input) || input.closest('.viena-ticket-field-hidden'))) return String(input.value || '').trim();
        }
        return '';
    }

    function ticketContext(root = activeTicketDialog()) {
        if (MANUAL_MOICA) return { node: '', cmts: '' };
        if (!root) return { node: '', cmts: '' };
        return {
            node: labelledValue(root, 'Nodo'),
            cmts: labelledValue(root, 'Nodo CMTS')
        };
    }

    function ticketIsInitiated(root) {
        return Boolean(root && labelledValue(root, 'Estado').toUpperCase() === 'INICIADA');
    }

    function setStatus(message, isError = false) {
        if (!state.status) return;
        state.status.textContent = String(message || '');
        state.status.dataset.state = isError ? 'error' : 'info';
    }

    function markUi(element) {
        element.setAttribute(UI_ATTRIBUTE, '1');
        return element;
    }

    function makeButton(text, className = '') {
        const button = markUi(document.createElement('button'));
        button.type = 'button';
        button.textContent = text;
        button.className = `viena-macro-control ${className}`.trim();
        return button;
    }

    function isolateInteractiveSurface(surface) {
        for (const type of [
            'pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'dblclick',
            'keydown', 'keypress', 'keyup', 'input', 'change', 'focusin', 'focusout'
        ]) {
            surface.addEventListener(type, event => event.stopPropagation());
        }
        return surface;
    }

    function createUi() {
        const style = document.createElement('style');
        style.id = 'viena-ticket-macros-style';
        style.textContent = `
            [data-viena-macro-actions] { position:relative; display:flex; flex-wrap:wrap; align-items:center; row-gap:8px; }
            [data-viena-macro-actions] > #panel-plantillas-viena,
            [data-viena-macro-actions] #viena-custom-template-groups { flex-wrap:wrap; max-width:100%; row-gap:8px; }
            [data-viena-macro-actions] button { max-width:100%; min-width:0; height:auto; min-height:36px; white-space:normal; }
            [data-viena-macro-actions] .v-btn__content { white-space:normal; flex-wrap:wrap; }
            #viena-ticket-macros-anchor { display:inline-flex; flex:0 0 auto; align-items:center; padding:0; margin:0 7px; }
            #viena-ticket-macros-button { margin:0 !important; }
            @media (max-width:600px) { #FO-TICKET-ADD > .modal-header:has(#viena-ticket-macros-button) { padding-bottom:44px !important; } #FO-TICKET-ADD > .modal-header > #viena-ticket-macros-button { top:auto !important; bottom:5px; transform:translateX(-50%) !important; white-space:nowrap; } }
            @media (max-width:1200px) {
                [data-viena-macro-actions] { padding-right:0 !important; }
                [data-viena-macro-actions] > .viena-ticket-resync-btn { position:static !important; margin:0 12px !important; }
                [data-viena-macro-actions] > #panel-plantillas-viena,
                [data-viena-macro-actions] #viena-custom-template-groups { margin-left:0 !important; }
            }
            @media (max-width:960px) {
                [data-viena-responsive-ticket] .ma-5 > .row:not([data-viena-macro-actions]) > .col:not(.col-12) { flex:0 0 50%; max-width:50%; min-width:0; }
            }
            @media (max-width:520px) {
                [data-viena-responsive-ticket] .ma-5 > .row:not([data-viena-macro-actions]) > .col:not(.col-12) { flex-basis:100%; max-width:100%; }
            }
            #viena-ticket-macros-menu { position:fixed; z-index:2147483647; box-sizing:border-box; width:min(640px,calc(100vw - 20px)); max-height:min(86vh,820px); overflow:auto; padding:20px; border:1px solid #c7d5e4; border-radius:16px; background:#f8fafc; color:#24324a; box-shadow:0 18px 48px rgba(15,35,60,.24); font:16px/1.5 Arial,sans-serif; }
            #viena-ticket-macros-menu[hidden] { display:none !important; }
            #viena-ticket-macros-menu .viena-macro-saved-row[hidden] { display:none !important; }
            #viena-ticket-macros-menu * { box-sizing:border-box; }
            #viena-ticket-macros-menu [data-viena-macro-row] { display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:12px; margin:8px 0; border:1px solid #e2e8f0; border-radius:9px; background:#fff; }
            #viena-ticket-macros-menu [data-viena-macro-row] > span { min-width:0; flex:1; overflow-wrap:anywhere; font-weight:700; }
            #viena-ticket-macros-menu .viena-macro-repair-actions { display:flex; flex-direction:column; align-items:stretch; gap:10px; }
            #viena-ticket-macros-menu .viena-macro-repair-actions > span { flex:none; width:100%; overflow-wrap:normal; }
            #viena-ticket-macros-menu .viena-macro-repair-actions > button { width:100%; white-space:normal; overflow-wrap:break-word; }
            #viena-ticket-macros-menu .viena-macro-repair-actions > .viena-macro-danger { margin-top:4px; }
            #viena-ticket-macros-menu .viena-macro-saved-row { display:grid; grid-template-columns:minmax(0,1fr) auto 40px 40px; gap:8px; padding:10px 12px; margin:0; border:0; border-bottom:1px solid #e2e8f0; border-radius:0; }
            #viena-ticket-macros-menu .viena-macro-saved-row > span { font-size:16px; line-height:1.35; }
            #viena-ticket-macros-menu .viena-macro-saved-row > span > small { margin-top:3px; }
            #viena-ticket-macros-menu .viena-macro-name { display:-webkit-box; -webkit-box-orient:vertical; -webkit-line-clamp:2; overflow:hidden; }
            #viena-ticket-macros-menu .viena-macro-folder, #viena-ticket-macros-menu .viena-macro-ungrouped { margin:16px 0; border:1px solid #d7e1ed; border-radius:10px; overflow:clip; background:#fff; }
            #viena-ticket-macros-menu .viena-macro-ungrouped > p { margin:0; padding:12px; font-size:14px; font-weight:700; color:#526176; background:#edf2f8; }
            #viena-ticket-macros-menu .viena-macro-folder > p { padding:0 16px; color:#64748b; font-size:14px; }
            #viena-ticket-macros-menu .viena-macro-folder-header { display:grid; grid-template-columns:40px minmax(0,1fr) 40px; align-items:center; gap:8px; padding:8px 12px; background:#edf2f8; }
            #viena-ticket-macros-menu .viena-macro-drag-handle { cursor:grab; touch-action:auto; border:0; background:transparent; color:#526176; font:22px Arial,sans-serif; min-height:44px; width:40px; padding:0; margin:0; }
            #viena-ticket-macros-menu .viena-macro-drag-handle:active { cursor:grabbing; }
            #viena-ticket-macros-menu .viena-macro-drop-before { box-shadow:inset 0 3px #254c83; }
            #viena-ticket-macros-menu .viena-macro-drop-after { box-shadow:inset 0 -3px #254c83; }
            #viena-ticket-macros-menu .viena-macro-drop-group { outline:2px solid #254c83; outline-offset:-2px; }
            #viena-ticket-macros-menu .viena-macro-folder-header .viena-macro-folder-toggle { text-align:left; overflow-wrap:anywhere; border:0; background:transparent; color:#173f7a; padding:8px; font-size:15px; }
            #viena-ticket-macros-menu .viena-macro-folder-select, #viena-ticket-macros-menu select { width:100%; min-width:0; min-height:44px; padding:10px; color:#24324a; background:#fff; border:1px solid #b8c7d9; border-radius:8px; font:14px Arial,sans-serif; }
            #viena-ticket-macros-menu input { width:100%; min-height:48px; margin:8px 0 0; padding:12px; border:1px solid #aabbd0; border-radius:9px; background:#fff; color:#24324a; font:16px Arial,sans-serif; }
            #viena-ticket-macros-menu .viena-macro-header { position:sticky; top:-20px; z-index:2; display:flex; align-items:center; gap:12px; margin:-20px -20px 20px; padding:20px; background:linear-gradient(120deg,#173f7a,#0f5aa9); color:#fff; }
            #viena-ticket-macros-menu .viena-macro-header > div { flex:1; min-width:0; }
            #viena-ticket-macros-menu .viena-macro-header h3 { margin:4px 0 0; font-size:22px; color:#fff; overflow-wrap:anywhere; }
            .viena-macro-brand { font-size:10px; font-weight:700; letter-spacing:1px; text-transform:uppercase; opacity:.8; }
            #viena-ticket-macros-menu .viena-macro-description { display:block; margin-top:4px; font-size:13px; font-weight:400; color:#64748b; }
            #viena-ticket-macros-menu .viena-macro-control, #viena-ticket-macro-recording .viena-macro-control { border:1px solid #b8c7d9; border-radius:8px; background:#fff; color:#173f7a; padding:10px 14px; margin:0; font:700 14px Arial,sans-serif; cursor:pointer; min-height:44px; }
            #viena-ticket-macros-menu .viena-macro-primary { background:#0f5aa9; color:#fff; border-color:#0f5aa9; }
            #viena-ticket-macro-recording .viena-macro-stop { background:#b42318; color:#fff; border-color:#b42318; }
            #viena-ticket-macros-menu .viena-macro-danger { color:#b42318; border-color:#efcbc8; }
            #viena-ticket-macros-menu button:disabled { opacity:.5; cursor:default; }
            #viena-ticket-macros-menu button:focus-visible, #viena-ticket-macro-recording button:focus-visible, #viena-ticket-macros-menu input:focus-visible { outline:2px solid #1769aa; outline-offset:3px; }
            #viena-ticket-macros-menu button:hover:not(:disabled), #viena-ticket-macro-recording button:hover { filter:brightness(.95); }
            #viena-ticket-macros-menu [data-state="error"] { color:#b42318; }
            #viena-ticket-macro-recording { position:fixed; z-index:2147483646; top:12px; right:12px; width:min(480px,calc(100vw - 24px)); box-sizing:border-box; padding:20px; border:1px solid #c7d5e4; border-top:4px solid #173f7a; border-radius:12px; background:#fff; color:#24324a; box-shadow:0 8px 26px rgba(15,35,60,.2); font:16px/1.5 Arial,sans-serif; }
            #viena-ticket-macro-recording .viena-macro-record-title { display:flex; align-items:center; gap:8px; color:#173f7a; font-weight:700; }
            #viena-ticket-macro-recording .viena-macro-record-title::before { content:''; width:8px; height:8px; border-radius:50%; background:#b42318; flex:none; }
            #viena-ticket-macro-recording .viena-macro-record-name { display:block; margin:6px 0; font-weight:700; overflow-wrap:anywhere; }
            #viena-ticket-macro-recording .viena-macro-record-count { display:block; min-height:22px; color:#64748b; font-size:14px; font-variant-numeric:tabular-nums; }
            #viena-ticket-macro-recording .viena-macro-record-actions { display:flex; gap:8px; margin-top:12px; flex-wrap:wrap; }
            #viena-ticket-macro-recording[hidden] { display:none !important; }
            #viena-ticket-macro-playback { position:fixed; z-index:2147483646; bottom:16px; right:16px; width:min(400px,calc(100vw - 32px)); box-sizing:border-box; padding:18px; border:1px solid #c7d5e4; border-left:4px solid #173f7a; border-radius:12px; background:#fff; color:#24324a; box-shadow:0 6px 22px rgba(15,35,60,.18); font:16px/1.5 Arial,sans-serif; }
            #viena-ticket-macro-playback[hidden] { display:none !important; }
            #viena-ticket-macro-playback button { margin:12px 8px 0 0; min-height:44px; border:1px solid #b8c7d9; border-radius:8px; padding:10px 14px; background:#fff; color:#173f7a; font:700 14px Arial,sans-serif; cursor:pointer; }
            #viena-ticket-macro-playback [data-state="error"] { color:#b42318; }
            #viena-ticket-macros-menu .viena-macro-choice { display:block; width:100%; margin:7px 0; text-align:left; white-space:normal; overflow-wrap:anywhere; }
            #viena-ticket-macros-menu .viena-macro-option-list { max-height:240px; overflow-y:auto; margin-top:10px; }
            #viena-ticket-macros-menu .viena-macro-toolbar, #viena-ticket-macros-menu .viena-macro-form-actions { display:flex; gap:12px; flex-wrap:wrap; margin:20px 0; }
            #viena-ticket-macros-menu .viena-macro-toolbar > button, #viena-ticket-macros-menu .viena-macro-form-actions > button { flex:1; min-width:0; min-height:48px; }
            #viena-ticket-macros-menu .viena-macro-intro { margin:12px 0; color:#526176; font-size:15px; }
            #viena-ticket-macros-menu .viena-macro-field { display:block; margin:24px 0; font-size:15px; font-weight:700; }
            #viena-ticket-macros-menu .viena-macro-field[hidden] { display:none; }
            #viena-ticket-macros-menu .viena-macro-steps { display:flex; gap:12px; padding:0; list-style:none; margin:20px 0; font-size:14px; color:#64748b; }
            #viena-ticket-macros-menu .viena-macro-steps > li { flex:1; padding:10px; border-bottom:3px solid #d7e1ed; }
            #viena-ticket-macros-menu .viena-macro-steps [aria-current="step"] { color:#173f7a; font-weight:700; border-color:#173f7a; }
            #viena-ticket-macros-menu .viena-macro-options { min-width:0; }
            #viena-ticket-macros-menu .viena-macro-options > summary { display:flex; align-items:center; justify-content:center; width:40px; min-height:44px; border-radius:8px; color:#173f7a; cursor:pointer; font-size:24px; list-style:none; }
            #viena-ticket-macros-menu .viena-macro-options > summary::-webkit-details-marker { display:none; }
            #viena-ticket-macros-menu .viena-macro-options > summary:hover { background:#e2e8f0; }
            #viena-ticket-macros-menu .viena-macro-options > summary:focus-visible { outline:2px solid #1769aa; outline-offset:2px; }
            #viena-ticket-macros-menu .viena-macro-options[open] { grid-column:1/-1; border-top:1px solid #d7e1ed; padding-top:8px; }
            #viena-ticket-macros-menu .viena-macro-options[open] > summary { width:auto; justify-content:flex-start; font:700 14px Arial,sans-serif; }
            #viena-ticket-macros-menu .viena-macro-options[open] > summary::after { content:' Cerrar opciones'; margin-left:8px; }
            #viena-ticket-macros-menu .viena-macro-options-body { display:flex; flex-wrap:wrap; gap:10px; padding:8px 0; }
            #viena-ticket-macros-menu .viena-macro-options:not([open]) > .viena-macro-options-body { display:none; }
            #viena-ticket-macros-menu .viena-macro-options-body > label { width:100%; font-size:14px; font-weight:700; }
            #viena-ticket-macros-menu .viena-macro-options-body > label > select { margin-top:8px; }
            #viena-ticket-macros-menu .viena-macro-review-list { max-height:240px; overflow:auto; padding-left:28px; font-size:14px; }
            #viena-ticket-macros-menu .viena-macro-review-list > li { padding:8px 4px; border-bottom:1px solid #e2e8f0; overflow-wrap:anywhere; }
            #viena-ticket-macros-menu .viena-macro-repair-context { border-left:4px solid #a66a12; padding:14px 16px; border-radius:8px; background:#fff7e8; font-size:16px; }
            #viena-ticket-macros-menu .viena-macro-options-title { margin:24px 0 8px; font-size:16px; color:#173f7a; }
            #viena-ticket-macro-playback progress { display:block; width:100%; height:8px; margin-top:14px; accent-color:#173f7a; }
            #viena-ticket-macro-playback .viena-macro-danger { color:#b42318; border-color:#efcbc8; }
            #viena-ticket-macros-menu [aria-live]:empty { display:none; }
            @media (max-width:480px) {
                #viena-ticket-macros-menu .viena-macro-saved-row { grid-template-columns:minmax(0,1fr) 44px 40px 40px; padding:10px; gap:6px; }
                #viena-ticket-macros-menu .viena-macro-saved-row > .viena-macro-primary { font-size:0; padding:0; }
                #viena-ticket-macros-menu .viena-macro-saved-row > .viena-macro-primary::before { content:'▶'; font-size:18px; }
                #viena-ticket-macros-menu .viena-macro-saved-row > .viena-macro-options[open] > summary { width:auto; }
                #viena-ticket-macros-menu .viena-macro-steps { gap:4px; font-size:13px; }
                #viena-ticket-macros-menu .viena-macro-steps > li { padding:8px 4px; }
            }
        `;
        style.textContent += `
            @keyframes viena-macro-enter { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:translateY(0); } }
            #viena-ticket-macros-menu:not([hidden]), #viena-ticket-macros-menu > *, #viena-ticket-macro-recording:not([hidden]) { animation:viena-macro-enter 160ms ease-out; }
            #viena-ticket-macros-menu .viena-macro-control { transition:background-color 140ms ease, border-color 140ms ease; }
            #viena-ticket-macro-delete-modal { position:fixed; inset:0; z-index:2147483647; display:flex; align-items:center; justify-content:center; padding:20px; background:rgba(15,23,42,.48); font:16px/1.5 Arial,sans-serif; }
            #viena-ticket-macro-delete-modal [role="dialog"] { width:min(480px,100%); box-sizing:border-box; padding:24px; border-radius:12px; background:#fff; color:#24324a; box-shadow:0 18px 48px rgba(15,35,60,.3); animation:viena-macro-enter 160ms ease-out; }
            #viena-ticket-macro-delete-modal h3 { margin:0 0 12px; color:#173f7a; font-size:20px; }
            #viena-ticket-macro-delete-modal p { overflow-wrap:anywhere; }
            #viena-ticket-macro-delete-modal .viena-macro-modal-actions { display:flex; justify-content:flex-end; gap:10px; margin-top:20px; flex-wrap:wrap; }
            #viena-ticket-macro-delete-modal button { border:1px solid #b8c7d9; border-radius:8px; background:#fff; color:#173f7a; padding:10px 16px; min-height:44px; font:700 14px Arial,sans-serif; cursor:pointer; }
            #viena-ticket-macro-delete-modal .viena-macro-danger { background:#b42318; border-color:#b42318; color:#fff; }
            #viena-ticket-macro-delete-modal button:focus-visible { outline:2px solid #1769aa; outline-offset:3px; }
            @media (prefers-reduced-motion:reduce) { #viena-ticket-macros-menu, #viena-ticket-macros-menu > *, #viena-ticket-macro-recording, #viena-ticket-macro-delete-modal [role="dialog"] { animation:none !important; } #viena-ticket-macros-menu .viena-macro-control { transition:none; } }
        `;
        if (MANUAL_MOICA) style.textContent += `
            #viena-ticket-macros-menu { width:min(430px,calc(100vw - 20px)); max-height:min(78vh,660px); padding:12px; border-radius:10px; font-size:12px; line-height:1.35; }
            #viena-ticket-macros-menu .viena-macro-header { top:-12px; margin:-12px -12px 10px; padding:10px 12px; gap:6px; }
            #viena-ticket-macros-menu .viena-macro-header h3 { font-size:16px; margin-top:2px; }
            #viena-ticket-macros-menu .viena-macro-control, #viena-ticket-macro-recording .viena-macro-control { min-height:30px; padding:5px 8px; font-size:12px; border-radius:6px; }
            #viena-ticket-macros-menu input, #viena-ticket-macros-menu select { min-height:32px; padding:6px 8px; font-size:12px; margin-top:4px; }
            #viena-ticket-macros-menu .viena-macro-field { margin:10px 0; font-size:12px; }
            #viena-ticket-macros-menu .viena-macro-intro { margin:8px 0; font-size:11px; }
            #viena-ticket-macros-menu .viena-macro-toolbar, #viena-ticket-macros-menu .viena-macro-form-actions { gap:6px; margin:10px 0; }
            #viena-ticket-macros-menu .viena-macro-toolbar > button, #viena-ticket-macros-menu .viena-macro-form-actions > button { min-height:32px; }
            #viena-ticket-macros-menu .viena-macro-steps { margin:14px 0; gap:8px; font-size:12px; }
            #viena-ticket-macros-menu .viena-macro-steps > li { padding:7px 5px; }
            #viena-ticket-macros-menu [data-viena-macro-row] { padding:8px; margin:6px 0; gap:6px; }
            #viena-ticket-macros-menu .viena-macro-saved-row { padding:4px 8px; gap:5px; }
            #viena-ticket-macros-menu .viena-macro-saved-row > span { font-size:12px; }
            #viena-ticket-macros-menu .viena-macro-description { font-size:10px; margin-top:1px; }
            #viena-ticket-macros-menu .viena-macro-folder, #viena-ticket-macros-menu .viena-macro-ungrouped { margin:10px 0; }
            #viena-ticket-macros-menu .viena-macro-ungrouped > p { padding:8px; font-size:12px; }
            #viena-ticket-macros-menu .viena-macro-folder-header { padding:3px 6px; grid-template-columns:30px minmax(0,1fr) 30px; gap:5px; }
            #viena-ticket-macros-menu .viena-macro-folder-header .viena-macro-folder-toggle { padding:4px; font-size:12px; }
            #viena-ticket-macros-menu .viena-macro-options > summary { min-height:30px; }
            #viena-ticket-macros-menu .viena-macro-native-repair-actions { flex-direction:column; align-items:stretch; }
            #viena-ticket-macros-menu .viena-macro-native-repair-actions > span { flex:none; width:100%; }
            #viena-ticket-macros-menu .viena-macro-native-repair-actions > button { width:100%; white-space:normal; }
            #viena-ticket-macro-recording { width:min(360px,calc(100vw - 24px)); padding:12px; font-size:14px; line-height:1.4; border-radius:9px; }
            #viena-ticket-macro-recording .viena-macro-record-name { margin:4px 0; }
            #viena-ticket-macro-recording .viena-macro-record-count { font-size:12px; min-height:18px; }
            #viena-ticket-macro-recording .viena-macro-record-actions { margin-top:8px; gap:6px; }
        `;
        document.head.appendChild(style);

        const menu = markUi(document.createElement('section'));
        menu.id = 'viena-ticket-macros-menu';
        menu.hidden = true;
        menu.setAttribute('role', 'dialog');
        menu.setAttribute('aria-label', 'Crear y reproducir tareas');
        isolateInteractiveSurface(menu);
        document.body.appendChild(menu);
        state.menu = menu;

        const recordingBar = markUi(document.createElement('div'));
        recordingBar.id = 'viena-ticket-macro-recording';
        recordingBar.hidden = true;
        recordingBar.setAttribute('role', 'status');
        recordingBar.setAttribute('aria-live', 'polite');
        isolateInteractiveSurface(recordingBar);
        document.body.appendChild(recordingBar);

        return recordingBar;
    }

    const recordingBar = createUi();

    function row(name, buttons, description = '') {
        const item = markUi(document.createElement('div'));
        item.setAttribute('data-viena-macro-row', '1');
        const label = markUi(document.createElement('span'));
        label.textContent = name;
        if (description) {
            const detail = markUi(document.createElement('small'));
            detail.className = 'viena-macro-description';
            detail.textContent = description;
            label.appendChild(detail);
        }
        item.appendChild(label);
        for (const button of buttons) item.appendChild(button);
        return item;
    }

    function addHeading(container, text) {
        const header = markUi(document.createElement('div'));
        header.className = 'viena-macro-header';
        const titles = markUi(document.createElement('div'));
        const brand = markUi(document.createElement('span'));
        brand.className = 'viena-macro-brand';
        brand.textContent = 'VIENA NOC Tools';
        const heading = markUi(document.createElement('h3'));
        heading.textContent = MANUAL_MOICA ? text.replace(/Macros Tareas/g, 'MACROS TAREA MANUAL').replace(/VIENA/g, 'MOICA') : text;
        titles.append(brand, heading);
        header.appendChild(titles);
        container.appendChild(header);
        return header;
    }

    function addStatus(container, bindState = true) {
        const status = markUi(document.createElement('div'));
        status.setAttribute('aria-live', 'polite');
        status.style.cssText = 'min-height:22px;margin-top:12px;font-weight:700;font-size:14px;';
        container.appendChild(status);
        if (bindState) state.status = status;
        return status;
    }

    function addSteps(current) {
        const steps = markUi(document.createElement('ol'));
        steps.className = 'viena-macro-steps';
        steps.setAttribute('aria-label', 'Etapas de grabación');
        ['Preparar', MANUAL_MOICA ? 'Grabar en MOICA' : 'Grabar en VIENA', 'Guardar'].forEach((text, index) => {
            const item = document.createElement('li');
            item.textContent = `${index + 1}. ${text}`;
            if (index + 1 === current) item.setAttribute('aria-current', 'step');
            steps.appendChild(item);
        });
        state.menu.appendChild(steps);
    }

    function optionsPanel(name, controls) {
        const details = markUi(document.createElement('details'));
        details.className = 'viena-macro-options';
        const summary = markUi(document.createElement('summary'));
        summary.textContent = '⋯';
        summary.title = `Más opciones de ${name}`;
        summary.setAttribute('aria-label', summary.title);
        const body = markUi(document.createElement('div'));
        body.className = 'viena-macro-options-body';
        body.append(...controls);
        details.append(summary, body);
        details.addEventListener('keydown', event => {
            if (event.key === 'Escape' && details.open) {
                event.preventDefault();
                event.stopPropagation();
                details.open = false;
                summary.focus({ preventScroll: true });
            }
        });
        return details;
    }

    function macroSearchField() {
        const field = markUi(document.createElement('label'));
        field.className = 'viena-macro-field';
        field.textContent = 'Buscar macros';
        const input = markUi(document.createElement('input'));
        input.id = 'viena-ticket-macro-search';
        input.type = 'search';
        input.autocomplete = 'off';
        input.placeholder = 'Escribí el nombre de la macro…';
        input.setAttribute('aria-label', 'Buscar macros');
        input.value = state.macroFilter;
        input.addEventListener('input', () => {
            state.macroFilter = input.value;
            state.applyMacroFilter?.();
        });
        field.appendChild(input);
        return field;
    }

    function renderList(searchField = null) {
        state.applyMacroFilter = null;
        if (searchField instanceof Element) {
            for (const child of Array.from(state.menu.children)) if (child !== searchField) child.remove();
        } else { state.menu.replaceChildren(); searchField = macroSearchField(); }
        const groups = [];
        let dragged = null;
        let highlighted = null;
        const clearHighlight = () => {
            highlighted?.classList.remove('viena-macro-drop-before', 'viena-macro-drop-after', 'viena-macro-drop-group');
            highlighted = null;
        };
        const canDrag = () => !state.organizing && !state.playing && !state.recording?.active && !state.pendingDelete && !state.menu.hidden;
        const dragHandle = (kind, item) => {
            const handle = makeButton('⠿');
            handle.className = 'viena-macro-drag-handle';
            handle.title = `Arrastrar ${kind === 'macro' ? 'macro' : 'carpeta'} ${item.name}`;
            handle.setAttribute('aria-label', handle.title);
            handle.draggable = true;
            handle.addEventListener('dragstart', event => {
                if (!canDrag() || !event.dataTransfer) { event.preventDefault(); return; }
                dragged = { kind, id: item.id };
                event.dataTransfer.effectAllowed = 'move';
                event.dataTransfer.setData('text/plain', item.name);
                event.stopPropagation();
            });
            handle.addEventListener('dragend', () => { dragged = null; clearHighlight(); });
            handle.addEventListener('click', event => event.preventDefault());
            return handle;
        };
        const dropTarget = (element, kind, id) => {
            const accepts = () => dragged && canDrag() && (dragged.kind === 'folder' ? kind === 'folder' : kind !== 'folder')
                && !(dragged.kind === kind && dragged.id === id);
            const destination = event => ({ kind, id, after: event.clientY >= element.getBoundingClientRect().top + element.getBoundingClientRect().height / 2 });
            element.addEventListener('dragover', event => {
                if (!accepts()) return;
                event.preventDefault();
                event.stopPropagation();
                event.dataTransfer.dropEffect = 'move';
                clearHighlight();
                highlighted = element;
                element.classList.add(kind === 'group' ? 'viena-macro-drop-group' : destination(event).after ? 'viena-macro-drop-after' : 'viena-macro-drop-before');
            });
            element.addEventListener('dragleave', event => {
                if (!element.contains(event.relatedTarget)) clearHighlight();
            });
            element.addEventListener('drop', event => {
                if (!accepts()) return;
                event.preventDefault();
                event.stopPropagation();
                const source = dragged;
                const target = destination(event);
                dragged = null;
                clearHighlight();
                void organize((macros, folders) => applyOrganizationDrop(macros, folders, source, target));
            });
        };
        const header = addHeading(state.menu, 'Macros Tareas');
        state.menu.insertBefore(header, state.menu.firstChild);
        if (!searchField.isConnected) state.menu.appendChild(searchField);
        const close = makeButton('Cerrar');
        close.addEventListener('click', closeMenu);
        header.appendChild(close);
        const introduction = markUi(document.createElement('p'));
        introduction.className = 'viena-macro-intro';
        introduction.textContent = 'Elegí una macro para reproducirla. Arrastrá desde ⠿ para organizar; en ⋯ encontrás más opciones.';
        state.menu.appendChild(introduction);
        const toolbar = markUi(document.createElement('div'));
        toolbar.className = 'viena-macro-toolbar';
        const record = makeButton('Grabar nueva tarea', 'viena-macro-primary');
        record.addEventListener('click', renderNewMacroForm);
        const folder = makeButton('Crear carpeta');
        folder.addEventListener('click', renderFolderForm);
        toolbar.append(record, folder);
        state.menu.appendChild(toolbar);

        if (!state.macros.length) {
            const empty = markUi(document.createElement('p'));
            empty.textContent = 'Todavía no guardaste tareas macro.';
            state.menu.appendChild(empty);
        }

        const appendMacro = (macro, container) => {
            const play = makeButton('Reproducir', 'viena-macro-primary');
            play.title = `Reproducir ${macro.name}`;
            play.setAttribute('aria-label', play.title);
            play.addEventListener('click', () => {
                if (state.playing || state.recording?.active) return;
                void playMacro(macro);
            });
            const remove = makeButton('Eliminar', 'viena-macro-danger');
            remove.addEventListener('click', async () => {
                if (state.pendingDelete || state.playing || state.recording?.active) return;
                state.pendingDelete = macro.id;
                try {
                    if (await confirmMacroDeletion(macro)) await deleteMacro(macro.id);
                } finally {
                    state.pendingDelete = '';
                }
            });
            const siblings = state.macros.filter(item => (item.folderId || '') === (macro.folderId || ''));
            const rename = organizationButton('Renombrar', `Renombrar macro ${macro.name}`, () => renderRenameMacroForm(macro));
            const up = organizationButton('↑ Subir', `Subir macro ${macro.name}`, () => organize((macros, folders) =>
                ({ macros: moveOrganizedItem(macros, macro.id, -1, true), folders })));
            const down = organizationButton('↓ Bajar', `Bajar macro ${macro.name}`, () => organize((macros, folders) =>
                ({ macros: moveOrganizedItem(macros, macro.id, 1, true), folders })));
            up.disabled = siblings[0]?.id === macro.id;
            down.disabled = siblings[siblings.length - 1]?.id === macro.id;
            const item = row(macro.name, [play], `${macro.actions.length} pasos`);
            const name = markUi(document.createElement('span'));
            name.className = 'viena-macro-name';
            name.textContent = macro.name;
            name.title = macro.name;
            item.firstElementChild.firstChild.replaceWith(name);
            item.classList.add('viena-macro-saved-row');
            item.dataset.macroId = macro.id;
            item.appendChild(dragHandle('macro', macro));
            dropTarget(item, 'macro', macro.id);
            const destination = markUi(document.createElement('select'));
            destination.className = 'viena-macro-folder-select';
            destination.setAttribute('aria-label', `Carpeta de ${macro.name}`);
            for (const folder of [{ id: '', name: 'Sin carpeta' }, ...state.folders]) {
                const option = document.createElement('option');
                option.value = folder.id;
                option.textContent = folder.name;
                destination.appendChild(option);
            }
            destination.value = macro.folderId || '';
            destination.addEventListener('change', () => void organize((macros, folders) => {
                const folderId = destination.value;
                if (folderId && !folders.some(folder => folder.id === folderId)) throw new Error('La carpeta ya no existe.');
                return { macros: macros.map(item => item.id === macro.id ? { ...item, folderId } : item), folders };
            }));
            const destinationLabel = markUi(document.createElement('label'));
            destinationLabel.textContent = 'Mover a carpeta';
            destinationLabel.appendChild(destination);
            item.appendChild(optionsPanel(macro.name, [rename, destinationLabel, up, down, remove]));
            container.appendChild(item);
        };
        const ungrouped = markUi(document.createElement('section'));
        ungrouped.className = 'viena-macro-ungrouped';
        const ungroupedHeader = markUi(document.createElement('p'));
        ungroupedHeader.textContent = 'Sin carpeta';
        ungrouped.appendChild(ungroupedHeader);
        dropTarget(ungroupedHeader, 'group', '');
        const ungroupedMacros = state.macros.filter(item => !item.folderId || !state.folders.some(folder => folder.id === item.folderId));
        for (const macro of ungroupedMacros) appendMacro(macro, ungrouped);
        groups.push({ section: ungrouped, macros: ungroupedMacros, collapsed: false });
        state.menu.appendChild(ungrouped);
        state.folders.forEach((folder, index) => {
            const section = markUi(document.createElement('section'));
            section.className = 'viena-macro-folder';
            section.dataset.folderId = folder.id;
            const header = markUi(document.createElement('div'));
            header.className = 'viena-macro-folder-header';
            const children = state.macros.filter(macro => macro.folderId === folder.id);
            const toggle = organizationButton(`${folder.collapsed ? '▸' : '▾'} ${folder.name} (${children.length})`, `Abrir o cerrar carpeta ${folder.name}`,
                () => organize((macros, folders) => ({ macros, folders: folders.map(item => item.id === folder.id ? { ...item, collapsed: !item.collapsed } : item) })));
            toggle.classList.add('viena-macro-folder-toggle');
            toggle.setAttribute('aria-expanded', String(!folder.collapsed));
            const up = organizationButton('↑ Subir', `Subir carpeta ${folder.name}`, () => organize((macros, folders) => ({ macros, folders: moveOrganizedItem(folders, folder.id, -1) })));
            const down = organizationButton('↓ Bajar', `Bajar carpeta ${folder.name}`, () => organize((macros, folders) => ({ macros, folders: moveOrganizedItem(folders, folder.id, 1) })));
            up.disabled = index === 0;
            down.disabled = index === state.folders.length - 1;
            const remove = organizationButton('Eliminar carpeta', `Eliminar carpeta ${folder.name}`, async () => {
                if (state.pendingDelete) return;
                state.pendingDelete = folder.id;
                try {
                    if (await confirmMacroDeletion({ ...folder, kind: 'folder' })) await organize((macros, folders) => ({
                        macros: macros.map(item => item.folderId === folder.id ? { ...item, folderId: '' } : item),
                        folders: folders.filter(item => item.id !== folder.id)
                    }));
                } finally { state.pendingDelete = ''; }
            });
            const rename = organizationButton('Renombrar carpeta', `Renombrar carpeta ${folder.name}`, () => renderRenameMacroForm(folder, true));
            header.append(dragHandle('folder', folder), toggle, optionsPanel(folder.name, [rename, up, down, remove]));
            dropTarget(header, 'folder', folder.id);
            dropTarget(toggle, 'group', folder.id);
            section.appendChild(header);
            if (!folder.collapsed) {
                for (const macro of children) appendMacro(macro, section);
            }
            state.menu.appendChild(section);
            groups.push({ section, macros: children, collapsed: folder.collapsed, toggle, folder });
        });
        const noMatches = markUi(document.createElement('p'));
        noMatches.className = 'viena-macro-search-empty';
        noMatches.setAttribute('role', 'status');
        state.menu.appendChild(noMatches);
        const searchText = text => normalizeText(text).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
        state.applyMacroFilter = () => {
            const query = searchText(state.macroFilter);
            let count = 0;
            for (const group of groups) {
                const matches = group.macros.filter(macro => searchText(macro.name).includes(query));
                count += matches.length;
                group.section.hidden = Boolean(query) && !matches.length;
                if (group.toggle) {
                    const expanded = !group.collapsed || Boolean(query && matches.length);
                    group.toggle.setAttribute('aria-expanded', String(expanded));
                    group.toggle.textContent = `${expanded ? '▾' : '▸'} ${group.folder.name} (${group.macros.length})`;
                }
                if (group.collapsed) {
                    if (!query) group.section.querySelectorAll('.viena-macro-saved-row').forEach(item => item.remove());
                    else if (matches.length && !group.section.querySelector('.viena-macro-saved-row')) {
                        for (const macro of group.macros) appendMacro(macro, group.section);
                    }
                }
                const matchingIds = new Set(matches.map(macro => macro.id));
                for (const item of group.section.querySelectorAll('.viena-macro-saved-row')) item.hidden = !matchingIds.has(item.dataset.macroId);
            }
            noMatches.hidden = !query || count > 0;
            noMatches.textContent = noMatches.hidden ? '' : `No hay macros que coincidan con "${state.macroFilter}".`;
        };
        state.applyMacroFilter();
        addStatus(state.menu);
    }

    function organizationButton(text, label, callback) {
        const button = makeButton(text);
        button.setAttribute('aria-label', label);
        button.title = label;
        button.addEventListener('click', () => void callback());
        return button;
    }

    async function organize(change) {
        if (state.organizing || state.playing || state.recording?.active) return;
        state.organizing = true;
        try {
            const macros = await readMacros();
            const next = change(macros, state.folders);
            if (next.macros === macros && next.folders === state.folders) return;
            await writeMacros(next.macros, next.folders);
            renderList();
            positionMenu();
        } catch (error) {
            renderList();
            setStatus(`No se pudo guardar la organización: ${String(error?.message || error)}`, true);
        } finally { state.organizing = false; }
    }

    function renderRenameMacroForm(macro, isFolder = false) {
        if (state.organizing || state.playing || state.recording?.active || state.pendingDelete) return;
        state.menu.replaceChildren();
        addHeading(state.menu, isFolder ? 'Renombrar carpeta' : 'Renombrar macro');
        const help = markUi(document.createElement('p'));
        help.className = 'viena-macro-intro';
        help.textContent = isFolder ? 'Cambiá el nombre de esta carpeta en tu biblioteca.' : 'Cambiá el nombre para reconocer esta tarea en tu biblioteca.';
        const form = markUi(document.createElement('form'));
        const field = markUi(document.createElement('label'));
        field.className = 'viena-macro-field';
        field.textContent = isFolder ? 'Nuevo nombre de la carpeta' : 'Nuevo nombre de la macro';
        const input = markUi(document.createElement('input'));
        input.setAttribute('aria-label', field.textContent);
        input.autocomplete = 'off';
        input.maxLength = 60;
        input.value = macro.name;
        field.appendChild(input);
        const save = makeButton('Guardar nombre', 'viena-macro-primary');
        save.type = 'submit';
        const cancel = makeButton('Cancelar');
        const back = () => { if (!state.organizing) { renderList(); positionMenu(); } };
        cancel.addEventListener('click', back);
        form.addEventListener('keydown', event => {
            if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); back(); }
        });
        form.addEventListener('submit', async event => {
            event.preventDefault();
            event.stopPropagation();
            if (state.organizing) return;
            const name = normalizeText(input.value);
            if (!name || name.length > 60) {
                setStatus('Escribí un nombre de entre 1 y 60 caracteres.', true);
                input.focus({ preventScroll: true });
                return;
            }
            state.organizing = true;
            save.disabled = cancel.disabled = input.disabled = true;
            save.textContent = 'Guardando…';
            try {
                const macros = await readMacros();
                const items = isFolder ? state.folders : macros;
                const current = items.find(item => item.id === macro.id);
                if (!current) throw new Error(isFolder ? 'La carpeta ya no existe. Volvé a la biblioteca.' : 'La macro ya no existe. Volvé a la biblioteca.');
                if (current.name !== macro.name) throw new Error('El nombre cambió en otra ventana. Volvé a la biblioteca y abrí Renombrar nuevamente.');
                if (items.some(item => item.id !== macro.id && item.name.toLowerCase() === name.toLowerCase())) {
                    throw new Error(isFolder ? 'Ya existe una carpeta con ese nombre.' : 'Ya existe una macro con ese nombre.');
                }
                if (current.name !== name) {
                    const renamed = items.map(item => item.id === macro.id ? { ...item, name } : item);
                    await writeMacros(isFolder ? macros : renamed, isFolder ? renamed : undefined);
                }
                else state.macros = macros;
                renderList();
                positionMenu();
                setStatus(isFolder ? 'Nombre de la carpeta guardado.' : 'Nombre de la macro guardado.', false);
            } catch (error) {
                if (state.menu.contains(input)) setStatus(`No se pudo renombrar: ${String(error?.message || error)}`, true);
            } finally {
                state.organizing = false;
                save.disabled = cancel.disabled = input.disabled = false;
                save.textContent = 'Guardar nombre';
            }
        });
        const actions = markUi(document.createElement('div'));
        actions.className = 'viena-macro-form-actions';
        actions.append(save, cancel);
        form.append(field, actions);
        state.menu.append(help, form);
        addStatus(state.menu);
        positionMenu();
        input.focus({ preventScroll: true });
        input.select();
    }

    function renderFolderForm() {
        state.menu.replaceChildren();
        addHeading(state.menu, 'Crear carpeta');
        const help = markUi(document.createElement('p'));
        help.className = 'viena-macro-intro';
        help.textContent = 'Agrupá tus macros por tarea o tecnología. Después podés moverlas arrastrando o desde Más opciones.';
        state.menu.appendChild(help);
        const input = markUi(document.createElement('input'));
        input.placeholder = 'Nombre de la carpeta';
        input.setAttribute('aria-label', 'Nombre de la carpeta');
        input.maxLength = 60;
        const create = makeButton('Guardar carpeta', 'viena-macro-primary');
        create.addEventListener('click', () => {
            const name = normalizeText(input.value);
            if (!name) { setStatus('Escribí un nombre para la carpeta.', true); input.focus(); return; }
            void organize((macros, folders) => {
                if (folders.length >= MAX_MACROS) throw new Error('Se alcanzó el límite de carpetas.');
                if (folders.some(folder => folder.name.toLowerCase() === name.toLowerCase())) throw new Error('Ya existe una carpeta con ese nombre.');
                return { macros, folders: [...folders, { id: `folder-${crypto.randomUUID()}`, name, collapsed: false }] };
            });
        });
        const cancel = makeButton('Cancelar');
        cancel.addEventListener('click', renderList);
        const field = markUi(document.createElement('label'));
        field.className = 'viena-macro-field';
        field.textContent = 'Nombre de la carpeta';
        field.appendChild(input);
        const actions = markUi(document.createElement('div'));
        actions.className = 'viena-macro-form-actions';
        actions.append(create, cancel);
        state.menu.append(field, actions);
        addStatus(state.menu);
        input.focus({ preventScroll: true });
    }

    function confirmMacroDeletion(macro) {
        return new Promise(resolve => {
            const previousFocus = document.activeElement;
            const wasInert = state.menu.inert;
            state.menu.inert = true;
            const overlay = isolateInteractiveSurface(markUi(document.createElement('div')));
            overlay.id = 'viena-ticket-macro-delete-modal';
            const card = markUi(document.createElement('section'));
            card.setAttribute('role', 'dialog');
            card.setAttribute('aria-modal', 'true');
            card.setAttribute('aria-labelledby', 'viena-ticket-macro-delete-title');
            card.setAttribute('aria-describedby', 'viena-ticket-macro-delete-description');
            const title = markUi(document.createElement('h3'));
            title.id = 'viena-ticket-macro-delete-title';
            title.textContent = macro.kind === 'folder' ? 'Eliminar carpeta' : 'Eliminar macro';
            const description = markUi(document.createElement('p'));
            description.id = 'viena-ticket-macro-delete-description';
            description.textContent = macro.kind === 'folder'
                ? `¿Querés eliminar la carpeta "${macro.name}"? Sus macros se conservarán en Sin carpeta.`
                : `¿Querés eliminar "${macro.name}"? Esta acción no se puede deshacer.`;
            const actions = markUi(document.createElement('div'));
            actions.className = 'viena-macro-modal-actions';
            const cancel = makeButton('Cancelar');
            const confirm = makeButton(macro.kind === 'folder' ? 'Eliminar carpeta' : 'Eliminar macro', 'viena-macro-danger');
            let settled = false;
            const finish = confirmed => {
                if (settled) return;
                settled = true;
                overlay.remove();
                state.menu.inert = wasInert;
                if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
                resolve(confirmed);
            };
            cancel.addEventListener('click', () => finish(false));
            confirm.addEventListener('click', () => finish(true));
            overlay.addEventListener('click', event => { if (event.target === overlay) finish(false); });
            overlay.addEventListener('keydown', event => {
                if (event.key === 'Escape') { event.preventDefault(); finish(false); }
                if (event.key === 'Tab') {
                    event.preventDefault();
                    (document.activeElement === cancel ? confirm : cancel).focus();
                }
            });
            actions.append(cancel, confirm);
            card.append(title, description, actions);
            overlay.appendChild(card);
            document.body.appendChild(overlay);
            cancel.focus({ preventScroll: true });
        });
    }

    function renderNewMacroForm() {
        state.menu.replaceChildren();
        addHeading(state.menu, 'Grabar una tarea');
        addSteps(1);
        const warning = markUi(document.createElement('p'));
        warning.textContent = `Dale un nombre fácil de reconocer. Al iniciar, realizá la tarea en ${MANUAL_MOICA ? 'MOICA' : 'VIENA'}: se guardarán tus clics y lo que escribas. Vos decidís cuándo detenerla.`;
        warning.className = 'viena-macro-intro';
        state.menu.appendChild(warning);
        const input = markUi(document.createElement('input'));
        input.type = 'text';
        input.maxLength = 60;
        input.autocomplete = 'off';
        input.placeholder = 'Nombre de la tarea macro';
        input.setAttribute('aria-label', 'Nombre de la tarea macro');
        const field = markUi(document.createElement('label'));
        field.className = 'viena-macro-field';
        field.textContent = 'Nombre de la macro';
        field.appendChild(input);
        state.menu.appendChild(field);
        const folder = markUi(document.createElement('select'));
        folder.setAttribute('aria-label', 'Carpeta de la macro');
        for (const item of [{ id: '', name: 'Sin carpeta' }, ...state.folders, { id: '__new__', name: 'Crear nueva carpeta…' }]) {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.name;
            folder.appendChild(option);
        }
        const folderField = markUi(document.createElement('label'));
        folderField.className = 'viena-macro-field';
        folderField.textContent = 'Carpeta';
        folderField.appendChild(folder);
        const newFolderField = markUi(document.createElement('label'));
        newFolderField.className = 'viena-macro-field';
        newFolderField.textContent = 'Nombre de la nueva carpeta';
        newFolderField.hidden = true;
        const newFolder = markUi(document.createElement('input'));
        newFolder.type = 'text';
        newFolder.maxLength = 60;
        newFolder.autocomplete = 'off';
        newFolder.setAttribute('aria-label', 'Nombre de la nueva carpeta');
        newFolderField.appendChild(newFolder);
        folder.addEventListener('change', () => {
            newFolderField.hidden = folder.value !== '__new__';
            if (!newFolderField.hidden) newFolder.focus();
        });
        state.menu.append(folderField, newFolderField);
        const privacy = markUi(document.createElement('p'));
        privacy.className = 'viena-macro-intro';
        privacy.textContent = 'Queda guardada en este navegador. Evitá incluir datos sensibles.';
        state.menu.appendChild(privacy);
        state.nameInput = input;
        const begin = makeButton('Iniciar grabación', 'viena-macro-primary');
        begin.addEventListener('click', () => startRecording(input.value, folder.value, newFolder.value));
        const back = makeButton('Volver');
        back.addEventListener('click', renderList);
        const actions = markUi(document.createElement('div'));
        actions.className = 'viena-macro-form-actions';
        actions.append(begin, back);
        state.menu.appendChild(actions);
        addStatus(state.menu);
        setTimeout(() => {
            if (state.menu.contains(input) && !state.menu.hidden) {
                try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
            }
        }, 0);
    }

    function renderReview() {
        state.menu.replaceChildren();
        const recording = state.recording;
        addHeading(state.menu, 'Grabación detenida');
        addSteps(3);
        const summary = markUi(document.createElement('p'));
        summary.textContent = `${recording.actions.length} acciones capturadas para "${recording.name}".`;
        state.menu.appendChild(summary);
        const help = markUi(document.createElement('p'));
        help.className = 'viena-macro-intro';
        help.textContent = 'Revisá el recorrido. Guardar agrega esta macro a tu biblioteca; Descartar elimina sólo esta grabación.';
        state.menu.appendChild(help);
        const steps = document.createElement('ol');
        steps.className = 'viena-macro-review-list';
        const verbs = { click: 'Seleccionar', setValue: 'Escribir en', setChecked: 'Cambiar selección de', key: 'Navegar en', focus: 'Ubicar', blur: 'Salir de' };
        for (const action of recording.actions) {
            const step = document.createElement('li');
            const target = action.target;
            const name = isRelatedEventDescriptor(target) ? 'evento del ticket actual' : target.label || target.text
                || target.ancestors?.find(item => item.label)?.label || target.ancestors?.find(item => item.text)?.text || 'control de VIENA';
            step.textContent = `${verbs[action.type] || 'Acción en'} ${name}`;
            steps.appendChild(step);
        }
        state.menu.appendChild(steps);
        const save = makeButton('Guardar tarea', 'viena-macro-primary');
        save.disabled = Boolean(recording.failure) || recording.actions.length === 0;
        save.addEventListener('click', () => void saveRecording());
        const discard = makeButton('Descartar');
        discard.addEventListener('click', () => {
            state.recording = null;
            renderList();
        });
        const actions = markUi(document.createElement('div'));
        actions.className = 'viena-macro-form-actions';
        actions.append(save, discard);
        state.menu.appendChild(actions);
        addStatus(state.menu);
        if (recording.failure) setStatus(recording.failure, true);
        else if (recording.warnings.length) setStatus(recording.warnings[0], false);
    }

    function renderRecordingBar() {
        if (!state.recording?.active) {
            recordingBar.hidden = true;
            return;
        }
        recordingBar.hidden = false;
        // Keep the pressed control alive while textarea blur/change is captured.
        if (!recordingBar.firstElementChild) {
            const title = markUi(document.createElement('div'));
            title.className = 'viena-macro-record-title';
            title.textContent = '2 de 3 · Grabación en curso';
            const name = markUi(document.createElement('span'));
            name.className = 'viena-macro-record-name';
            const count = markUi(document.createElement('span'));
            count.className = 'viena-macro-record-count';
            const actions = markUi(document.createElement('div'));
            actions.className = 'viena-macro-record-actions';
            const stop = makeButton('Detener grabación', 'viena-macro-stop');
            stop.addEventListener('click', stopRecording);
            const cancel = makeButton('Cancelar');
            cancel.addEventListener('click', cancelRecording);
            actions.append(stop, cancel);
            recordingBar.append(title, name, count, actions);
        }
        recordingBar.querySelector('.viena-macro-record-name').textContent = state.recording.name;
        recordingBar.querySelector('.viena-macro-record-count').textContent = `${state.recording.actions.length} pasos capturados · Seguí trabajando en ${MANUAL_MOICA ? 'MOICA' : 'VIENA'} y detenela cuando termines.`;
    }

    async function readMacros() {
        const result = await chrome.storage.local.get(STORAGE_KEY);
        const stored = result?.[STORAGE_KEY];
        if (stored === undefined) { state.folders = []; return []; }
        if (!stored || stored.schema !== 1 || !Array.isArray(stored.macros)) {
            throw new Error('El almacenamiento de macros tiene un formato no compatible; no se modificó.');
        }
        if (stored.macros.some(macro => !macro || typeof macro.id !== 'string'
            || typeof macro.name !== 'string' || !Array.isArray(macro.actions)
            || macro.actions.length > MAX_ACTIONS)) {
            throw new Error('Hay una tarea macro dañada; no se modificó el almacenamiento.');
        }
        if (stored.folders !== undefined && (!Array.isArray(stored.folders)
            || stored.folders.some(folder => !folder || typeof folder.id !== 'string' || typeof folder.name !== 'string')
            || new Set(stored.folders.map(folder => folder.id)).size !== stored.folders.length)) {
            throw new Error('El almacenamiento de carpetas no es compatible; no se modificó.');
        }
        state.folders = stored.folders || [];
        return stored.macros;
    }

    async function writeMacros(macros, folders) {
        if (macros.length > MAX_MACROS) throw new Error(`Se alcanzó el límite de ${MAX_MACROS} tareas macro.`);
        const previous = (await chrome.storage.local.get(STORAGE_KEY))?.[STORAGE_KEY];
        const payload = { ...(previous || {}), schema: 1, macros };
        if (folders !== undefined) payload.folders = folders;
        const bytes = new TextEncoder().encode(JSON.stringify(payload)).length;
        if (bytes > MAX_STORAGE_BYTES) throw new Error('Las macros superarían el límite local de almacenamiento de 4 MB.');
        await chrome.storage.local.set({ [STORAGE_KEY]: payload });
        state.macros = macros;
        state.folders = payload.folders || [];
    }

    async function openMenu() {
        state.hidden = false;
        state.menu.hidden = false;
        state.macroFilter = '';
        state.applyMacroFilter = null;
        state.menu.replaceChildren();
        addHeading(state.menu, 'Macros Tareas');
        const searchField = macroSearchField();
        state.menu.appendChild(searchField);
        positionMenu();
        searchField.querySelector('input').focus({ preventScroll: true });
        try {
            state.macros = await readMacros();
            state.pendingDelete = '';
            renderList(searchField);
            positionMenu();
            if (!state.menu.hidden) searchField.querySelector('input').focus({ preventScroll: true });
        } catch (error) {
            state.hidden = false;
            state.menu.hidden = false;
            state.menu.replaceChildren();
            addHeading(state.menu, 'No se pudieron cargar las tareas');
            addStatus(state.menu);
            setStatus(error.message, true);
            positionMenu();
        }
    }

    function closeMenu() {
        if (state.recording?.active || state.playing || state.pendingDelete) return;
        state.hidden = true;
        state.menu.hidden = true;
        state.button?.setAttribute('aria-expanded', 'false');
    }

    function positionMenu() {
        if (!state.button || state.menu.hidden) return;
        const rect = state.button.getBoundingClientRect();
        const menuRect = state.menu.getBoundingClientRect();
        const left = Math.max(10, Math.min(rect.left, window.innerWidth - menuRect.width - 10));
        const top = Math.max(10, Math.min(rect.bottom + 7, window.innerHeight - menuRect.height - 10));
        state.menu.style.left = `${Math.round(left)}px`;
        state.menu.style.top = `${Math.round(top)}px`;
    }

    function startRecording(rawName, folderId = '', rawFolderName = '') {
        const name = normalizeText(rawName);
        if (!name) {
            setStatus('Escribí un nombre para la tarea macro antes de grabar.', true);
            state.nameInput?.focus();
            return;
        }
        if (state.recording?.active) return;
        const newFolderName = folderId === '__new__' ? normalizeText(rawFolderName) : '';
        if (folderId === '__new__' && (!newFolderName || state.folders.some(folder => folder.name.toLowerCase() === newFolderName.toLowerCase()))) {
            setStatus(newFolderName ? 'Ya existe una carpeta con ese nombre; elegila en la lista.' : 'Escribí el nombre de la nueva carpeta.', true);
            return;
        }
        if (folderId && folderId !== '__new__' && !state.folders.some(folder => folder.id === folderId)) {
            setStatus('La carpeta ya no existe; elegí otra.', true);
            return;
        }
        state.recording = {
            id: `macro-${Date.now()}-${globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2, 10)}`,
            name,
            folderId: folderId === '__new__' ? '' : folderId,
            newFolderName,
            startedAt: Date.now(),
            lastActionAt: Date.now(),
            context: ticketContext(),
            actions: [],
            warnings: [],
            failure: '',
            active: true
        };
        renderRecordingBar();
        state.menu.hidden = true;
        state.hidden = true;
    }

    function stopRecording() {
        if (!state.recording?.active) return;
        state.recording.active = false;
        renderRecordingBar();
        state.menu.hidden = false;
        state.hidden = false;
        renderReview();
        positionMenu();
    }

    function cancelRecording() {
        if (!state.recording?.active) return;
        state.recording.active = false;
        state.recording = null;
        renderRecordingBar();
        state.menu.hidden = false;
        state.hidden = false;
        renderList();
        positionMenu();
    }

    function captureTarget(event) {
        if (!state.recording?.active || state.playing || !event.isTrusted) return null;
        const raw = event.target;
        if (!(raw instanceof Element) || raw.closest(`[${UI_ATTRIBUTE}]`)) return null;
        if (isSensitiveInput(raw)) {
            const warning = 'Se omitió un campo sensible o selector de archivo.';
            if (!state.recording.warnings.includes(warning)) state.recording.warnings.push(warning);
            renderRecordingBar();
            return null;
        }
        return raw;
    }

    function appendAction(action) {
        const recording = state.recording;
        if (!recording?.active) return;
        if (recording.actions.length >= MAX_ACTIONS) {
            recording.failure = `La grabación superó ${MAX_ACTIONS} acciones y no se puede guardar.`;
            stopRecording();
            return;
        }
        action.delayMs = Math.min(2500, Math.max(0, Date.now() - recording.lastActionAt));
        recording.lastActionAt = Date.now();
        const previous = recording.actions[recording.actions.length - 1];
        if (shouldCollapseInputAction(previous, action)) {
            action.eventTypes = [...new Set([...(previous.eventTypes || [previous.eventType]), ...(action.eventTypes || [action.eventType])])];
            recording.actions[recording.actions.length - 1] = action;
        } else {
            recording.actions.push(action);
        }
        renderRecordingBar();
    }

    function captureClick(event) {
        try {
            const raw = captureTarget(event);
            if (!raw) return;
            if (MANUAL_MOICA && raw.localName === 'option') return; // Native change records the selection.
            if (MANUAL_MOICA && raw.matches('.modal')) return; // Native selection can report a click on the modal backdrop.
            // VIENA binds some actions on the inner title, not the enclosing menu item.
            const target = raw;
            appendAction({
                type: 'click',
                targetKey: targetKeyFor(target),
                target: templateDescriptor(descriptorFor(target), state.recording.context),
                eventType: 'click'
            });
        } catch (error) {
            if (state.recording) {
                state.recording.failure = `No se pudo capturar una acción: ${String(error?.message || error)}.`;
                renderRecordingBar();
            }
        }
    }

    function captureValue(event) {
        try {
            const target = captureTarget(event);
            if (!target || !target.matches('input,textarea,select,[contenteditable="true"]')) return;
            const descriptor = descriptorFor(target);
            if (target.matches('input[type="checkbox"],input[type="radio"]')) {
                appendAction({
                    type: 'setChecked',
                    targetKey: targetKeyFor(target),
                    target: templateDescriptor(descriptor, state.recording.context),
                    checked: Boolean(target.checked),
                    eventType: event.type
                });
                return;
            }
            const value = target.isContentEditable ? target.textContent : target.value;
            const exactValue = String(value ?? '');
            appendAction({
                type: 'setValue',
                targetKey: targetKeyFor(target),
                target: templateDescriptor(descriptor, state.recording.context),
                value: exactValue,
                valueTemplate: MANUAL_MOICA ? exactValue : tokenizeTicketValues(exactValue, state.recording.context),
                ...(MANUAL_MOICA && target.localName === 'select' ? {
                    nativeOption: { text: normalizeText(target.selectedOptions[0]?.textContent), value: exactValue }
                } : {}),
                eventType: event.type
            });
        } catch (error) {
            if (state.recording) {
                state.recording.failure = `No se pudo capturar el contenido de un campo: ${String(error?.message || error)}.`;
                renderRecordingBar();
            }
        }
    }

    function captureKey(event) {
        if (!['Enter', 'Escape', 'Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
        try {
            const target = captureTarget(event);
            if (!target) return;
            appendAction({
                type: 'key',
                targetKey: targetKeyFor(target),
                target: templateDescriptor(descriptorFor(target), state.recording.context),
                key: event.key,
                code: event.code,
                altKey: Boolean(event.altKey),
                ctrlKey: Boolean(event.ctrlKey),
                metaKey: Boolean(event.metaKey),
                shiftKey: Boolean(event.shiftKey),
                eventType: 'keydown'
            });
        } catch (error) {
            if (state.recording) {
                state.recording.failure = `No se pudo capturar una tecla: ${String(error?.message || error)}.`;
                renderRecordingBar();
            }
        }
    }

    document.addEventListener('click', captureRepairTarget, true);
    document.addEventListener('click', captureClick, true);
    document.addEventListener('input', captureValue, true);
    document.addEventListener('change', captureValue, true);
    document.addEventListener('keydown', captureKey, true);
    let pointerOnMacroUi = false;
    document.addEventListener('pointerdown', event => {
        const target = event.target;
        pointerOnMacroUi = Boolean(target instanceof Element && target.closest(`[${UI_ATTRIBUTE}]`));
        if (pointerOnMacroUi) setTimeout(() => { pointerOnMacroUi = false; }, 0);
    }, true);
    document.addEventListener('focusin', event => captureFocus(event, 'focus'), true);
    document.addEventListener('focusout', event => captureFocus(event, 'blur'), true);

    function captureFocus(event, type) {
        try {
            if (pointerOnMacroUi || event.relatedTarget?.closest?.(`[${UI_ATTRIBUTE}]`)) return;
            const target = captureTarget(event);
            if (!target) return;
            appendAction({
                type,
                targetKey: targetKeyFor(target),
                target: templateDescriptor(descriptorFor(target), state.recording.context),
                eventType: event.type
            });
        } catch (error) {
            if (state.recording) {
                state.recording.failure = `No se pudo capturar el foco de un control: ${String(error?.message || error)}.`;
                renderRecordingBar();
            }
        }
    }

    async function saveRecording() {
        const recording = state.recording;
        if (!recording || recording.active || recording.failure || !recording.actions.length) return;
        try {
            const macros = await readMacros();
            if (macros.some(macro => macro.name.toLowerCase() === recording.name.toLowerCase())) {
                throw new Error('Ya existe una tarea con ese nombre; elegí otro nombre para evitar reemplazarla.');
            }
            let folders = state.folders;
            let folderId = recording.folderId || '';
            if (recording.newFolderName) {
                const existing = folders.find(folder => folder.name.toLowerCase() === recording.newFolderName.toLowerCase());
                folderId = existing?.id || `folder-${crypto.randomUUID()}`;
                if (!existing) folders = [...folders, { id: folderId, name: recording.newFolderName, collapsed: false }];
            } else if (folderId && !folders.some(folder => folder.id === folderId)) {
                throw new Error('La carpeta seleccionada ya no existe. La grabación se conserva.');
            }
            await writeMacros([...macros, {
                id: recording.id,
                name: recording.name,
                folderId,
                createdAt: new Date(recording.startedAt).toISOString(),
                actions: recording.actions
            }], folders);
            state.recording = null;
            renderList();
            setStatus('Tarea macro guardada localmente en este navegador.', false);
        } catch (error) {
            setStatus(`No se pudo guardar la tarea macro: ${String(error?.message || error)}`, true);
        }
    }

    async function deleteMacro(id) {
        try {
            const macros = await readMacros();
            await writeMacros(macros.filter(macro => macro.id !== id));
            state.pendingDelete = '';
            renderList();
            setStatus('Tarea macro eliminada de este navegador.', false);
        } catch (error) {
            setStatus(`No se pudo eliminar la tarea macro: ${String(error?.message || error)}`, true);
        }
    }

    function findTarget(descriptor, dom = document) {
        const dialogs = Array.from(dom.querySelectorAll('.v-dialog__content--active')).filter(visible);
        const activeDialog = dialogs[dialogs.length - 1];
        const loadingOverlay = activeDialog?.querySelector?.('.v-overlay--active');
        if (loadingOverlay && visible(loadingOverlay)) return null;
        const eligible = element => {
            if (!element || !visible(element) || element.disabled || element.closest?.(`[${UI_ATTRIBUTE}]`)) return false;
            // Vuetify keeps old dialogs and forms mounted; portaled menus remain outside the dialog.
            const dialog = element.closest?.('.v-dialog__content');
            if (dialog) return dialog === activeDialog;
            // Selection gestures can record the exact application root. It is
            // an ancestor of the active modal, not a background form control.
            if (descriptor.id === 'app' && element.id === 'app' && activeDialog
                && element.contains(activeDialog)) return true;
            return !activeDialog || Boolean(element.closest?.('.v-menu__content'));
        };
        if (isRelatedEventDescriptor(descriptor)) {
            const menus = Array.from(dom.querySelectorAll('.v-menu__content')).filter(menu => visible(menu) && isRelatedEventMenu(menu));
            if (menus.length) {
                const events = menus.flatMap(menu => Array.from(menu.querySelectorAll('.v-list-item__title'))).filter(eligible);
                if (descriptor.currentEvent) {
                    const selected = events.filter(item => normalizeText(item.textContent) === descriptor.currentEvent);
                    return selected.length === 1 ? selected[0] : null;
                }
                // Event numbers belong to the current ticket. Never choose by
                // the old number or silently pick one when several are listed.
                return events.length === 1 ? events[0] : null;
            }
            if (descriptor.contextTarget === 'related-event') return null;
        }
        let direct = null;
        try {
            direct = descriptor.selector ? dom.querySelector(descriptor.selector) : null;
        } catch (_) {}
        // MOICA uses stable IDs for chained selects. While one is disabled/loading,
        // another select with the same form ancestors is never a valid replacement.
        if (MANUAL_MOICA && descriptor.id) {
            return eligible(direct) && direct.id === descriptor.id && scoreCandidate(direct, descriptor) >= 4 ? direct : null;
        }
        const generatedId = /^(input|list-item|list)-\d+(?:-\d+)?$/.test(descriptor.id || '');
        if (!generatedId && eligible(direct) && scoreCandidate(direct, descriptor) >= 4) return direct;

        const tag = /^[a-z][a-z0-9-]*$/i.test(descriptor.tag) ? descriptor.tag : '*';
        const candidates = Array.from(dom.querySelectorAll(tag)).filter(eligible);
        return uniqueBestCandidate(candidates, descriptor);
    }

    const loadedOptionMenus = new WeakMap();
    const optionMenuFingerprint = menu => Array.from(menu.querySelectorAll('[role="option"],[role="menuitem"]'))
        .map(option => `${option.getAttribute('aria-disabled') || ''}:${normalizeText(option.textContent)}`).join('\n');

    async function loadCurrentMenuOptions(descriptor, menuScope = null) {
        if (!isOptionDescriptor(descriptor) || isRelatedEventDescriptor(descriptor)) return;
        const optionSelector = '[role="option"],[role="menuitem"]';
        const fingerprint = optionMenuFingerprint;
        for (const menu of (menuScope || Array.from(document.querySelectorAll('.v-menu__content'))).filter(visible)) {
            if (!menu.querySelector(optionSelector)) continue;
            if (loadedOptionMenus.get(menu) === fingerprint(menu)) continue;
            const initialScroll = menu.scrollTop;
            let stable = 0;
            let complete = false;
            try {
                // Actual VIENA VSelect renders twenty items, then appends twenty
                // when its own content scrolls near the bottom. Do not modify Vue data.
                for (let batch = 0; batch < 50 && menu.isConnected && visible(menu); batch += 1) {
                    if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                    const before = fingerprint(menu);
                    menu.scrollTop = menu.scrollHeight;
                    menu.dispatchEvent(new Event('scroll', { bubbles: false }));
                    await new Promise(resolve => setTimeout(resolve, 80));
                    stable = before === fingerprint(menu) ? stable + 1 : 0;
                    if (stable >= 2) { complete = true; break; }
                }
                if (complete) loadedOptionMenus.set(menu, fingerprint(menu));
            } finally {
                if (menu.isConnected) menu.scrollTop = initialScroll;
            }
        }
    }

    async function waitForTarget(descriptor, timeoutMs = 8000, action = null, ticket = null, step = null) {
        const end = Date.now() + timeoutMs;
        let stableMenu = null;
        let stableOptions = '';
        let stableSince = 0;
        while (Date.now() < end) {
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            if (action) await loadCurrentMenuOptions(descriptor);
            const target = action ? findActionTarget(action, ticket) : findTarget(descriptor);
            if (target && visible(target) && !target.disabled) return target;
            // A loaded dropdown cannot resolve a missing/ambiguous choice by
            // waiting eight seconds. Keep the full timeout for controls still loading.
            if (step && isOptionDescriptor(descriptor)) {
                const activator = correctionActivator(step);
                const opened = ticket.openedDropdown;
                const menus = correctionMenus(step);
                const newMenus = opened?.activator === activator
                    ? menus.filter(menu => !opened.before.has(menu)) : [];
                const menu = linkedCorrectionMenu(step, activator) || (newMenus.length === 1 ? newMenus[0] : null);
                const dialogs = Array.from(document.querySelectorAll('.v-dialog__content--active')).filter(visible);
                const overlay = dialogs[dialogs.length - 1]?.querySelector('.v-overlay--active');
                const options = menu ? optionMenuFingerprint(menu) : '';
                const ready = options && !(overlay && visible(overlay))
                    && (isRelatedEventDescriptor(descriptor) || loadedOptionMenus.get(menu) === options);
                if (!ready) { stableMenu = null; stableSince = 0; }
                else if (stableMenu !== menu || stableOptions !== options) {
                    stableMenu = menu;
                    stableOptions = options;
                    stableSince = Date.now();
                } else if (Date.now() - stableSince >= 600) return null;
            }
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        return null;
    }

    function setNativeValue(target, value) {
        if (target.isContentEditable) {
            target.textContent = value;
            return;
        }
        const prototype = Object.getPrototypeOf(target);
        const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
        if (setter) setter.call(target, value);
        else target.value = value;
        if (target.localName === 'textarea') {
            target.setSelectionRange(0, 0);
            target.scrollTop = 0;
            target.scrollLeft = 0;
        }
    }

    function playbackDelayMs(recordedDelay) {
        if (MANUAL_MOICA) return 0;
        const delay = Number(recordedDelay);
        return Number.isFinite(delay) ? Math.min(250, Math.max(0, delay / 10)) : 0;
    }

    async function clickTarget(target) {
        if (target.matches('select')) return;
        // Older recordings stored the menu-item wrapper. The supplied VIENA bundle
        // binds openTaskCreation on its title; clicking the title also bubbles to the wrapper.
        const hit = target.matches('[role="menuitem"],.v-list-item')
            ? target.querySelector('.v-list-item__title') || target
            : target;
        const rect = hit.getBoundingClientRect();
        const init = { bubbles: true, cancelable: true, composed: true, view: window,
            clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, button: 0 };
        hit.dispatchEvent(new MouseEvent('mouseover', init));
        // mouseenter does not bubble. Reproduce entry along the path so both a
        // hover activator and a portaled menu can cancel their pending close delay.
        const path = [];
        for (let element = hit; element; element = element.parentElement) path.unshift(element);
        for (const element of path) element.dispatchEvent(new MouseEvent('mouseenter', { ...init, bubbles: false }));
        hit.dispatchEvent(new MouseEvent('mousemove', init));
        await new Promise(resolve => setTimeout(resolve, 0));
        hit.dispatchEvent(new MouseEvent('mousedown', { ...init, buttons: 1 }));
        if (target.matches('button,a,input,textarea,[tabindex]')) target.focus({ preventScroll: true });
        hit.dispatchEvent(new MouseEvent('mouseup', { ...init, buttons: 0 }));
        hit.dispatchEvent(new MouseEvent('click', { ...init, buttons: 0, detail: 1 }));
    }

    async function waitForManualRequests() {
        if (!MANUAL_MOICA) return;
        const deadline = Date.now() + 8000;
        while (Date.now() < deadline) {
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            document.documentElement.removeAttribute('data-viena-moica-ajax-active');
            document.dispatchEvent(new Event('viena:moica-request-status'));
            const active = document.documentElement.getAttribute('data-viena-moica-ajax-active');
            if (active === '0' && document.documentElement.getAttribute('data-viena-moica-modal-pending') === '0') return;
            if (active === 'unavailable') throw new Error('MOICA no permite comprobar sus cargas pendientes. Se detuvo la macro.');
            await new Promise(resolve => setTimeout(resolve, 25));
        }
        throw new Error('MOICA no terminó de cargar sus datos. Se detuvo la macro; recargá la extensión y la página si el problema persiste.');
    }

    async function replaceManualProblems(ticket) {
        if (ticket.manualProblemsReplaced) return;
        const problems = Array.from(document.querySelectorAll('#TKT-PROBLEMAS-DIV > .jsProblema'));
        const removals = problems.map(problem => ({ problem, button: Array.from(problem.querySelectorAll('.panel-heading > button'))
            .find(button => /^delProblema\(this\);?$/i.test(String(button.getAttribute('onclick') || '').trim()) && !button.disabled) }));
        if (removals.some(item => !item.button)) throw new Error('No se pudo identificar el botón nativo para quitar el problema anterior.');
        for (const { problem, button } of removals) {
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            await clickTarget(button);
            const deadline = Date.now() + 1000;
            while (problem.isConnected && Date.now() < deadline && !state.cancelPlayback) {
                await new Promise(resolve => setTimeout(resolve, 25));
            }
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            if (problem.isConnected) throw new Error('MOICA no quitó el problema anterior; se detuvo la macro para evitar acumular problemas.');
        }
        ticket.manualProblemsReplaced = true;
    }

    async function executeAction(action, ticket, step = null) {
        await waitForManualRequests();
        const descriptor = renderDescriptor(action.target, ticket);
        if (Object.values({
            ariaLabel: descriptor.ariaLabel,
            title: descriptor.title,
            placeholder: descriptor.placeholder,
            label: descriptor.label,
            text: descriptor.text
        }).some(value => value === null)) {
            throw new Error('La macro requiere datos Nodo/Nodo CMTS que no están disponibles en este ticket.');
        }
        // A blur can be recorded after Vue has removed its control. It must not stop the next action.
        const target = action.type === 'blur' ? findActionTarget(action, ticket)
            : await waitForTarget(descriptor, 8000, action, ticket, step);
        if (!target && action.type === 'blur') return;
        if (!target) {
            const error = new Error(`No se encontró de forma inequívoca el control ${descriptor.label || descriptor.text || descriptor.id || descriptor.selector}.`);
            error.macroTargetMissing = true;
            throw error;
        }
        if (action.type === 'click') {
            // Older MOICA recordings include the modal root when a native select
            // closes. Replaying that click dismisses Bootstrap's problem dialog.
            if (MANUAL_MOICA && target.matches('.modal')) return;
            if (MANUAL_MOICA && ['BT-ADD-PROBLEMA', 'BTN-ADD-PROBLEMA-TKT'].includes(target.id)) {
                await replaceManualProblems(ticket);
            }
            target.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
            ticket.openedDropdown = target.matches('[role="combobox"],[aria-haspopup],.v-input__slot,.v-select__slot') || target.closest('.v-select')
                ? { activator: target, before: new Set(Array.from(document.querySelectorAll('.v-menu__content')).filter(visible)) } : null;
            await clickTarget(target);
        } else if (action.type === 'setValue') {
            let value = !MANUAL_MOICA && target.localName === 'textarea' ? resolveMacroTextarea(action, ticket)
                : resolveTicketTemplate(action.valueTemplate ?? action.value, ticket);
            if (MANUAL_MOICA && target.localName === 'select' && action.nativeOption) {
                const deadline = Date.now() + 8000;
                let option;
                while (!state.cancelPlayback && Date.now() < deadline) {
                    option = resolveNativeOption(target, action.nativeOption);
                    if (option) break;
                    await new Promise(resolve => setTimeout(resolve, 50));
                }
                if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                if (!option) {
                    const error = new Error(`La opción ${action.nativeOption.text} cambió o no está disponible.`);
                    error.macroTargetMissing = true;
                    throw error;
                }
                value = option.value;
            }
            if (value === null) throw new Error('La macro requiere Nodo o Nodo CMTS y el ticket actual no tiene ese dato.');
            setNativeValue(target, value);
            for (const eventType of action.eventTypes || [action.eventType || 'input']) {
                target.dispatchEvent(new Event(eventType, { bubbles: true }));
            }
        } else if (action.type === 'setChecked') {
            target.checked = Boolean(action.checked);
            for (const eventType of action.eventTypes || [action.eventType || 'change']) {
                target.dispatchEvent(new Event(eventType, { bubbles: true }));
            }
        } else if (action.type === 'key') {
            target.dispatchEvent(new KeyboardEvent('keydown', {
                key: action.key,
                code: action.code || '',
                altKey: Boolean(action.altKey),
                ctrlKey: Boolean(action.ctrlKey),
                metaKey: Boolean(action.metaKey),
                shiftKey: Boolean(action.shiftKey),
                bubbles: true,
                cancelable: true
            }));
        } else if (action.type === 'focus') {
            target.focus({ preventScroll: true });
        } else if (action.type === 'blur') {
            target.blur();
        } else {
            throw new Error(`Tipo de acción no compatible: ${String(action.type)}`);
        }
    }

    function cancelPlayback() {
        state.cancelPlayback = true;
        const repair = state.repair;
        if (repair && !repair.saving) {
            state.repair = null;
            repair.reject(new Error('Reproducción detenida por el operador.'));
        }
    }

    function correctionActivator(repair) {
        for (let index = repair.index - 1; index >= 0; index -= 1) {
            const action = repair.macro.actions[index];
            if (action.type !== 'click' || isOptionDescriptor(action.target)) continue;
            let target = findActionTarget(action, repair.ticket);
            if (!target && action.target.label) target = findTarget(renderDescriptor({ ...action.target, text: '' }, repair.ticket));
            if (!target) continue;
            if (target.matches('[role="combobox"],[aria-haspopup],.v-input__slot,.v-select__slot') || target.closest('.v-select')) return target;
            // Never replay a different button while repairing a dropdown selection.
            return null;
        }
        return null;
    }

    function correctionMenus(repair) {
        const related = isRelatedEventDescriptor(repair.macro.actions[repair.index].target);
        return Array.from(document.querySelectorAll('.v-menu__content')).filter(menu => visible(menu)
            && menu.querySelector('[role="option"],[role="menuitem"]') && isRelatedEventMenu(menu) === related);
    }

    function linkedCorrectionMenu(repair, activator) {
        const field = activator?.closest('.v-input');
        for (const element of [activator, ...(field?.querySelectorAll('[aria-controls],[aria-owns]') || [])]) {
            for (const attribute of ['aria-controls', 'aria-owns']) {
                for (const id of (element?.getAttribute(attribute) || '').split(/\s+/).filter(Boolean)) {
                    const owned = document.getElementById(id);
                    const menu = owned?.closest('.v-menu__content');
                    if (menu && correctionMenus(repair).includes(menu)) return menu;
                }
            }
        }
        return null;
    }

    async function ensureCorrectionMenu(repair) {
        const activator = correctionActivator(repair);
        const linked = linkedCorrectionMenu(repair, activator);
        if (linked) return repair.menu = linked;
        if (repair.menu && correctionMenus(repair).includes(repair.menu)) return repair.menu;
        if (!activator) throw new Error('Abrí el desplegable de este paso en VIENA y volvé a pulsar Ver opciones actuales, o usá Elegir opción en VIENA.');
        const before = new Set(correctionMenus(repair));
        await clickTarget(activator);
        const end = Date.now() + 2500;
        while (Date.now() < end && state.repair === repair && !state.cancelPlayback) {
            const linked = linkedCorrectionMenu(repair, activator);
            const opened = correctionMenus(repair).filter(menu => !before.has(menu));
            if (linked || opened.length === 1) return repair.menu = linked || opened[0];
            if (opened.length > 1) break;
            await new Promise(resolve => setTimeout(resolve, 80));
        }
        throw new Error('No se pudo identificar un único desplegable para este paso. Abrilo en VIENA y usá Elegir opción en VIENA.');
    }

    function findCorrectionTarget(descriptor, menu) {
        if (!menu?.isConnected || !visible(menu)) return null;
        return findTarget({ ...descriptor, contextTarget: 'exact' }, {
            querySelector: selector => menu.querySelector(selector),
            querySelectorAll: selector => selector === '.v-dialog__content--active'
                ? document.querySelectorAll(selector) : menu.querySelectorAll(selector)
        });
    }

    function showNativeOptionCorrection(repair) {
        state.menu.replaceChildren();
        const action = repair.macro.actions[repair.index];
        addHeading(state.menu, `Actualizar paso ${repair.index + 1}`);
        const info = markUi(document.createElement('p'));
        info.className = 'viena-macro-repair-context';
        info.textContent = `La macro esperaba: ${action.nativeOption.text}. Elegí la opción actual de MOICA para guardar la corrección y continuar desde este paso.`;
        state.menu.appendChild(info);
        const refresh = makeButton('Ver opciones actuales');
        refresh.addEventListener('click', () => showNativeOptionCorrection(repair));
        const stop = makeButton('Detener reproducción', 'viena-macro-danger');
        stop.addEventListener('click', cancelPlayback);
        const actions = row('Corregí sólo este paso.', [refresh, stop]);
        actions.classList.add('viena-macro-native-repair-actions');
        state.menu.appendChild(actions);
        repair.status = addStatus(state.menu, false);
        const list = markUi(document.createElement('div'));
        list.className = 'viena-macro-option-list';
        const select = findTarget(action.target);
        for (const option of Array.from(select?.options || [])) {
            if (option.disabled || !normalizeText(option.textContent)) continue;
            const saved = { text: normalizeText(option.textContent), value: option.value };
            const choice = makeButton(saved.text, 'viena-macro-choice');
            choice.addEventListener('click', async () => {
                if (repair.saving || state.repair !== repair) return;
                repair.saving = true;
                try {
                    const currentSelect = findTarget(action.target);
                    const currentOption = currentSelect && resolveNativeOption(currentSelect, saved);
                    if (!currentOption) throw new Error('La opción cambió. Pulsá Ver opciones actuales.');
                    const latest = await readMacros();
                    const macro = latest.find(item => item.id === repair.macro.id);
                    if (!macro || JSON.stringify(macro.actions[repair.index]) !== JSON.stringify(action)) {
                        throw new Error('La macro cambió en otra ventana. Detené y volvé a abrirla.');
                    }
                    if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                    const corrected = { ...macro, actions: macro.actions.map((item, index) => index !== repair.index ? item : {
                        ...item, nativeOption: { ...saved, value: currentOption.value },
                        value: currentOption.value, valueTemplate: currentOption.value,
                        nativeOptionHistory: [...(item.nativeOptionHistory || []), { ...item.nativeOption, correctedAt: new Date().toISOString() }]
                    }) };
                    await writeMacros(latest.map(item => item.id === macro.id ? corrected : item));
                    if (state.cancelPlayback) return;
                    state.repair = null;
                    state.menu.hidden = true;
                    state.hidden = true;
                    state.button?.setAttribute('aria-expanded', 'false');
                    repair.resolve(corrected);
                } catch (error) {
                    repair.status.textContent = String(error?.message || error);
                    repair.status.dataset.state = 'error';
                } finally {
                    repair.saving = false;
                }
            });
            list.appendChild(choice);
        }
        state.menu.appendChild(list);
        state.menu.hidden = false;
        state.hidden = false;
        state.button?.setAttribute('aria-expanded', 'true');
        positionMenu();
    }

    function showStepCorrection(repair) {
        if (MANUAL_MOICA && repair.macro.actions[repair.index].nativeOption) {
            showNativeOptionCorrection(repair);
            return;
        }
        state.menu.replaceChildren();
        const action = repair.macro.actions[repair.index];
        const descriptor = renderDescriptor(action.target, repair.ticket);
        addHeading(state.menu, `Actualizar paso ${repair.index + 1}`);
        const info = markUi(document.createElement('p'));
        const previous = isRelatedEventDescriptor(descriptor) ? 'Evento asociado al ticket actual' : descriptor.text || descriptor.label
            || descriptor.ancestors?.find(item => item.text)?.text || 'Control grabado';
        const available = new Set([action.target, ...(action.targetAlternatives || [])]
            .map(target => findTarget(renderDescriptor(target, repair.ticket))).filter(Boolean));
        info.textContent = available.size > 1
            ? `La macro "${repair.macro.name}" tiene varias opciones guardadas que aparecen en VIENA. Elegí la correcta para este ticket.`
            : `La macro "${repair.macro.name}" esperaba: ${previous}. VIENA no lo muestra como fue grabado.`;
        info.className = 'viena-macro-repair-context';
        state.menu.appendChild(info);
        const help = markUi(document.createElement('p'));
        help.textContent = 'Elegí la opción actual o señalala en VIENA. La macro continuará desde este paso, sin repetir los anteriores.';
        help.className = 'viena-macro-intro';
        state.menu.appendChild(help);
        if (isOptionDescriptor(descriptor) && !isRelatedEventDescriptor(descriptor)) {
            const label = markUi(document.createElement('label'));
            label.className = 'viena-macro-field';
            label.textContent = 'Cómo guardar esta opción';
            const mode = markUi(document.createElement('select'));
            mode.setAttribute('aria-label', 'Cómo guardar esta opción');
            mode.style.cssText = 'display:block;margin-top:10px;';
            for (const [value, text] of [['alternative', 'Conservar opciones anteriores'], ['replace', 'Reemplazar opción original']]) {
                const option = document.createElement('option');
                option.value = value;
                option.textContent = text;
                mode.appendChild(option);
            }
            mode.value = repair.keepAlternative ? 'alternative' : 'replace';
            mode.addEventListener('change', () => { repair.keepAlternative = mode.value === 'alternative'; });
            label.appendChild(mode);
            state.menu.appendChild(label);
            if (action.targetAlternatives?.length) {
                const known = markUi(document.createElement('p'));
                known.textContent = `Opciones guardadas: ${[action.target, ...action.targetAlternatives]
                    .map(item => item.text || item.ancestors?.find(ancestor => ancestor.text)?.text || item.label).filter(Boolean).join(' · ')}`;
                state.menu.appendChild(known);
            }
            help.textContent = 'Elegí la opción de este ticket. Podés conservar las opciones anteriores o reemplazarlas. Continúa desde este paso.';
        }
        if (isOptionDescriptor(descriptor)) {
            const optionsTitle = document.createElement('h4');
            optionsTitle.className = 'viena-macro-options-title';
            optionsTitle.textContent = 'Opciones que muestra VIENA';
            state.menu.appendChild(optionsTitle);
            const list = markUi(document.createElement('div'));
            list.className = 'viena-macro-option-list';
            state.menu.appendChild(list);
            const menus = correctionMenus(repair);
            const menu = linkedCorrectionMenu(repair, correctionActivator(repair))
                || (menus.includes(repair.menu) ? repair.menu : menus.length === 1 ? menus[0] : null);
            if (menu) repair.menu = menu;
            const options = Array.from(menu?.querySelectorAll('[role="option"],[role="menuitem"]') || []);
            for (const option of options) {
                const target = option.querySelector('.v-list-item__title,.v-list-item__content') || option;
                const current = descriptorFor(target);
                if (!visible(target) || option.getAttribute('aria-disabled') === 'true'
                    || findCorrectionTarget(current, menu) !== target) continue;
                const choice = makeButton(normalizeText(option.textContent), 'viena-macro-choice');
                choice.addEventListener('click', () => void saveStepCorrection(repair, null, current));
                list.appendChild(choice);
            }
            if (!list.childElementCount) {
                const empty = document.createElement('p');
                empty.textContent = 'No hay opciones visibles de este paso. Ver opciones actuales intenta abrir el desplegable; también podés elegir directamente en VIENA.';
                list.appendChild(empty);
            }
        }
        const capture = makeButton(isOptionDescriptor(descriptor) ? 'Elegir opción en VIENA' : 'Señalar control en VIENA', 'viena-macro-primary');
        capture.title = 'Captura una elección, guarda la corrección y continúa desde este paso.';
        capture.addEventListener('click', () => {
            if (repair.saving || repair.refreshing) return;
            repair.capture = true;
            state.menu.hidden = true;
            state.hidden = true;
            state.button?.setAttribute('aria-expanded', 'false');
            setStatus(isOptionDescriptor(descriptor)
                ? `Esperando tu elección para el paso ${repair.index + 1}. Abrí el desplegable en VIENA y elegí la opción correcta. Se guarda y continúa automáticamente; abrirlo no guarda una corrección. Podés detener la reproducción para cancelar.`
                : `Esperando tu elección para el paso ${repair.index + 1}. Hacé clic en el control correcto de VIENA. Se guarda y continúa automáticamente.`, false);
        });
        const refresh = makeButton('Ver opciones actuales');
        refresh.addEventListener('click', async () => {
            if (repair.saving || repair.refreshing) return;
            repair.refreshing = true;
            refresh.disabled = true;
            refresh.textContent = 'Buscando opciones…';
            try {
                const menu = isOptionDescriptor(descriptor) ? await ensureCorrectionMenu(repair) : null;
                await loadCurrentMenuOptions(descriptor, menu ? [menu] : null);
                if (state.repair === repair && !repair.saving) showStepCorrection(repair);
            } catch (error) {
                if (state.repair === repair) {
                    repair.status.textContent = String(error?.message || error);
                    repair.status.dataset.state = 'error';
                }
            } finally { repair.refreshing = false; refresh.disabled = false; refresh.textContent = 'Ver opciones actuales'; }
        });
        const stop = makeButton('Detener reproducción', 'viena-macro-danger');
        stop.addEventListener('click', cancelPlayback);
        const actions = row('Corregí sólo este paso.', [capture, refresh, stop]);
        actions.classList.add('viena-macro-repair-actions');
        state.menu.insertBefore(actions, state.menu.querySelector('.viena-macro-field') || state.menu.querySelector('.viena-macro-options-title'));
        repair.status = addStatus(state.menu, false);
        state.menu.hidden = false;
        state.hidden = false;
        state.button?.setAttribute('aria-expanded', 'true');
        positionMenu();
    }

    function requestStepCorrection(macro, index, ticket) {
        return new Promise((resolve, reject) => {
            const repair = { macro, index, ticket, resolve, reject, saving: false, capture: false, status: null,
                keepAlternative: isProblemStep(macro, index) || Boolean(macro.actions[index].targetAlternatives?.length) };
            state.repair = repair;
            setStatus(`Macro en pausa: el paso ${index + 1} requiere una corrección.`, false);
            showStepCorrection(repair);
        });
    }

    async function saveStepCorrection(repair, target, choice = null) {
        if (state.repair !== repair || repair.saving || repair.refreshing || state.cancelPlayback) return;
        repair.saving = true;
        try {
            if (choice) {
                const menu = await ensureCorrectionMenu(repair);
                await loadCurrentMenuOptions(renderDescriptor(repair.macro.actions[repair.index].target, repair.ticket), [menu]);
                target = findCorrectionTarget(choice, menu);
            }
            if (state.repair !== repair || state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            if (!target) throw new Error('La opción elegida ya no aparece en este desplegable. Pulsá Ver opciones actuales y elegí nuevamente.');
            const descriptor = descriptorFor(target);
            const menu = target.closest('.v-menu__content');
            const option = target.closest('[role="option"],[role="menuitem"]');
            if (isSensitiveInput(target) || option?.getAttribute('aria-disabled') === 'true' || (menu ? findCorrectionTarget(descriptor, menu)
                : findTarget({ ...descriptor, contextTarget: 'exact' })) !== target) {
                throw new Error('El control elegido ya no está disponible. Volvé a elegirlo en VIENA.');
            }
            const latest = [...await readMacros()];
            const position = latest.findIndex(item => item.id === repair.macro.id);
            if (position < 0 || JSON.stringify(latest[position].actions[repair.index])
                !== JSON.stringify(repair.macro.actions[repair.index])) {
                throw new Error('La macro cambió en otra ventana. Detené la reproducción y volvé a abrirla.');
            }
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            const previousAction = latest[position].actions[repair.index];
            const learnedTarget = templateDescriptor(descriptor, repair.ticket);
            const keepAlternative = repair.keepAlternative && isOptionDescriptor(previousAction.target)
                && !isRelatedEventDescriptor(previousAction.target);
            const corrected = keepAlternative
                ? addMacroStepAlternative(latest[position], repair.index, learnedTarget)
                : replaceMacroStep(latest[position], repair.index, targetKeyFor(target), learnedTarget);
            latest[position] = corrected;
            await writeMacros(latest);
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            const playback = document.getElementById('viena-ticket-macro-playback');
            if (playback) {
                let notice = playback.querySelector('.viena-macro-correction-notice');
                if (!notice) {
                    notice = markUi(document.createElement('p'));
                    notice.className = 'viena-macro-correction-notice';
                    notice.style.cssText = 'font-size:14px;color:#173f7a;';
                    playback.appendChild(notice);
                }
                notice.textContent = `Corrección guardada para el paso ${repair.index + 1}. La macro continúa desde este paso.`;
            }
            if (keepAlternative) {
                repair.ticket.optionChoices ||= new Map();
                repair.ticket.optionChoices.set(actionChoiceKey(previousAction), learnedTarget);
            }
            if (descriptor.contextTarget === 'related-event') {
                repair.ticket.relatedEvent = normalizeText(target.closest('.v-list-item,[role="menuitem"]')?.textContent || target.textContent);
            }
            state.repair = null;
            state.menu.hidden = true;
            state.hidden = true;
            state.button?.setAttribute('aria-expanded', 'false');
            repair.resolve(corrected);
        } catch (error) {
            if (state.cancelPlayback || state.repair !== repair) {
                state.repair = null;
                repair.reject(error);
            } else {
                repair.capture = false;
                showStepCorrection(repair);
                repair.status.textContent = String(error?.message || error);
                repair.status.dataset.state = 'error';
            }
        } finally {
            repair.saving = false;
        }
    }

    function captureRepairTarget(event) {
        const repair = state.repair;
        if (!repair?.capture || repair.saving || !event.isTrusted || state.cancelPlayback) return;
        const target = event.target;
        if (!(target instanceof Element) || target.closest(`[${UI_ATTRIBUTE}]`) || isSensitiveInput(target)) return;
        if (isOptionDescriptor(repair.macro.actions[repair.index].target)
            && !target.closest('[role="option"],[role="menuitem"],.v-list-item')) return;
        if (isOptionDescriptor(repair.macro.actions[repair.index].target)) {
            const menus = correctionMenus(repair);
            const expected = linkedCorrectionMenu(repair, correctionActivator(repair))
                || (menus.includes(repair.menu) ? repair.menu : menus.length === 1 ? menus[0] : null);
            if (!expected || target.closest('.v-menu__content') !== expected) {
                setStatus('Elegí la opción del desplegable correspondiente a este paso. La corrección sigue esperando tu elección.', false);
                return;
            }
        }
        // Capture the replacement click, then execute it once after the correction is saved.
        event.preventDefault();
        event.stopImmediatePropagation();
        void saveStepCorrection(repair, target);
    }

    async function playMacro(macro) {
        state.playing = true;
        state.cancelPlayback = false;
        state.menu.hidden = true;
        state.hidden = true;
        state.button?.setAttribute('aria-expanded', 'false');
        let playback = document.getElementById('viena-ticket-macro-playback');
        if (!playback) {
            playback = markUi(document.createElement('section'));
            playback.id = 'viena-ticket-macro-playback';
            playback.setAttribute('role', 'status');
            isolateInteractiveSurface(playback);
            document.body.appendChild(playback);
        }
        playback.replaceChildren();
        playback.hidden = false;
        const title = markUi(document.createElement('strong'));
        title.textContent = macro.name;
        playback.appendChild(title);
        const progress = markUi(document.createElement('progress'));
        progress.max = Math.max(1, macro.actions.length);
        progress.value = 0;
        progress.setAttribute('aria-label', 'Progreso de reproducción');
        playback.appendChild(progress);
        addStatus(playback);
        const cancel = makeButton('Detener reproducción', 'viena-macro-danger');
        cancel.addEventListener('click', cancelPlayback);
        playback.appendChild(cancel);
        const context = ticketContext();
        let currentMacro = macro;
        let currentStep = 0;
        let succeeded = false;
        try {
            if (MANUAL_MOICA) {
                await waitForManualRequests();
                await replaceManualProblems(context);
                const message = document.getElementById('TKT-MSG-ADD');
                if (!message || message.disabled || message.readOnly) throw new Error('El campo Mensaje de MOICA no está disponible para reemplazar su contenido.');
                setNativeValue(message, '');
                message.dispatchEvent(new Event('input', { bubbles:true }));
                message.dispatchEvent(new Event('change', { bubbles:true }));
            }
            for (let index = 0; index < currentMacro.actions.length; index += 1) {
                if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                currentStep = index + 1;
                const action = currentMacro.actions[index];
                setStatus(`Acción ${index + 1} de ${currentMacro.actions.length}…`, false);
                const delayMs = playbackDelayMs(action.delayMs);
                if (delayMs > 0) await new Promise(resolve => setTimeout(resolve, delayMs));
                if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                let completed = false;
                while (!completed) {
                    try {
                        await executeAction(currentMacro.actions[index], context, { macro: currentMacro, index, ticket: context });
                        progress.value = index + 1;
                        completed = true;
                    } catch (error) {
                        if (!error.macroTargetMissing || state.cancelPlayback) throw error;
                        currentMacro = await requestStepCorrection(currentMacro, index, context);
                        if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                    }
                }
                // Let Vue apply synchronous state changes before locating the next control.
                await new Promise(resolve => setTimeout(resolve, 0));
            }
            await waitForManualRequests();
            setStatus(`Se completaron ${currentMacro.actions.length} acciones. Revisá el resultado en ${MANUAL_MOICA ? 'MOICA' : 'VIENA'}.`, false);
            succeeded = true;
        } catch (error) {
            setStatus(`Reproducción detenida en la acción ${currentStep}: ${String(error?.message || error)}`, true);
        } finally {
            state.playing = false;
            state.cancelPlayback = false;
            state.repair = null;
            state.menu.hidden = true;
            state.hidden = true;
            state.button?.setAttribute('aria-expanded', 'false');
            cancel.remove();
            const dismiss = makeButton('Cerrar');
            dismiss.addEventListener('click', () => { playback.hidden = true; });
            const done = makeButton('Volver a las tareas');
            done.addEventListener('click', () => {
                playback.hidden = true;
                void openMenu();
            });
            playback.append(dismiss, done);
            if (succeeded) {
                const completedStatus = state.status;
                setTimeout(() => {
                    if (!state.playing && state.status === completedStatus) playback.hidden = true;
                }, 2000);
            }
        }
    }

    function mountButton() {
        if (MANUAL_MOICA) {
            const header = document.querySelector('#FO-TICKET-ADD > .modal-header');
            if (!header || state.button?.isConnected) return;
            const button = makeButton('MACROS TAREA MANUAL', 'viena-macro-primary');
            button.id = 'viena-ticket-macros-button';
            button.setAttribute('aria-haspopup', 'dialog');
            button.setAttribute('aria-expanded', 'false');
            header.style.position = 'relative';
            button.style.cssText = 'position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);margin:0;padding:6px 16px;border:1px solid #173f7a;border-radius:6px;background:#173f7a;color:white;font:700 13px Arial;cursor:pointer;';
            button.addEventListener('click', () => {
                if (state.recording?.active || state.playing) return;
                if (state.menu.hidden) void openMenu(); else closeMenu();
                button.setAttribute('aria-expanded', String(!state.menu.hidden));
            });
            header.appendChild(button);
            state.button = button;
            return;
        }
        const root = activeTicketDialog();
        const panel = root?.querySelector('#panel-plantillas-viena');
        const initiated = ticketIsInitiated(root);
        if (!initiated || !panel?.parentElement) {
            state.button?.parentElement?.remove();
            state.button = null;
            if (state.recording?.active) {
                state.recording.failure = 'El ticket dejó de estar INICIADA; se detuvo la grabación sin guardarla.';
                stopRecording();
            }
            closeMenu();
            return;
        }
        if (state.button?.isConnected) return;
        const button = markUi(document.createElement('button'));
        button.type = 'button';
        button.id = 'viena-ticket-macros-button';
        button.className = 'mx-3 v-btn v-btn--is-elevated v-btn--has-bg theme--dark v-size--default primary';
        button.setAttribute('aria-haspopup', 'dialog');
        button.setAttribute('aria-expanded', 'false');
        const content = markUi(document.createElement('span'));
        content.className = 'v-btn__content';
        content.textContent = 'Macros Tareas';
        button.appendChild(content);
        button.style.cssText = 'cursor:pointer;margin-left:8px;';
        button.addEventListener('click', () => {
            if (state.recording?.active || state.playing) return;
            if (state.menu.hidden) void openMenu();
            else closeMenu();
            button.setAttribute('aria-expanded', String(!state.menu.hidden));
        });
        const actions = panel.parentElement;
        root.setAttribute('data-viena-responsive-ticket', '1');
        actions.setAttribute('data-viena-macro-actions', '1');
        const anchor = markUi(document.createElement('div'));
        anchor.id = 'viena-ticket-macros-anchor';
        anchor.appendChild(button);
        panel.insertBefore(anchor, panel.querySelector('#viena-custom-template-manager-btn'));
        state.button = button;
    }

    function observeTicketUi() {
        if (MANUAL_MOICA) {
            window.addEventListener('resize', positionMenu, { passive: true });
            document.addEventListener('keydown', event => {
                if (event.key === 'Escape' && !state.recording?.active && !state.playing) closeMenu();
            });
            mountButton();
            return;
        }
        document.addEventListener('viena:ui-refresh', mountButton);
        let timer = 0;
        const observer = new MutationObserver(mutations => {
            const relevant = mutations.some(mutation => {
                const nodes = [...mutation.addedNodes, ...mutation.removedNodes];
                return nodes.some(node => {
                    const element = node.nodeType === 1 ? node : node.parentElement;
                    return element && (element.id === 'panel-plantillas-viena'
                        || (state.button && (element === state.button || element.contains?.(state.button))));
                });
            });
            if (!relevant) return;
            clearTimeout(timer);
            timer = setTimeout(mountButton, 40);
        });
        observer.observe(document.body, { childList: true, subtree: true });
        window.addEventListener('resize', positionMenu, { passive: true });
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape' && !state.recording?.active && !state.playing) closeMenu();
        });
        mountButton();
    }

    observeTicketUi();
})();
