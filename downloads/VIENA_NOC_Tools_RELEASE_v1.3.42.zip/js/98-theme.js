(() => {
  'use strict';
  try {
    const KEY='viena_ui_theme_v1';
    const CSS="html[data-viena-theme=\"dark\"]{color-scheme:dark;--ink:#dbe7f4;--text:#d7e3ef;--muted:#8fa5ba;--line:#293c50;--soft:#101a26;--soft2:#142233;--greenbg:#112c1c;--warnbg:#332811;--redbg:#33191b;--shadow:0 8px 26px rgba(0,0,0,.24)}\nhtml[data-viena-theme=\"dark\"] body,html[data-viena-theme=\"dark\"] .main,html[data-viena-theme=\"dark\"] .content{background:#0b131d!important;color:#d7e3ef!important}\nhtml[data-viena-theme=\"dark\"] .card,html[data-viena-theme=\"dark\"] .panel,html[data-viena-theme=\"dark\"] .operator-box,html[data-viena-theme=\"dark\"] .runtime-strip,html[data-viena-theme=\"dark\"] .personalization-row,html[data-viena-theme=\"dark\"] .update-box,html[data-viena-theme=\"dark\"] .install-folder,html[data-viena-theme=\"dark\"] .advanced-body,html[data-viena-theme=\"dark\"] .stats>div,html[data-viena-theme=\"dark\"] .update-summary>div,html[data-viena-theme=\"dark\"] .operator-grid>div,html[data-viena-theme=\"dark\"] .folder-name,html[data-viena-theme=\"dark\"] .editor-shell,html[data-viena-theme=\"dark\"] .editor-titlebar,html[data-viena-theme=\"dark\"] .button-editor-sidebar,html[data-viena-theme=\"dark\"] .button-editor-main,html[data-viena-theme=\"dark\"] .editor-section,html[data-viena-theme=\"dark\"] .editor-button-card,html[data-viena-theme=\"dark\"] .template-card,html[data-viena-theme=\"dark\"] .template-body,html[data-viena-theme=\"dark\"] .reason-row,html[data-viena-theme=\"dark\"] .icon-panel,html[data-viena-theme=\"dark\"] .viena-theme-panel{background:#121d2a!important;border-color:#293c50!important;color:#d7e3ef!important;box-shadow:none!important}\nhtml[data-viena-theme=\"dark\"] .platform-row,html[data-viena-theme=\"dark\"] .tool-row{background:linear-gradient(180deg,#142130,#101a26)!important;border-color:#293c50!important}\nhtml[data-viena-theme=\"dark\"] .section-title,html[data-viena-theme=\"dark\"] .platform-name,html[data-viena-theme=\"dark\"] .operator-value,html[data-viena-theme=\"dark\"] .user-auto-value,html[data-viena-theme=\"dark\"] .update-value,html[data-viena-theme=\"dark\"] .page-head h1,html[data-viena-theme=\"dark\"] .panel h2,html[data-viena-theme=\"dark\"] .tool-name,html[data-viena-theme=\"dark\"] .stats b,html[data-viena-theme=\"dark\"] .update-summary b,html[data-viena-theme=\"dark\"] .operator-grid b,html[data-viena-theme=\"dark\"] .editor-titlebar h2{color:#dbeaff!important}\nhtml[data-viena-theme=\"dark\"] .operator-label,html[data-viena-theme=\"dark\"] .hint,html[data-viena-theme=\"dark\"] .statusline,html[data-viena-theme=\"dark\"] .runtime-version,html[data-viena-theme=\"dark\"] .muted,html[data-viena-theme=\"dark\"] .panel-copy,html[data-viena-theme=\"dark\"] .page-head p,html[data-viena-theme=\"dark\"] .stats span,html[data-viena-theme=\"dark\"] .update-summary span,html[data-viena-theme=\"dark\"] .operator-grid span,html[data-viena-theme=\"dark\"] .operator-grid small,html[data-viena-theme=\"dark\"] .minor-status{color:#8fa5ba!important}\nhtml[data-viena-theme=\"dark\"] input,html[data-viena-theme=\"dark\"] textarea,html[data-viena-theme=\"dark\"] select{background:#0d1722!important;border-color:#34495f!important;color:#e5eef7!important}\nhtml[data-viena-theme=\"dark\"] input::placeholder,html[data-viena-theme=\"dark\"] textarea::placeholder{color:#71889e!important}\nhtml[data-viena-theme=\"dark\"] .btn.secondary,html[data-viena-theme=\"dark\"] .btn.ghost,html[data-viena-theme=\"dark\"] .chip,html[data-viena-theme=\"dark\"] .tool-action,html[data-viena-theme=\"dark\"] .section-action{background:#15283a!important;border-color:#34516e!important;color:#82bdff!important}\nhtml[data-viena-theme=\"dark\"] .info-line,html[data-viena-theme=\"dark\"] .update-status,html[data-viena-theme=\"dark\"] .update-notes,html[data-viena-theme=\"dark\"] .background-update-panel{background:#101b27!important;border-color:#293c50!important;color:#a9bfd2!important}\nhtml[data-viena-theme=\"dark\"] .success-line{background:#11291c!important;border-color:#24563a!important;color:#82d8a1!important}\nhtml[data-viena-theme=\"dark\"] .assign-warning{background:#332811!important;border-color:#5b4720!important;color:#e6c77f!important}\nhtml[data-viena-theme=\"dark\"] details.advanced>summary,html[data-viena-theme=\"dark\"] .release-history>summary{color:#8ec1f4!important}\nhtml[data-viena-theme=\"dark\"] .release-entry{background:#101a26!important;border-color:#2b3d50!important}\nhtml[data-viena-theme=\"dark\"] footer{background:#0c1621!important;border-color:#25384a!important;color:#7890a6!important}\n.viena-theme-row{margin-top:8px;width:100%;text-align:left}\n.viena-theme-switch{margin-left:auto;width:42px;height:24px;border-radius:999px;padding:2px;background:#c8d8e8;display:flex;align-items:center;flex:0 0 auto;transition:background .16s ease}\n.viena-theme-switch:after{content:\"\";width:20px;height:20px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.22);transform:translateX(0);transition:transform .16s ease}\nhtml[data-viena-theme=\"dark\"] .viena-theme-switch{background:#2d7bd0}\nhtml[data-viena-theme=\"dark\"] .viena-theme-switch:after{transform:translateX(18px)}\n.viena-theme-panel-body{display:flex;align-items:center;justify-content:space-between;gap:18px}\n.viena-theme-copy strong{display:block;font-size:14px}.viena-theme-copy span{display:block;margin-top:4px;font-size:11px;color:var(--muted)}\n.viena-theme-segmented{display:inline-grid;grid-template-columns:1fr 1fr;gap:3px;padding:3px;border:1px solid #cbd9e8;border-radius:9px;background:#eef4fa}\n.viena-theme-segmented button{min-width:76px;border:0;border-radius:6px;padding:7px 10px;background:transparent;color:#55718d;font-weight:780;cursor:pointer}\n.viena-theme-segmented button.active{background:#fff;color:#075fbe;box-shadow:0 1px 4px rgba(20,55,90,.13)}\nhtml[data-viena-theme=\"dark\"] .viena-theme-segmented{background:#0d1722;border-color:#33485d}\nhtml[data-viena-theme=\"dark\"] .viena-theme-segmented button{color:#91a8bc}\nhtml[data-viena-theme=\"dark\"] .viena-theme-segmented button.active{background:#19314a;color:#8fc6ff;box-shadow:none}\n@media(max-width:620px){.viena-theme-panel-body{align-items:flex-start;flex-direction:column}.viena-theme-segmented{width:100%}.viena-theme-segmented button{min-width:0}}";
    if(!document.getElementById('viena-theme-style')){const style=document.createElement('style');style.id='viena-theme-style';style.textContent=CSS;document.head.appendChild(style);}
    const root=document.documentElement;
    const normalize=value=>value==='dark'?'dark':'light';
    const current=()=>normalize(root.dataset.vienaTheme);
    const refreshControls=()=>{
      const theme=current();
      document.querySelectorAll('[data-viena-theme-label]').forEach(el=>{el.textContent=theme==='dark'?'Oscuro':'Claro';});
      document.querySelectorAll('[data-viena-theme-toggle]').forEach(el=>{el.setAttribute('aria-pressed',theme==='dark'?'true':'false');});
      document.querySelectorAll('[data-viena-theme-choice]').forEach(el=>{el.classList.toggle('active',el.dataset.vienaThemeChoice===theme);});
    };
    const apply=value=>{
      const theme=normalize(value);
      root.dataset.vienaTheme=theme;
      root.style.colorScheme=theme;
      try{localStorage.setItem(KEY,theme);}catch(_){}
      refreshControls();
    };
    const save=value=>{
      const theme=normalize(value);
      apply(theme);
      try{chrome.storage.local.set({[KEY]:theme},()=>{void chrome.runtime.lastError;});}catch(_){}
    };
    const mount=()=>{
      const full=new URLSearchParams(location.search).get('full')==='1';
      if(full){
        if(document.getElementById('vienaThemePanel')){refreshControls();return;}
        const view=document.querySelector('.view[data-view="personalization"]');
        if(!view)return;
        const iconPanel=view.querySelector('.icon-panel');
        const anchor=iconPanel||view.querySelector('.page-head');
        if(!anchor)return;
        const panel=document.createElement('article');
        panel.id='vienaThemePanel';
        panel.className='panel viena-theme-panel';
        panel.innerHTML='<div class="viena-theme-panel-body"><div class="viena-theme-copy"><strong>Tema de la extensión</strong><span>Se comparte con el popup y queda guardado en esta instalación.</span></div><div class="viena-theme-segmented" role="group" aria-label="Tema de la extensión"><button type="button" data-viena-theme-choice="light">Claro</button><button type="button" data-viena-theme-choice="dark">Oscuro</button></div></div>';
        panel.querySelectorAll('[data-viena-theme-choice]').forEach(btn=>btn.addEventListener('click',()=>save(btn.dataset.vienaThemeChoice)));
        anchor.insertAdjacentElement(iconPanel?'beforebegin':'afterend',panel);
      }else{
        if(document.getElementById('vienaThemeTogglePopup')){refreshControls();return;}
        const editor=document.getElementById('openButtonEditor');
        if(!editor)return;
        const button=document.createElement('button');
        button.id='vienaThemeTogglePopup';
        button.type='button';
        button.className='personalization-row viena-theme-row';
        button.dataset.vienaThemeToggle='1';
        button.innerHTML='<span class="personalization-icon" aria-hidden="true">◐</span><span class="personalization-copy"><b>Tema de la extensión</b><span>Actual: <strong data-viena-theme-label>Claro</strong></span></span><span class="viena-theme-switch" aria-hidden="true"></span>';
        button.addEventListener('click',()=>save(current()==='dark'?'light':'dark'));
        editor.insertAdjacentElement('afterend',button);
      }
      refreshControls();
    };
    let cached='light';
    try{cached=normalize(localStorage.getItem(KEY));}catch(_){}
    apply(cached);
    mount();
    try{
      chrome.storage.local.get([KEY],data=>{void chrome.runtime.lastError;if(data&&data[KEY])apply(data[KEY]);mount();});
      chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[KEY])apply(changes[KEY].newValue);});
    }catch(_){}
  } catch (error) {
    console.warn('VIENA theme disabled:',error);
  }
})();