(() => {
  'use strict';
  const data={
  "version": "1.3.42",
  "title": "Más control para tu trabajo",
  "notes": [
    "Personalizá la vista del ticket: elegí qué campos y botones mostrar y ordenalos a tu gusto.",
    "Vista previa en el mismo ticket: revisá el resultado antes de aplicar o cancelar los cambios.",
    "Distribución adaptable al ancho de la pantalla, también en tickets completados.",
    "Popup más ancho para consultar las herramientas con mayor comodidad.",
    "Incluye las macros VIENA/MOICA, sus bibliotecas y el respaldo de macros de la 1.3.41.",
    "Incluye el editor, traslado y respaldo de botones personales y plantillas.",
    "Incluye la edición de Asignaciones y las mejoras de reemplazo de macros MOICA.",
    "Incluye la interfaz renovada y el modo claro y oscuro de la 1.3.41."
  ],
  "previousNotes": [
    "Nueva interfaz del panel y los editores, con modo claro y oscuro en Personalización.",
    "Macros en VIENA y tareas manuales de MOICA: grabar, reproducir, detener y corregir pasos.",
    "Bibliotecas con búsqueda, carpetas, renombrado y orden por arrastre; elegí la carpeta antes de grabar.",
    "Respaldo e importación de macros VIENA/MOICA y de botones personales con sus plantillas.",
    "Plantillas editables: mensajes y motivos propios, traslado entre botones y orden por arrastre.",
    "Asignaciones: crear, editar, sumar tipificaciones, quitar códigos y eliminar plantillas.",
    "MOICA reemplaza los problemas y el mensaje anteriores al ejecutar otra macro; revisá el resultado.",
    "Anuncio de novedades deslizable al entrar a VIENA, una vez por actualización."
  ],
  "newSlideCount": 4,
  "slides": [
    {
      "title": "Elegí qué ver en cada ticket",
      "text": "Abrí ⚙ Personalizar vista y tildá los campos y botones que necesitás. Arrastrá los elementos o usá las flechas para elegir el orden. Tu vista se guarda para tu usuario al aplicar los cambios.",
      "image": "personalizar.png",
      "kind": "detail",
      "caption": "Personalizar vista · Botones y campos del ticket",
      "tip": "Ocultar un campo sólo cambia la vista: los datos del ticket se conservan."
    },
    {
      "title": "Tus botones, en el orden que te sirve",
      "text": "Mostrá, ocultá y ordená los botones superiores, incluidos los de VIENA y tus botones personales. Arrastrá desde el asa o usá las flechas.",
      "image": "personalizar.png",
      "kind": "detail",
      "caption": "Botones superiores · Visibilidad y orden",
      "tip": "Mostrar todos recupera los botones ocultos y conserva el orden que elegiste."
    },
    {
      "title": "Mirá el resultado antes de guardarlo",
      "text": "Los cambios se muestran en el mismo ticket. Usá Ver resultado para ocultar el desplegable y revisar la distribución completa. Aplicar guarda; Cancelar vuelve a tu vista anterior.",
      "image": "resultado.png",
      "kind": "result",
      "caption": "Vista previa sobre el ticket · Sin abrir otra ventana",
      "tip": "Podés seguir editando: nada se guarda hasta que toques Aplicar."
    },
    {
      "title": "Una distribución que acompaña tu pantalla",
      "text": "La ficha se adapta al ancho de la ventana, también con pantalla dividida. Abrir Personalizar vista mantiene la distribución. En tickets completados, los accesos a plataformas quedan antes del mensaje.",
      "image": "resultado.png",
      "kind": "result",
      "caption": "Distribución adaptable · Imagen ilustrativa con tarea iniciada",
      "tip": "Restaurar vista predeterminada recupera el orden y la visibilidad originales; revisá y aplicá."
    },
    {
      "title": "Grabá tareas en VIENA",
      "text": "En un ticket con tarea iniciada, abrí Macros Tareas. Elegí Grabar nueva tarea, realizá el recorrido, detené la grabación y guardala. Reproducila para repetir esos pasos en otro ticket; revisá siempre el resultado.",
      "image": "macros-grabando.png",
      "kind": "result",
      "caption": "Macros VIENA · Grabación en curso",
      "tip": "Detené la grabación y guardá la macro cuando termines el recorrido.",
      "group": "1.3.41"
    },
    {
      "title": "Macros para tareas manuales en MOICA",
      "text": "En Nuevo Ticket, abrí MACROS TAREA MANUAL. Grabá el recorrido y guardalo para reutilizarlo. Podés detener la reproducción y revisar el formulario antes de enviarlo.",
      "image": "macros-moica.png",
      "kind": "result",
      "caption": "Macros de tareas manuales · MOICA",
      "tip": "Revisá el formulario antes de enviar el ticket.",
      "group": "1.3.41"
    },
    {
      "title": "Organizá tus macros",
      "text": "Buscá por nombre, creá carpetas y arrastrá para ordenar o mover macros. En Más opciones podés renombrarlas y eliminarlas. Antes de grabar también podés elegir una carpeta existente o crear una nueva.",
      "image": "macros-biblioteca.png",
      "kind": "library",
      "caption": "Biblioteca · Buscar, reproducir y organizar carpetas",
      "tip": "Las carpetas ayudan a encontrar y ordenar tus recorridos.",
      "group": "1.3.41"
    },
    {
      "title": "Corregí una macro y continuá",
      "text": "Si cambió una opción, la macro se pausa. Usá Actualizar paso y elegí la opción correcta del sistema para guardar la corrección y continuar. Detener interrumpe el recorrido, pero no deshace los pasos ya realizados.",
      "image": "macros-corregir.png",
      "kind": "result",
      "caption": "Actualizar paso · Ejemplo de una opción que cambió",
      "tip": "Detener no deshace los pasos ya realizados.",
      "group": "1.3.41"
    },
    {
      "title": "Llevá tus macros a otra PC",
      "text": "Abrí Personalización → Respaldo de macros y descargá ambas bibliotecas. En la otra PC, elegí el archivo, revisá el resumen y restauralas. Las macros existentes se conservan; el mismo respaldo no se duplica.",
      "tip": "Revisá el resumen del respaldo antes de restaurar.",
      "group": "1.3.41"
    },
    {
      "title": "Personalizá tus botones y plantillas",
      "text": "Desde el Editor de botones creá tus propios botones y agregá plantillas. Editá nombres, mensajes y motivos según tu trabajo. Guardar cambios confirma la edición; Descartar cambios conserva lo anterior.",
      "image": "plantillas-editor.png",
      "kind": "editor",
      "caption": "Editor de botones y plantillas · Captura de ejemplo en DEV",
      "tip": "Guardar cambios confirma; Descartar cambios conserva lo anterior.",
      "group": "1.3.41"
    },
    {
      "title": "Mové y ordená tus plantillas",
      "text": "Usá Mover a otro botón para trasladar una plantilla a uno existente o crear un destino nuevo. En el editor, arrastrá para ordenar y guardá los cambios. En el menú desplegable, el orden se guarda al soltar.",
      "image": "plantillas-editor.png",
      "kind": "editor",
      "caption": "Mover a otro botón · Revisar y guardar cambios",
      "tip": "En el editor confirmás al guardar; en el menú, el orden se guarda al soltar.",
      "group": "1.3.41"
    },
    {
      "title": "Respaldá tus botones personales",
      "text": "En el Editor de botones, guardá tus cambios y elegí Exportar botones. Para importarlos en otra PC, seleccioná el respaldo, revisá los botones y plantillas que se agregarán y confirmá la importación.",
      "image": "botones-respaldo.png",
      "kind": "editor",
      "caption": "Respaldo de botones · Captura de ejemplo en DEV",
      "tip": "Se conservan los botones existentes; revisá lo que se agregará.",
      "group": "1.3.41"
    },
    {
      "title": "Editá tus Asignaciones",
      "text": "Seleccioná tipificaciones en VIENA y creá una plantilla desde Asignaciones. El lápiz permite editarla: Agregar selección actual suma códigos sin duplicar, × los quita y Guardar confirma. También podés eliminar una plantilla.",
      "tip": "Agregar selección actual suma códigos sin duplicar.",
      "group": "1.3.41"
    },
    {
      "title": "Macros MOICA sin acumulaciones",
      "text": "Al ejecutar otra macro, se reemplazan los valores grabados. El mensaje se limpia y los problemas anteriores se retiran cuando el recorrido usa esos campos. Si no puede retirarlos, la macro se detiene. Revisá siempre el formulario.",
      "tip": "La macro se detiene si no puede retirar los problemas anteriores.",
      "group": "1.3.41"
    },
    {
      "title": "Nueva interfaz",
      "text": "El popup, la vista completa y los editores tienen una presentación renovada, controles más claros y una distribución adaptable al tamaño de la ventana. Encontrá tus herramientas y personalizaciones desde el panel.",
      "image": "botones-respaldo.png",
      "kind": "result",
      "caption": "Nueva interfaz · Personalización y editor en DEV",
      "tip": "Tus herramientas y personalizaciones siguen en el panel.",
      "group": "1.3.41"
    },
    {
      "title": "Modo oscuro",
      "text": "Abrí Personalización y elegí Claro u Oscuro en Tema visual. La elección se guarda en esta instalación y se comparte entre el popup y la vista completa de la extensión.",
      "image": "popup-oscuro.png",
      "kind": "result",
      "caption": "Modo oscuro · Popup de ejemplo en DEV",
      "tip": "El tema elegido se comparte entre el popup y la vista completa.",
      "group": "1.3.41"
    }
  ]
};
  data.notes=Object.freeze(data.notes);data.previousNotes=Object.freeze(data.previousNotes);data.slides=Object.freeze(data.slides.map(s=>Object.freeze(s)));
  globalThis.VienaReleaseNotes=Object.freeze(data);
})();
