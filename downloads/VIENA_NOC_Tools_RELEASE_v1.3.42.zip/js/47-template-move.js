(function(root){
    'use strict';
    const clone=value=>JSON.parse(JSON.stringify(value));
    const norm=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
    function comparable(state){
        return JSON.stringify({user:state?.user,buttons:[state?.sistema,...(state?.personales||[])].map(g=>({
            id:g?.id,nombre:g?.nombre,plantillas:(g?.plantillas||[]).map(p=>({
                id:p.id,nombre:p.nombre,mensaje:p.mensaje,motivo:p.motivo||'',motivoContiene:p.motivoContiene||[]
            }))
        }))});
    }
    function createSession(saved){
        let baseline=clone(saved),state=clone(saved);
        const buttons=()=>[state.sistema,...state.personales];
        const getButton=id=>buttons().find(g=>g.id===id);
        function setButton(value){
            const item=clone(value);
            item.id=item.id||'g_'+root.crypto.randomUUID();
            item.plantillas=(item.plantillas||[]).map(p=>{
                const aliases=Array.isArray(p.motivoContiene)?p.motivoContiene:[];
                const reason=aliases.length&&norm(p.motivo)===norm(aliases.join(' | '))?'':p.motivo;
                return {...p,id:p.id||'p_'+root.crypto.randomUUID(),motivo:reason||''};
            });
            if(item.id===state.sistema.id){item.system=true;state.sistema=item;}
            else {item.system=false;const index=state.personales.findIndex(g=>g.id===item.id);if(index<0)state.personales.push(item);else state.personales[index]=item;}
            return item;
        }
        function move(sourceId,templateId,targetId,newName){
            const source=getButton(sourceId),template=source?.plantillas.find(p=>p.id===templateId);
            if(!template)throw Error('No se encontró la plantilla en el borrador.');
            if(targetId===sourceId)throw Error('Elegí otro botón como destino.');
            let target=getButton(targetId);
            if(targetId==='__new__'){
                const nombre=String(newName||'').replace(/\s+/g,' ').trim();
                if(!nombre||nombre.length>28)throw Error('Ingresá un nombre de hasta 28 caracteres para el nuevo botón.');
                if(buttons().some(g=>norm(g.nombre)===norm(nombre)))throw Error('Ya existe un botón con ese nombre.');
                target={id:'g_'+root.crypto.randomUUID(),nombre,system:false,plantillas:[],createdAt:Date.now()};
            }
            if(!target)throw Error('Elegí un botón de destino.');
            if(target.plantillas.some(p=>p.id===template.id||norm(p.nombre)===norm(template.nombre)))throw Error('El destino ya tiene una plantilla con ese nombre.');
            if(targetId==='__new__')state.personales.push(target);
            source.plantillas=source.plantillas.filter(p=>p.id!==templateId);
            target.plantillas.push({...template,system:!!target.system});
            return target.id;
        }
        return {get state(){return state;},get expectedState(){return clone(baseline);},buttons,getButton,setButton,move,
            dirty:()=>comparable(state)!==comparable(baseline),
            discard:()=>{state=clone(baseline);},
            accept:savedState=>{baseline=clone(savedState);state=clone(savedState);},
            removeButton:id=>{if(id===state.sistema.id)throw Error('El botón del sistema está protegido.');state.personales=state.personales.filter(g=>g.id!==id);}
        };
    }
    function confirmDiscard(host){
        return new Promise(resolve=>{
            const overlay=document.createElement('div');overlay.className='viena-editor-unsaved-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Cambios sin guardar');
            Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'2147483647',background:'rgba(15,23,42,.58)',display:'grid',placeItems:'center',padding:'16px'});
            const card=document.createElement('div');Object.assign(card.style,{width:'min(440px,100%)',boxSizing:'border-box',padding:'22px',borderRadius:'12px',background:'#fff',color:'#243b57',font:'16px/1.5 Arial'});
            const title=document.createElement('strong');title.textContent='Cambios sin guardar';
            const text=document.createElement('p');text.textContent='Tenés cambios sin guardar. Si cerrás ahora, se descartarán los cambios y las plantillas quedarán en sus botones originales.';
            const actions=document.createElement('div');Object.assign(actions.style,{display:'flex',gap:'10px',flexWrap:'wrap'});
            const stay=document.createElement('button');stay.type='button';stay.textContent='Seguir editando';
            const discard=document.createElement('button');discard.type='button';discard.textContent='Descartar y cerrar';
            for(const button of [stay,discard])Object.assign(button.style,{padding:'10px',border:'1px solid #94a3b8',borderRadius:'7px',font:'inherit',cursor:'pointer',background:'#fff',color:'#174f80'});
            const previous=document.activeElement;
            const done=value=>{overlay.remove();previous?.focus?.();resolve(value);};
            stay.addEventListener('click',()=>done(false));discard.addEventListener('click',()=>done(true));
            overlay.addEventListener('keydown',event=>{if(event.key==='Escape'){event.stopPropagation();done(false);}if(event.key==='Tab'){event.preventDefault();(document.activeElement===stay?discard:stay).focus();}});
            for(const type of ['pointerdown','mousedown','mouseup','click','keydown'])overlay.addEventListener(type,event=>event.stopPropagation());
            actions.append(stay,discard);card.append(title,text,actions);overlay.append(card);host.append(overlay);stay.focus();
        });
    }
    function mount(host,options){
        host.querySelector('.viena-template-move-form')?.remove();
        const form=document.createElement('div');form.className='viena-template-move-form';
        Object.assign(form.style,{display:'grid',gap:'10px',padding:'12px',marginTop:'10px',border:'1px solid #94a3b8',borderRadius:'8px',minWidth:'0'});
        const title=document.createElement('strong');title.textContent='Mover a otro botón';
        const help=document.createElement('div');help.textContent='La plantilla se moverá en el editor. Tocá Guardar cambios para confirmar; si descartás, quedará en el botón original.';
        const label=document.createElement('label');label.textContent='Botón de destino';label.style.display='grid';label.style.gap='6px';
        const select=document.createElement('select');select.setAttribute('aria-label','Botón de destino');
        for(const item of options.buttons.filter(g=>g.id!==options.sourceId)){
            const option=document.createElement('option');option.value=item.id;option.textContent=item.nombre;select.append(option);
        }
        const fresh=document.createElement('option');fresh.value='__new__';fresh.textContent='＋ Crear nuevo botón';select.append(fresh);label.append(select);
        const nameLabel=document.createElement('label');nameLabel.textContent='Nombre del nuevo botón';nameLabel.style.display='grid';nameLabel.style.gap='6px';
        const name=document.createElement('input');name.type='text';name.maxLength=28;name.setAttribute('aria-label','Nombre del nuevo botón');nameLabel.append(name);
        for(const control of [select,name])Object.assign(control.style,{width:'100%',maxWidth:'100%',minWidth:'0',boxSizing:'border-box',padding:'10px',border:'1px solid #94a3b8',borderRadius:'6px',font:'inherit',color:'inherit',background:'inherit',height:'auto',minHeight:'42px'});
        const update=()=>{nameLabel.hidden=select.value!=='__new__';nameLabel.style.display=nameLabel.hidden?'none':'grid';};select.addEventListener('change',update);update();
        const status=document.createElement('div');status.setAttribute('role','status');status.style.overflowWrap='anywhere';
        const actions=document.createElement('div');Object.assign(actions.style,{display:'flex',flexWrap:'wrap',gap:'8px'});
        const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancelar';cancel.className='btn secondary';
        const move=document.createElement('button');move.type='button';move.textContent='Mover plantilla';move.className='btn primary';
        for(const button of [cancel,move])Object.assign(button.style,{padding:'9px 12px',borderRadius:'7px',border:'1px solid #94a3b8',cursor:'pointer',font:'inherit'});
        Object.assign(move.style,{background:'#1268c4',color:'#fff'});
        cancel.addEventListener('click',()=>form.remove());
        move.addEventListener('click',async()=>{
            if(move.disabled)return;
            move.disabled=true;cancel.disabled=true;select.disabled=true;name.disabled=true;status.textContent='Moviendo plantilla…';
            try{await options.onMove({targetId:select.value,newName:name.value});form.remove();}
            catch(error){status.textContent=String(error?.message||error||'No se pudo mover la plantilla.');}
            finally{move.disabled=false;cancel.disabled=false;select.disabled=false;name.disabled=false;}
        });
        actions.append(cancel,move);form.append(title,help,label,nameLabel,status,actions);host.append(form);select.focus();return form;
    }
    function reorder(items,ids){
        const byId=new Map(items.map(p=>[String(p.id),p]));
        if(ids.length!==items.length||new Set(ids).size!==items.length||ids.some(id=>!byId.has(id)))throw Error('El orden de las plantillas cambió. Volvé a intentarlo.');
        return ids.map(id=>byId.get(id));
    }
    function bindReorder(host,{selector,onReorder,onError=()=>{},canStart=()=>true}){
        let source=null,busy=false,suppressUntil=0;
        const rows=()=>Array.from(host.querySelectorAll(selector));
        const rowFor=event=>event.target.closest?.(selector);
        const clear=()=>{rows().forEach(row=>{row.classList.remove('viena-template-dragging');row.style.removeProperty('outline');});source=null;};
        host.addEventListener('dragstart',event=>{
            const row=rowFor(event);
            if(!row||busy||!canStart()||event.target.closest('input,textarea,select')){event.preventDefault();return;}
            source=row;row.classList.add('viena-template-dragging');
            event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',row.dataset.templateId);
            suppressUntil=Date.now()+500;
        });
        host.addEventListener('dragover',event=>{
            const row=rowFor(event);if(!source||!row||row===source)return;
            event.preventDefault();event.dataTransfer.dropEffect='move';
            rows().forEach(r=>r.style.removeProperty('outline'));row.style.outline='2px solid #1268c4';
        });
        host.addEventListener('drop',async event=>{
            const row=rowFor(event);if(!source||!row||busy)return;
            event.preventDefault();event.stopPropagation();
            const previous=rows(),moved=source,offsets=[];
            for(let node=host;node;node=node.parentElement)if(node.scrollHeight>node.clientHeight)offsets.push([node,node.scrollTop]);
            clear();suppressUntil=Date.now()+500;
            if(row===moved)return;
            const rect=row.getBoundingClientRect();host.insertBefore(moved,event.clientY<rect.top+rect.height/2?row:row.nextSibling);
            const ids=rows().map(r=>r.dataset.templateId);busy=true;
            try{await onReorder(ids);}
            catch(error){previous.forEach(r=>host.append(r));onError(error);}
            finally{busy=false;offsets.forEach(([node,top])=>{node.scrollTop=top;});}
        });
        host.addEventListener('dragend',()=>{suppressUntil=Date.now()+500;clear();});
        host.addEventListener('click',event=>{if(busy||source||Date.now()<suppressUntil){event.preventDefault();event.stopImmediatePropagation();}},true);
        host.addEventListener('keydown',event=>{if(busy&&(event.key==='Enter'||event.key===' ')){event.preventDefault();event.stopImmediatePropagation();}},true);
        return {get active(){return !!source||busy;}};
    }
    const api={mount,createSession,comparable,confirmDiscard,reorder,bindReorder};if(typeof module==='object'&&module.exports)module.exports=api;else root.VienaTemplateMove=api;
})(globalThis);
