(function() {
    'use strict';
    const api = globalThis.VienaMacroTransfer;
    const get = id => document.getElementById(id);
    let selected = null;
    let busy = false;
    const describe = libraries => `VIENA: ${libraries[api.keys[0]].macros.length} macros · ${(libraries[api.keys[0]].folders || []).length} carpetas\nMOICA: ${libraries[api.keys[1]].macros.length} macros · ${(libraries[api.keys[1]].folders || []).length} carpetas`;
    function status(message,error=false) { get('status').textContent=message; get('status').dataset.error=String(error); }
    function controls() {
        get('export').disabled=busy;
        get('backup').disabled=busy;
        get('restore').disabled=busy || !selected;
        get('cancel').disabled=busy || !selected;
    }
    async function operation(fn) {
        if (busy) return;
        busy=true; controls();
        try { await fn(); } catch(error) { status(error.message || 'No se pudo completar la operación. Volvé a intentar.',true); }
        finally { busy=false; controls(); }
    }
    async function refresh() {
        const backup = api.exportBackup(await chrome.storage.local.get(api.keys));
        get('counts').textContent=describe(backup.libraries);
    }
    function clear() { selected=null; get('backup').value=''; get('preview').textContent=''; controls(); }
    get('export').addEventListener('click',()=>void operation(async()=>{
        const backup=api.exportBackup(await chrome.storage.local.get(api.keys));
        const url=URL.createObjectURL(new Blob([JSON.stringify(backup,null,2)],{type:'application/json'}));
        const link=document.createElement('a');
        link.href=url; link.download=`VIENA-MOICA-macros-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;
        document.body.appendChild(link); link.click(); link.remove();
        setTimeout(()=>URL.revokeObjectURL(url),60000);
        get('counts').textContent=describe(backup.libraries);
        status('Respaldo solicitado. Comprobá que el archivo esté en Descargas antes de trasladarlo.\n'+describe(backup.libraries));
    }));
    get('backup').addEventListener('change',()=>void operation(async()=>{
        selected=null; get('preview').textContent='';
        const file=get('backup').files[0]; if(!file) return;
        if(file.size>32*1024*1024) throw new Error('El archivo es demasiado grande para un respaldo de macros.');
        let backup;
        try { backup=JSON.parse(await file.text()); }
        catch (_) { throw new Error('No se pudo leer el respaldo. Seleccioná el archivo JSON descargado desde Respaldo de macros.'); }
        const current=await chrome.storage.local.get(api.keys);
        const merged=api.mergeBackup(current,backup);
        selected={backup,before:api.stable(current)};
        get('preview').textContent=(backup.operation==='update_moica_priorities'
            ? `Se actualizará la prioridad de ${backup.priorityUpdates.length} macros existentes de MOICA, sin agregar copias.`
            : 'El archivo contiene:\n'+describe(backup.libraries))+'\nDespués de restaurar:\n'+describe(merged);
        status('Revisá las cantidades y pulsá Restaurar ambas bibliotecas. Todavía no se guardó ningún cambio.');
    }));
    get('cancel').addEventListener('click',()=>{clear();status('Restauración cancelada. Tus macros se conservan.');});
    get('restore').addEventListener('click',()=>void operation(async()=>{
        if(!selected) return;
        const current=await chrome.storage.local.get(api.keys);
        if(api.stable(current)!==selected.before) { clear(); throw new Error('Las macros cambiaron desde la vista previa. Seleccioná nuevamente el respaldo para revisar las cantidades.'); }
        const merged=api.mergeBackup(current,selected.backup);
        // One storage operation only after both libraries have passed validation.
        await chrome.storage.local.set(merged);
        const saved=await chrome.storage.local.get(api.keys);
        if(api.stable(saved)!==api.stable(merged)) { clear(); throw new Error('No se pudo verificar la restauración completa. Volvé a revisar las bibliotecas antes de continuar.'); }
        clear(); await refresh();
        status('Ambas bibliotecas restauradas y verificadas.\n'+describe(saved)+'\nCerrá y volvé a abrir los menús de macros de VIENA y MOICA.');
    }));
    void operation(refresh);
})();
