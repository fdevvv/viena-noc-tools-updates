(function(root) {
    'use strict';
    const keys = ['viena_ticket_macros_v1', 'moica_manual_macros_v1'];
    const clone = value => JSON.parse(JSON.stringify(value));
    function stable(value) {
        if (Array.isArray(value)) return '[' + value.map(stable).join(',') + ']';
        if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + stable(value[key])).join(',') + '}';
        return JSON.stringify(value);
    }
    function validate(library) {
        if (!library || library.schema !== 1 || !Array.isArray(library.macros)
            || library.macros.some(m => !m || typeof m.id !== 'string' || !m.id || typeof m.name !== 'string' || !Array.isArray(m.actions) || m.actions.length > 1000)
            || new Set(library.macros.map(m => m.id)).size !== library.macros.length
            || (library.folders !== undefined && (!Array.isArray(library.folders) || library.folders.some(f => !f || typeof f.id !== 'string' || !f.id || typeof f.name !== 'string')
                || new Set(library.folders.map(f => f.id)).size !== library.folders.length))) {
            throw new Error('El respaldo o la biblioteca tiene un formato no compatible. No se guardó ningún cambio.');
        }
        if (library.macros.length > 50 || (library.folders || []).length > 50) throw new Error('La biblioteca resultante supera el límite de 50 macros o carpetas. No se guardó ningún cambio.');
        if (new TextEncoder().encode(JSON.stringify(library)).length > 4 * 1024 * 1024) throw new Error('La biblioteca supera el límite de 4 MB. No se guardó ningún cambio.');
        return library;
    }
    function exportBackup(storage) {
        const libraries = {};
        for (const key of keys) libraries[key] = clone(validate(storage[key] === undefined ? {schema:1, macros:[], folders:[]} : storage[key]));
        return {format:'VIENA_NOC_MACROS', schema:1, exportedAt:new Date().toISOString(), libraries};
    }
    function sameItem(a,b) {
        const {id:ignoredA,...restA} = a;
        const {id:ignoredB,...restB} = b;
        return stable(restA) === stable(restB);
    }
    function addItem(items,item) {
        const existing = items.find(candidate => candidate.id === item.id);
        if (!existing) { items.push(clone(item)); return item.id; }
        if (sameItem(existing,item)) return existing.id;
        for (let n=1;;n++) {
            const id = item.id + '-import-' + n;
            const candidate = items.find(entry => entry.id === id);
            if (candidate && sameItem(candidate,item)) return id;
            if (!candidate) { items.push({...clone(item),id}); return id; }
        }
    }
    function mergeBackup(storage,backup) {
        if (backup?.format === 'VIENA_NOC_MACROS' && backup.schema === 1 && backup.operation === 'update_moica_priorities') {
            const updates = backup.priorityUpdates;
            if (!Array.isArray(updates) || !updates.length || updates.length > 50
                || new Set(updates.map(item => item?.id)).size !== updates.length
                || updates.some(item => !item || typeof item.id !== 'string' || typeof item.name !== 'string' || !['Mayor','Menor','Critica'].includes(item.value))) {
                throw new Error('El archivo de prioridades no es válido. No se guardó ningún cambio.');
            }
            const result = Object.fromEntries(keys.map(key => [key, clone(validate(storage[key] || {schema:1,macros:[],folders:[]}))]));
            const library = result[keys[1]];
            for (const update of updates) {
                const macro = library.macros.find(item => item.id === update.id && item.name === update.name);
                if (!macro) throw new Error(`No se encontró la macro ${update.name} del respaldo. No se guardó ningún cambio.`);
                const last = macro.actions[macro.actions.length - 1];
                if (last?.type === 'setValue' && last.target?.id === 'TKT-PRIORIDAD-ADD') {
                    Object.assign(last, {value:update.value,valueTemplate:update.value,nativeOption:{text:update.value,value:update.value},eventTypes:['input','change']});
                } else macro.actions.push({type:'setValue',targetKey:'id:TKT-PRIORIDAD-ADD',
                    target:{id:'TKT-PRIORIDAD-ADD',selector:'#TKT-PRIORIDAD-ADD',tag:'select',classes:['form-control'],ancestors:[]},
                    value:update.value,valueTemplate:update.value,nativeOption:{text:update.value,value:update.value},eventType:'change',eventTypes:['input','change'],delayMs:0});
            }
            validate(library);
            return result;
        }
        if (!backup || backup.format !== 'VIENA_NOC_MACROS' || backup.schema !== 1 || !backup.libraries
            || keys.some(key => !Object.prototype.hasOwnProperty.call(backup.libraries,key))) throw new Error('Seleccioná un respaldo completo de macros VIENA y MOICA. No se guardó ningún cambio.');
        const result = {};
        for (const key of keys) {
            const incoming = validate(backup.libraries[key]);
            const current = storage[key];
            if (current === undefined) { result[key] = clone(incoming); continue; }
            validate(current);
            const merged = clone(current);
            const folderMap = new Map();
            if ((incoming.folders || []).length) {
                merged.folders = merged.folders || [];
                for (const folder of incoming.folders) folderMap.set(folder.id,addItem(merged.folders,folder));
            }
            for (const macro of incoming.macros) {
                const item = clone(macro);
                if (folderMap.has(item.folderId)) item.folderId = folderMap.get(item.folderId);
                addItem(merged.macros,item);
            }
            result[key] = validate(merged);
        }
        return result;
    }
    const api = {keys, exportBackup, mergeBackup, stable};
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.VienaMacroTransfer = api;
})(globalThis);
