(function(root){
    'use strict';
    const clone=value=>JSON.parse(JSON.stringify(value));
    const stable=value=>Array.isArray(value)?'['+value.map(stable).join(',')+']':value&&typeof value==='object'?'{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+stable(value[key])).join(',')+'}':JSON.stringify(value);
    const norm=value=>String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
    function validate(backup){
        if(!backup||backup.format!=='VIENA_NOC_BUTTONS'||backup.schema!==1||!Array.isArray(backup.buttons)||!backup.contexts||typeof backup.contexts!=='object'||Array.isArray(backup.contexts))throw Error('Seleccioná un respaldo de botones exportado desde el editor.');
        const groups=new Set(),templates=new Set();
        for(const group of backup.buttons){
            if(!group||typeof group.id!=='string'||!group.id||['__proto__','constructor','prototype'].includes(group.id)||groups.has(group.id)||typeof group.nombre!=='string'||!group.nombre.trim()||group.nombre.length>28||!Array.isArray(group.plantillas))throw Error('Hay un botón inválido o repetido en el respaldo. No se importó nada.');
            groups.add(group.id);const names=new Set();
            for(const p of group.plantillas){
                if(!p||typeof p.id!=='string'||!p.id||['__proto__','constructor','prototype'].includes(p.id)||templates.has(p.id)||typeof p.nombre!=='string'||!p.nombre.trim()||p.nombre.length>32||names.has(norm(p.nombre))||typeof p.mensaje!=='string'||!p.mensaje.trim()||typeof p.motivo!=='string')throw Error('Hay una plantilla inválida o repetida en el respaldo. No se importó nada.');
                templates.add(p.id);names.add(norm(p.nombre));
            }
        }
        for(const [id,context] of Object.entries(backup.contexts)){
            if(!templates.has(id)||!context||typeof context!=='object'||Array.isArray(context)||!Array.isArray(context.known)||context.known.some(x=>typeof x!=='string')||!context.byContext||typeof context.byContext!=='object'||Array.isArray(context.byContext)||Object.values(context.byContext).some(x=>!x||typeof x.motivo!=='string'||(x.tipificacion!==undefined&&typeof x.tipificacion!=='string')))throw Error('Los motivos del respaldo no son compatibles. No se importó nada.');
        }
        if(new TextEncoder().encode(JSON.stringify(backup)).length>4*1024*1024)throw Error('El respaldo de botones supera 4 MB.');
        return backup;
    }
    const content=group=>stable(group.plantillas.map(p=>({nombre:p.nombre,mensaje:p.mensaje,motivo:p.motivo,estado:p.estado||'COMPLETADA'})));
    function merge(current,backup,systemName,reservedTemplateIds=[]){
        validate(backup);
        const buttons=clone(current),contexts={};
        const usedTemplates=new Set([...reservedTemplateIds,...buttons.flatMap(g=>g.plantillas.map(p=>p.id))]);
        for(const source of backup.buttons){
            let id=source.id,n=0,found;
            while((found=buttons.find(g=>g.id===id))){
                if(content(found)===content(source)&&(n>0||norm(found.nombre)===norm(source.nombre)))break;
                id=source.id+'-import-'+(++n);
            }
            if(found)continue;
            const group=clone(source);group.id=id;
            const names=new Set([norm(systemName),...buttons.map(g=>norm(g.nombre))]);
            let suffix=1;
            while(names.has(norm(group.nombre))){const tail=' ('+(++suffix)+')';group.nombre=source.nombre.slice(0,28-tail.length)+tail;}
            for(const p of group.plantillas){
                const old=p.id;let count=0;
                while(usedTemplates.has(p.id))p.id=old+'-import-'+(++count);
                usedTemplates.add(p.id);
                if(backup.contexts[old])contexts[p.id]=clone(backup.contexts[old]);
            }
            buttons.push(group);
        }
        const imported=buttons.slice(current.length).map(group=>({nombre:group.nombre,templates:group.plantillas.length}));
        return {buttons,contexts,added:buttons.length-current.length,addedTemplates:imported.reduce((sum,group)=>sum+group.templates,0),imported};
    }
    function mount(host,options){
        if(!document.getElementById('viena-button-backup-style')){
            const style=document.createElement('style');style.id='viena-button-backup-style';
            style.textContent=`
                .viena-button-backup{box-sizing:border-box;display:grid;gap:14px;min-width:0;padding:16px;margin:0 0 18px;border:1px solid #cbd5e1;border-radius:10px;background:#f4f7fb;color:#193d66;line-height:1.5}
                .viena-button-backup p{margin:0;color:inherit;overflow-wrap:anywhere}
                .viena-button-backup label{display:grid;gap:8px;color:inherit;font-weight:600;min-width:0}
                .viena-button-backup input[type=file]{box-sizing:border-box;display:block;width:100%;height:auto;min-height:52px;min-width:0;max-width:100%;padding:8px;border:1px solid #b7c8d9;border-radius:8px;background:#fff;color:#193d66;font:inherit;line-height:1.4}
                .viena-button-backup input::file-selector-button{margin-right:10px;padding:6px 10px;border:1px solid #a7bbce;border-radius:5px;background:#e7eef6;color:#193d66;font:inherit}
                .viena-button-backup-actions{display:flex;flex-wrap:wrap;gap:10px;min-width:0}
                .viena-button-backup button{box-sizing:border-box;max-width:100%;min-height:40px;padding:10px 14px;margin:0;border-radius:8px;border:1px solid #193d66;background:#193d66;color:white;cursor:pointer;font:inherit;white-space:normal;overflow-wrap:anywhere;line-height:1.4}
                .viena-button-backup button:disabled{opacity:.5;cursor:default}
                .viena-button-backup button:focus-visible,.viena-button-backup input:focus-visible{outline:3px solid #cf9830;outline-offset:3px}
                .viena-button-backup .viena-button-backup-status{white-space:pre-line;color:#193d66}
                .viena-button-backup-status:empty{display:none}
                .viena-button-backup .viena-button-backup-status[data-error=true]{color:#a82a20}
                html[data-viena-theme=dark]:not(.standalone-folder-root) .viena-button-backup{background:#121d2a!important;border-color:#34495f!important;color:#d7e3ef!important}
                html[data-viena-theme=dark]:not(.standalone-folder-root) .viena-button-backup p,html[data-viena-theme=dark]:not(.standalone-folder-root) .viena-button-backup label{color:#d7e3ef!important}
                html[data-viena-theme=dark]:not(.standalone-folder-root) .viena-button-backup input[type=file]{background:#0d1722!important;border-color:#34495f!important;color:#e5eef7!important}
                html[data-viena-theme=dark]:not(.standalone-folder-root) .viena-button-backup input::file-selector-button{background:#203950;color:#e5eef7;border-color:#47657f}
                html[data-viena-theme=dark]:not(.standalone-folder-root) .viena-button-backup button{background:#203e60!important;border-color:#52799e!important;color:#f1f6fc!important}
                html[data-viena-theme=dark]:not(.standalone-folder-root) .viena-button-backup .viena-button-backup-status[data-error=true]{color:#ffb3ad!important}
                @media(max-width:520px){.viena-button-backup-actions{flex-direction:column}.viena-button-backup-actions button{width:100%}}
            `;
            document.head.append(style);
        }
        const box=document.createElement('section');box.setAttribute('aria-label','Respaldo de botones personales');
        box.className='viena-button-backup';
        const info=document.createElement('p');info.textContent='Guardá tus botones personales con todas sus plantillas para importarlos en otra PC. Los botones existentes se conservan.';
        const exportButton=document.createElement('button');exportButton.type='button';exportButton.textContent='Exportar botones';
        const importLabel=document.createElement('label');importLabel.textContent='Archivo de respaldo de botones';
        const file=document.createElement('input');file.type='file';file.accept='.json,application/json';file.setAttribute('aria-label','Archivo de respaldo de botones');file.style.maxWidth='100%';importLabel.append(file);
        const preview=document.createElement('p');preview.className='viena-button-backup-status';preview.setAttribute('role','status');
        const apply=document.createElement('button');apply.type='button';apply.textContent='Importar botones del respaldo';apply.disabled=true;
        const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancelar importación';cancel.disabled=true;
        const exportActions=document.createElement('div');exportActions.className='viena-button-backup-actions';exportActions.append(exportButton);
        const importActions=document.createElement('div');importActions.className='viena-button-backup-actions';importActions.append(apply,cancel);
        let selected=null,busy=false;
        const controls=()=>{exportButton.disabled=busy;file.disabled=busy;apply.disabled=busy||!selected;cancel.disabled=busy||!selected};
        const message=(text,error=false)=>{preview.textContent=text;preview.dataset.error=String(error)};
        const count=(n,singular,plural)=>n+' '+(n===1?singular:plural);
        const details=result=>count(result.added,'botón','botones')+' y '+count(result.addedTemplates,'plantilla','plantillas');
        const run=async fn=>{if(busy)return;busy=true;controls();try{await fn()}catch(e){message(e.message||'No se pudo completar la operación.',true)}finally{busy=false;controls()}};
        exportButton.addEventListener('click',()=>void run(async()=>{
            const backup=validate(await options.exportBackup());
            const url=URL.createObjectURL(new Blob([JSON.stringify(backup,null,2)],{type:'application/json'}));
            const a=document.createElement('a');a.href=url;a.download='VIENA-botones-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
            message('Respaldo de '+count(backup.buttons.length,'botón','botones')+' y '+count(backup.buttons.reduce((sum,g)=>sum+g.plantillas.length,0),'plantilla','plantillas')+' solicitado. Verificá el archivo en Descargas.');
        }));
        file.addEventListener('change',()=>void run(async()=>{
            selected=null;message('');const chosen=file.files[0];if(!chosen)return;
            if(chosen.size>32*1024*1024)throw Error('El archivo es demasiado grande para un respaldo de botones.');
            let backup;try{backup=JSON.parse(await chosen.text())}catch(_){throw Error('No se pudo leer el archivo de respaldo de botones.');}validate(backup);
            const result=await options.previewImport(backup);selected={backup,snapshot:result.snapshot};
            const totalTemplates=backup.buttons.reduce((sum,g)=>sum+g.plantillas.length,0);
            message('El respaldo contiene '+count(backup.buttons.length,'botón','botones')+' y '+count(totalTemplates,'plantilla','plantillas')+'.\nSe agregarán '+details(result)+'.'
                +(result.imported.length?'\n'+result.imported.map(g=>'• '+g.nombre+': '+count(g.templates,'plantilla','plantillas')).join('\n'):'\nLos botones del respaldo ya existen; no se duplicarán.')
                +'\nRevisá el resumen y pulsá Importar botones del respaldo.');
        }));
        cancel.addEventListener('click',()=>{selected=null;file.value='';message('Importación cancelada. Tus botones se conservan.');controls()});
        apply.addEventListener('click',()=>void run(async()=>{
            if(!selected)return;const result=await options.importBackup(selected.backup,selected.snapshot);selected=null;file.value='';
            message('Importación guardada y verificada: '+details(result)+'.'+(result.warning?' '+result.warning:''));
            if(options.onRestored)await options.onRestored();
        }));
        box.append(info,exportActions,importLabel,preview,importActions);host.append(box);return box;
    }
    const api={validate,merge,stable,mount};
    if(typeof module==='object'&&module.exports)module.exports=api;else root.VienaButtonBackup=api;
})(globalThis);
