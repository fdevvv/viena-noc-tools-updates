(() => {
    'use strict';
    if (globalThis.VienaTicketFields) return;
    const PREFIX = 'viena_ticket_field_visible_v1:';
    const BUTTON_PREFIX = 'viena_ticket_button_visible_v1:';
    const ORDER_PREFIX = 'viena_ticket_field_order_v1:';
    const BUTTON_ORDER_PREFIX = 'viena_ticket_button_order_v1:';
    const buttonAttributes = new WeakMap();
    const states = new Map();
    let current = null;
    const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
    const key = (user, name) => name === '@order' ? ORDER_PREFIX + encodeURIComponent(user)
        : name === '@button-order' ? BUTTON_ORDER_PREFIX + encodeURIComponent(user)
        : (name.startsWith('@button:') ? BUTTON_PREFIX : PREFIX) + encodeURIComponent(user) + ':' + encodeURIComponent(name.startsWith('@button:') ? name.slice(8) : name);
    const bounded = promise => {
        let timer;
        return Promise.race([promise, new Promise((_, reject) => {
            timer = setTimeout(() => reject(new Error('storage timeout')), 2500);
        })]).finally(() => clearTimeout(timer));
    };
    function userName() {
        const value = clean(globalThis.VienaUserConfig?.detectar?.() || globalThis.VienaUserConfig?.current).toLowerCase();
        return /^[a-z][a-z0-9._-]{2,30}$/.test(value) ? value : '';
    }
    function visible(state, name) {
        const value = current?.state === state && Object.hasOwn(current.draft || {},name) ? current.draft[name] : state.values[name];
        return typeof value === 'boolean' ? value : true;
    }
    function read(state, names) {
        if (!state.user) return;
        const missing = names.filter(name => !state.loaded.has(name));
        if (!missing.length) return;
        missing.forEach(name => {
            state.loaded.add(name);
            try {
                const mirror = localStorage.getItem(key(state.user, name));
                if (mirror === 'true' || mirror === 'false') state.values[name] = mirror === 'true';
                else if ((name === '@order' || name === '@button-order') && mirror) { const order = JSON.parse(mirror); if (Array.isArray(order)) state.values[name] = order.filter(item => typeof item === 'string'); }
            } catch (_) {}
        });
        void bounded(chrome.storage.local.get(missing.map(name => key(state.user, name))))
            .then(values => {
                for (const name of missing) {
                    if (state.changed.has(name)) continue;
                    const value = values[key(state.user, name)];
                    if (typeof value === 'boolean') state.values[name] = value;
                    else if ((name === '@order' || name === '@button-order') && Array.isArray(value)) state.values[name] = value.filter(item => typeof item === 'string');
                }
                refresh();
            }).catch(() => {
                if (current?.state === state) current.status.textContent = 'No se pudo leer la configuración guardada. Podés volver a intentar al reabrir VIENA.';
            });
    }
    function ordered(state, names, slot = '@order') {
        const value = current?.state === state && Object.hasOwn(current.draft || {},slot) ? current.draft[slot] : state.values[slot];
        const saved = Array.isArray(value) ? value : [];
        return [...new Set([...saved.filter(name => names.includes(name)), ...names])];
    }
    async function save(state, updates) {
        const view = current;
        if (!state.user || view.busy) return;
        const focus = view.menu.contains(document.activeElement) ? document.activeElement : null;
        const previous = Object.fromEntries(Object.keys(updates).map(name => [name, state.values[name]]));
        view.busy = true;
        for (const [name, value] of Object.entries(updates)) { state.changed.add(name); state.values[name] = value; }
        refresh();
        try {
            await bounded(chrome.storage.local.set(Object.fromEntries(Object.entries(updates).map(([name, value]) => [key(state.user, name), value]))));
            for (const [name, value] of Object.entries(updates)) { try { localStorage.setItem(key(state.user, name), JSON.stringify(value)); } catch (_) {} }
            view.status.textContent = 'Configuración guardada.';
            return true;
        } catch (_) {
            Object.assign(state.values, previous);
            view.status.textContent = 'No se pudo guardar. Volvé a intentar.';
            return false;
        } finally { view.busy = false; refresh(); if (focus?.isConnected && !focus.disabled) focus.focus({preventScroll:true}); }
    }
    function edit(state, updates) {
        if (!state.user || current.busy || current.state !== state) return;
        current.draft = { ...current.draft, ...updates };
        refresh();
        current.status.textContent = 'Vista previa · Cambios sin guardar.';
    }
    function toolbarData(root) {
        const native = [...root.querySelectorAll('button')].find(button => ['crear tarea','cambiar estado'].includes(clean(button.textContent).toLowerCase()));
        const toolbar = root.querySelector('#panel-plantillas-viena')?.parentElement || native?.closest('.row');
        if (!toolbar) return { toolbar:null, buttons:[] };
        const buttons = [...toolbar.querySelectorAll('button')].filter(button => !button.closest('.viena-ticket-fields-bar,.v-menu__content') && button.closest('.row') === toolbar)
            .map(button => ({ button, name:clean(button.textContent).replace(/^[✓✔✎]\s*/, ''), id:button.id }));
        return { toolbar, buttons:buttons.filter(item => item.name) };
    }
    function applyButton(button, hidden) {
        if (hidden && !buttonAttributes.has(button)) buttonAttributes.set(button, { aria:button.getAttribute('aria-hidden'), tab:button.getAttribute('tabindex') });
        button.classList.toggle('viena-ticket-button-hidden', hidden);
        if (hidden) { button.setAttribute('aria-hidden','true'); button.setAttribute('tabindex','-1'); }
        else if (buttonAttributes.has(button)) {
            const attributes = buttonAttributes.get(button);
            for (const [name, value] of [['aria-hidden',attributes.aria],['tabindex',attributes.tab]]) { if (value === null) button.removeAttribute(name); else button.setAttribute(name,value); }
            buttonAttributes.delete(button);
        }
    }
    function moveField(name, target, before = true) {
        if (!current?.state.user || current.busy || name === target) return;
        const order = ordered(current.state, current.names);
        if (!order.includes(name) || !order.includes(target)) return;
        order.splice(order.indexOf(name),1); order.splice(order.indexOf(target)+(before?0:1),0,name);
        const other = (current.state.values['@order'] || []).filter(item => !order.includes(item));
        edit(current.state, { '@order':[...order,...other] });
    }
    function moveButton(name, target, before = true) {
        if (!current?.state.user || current.busy || name === target) return;
        const order = ordered(current.state, current.buttons.map(item => item.name), '@button-order');
        if (!order.includes(name) || !order.includes(target)) return;
        order.splice(order.indexOf(name),1); order.splice(order.indexOf(target)+(before?0:1),0,name);
        const other = (current.state.values['@button-order'] || []).filter(item => !order.includes(item));
        edit(current.state, { '@button-order':[...order,...other] });
    }
    function discover(root) {
        for (const area of root.querySelectorAll('.ma-5')) {
            const fields = [];
            for (const row of area.querySelectorAll(':scope > .row')) {
                for (const column of row.querySelectorAll(':scope > .col')) {
                    if (column.classList.contains('viena-ticket-tools-host') || column.classList.contains('viena-completed-person-hidden')) continue;
                    const label = column.querySelector('.v-text-field__slot > label');
                    const control = label?.parentElement.querySelector('input[readonly],textarea[readonly]');
                    const name = clean(label?.textContent);
                    if (!name || !control) continue;
                    fields.push({ name, column, row, wide: control.tagName === 'TEXTAREA' });
                }
            }
            if (fields.some(field => field.name === 'Estado') && fields.some(field => field.name === 'Nodo CMTS')) return { area, fields };
        }
        return null;
    }
    function ensureStyle() {
        if (document.getElementById('viena-ticket-fields-style')) return;
        const style = document.createElement('style');
        style.id = 'viena-ticket-fields-style';
        style.textContent = `
            .viena-ticket-fields-grid { display:grid !important; grid-template-columns:repeat(4,minmax(0,1fr)); gap:0 0; }
            .viena-ticket-fields-grid > .viena-ticket-fields-row { display:contents !important; }
            .viena-ticket-fields-grid > .viena-ticket-fields-row > .viena-ticket-field { width:auto !important; max-width:100% !important; min-width:0 !important; }
            .viena-ticket-fields-grid > .viena-ticket-fields-row > .viena-ticket-field-hidden { display:none !important; }
            .viena-ticket-field-wide,.viena-ticket-fields-grid > .row > .viena-ticket-tools-host { grid-column:1 / -1; }
            .viena-ticket-fields-bar { grid-column:1 / -1; display:flex; justify-content:flex-end; position:relative; padding:0 12px 8px; }
            .viena-ticket-fields-toggle { min-height:36px; padding:6px 12px; border:1px solid #b8c9dc; border-radius:6px; color:#174f80; background:#f1f6fb; font:600 14px Arial; cursor:pointer; }
            .viena-ticket-fields-menu { position:absolute; right:12px; top:100%; width:min(340px,calc(100vw - 64px)); max-height:min(65vh,600px); overflow:auto; padding:14px; border:1px solid #b8c9dc; border-radius:10px; background:#fff; color:#24324a; box-shadow:0 8px 24px #10233b33; z-index:1000001; font:14px/1.5 Arial; }
            .viena-ticket-fields-menu[hidden] { display:none !important; }
            .viena-ticket-fields-menu label { display:flex; align-items:center; gap:10px; padding:7px 0; cursor:pointer; }
            .viena-ticket-fields-menu input[type=checkbox] { width:18px !important; height:18px !important; flex:0 0 18px; margin:0; accent-color:#1976d2; }
            .viena-ticket-fields-status { margin:8px 0; font-size:13px; }
            .viena-ticket-fields-menu button { min-height:34px; cursor:pointer; }
            .viena-ticket-fields-toolbar { position:relative !important; display:flex !important; flex-wrap:wrap; align-items:center; gap:8px; padding-right:0 !important; }
            .v-banner:has(.viena-ticket-fields-toolbar), .v-banner__wrapper:has(.viena-ticket-fields-toolbar), .v-banner__content:has(.viena-ticket-fields-toolbar), .v-banner__text:has(.viena-ticket-fields-toolbar) { overflow:visible !important; }
            .viena-ticket-fields-toolbar > #panel-plantillas-viena, .viena-ticket-fields-toolbar #viena-custom-template-groups, .viena-ticket-fields-toolbar #viena-ticket-macros-anchor { display:contents !important; }
            .viena-ticket-fields-toolbar > .viena-ticket-resync-btn { position:static !important; margin-left:auto !important; margin-right:0 !important; }
            .viena-ticket-fields-toolbar.viena-ticket-buttons-ordered > .viena-ticket-resync-btn { margin-left:0 !important; }
            .viena-ticket-fields-toolbar button:not(.viena-ticket-button-hidden) { margin:0 !important; }
            .viena-ticket-fields-toolbar #viena-custom-template-manager-btn { color:#1976d2 !important; background:white !important; border:1px solid #b8c9dc; box-shadow:none !important; }
            .viena-ticket-fields-toolbar > .viena-ticket-fields-bar { position:static; padding:0; margin-left:auto; }
            .viena-ticket-button-hidden { position:absolute !important; width:1px !important; height:1px !important; min-width:0 !important; min-height:0 !important; padding:0 !important; margin:0 !important; overflow:hidden !important; clip-path:inset(50%) !important; opacity:0 !important; pointer-events:none !important; }
            .viena-ticket-fields-menu { width:min(420px,calc(100vw - 32px)); padding:0; display:flex; flex-direction:column; max-height:min(76vh,820px); }
            .viena-ticket-fields-header,.viena-ticket-fields-footer { padding:14px 16px; flex:0 0 auto; background:inherit; }
            .viena-ticket-fields-header { display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid #d7e4f0; }
            .viena-ticket-fields-header strong { font-size:18px; }
            .viena-ticket-fields-body { overflow:auto; min-height:0; padding:0 16px; }
            .viena-ticket-fields-body section { padding:12px 0; border-bottom:1px solid #d7e4f0; }
            .viena-ticket-fields-body h3 { margin:0 0 4px; font-size:15px; color:#1976d2; }
            .viena-ticket-fields-help { margin:0 0 8px; color:#64748b; font-size:13px; }
            .viena-ticket-field-option,.viena-ticket-button-option { display:flex; align-items:center; border:1px solid #d7e4f0; border-radius:5px; margin:4px 0; padding:0 6px; gap:6px; }
            .viena-ticket-field-option label,.viena-ticket-button-option label { flex:1; min-width:0; }
            .viena-ticket-field-drag { cursor:grab; padding:5px; user-select:none; }
            .viena-ticket-field-option button,.viena-ticket-button-option button { border:0; background:transparent; color:#174f80; padding:0 5px; }
            .viena-ticket-field-option.viena-ticket-field-drop,.viena-ticket-button-option.viena-ticket-field-drop { outline:2px solid #1976d2; }
            .viena-ticket-fields-footer { border-top:1px solid #d7e4f0; display:flex; flex-wrap:wrap; gap:8px; }
            .viena-ticket-fields-footer button,.viena-ticket-fields-show-buttons { border:1px solid #b8c9dc; border-radius:5px; background:#fff; color:#174f80; padding:6px 10px; }
            .viena-ticket-fields-footer .viena-ticket-fields-done { background:#1976d2; color:#fff; margin-left:auto; }
            .viena-ticket-fields-preview-bar { position:fixed; bottom:16px; left:50%; transform:translateX(-50%); z-index:1000002; display:flex; flex-wrap:wrap; align-items:center; justify-content:center; gap:8px; width:max-content; max-width:calc(100vw - 32px); padding:12px; border:1px solid #b8c9dc; border-radius:8px; background:#fff; color:#174f80; box-shadow:0 4px 20px #10233b33; font:14px Arial; }
            .viena-ticket-fields-preview-bar[hidden] { display:none !important; }
            .viena-ticket-fields-preview-bar button { min-height:34px; border:1px solid #b8c9dc; border-radius:5px; padding:6px 10px; background:#fff; color:#174f80; cursor:pointer; }
            .viena-ticket-fields-preview-bar .viena-ticket-fields-preview-apply { background:#1976d2; color:#fff; }
            @media(max-width:960px) { .viena-ticket-fields-grid { grid-template-columns:repeat(2,minmax(0,1fr)); } }
            @media(max-width:520px) { .viena-ticket-fields-grid { grid-template-columns:minmax(0,1fr); } }
            html[data-viena-theme="dark"] .viena-ticket-fields-menu, .theme--dark .viena-ticket-fields-menu { background:#1e293b; color:#e2e8f0; border-color:#64748b; }
        `;
        document.head.appendChild(style);
    }
    function mount(root, area) {
        const bar = document.createElement('div');
        bar.className = 'viena-ticket-fields-bar';
        bar.setAttribute('data-viena-macro-ui', '1');
        const button = document.createElement('button');
        button.type = 'button'; button.className = 'viena-ticket-fields-toggle';
        button.textContent = '⚙ Personalizar vista'; button.setAttribute('aria-expanded', 'false'); button.setAttribute('aria-controls', 'viena-ticket-fields-menu');
        const menu = document.createElement('div');
        menu.id = 'viena-ticket-fields-menu'; menu.className = 'viena-ticket-fields-menu'; menu.hidden = true;
        menu.setAttribute('role', 'dialog'); menu.setAttribute('aria-label', 'Personalizar vista');
        const title = document.createElement('strong'); title.textContent = 'Personalizar vista';
        const header = document.createElement('div'); header.className='viena-ticket-fields-header';
        const body = document.createElement('div'); body.className='viena-ticket-fields-body';
        const buttonsSection = document.createElement('section');
        const buttonsTitle = document.createElement('h3'); buttonsTitle.textContent='Botones superiores';
        const buttonsHelp = document.createElement('p'); buttonsHelp.className='viena-ticket-fields-help'; buttonsHelp.textContent='Arrastrá para ordenar · Destildá para ocultar';
        const buttonOptions = document.createElement('div'); buttonOptions.className='viena-ticket-button-options';
        const showButtons = document.createElement('button'); showButtons.type='button'; showButtons.className='viena-ticket-fields-show-buttons'; showButtons.textContent='Mostrar todos';
        showButtons.onclick=()=>edit(current.state,Object.fromEntries(current.buttons.map(item=>['@button:'+item.name,true])));
        buttonsSection.append(buttonsTitle,buttonsHelp,buttonOptions,showButtons);
        const fieldsSection = document.createElement('section');
        const fieldsTitle = document.createElement('h3'); fieldsTitle.textContent='Campos del ticket';
        const help = document.createElement('p'); help.className='viena-ticket-fields-help'; help.textContent='Arrastrá para ordenar · Destildá para ocultar';
        const options = document.createElement('div'); options.className='viena-ticket-field-options';
        fieldsSection.append(fieldsTitle,help,options);
        const status = document.createElement('p'); status.className = 'viena-ticket-fields-status'; status.setAttribute('role', 'status');
        const close = document.createElement('button'); close.type = 'button'; close.textContent = '×'; close.setAttribute('aria-label','Cerrar personalización');
        const footer = document.createElement('div'); footer.className='viena-ticket-fields-footer';
        const reset = document.createElement('button'); reset.type='button'; reset.className='viena-ticket-fields-reset'; reset.textContent='Restaurar vista predeterminada';
        reset.onclick=()=>edit(current.state,{...Object.fromEntries([...current.names,...current.buttons.map(item=>'@button:'+item.name)].map(name=>[name,true])),'@order':[],'@button-order':[]});
        const done = document.createElement('button'); done.type='button'; done.className='viena-ticket-fields-done'; done.textContent='Aplicar';
        const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancelar';cancel.className='viena-ticket-fields-cancel';
        const result=document.createElement('button');result.type='button';result.textContent='Ver resultado';result.className='viena-ticket-fields-preview-result';
        const preview=document.createElement('div');preview.className='viena-ticket-fields-preview-bar';preview.hidden=true;
        const previewText=document.createElement('span');previewText.textContent='Vista previa · Cambios sin guardar';previewText.setAttribute('role','status');
        const previewEdit=document.createElement('button');previewEdit.type='button';previewEdit.textContent='Editar';
        const previewApply=document.createElement('button');previewApply.type='button';previewApply.textContent='Aplicar';previewApply.className='viena-ticket-fields-preview-apply';
        const previewCancel=document.createElement('button');previewCancel.type='button';previewCancel.textContent='Cancelar';previewCancel.className='viena-ticket-fields-preview-cancel';
        preview.append(previewText,previewEdit,previewApply,previewCancel);
        header.append(title,close); body.append(status,buttonsSection,fieldsSection); footer.append(reset,result,cancel,done); menu.append(header,body,footer); bar.append(button,menu,preview); area.prepend(bar);
        const hideMenu = () => { menu.hidden=true;area.classList.remove('viena-ticket-fields-open');button.setAttribute('aria-expanded','false');button.focus({preventScroll:true}); };
        const closeMenu = () => { if(current.busy)return;current.draft=null;refresh();hideMenu(); };
        const openMenu = () => { menu.hidden=false;area.classList.add('viena-ticket-fields-open');button.setAttribute('aria-expanded','true');(menu.querySelector('input:not(:disabled)')||close).focus({preventScroll:true}); };
        button.onclick = () => { if(menu.hidden)openMenu();else closeMenu(); };
        close.onclick = closeMenu;
        cancel.onclick=previewCancel.onclick=closeMenu;
        result.onclick=hideMenu;
        previewEdit.onclick=openMenu;
        done.onclick=previewApply.onclick=async()=>{if(current.busy||!current.draft)return;const view=current,updates=view.draft;view.draft=null;const saved=await save(view.state,updates);if(current===view&&saved)hideMenu();};
        bar.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); closeMenu(); } });
        for (const type of ['pointerdown','pointerup','mousedown','mouseup','click','dblclick','keydown','keypress','keyup','input','change','focusin','focusout']) bar.addEventListener(type, event => event.stopPropagation());
        return { root, area, bar, button, menu, options, buttonOptions, buttonsSection, status, preview, done, previewApply, result, signature:'', busy:false, dragName:'', draft:null };
    }
    function refresh() {
        const root = [...document.querySelectorAll('.v-dialog__content--active')].reverse().find(dialog => dialog.getClientRects().length && /^TICKET\s*:/i.test(clean(dialog.querySelector('.v-toolbar__title')?.textContent)));
        if (!root) { current?.bar.remove(); current = null; return; }
        const data = discover(root);
        if (!data) return;
        ensureStyle();
        if (current?.area !== data.area || !current.bar.isConnected) { current?.bar.remove(); current = mount(root, data.area); }
        const user = userName();
        if (!states.has(user)) states.set(user, { user, values:Object.create(null), loaded:new Set(), changed:new Set() });
        const state = states.get(user);
        if(current.state!==state)current.draft=null;
        current.state = state;
        const toolbar = toolbarData(root);
        const names = [...new Set(data.fields.map(field => field.name))];
        const signature = JSON.stringify([user, names, toolbar.buttons.map(item=>item.name)]);
        if(signature!==current.signature)current.draft=null;
        current.buttons = toolbar.buttons;
        if (toolbar.toolbar) { toolbar.toolbar.classList.add('viena-ticket-fields-toolbar'); if(current.bar.parentElement!==toolbar.toolbar) toolbar.toolbar.append(current.bar); }
        const buttonOrder = ordered(state, toolbar.buttons.map(item=>item.name), '@button-order');
        toolbar.toolbar?.classList.toggle('viena-ticket-buttons-ordered',!!(current.draft?.['@button-order']||state.values['@button-order'])?.length);
        current.bar.style.order=String(buttonOrder.length+1);
        for (const item of toolbar.buttons) { applyButton(item.button,!visible(state,'@button:'+item.name)); item.button.style.order=String(buttonOrder.indexOf(item.name)); }
        data.area.classList.add('viena-ticket-fields-grid');
        current.names=names;
        const order=ordered(state,names);
        for (const field of data.fields) {
            field.row.classList.add('viena-ticket-fields-row');
            field.column.classList.add('viena-ticket-field');
            field.column.classList.toggle('viena-ticket-field-wide', field.wide);
            field.column.classList.toggle('viena-ticket-field-hidden', !visible(state, field.name));
            field.column.style.order=String(order.indexOf(field.name)*2);
        }
        const messageIndex=order.indexOf('Mensaje');
        for(const host of data.area.querySelectorAll('.viena-ticket-tools-host')) host.style.order=String((messageIndex<0?order.length:messageIndex)*2-1);
        read(state, [...names,...toolbar.buttons.map(item=>'@button:'+item.name),'@order','@button-order']);
        if (signature !== current.signature) {
            current.signature = signature; current.menu.hidden = true; data.area.classList.remove('viena-ticket-fields-open'); current.button.setAttribute('aria-expanded','false'); current.options.replaceChildren(); current.buttonOptions.replaceChildren();
            current.status.textContent = user ? 'Los cambios se guardan para tu usuario.' : 'Esperando identificar tu usuario VIENA para guardar tus preferencias.';
            for (const name of names) {
                const row=document.createElement('div'); row.className='viena-ticket-field-option'; row.dataset.name=name;
                const handle=document.createElement('span'); handle.className='viena-ticket-field-drag'; handle.textContent='⠿'; handle.draggable=true; handle.title='Arrastrar '+name;
                handle.addEventListener('dragstart',event=>{if(current.busy||!state.user){event.preventDefault();return;}current.dragKind='fields';current.dragName=name;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',name);});
                handle.addEventListener('dragend',()=>{current.dragName='';current.options.querySelectorAll('.viena-ticket-field-drop').forEach(item=>item.classList.remove('viena-ticket-field-drop'));});
                row.addEventListener('dragover',event=>{if(current.dragKind!=='fields'||!current.dragName||current.busy)return;event.preventDefault();row.classList.add('viena-ticket-field-drop');});
                row.addEventListener('dragleave',()=>row.classList.remove('viena-ticket-field-drop'));
                row.addEventListener('drop',event=>{if(current.dragKind!=='fields')return;event.preventDefault();row.classList.remove('viena-ticket-field-drop');const source=current.dragName;current.dragName='';if(source)moveField(source,name);});
                const label = document.createElement('label');
                const input = document.createElement('input'); input.type = 'checkbox'; input.dataset.field = name;
                label.append(input, document.createTextNode(name)); row.append(handle,label);
                for(const direction of [-1,1]){const arrow=document.createElement('button');arrow.type='button';arrow.dataset.direction=String(direction);arrow.textContent=direction<0?'↑':'↓';arrow.setAttribute('aria-label',(direction<0?'Subir ':'Bajar ')+name);arrow.onclick=()=>{const order=ordered(state,current.names),index=order.indexOf(name);if(order[index+direction])moveField(name,order[index+direction],direction<0);};row.append(arrow);}
                current.options.append(row);
                input.addEventListener('change', async () => {
                    edit(state,{[name]:input.checked});
                });
            }
            for(const item of toolbar.buttons){
                const name=item.name,row=document.createElement('div');row.className='viena-ticket-button-option';row.dataset.name=name;
                const handle=document.createElement('span');handle.className='viena-ticket-field-drag';handle.textContent='⠿';handle.draggable=true;handle.title='Arrastrar '+name;
                handle.addEventListener('dragstart',event=>{if(current.busy||!state.user){event.preventDefault();return;}current.dragKind='buttons';current.dragName=name;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',name);});
                handle.addEventListener('dragend',()=>{current.dragName='';current.buttonOptions.querySelectorAll('.viena-ticket-field-drop').forEach(item=>item.classList.remove('viena-ticket-field-drop'));});
                row.addEventListener('dragover',event=>{if(current.dragKind!=='buttons'||!current.dragName||current.busy)return;event.preventDefault();row.classList.add('viena-ticket-field-drop');});
                row.addEventListener('dragleave',()=>row.classList.remove('viena-ticket-field-drop'));
                row.addEventListener('drop',event=>{if(current.dragKind!=='buttons')return;event.preventDefault();row.classList.remove('viena-ticket-field-drop');const source=current.dragName;current.dragName='';if(source)moveButton(source,name);});
                const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.dataset.button=name;label.append(input,document.createTextNode(name));row.append(handle,label);
                for(const direction of [-1,1]){const arrow=document.createElement('button');arrow.type='button';arrow.dataset.direction=String(direction);arrow.textContent=direction<0?'↑':'↓';arrow.setAttribute('aria-label',(direction<0?'Subir ':'Bajar ')+name);arrow.onclick=()=>{const order=ordered(state,current.buttons.map(item=>item.name),'@button-order'),index=order.indexOf(name);if(order[index+direction])moveButton(name,order[index+direction],direction<0);};row.append(arrow);}
                current.buttonOptions.append(row);input.onchange=()=>edit(state,{['@button:'+name]:input.checked});
            }
        }
        const rows=[...current.options.children];
        for(const name of order){const row=rows.find(item=>item.dataset.name===name);if(row&&current.options.children[order.indexOf(name)]!==row)current.options.insertBefore(row,current.options.children[order.indexOf(name)]||null);}
        for (const input of current.options.querySelectorAll('input')) { input.checked = visible(state, input.dataset.field); input.disabled = !user || current.busy; }
        for (const input of current.buttonOptions.querySelectorAll('input')) { input.checked=visible(state,'@button:'+input.dataset.button);input.disabled=!user||current.busy; }
        const buttonRows=[...current.buttonOptions.children];
        for(const name of buttonOrder){const row=buttonRows.find(item=>item.dataset.name===name),index=buttonOrder.indexOf(name);if(row&&current.buttonOptions.children[index]!==row)current.buttonOptions.insertBefore(row,current.buttonOptions.children[index]||null);}
        for(const row of current.buttonOptions.children){const index=buttonOrder.indexOf(row.dataset.name);for(const button of row.querySelectorAll('button'))button.disabled=!user||current.busy||(Number(button.dataset.direction)<0?index===0:index===buttonOrder.length-1);}
        current.buttonsSection.hidden=!toolbar.buttons.length;
        for(const row of current.options.children){const index=order.indexOf(row.dataset.name);for(const button of row.querySelectorAll('button'))button.disabled=!user||current.busy||(Number(button.dataset.direction)<0?index===0:index===order.length-1);}
        for(const button of current.menu.querySelectorAll('.viena-ticket-fields-reset,.viena-ticket-fields-show-buttons'))button.disabled=!user||current.busy;
        const pending=!!current.draft&&Object.keys(current.draft).some(name=>JSON.stringify(current.draft[name])!==JSON.stringify(state.values[name]));
        current.preview.hidden=!pending;
        current.done.disabled=current.previewApply.disabled=!user||current.busy||!pending;
        current.result.disabled=!pending||current.busy;
        for(const button of current.bar.querySelectorAll('.viena-ticket-fields-cancel,.viena-ticket-fields-preview-cancel,.viena-ticket-fields-header > button'))button.disabled=current.busy;
    }
    globalThis.VienaTicketFields = { refresh };
    document.addEventListener('viena:ui-refresh', refresh);
    refresh();
})();
