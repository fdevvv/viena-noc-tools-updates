(() => {
  'use strict';
  globalThis.VienaReleaseNotes = Object.freeze({
    version: '1.3.41',
    title: 'Nueva interfaz, macros y personalización',
    notes: Object.freeze([
      'Nueva interfaz del panel y los editores, con modo claro y oscuro en Personalización.',
      'Macros en VIENA y tareas manuales de MOICA: grabar, reproducir, detener y corregir pasos.',
      'Bibliotecas con búsqueda, carpetas, renombrado y orden por arrastre; elegí la carpeta antes de grabar.',
      'Respaldo e importación de macros VIENA/MOICA y de botones personales con sus plantillas.',
      'Plantillas editables: mensajes y motivos propios, traslado entre botones y orden por arrastre.',
      'Asignaciones: crear, editar, sumar tipificaciones, quitar códigos y eliminar plantillas.',
      'MOICA reemplaza los problemas y el mensaje anteriores al ejecutar otra macro; revisá el resultado.',
      'Anuncio de novedades deslizable al entrar a VIENA, una vez por actualización.'
    ]),
    slides: Object.freeze([
      {title:'Grabá tareas en VIENA',text:'En un ticket con tarea iniciada, abrí Macros Tareas. Elegí Grabar nueva tarea, realizá el recorrido, detené la grabación y guardala. Reproducila para repetir esos pasos en otro ticket; revisá siempre el resultado.'},
      {title:'Macros para tareas manuales en MOICA',text:'En Nuevo Ticket, abrí MACROS TAREA MANUAL. Grabá el recorrido y guardalo para reutilizarlo. Podés detener la reproducción y revisar el formulario antes de enviarlo.'},
      {title:'Organizá tus macros',text:'Buscá por nombre, creá carpetas y arrastrá para ordenar o mover macros. En Más opciones podés renombrarlas y eliminarlas. Antes de grabar también podés elegir una carpeta existente o crear una nueva.'},
      {title:'Corregí una macro y continuá',text:'Si cambió una opción, la macro se pausa. Usá Actualizar paso y elegí la opción correcta del sistema para guardar la corrección y continuar. Detener interrumpe el recorrido, pero no deshace los pasos ya realizados.'},
      {title:'Llevá tus macros a otra PC',text:'Abrí Personalización → Respaldo de macros y descargá ambas bibliotecas. En la otra PC, elegí el archivo, revisá el resumen y restauralas. Las macros existentes se conservan; el mismo respaldo no se duplica.'},
      {title:'Personalizá tus botones y plantillas',text:'Desde el Editor de botones creá tus propios botones y agregá plantillas. Editá nombres, mensajes y motivos según tu trabajo. Guardar cambios confirma la edición; Descartar cambios conserva lo anterior.'},
      {title:'Mové y ordená tus plantillas',text:'Usá Mover a otro botón para trasladar una plantilla a uno existente o crear un destino nuevo. En el editor, arrastrá para ordenar y guardá los cambios. En el menú desplegable, el orden se guarda al soltar.'},
      {title:'Respaldá tus botones personales',text:'En el Editor de botones, guardá tus cambios y elegí Exportar botones. Para importarlos en otra PC, seleccioná el respaldo, revisá los botones y plantillas que se agregarán y confirmá la importación.'},
      {title:'Editá tus Asignaciones',text:'Seleccioná tipificaciones en VIENA y creá una plantilla desde Asignaciones. El lápiz permite editarla: Agregar selección actual suma códigos sin duplicar, × los quita y Guardar confirma. También podés eliminar una plantilla.'},
      {title:'Macros MOICA sin acumulaciones',text:'Al ejecutar otra macro, se reemplazan los valores grabados. El mensaje se limpia y los problemas anteriores se retiran cuando el recorrido usa esos campos. Si no puede retirarlos, la macro se detiene. Revisá siempre el formulario.'},
      {title:'Nueva interfaz',text:'El popup, la vista completa y los editores tienen una presentación renovada, controles más claros y una distribución adaptable al tamaño de la ventana. Encontrá tus herramientas y personalizaciones desde el panel.'},
      {title:'Modo oscuro',text:'Abrí Personalización y elegí Claro u Oscuro en Tema visual. La elección se guarda en esta instalación y se comparte entre el popup y la vista completa de la extensión.'}
    ].map(slide=>Object.freeze(slide)))
  });
})();
