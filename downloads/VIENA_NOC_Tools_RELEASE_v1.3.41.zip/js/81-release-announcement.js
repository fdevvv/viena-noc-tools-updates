(() => {
  'use strict';
  if (location.hostname !== 'viena.telecentro.net.ar' || window.top !== window) return;
  const release=globalThis.VienaReleaseNotes;
  const HOST='viena-noc-release-announcement';
  if (!release || document.getElementById(HOST)) return;
  const channel=/\bDEV\b/i.test(chrome.runtime.getManifest().name)?'dev':'release';
  const key=`viena_release_news_seen_${channel}_v1`;
  let reading=false;
  async function start(){
    if(reading || document.getElementById(HOST)) return;
    reading=true;
    let timer;
    try {
      const stored=await Promise.race([
        chrome.storage.local.get([key,'viena_ui_theme_v1']),
        new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('timeout')),3000);})
      ]);
      if(stored[key]===release.version || document.getElementById(HOST)) return;
      await show(stored.viena_ui_theme_v1==='dark');
    } catch (_) { /* A failed announcement must never block VIENA. */ }
    finally { clearTimeout(timer);reading=false; }
  }
  function show(dark){
    return new Promise(resolve=>{
      const previous=document.activeElement;
      const host=document.createElement('div');host.id=HOST;
      const shadow=host.attachShadow({mode:'open'});
      const style=document.createElement('style');
      style.textContent=`
        :host{all:initial}*{box-sizing:border-box}
        dialog{--surface:#fff;--ink:#18324e;--muted:#52677c;--line:#d6e2ee;--soft:#f1f6fc;padding:0;border:1px solid var(--line);border-radius:20px;width:min(620px,calc(100vw - 28px));max-height:calc(100dvh - 28px);overflow:auto;background:var(--surface);color:var(--ink);box-shadow:0 24px 80px #071a3d55;font:16px/1.55 Arial,Helvetica,sans-serif}
        dialog.dark{--surface:#121e2c;--ink:#e1eaf4;--muted:#aabdd1;--line:#33465b;--soft:#1a2c40;color-scheme:dark}
        dialog::backdrop{background:#07172e88}header{padding:22px 26px;background:linear-gradient(120deg,#092e60,#164e89);color:#fff;display:flex;gap:16px;align-items:flex-start}header div{flex:1}.kicker{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#d0e2f7}h1{font-size:24px;line-height:1.25;margin:6px 0 0}button{font:inherit;cursor:pointer;border-radius:10px;min-height:44px;padding:9px 15px;border:1px solid var(--line);background:var(--soft);color:var(--ink)}button:focus-visible{outline:3px solid #4c9be8;outline-offset:3px}.close{background:transparent;color:white;border-color:#ffffff66;font-size:24px;line-height:1;padding:8px 12px}main{padding:24px 26px;touch-action:pan-y}.count{color:var(--muted);font-size:13px}h2{font-size:24px;line-height:1.3;margin:10px 0 14px}p{margin:0;min-height:125px;color:var(--muted)}.dots{display:flex;justify-content:center;gap:6px;padding:0 20px 18px}.dot{width:8px;height:8px;border-radius:50%;background:var(--line)}.dot.active{background:#3887d5}footer{border-top:1px solid var(--line);padding:18px 26px;display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between}button:disabled{opacity:.45;cursor:default}.primary{background:#165aa0;color:white;border-color:#165aa0}.next{margin-left:auto}@media(max-width:440px){header,main,footer{padding:18px}h1,h2{font-size:21px}p{min-height:0}footer button{padding:8px 11px;font-size:14px}}@media(prefers-reduced-motion:no-preference){dialog[open]{animation:appear .16s ease-out}@keyframes appear{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}`;
      const dialog=document.createElement('dialog');dialog.className=dark?'dark':'';
      dialog.setAttribute('aria-labelledby','news-title');dialog.setAttribute('aria-describedby','news-text');
      const header=document.createElement('header'),heading=document.createElement('div');
      const kicker=document.createElement('div');kicker.className='kicker';kicker.textContent=`VIENA NOC Tools · v${release.version}`;
      const title=document.createElement('h1');title.id='news-title';title.textContent='Conocé las novedades';heading.append(kicker,title);
      const close=document.createElement('button');close.type='button';close.className='close';close.textContent='×';close.setAttribute('aria-label','Cerrar novedades');header.append(heading,close);
      const main=document.createElement('main'),count=document.createElement('div'),slideTitle=document.createElement('h2'),text=document.createElement('p');
      count.className='count';text.id='news-text';main.setAttribute('aria-live','polite');main.setAttribute('aria-atomic','true');main.append(count,slideTitle,text);
      const dots=document.createElement('div');dots.className='dots';dots.setAttribute('aria-hidden','true');
      release.slides.forEach(()=>{const dot=document.createElement('span');dot.className='dot';dots.append(dot);});
      const footer=document.createElement('footer');
      function button(label,cls=''){const b=document.createElement('button');b.type='button';b.textContent=label;b.className=cls;return b;}
      const prev=button('Anterior'),next=button('Siguiente','next'),done=button('Entendido','primary');footer.append(prev,next,done);
      dialog.append(header,main,dots,footer);shadow.append(style,dialog);(document.body||document.documentElement).append(host);
      let index=0,closed=false,touchX=null;
      function render(){const slide=release.slides[index];count.textContent=`Novedad ${index+1} de ${release.slides.length} · Deslizá o usá las flechas`;slideTitle.textContent=slide.title;text.textContent=slide.text;prev.disabled=index===0;next.disabled=index===release.slides.length-1;Array.from(dots.children).forEach((d,i)=>d.classList.toggle('active',i===index));}
      function move(delta){index=Math.max(0,Math.min(release.slides.length-1,index+delta));render();}
      function dismiss(){if(closed)return;closed=true;dialog.close();host.remove();if(previous?.isConnected)previous.focus({preventScroll:true});void chrome.storage.local.set({[key]:release.version}).catch(()=>{});resolve();}
      prev.addEventListener('click',()=>move(-1));next.addEventListener('click',()=>move(1));done.addEventListener('click',dismiss);close.addEventListener('click',dismiss);
      dialog.addEventListener('cancel',e=>{e.preventDefault();dismiss();});
      dialog.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();dismiss();}else if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();e.stopPropagation();move(e.key==='ArrowRight'?1:-1);}});
      main.addEventListener('touchstart',e=>{touchX=e.touches.length===1?e.touches[0].clientX:null;},{passive:true});
      main.addEventListener('touchend',e=>{if(touchX!==null&&e.changedTouches.length){const delta=e.changedTouches[0].clientX-touchX;if(Math.abs(delta)>50)move(delta<0?1:-1);}touchX=null;},{passive:true});
      render();dialog.showModal();next.focus({preventScroll:true});
    });
  }
  // One VIENA tab presents the announcement while the other tabs remain usable.
  if(navigator.locks?.request){void navigator.locks.request(`viena-news-${channel}`,{ifAvailable:true},lock=>lock?start():undefined).catch(()=>{});}
  else void start();
})();
