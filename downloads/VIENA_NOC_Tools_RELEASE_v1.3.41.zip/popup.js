'use strict';
const VIENA_THEME_KEY='viena_ui_theme_v1';
const VIENA_THEME_PARAMS=new URLSearchParams(location.search);
const VIENA_THEME_STANDALONE=VIENA_THEME_PARAMS.get('standalone')==='1'||VIENA_THEME_PARAMS.get('macroBackup')==='1';
function vienaThemeNormalize(value){return value==='dark'?'dark':'light'}
function vienaThemePaint(root=document){if(VIENA_THEME_STANDALONE)return;const theme=vienaThemeNormalize(document.documentElement.dataset.vienaTheme);root.querySelectorAll('[data-viena-theme-choice]').forEach(button=>{const active=button.dataset.vienaThemeChoice===theme;button.classList.toggle('active',active);button.setAttribute('aria-pressed',active?'true':'false')})}
function vienaThemeApply(value){if(VIENA_THEME_STANDALONE)return 'light';const theme=vienaThemeNormalize(value);document.documentElement.dataset.vienaTheme=theme;vienaThemePaint();return theme}
async function vienaThemeSave(value){if(VIENA_THEME_STANDALONE)return;const theme=vienaThemeApply(value);try{await chrome.storage.local.set({[VIENA_THEME_KEY]:theme})}catch(_){}}
function vienaThemeBind(root=document){if(VIENA_THEME_STANDALONE)return;root.querySelectorAll('[data-viena-theme-choice]').forEach(button=>{if(button.dataset.vienaThemeBound==='1')return;button.dataset.vienaThemeBound='1';button.addEventListener('click',()=>{void vienaThemeSave(button.dataset.vienaThemeChoice)})});vienaThemePaint(root)}
globalThis.VienaTheme=Object.freeze({apply:vienaThemeApply,save:vienaThemeSave,bind:vienaThemeBind});
if(!VIENA_THEME_STANDALONE){chrome.storage.local.get([VIENA_THEME_KEY]).then(data=>vienaThemeApply(data?.[VIENA_THEME_KEY])).catch(()=>vienaThemeApply('light'));chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[VIENA_THEME_KEY])vienaThemeApply(changes[VIENA_THEME_KEY].newValue)});queueMicrotask(()=>vienaThemeBind(document))}
if (VIENA_THEME_PARAMS.get('macroBackup') === '1') {
  // Dedicated backup page is mounted by 48; popup and updater UI stay inactive.
} else if (new URLSearchParams(location.search).get('full') === '1') {
  globalThis.VienaHomeUI?.init?.();
} else {
const ASSIGN_KEY = 'viena_asignar_multiple_filtro';
const VIENA_UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/fdevvv/viena-noc-tools-updates/refs/heads/main/release/latest.json';
const VIENA_DEV_LOCAL_UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/fdevvv/viena-noc-tools-updates/refs/heads/main/dev/self-update.json';
const VIENA_RELEASE_MANIFEST_URL = 'https://raw.githubusercontent.com/fdevvv/viena-noc-tools-updates/refs/heads/main/release/latest.json';
const popupQueryParams = new URLSearchParams(location.search);
const isStandaloneFolderContext = popupQueryParams.get('standalone') === '1';
const installedVersionEl = document.getElementById('installedVersion');
const latestVersionEl = document.getElementById('latestVersion');
const updateStatusEl = document.getElementById('updateStatus');
const updateNotesEl = document.getElementById('updateNotes');
const checkUpdateBtn = document.getElementById('checkUpdate');
const openUpdateBtn = document.getElementById('openUpdate');
const manualReleaseZipBtn = document.getElementById('manualReleaseZip');
let updateDownloadUrl = '';
let updatePackageUrl = '';
let updatePackageSha256 = '';
let updateLatestVersion = '';
let updateLatestBuild = '';
let updateTargetChannel = '';
let currentRuntimeBuild = '';
let updateBadgeAvailable = false;
let runtimeBadgeState = 'CHECKING';
let waitingForRuntimeReload = false;
let updateCheckInFlight = false;
const VIENA_POPUP_BUILD_ID = '1.3.41';
const POPUP_DEV_UPDATE_CACHE_KEY = 'viena_popup_dev_update_cache_v1';

const updateConfirmOverlay = document.getElementById('updateConfirmOverlay');
const updateConfirmTitle = document.getElementById('updateConfirmTitle');
const updateConfirmVersion = document.getElementById('updateConfirmVersion');
const updateConfirmMessage = document.getElementById('updateConfirmMessage');
const updateConfirmCancel = document.getElementById('updateConfirmCancel');
const updateConfirmAccept = document.getElementById('updateConfirmAccept');
let updateConfirmCleanup = null;

function closeUpdateConfirm() {
  if (!updateConfirmOverlay) return;
  updateConfirmOverlay.classList.remove('show');
  updateConfirmOverlay.setAttribute('aria-hidden', 'true');
  if (typeof updateConfirmCleanup === 'function') updateConfirmCleanup();
  updateConfirmCleanup = null;
}

function requestUpdateConfirmation({
  title = 'Actualizar VIENA NOC Tools',
  fromLabel = '',
  toLabel = '',
  message = 'Los archivos de la carpeta vinculada serán reemplazados automáticamente.',
  confirmLabel = 'Actualizar'
} = {}, onConfirm, onCancel) {
  if (!updateConfirmOverlay || !updateConfirmAccept || !updateConfirmCancel) {
    showToast('No se pudo abrir la confirmación de actualización.', 'error');
    if (typeof onCancel === 'function') onCancel();
    return;
  }
  if (typeof updateConfirmCleanup === 'function') updateConfirmCleanup();

  updateConfirmTitle.textContent = title;
  updateConfirmVersion.textContent = fromLabel && toLabel ? `${fromLabel}  →  ${toLabel}` : (toLabel || fromLabel || 'Nueva versión');
  updateConfirmMessage.textContent = message;
  updateConfirmAccept.textContent = confirmLabel;

  const cancel = () => {
    closeUpdateConfirm();
    if (typeof onCancel === 'function') onCancel();
  };
  const accept = () => {
    closeUpdateConfirm();
    if (typeof onConfirm === 'function') onConfirm();
  };
  const keydown = (event) => {
    if (event.key === 'Escape') cancel();
  };
  const backdrop = (event) => {
    if (event.target === updateConfirmOverlay) cancel();
  };

  updateConfirmCancel.addEventListener('click', cancel);
  updateConfirmAccept.addEventListener('click', accept);
  updateConfirmOverlay.addEventListener('click', backdrop);
  document.addEventListener('keydown', keydown);
  updateConfirmCleanup = () => {
    updateConfirmCancel.removeEventListener('click', cancel);
    updateConfirmAccept.removeEventListener('click', accept);
    updateConfirmOverlay.removeEventListener('click', backdrop);
    document.removeEventListener('keydown', keydown);
  };

  updateConfirmOverlay.classList.add('show');
  updateConfirmOverlay.setAttribute('aria-hidden', 'false');
  setTimeout(() => updateConfirmAccept.focus(), 0);
}

const currentBadgeHelp = document.getElementById('currentBadgeHelp');
const currentBadgeCode = document.getElementById('currentBadgeCode');
const currentBadgeText = document.getElementById('currentBadgeText');
const BADGE_HELP = {
  ON: { cls: 'on', text: '<b>ON — Activa.</b> La extensión y la pestaña operativa están sincronizadas.' },
  TAB: { cls: 'tab', text: '<b>TAB — Pestaña desactualizada.</b> Recargá la pestaña marcada como “Recargar”.' },
  RLD: { cls: 'rld', text: '<b>RLD — Extensión por recargar.</b> Chrome todavía está usando el runtime anterior; esperá la recarga automática o recargá manualmente si persiste.' },
  UPD: { cls: 'upd', text: '<b>UPD — Actualización disponible.</b> Hay una RELEASE más nueva para descargar.' },
  CHECKING: { cls: 'checking', text: '<b>Estado:</b> comprobando el runtime, las pestañas y el canal de actualización.' }
};

function renderCurrentBadgeHelp() {
  if (!currentBadgeHelp || !currentBadgeCode || !currentBadgeText) return;
  const code = runtimeBadgeState === 'RLD' || runtimeBadgeState === 'TAB'
    ? runtimeBadgeState
    : updateBadgeAvailable
      ? 'UPD'
      : runtimeBadgeState === 'ON' ? 'ON' : 'CHECKING';
  const info = BADGE_HELP[code] || BADGE_HELP.CHECKING;
  currentBadgeHelp.className = `status-context ${info.cls}`;
  currentBadgeCode.textContent = code === 'CHECKING' ? '…' : code;
  const updText = updateTargetChannel === 'DEV'
    ? '<b>UPD — Actualización DEV disponible.</b> Hay un build DEV más nuevo listo para instalar.'
    : BADGE_HELP.UPD.text;
  currentBadgeText.innerHTML = code === 'UPD' ? updText : info.text;
}

renderCurrentBadgeHelp();

const OPERATOR_RELEASE_HISTORY = [
  ...(globalThis.VienaReleaseNotes ? [globalThis.VienaReleaseNotes] : []),
  {
    version: '1.3.38',
    title: 'Estado de actualización más preciso',
    notes: [
      'Se corrigió la detección de la RELEASE vigente para que el estado mostrado coincida con la versión publicada.',
      'Se ordenó el historial visible para mantener únicamente información útil para el operador.'
    ]
  },
  {
    version: '1.3.37',
    title: 'Mejoras de estabilidad',
    notes: [
      'Se mejoró la estabilidad general de la extensión y la actualización de actividad.',
      'El historial visible incorpora las RELEASES recientes con información operativa.'
    ]
  },
  {
    version: '1.3.36',
    title: 'Menús de Completar Tarea más ordenados',
    notes: [
      'Completar Tarea y los botones personales mantienen un solo menú desplegable abierto a la vez.',
      'El historial de versiones visible en el popup se actualizó con las RELEASES recientes.'
    ]
  }
];


function renderOperatorReleaseHistory() {
  const list = document.getElementById('releaseHistoryList');
  if (!list) return;
  const installed = chrome.runtime.getManifest().version;
  const isDev = /DEV/i.test(String(chrome.runtime.getManifest().name || ''));
  list.replaceChildren();

  for (const release of OPERATOR_RELEASE_HISTORY) {
    const entry = document.createElement('div');
    entry.className = 'release-entry';

    const head = document.createElement('div');
    head.className = 'release-entry-head';
    const version = document.createElement('span');
    version.className = 'release-version';
    version.textContent = `v${release.version}`;
    head.appendChild(version);

    if (release.version === installed) {
      const tag = document.createElement('span');
      tag.className = 'release-tag current';
      tag.textContent = isDev ? 'DEV actual' : 'Actual';
      head.appendChild(tag);
    }

    const title = document.createElement('div');
    title.className = 'release-title';
    title.textContent = release.title;

    const notes = document.createElement('ul');
    notes.className = 'release-notes';
    for (const note of release.notes) {
      const li = document.createElement('li');
      li.textContent = note;
      notes.appendChild(li);
    }

    entry.append(head, title, notes);
    list.appendChild(entry);
  }
}

renderOperatorReleaseHistory();

function compareVersions(a, b) {
  const pa = String(a || '').split('.').map(n => Number.parseInt(n, 10) || 0);
  const pb = String(b || '').split('.').map(n => Number.parseInt(n, 10) || 0);
  const max = Math.max(pa.length, pb.length);
  for (let i = 0; i < max; i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

function compareDevBuilds(latestBuild, runtimeBuild) {
  const latestFix = String(latestBuild || '').match(/(?:^|[-_.])fix(\d+)$/i);
  const runtimeFix = String(runtimeBuild || '').match(/(?:^|[-_.])fix(\d+)$/i);
  return latestBuild === runtimeBuild ? 0
    : latestFix && runtimeFix ? Number(latestFix[1]) - Number(runtimeFix[1])
      : 1;
}

function validHttpsUrl(value) {
  try { return new URL(String(value || '')).protocol === 'https:'; } catch (_) { return false; }
}

function setUpdateStatus(text, type = '') {
  updateStatusEl.textContent = text;
  updateStatusEl.className = 'update-status' + (type ? ` ${type}` : '');
}

function isDevRuntime() {
  return /\bDEV\b/i.test(String(chrome.runtime.getManifest().name || ''));
}


const MANUAL_RELEASE_ZIP_USERS = Object.freeze({
  DEV: new Set(['efoschi']),
  RELEASE: new Set(['mbruno'])
});
const MANUAL_RELEASE_ZIP_BASE_URL = 'https://raw.githubusercontent.com/fdevvv/viena-noc-tools-updates/refs/heads/main/downloads';

function normalizeManualUpdateUser(value) {
  const raw = typeof value === 'string' ? value : (value?.usuario ?? value?.username ?? value?.user ?? '');
  return String(raw || '').trim().toLowerCase();
}

async function getRecognizedVienaUserForManualUpdate() {
  try {
    const data = await chrome.storage.local.get(['viena_usuario']);
    return normalizeManualUpdateUser(data?.viena_usuario);
  } catch (_) {
    return '';
  }
}

async function resolveManualReleaseZipTarget() {
  const channel = isDevRuntime() ? 'DEV' : 'RELEASE';
  const user = await getRecognizedVienaUserForManualUpdate();
  if (!MANUAL_RELEASE_ZIP_USERS[channel]?.has(user)) return null;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 6000);
  try {
    const url = `${VIENA_RELEASE_MANIFEST_URL}?_manual_zip=${Date.now()}`;
    const response = await fetch(url, { cache: 'no-store', signal: controller.signal, headers: { 'Cache-Control': 'no-cache' } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const latest = String(data?.latest || '').trim();
    if (!/^\d+\.\d+\.\d+$/.test(latest)) throw new Error('RELEASE latest inválida');
    return { user, latest, url: `${MANUAL_RELEASE_ZIP_BASE_URL}/VIENA_NOC_Tools_RELEASE_v${latest}.zip` };
  } finally {
    clearTimeout(timer);
  }
}

async function refreshManualReleaseZipButton() {
  if (!manualReleaseZipBtn) return;
  manualReleaseZipBtn.style.display = 'none';
  manualReleaseZipBtn.dataset.url = '';
  manualReleaseZipBtn.dataset.version = '';
  try {
    const target = await resolveManualReleaseZipTarget();
    if (!target) return;
    manualReleaseZipBtn.dataset.url = target.url;
    manualReleaseZipBtn.dataset.version = target.latest;
    manualReleaseZipBtn.textContent = `Descargar ZIP · v${target.latest}`;
    manualReleaseZipBtn.style.display = '';
  } catch (_) {}
}

manualReleaseZipBtn?.addEventListener('click', async () => {
  const previous = manualReleaseZipBtn.textContent;
  manualReleaseZipBtn.disabled = true;
  try {
    const target = await resolveManualReleaseZipTarget();
    if (!target) {
      manualReleaseZipBtn.style.display = 'none';
      return;
    }
    const result = await chrome.runtime.sendMessage({ type: 'VIENA_OPEN_MANUAL_RELEASE_ZIP', url: target.url, version: target.latest });
    if (!result?.ok) throw new Error(result?.detail || result?.error || 'No se pudo abrir la descarga.');
    showToast(`Abriendo ZIP manual de la RELEASE ${target.latest}.`, 'success');
  } catch (error) {
    showToast(`No se pudo abrir el ZIP manual: ${String(error?.message || error)}`, 'error');
  } finally {
    manualReleaseZipBtn.disabled = false;
    manualReleaseZipBtn.textContent = previous;
  }
});

if (!isStandaloneFolderContext) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes?.viena_usuario) void refreshManualReleaseZipButton();
  });
  void refreshManualReleaseZipButton();
}

async function fetchDevChannelState() {
  // FIX116: la búsqueda del popup queda aislada del service worker.
  // El bug de FIX114/115 era que el popup esperaba VIENA_UPDATE_CHECK_NOW y podía
  // quedar visualmente en "Buscando..." si el worker no cerraba el canal de respuesta.
  // El manifest DEV es pequeño: se consulta directamente con AbortController y límite duro.
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const url = `${VIENA_DEV_LOCAL_UPDATE_MANIFEST_URL}?_popup=${Date.now()}`;
    const response = await fetch(url, {
      cache: 'no-store',
      signal: controller.signal,
      headers: { 'Cache-Control': 'no-cache, no-store' }
    });
    if (!response.ok) throw new Error(`DEV manifest HTTP ${response.status}`);
    const data = await response.json();
    const latest = String(data?.version || '').trim();
    const latestBuild = String(data?.build || '').trim();
    const channel = String(data?.channel || '').toUpperCase();
    const packageUrl = String(data?.package_url || '').trim();
    const packageSha256 = String(data?.package_sha256 || '').toLowerCase();
    if (!/^\d+\.\d+\.\d+$/.test(latest) || !latestBuild || channel !== 'DEV') {
      throw new Error('El canal DEV devolvió una identidad inválida.');
    }
    if (!validHttpsUrl(packageUrl) || !/^[a-f0-9]{64}$/.test(packageSha256)) {
      throw new Error('El canal DEV devolvió un paquete inválido.');
    }
    return {
      installed: chrome.runtime.getManifest().version,
      latest,
      latestBuild,
      runtimeBuild: VIENA_POPUP_BUILD_ID,
      mandatory: false,
      downloadUrl: '',
      packageUrl,
      packageSha256,
      notes: Array.isArray(data?.notes) && data.notes.length
        ? data.notes
        : ['Canal DEV: actualización directa de la carpeta vinculada desde el popup.'],
      channel: 'DEV'
    };
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('La consulta DEV superó 5 segundos.');
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function checkForUpdates({ manual = false } = {}) {
  // Una comprobación silenciosa de arranque puede convivir con una búsqueda manual.
  // Sólo bloqueamos dobles clicks manuales.
  if (manual && updateCheckInFlight) return;
  if (manual) updateCheckInFlight = true;
  const installed = chrome.runtime.getManifest().version;
  installedVersionEl.textContent = installed;
  let busyWatchdog = 0;
  if (manual) {
    checkUpdateBtn.disabled = true;
    checkUpdateBtn.setAttribute('aria-busy', 'true');
    checkUpdateBtn.textContent = 'Buscando…';
    // Última defensa de UI: aunque una Promise externa se comporte mal, el botón
    // recupera estado en un plazo acotado.
    busyWatchdog = setTimeout(() => {
      updateCheckInFlight = false;
      checkUpdateBtn.disabled = false;
      checkUpdateBtn.removeAttribute('aria-busy');
      checkUpdateBtn.textContent = 'Buscar actualización DEV';
      setUpdateStatus('La comprobación tardó demasiado. Podés volver a intentarlo sin cerrar el popup.', 'warn');
    }, 6500);
  }
  try {
    let data = null;
    if (isDevRuntime()) {
      data = await fetchDevChannelState();
    } else {
      let result;
      try {
        result = await chrome.runtime.sendMessage({ type: 'VIENA_UPDATE_CHECK_NOW' });
      } catch (_) {
        result = null;
      }
      data = result?.ok ? result.state : null;
    }
    if (!isDevRuntime() && (!data || !/^\d+\.\d+\.\d+$/.test(String(data.latest || '').trim()))) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 6000);
      try {
        const freshManifestUrl = `${VIENA_UPDATE_MANIFEST_URL}${VIENA_UPDATE_MANIFEST_URL.includes('?') ? '&' : '?'}_=${Date.now()}`;
        const response = await fetch(freshManifestUrl, { cache: 'no-store', signal: controller.signal, headers: { 'Cache-Control': 'no-cache' } });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const remote = await response.json();
        data = {
          installed,
          latest: String(remote?.latest || '').trim(),
          mandatory: remote?.mandatory === true || (remote?.minimum && compareVersions(installed, String(remote.minimum)) < 0),
          downloadUrl: validHttpsUrl(remote?.download_url) ? remote.download_url : '',
          packageUrl: validHttpsUrl(remote?.package_url) ? remote.package_url : '',
          packageSha256: /^[a-f0-9]{64}$/i.test(String(remote?.package_sha256 || '')) ? String(remote.package_sha256).toLowerCase() : '',
          latestBuild: String(remote?.build || '').trim(),
          channel: 'RELEASE',
          notes: Array.isArray(remote?.notes) ? remote.notes.filter(Boolean).slice(0, 8) : []
        };
      } finally {
        clearTimeout(timer);
      }
    }

    const latest = String(data?.latest || '').trim();
    if (!/^\d+\.\d+\.\d+$/.test(latest)) throw new Error(isDevRuntime() ? 'El canal DEV no contiene una versión válida' : 'release/latest.json no contiene latest válido');
    latestVersionEl.textContent = isDevRuntime() ? `${latest} DEV` : latest;
    const notes = Array.isArray(data.notes) ? data.notes.filter(Boolean).slice(0, 8).join('\n• ') : '';
    if (notes) updateNotesEl.textContent = '• ' + notes;

    if (isDevRuntime()) {
      const runtimeBuild = String(data?.runtimeBuild || '').trim();
      const latestBuild = String(data?.latestBuild || '').trim();
      if (!latestBuild || String(data?.channel || 'DEV').toUpperCase() !== 'DEV') throw new Error('El canal DEV no contiene un build válido');
      updateLatestVersion = latest;
      updateLatestBuild = '';
      updateTargetChannel = 'RELEASE';
      updateLatestBuild = latestBuild;
      updateTargetChannel = 'DEV';
      if (validHttpsUrl(data.packageUrl) && /^[a-f0-9]{64}$/i.test(String(data.packageSha256 || ''))) {
        updatePackageUrl = data.packageUrl;
        updatePackageSha256 = String(data.packageSha256).toLowerCase();
      }
      if (!runtimeBuild) throw new Error('No se pudo identificar el build DEV activo.');
      currentRuntimeBuild = runtimeBuild;
      const changed = compareDevBuilds(latestBuild, runtimeBuild) > 0;
      // Cache local del popup: al volver a abrir, DISPONIBLE se hidrata sin
      // esperar al service worker ni a la red. No bloquea el render.
      void chrome.storage.local.set({
        [POPUP_DEV_UPDATE_CACHE_KEY]: {
          latest,
          latestBuild,
          runtimeBuild: VIENA_POPUP_BUILD_ID,
          packageUrl: data.packageUrl,
          packageSha256: data.packageSha256,
          notes: Array.isArray(data.notes) ? data.notes.slice(0, 8) : [],
          available: changed,
          checkedAt: Date.now()
        }
      }).catch(() => {});
      if (changed) {
        updateBadgeAvailable = true;
        renderCurrentBadgeHelp();
        await renderUpdateActionButton();
        setUpdateStatus(`Nuevo build DEV disponible: ${latestBuild}.`, 'warn');
        if (manual) showToast('Hay un nuevo build DEV disponible.', 'warning');
      } else if (latestBuild === runtimeBuild) {
        updateBadgeAvailable = false;
        updateDownloadUrl = '';
        updatePackageUrl = '';
        updatePackageSha256 = '';
        updateLatestVersion = latest;
        updateLatestBuild = latestBuild;
        updateTargetChannel = 'DEV';
        openUpdateBtn.style.display = 'none';
        renderCurrentBadgeHelp();
        setUpdateStatus('Estás usando el último build DEV publicado.', 'ok');
        if (manual) showToast('VIENA NOC Tools DEV está actualizado.', 'success');
      } else {
        updateBadgeAvailable = false;
        updateDownloadUrl = '';
        updatePackageUrl = '';
        updatePackageSha256 = '';
        updateLatestVersion = latest;
        updateLatestBuild = latestBuild;
        updateTargetChannel = 'DEV';
        openUpdateBtn.style.display = 'none';
        renderCurrentBadgeHelp();
        setUpdateStatus(`El build activo es más reciente que el publicado (${latestBuild}). No hay una actualización disponible.`, 'ok');
        if (manual) showToast('El build activo es más reciente que el publicado.', 'success');
      }
      return;
    }

    const cmp = compareVersions(latest, installed);
    if (cmp > 0) {
      updateBadgeAvailable = true;
      renderCurrentBadgeHelp();
      updateLatestVersion = latest;
      updateLatestBuild = String(data?.latestBuild || data?.build || '').trim();
      updateTargetChannel = 'RELEASE';
      if (validHttpsUrl(data.downloadUrl)) updateDownloadUrl = data.downloadUrl;
      if (validHttpsUrl(data.packageUrl) && /^[a-f0-9]{64}$/i.test(String(data.packageSha256 || ''))) {
        updatePackageUrl = data.packageUrl;
        updatePackageSha256 = String(data.packageSha256).toLowerCase();
      }
      await renderUpdateActionButton();
      setUpdateStatus(data.mandatory ? `Actualización requerida: v${latest}.` : `Nueva versión disponible: v${latest}.`, 'warn');
      if (manual) showToast(`Hay una actualización disponible: v${latest}.`, 'warning');
    } else if (cmp === 0) {
      updateBadgeAvailable = false;
      updateDownloadUrl = '';
      updatePackageUrl = '';
      updatePackageSha256 = '';
      updateLatestVersion = latest;
      updateLatestBuild = '';
      updateTargetChannel = 'RELEASE';
      openUpdateBtn.style.display = 'none';
      renderCurrentBadgeHelp();
      setUpdateStatus('Estás usando la última versión.', 'ok');
      if (manual) showToast(`VIENA NOC Tools está actualizado en v${latest}.`, 'success');
    } else {
      updateBadgeAvailable = false;
      renderCurrentBadgeHelp();
      setUpdateStatus(`Tu versión v${installed} es más nueva que el canal publicado (v${latest}).`, 'warn');
    }
  } catch (error) {
    updateBadgeAvailable = false;
    renderCurrentBadgeHelp();
    latestVersionEl.textContent = '—';
    setUpdateStatus(`No se pudo comprobar la versión: ${error?.name === 'AbortError' ? 'tiempo de espera agotado' : error?.message || 'error desconocido'}.`, 'error');
    if (manual) showToast('No se pudo comprobar actualizaciones.', 'error');
  } finally {
    if (manual) {
      if (busyWatchdog) clearTimeout(busyWatchdog);
      updateCheckInFlight = false;
      checkUpdateBtn.disabled = false;
      checkUpdateBtn.removeAttribute('aria-busy');
      checkUpdateBtn.textContent = isDevRuntime() ? 'Buscar actualización DEV' : 'Buscar actualización';
    }
  }
}

async function hydrateCachedDevUpdateState() {
  if (!isDevRuntime()) return;
  try {
    // FIX116: leer cache local directamente. Abrir el popup no depende de que el
    // service worker despierte o responda.
    const saved = await popupPromiseTimeout(
      chrome.storage.local.get([POPUP_DEV_UPDATE_CACHE_KEY]),
      500,
      'popup_cache_timeout'
    );
    const state = saved?.[POPUP_DEV_UPDATE_CACHE_KEY] || null;
    const latestBuild = String(state?.latestBuild || '').trim();
    if (!state?.available || !latestBuild || compareDevBuilds(latestBuild, VIENA_POPUP_BUILD_ID) <= 0) return;
    const packageUrl = String(state?.packageUrl || '').trim();
    const packageSha256 = String(state?.packageSha256 || '').toLowerCase();
    currentRuntimeBuild = VIENA_POPUP_BUILD_ID;
    updateLatestVersion = String(state?.latest || chrome.runtime.getManifest().version || '').trim();
    updateLatestBuild = latestBuild;
    updateTargetChannel = 'DEV';
    updatePackageUrl = validHttpsUrl(packageUrl) ? packageUrl : '';
    updatePackageSha256 = /^[a-f0-9]{64}$/.test(packageSha256) ? packageSha256 : '';
    updateBadgeAvailable = true;
    latestVersionEl.textContent = `${updateLatestVersion} DEV`;
    const notes = Array.isArray(state?.notes) ? state.notes.filter(Boolean).slice(0, 8).join('\n• ') : '';
    if (notes) updateNotesEl.textContent = '• ' + notes;
    renderCurrentBadgeHelp();
    await renderUpdateActionButton();
    setUpdateStatus(`Nuevo build DEV disponible: ${latestBuild}.`, 'warn');
  } catch (_) {
    // Cache best-effort: nunca impedir la apertura del popup.
  }
}

checkUpdateBtn.addEventListener('click', () => void checkForUpdates({ manual: true }));
openUpdateBtn.addEventListener('click', async () => {
  if (updatePackageUrl && updatePackageSha256 && window.VienaLocalUpdater?.supported()) {
    const currentVersion = chrome.runtime.getManifest().version || 'actual';
    const isDevTarget = updateTargetChannel === 'DEV';
    requestUpdateConfirmation({
      title: isDevTarget ? 'Actualizar VIENA NOC Tools DEV' : 'Actualizar VIENA NOC Tools',
      fromLabel: isDevTarget ? (currentRuntimeBuild || 'DEV actual') : `v${currentVersion}`,
      toLabel: isDevTarget ? updateLatestBuild : `v${updateLatestVersion}`,
      message: cachedInstallFolderStatus?.linked
        ? `Se reemplazarán automáticamente los archivos de la carpeta ${isDevTarget ? 'DEV ' : ''}vinculada.`
        : `Primero se te pedirá elegir la carpeta ${isDevTarget ? 'DEV ' : ''}instalada. Después se reemplazarán sus archivos automáticamente.`
    }, () => { void runLocalChannelUpdate(openUpdateBtn); });
    return;
  }
  if (!validHttpsUrl(updateDownloadUrl)) return;
  await chrome.tabs.create({ url: updateDownloadUrl });
});

const testUpdateNotificationBtn = document.getElementById('testUpdateNotification');
const testUpdateNotificationRow = document.getElementById('testUpdateNotificationRow');
if (isDevRuntime()) {
  if (testUpdateNotificationRow) testUpdateNotificationRow.style.display = 'flex';
  if (testUpdateNotificationBtn) {
    testUpdateNotificationBtn.addEventListener('click', async () => {
      testUpdateNotificationBtn.disabled = true;
      try {
        const result = await chrome.runtime.sendMessage({ type: 'VIENA_DEV_TEST_UPDATE_BANNER' });
        if (!result?.ok) throw new Error(result?.detail || 'No se pudo mostrar el aviso');
        showToast('Aviso DEV enviado a las pestañas de VIENA abiertas.', 'success');
      } catch (error) {
        showToast(`No se pudo probar el aviso: ${error?.message || 'error desconocido'}.`, 'error');
      } finally {
        testUpdateNotificationBtn.disabled = false;
      }
    });
  }
} else {
  testUpdateNotificationRow?.remove();
}

const userInput = document.getElementById('user');
const assignInput = document.getElementById('assignSurname');
const userStatus = document.getElementById('userStatus');
const assignStatus = document.getElementById('assignStatus');
const toast = document.getElementById('toast');
const toastText = document.getElementById('toastText');
const toastIcon = document.getElementById('toastIcon');
let toastTimer = 0;

function showToast(message, type = 'success') {
  if (toastTimer) clearTimeout(toastTimer);
  toast.className = `show ${type}`;
  toastText.textContent = message;
  toastIcon.textContent = type === 'success' ? '✓' : type === 'error' ? '!' : 'i';
  toastTimer = setTimeout(hideToast, 3200);
}
function hideToast() {
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = 0;
  toast.className = '';
}
document.getElementById('toastClose').addEventListener('click', hideToast);

const installFolderBadge = document.getElementById('installFolderBadge');
const installFolderState = document.getElementById('installFolderState');
const linkInstallFolderBtn = document.getElementById('linkInstallFolder');
const unlinkInstallFolderBtn = document.getElementById('unlinkInstallFolder');
const localUpdateProgress = document.getElementById('localUpdateProgress');
const backgroundUpdatePanel = document.getElementById('backgroundUpdatePanel');
const backgroundUpdateTitle = document.getElementById('backgroundUpdateTitle');
const backgroundUpdateFill = document.getElementById('backgroundUpdateFill');
const backgroundUpdateStage = document.getElementById('backgroundUpdateStage');
const backgroundUpdateStep = document.getElementById('backgroundUpdateStep');
let backgroundUpdateActive = false;
let cachedInstallFolderStatus = null;
let cachedInstallFolderHandle = null;
const standaloneFolderMode = isStandaloneFolderContext
  ? String(popupQueryParams.get('mode') || 'link')
  : '';

const standaloneFolderPage = document.getElementById('standaloneFolderPage');
const standaloneFolderTitle = document.getElementById('standaloneFolderTitle');
const standaloneFolderCopy = document.getElementById('standaloneFolderCopy');
const standaloneFolderSelectBtn = document.getElementById('standaloneFolderSelect');
const standaloneFolderCancelBtn = document.getElementById('standaloneFolderCancel');
const standaloneFolderStatus = document.getElementById('standaloneFolderStatus');
function setStandaloneFolderStatus(text, type = '') {
  if (!standaloneFolderStatus) return;
  standaloneFolderStatus.textContent = text;
  standaloneFolderStatus.className = 'standalone-folder-status' + (type ? ` ${type}` : '');
}
function configureStandaloneFolderPage() {
  if (!standaloneFolderMode) return;
  document.documentElement.classList.add('standalone-folder-root');
  document.body.classList.add('standalone-folder');
  const relink = standaloneFolderMode === 'relink';
  if (standaloneFolderTitle) standaloneFolderTitle.textContent = relink ? 'Cambiar carpeta de VIENA NOC Tools' : 'Vincular carpeta de VIENA NOC Tools';
  if (standaloneFolderCopy) standaloneFolderCopy.textContent = relink
    ? 'Seleccioná nuevamente la carpeta correcta de esta instalación. La carpeta anterior dejará de usarse para futuras actualizaciones.'
    : 'Seleccioná la carpeta donde está instalada la extensión. Esta autorización permite aplicar futuras actualizaciones directamente sobre esa instalación.';
  if (standaloneFolderSelectBtn) standaloneFolderSelectBtn.textContent = relink ? 'Seleccionar nueva carpeta' : 'Seleccionar carpeta';
}
function folderPickerWasCancelled(error) {
  const name = String(error?.name || '');
  const message = String(error?.message || error || '');
  return name === 'AbortError' || /aborted a request|user aborted|cancel/i.test(message);
}
async function closeStandaloneFolderPage() {
  try { const tab = await chrome.tabs.getCurrent(); if (tab?.id) { await chrome.tabs.remove(tab.id); return; } } catch (_) {}
  try { window.close(); } catch (_) {}
}
async function performStandaloneFolderLink() {
  const updater = window.VienaLocalUpdater;
  if (!updater?.pickAndLink) throw new Error('El selector de carpeta no está disponible.');
  const recovery = await updater.getRecoveryStatus?.().catch(() => null);
  const recoveryStage = String(recovery?.journal?.stage || '');
  const hasRecoveryJournal = ['prepared','writing','verifying','rollback_incomplete','awaiting_reload'].includes(recoveryStage);
  const linked = await updater.pickAndLink({ requireRuntimeMatch: !hasRecoveryJournal });
  cachedInstallFolderHandle = linked?.handle || null;
  cachedInstallFolderStatus = null;
  setStandaloneFolderStatus('✓ Carpeta vinculada correctamente. Volviendo…', 'ok');
  if (hasRecoveryJournal) {
    try { await chrome.runtime.sendMessage({ type: 'VIENA_BACKGROUND_UPDATE_RESUME' }); } catch (_) {}
  }
  setTimeout(() => { void closeStandaloneFolderPage(); }, 500);
  return linked;
}
configureStandaloneFolderPage();
if (standaloneFolderSelectBtn) {
  standaloneFolderSelectBtn.addEventListener('click', async () => {
    standaloneFolderSelectBtn.disabled = true;
    setStandaloneFolderStatus('Esperando selección de carpeta…');
    try { await performStandaloneFolderLink(); }
    catch (error) {
      if (folderPickerWasCancelled(error)) setStandaloneFolderStatus('No se seleccionó ninguna carpeta. Podés volver a intentarlo.', 'warn');
      else setStandaloneFolderStatus(`No se pudo vincular la carpeta: ${String(error?.message || error)}`, 'error');
      standaloneFolderSelectBtn.disabled = false;
    }
  });
}
if (standaloneFolderCancelBtn) standaloneFolderCancelBtn.addEventListener('click', () => { void closeStandaloneFolderPage(); });


function renderBackgroundUpdateState(state) {
  const stage = String(state?.stage || '');
  const visible = Boolean(state && (state.active || ['completed','registry_pending','error'].includes(stage)));
  backgroundUpdateActive = Boolean(state?.active);
  if (backgroundUpdatePanel) backgroundUpdatePanel.classList.toggle('show', visible);
  if (!visible) return;

  const success = stage === 'completed';
  const registryPending = stage === 'registry_pending';
  const failed = stage === 'error';
  const step = Math.max(0, Math.min(5, Number(state.step || ((success || registryPending) ? 5 : 1))));
  let pct = step * 20;
  if (stage === 'applying' && Number(state.totalWrites) > 0) {
    pct = 60 + Math.round((Math.max(0, Number(state.writtenCount || 0)) / Number(state.totalWrites)) * 20);
  }
  if (success || registryPending) pct = 100;
  if (backgroundUpdateFill) backgroundUpdateFill.style.width = `${Math.max(0,Math.min(100,pct))}%`;
  if (backgroundUpdateTitle) backgroundUpdateTitle.textContent = failed ? 'Error al actualizar' : (success || registryPending) ? 'Actualización completada' : 'Actualización en curso…';
  if (backgroundUpdateStage) backgroundUpdateStage.textContent = failed ? String(state.error || 'No se pudo completar la actualización.') : String(state.label || 'Procesando actualización…');
  if (backgroundUpdateStep) backgroundUpdateStep.textContent = failed ? 'ERROR' : registryPending ? 'REGISTRO PENDIENTE' : `${success ? 5 : step} / 5`;

  if (openUpdateBtn) {
    openUpdateBtn.disabled = backgroundUpdateActive;
    if (backgroundUpdateActive) {
      openUpdateBtn.style.display = '';
      openUpdateBtn.textContent = 'Actualización en curso…';
    }
  }
  if (checkUpdateBtn) checkUpdateBtn.disabled = backgroundUpdateActive;
}

async function refreshBackgroundUpdateState() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'VIENA_BACKGROUND_UPDATE_GET' });
    if (result?.ok) renderBackgroundUpdateState(result.state);
  } catch (_) {}
}

function setLocalUpdateProgress(text = '', type = '') {
  if (!localUpdateProgress) return;
  localUpdateProgress.textContent = text;
  localUpdateProgress.className = 'update-progress' + (type ? ` ${type}` : '');
}

function popupPromiseTimeout(promise, ms, code = 'timeout') {
  let timer = 0;
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(code)), ms); })
  ]).finally(() => { if (timer) clearTimeout(timer); });
}

async function refreshInstallFolderUiNow() {
  const updater = window.VienaLocalUpdater;
  if (!updater?.supported()) {
    if (installFolderBadge) { installFolderBadge.textContent = 'No disponible'; installFolderBadge.className = 'release-tag'; }
    if (installFolderState) { installFolderState.textContent = 'Este Chrome no habilitó acceso a carpetas desde el popup.'; installFolderState.className = 'install-folder-state error'; }
    if (linkInstallFolderBtn) linkInstallFolderBtn.disabled = true;
    if (unlinkInstallFolderBtn) unlinkInstallFolderBtn.style.display = 'none';
    cachedInstallFolderStatus = { supported: false, linked: false }; return cachedInstallFolderStatus;
  }
  const status = await popupPromiseTimeout(updater.getLinkStatus(), 1800, 'folder_status_timeout');
  try { cachedInstallFolderHandle = await popupPromiseTimeout(updater.getStoredHandleForUi(), 1200, 'folder_handle_timeout'); }
  catch (_) { cachedInstallFolderHandle = null; }
  if (!status.linked) {
    if (installFolderBadge) { installFolderBadge.textContent = 'Sin vincular'; installFolderBadge.className = 'release-tag'; }
    if (installFolderState) { installFolderState.textContent = 'Vinculala una sola vez para que las actualizaciones puedan reemplazar los archivos de esta instalación.'; installFolderState.className = 'install-folder-state'; }
    if (linkInstallFolderBtn) { linkInstallFolderBtn.disabled = false; linkInstallFolderBtn.textContent = 'Vincular carpeta'; }
    if (unlinkInstallFolderBtn) unlinkInstallFolderBtn.style.display = 'none';
    cachedInstallFolderStatus = status;
    return status;
  }
  if (unlinkInstallFolderBtn) unlinkInstallFolderBtn.style.display = '';
  if (linkInstallFolderBtn) {
    linkInstallFolderBtn.disabled = false;
    linkInstallFolderBtn.textContent = status.permission === 'relink' ? 'Volver a vincular' : 'Cambiar carpeta';
  }
  // La carpeta vinculada y el permiso de escritura son estados distintos.
  // Si Chrome conserva el handle, el popup debe seguir mostrando VINCULADA
  // aunque queryPermission(readwrite) vuelva temporalmente a "prompt".
  // La autorización se solicita recién desde el click real de Actualizar.
  if (status.permission === 'relink') {
    if (installFolderBadge) { installFolderBadge.textContent = 'VINCULAR'; installFolderBadge.className = 'release-tag'; }
    if (installFolderState) { installFolderState.textContent = `${status.name || 'Carpeta'} quedó recordada, pero Chrome perdió el identificador de acceso. Volvé a vincularla una vez.`; installFolderState.className = 'install-folder-state warn'; }
    cachedInstallFolderStatus = status;
    return status;
  }
  if (status.identityVerified && !status.valid) {
    if (installFolderBadge) { installFolderBadge.textContent = 'Revisar'; installFolderBadge.className = 'release-tag'; }
    if (installFolderState) { installFolderState.textContent = status.error || 'La carpeta vinculada ya no parece una instalación válida.'; installFolderState.className = 'install-folder-state error'; }
    cachedInstallFolderStatus = status;
    return status;
  }
  if (installFolderBadge) { installFolderBadge.textContent = 'Vinculada'; installFolderBadge.className = 'release-tag current'; }
  if (installFolderState) {
    if (!status.identityVerified) {
      installFolderState.textContent = `${status.name || 'Carpeta vinculada'} · Vinculada · acceso guardado · se verificará al actualizar`;
      installFolderState.className = 'install-folder-state';
    } else {
      const identity = status.identity || {};
      const parts = [status.name || 'Carpeta vinculada'];
      if (identity.channel) parts.push(identity.channel);
      if (identity.version) parts.push(`v${identity.version}`);
      if (identity.build) parts.push(`build ${identity.build}`);
      installFolderState.textContent = parts.join(' · ');
      installFolderState.className = 'install-folder-state ok';
    }
  }
  cachedInstallFolderStatus = status;
  return status;
}

let installFolderRefreshInFlight = null;
async function refreshInstallFolderUi() {
  if (installFolderRefreshInFlight) return installFolderRefreshInFlight;
  const run = refreshInstallFolderUiNow().catch(error => {
    const message = String(error?.message || error || '');
    const fallback = cachedInstallFolderStatus || { supported: true, linked: false, pending: true };
    if (installFolderState) {
      installFolderState.textContent = /folder_(status|handle)_timeout/.test(message)
        ? 'La comprobación del vínculo tardó demasiado. Esto no bloquea el popup ni la búsqueda de actualizaciones.'
        : 'No se pudo comprobar el vínculo en este momento. Podés volver a intentarlo.';
      installFolderState.className = 'install-folder-state warn';
    }
    cachedInstallFolderStatus = fallback;
    return fallback;
  });
  installFolderRefreshInFlight = run;
  try {
    const status = await run;
    // Mantener el CTA sincronizado con la misma fuente que pinta el badge de carpeta.
    // Así no puede quedar "Vincular y actualizar" después de que la card ya muestra "Vinculada".
    if (updatePackageUrl && updatePackageSha256) await renderUpdateActionButton();
    return status;
  }
  finally { if (installFolderRefreshInFlight === run) installFolderRefreshInFlight = null; }
}

async function renderUpdateActionButton() {
  if (!openUpdateBtn) return;
  if (backgroundUpdateActive) {
    openUpdateBtn.style.display = '';
    openUpdateBtn.disabled = true;
    openUpdateBtn.textContent = 'Actualización en curso…';
    return;
  }
  if (updatePackageUrl && updatePackageSha256 && window.VienaLocalUpdater?.supported()) {
    const applyLabel = folder => {
      if (!openUpdateBtn || backgroundUpdateActive) return;
      openUpdateBtn.style.display = '';
      // FIX114: un estado de carpeta todavía no hidratado NO equivale a "sin vincular".
      // Sólo pedimos vincular cuando está confirmado que no hay handle, o Chrome lo perdió (relink).
      const mustLink = folder?.linked === false || folder?.permission === 'relink';
      if (updateTargetChannel === 'DEV') {
        const shortBuild = updateLatestBuild || `v${updateLatestVersion}`;
        openUpdateBtn.textContent = mustLink
          ? `Vincular y actualizar DEV`
          : `Actualizar DEV · ${shortBuild}`;
      } else {
        openUpdateBtn.textContent = mustLink
          ? `Vincular y actualizar a v${updateLatestVersion}`
          : `Actualizar a v${updateLatestVersion}`;
      }
    };
    // FIX107 CRITICAL: rendering an available update must be pure DOM work.
    // Do not touch File System Access / IndexedDB here. The folder is validated
    // only from the operator's explicit Actualizar click.
    applyLabel(cachedInstallFolderStatus);
    return;
  }
  if (validHttpsUrl(updateDownloadUrl)) {
    openUpdateBtn.style.display = '';
    openUpdateBtn.textContent = 'Descargar actualización';
  } else {
    openUpdateBtn.style.display = 'none';
  }
}

async function openFolderSetupPage(mode = 'link') {
  const url = chrome.runtime.getURL(`popup.html?standalone=1&mode=${encodeURIComponent(mode)}`);
  let current = null;
  try { current = await chrome.tabs.getCurrent(); } catch (_) {}
  if (!current?.id) {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      current = tabs[0] || null;
    } catch (_) {}
  }
  const options = { url, active: true };
  if (Number.isInteger(current?.index)) options.index = current.index + 1;
  await chrome.tabs.create(options);
}

async function ensureFolderReadyFromUserClick() {
  const updater = window.VienaLocalUpdater;
  if (!updater?.supported()) throw new Error('File System Access no está disponible en este Chrome.');

  // La reautorización se intenta directamente desde el click del operador.
  // No hacemos ningún await antes de requestPermission para no perder la
  // activación transitoria exigida por Chrome.
  const status = cachedInstallFolderStatus;
  const handle = cachedInstallFolderHandle;

  if (status?.linked && status.permission === 'granted' && status.valid) return status;

  if (status?.linked && status.permission !== 'granted' && status.permission !== 'relink' && handle) {
    await updater.authorizeStoredHandleFromGesture(handle);
    const refreshed = await refreshInstallFolderUi();
    if (refreshed?.linked && refreshed.permission === 'granted' && refreshed.valid) return refreshed;
    throw new Error('Chrome no dejó la carpeta lista para escritura.');
  }

  // Si nunca se seleccionó la carpeta o Chrome perdió el handle, hay que abrir
  // una página estable porque showDirectoryPicker puede cerrar el popup toolbar.
  await openFolderSetupPage(status?.linked ? 'relink' : 'link');
  throw new Error(status?.linked
    ? 'Chrome perdió el identificador de la carpeta. Volvé a seleccionarla una vez.'
    : 'Vinculá la carpeta una vez en la configuración que se abrió.');
}

async function runLocalChannelUpdate(button) {
  button.disabled = true;
  const originalText = button.textContent;
  setLocalUpdateProgress('Preparando actualización…', 'running');
  try {
    await ensureFolderReadyFromUserClick();

    const request = {
      packageUrl: updatePackageUrl,
      packageSha256: updatePackageSha256,
      expectedVersion: updateLatestVersion,
      expectedBuild: updateLatestBuild || '',
      expectedChannel: updateTargetChannel || (isDevRuntime() ? 'DEV' : 'RELEASE')
    };
    const accepted = await chrome.runtime.sendMessage({ type: 'VIENA_BACKGROUND_UPDATE_START', request });
    if (!accepted?.ok) throw new Error(accepted?.error || 'No se pudo iniciar la actualización en segundo plano.');

    backgroundUpdateActive = true;
    button.textContent = 'Actualización en curso…';
    button.disabled = true;
    setLocalUpdateProgress('Actualización iniciada. Podés cerrar este popup; el proceso continuará automáticamente.', 'running');
    await refreshBackgroundUpdateState();
  } catch (error) {
    backgroundUpdateActive = false;
    setLocalUpdateProgress(error?.name === 'AbortError' ? 'Selección de carpeta cancelada.' : String(error?.message || error), 'error');
    if (error?.name !== 'AbortError') showToast(`No se pudo iniciar la actualización: ${error?.message || 'error desconocido'}.`, 'error');
    button.textContent = originalText;
    button.disabled = false;
  }
}

async function fetchDevLocalUpdateManifest() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const url = `${VIENA_DEV_LOCAL_UPDATE_MANIFEST_URL}?_=${Date.now()}`;
    const response = await fetch(url, { cache: 'no-store', signal: controller.signal, headers: { 'Cache-Control': 'no-cache' } });
    if (!response.ok) throw new Error(`DEV manifest HTTP ${response.status}`);
    const data = await response.json();
    const packageUrl = String(data?.package_url || '');
    const packageSha256 = String(data?.package_sha256 || '').toLowerCase();
    if (!validHttpsUrl(packageUrl) || !/^[a-f0-9]{64}$/.test(packageSha256)) throw new Error('Canal DEV de actualización local inválido.');
    return {
      version: String(data?.version || ''),
      build: String(data?.build || ''),
      channel: String(data?.channel || '').toUpperCase(),
      packageUrl, packageSha256
    };
  } finally { clearTimeout(timer); }
}

if (linkInstallFolderBtn) {
  linkInstallFolderBtn.addEventListener('click', async () => {
    linkInstallFolderBtn.disabled = true;
    try {
      const status = cachedInstallFolderStatus;

      if (standaloneFolderMode) {
        await performStandaloneFolderLink();
        return;
      }

      // El popup toolbar abre una pestaña estable porque showDirectoryPicker
      // necesita sobrevivir al cierre automático del popup.
      await openFolderSetupPage(status?.linked ? 'relink' : 'link');
      setLocalUpdateProgress(status?.linked
        ? 'Se abrió la configuración para cambiar la carpeta vinculada.'
        : 'Se abrió la configuración inicial de carpeta. Esta selección se realiza una sola vez.', '');
    } catch (error) {
      if (standaloneFolderMode && folderPickerWasCancelled(error)) setStandaloneFolderStatus('No se seleccionó ninguna carpeta. Podés volver a intentarlo.', 'warn');
      else {
        setLocalUpdateProgress(String(error?.message || error), 'error');
        if (!standaloneFolderMode) showToast(`No se pudo autorizar la carpeta: ${error?.message || 'error desconocido'}.`, 'error');
      }
    } finally { linkInstallFolderBtn.disabled = false; }
  });
}

if (unlinkInstallFolderBtn) {
  unlinkInstallFolderBtn.addEventListener('click', async () => {
    const bg = await chrome.runtime.sendMessage({ type: 'VIENA_BACKGROUND_UPDATE_GET' }).catch(() => null);
    if (bg?.state?.active) {
      setLocalUpdateProgress('No se puede desvincular la carpeta mientras una actualización está en curso o recuperándose.', 'error');
      showToast('Esperá a que termine la actualización antes de desvincular la carpeta.', 'error');
      return;
    }
    await window.VienaLocalUpdater.unlink();
    cachedInstallFolderHandle = null;
    cachedInstallFolderStatus = null;
    setLocalUpdateProgress('Carpeta desvinculada.', '');
    await refreshInstallFolderUi();
    await renderUpdateActionButton();
  });
}

async function recoverInterruptedLocalUpdate() {
  const updater = window.VienaLocalUpdater;
  if (!updater?.getRecoveryStatus) return;
  try {
    await refreshBackgroundUpdateState();
    const recovery = await updater.getRecoveryStatus();
    const journal = recovery?.journal;
    if (!journal) return;
    if (['prepared','writing','verifying','rollback_incomplete','awaiting_reload'].includes(String(journal.stage || ''))) {
      setLocalUpdateProgress(`Actualización pendiente detectada (${journal.stage}). El motor en segundo plano está recuperando el proceso…`, 'running');
      try { await chrome.runtime.sendMessage({ type: 'VIENA_BACKGROUND_UPDATE_RESUME' }); } catch (_) {}
      await refreshBackgroundUpdateState();
    }
  } catch (error) {
    setLocalUpdateProgress(`Recuperación pendiente: ${String(error?.message || error)}`, 'error');
  }
}

if (!isStandaloneFolderContext) {
  // FIX102: first paint before any async/runtime work. Nothing below can block
  // Chrome from presenting the popup window.
  if (isDevRuntime() && checkUpdateBtn) checkUpdateBtn.textContent = 'Buscar actualización DEV';
  setTimeout(() => {
    void hydrateCachedDevUpdateState();
    void refreshInstallFolderUi();
    void refreshBackgroundUpdateState();
    void recoverInterruptedLocalUpdate();
  }, 120);
  // FIX116: comprobación silenciosa automática. La tarjeta deja de arrancar
  // permanentemente en DISPONIBLE "—"; si hay red, se actualiza sola.
  setTimeout(() => { void checkForUpdates({ manual: false }); }, 350);
  setInterval(() => { void refreshBackgroundUpdateState(); }, 1200);
  chrome.runtime.onMessage.addListener(msg => {
    if (msg?.type === 'VIENA_BACKGROUND_UPDATE_PROGRESS') renderBackgroundUpdateState(msg.state);
  });
  window.addEventListener('focus', () => {
    setTimeout(() => {
      void refreshInstallFolderUi();
    }, 80);
  });
}


async function refreshRegistrySyncStatus(force=false){
  const el=document.getElementById('registryStatus');
  const btn=document.getElementById('testRegistry');
  try{
    if(force){
      if(btn) btn.disabled=true;
      const hb=await chrome.runtime.sendMessage({type:'VIENA_INSTALL_REGISTRY_SYNC_NOW',reason:'popup'});
      if(!hb?.ok && !hb?.skipped) throw new Error(hb?.error||hb?.reason||'registro_fallido');
    }
    const st=await chrome.runtime.sendMessage({type:'VIENA_GET_INSTALL_REGISTRY_STATUS'});
    if(!st?.ok) throw new Error(st?.error||'status_failed');
    if(st.lastOk){
      const runtimeVersion=String(chrome.runtime.getManifest().version||'');
      let runtimeBuild='';
      try { runtimeBuild=String((await window.VienaLocalUpdater?.getRuntimeIdentity?.())?.build||''); } catch (_) {}
      const storedVersion=String(st.lastVersion||'');
      const storedBuild=String(st.lastBuild||'');
      const identityStale=(storedVersion && runtimeVersion && storedVersion!==runtimeVersion) || (storedBuild && runtimeBuild && storedBuild!==runtimeBuild);
      if(identityStale){
        el.textContent='Registro de instalación: sincronizando versión actual…';
        el.style.color='#72500e';
      }else{
        const mins=Math.max(0,Math.round((Date.now()-Number(st.lastOk))/60000));
        const who=st.lastUser||st.usuario||'sin usuario detectado';
        el.textContent=`Registro de instalación: OK · ${who} · hace ${mins} min · v${storedVersion||runtimeVersion}`;
        el.style.color='#1d6230';
      }
    }else if(st.lastError){
      const transient=String(st.lastError)==='timeout_temporal';
      el.textContent=transient?'Registro de instalación: reintentando automáticamente…':`Registro de instalación: error · ${st.lastError}`;
      el.style.color=transient?'#72500e':'#8d251d';
    }else{
      el.textContent='Registro de instalación: todavía sin registro confirmado.';
      el.style.color='#72500e';
    }
  }catch(e){
    if(el){const msg=String(e?.message||e);const transient=/timeout_temporal|aborted|abort/i.test(msg);el.textContent=transient?'Registro de instalación: reintentando automáticamente…':`Registro de instalación: error · ${msg}`;el.style.color=transient?'#72500e':'#8d251d';}
  }finally{if(btn) btn.disabled=false;}
}
const testRegistryBtn=document.getElementById('testRegistry');
if(testRegistryBtn) testRegistryBtn.addEventListener('click',async()=>{await refreshRegistrySyncStatus(true);});

function validSurname(value) {
  const v = String(value || '').trim();
  if (v.length < 2 || v.length > 50) return false;
  try { return /^[\p{L}\p{M}][\p{L}\p{M}'’.-]*(?:\s+[\p{L}\p{M}][\p{L}\p{M}'’.-]*)*$/u.test(v); }
  catch (_) { return /^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ'’.-]*(?:\s+[A-Za-zÁÉÍÓÚÜÑáéíóúüñ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ'’.-]*)*$/.test(v); }
}


async function refresh() {
  const local = await chrome.storage.local.get(['viena_usuario', 'viena_usuario_origen', ASSIGN_KEY]);
  let sync = {};
  try { sync = await chrome.storage.sync.get([ASSIGN_KEY]); } catch (_) {}

  userInput.value = local.viena_usuario || '';
  assignInput.value = String(local[ASSIGN_KEY] || sync[ASSIGN_KEY] || '').trim();

  const autoDetected = Boolean(local.viena_usuario && local.viena_usuario_origen === 'auto');
  userInput.readOnly = autoDetected;
  userInput.setAttribute('aria-readonly', autoDetected ? 'true' : 'false');
  const saveUserBtn = document.getElementById('saveUser');
  const userField = document.getElementById('vienaUserField');
  const userLabel = document.getElementById('userLabel');
  const userAutoPanel = document.getElementById('userAutoPanel');
  const userAutoValue = document.getElementById('userAutoValue');
  const userManualRow = document.getElementById('userManualRow');
  const userHint = document.getElementById('userHint');
  if (userField) userField.classList.toggle('auto-user', autoDetected);
  if (userLabel) userLabel.textContent = autoDetected ? '🔒 Usuario VIENA' : 'Usuario VIENA';
  if (userAutoPanel) userAutoPanel.hidden = !autoDetected;
  if (userAutoValue) userAutoValue.textContent = local.viena_usuario || '';
  if (userManualRow) { userManualRow.hidden = autoDetected; userManualRow.style.setProperty('display', autoDetected ? 'none' : '', autoDetected ? 'important' : ''); }
  if (userHint) {
    userHint.textContent = autoDetected
      ? ''
      : 'No pude detectarlo automáticamente. Ingresá tu propio usuario VIENA y guardalo.';
    userHint.style.display = autoDetected ? 'none' : '';
  }
  const brandVersionEl = document.querySelector('.header .version');
  if (brandVersionEl) { const channelLabel = isDevRuntime() ? 'DEV' : 'RELEASE'; brandVersionEl.textContent = `v${chrome.runtime.getManifest().version} ${channelLabel} · Manifest V3`; }
  if (saveUserBtn) {
    saveUserBtn.disabled = autoDetected;
    saveUserBtn.style.display = autoDetected ? 'none' : '';
    saveUserBtn.textContent = 'Guardar';
    saveUserBtn.title = 'Guardar Usuario VIENA manualmente';
  }
  if (local.viena_usuario) {
    userStatus.textContent = autoDetected
      ? 'Este usuario se obtiene de tu sesión de VIENA y no puede modificarse.'
      : 'Usuario VIENA configurado manualmente.';
  } else {
    userStatus.textContent = 'No pude detectar el usuario en VIENA. Ingresalo manualmente y guardalo.';
  }
  assignStatus.textContent = assignInput.value ? `Apellido configurado: ${assignInput.value}` : 'Falta configurar el apellido para las acciones de asignación.';
}

if (!isStandaloneFolderContext) {
  // FIX102: user/registry/update work starts only after the popup has painted.
  setTimeout(() => {
    void (async()=>{
      try { await chrome.runtime.sendMessage({type:'VIENA_DETECT_USER_NOW'}); } catch (_) {}
      try { await refresh(); } catch (_) {}
      try { await refreshRegistrySyncStatus(false); } catch (_) {}
      void chrome.runtime.sendMessage({type:'VIENA_INSTALL_REGISTRY_SYNC_NOW',reason:'popup_open'}).then(()=>setTimeout(()=>void refreshRegistrySyncStatus(false),1200)).catch(()=>{});
    })();
    // FIX105 CRITICAL: update checks are manual-only. Never start network/update discovery during popup boot.
  }, 180);
}

document.getElementById('saveUser').addEventListener('click', async () => {
  const state = await chrome.storage.local.get(['viena_usuario_origen']);
  if (state.viena_usuario_origen === 'auto') {
    showToast('El Usuario VIENA fue detectado automáticamente y está bloqueado.', 'warning');
    await refresh();
    return;
  }
  const v = userInput.value.trim().toLowerCase();
  if (!/^[a-z][a-z0-9._-]{2,30}$/i.test(v)) {
    showToast('Ingresá un usuario VIENA válido.', 'error');
    userInput.focus();
    return;
  }
  await chrome.storage.local.set({ viena_usuario: v, viena_usuario_origen: 'manual' });
  showToast('Usuario VIENA guardado.', 'success');
  await refresh();
});

document.getElementById('saveAssign').addEventListener('click', async () => {
  const v = assignInput.value.trim();
  if (!validSurname(v)) {
    showToast('Ingresá tu apellido, sin usuario de red ni números.', 'error');
    assignInput.focus();
    return;
  }
  await chrome.storage.local.set({ [ASSIGN_KEY]: v });
  try { await chrome.storage.sync.set({ [ASSIGN_KEY]: v }); } catch (_) {}
  showToast('Apellido para asignación guardado.', 'success');
  await refresh();
});


chrome.storage.onChanged.addListener((changes, area) => {
  if ((area === 'local' || area === 'sync') && (changes[ASSIGN_KEY] || changes.viena_usuario || changes.viena_usuario_origen)) void refresh();
});




const runtimePill = document.getElementById('runtimePill');
const runtimePillText = document.getElementById('runtimePillText');
const runtimeVersionText = document.getElementById('runtimeVersionText');
const runtimeAdvice = document.getElementById('runtimeAdvice');
const refreshRuntimeStatusBtn = document.getElementById('refreshRuntimeStatus');
const PLATFORM_LABELS = {
  viena: 'VIENA',
  miraStats: 'MIRA Estadísticas',
  miraCm: 'MIRA Listado de CMs',
  gpon: 'GPON',
  fuentes: 'Fuentes',
  moica2: 'MOICA2',
  grafana: 'Grafana',
  metricas: 'Métricas'
};


// Favicons reales de plataforma. Mantiene el mismo mapa canónico y el mismo
// backend VIENA_GET_FAVICON_BYTES usado por los botones operativos de VIENA.
const POPUP_PLATFORM_ICON_PAGES = Object.freeze({
  viena: 'https://viena.telecentro.net.ar/',
  miraStats: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
  miraCm: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
  gpon: 'https://monitoreogpon.telecentro.net.ar/#/listOnts',
  fuentes: 'https://fuentes.telecentro.net.ar/webs/home.php',
  moica2: 'https://moica2.telecentro.net.ar/buscarTicket.php',
  grafana: 'https://grafana-telemetria.telecentro.net.ar/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e?orgId=1',
  metricas: 'https://metricas-gdt.telecentro.net.ar/nodos/home.php'
});
const POPUP_FAVICON_CACHE = new Map();
async function popupFaviconBlob(pageUrl) {
  if (!pageUrl || !chrome?.runtime?.sendMessage) return null;
  if (POPUP_FAVICON_CACHE.has(pageUrl)) return POPUP_FAVICON_CACHE.get(pageUrl);
  const request = (async () => {
    try {
      const result = await chrome.runtime.sendMessage({ type: 'VIENA_GET_FAVICON_BYTES', pageUrl });
      if (!result?.ok || !Array.isArray(result.bytes) || !result.bytes.length) return null;
      return new Blob([new Uint8Array(result.bytes)], { type: result.mime || 'image/png' });
    } catch (_) { return null; }
  })();
  POPUP_FAVICON_CACHE.set(pageUrl, request);
  return request;
}
async function renderPopupFavicon(canvas, pageUrl) {
  try {
    const blob = await popupFaviconBlob(pageUrl);
    if (!blob || !canvas?.isConnected) return false;
    const bitmap = await createImageBitmap(blob);
    if (!canvas.isConnected) { try { bitmap.close(); } catch (_) {} return false; }
    canvas.width = 16;
    canvas.height = 16;
    const ctx = canvas.getContext('2d');
    if (!ctx) return false;
    ctx.clearRect(0, 0, 16, 16);
    ctx.drawImage(bitmap, 0, 0, 16, 16);
    try { bitmap.close(); } catch (_) {}
    canvas.dataset.vienaIconReady = '1';
    return true;
  } catch (_) { return false; }
}
function renderPopupPlatformFavicons() {
  document.querySelectorAll('canvas.viena-platform-icon[data-platform]').forEach(canvas => {
    const pageUrl = POPUP_PLATFORM_ICON_PAGES[canvas.dataset.platform];
    if (pageUrl) void renderPopupFavicon(canvas, pageUrl);
  });
}
renderPopupPlatformFavicons();

const openFullViewBtn = document.getElementById('openFullView');
if (openFullViewBtn) {
  openFullViewBtn.addEventListener('click', async () => {
    try {
      // Abre la vista completa dedicada de VIENA NOC Tools.
      await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?full=1#general') });
    } catch (error) {
      showToast(String(error?.message || error || 'No se pudo abrir la vista en pestaña.'), 'error');
    }
  });
}

function setRuntimePill(text, type = 'ok') {
  if (!runtimePill || !runtimePillText) return;
  runtimePillText.textContent = text;
  runtimePill.className = 'runtime-pill' + (type === 'warn' ? ' warn' : type === 'error' ? ' error' : '');
}

function setRuntimeAdvice(text = '', type = 'warn') {
  if (!runtimeAdvice) return;
  runtimeAdvice.textContent = text;
  runtimeAdvice.className = text ? `runtime-advice show ${type}` : 'runtime-advice';
}

async function runPlatformAction(key, action, button) {
  const label = PLATFORM_LABELS[key] || key;
  if (button) button.disabled = true;
  try {
    const result = await chrome.runtime.sendMessage({ type: 'VIENA_PLATFORM_ACTION', platform: key, action, background: true });
    if (!result?.ok) throw new Error(result?.detail || result?.code || 'No se pudo completar la acción.');
    showToast(action === 'open' ? `${label} abierto.` : `${label}: pestaña primaria recargada.`, 'success');
    await refreshRuntimeStatus();
  } catch (error) {
    showToast(`${label}: ${String(error?.message || error || 'error desconocido')}`, 'error');
  } finally {
    if (button?.isConnected) button.disabled = false;
  }
}

function renderPlatformState(key, state) {
  const el = document.getElementById(`st-${key}`);
  if (!el) return;
  el.replaceChildren();
  if (!state?.open) {
    el.className = 'platform-state closed';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'platform-action open';
    button.textContent = 'Abrir';
    button.title = `Abrir ${PLATFORM_LABELS[key] || key}`;
    button.addEventListener('click', () => void runPlatformAction(key, 'open', button));
    el.appendChild(button);
    return;
  }
  if (state.loading) {
    el.className = 'platform-state';
    el.textContent = 'Cargando…';
    return;
  }
  if (state.needsReload) {
    el.className = 'platform-state reload';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'platform-action reload';
    button.textContent = 'Recargar';
    button.title = `Recargar la pestaña primaria de ${PLATFORM_LABELS[key] || key}`;
    button.addEventListener('click', () => void runPlatformAction(key, 'reload', button));
    el.appendChild(button);
    return;
  }
  el.textContent = state.tabs > 1 ? `Abierto (${state.tabs})` : 'Abierto';
  el.className = 'platform-state';
}

const VIENA_RUNTIME_STATUS_TIMEOUT_MS = 5000;

async function getOperationalStatusWithTimeout() {
  let timer = 0;
  try {
    return await Promise.race([
      chrome.runtime.sendMessage({ type: 'VIENA_GET_OPERATIONAL_STATUS' }),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Tiempo de espera agotado al comprobar el estado.')), VIENA_RUNTIME_STATUS_TIMEOUT_MS); })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function refreshRuntimeStatus({manual = false} = {}) {
  if (refreshRuntimeStatusBtn) refreshRuntimeStatusBtn.disabled = true;
  try {
    const result = await getOperationalStatusWithTimeout();
    if (!result?.ok) throw new Error(result?.detail || 'No se pudo consultar el estado.');
    const platforms = result.platforms || {};
    Object.keys(PLATFORM_LABELS).forEach(key => renderPlatformState(key, platforms[key]));
    if (runtimeVersionText) runtimeVersionText.textContent = `Runtime v${result.runtimeVersion} · build ${result.runtimeBuild}`;

    if (result.extensionNeedsReload) {
      runtimeBadgeState = 'RLD';
      renderCurrentBadgeHelp();
      setRuntimePill('Recargar extensión', 'error');
      setRuntimeAdvice('Detecté archivos de una build nueva. La extensión hará dos comprobaciones de estabilidad antes de recargarse sola. Si el estado persiste, recargala manualmente y después recargá las pestañas operativas marcadas.', 'error');
      if (manual) showToast('La extensión necesita recargarse en Chrome.', 'error');
      return;
    }

    const stale = Object.entries(platforms).filter(([,v]) => v?.open && v?.needsReload).map(([k]) => PLATFORM_LABELS[k] || k);
    if (stale.length) {
      runtimeBadgeState = 'TAB';
      renderCurrentBadgeHelp();
      setRuntimePill('Páginas desactualizadas', 'warn');
      setRuntimeAdvice(`Tocá “Recargar” en estas plataformas para cargar la versión actual en su pestaña primaria: ${stale.join(', ')}.`, 'warn');
      if (manual) showToast('Hay pestañas que necesitan recarga.', 'warning');
      return;
    }

    runtimeBadgeState = 'ON';
    renderCurrentBadgeHelp();
    setRuntimePill('Activa', 'ok');
    setRuntimeAdvice('');
    if (manual) showToast('Extensión y pestañas abiertas sincronizadas.', 'success');
  } catch (error) {
    runtimeBadgeState = 'CHECKING';
    renderCurrentBadgeHelp();
    setRuntimePill('Sin respuesta', 'error');
    setRuntimeAdvice(`No pude verificar el runtime: ${String(error?.message || error || 'error desconocido')}`, 'error');
    if (manual) showToast('No se pudo actualizar el estado.', 'error');
  } finally {
    if (refreshRuntimeStatusBtn) refreshRuntimeStatusBtn.disabled = false;
  }
}

if (refreshRuntimeStatusBtn) refreshRuntimeStatusBtn.addEventListener('click', () => void refreshRuntimeStatus({manual:true}));
if (!isStandaloneFolderContext) void refreshRuntimeStatus();


// Estado operativo en tiempo real mientras el popup permanece abierto.
// Abrir/Recargar desde el panel no activa la pestaña destino, por lo que el
// popup conserva el foco. Los eventos de tabs refrescan el estado sin exigir
// tocar manualmente "Actualizar estado".
let runtimeRefreshTimer = 0;
function scheduleRuntimeStatusRefresh(delay = 120) {
  if (runtimeRefreshTimer) clearTimeout(runtimeRefreshTimer);
  runtimeRefreshTimer = setTimeout(() => { runtimeRefreshTimer = 0; void refreshRuntimeStatus(); }, delay);
}
if (!isStandaloneFolderContext && chrome?.tabs) {
  chrome.tabs.onCreated.addListener(() => scheduleRuntimeStatusRefresh(120));
  chrome.tabs.onUpdated.addListener((_tabId, changeInfo) => {
    if (changeInfo.status || changeInfo.url) scheduleRuntimeStatusRefresh(changeInfo.status === 'complete' ? 80 : 140);
  });
  chrome.tabs.onRemoved.addListener(() => scheduleRuntimeStatusRefresh(80));
  chrome.tabs.onActivated.addListener(() => scheduleRuntimeStatusRefresh(80));
}


// Botones y plantillas: abrir la nueva vista completa directamente en Personalización.
const openButtonEditorBtn = document.getElementById('openButtonEditor');
const buttonEditorStatusEl = document.getElementById('buttonEditorStatus');
if (openButtonEditorBtn) {
  openButtonEditorBtn.addEventListener('click', async () => {
    openButtonEditorBtn.disabled = true;
    if (buttonEditorStatusEl) buttonEditorStatusEl.textContent = 'Abriendo editor…';
    try {
      const targetUrl = chrome.runtime.getURL('popup.html?full=1#personalization');
      const extensionPrefix = chrome.runtime.getURL('popup.html?full=1');
      const tabs = await chrome.tabs.query({});
      const existing = tabs.find(tab => tab?.id && String(tab.url || '').startsWith(extensionPrefix));
      if (existing?.id) {
        await chrome.tabs.update(existing.id, { active: true, url: targetUrl });
        if (existing.windowId != null) {
          try { await chrome.windows.update(existing.windowId, { focused: true }); } catch (_) {}
        }
      } else {
        let current = null;
        try {
          const active = await chrome.tabs.query({ active: true, currentWindow: true });
          current = active[0] || null;
        } catch (_) {}
        const options = { url: targetUrl, active: true };
        if (Number.isInteger(current?.index)) options.index = current.index + 1;
        await chrome.tabs.create(options);
      }
      if (buttonEditorStatusEl) buttonEditorStatusEl.textContent = '';
      window.close();
    } catch (error) {
      const msg = String(error?.message || error || 'No se pudo abrir el editor.');
      if (buttonEditorStatusEl) buttonEditorStatusEl.textContent = msg;
      showToast(msg, 'error');
      openButtonEditorBtn.disabled = false;
    }
  });
}


}


// VIENA_UPDATE_BUTTON_LABEL_FIX93
(() => {
  const normalize = () => {
    const btn = document.getElementById('openUpdate');
    if (!btn) return;
    const text = String(btn.textContent || '').replace(/\s+/g,' ').trim();
    if (!/^Actualizar DEV\b/i.test(text)) return;
    const match = text.match(/\b(\d+\.\d+\.\d+)\b/);
    const normalized = match ? 'Actualizar DEV · ' + match[1] : 'Actualizar DEV';
    if (btn.textContent !== normalized) btn.textContent = normalized;
  };
  const target = document.getElementById('openUpdate');
  if (target) {
    new MutationObserver(normalize).observe(target,{childList:true,subtree:true,characterData:true});
    normalize();
  }
})();
