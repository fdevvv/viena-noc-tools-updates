(function(){
'use strict';
if(window.__VIENA_MOICA_HOME_NAV__) return;
window.__VIENA_MOICA_HOME_NAV__=true;

const BUSCAR_PATH='/buscarTicket.php';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitFor(fn,timeout=12000,step=100){
  const start=Date.now();
  while(Date.now()-start<timeout){
    const value=fn();
    if(value) return value;
    await sleep(step);
  }
  return null;
}
function click(el){
  if(!el) return false;
  el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));
  el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));
  el.click();
  return true;
}

chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg?.type!=='VIENA_MOICA_NAVIGATE') return;
  (async()=>{
    if(location.pathname.includes(BUSCAR_PATH)) return {ok:true,already:true};
    const link=await waitFor(()=>{
      return document.querySelector('a[href="/buscarTicket.php"], a[href$="/buscarTicket.php"], a[href*="buscarTicket.php"]');
    },12000,100);
    if(!link) return {ok:false,code:'buscar_link_not_found'};
    click(link);
    return {ok:true,navigated:true};
  })().then(sendResponse).catch(error=>sendResponse({ok:false,code:'error',detail:String(error?.message||error)}));
  return true;
});
})();
