(() => {
  'use strict';
  if (globalThis.__VIENA_GM_SHIM__) return;
  globalThis.__VIENA_GM_SHIM__ = true;

  let nextListenerId = 1;
  const listeners = new Map();

  globalThis.GM_getValue = async function(key, defaultValue = undefined) {
    const result = await chrome.storage.local.get(key);
    return Object.prototype.hasOwnProperty.call(result, key) ? result[key] : defaultValue;
  };

  globalThis.GM_setValue = async function(key, value) {
    await chrome.storage.local.set({ [key]: value });
  };

  globalThis.GM_addValueChangeListener = function(key, callback) {
    const id = nextListenerId++;
    const handler = (changes, areaName) => {
      if (areaName !== 'local' || !changes[key]) return;
      const change = changes[key];
      try {
        callback(key, change.oldValue, change.newValue, true);
      } catch (error) {
        console.error('[VIENA NOC Tools] storage listener error:', error);
      }
    };
    listeners.set(id, handler);
    chrome.storage.onChanged.addListener(handler);
    return id;
  };

  globalThis.GM_removeValueChangeListener = function(id) {
    const handler = listeners.get(id);
    if (!handler) return false;
    chrome.storage.onChanged.removeListener(handler);
    listeners.delete(id);
    return true;
  };

  // All extension content scripts share this isolated world. The legacy
  // userscripts can therefore use unsafeWindow as their shared bridge object
  // without exposing extension APIs to the page itself.
  globalThis.unsafeWindow = globalThis;
})();
