(function () {
    'use strict';

    // ------------------------------------------------------------------
    // CONFIGURACIÓN
    // ------------------------------------------------------------------

    const PLANTILLAS = [

        {
            nombre: 'INGRESS OK',
            estado: 'COMPLETADA',
            motivo: 'Se observa servicio con parametros de servicio OK',
            mensaje: 'Se verifica niveles de ingress en el nodo dentro de los parametros aceptables.'
        },

        {
            nombre: 'CONTINUA AFECT',
            estado: 'COMPLETADA',
            motivo: 'Falla de red identificada – Se crea tarea de campo',
            mensaje: 'Se genera nueva tarea, ya que se observa que luego de los trabajos realizados la afectacion persiste.'
        },

        {
            nombre: 'NIVELES RET/DR',
            estado: 'COMPLETADA',
            motivo: 'Sin falla detectada - Listo para cierre.',
            mensaje: 'Se verifica niveles en el nodo dentro de los parametros aceptables.'
        },

        {
            nombre: 'NODO UP SIN P',
            estado: 'COMPLETADA',
            motivo: 'Sin falla de red detectada',
            mensaje: 'Se verifica nodo operativo, sin patron de red alguno para la generacion de tarea correctiva de red.'
        },

        {
            nombre: 'TRANSPONDER UP',
            estado: 'COMPLETADA',
            motivo: 'Se observa servicio con parametros de servicio OK',
            mensaje: 'Se verifica transponder operativo.'
        },

        {
            nombre: 'CLIENT OK',
            estado: 'COMPLETADA',
            motivo: 'Se observa servicio con parametros de servicio OK',
            mensaje: 'Se verifica cliente operativo y en parametros, sin patron de falla.'
        },

        {
            nombre: 'CLIENT FTTH SERVICE',
            estado: 'COMPLETADA',
            motivo: 'Se observa servicio con parametros de servicio OK',
            mensaje: 'Se verifica niveles operativos y caja sin patron de falla. Derivar cliente a service.'
        },

        {
            nombre: 'CLI UNICO AFECT',
            estado: 'COMPLETADA',
            motivo: 'Se observa servicio con parametros de servicio OK',
            mensaje: 'Se verifica que el cliente es el unico afectado. Favor de derivar a service y pactar visita tecnica para revisar la instalacion del mismo.'
        },

        {
            nombre: 'EVENTO ENERGIA',
            estado: 'COMPLETADA',
            motivo: 'Posible Corte de luz en clientes',
            mensaje: 'Posible evento de energia, se mantiene en monitoria.'
        },

        {
            nombre: 'EVENTO ENERGIA FTTH',
            estado: 'COMPLETADA',
            motivoContiene: ['dying-gasp', 'dying gasp'],
            mensaje: 'Posible evento de energia, se mantiene en monitoria.'
        },

        {
            nombre: 'EDIFICIO OK',
            estado: 'COMPLETADA',
            motivo: 'Sin falla de red detectada',
            mensaje: 'Edificio UP, en parametros y sin patron de falla.'
        }

    ];


    // ------------------------------------------------------------------
    // HELPERS
    // ------------------------------------------------------------------

    function esVisible(el) {
        return !!(el && el.offsetParent !== null);
    }


    function obtenerHostToastSeguro() {
        // Los v-dialog persistent de Vuetify animan/escalean cuando reciben un click
        // "afuera". Un toast agregado a document.body cuenta como click externo.
        // Montarlo dentro del dialog activo de mayor z-index evita ese mini-zoom.
        const activos = Array.from(document.querySelectorAll('.v-dialog__content.v-dialog__content--active'))
            .map(content => ({
                content,
                dialog: content.querySelector('.v-dialog.v-dialog--active')
            }))
            .filter(({dialog}) => dialog && dialog.isConnected && getComputedStyle(dialog).display !== 'none')
            .sort((a, b) => {
                const za = Number.parseInt(getComputedStyle(a.content).zIndex || '0', 10) || 0;
                const zb = Number.parseInt(getComputedStyle(b.content).zIndex || '0', 10) || 0;
                return za - zb;
            });
        return activos.length ? activos[activos.length - 1].dialog : document.body;
    }

    function mostrarToastPlantillas(mensaje, tipo = 'error') {
        const ID = 'viena-templates-toast';
        document.getElementById(ID)?.remove();
        const palette = tipo === 'success'
            ? { accent:'#2e7d32', icon:'✓' }
            : { accent:'#c62828', icon:'!' };
        const toast = document.createElement('div');
        toast.id = ID;
        toast.setAttribute('role', tipo === 'error' ? 'alert' : 'status');
        toast.setAttribute('aria-live', tipo === 'error' ? 'assertive' : 'polite');
        Object.assign(toast.style, {
            position:'fixed', top:'18px', right:'18px', zIndex:'2147483647',
            width:'min(440px, calc(100vw - 32px))', background:'#fff', color:'#1f2937',
            border:'1px solid #d7e0ea', borderLeft:`5px solid ${palette.accent}`, borderRadius:'10px',
            boxShadow:'0 12px 34px rgba(15,35,60,.24)', fontFamily:'Arial, sans-serif',
            display:'flex', alignItems:'flex-start', gap:'11px', padding:'13px 14px', opacity:'0',
            transform:'translateY(-8px)', transition:'opacity .16s ease, transform .16s ease'
        });
        const icon = document.createElement('div');
        icon.textContent = palette.icon;
        Object.assign(icon.style, {width:'28px',height:'28px',minWidth:'28px',borderRadius:'50%',background:palette.accent,color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'17px',fontWeight:'800'});
        const content = document.createElement('div'); content.style.flex='1';
        const title = document.createElement('div'); title.textContent='VIENA NOC Tools';
        Object.assign(title.style, {fontSize:'13px',fontWeight:'800',color:'#183b63',marginBottom:'2px'});
        const body = document.createElement('div'); body.textContent=String(mensaje || '');
        Object.assign(body.style, {fontSize:'14px',fontWeight:'600',lineHeight:'1.4'});
        content.append(title, body);
        const close = document.createElement('button'); close.type='button'; close.textContent='×'; close.setAttribute('aria-label','Cerrar notificación');
        Object.assign(close.style, {border:'0',background:'transparent',color:'#64748b',fontSize:'21px',lineHeight:'1',padding:'0 2px',cursor:'pointer'});
        toast.append(icon, content, close);
        const toastHost = obtenerHostToastSeguro();
        toast.dataset.vienaToastHost = toastHost === document.body ? 'body' : 'active-dialog';
        toastHost.appendChild(toast);
        let timer=0;
        const remove=()=>{ if(!toast.isConnected)return; if(timer)clearTimeout(timer); toast.style.opacity='0'; toast.style.transform='translateY(-8px)'; setTimeout(()=>toast.remove(),180); };
        close.tabIndex = -1;
        close.addEventListener('pointerdown', event => { event.preventDefault(); event.stopPropagation(); }, true);
        close.addEventListener('mousedown', event => { event.preventDefault(); event.stopPropagation(); }, true);
        close.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); remove(); });
        toast.addEventListener('click', event => event.stopPropagation());
        requestAnimationFrame(()=>{toast.style.opacity='1';toast.style.transform='translateY(0)';});
        timer=setTimeout(remove,5200);
    }


    function esperarPorTexto(selector, texto, exacto = true, timeout = 6000) {

        return new Promise((resolve, reject) => {

            const inicio = Date.now();

            const buscar = () => {

                const candidatos =
                    Array.from(
                        document.querySelectorAll(selector)
                    ).filter(esVisible);

                const encontrado =
                    candidatos.find(el => {

                        const t =
                            el.textContent
                                .trim()
                                .toLowerCase();

                        return exacto
                            ? t === texto.trim().toLowerCase()
                            : t.includes(texto.trim().toLowerCase());
                    });

                if (encontrado) {
                    return resolve(encontrado);
                }

                if (Date.now() - inicio > timeout) {

                    return reject(
                        new Error(
                            `No se encontró: "${texto}"`
                        )
                    );
                }

                setTimeout(buscar, 150);
            };

            buscar();
        });
    }


    function esperarCondicion(fn, timeout = 6000) {

        return new Promise((resolve, reject) => {

            const inicio = Date.now();

            const chequear = () => {

                const resultado = fn();

                if (resultado) {
                    return resolve(resultado);
                }

                if (Date.now() - inicio > timeout) {

                    return reject(
                        new Error(
                            'Timeout esperando condición'
                        )
                    );
                }

                setTimeout(chequear, 150);
            };

            chequear();
        });
    }


    function setValorReactivo(elemento, valor) {
        if (!elemento) return;
        if (elemento.isContentEditable) {
            elemento.textContent = valor;
        } else {
            const proto = Object.getPrototypeOf(elemento);
            const descriptor = Object.getOwnPropertyDescriptor(proto, 'value') ||
                Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value') ||
                Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
            if (descriptor?.set) descriptor.set.call(elemento, valor);
            else elemento.value = valor;
        }
        elemento.dispatchEvent(new Event('input', {bubbles:true}));
        elemento.dispatchEvent(new Event('change', {bubbles:true}));
    }



    function pausa(ms) {

        return new Promise(
            resolve =>
                setTimeout(resolve, ms)
        );
    }


    // ------------------------------------------------------------------
    // FIX DEL ZOOM
    // ------------------------------------------------------------------
    //
    // Este es el mismo fix que funcionó en consola:
    //
    // .v-dialog.v-dialog--active.v-dialog--persistent {
    //     transform: none !important;
    //     transition: none !important;
    //     animation: none !important;
    // }
    //
    // PERO:
    //
    // No lo dejamos activo permanentemente.
    //
    // Solo se aplica cuando vos ya tenés el ticket abierto
    // y presionás el botón "Completar Tarea".
    //
    // De esta manera no interviene durante el render inicial
    // del diálogo de VIENA.
    // ------------------------------------------------------------------

    function activarFixZoomTemporal() {

        const anterior =
            document.getElementById(
                'viena-fix-zoom-temporal'
            );

        if (anterior) {
            anterior.remove();
        }

        const style =
            document.createElement('style');

        style.id =
            'viena-fix-zoom-temporal';

        style.textContent = `

            /* No tocamos transform del diálogo principal.
               Forzarlo a none era lo que podía producir el salto/zoom. */
            .v-dialog.v-dialog--active.v-dialog--persistent,
            .v-dialog.v-dialog--active.v-dialog--persistent *,
            .v-menu__content,
            .v-menu__content * {

                transition: none !important;
                animation: none !important;
            }

            #panel-plantillas-viena,
            #panel-plantillas-viena * {

                transform: none !important;
                transition: none !important;
                animation: none !important;
            }

        `;

        document.head.appendChild(style);

        setTimeout(() => {
            if (style.isConnected) {
                style.remove();
            }
        }, 1800);
    }



    // ------------------------------------------------------------------
    // SELECTORES ROBUSTOS VIENA / VUETIFY
    // ------------------------------------------------------------------

    function normalizarTexto(valor) {
        return String(valor || '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();
    }

    function normalizarMotivo(valor) {
        // Los textos de VIENA y los guardados pueden diferir en caracteres Unicode
        // visualmente idénticos (guiones, NBSP, zero-width, normalización NFKC).
        // Canonicalizamos sólo para comparar motivos; no modifica el texto guardado
        // ni hace coincidencias parciales que puedan seleccionar otro motivo.
        return String(valor || '')
            .normalize('NFKC')
            .replace(/[\u200B-\u200D\uFEFF]/g, '')
            .replace(/\u00A0/g, ' ')
            .replace(/[‐‑‒–—−]/g, '-')
            .replace(/\s*-\s*/g, ' - ')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();
    }

    function encontrarInputPorLabel(fragmentos) {

        const buscados =
            fragmentos.map(normalizarTexto);

        const labels =
            Array.from(
                document.querySelectorAll('label')
            ).filter(esVisible);

        for (const label of labels) {

            const texto =
                normalizarTexto(
                    label.textContent
                );

            if (
                !buscados.some(
                    buscado =>
                        texto === buscado ||
                        texto.includes(buscado)
                )
            ) {
                continue;
            }

            const contenedor =
                label.closest('.v-input');

            if (
                contenedor &&
                esVisible(contenedor)
            ) {
                return contenedor;
            }
        }

        return null;
    }

    async function esperarInputPorLabel(
        fragmentos,
        timeout = 2500
    ) {

        return esperarCondicion(
            () =>
                encontrarInputPorLabel(
                    fragmentos
                ),
            timeout
        );
    }

    async function seleccionarItemVisible(
        texto,
        timeout = 2500
    ) {

        const buscado =
            normalizarTexto(texto);

        return esperarCondicion(() => {

            const items =
                Array.from(
                    document.querySelectorAll(
                        '.v-list-item__title, .v-list-item'
                    )
                ).filter(esVisible);

            const encontrado =
                items.find(el =>
                    normalizarTexto(
                        el.textContent
                    ) === buscado
                );

            if (!encontrado) {
                return null;
            }

            return (
                encontrado.closest('.v-list-item') ||
                encontrado
            );

        }, timeout);
    }

    async function seleccionarItemVisibleQueContenga(textos, timeout = 3500) {
        const variantes = (Array.isArray(textos) ? textos : [textos])
            .map(normalizarTexto)
            .map(t => t.replace(/[‐‑‒–—-]+/g, ' ').replace(/\s+/g, ' ').trim());

        return esperarCondicion(() => {
            const items = Array.from(
                document.querySelectorAll('.v-list-item__title, .v-list-item')
            ).filter(esVisible);

            const encontrado = items.find(el => {
                const texto = normalizarTexto(el.textContent)
                    .replace(/[‐‑‒–—-]+/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim();
                return variantes.some(v => texto.includes(v));
            });

            return encontrado
                ? (encontrado.closest('.v-list-item') || encontrado)
                : null;
        }, timeout);
    }


    const MOTIVO_OVERRIDES_KEY = 'viena_motivo_overrides_v1';
    const MOTIVO_CONTEXTOS_KEY = 'viena_motivo_contextos_v2';
    const MENSAJE_OVERRIDES_KEY = 'viena_template_message_overrides_v1';
    const CUSTOM_TEMPLATES_KEY = 'viena_custom_templates_v1';
    const CUSTOM_TEMPLATE_GROUPS_KEY = 'viena_custom_template_groups_v1';
    const SYSTEM_COMPLETE_CONFIG_KEY = 'viena_system_complete_config_v1';
    const USUARIO_KEY = 'viena_usuario';
    const MENSAJE_SITE_STORAGE_KEY = 'viena_template_message_overrides_v1__dev';
    const MENSAJE_SITE_USER_KEY = 'viena_template_message_user_v1__dev';
    const CUSTOM_TEMPLATES_SITE_KEY = 'viena_custom_templates_v1__dev';
    const CUSTOM_TEMPLATE_GROUPS_SITE_KEY = 'viena_custom_template_groups_v1__dev';
    const SYSTEM_COMPLETE_CONFIG_SITE_KEY = 'viena_system_complete_config_v1__dev';
    const RELEASE_CUSTOM_TEMPLATE_GROUPS_SITE_KEY = 'viena_custom_template_groups_v1';
    const DEV_GROUPS_IMPORT_MARKER = 'viena_dev_release_groups_import_v1';

    let mensajeOverridesCache = {};
    let usuarioPlantillasCache = '';
    let mensajesCacheListo = false;
    let customTemplatesCache = {};
    let customTemplatesCacheListo = false;
    let customTemplateGroupsCache = {};
    let customTemplateGroupsCacheListo = false;
    let systemCompleteConfigCache = {};
    let systemCompleteConfigCacheListo = false;
    let mostrarEditorPlantillaGlobal = null;
    let ocultarEditorPlantillaGlobal = null;

    function clavePlantilla(plantilla) {
        const id = String(plantilla?.id || '').trim();
        if (id) return '@custom:' + id;
        return String(plantilla?.nombre || '').trim();
    }

    function storageAreaGet(area, key) {
        return new Promise(resolve => {
            try {
                area.get([key], data => {
                    const err = chrome.runtime?.lastError;
                    if (err) {
                        console.warn('[VIENA Plantillas] Storage read:', err.message);
                        resolve({});
                        return;
                    }
                    resolve(data?.[key] || {});
                });
            } catch (_) {
                resolve({});
            }
        });
    }

    function storageAreaSet(area, key, value) {
        return new Promise(resolve => {
            try {
                area.set({ [key]: value }, () => {
                    const err = chrome.runtime?.lastError;
                    if (err) console.warn('[VIENA Plantillas] Storage write:', err.message);
                    resolve(!err);
                });
            } catch (_) {
                resolve(false);
            }
        });
    }

    function normalizarClaveUsuario(valor) {
        return String(valor || '').trim().toLowerCase() || '__sin_usuario__';
    }

    async function cargarMensajesPersonalizados() {
        try {
            const [usuarioData, syncMap, localMap] = await Promise.all([
                storageAreaGet(chrome.storage.local, USUARIO_KEY),
                storageAreaGet(chrome.storage.sync, MENSAJE_OVERRIDES_KEY),
                storageAreaGet(chrome.storage.local, MENSAJE_OVERRIDES_KEY)
            ]);
            let siteMap = {};
            try {
                const raw = localStorage.getItem(MENSAJE_SITE_STORAGE_KEY);
                const parsed = raw ? JSON.parse(raw) : {};
                if (parsed && typeof parsed === 'object') siteMap = parsed;
            } catch (_) {}

            // storageAreaGet devuelve el valor directo; para una clave string el
            // resultado puede ser string, y para los overrides debe ser objeto.
            let usuarioPersistidoSitio = '';
            try {
                usuarioPersistidoSitio = String(localStorage.getItem(MENSAJE_SITE_USER_KEY) || '').trim();
            } catch (_) {}

            usuarioPlantillasCache = normalizarClaveUsuario(
                typeof usuarioData === 'string' && usuarioData.trim() ? usuarioData : usuarioPersistidoSitio
            );

            const localObj = localMap && typeof localMap === 'object' ? localMap : {};
            const syncObj = syncMap && typeof syncMap === 'object' ? syncMap : {};
            mensajeOverridesCache = { ...localObj, ...syncObj, ...siteMap };
            mensajesCacheListo = true;
        } catch (_) {
            mensajesCacheListo = true;
        }
    }

    function mensajesDelUsuario() {
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        const map = mensajeOverridesCache && typeof mensajeOverridesCache === 'object'
            ? mensajeOverridesCache
            : {};
        const propios = map[user];
        return propios && typeof propios === 'object' ? propios : {};
    }

    async function mensajeConfigurado(plantilla) {
        if (!mensajesCacheListo) await cargarMensajesPersonalizados();
        const personalizados = mensajesDelUsuario();
        const guardado = personalizados?.[clavePlantilla(plantilla)];
        return String(guardado == null ? plantilla.mensaje : guardado).trim();
    }

    async function guardarMensajePersonalizado(plantilla, mensaje) {
        if (!mensajesCacheListo) await cargarMensajesPersonalizados();
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        const texto = String(mensaje || '').trim();
        if (!texto) throw new Error('El mensaje no puede quedar vacío.');

        const base = mensajeOverridesCache && typeof mensajeOverridesCache === 'object'
            ? { ...mensajeOverridesCache }
            : {};
        const propios = base[user] && typeof base[user] === 'object' ? { ...base[user] } : {};
        propios[clavePlantilla(plantilla)] = texto;
        base[user] = propios;
        mensajeOverridesCache = base;

        let okSite = false;
        try {
            localStorage.setItem(MENSAJE_SITE_STORAGE_KEY, JSON.stringify(base));
            localStorage.setItem(MENSAJE_SITE_USER_KEY, user);
            okSite = true;
        } catch (_) {}
        const [okLocal, okSync] = await Promise.all([
            storageAreaSet(chrome.storage.local, MENSAJE_OVERRIDES_KEY, base),
            storageAreaSet(chrome.storage.sync, MENSAJE_OVERRIDES_KEY, base)
        ]);
        if (!okLocal && !okSync && !okSite) throw new Error('No se pudo guardar la personalización.');
        return texto;
    }

    async function restaurarMensajePredeterminado(plantilla) {
        if (!mensajesCacheListo) await cargarMensajesPersonalizados();
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        const base = mensajeOverridesCache && typeof mensajeOverridesCache === 'object'
            ? { ...mensajeOverridesCache }
            : {};
        const propios = base[user] && typeof base[user] === 'object' ? { ...base[user] } : {};
        delete propios[clavePlantilla(plantilla)];
        if (Object.keys(propios).length) base[user] = propios;
        else delete base[user];
        mensajeOverridesCache = base;
        try {
            localStorage.setItem(MENSAJE_SITE_STORAGE_KEY, JSON.stringify(base));
            localStorage.setItem(MENSAJE_SITE_USER_KEY, user);
        } catch (_) {}
        await Promise.all([
            storageAreaSet(chrome.storage.local, MENSAJE_OVERRIDES_KEY, base),
            storageAreaSet(chrome.storage.sync, MENSAJE_OVERRIDES_KEY, base)
        ]);
        return String(plantilla.mensaje || '').trim();
    }

    cargarMensajesPersonalizados();
    chrome.storage.onChanged.addListener((c, area) => {
        if (area === 'local' && c[USUARIO_KEY]) {
            usuarioPlantillasCache = normalizarClaveUsuario(c[USUARIO_KEY].newValue);
            try { localStorage.setItem(MENSAJE_SITE_USER_KEY, usuarioPlantillasCache); } catch (_) {}
        }
        if ((area === 'local' || area === 'sync') && c[MENSAJE_OVERRIDES_KEY]) {
            const nuevo = c[MENSAJE_OVERRIDES_KEY].newValue;
            if (nuevo && typeof nuevo === 'object') mensajeOverridesCache = { ...nuevo };
            else mensajeOverridesCache = {};
            mensajesCacheListo = true;
        }
        if ((area === 'local' || area === 'sync') && c[CUSTOM_TEMPLATES_KEY]) {
            const nuevo = c[CUSTOM_TEMPLATES_KEY].newValue;
            if (nuevo && typeof nuevo === 'object') customTemplatesCache = { ...nuevo };
            else customTemplatesCache = {};
            customTemplatesCacheListo = true;
            document.dispatchEvent(new CustomEvent('viena:custom-templates-changed'));
        }
        if ((area === 'local' || area === 'sync') && c[CUSTOM_TEMPLATE_GROUPS_KEY]) {
            const nuevo = c[CUSTOM_TEMPLATE_GROUPS_KEY].newValue;
            if (nuevo && typeof nuevo === 'object') customTemplateGroupsCache = { ...nuevo };
            else customTemplateGroupsCache = {};
            customTemplateGroupsCacheListo = true;
            document.dispatchEvent(new CustomEvent('viena:custom-template-groups-changed'));
        }
        if ((area === 'local' || area === 'sync') && c[SYSTEM_COMPLETE_CONFIG_KEY]) {
            const nuevo = c[SYSTEM_COMPLETE_CONFIG_KEY].newValue;
            if (nuevo && typeof nuevo === 'object') systemCompleteConfigCache = { ...nuevo };
            else systemCompleteConfigCache = {};
            systemCompleteConfigCacheListo = true;
            document.dispatchEvent(new CustomEvent('viena:system-complete-config-changed'));
        }
    });

    function normalizarPlantillaPersonalizada(item) {
        if (!item || typeof item !== 'object') return null;
        const id = String(item.id || '').trim();
        const nombre = String(item.nombre || '').replace(/\s+/g, ' ').trim();
        const mensaje = String(item.mensaje || '').trim();
        if (!id || !nombre || !mensaje) return null;
        return {
            id,
            nombre: nombre.slice(0, 32),
            estado: 'COMPLETADA',
            motivo: String(item.motivo || '').trim(),
            mensaje,
            custom: true,
            createdAt: Number(item.createdAt || Date.now()),
            updatedAt: Number(item.updatedAt || item.createdAt || Date.now())
        };
    }

    function fusionarMapasPlantillas(...maps) {
        const salida = {};
        for (const map of maps) {
            if (!map || typeof map !== 'object') continue;
            for (const [usuario, lista] of Object.entries(map)) {
                if (!Array.isArray(lista)) continue;
                const porId = new Map((salida[usuario] || []).map(x => [x.id, x]));
                for (const bruto of lista) {
                    const item = normalizarPlantillaPersonalizada(bruto);
                    if (!item) continue;
                    const anterior = porId.get(item.id);
                    if (!anterior || item.updatedAt >= anterior.updatedAt) porId.set(item.id, item);
                }
                salida[usuario] = Array.from(porId.values()).sort((a, b) => a.createdAt - b.createdAt);
            }
        }
        return salida;
    }

    async function cargarPlantillasPersonalizadas() {
        if (!mensajesCacheListo) await cargarMensajesPersonalizados();
        try {
            const [syncMap, localMap] = await Promise.all([
                storageAreaGet(chrome.storage.sync, CUSTOM_TEMPLATES_KEY),
                storageAreaGet(chrome.storage.local, CUSTOM_TEMPLATES_KEY)
            ]);
            let siteMap = {};
            try {
                const raw = localStorage.getItem(CUSTOM_TEMPLATES_SITE_KEY);
                const parsed = raw ? JSON.parse(raw) : {};
                if (parsed && typeof parsed === 'object') siteMap = parsed;
            } catch (_) {}

            customTemplatesCache = fusionarMapasPlantillas(localMap, syncMap, siteMap);
            customTemplatesCacheListo = true;

            await Promise.all([
                storageAreaSet(chrome.storage.local, CUSTOM_TEMPLATES_KEY, customTemplatesCache),
                storageAreaSet(chrome.storage.sync, CUSTOM_TEMPLATES_KEY, customTemplatesCache)
            ]);
        } catch (_) {
            customTemplatesCacheListo = true;
        }
    }

    function plantillasPersonalizadasDelUsuario() {
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        const lista = customTemplatesCache?.[user];
        return Array.isArray(lista) ? lista.map(normalizarPlantillaPersonalizada).filter(Boolean) : [];
    }

    async function persistirMapaPlantillasPersonalizadas(map) {
        customTemplatesCache = map && typeof map === 'object' ? map : {};
        customTemplatesCacheListo = true;
        let okSite = false;
        try {
            localStorage.setItem(CUSTOM_TEMPLATES_SITE_KEY, JSON.stringify(customTemplatesCache));
            localStorage.setItem(MENSAJE_SITE_USER_KEY, normalizarClaveUsuario(usuarioPlantillasCache));
            okSite = true;
        } catch (_) {}
        const [okLocal, okSync] = await Promise.all([
            storageAreaSet(chrome.storage.local, CUSTOM_TEMPLATES_KEY, customTemplatesCache),
            storageAreaSet(chrome.storage.sync, CUSTOM_TEMPLATES_KEY, customTemplatesCache)
        ]);
        if (!okSite && !okLocal && !okSync) throw new Error('No se pudo guardar la plantilla personalizada.');
        document.dispatchEvent(new CustomEvent('viena:custom-templates-changed'));
    }

    async function guardarPlantillaPersonalizada(datos, idExistente = '') {
        if (!customTemplatesCacheListo) await cargarPlantillasPersonalizadas();
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        if (user === '__sin_usuario__') {
            throw new Error('No pude identificar tu usuario VIENA. Revisá el panel de la extensión antes de crear plantillas.');
        }

        const nombre = String(datos?.nombre || '').replace(/\s+/g, ' ').trim();
        const mensaje = String(datos?.mensaje || '').trim();
        const motivo = String(datos?.motivo || '').trim();
        if (!nombre) throw new Error('Ingresá un nombre para el botón.');
        if (!mensaje) throw new Error('Ingresá el mensaje de cierre.');
        if (nombre.length > 32) throw new Error('El nombre puede tener hasta 32 caracteres.');

        const lista = plantillasPersonalizadasDelUsuario();
        const conflictoFijo = PLANTILLAS.some(p => normalizarTexto(p.nombre) === normalizarTexto(nombre));
        const conflictoCustom = lista.some(p => p.id !== idExistente && normalizarTexto(p.nombre) === normalizarTexto(nombre));
        if (conflictoFijo || conflictoCustom) throw new Error('Ya existe una plantilla con ese nombre.');

        const ahora = Date.now();
        const id = idExistente || `p_${ahora.toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
        const anterior = lista.find(p => p.id === id);
        const item = normalizarPlantillaPersonalizada({
            id,
            nombre,
            mensaje,
            motivo,
            createdAt: anterior?.createdAt || ahora,
            updatedAt: ahora
        });
        const nuevaLista = anterior
            ? lista.map(p => p.id === id ? item : p)
            : [...lista, item];
        const map = { ...(customTemplatesCache || {}), [user]: nuevaLista };
        await persistirMapaPlantillasPersonalizadas(map);
        return item;
    }

    async function eliminarPlantillaPersonalizada(id) {
        if (!customTemplatesCacheListo) await cargarPlantillasPersonalizadas();
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        const lista = plantillasPersonalizadasDelUsuario();
        const objetivo = lista.find(p => p.id === id);
        if (!objetivo) return false;
        const map = { ...(customTemplatesCache || {}), [user]: lista.filter(p => p.id !== id) };
        if (!map[user].length) delete map[user];
        await persistirMapaPlantillasPersonalizadas(map);

        const clave = clavePlantilla(objetivo);
        try {
            const motivos = await storageGet(MOTIVO_OVERRIDES_KEY);
            if (motivos && typeof motivos === 'object' && clave in motivos) {
                delete motivos[clave];
                await storageSet(MOTIVO_OVERRIDES_KEY, motivos);
            }
            const contextos = await storageGet(MOTIVO_CONTEXTOS_KEY);
            if (contextos?.templates && clave in contextos.templates) {
                const templates = { ...contextos.templates };
                delete templates[clave];
                await storageSet(MOTIVO_CONTEXTOS_KEY, { ...contextos, version: 2, templates });
            }
        } catch (_) {}
        try {
            const base = mensajeOverridesCache && typeof mensajeOverridesCache === 'object' ? { ...mensajeOverridesCache } : {};
            const propios = base[user] && typeof base[user] === 'object' ? { ...base[user] } : {};
            delete propios[clave];
            if (Object.keys(propios).length) base[user] = propios; else delete base[user];
            mensajeOverridesCache = base;
            try { localStorage.setItem(MENSAJE_SITE_STORAGE_KEY, JSON.stringify(base)); } catch (_) {}
            await Promise.all([
                storageAreaSet(chrome.storage.local, MENSAJE_OVERRIDES_KEY, base),
                storageAreaSet(chrome.storage.sync, MENSAJE_OVERRIDES_KEY, base)
            ]);
        } catch (_) {}
        return true;
    }

    cargarPlantillasPersonalizadas();

    function normalizarGrupoPlantillas(item) {
        if (!item || typeof item !== 'object') return null;
        const id = String(item.id || '').trim();
        const nombre = String(item.nombre || '').replace(/\s+/g, ' ').trim();
        const brutas = Array.isArray(item.plantillas) ? item.plantillas : [];
        const plantillas = brutas.map(normalizarPlantillaPersonalizada).filter(Boolean);
        if (!id || !nombre || !plantillas.length) return null;
        return {
            id,
            nombre: nombre.slice(0, 28),
            plantillas,
            createdAt: Number(item.createdAt || Date.now()),
            updatedAt: Number(item.updatedAt || item.createdAt || Date.now())
        };
    }

    function fusionarMapasGrupos(...maps) {
        const salida = {};
        for (const map of maps) {
            if (!map || typeof map !== 'object') continue;
            for (const [usuario, lista] of Object.entries(map)) {
                if (!Array.isArray(lista)) continue;
                const porId = new Map((salida[usuario] || []).map(x => [x.id, x]));
                for (const bruto of lista) {
                    const grupo = normalizarGrupoPlantillas(bruto);
                    if (!grupo) continue;
                    const anterior = porId.get(grupo.id);
                    if (!anterior || grupo.updatedAt >= anterior.updatedAt) porId.set(grupo.id, grupo);
                }
                salida[usuario] = Array.from(porId.values()).sort((a, b) => a.createdAt - b.createdAt);
            }
        }
        return salida;
    }

    async function persistirMapaGrupos(map) {
        customTemplateGroupsCache = map && typeof map === 'object' ? map : {};
        customTemplateGroupsCacheListo = true;
        let okSite = false;
        try {
            localStorage.setItem(CUSTOM_TEMPLATE_GROUPS_SITE_KEY, JSON.stringify(customTemplateGroupsCache));
            localStorage.setItem(MENSAJE_SITE_USER_KEY, normalizarClaveUsuario(usuarioPlantillasCache));
            okSite = true;
        } catch (_) {}
        const [okLocal, okSync] = await Promise.all([
            storageAreaSet(chrome.storage.local, CUSTOM_TEMPLATE_GROUPS_KEY, customTemplateGroupsCache),
            storageAreaSet(chrome.storage.sync, CUSTOM_TEMPLATE_GROUPS_KEY, customTemplateGroupsCache)
        ]);
        if (!okSite && !okLocal && !okSync) throw new Error('No se pudo guardar el botón personalizado.');
        document.dispatchEvent(new CustomEvent('viena:custom-template-groups-changed'));
    }


    function plantillaSistemaBase(plantilla, indice) {
        const motivoContiene = Array.isArray(plantilla?.motivoContiene)
            ? plantilla.motivoContiene.map(x => String(x || '').trim()).filter(Boolean)
            : [];
        return {
            id: `sys_${indice}`,
            nombre: String(plantilla?.nombre || '').replace(/\s+/g, ' ').trim().slice(0, 32),
            estado: 'COMPLETADA',
            motivo: String(plantilla?.motivo || '').trim(),
            motivoContiene,
            mensaje: String(plantilla?.mensaje || '').trim(),
            custom: true,
            system: true,
            createdAt: indice + 1,
            updatedAt: 0
        };
    }

    function plantillasSistemaPredeterminadas() {
        return PLANTILLAS.map((p, i) => plantillaSistemaBase(p, i));
    }

    function normalizarPlantillaSistema(item, anterior = null) {
        if (!item || typeof item !== 'object') return null;
        const ahora = Date.now();
        const id = String(item.id || anterior?.id || `sysu_${ahora.toString(36)}_${Math.random().toString(36).slice(2, 8)}`).trim();
        const nombre = String(item.nombre || '').replace(/\s+/g, ' ').trim();
        const mensaje = String(item.mensaje || '').trim();
        if (!id || !nombre || !mensaje) return null;
        const motivo = String(item.motivo || '').trim();
        let motivoContiene = Array.isArray(item.motivoContiene)
            ? item.motivoContiene.map(x => String(x || '').trim()).filter(Boolean)
            : [];
        if (motivo) motivoContiene = [];
        return {
            id,
            nombre: nombre.slice(0, 32),
            estado: 'COMPLETADA',
            motivo,
            motivoContiene,
            mensaje,
            custom: true,
            system: true,
            createdAt: Number(anterior?.createdAt || item.createdAt || ahora),
            updatedAt: ahora
        };
    }

    function normalizarConfigCompletarSistema(item) {
        if (!item || typeof item !== 'object') return null;
        const nombre = String(item.nombre || '').replace(/\s+/g, ' ').trim();
        const brutas = Array.isArray(item.plantillas) ? item.plantillas : [];
        const plantillas = brutas.map(p => normalizarPlantillaSistema(p, p)).filter(Boolean);
        if (!nombre || !plantillas.length) return null;
        return {
            nombre: nombre.slice(0, 28),
            plantillas,
            updatedAt: Number(item.updatedAt || Date.now())
        };
    }

    function configCompletarSistemaDelUsuario() {
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        const configurado = normalizarConfigCompletarSistema(systemCompleteConfigCache?.[user]);
        if (configurado) return configurado;
        return {
            nombre: 'Completar Tarea',
            plantillas: plantillasSistemaPredeterminadas(),
            updatedAt: 0
        };
    }

    function nombreCompletarActivo() {
        return configCompletarSistemaDelUsuario().nombre || 'Completar Tarea';
    }

    function plantillasCompletarActivas() {
        return configCompletarSistemaDelUsuario().plantillas;
    }

    async function persistirConfigCompletarSistema(map) {
        systemCompleteConfigCache = map && typeof map === 'object' ? map : {};
        systemCompleteConfigCacheListo = true;
        let okSite = false;
        try {
            localStorage.setItem(SYSTEM_COMPLETE_CONFIG_SITE_KEY, JSON.stringify(systemCompleteConfigCache));
            localStorage.setItem(MENSAJE_SITE_USER_KEY, normalizarClaveUsuario(usuarioPlantillasCache));
            okSite = true;
        } catch (_) {}
        const [okLocal, okSync] = await Promise.all([
            storageAreaSet(chrome.storage.local, SYSTEM_COMPLETE_CONFIG_KEY, systemCompleteConfigCache),
            storageAreaSet(chrome.storage.sync, SYSTEM_COMPLETE_CONFIG_KEY, systemCompleteConfigCache)
        ]);
        if (!okSite && !okLocal && !okSync) throw new Error('No se pudo guardar la configuración de Completar Tarea.');
        document.dispatchEvent(new CustomEvent('viena:system-complete-config-changed'));
    }

    async function cargarConfigCompletarSistema() {
        if (!mensajesCacheListo) await cargarMensajesPersonalizados();
        try {
            const [syncMap, localMap] = await Promise.all([
                storageAreaGet(chrome.storage.sync, SYSTEM_COMPLETE_CONFIG_KEY),
                storageAreaGet(chrome.storage.local, SYSTEM_COMPLETE_CONFIG_KEY)
            ]);
            let siteMap = {};
            try {
                const raw = localStorage.getItem(SYSTEM_COMPLETE_CONFIG_SITE_KEY);
                const parsed = raw ? JSON.parse(raw) : {};
                if (parsed && typeof parsed === 'object') siteMap = parsed;
            } catch (_) {}
            systemCompleteConfigCache = { ...(localMap || {}), ...(syncMap || {}), ...(siteMap || {}) };
            systemCompleteConfigCacheListo = true;
            await Promise.all([
                storageAreaSet(chrome.storage.local, SYSTEM_COMPLETE_CONFIG_KEY, systemCompleteConfigCache),
                storageAreaSet(chrome.storage.sync, SYSTEM_COMPLETE_CONFIG_KEY, systemCompleteConfigCache)
            ]);
        } catch (_) {
            systemCompleteConfigCacheListo = true;
        }
    }

    async function guardarConfigCompletarSistema(datos) {
        if (!systemCompleteConfigCacheListo) await cargarConfigCompletarSistema();
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        if (user === '__sin_usuario__') throw new Error('No pude identificar tu usuario VIENA. Revisá el panel de la extensión.');
        const nombre = String(datos?.nombre || '').replace(/\s+/g, ' ').trim();
        if (!nombre) throw new Error('Ingresá un nombre para el botón.');
        if (nombre.length > 28) throw new Error('El nombre del botón puede tener hasta 28 caracteres.');
        const grupos = gruposPersonalizadosDelUsuario();
        if (grupos.some(g => normalizarTexto(g.nombre) === normalizarTexto(nombre))) {
            throw new Error('Ya existe un botón personal con ese nombre.');
        }
        const brutas = Array.isArray(datos?.plantillas) ? datos.plantillas : [];
        if (!brutas.length) throw new Error('Agregá al menos una plantilla al botón.');
        const anterior = configCompletarSistemaDelUsuario();
        const anterioresPorId = new Map((anterior.plantillas || []).map(p => [p.id, p]));
        const nombres = new Set();
        const plantillas = [];
        for (const bruto of brutas) {
            const n = String(bruto?.nombre || '').replace(/\s+/g, ' ').trim();
            const msg = String(bruto?.mensaje || '').trim();
            if (!n) throw new Error('Todas las plantillas necesitan un nombre.');
            if (!msg) throw new Error(`La plantilla “${n}” necesita un mensaje.`);
            const k = normalizarTexto(n);
            if (nombres.has(k)) throw new Error(`El nombre “${n}” está repetido dentro del botón.`);
            nombres.add(k);
            const anteriorPlantilla = anterioresPorId.get(String(bruto?.id || '')) || null;
            const motivoTexto = String(bruto?.motivo || '').trim();
            const motivoAnteriorVisible = anteriorPlantilla?.motivo
                ? String(anteriorPlantilla.motivo)
                : (Array.isArray(anteriorPlantilla?.motivoContiene) ? anteriorPlantilla.motivoContiene.join(' | ') : '');
            const conservarContiene = !!(anteriorPlantilla?.motivoContiene?.length &&
                normalizarTexto(motivoTexto) === normalizarTexto(motivoAnteriorVisible));
            const item = normalizarPlantillaSistema({
                ...bruto,
                motivo: conservarContiene ? '' : motivoTexto,
                motivoContiene: conservarContiene ? anteriorPlantilla.motivoContiene : []
            }, anteriorPlantilla);
            if (!item) throw new Error(`No se pudo guardar la plantilla “${n}”.`);
            plantillas.push(item);
        }
        const config = { nombre, plantillas, updatedAt: Date.now() };
        await persistirConfigCompletarSistema({ ...(systemCompleteConfigCache || {}), [user]: config });
        return config;
    }

    cargarConfigCompletarSistema();

    async function cargarGruposPersonalizados() {
        if (!mensajesCacheListo) await cargarMensajesPersonalizados();
        try {
            const [syncMap, localMap] = await Promise.all([
                storageAreaGet(chrome.storage.sync, CUSTOM_TEMPLATE_GROUPS_KEY),
                storageAreaGet(chrome.storage.local, CUSTOM_TEMPLATE_GROUPS_KEY)
            ]);
            let siteMap = {};
            try {
                const raw = localStorage.getItem(CUSTOM_TEMPLATE_GROUPS_SITE_KEY);
                const parsed = raw ? JSON.parse(raw) : {};
                if (parsed && typeof parsed === 'object') siteMap = parsed;
            } catch (_) {}

            // DEV: importar UNA sola vez los botones personales existentes en RELEASE.
            // La fuente es el respaldo del sitio (compartido por origen), pero la copia se
            // guarda únicamente en el storage aislado de esta extensión DEV y en su key __dev.
            // Nunca se escribe sobre la key RELEASE.
            let releaseSiteMap = {};
            const importMarker = await storageAreaGet(chrome.storage.local, DEV_GROUPS_IMPORT_MARKER);
            const debeImportarRelease = !importMarker?.done;
            if (debeImportarRelease) {
                try {
                    const rawRelease = localStorage.getItem(RELEASE_CUSTOM_TEMPLATE_GROUPS_SITE_KEY);
                    const parsedRelease = rawRelease ? JSON.parse(rawRelease) : {};
                    if (parsedRelease && typeof parsedRelease === 'object') releaseSiteMap = parsedRelease;
                } catch (_) {}
            }

            customTemplateGroupsCache = fusionarMapasGrupos(localMap, syncMap, siteMap, releaseSiteMap);
            customTemplateGroupsCacheListo = true;

            if (debeImportarRelease) {
                try { localStorage.setItem(CUSTOM_TEMPLATE_GROUPS_SITE_KEY, JSON.stringify(customTemplateGroupsCache)); } catch (_) {}
                await Promise.all([
                    storageAreaSet(chrome.storage.local, CUSTOM_TEMPLATE_GROUPS_KEY, customTemplateGroupsCache),
                    storageAreaSet(chrome.storage.sync, CUSTOM_TEMPLATE_GROUPS_KEY, customTemplateGroupsCache),
                    storageAreaSet(chrome.storage.local, DEV_GROUPS_IMPORT_MARKER, { done: true, importedAt: Date.now() })
                ]);
            }

            // Migración no destructiva de v1.3.12/v1.3.13: si existían plantillas
            // personales planas y todavía no hay botones-grupo, se agrupan dentro de
            // "Mis cierres". Así ninguna personalización previa queda huérfana.
            if (!customTemplatesCacheListo) await cargarPlantillasPersonalizadas();
            const user = normalizarClaveUsuario(usuarioPlantillasCache);
            const actuales = Array.isArray(customTemplateGroupsCache[user]) ? customTemplateGroupsCache[user] : [];
            const legacy = plantillasPersonalizadasDelUsuario();
            if (!actuales.length && legacy.length) {
                const ahora = Date.now();
                customTemplateGroupsCache = {
                    ...customTemplateGroupsCache,
                    [user]: [{
                        id: `g_migrado_${ahora.toString(36)}`,
                        nombre: 'Mis cierres',
                        plantillas: legacy,
                        createdAt: ahora,
                        updatedAt: ahora
                    }]
                };
                await persistirMapaGrupos(customTemplateGroupsCache);
            } else {
                await Promise.all([
                    storageAreaSet(chrome.storage.local, CUSTOM_TEMPLATE_GROUPS_KEY, customTemplateGroupsCache),
                    storageAreaSet(chrome.storage.sync, CUSTOM_TEMPLATE_GROUPS_KEY, customTemplateGroupsCache)
                ]);
            }
        } catch (_) {
            customTemplateGroupsCacheListo = true;
        }
    }

    function gruposPersonalizadosDelUsuario() {
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        const lista = customTemplateGroupsCache?.[user];
        return Array.isArray(lista) ? lista.map(normalizarGrupoPlantillas).filter(Boolean) : [];
    }

    function normalizarPlantillaGrupo(datos, anterior = null) {
        const ahora = Date.now();
        return normalizarPlantillaPersonalizada({
            id: String(datos?.id || anterior?.id || `p_${ahora.toString(36)}_${Math.random().toString(36).slice(2, 8)}`),
            nombre: String(datos?.nombre || ''),
            motivo: String(datos?.motivo || ''),
            mensaje: String(datos?.mensaje || ''),
            createdAt: Number(anterior?.createdAt || datos?.createdAt || ahora),
            updatedAt: ahora
        });
    }

    async function guardarGrupoPersonalizado(datos, idExistente = '') {
        if (!customTemplateGroupsCacheListo) await cargarGruposPersonalizados();
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        if (user === '__sin_usuario__') throw new Error('No pude identificar tu usuario VIENA. Revisá el panel de la extensión.');
        const nombre = String(datos?.nombre || '').replace(/\s+/g, ' ').trim();
        if (!nombre) throw new Error('Ingresá un nombre para el botón.');
        if (nombre.length > 28) throw new Error('El nombre del botón puede tener hasta 28 caracteres.');
        const brutas = Array.isArray(datos?.plantillas) ? datos.plantillas : [];
        if (!brutas.length) throw new Error('Agregá al menos una plantilla al botón.');

        const grupos = gruposPersonalizadosDelUsuario();
        if (grupos.some(g => g.id !== idExistente && normalizarTexto(g.nombre) === normalizarTexto(nombre))) {
            throw new Error('Ya existe un botón personal con ese nombre.');
        }
        if (normalizarTexto(nombre) === normalizarTexto(nombreCompletarActivo())) {
            throw new Error('Ese nombre ya está usado por el botón del sistema.');
        }
        const anterior = grupos.find(g => g.id === idExistente) || null;
        const anterioresPorId = new Map((anterior?.plantillas || []).map(p => [p.id, p]));
        const plantillas = [];
        const nombres = new Set();
        for (const bruto of brutas) {
            const n = String(bruto?.nombre || '').replace(/\s+/g, ' ').trim();
            const msg = String(bruto?.mensaje || '').trim();
            if (!n) throw new Error('Todas las plantillas necesitan un nombre.');
            if (!msg) throw new Error(`La plantilla “${n}” necesita un mensaje.`);
            const k = normalizarTexto(n);
            if (nombres.has(k)) throw new Error(`El nombre “${n}” está repetido dentro del botón.`);
            nombres.add(k);
            const item = normalizarPlantillaGrupo(bruto, anterioresPorId.get(String(bruto?.id || '')) || null);
            if (!item) throw new Error(`No se pudo guardar la plantilla “${n}”.`);
            plantillas.push(item);
        }
        const ahora = Date.now();
        const id = idExistente || `g_${ahora.toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
        const grupo = normalizarGrupoPlantillas({
            id,
            nombre,
            plantillas,
            createdAt: anterior?.createdAt || ahora,
            updatedAt: ahora
        });
        const nuevaLista = anterior ? grupos.map(g => g.id === id ? grupo : g) : [...grupos, grupo];
        await persistirMapaGrupos({ ...(customTemplateGroupsCache || {}), [user]: nuevaLista });
        return grupo;
    }

    async function eliminarGrupoPersonalizado(id) {
        if (!customTemplateGroupsCacheListo) await cargarGruposPersonalizados();
        const user = normalizarClaveUsuario(usuarioPlantillasCache);
        const grupos = gruposPersonalizadosDelUsuario();
        const objetivo = grupos.find(g => g.id === id);
        if (!objetivo) return false;
        const map = { ...(customTemplateGroupsCache || {}), [user]: grupos.filter(g => g.id !== id) };
        if (!map[user].length) delete map[user];
        await persistirMapaGrupos(map);
        return true;
    }

    cargarGruposPersonalizados();

    function storageGet(key) {
        return storageAreaGet(chrome.storage.local, key);
    }

    function storageSet(key, value) {
        return storageAreaSet(chrome.storage.local, key, value);
    }

    function obtenerTipificacionTareaActual(dialogo) {
        const scopes = [];
        if (dialogo) scopes.push(dialogo);
        const active = document.querySelector('.v-dialog__content.v-dialog__content--active .v-dialog');
        if (active && !scopes.includes(active)) scopes.push(active);
        scopes.push(document);

        for (const scope of scopes) {
            const labels = Array.from(scope.querySelectorAll?.('label') || []);
            for (const label of labels) {
                const nombre = normalizarTexto(label.textContent);
                if (nombre !== 'tipificación de la tarea' && nombre !== 'tipificacion de la tarea') continue;
                const campo = label.closest('.v-input') || label.parentElement;
                const input = campo?.querySelector('input');
                const valor = String(input?.value || '').replace(/\s+/g, ' ').trim();
                if (valor) return valor;
            }
        }
        return '';
    }

    function claveContextoMotivo(valor) {
        return String(valor || '')
            .normalize('NFKD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-zA-Z0-9]+/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();
    }

    function motivosUnicos(valores) {
        const vistos = new Set();
        const salida = [];
        for (const bruto of valores || []) {
            const texto = String(bruto || '').trim();
            const k = normalizarMotivo(texto);
            if (!texto || !k || vistos.has(k)) continue;
            vistos.add(k);
            salida.push(texto);
        }
        return salida;
    }

    async function estadoMotivosPlantilla(plantilla) {
        const clave = clavePlantilla(plantilla);
        const [contextosRaw, legacyRaw] = await Promise.all([
            storageGet(MOTIVO_CONTEXTOS_KEY),
            storageGet(MOTIVO_OVERRIDES_KEY)
        ]);
        const root = contextosRaw && typeof contextosRaw === 'object' ? contextosRaw : {};
        const templates = root.templates && typeof root.templates === 'object' ? root.templates : {};
        const entryRaw = templates[clave] && typeof templates[clave] === 'object' ? templates[clave] : {};
        const byContext = entryRaw.byContext && typeof entryRaw.byContext === 'object' ? entryRaw.byContext : {};
        const legacy = String(legacyRaw?.[clave] || '').trim();
        const known = motivosUnicos([
            ...(Array.isArray(entryRaw.known) ? entryRaw.known : []),
            plantilla?.motivo,
            legacy
        ]);
        return { root, templates, clave, byContext, known, legacy };
    }

    async function guardarAsociacionMotivo(plantilla, tipificacion, motivo) {
        const limpio = String(motivo || '').trim();
        const contexto = claveContextoMotivo(tipificacion);
        if (!limpio || !contexto) return false;

        const estado = await estadoMotivosPlantilla(plantilla);
        const entryAnterior = estado.templates[estado.clave] && typeof estado.templates[estado.clave] === 'object'
            ? estado.templates[estado.clave] : {};
        const known = motivosUnicos([...(estado.known || []), limpio]);
        const byContext = { ...(estado.byContext || {}) };
        byContext[contexto] = {
            motivo: limpio,
            tipificacion: String(tipificacion || '').replace(/\s+/g, ' ').trim(),
            updatedAt: Date.now()
        };
        const templates = {
            ...(estado.templates || {}),
            [estado.clave]: {
                ...entryAnterior,
                known,
                byContext,
                updatedAt: Date.now()
            }
        };
        return storageSet(MOTIVO_CONTEXTOS_KEY, { version: 2, templates });
    }

    async function motivoConfigurado(plantilla, dialogo) {
        const tipificacion = dialogo ? obtenerTipificacionTareaActual(dialogo) : '';
        const contexto = claveContextoMotivo(tipificacion);
        const estado = await estadoMotivosPlantilla(plantilla);
        const exacto = contexto ? estado.byContext?.[contexto] : null;
        return String(exacto?.motivo || estado.legacy || plantilla.motivo || '').trim();
    }

    async function motivosConfiguradosParaEditor(plantilla) {
        const estado = await estadoMotivosPlantilla(plantilla);
        const contextuales = Object.values(estado.byContext || {})
            .map(entry => String(entry?.motivo || '').trim())
            .filter(Boolean);
        return motivosUnicos([
            ...(estado.known || []),
            ...contextuales,
            plantilla?.motivo,
            estado.legacy
        ]);
    }

    function motivosVisibles() {
        const vistos = new Set();
        return Array.from(document.querySelectorAll('.v-list-item__title'))
            .filter(esVisible)
            .map(el => String(el.textContent || '').trim())
            .filter(Boolean)
            .filter(t => {
                const k = normalizarMotivo(t);
                if (vistos.has(k)) return false;
                vistos.add(k);
                return true;
            });
    }

    function controlMotivoDelDialogo(dialogo) {
        if (!dialogo) return null;
        const label = Array.from(dialogo.querySelectorAll('label')).find(el =>
            esVisible(el) && normalizarTexto(el.textContent).includes('motivo')
        );
        if (!label) return null;
        const contenedor = label.closest('.v-input') || label.parentElement;
        const input = contenedor?.querySelector('input[role="combobox"], input') || null;
        const clickable =
            contenedor?.querySelector('.v-input__slot, .v-select__slot, [role="combobox"]') ||
            input || contenedor;
        return { label, contenedor, input, clickable };
    }

    function esVisiblePortal(el) {
        if (!el || !el.isConnected) return false;
        try {
            const style = getComputedStyle(el);
            if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') return false;
            const rect = el.getBoundingClientRect();
            return rect.width > 0 && rect.height > 0;
        } catch (_) {
            return false;
        }
    }

    function selectoresItemMotivo() {
        // El DOM de VIENA/Vuetify puede variar por tipificación/versión: algunas listas
        // usan option, otras menuitem y otras sólo .v-list-item. La seguridad no está en
        // el role: está en limitar siempre los items al menú asociado al control MOTIVO.
        return '[role="option"], [role="menuitem"], [role="menuitemradio"], .v-list-item';
    }

    function itemsSeleccionablesDelMenu(menu) {
        if (!menu) return [];
        const vistos = new Set();

        // En los selects nativos de Vuetify, las opciones reales suelen ser hijos
        // directos de `.v-select-list`. Priorizar esos hijos evita capturar listas
        // internas ajenas aunque compartan `.v-list-item` o roles ARIA.
        const directos = Array.from(menu.children || []).filter(el =>
            el.matches?.('[role="option"], [role="menuitem"], [role="menuitemradio"], .v-list-item')
        );
        const candidatos = directos.length
            ? directos
            : Array.from(menu.querySelectorAll(selectoresItemMotivo()));

        return candidatos
            .filter(esVisiblePortal)
            .filter(el => {
                const texto = normalizarTexto(el.textContent || '');
                if (!texto) return false;
                const key = `${texto}|${Math.round(el.getBoundingClientRect().top)}|${Math.round(el.getBoundingClientRect().left)}`;
                if (vistos.has(key)) return false;
                vistos.add(key);
                return true;
            });
    }

    function menuMotivoDelControl(control) {
        if (!control) return null;
        const anchor = control.contenedor?.getBoundingClientRect?.();

        const menuGeometricamenteAsociado = menu => {
            if (!esVisiblePortal(menu)) return false;
            const items = itemsSeleccionablesDelMenu(menu);
            if (!items.length) return false;
            if (!anchor) return true;
            const r = menu.getBoundingClientRect();
            const overlapX = Math.max(0, Math.min(anchor.right + 36, r.right) - Math.max(anchor.left - 36, r.left));
            const anchoReferencia = Math.max(80, Math.min(anchor.width || 80, r.width || 80));
            const alineadoX = overlapX >= anchoReferencia * 0.45 || Math.abs(r.left - anchor.left) <= 56;
            const cercaY = r.top >= anchor.top - 40 && r.top <= anchor.bottom + 620;
            return alineadoX && cercaY;
        };

        const normalizarMenu = target => {
            if (!target) return null;
            // `v-select-list` es la firma semántica del desplegable de un v-select.
            // Es mucho más fiable que un role genérico `listbox`, porque la navegación
            // lateral de VIENA también usa listbox/v-list.
            if (target.matches?.('.v-select-list')) return target;
            return target.querySelector?.('.v-select-list') ||
                target.closest?.('.v-select-list') ||
                target.closest?.('.v-menu__content')?.querySelector?.('.v-select-list') ||
                target;
        };

        // 1) Relación explícita del control. Aunque Vue pueda dejar un aria-owns viejo,
        // si apunta a una v-select-list válida y visible tiene máxima prioridad.
        const ids = new Set();
        for (const el of [control.input, control.clickable, control.contenedor]) {
            if (!el?.getAttribute) continue;
            for (const attr of ['aria-owns', 'aria-controls']) {
                String(el.getAttribute(attr) || '').trim().split(/\s+/).filter(Boolean).forEach(id => ids.add(id));
            }
        }
        for (const id of ids) {
            const menu = normalizarMenu(document.getElementById(id));
            if (menuGeometricamenteAsociado(menu)) return menu;
        }

        // 2) Fallback principal: sólo listas de SELECT de Vuetify. El HTML real puede
        // usar IDs distintos entre el control (`list-609`) y la lista renderizada
        // (`list-573`/`list-item-587-*`), así que no exigimos coincidencia de IDs.
        const selectLists = Array.from(document.querySelectorAll(
            '.v-select-list[role="listbox"], .v-list.v-select-list'
        )).filter(menuGeometricamenteAsociado);

        if (selectLists.length) {
            if (!anchor) return selectLists[selectLists.length - 1];
            let best = null, bestScore = Infinity;
            for (const menu of selectLists) {
                const r = menu.getBoundingClientRect();
                const overlapX = Math.max(0, Math.min(anchor.right, r.right) - Math.max(anchor.left, r.left));
                const dy = Math.min(Math.abs(r.top - anchor.bottom), Math.abs(r.bottom - anchor.top));
                const dx = Math.abs(r.left - anchor.left);
                const dw = Math.abs((r.width || 0) - (anchor.width || 0));
                const score = dy + dx * 0.30 + dw * 0.08 + (overlapX > 0 ? 0 : 10000);
                if (score < bestScore) { bestScore = score; best = menu; }
            }
            if (best) return best;
        }

        // 3) Compatibilidad defensiva para variantes futuras que no usen
        // `.v-select-list`: recién aquí se consideran menús/listboxes genéricos,
        // siempre sujetos al contexto geométrico del control MOTIVO.
        const menus = Array.from(document.querySelectorAll(
            '.v-menu__content.menuable__content__active, .v-menu__content, [role="listbox"]'
        ))
            .map(normalizarMenu)
            .filter(Boolean)
            .filter((menu, i, arr) => arr.indexOf(menu) === i)
            .filter(menuGeometricamenteAsociado);
        if (!menus.length) return null;
        if (!anchor) return menus[menus.length - 1];

        let best = null, bestScore = Infinity;
        for (const menu of menus) {
            const r = menu.getBoundingClientRect();
            const overlapX = Math.max(0, Math.min(anchor.right, r.right) - Math.max(anchor.left, r.left));
            const dy = Math.min(Math.abs(r.top - anchor.bottom), Math.abs(r.bottom - anchor.top));
            const dx = Math.abs(r.left - anchor.left);
            const score = dy + dx * 0.35 + (overlapX > 0 ? 0 : 10000);
            if (score < bestScore) { bestScore = score; best = menu; }
        }
        return best;
    }

    async function abrirMenuMotivo(dialogo, timeout = 10000) {
        const inicio = Date.now();
        let control = controlMotivoDelDialogo(dialogo);
        if (!control?.clickable) throw new Error('Se encontró Motivo pero no su selector');

        let menu = menuMotivoDelControl(control);
        if (menu) return { control, menu };

        // El TRACE real muestra que VIENA termina el XHR de motivos y apenas ~13 ms
        // después nuestro flujo intentaba abrir el selector. Vue todavía puede
        // reemplazar ese control/listado en el siguiente render. Re-adquirimos el
        // control durante toda la espera y sólo hacemos click cuando el selector
        // actual está cerrado. Si fue reemplazado, el nuevo nodo recibe el click.
        let ultimoClickable = null;
        let ultimoClick = 0;
        while (Date.now() - inicio < timeout) {
            control = controlMotivoDelDialogo(dialogo) || control;
            const clickable = control?.clickable;
            if (!clickable?.isConnected) {
                await pausa(60);
                continue;
            }

            menu = menuMotivoDelControl(control);
            if (menu) return { control, menu };

            const expanded = String(clickable.getAttribute?.('aria-expanded') || '').toLowerCase();
            const ahora = Date.now();
            const nodoCambio = clickable !== ultimoClickable;
            const puedeReintentar = ahora - ultimoClick >= 450;
            if ((nodoCambio || expanded !== 'true') && puedeReintentar) {
                try { clickable.click(); } catch (_) {}
                ultimoClickable = clickable;
                ultimoClick = ahora;
            }
            await pausa(60);
        }
        throw new Error('No apareció la lista de motivos de VIENA');
    }

    async function cerrarMenuMotivo(dialogo) {
        let control = controlMotivoDelDialogo(dialogo);
        let menu = menuMotivoDelControl(control);
        if (!menu) return true;
        const input = control?.input || document.activeElement;
        try {
            input?.dispatchEvent(new KeyboardEvent('keydown', {key:'Escape', code:'Escape', keyCode:27, which:27, bubbles:true}));
            input?.dispatchEvent(new KeyboardEvent('keyup', {key:'Escape', code:'Escape', keyCode:27, which:27, bubbles:true}));
        } catch (_) {}
        for (let i=0;i<8;i++) {
            await pausa(50);
            control = controlMotivoDelDialogo(dialogo) || control;
            menu = menuMotivoDelControl(control);
            if (!menu) return true;
        }
        // Fallback: toggle del mismo control. No bloquear el flujo si Vuetify demora.
        try { control?.clickable?.click(); } catch (_) {}
        await pausa(100);
        return !menuMotivoDelControl(controlMotivoDelDialogo(dialogo) || control);
    }

    function opcionesMotivoDelMenu(menu) {
        // Importante: admitir las variantes de markup de VIENA, pero SIEMPRE dentro del
        // menú que ya fue asociado específicamente al selector MOTIVO. Nunca global.
        return itemsSeleccionablesDelMenu(menu);
    }

    function motivosDelMenu(menu) {
        const vistos = new Set();
        return opcionesMotivoDelMenu(menu)
            .map(el => String(el.textContent || '').trim())
            .filter(Boolean)
            .filter(t => {
                const k = normalizarMotivo(t);
                if (vistos.has(k)) return false;
                vistos.add(k);
                return true;
            });
    }

    function itemMotivoExactoEnMenu(menu, texto) {
        const buscado = normalizarMotivo(texto);
        return opcionesMotivoDelMenu(menu)
            .find(el => normalizarMotivo(el.textContent) === buscado) || null;
    }

    function itemMotivoContieneEnMenu(menu, textos) {
        const variantes = (Array.isArray(textos) ? textos : [textos])
            .map(normalizarTexto)
            .map(t => t.replace(/[‐‑‒–—-]+/g, ' ').replace(/\s+/g, ' ').trim())
            .filter(Boolean);
        if (!variantes.length) return null;
        return opcionesMotivoDelMenu(menu).find(el => {
            const texto = normalizarTexto(el.textContent)
                .replace(/[‐‑‒–—-]+/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
            return variantes.some(v => texto.includes(v));
        }) || null;
    }

    function confirmarNuevoMotivo(texto) {
        return new Promise(resolve => {
            const overlay = document.createElement('div');
            overlay.id = 'viena-motivo-confirm-overlay';
            Object.assign(overlay.style, {
                position: 'fixed', inset: '0', zIndex: '2147483647',
                background: 'rgba(0,0,0,.58)', display: 'flex',
                alignItems: 'center', justifyContent: 'center', padding: '24px'
            });

            const card = document.createElement('div');
            Object.assign(card.style, {
                width: 'min(520px, 92vw)', background: '#fff', color: '#1f2937',
                borderRadius: '12px', boxShadow: '0 18px 60px rgba(0,0,0,.35)',
                padding: '22px', fontFamily: 'Arial, sans-serif'
            });

            const title = document.createElement('div');
            title.textContent = 'Confirmar nuevo motivo';
            Object.assign(title.style, {fontSize:'18px', fontWeight:'700', marginBottom:'10px'});

            const ayuda = document.createElement('div');
            ayuda.textContent = '¿Querés usar este motivo para completar la tarea?';
            Object.assign(ayuda.style, {fontSize:'15px', marginBottom:'12px', lineHeight:'1.4'});

            const elegido = document.createElement('div');
            elegido.textContent = texto;
            Object.assign(elegido.style, {
                border:'1px solid #93c5fd', background:'#eff6ff', borderRadius:'8px',
                padding:'12px', fontSize:'15px', fontWeight:'700', lineHeight:'1.4',
                marginBottom:'18px', userSelect:'text', WebkitUserSelect:'text'
            });

            const actions = document.createElement('div');
            Object.assign(actions.style, {display:'flex', justifyContent:'flex-end', gap:'10px'});
            const volver = document.createElement('button');
            volver.type = 'button'; volver.textContent = 'Volver';
            const confirmar = document.createElement('button');
            confirmar.type = 'button'; confirmar.textContent = 'Confirmar motivo';
            for (const b of [volver, confirmar]) Object.assign(b.style, {
                border:'0', borderRadius:'8px', padding:'10px 14px', cursor:'pointer', fontWeight:'700'
            });
            volver.style.background = '#e2e8f0';
            confirmar.style.background = '#1976d2'; confirmar.style.color = '#fff';

            const terminar = valor => { overlay.remove(); resolve(valor); };
            volver.addEventListener('click', () => terminar(false));
            confirmar.addEventListener('click', () => terminar(true));
            overlay.addEventListener('click', e => { if (e.target === overlay) terminar(false); });

            actions.append(volver, confirmar);
            card.append(title, ayuda, elegido, actions);
            overlay.appendChild(card);
            document.body.appendChild(overlay);
            confirmar.focus();
        });
    }

    function elegirMotivoDesdePopup(plantilla, actual, opciones) {
        return new Promise(resolve => {
            const viejo = document.getElementById('viena-motivo-repair-overlay');
            if (viejo) viejo.remove();

            const overlay = document.createElement('div');
            overlay.id = 'viena-motivo-repair-overlay';
            Object.assign(overlay.style, {
                position: 'fixed', inset: '0', zIndex: '2147483647',
                background: 'rgba(0,0,0,.55)', display: 'flex',
                alignItems: 'center', justifyContent: 'center', padding: '24px'
            });

            const card = document.createElement('div');
            Object.assign(card.style, {
                width: 'min(680px, 94vw)', maxHeight: '82vh', overflow: 'auto',
                background: '#fff', color: '#1f2937', borderRadius: '12px',
                boxShadow: '0 18px 60px rgba(0,0,0,.35)', padding: '22px',
                fontFamily: 'Arial, sans-serif'
            });

            const esPrimeraConfiguracion = !String(actual || '').trim();
            const title = document.createElement('div');
            title.textContent = esPrimeraConfiguracion
                ? 'Elegí el motivo de cierre para esta plantilla'
                : 'VIENA cambió o eliminó el motivo configurado';
            Object.assign(title.style, {fontSize:'18px', fontWeight:'700', marginBottom:'8px'});

            const info = document.createElement('div');
            info.textContent = `Plantilla: ${plantilla.nombre}`;
            Object.assign(info.style, {fontSize:'15px', marginBottom:'6px', lineHeight:'1.4'});

            const anterior = document.createElement('div');
            anterior.textContent = esPrimeraConfiguracion
                ? 'Todavía no hay un motivo guardado para esta tipificación. El que elijas quedará asociado a este contexto.'
                : `Motivo anterior: ${actual}`;
            Object.assign(anterior.style, {fontSize:'15px', color:'#4b5563', marginBottom:'16px', lineHeight:'1.4'});

            const ayuda = document.createElement('div');
            ayuda.textContent = esPrimeraConfiguracion
                ? 'Seleccioná uno de los motivos disponibles en este ticket. La elección se recordará para esta tipificación y no afectará los demás contextos de la plantilla.'
                : 'Seleccioná una opción. El texto también se puede seleccionar y copiar con Ctrl+C.';
            Object.assign(ayuda.style, {fontSize:'15px', marginBottom:'12px', lineHeight:'1.4'});

            const lista = document.createElement('div');
            Object.assign(lista.style, {display:'grid', gap:'8px', marginBottom:'18px'});

            opciones.forEach(opcion => {
                const fila = document.createElement('div');
                fila.tabIndex = 0;
                fila.setAttribute('role', 'button');
                fila.textContent = opcion;
                Object.assign(fila.style, {
                    border:'1px solid #cbd5e1', borderRadius:'8px', padding:'11px 12px',
                    cursor:'pointer', background:'#f8fafc', lineHeight:'1.35',
                    userSelect:'text', WebkitUserSelect:'text'
                });
                fila.addEventListener('mouseenter', () => fila.style.background = '#eef6ff');
                fila.addEventListener('mouseleave', () => fila.style.background = '#f8fafc');
                const elegir = async e => {
                    // Si el usuario está seleccionando texto, no ejecutar la opción.
                    const sel = String(window.getSelection?.() || '');
                    if (e.type === 'click' && sel.trim()) return;
                    const confirmado = await confirmarNuevoMotivo(opcion);
                    if (!confirmado) return;
                    overlay.remove();
                    resolve(opcion);
                };
                fila.addEventListener('click', elegir);
                fila.addEventListener('keydown', e => {
                    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); elegir(e); }
                });
                lista.appendChild(fila);
            });

            const manualLabel = document.createElement('div');
            manualLabel.textContent = 'Otro motivo';
            Object.assign(manualLabel.style, {fontSize:'15px', fontWeight:'700', marginBottom:'7px'});

            const input = document.createElement('input');
            input.type = 'text';
            input.placeholder = 'Escribí el nombre exacto si no está en la lista';
            Object.assign(input.style, {
                boxSizing:'border-box', width:'100%', border:'1px solid #94a3b8',
                borderRadius:'8px', padding:'11px 12px', fontSize:'15px', marginBottom:'14px', lineHeight:'1.4', userSelect:'text', WebkitUserSelect:'text', pointerEvents:'auto'
            });

            const actions = document.createElement('div');
            Object.assign(actions.style, {display:'flex', justifyContent:'flex-end', gap:'10px'});
            const cancelar = document.createElement('button');
            cancelar.type = 'button'; cancelar.textContent = 'Cancelar';
            const aceptar = document.createElement('button');
            aceptar.type = 'button'; aceptar.textContent = 'Usar otro motivo';
            for (const b of [cancelar, aceptar]) Object.assign(b.style, {
                border:'0', borderRadius:'8px', padding:'10px 14px', cursor:'pointer', fontWeight:'700'
            });
            cancelar.style.background = '#e2e8f0';
            aceptar.style.background = '#1976d2'; aceptar.style.color = '#fff';
            cancelar.addEventListener('click', () => { overlay.remove(); resolve(''); });
            aceptar.addEventListener('click', async () => {
                const valor = input.value.trim();
                if (!valor) { input.focus(); return; }
                const confirmado = await confirmarNuevoMotivo(valor);
                if (!confirmado) { input.focus(); return; }
                overlay.remove(); resolve(valor);
            });
            // Input nativo: no interceptar pointer/mouse/focus/input/keydown.
            // El parche anterior frenaba la propagación de todos esos eventos y en
            // VIENA terminaba interfiriendo con la escritura normal. Sólo capturamos
            // Enter para confirmar el texto manual.
            input.addEventListener('keydown', e => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    aceptar.click();
                }
            });
            overlay.addEventListener('click', e => { if (e.target === overlay) { overlay.remove(); resolve(''); } });
            actions.append(cancelar, aceptar);
            card.append(title, info, anterior, ayuda, lista, manualLabel, input, actions);
            overlay.appendChild(card);
            document.body.appendChild(overlay);
        });
    }

    async function seleccionarMotivoConAutorreparacion(plantilla, dialogo) {
        const tipificacion = obtenerTipificacionTareaActual(dialogo);
        const contexto = claveContextoMotivo(tipificacion);
        const estado = await estadoMotivosPlantilla(plantilla);
        const exactoGuardado = contexto ? String(estado.byContext?.[contexto]?.motivo || '').trim() : '';

        let { menu } = await abrirMenuMotivo(dialogo, 10000);
        const opciones = motivosDelMenu(menu);
        if (!opciones.length) {
            throw new Error('VIENA no mostró opciones para Motivo de cambio de estado');
        }

        // 1) Asociación exacta plantilla + tipificación/contexto.
        if (exactoGuardado) {
            const itemExacto = itemMotivoExactoEnMenu(menu, exactoGuardado);
            if (itemExacto) return itemExacto;
        }

        // 2) Si es un contexto nuevo (o el motivo exacto desapareció), buscar motivos
        // ya conocidos de esta plantilla que sigan existiendo en el ticket actual.
        const candidatos = [];
        const vistos = new Set();
        for (const conocido of estado.known || []) {
            const item = itemMotivoExactoEnMenu(menu, conocido);
            const key = normalizarMotivo(item?.textContent || '');
            if (!item || !key || vistos.has(key)) continue;
            vistos.add(key);
            candidatos.push({ texto: String(item.textContent || '').trim(), item });
        }

        if (!candidatos.length && plantilla?.motivoContiene) {
            const itemContiene = itemMotivoContieneEnMenu(menu, plantilla.motivoContiene);
            if (itemContiene) {
                const texto = String(itemContiene.textContent || '').trim();
                candidatos.push({ texto, item: itemContiene });
            }
        }

        // Si hay una sola opción conocida válida, la asociación es inequívoca:
        // aprenderla para esta tipificación y no volver a preguntar.
        if (candidatos.length === 1) {
            if (tipificacion) await guardarAsociacionMotivo(plantilla, tipificacion, candidatos[0].texto);
            return candidatos[0].item;
        }

        // Si VIENA sólo ofrece un motivo, también es una elección inequívoca.
        if (!candidatos.length && opciones.length === 1) {
            const unico = opciones[0];
            if (tipificacion) await guardarAsociacionMotivo(plantilla, tipificacion, unico);
            const item = itemMotivoExactoEnMenu(menu, unico);
            if (item) return item;
        }

        // 3) Ambigüedad real: pedir elección. No reemplazamos globalmente el motivo
        // de la plantilla; guardamos exclusivamente la asociación de este contexto.
        const menuOriginal = menu;
        const estiloAnterior = {
            visibility: menuOriginal.style.visibility,
            pointerEvents: menuOriginal.style.pointerEvents
        };
        menuOriginal.style.visibility = 'hidden';
        menuOriginal.style.pointerEvents = 'none';

        await pausa(0);
        const anteriorParaDialogo = exactoGuardado || estado.legacy || String(plantilla?.motivo || '').trim();
        const nuevo = await elegirMotivoDesdePopup(plantilla, anteriorParaDialogo, opciones);
        if (menuOriginal?.isConnected) {
            menuOriginal.style.visibility = estiloAnterior.visibility;
            menuOriginal.style.pointerEvents = estiloAnterior.pointerEvents;
        }
        await cerrarMenuMotivo(dialogo);

        if (!nuevo || !nuevo.trim()) {
            throw new Error(anteriorParaDialogo
                ? 'Motivo no encontrado y corrección cancelada para ' + plantilla.nombre
                : 'No se configuró un motivo para ' + plantilla.nombre);
        }

        const nuevoLimpio = nuevo.trim();
        ({ menu } = await abrirMenuMotivo(dialogo, 10000));
        const itemNuevo = itemMotivoExactoEnMenu(menu, nuevoLimpio);
        if (!itemNuevo) {
            throw new Error('El motivo elegido ya no aparece entre las opciones actuales de VIENA: "' + nuevoLimpio + '"');
        }

        if (tipificacion) {
            await guardarAsociacionMotivo(plantilla, tipificacion, nuevoLimpio);
        } else {
            // Fallback para un ticket cuyo DOM no exponga todavía la tipificación:
            // conservar compatibilidad v1 sin destruir asociaciones contextuales v2.
            const overrides = await storageGet(MOTIVO_OVERRIDES_KEY);
            overrides[clavePlantilla(plantilla)] = nuevoLimpio;
            await storageSet(MOTIVO_OVERRIDES_KEY, overrides);
        }

        if (exactoGuardado && normalizarMotivo(exactoGuardado) !== normalizarMotivo(nuevoLimpio)) {
            console.warn('[VIENA Plantillas] Motivo contextual actualizado:', {
                plantilla: plantilla.nombre, tipificacion, anterior: exactoGuardado, nuevo: nuevoLimpio
            });
        } else {
            mostrarToastPlantillas(
                tipificacion
                    ? 'Motivo guardado para ' + plantilla.nombre + ' · ' + tipificacion + '.'
                    : 'Motivo guardado para ' + plantilla.nombre + '.',
                'success'
            );
        }
        return itemNuevo;
    }

    let ejecutandoPlantilla = false;


    // ------------------------------------------------------------------
    // FLUJO PRINCIPAL
    // ------------------------------------------------------------------

    async function ejecutarPlantilla(plantilla) {

        if (ejecutandoPlantilla) return;
        ejecutandoPlantilla = true;

        try {
            const btnCambiarEstado = await esperarPorTexto(
                'button span, button', 'Cambiar Estado', true, 3000
            );
            btnCambiarEstado.closest('button').click();

            // VIENA puede mostrar primero el menú de estados o abrir directamente
            // el diálogo. No esperamos un item si el diálogo ya está abierto.
            await pausa(120);

            let dialogo = Array.from(
                document.querySelectorAll('.v-dialog.v-dialog--active, .v-dialog')
            ).find(el =>
                esVisible(el) &&
                normalizarTexto(el.textContent).includes('confirmación de cambio de estado')
            );

            if (!dialogo) {
                const itemEstado = await seleccionarItemVisible(plantilla.estado, 3000);
                itemEstado.click();

                dialogo = await esperarCondicion(() =>
                    Array.from(document.querySelectorAll('.v-dialog.v-dialog--active, .v-dialog'))
                        .find(el =>
                            esVisible(el) &&
                            normalizarTexto(el.textContent)
                                .includes('confirmación de cambio de estado')
                        ) || null,
                    4000
                );
            }

            // Motivo: trabajar siempre con el control exacto del diálogo activo.
            if (plantilla.motivo || plantilla.motivoContiene || plantilla.custom) {
                const itemMotivo = await seleccionarMotivoConAutorreparacion(plantilla, dialogo);
                itemMotivo.click();
                // Esperar a que Vuetify procese la selección antes de completar Mensaje.
                const inicioMotivo = Date.now();
                while (Date.now() - inicioMotivo < 2500) {
                    const control = controlMotivoDelDialogo(dialogo);
                    const menu = menuMotivoDelControl(control);
                    if (!menu) break;
                    await pausa(60);
                }
            }

            const campoMensaje = () => {
                const labels = Array.from(dialogo.querySelectorAll('label'));
                const label = labels.find(el => esVisible(el) && normalizarTexto(el.textContent) === 'mensaje') ||
                    labels.find(el => esVisible(el) && normalizarTexto(el.textContent).includes('mensaje'));
                const cont = label?.closest('.v-input') || label?.parentElement;
                return cont?.querySelector('textarea:not([readonly]), input:not([readonly]), [contenteditable="true"]') ||
                    Array.from(dialogo.querySelectorAll('textarea:not([readonly])')).find(esVisible) || null;
            };

            let textarea = null;
            const inicioMensaje = Date.now();
            while (Date.now() - inicioMensaje < 4000) {
                textarea = campoMensaje();
                if (textarea && esVisible(textarea)) break;
                await pausa(80);
            }
            if (!textarea) throw new Error('No apareció el campo Mensaje después de seleccionar el motivo');

            const mensajeFinal = await mensajeConfigurado(plantilla);
            setValorReactivo(textarea, mensajeFinal);

            const btnConfirmar = await esperarCondicion(() =>
                Array.from(dialogo.querySelectorAll('button'))
                    .find(btn =>
                        esVisible(btn) &&
                        normalizarTexto(btn.textContent) === 'confirmar'
                    ) || null,
                3000
            );

            btnConfirmar.click();

        } catch (error) {
            mostrarToastPlantillas(
                'No se pudo completar automáticamente: ' + error.message + ' Verificá el paso manualmente.',
                'error'
            );
            console.warn('[VIENA Plantillas] Acción no completada:', error);

        } finally {
            ejecutandoPlantilla = false;
        }
    }


    // ------------------------------------------------------------------
    // BOTONES PERSONALES — CADA BOTÓN CONTIENE SU PROPIO MENÚ DE PLANTILLAS
    // ------------------------------------------------------------------

    function confirmarEliminarGrupoPersonalizado(nombre) {
        return new Promise(resolve => {
            document.getElementById('viena-custom-template-confirm-overlay')?.remove();
            const overlay = document.createElement('div');
            overlay.id = 'viena-custom-template-confirm-overlay';
            Object.assign(overlay.style, {
                position:'fixed', inset:'0', zIndex:'2147483647', background:'rgba(15,23,42,.56)',
                display:'flex', alignItems:'center', justifyContent:'center', padding:'20px'
            });
            const card = document.createElement('div');
            Object.assign(card.style, {
                width:'min(520px, 94vw)', background:'#fff', borderRadius:'12px',
                boxShadow:'0 20px 64px rgba(15,23,42,.32)', padding:'22px',
                fontFamily:'Arial, sans-serif', color:'#1f2937'
            });
            aislarSuperficieInteractiva(card);
            const title = document.createElement('div');
            title.textContent = 'Eliminar botón personal';
            Object.assign(title.style,{fontSize:'19px',fontWeight:'800',color:'#183b63',marginBottom:'8px'});
            const body = document.createElement('div');
            body.textContent = `¿Querés eliminar “${nombre}” y todas las plantillas que contiene?`;
            Object.assign(body.style,{fontSize:'15px',lineHeight:'1.45',marginBottom:'18px'});
            const actions = document.createElement('div');
            Object.assign(actions.style,{display:'flex',justifyContent:'flex-end',gap:'9px'});
            const cancel = document.createElement('button'); cancel.type='button'; cancel.textContent='Cancelar';
            const ok = document.createElement('button'); ok.type='button'; ok.textContent='Eliminar';
            Object.assign(cancel.style,{border:'1px solid #cbd5e1',background:'#fff',color:'#334155',borderRadius:'8px',padding:'10px 15px',fontSize:'14px',fontWeight:'700',cursor:'pointer'});
            Object.assign(ok.style,{border:'1px solid #b91c1c',background:'#c62828',color:'#fff',borderRadius:'8px',padding:'10px 15px',fontSize:'14px',fontWeight:'700',cursor:'pointer'});
            const done = value => { overlay.remove(); resolve(value); };
            cancel.addEventListener('click',()=>done(false));
            ok.addEventListener('click',()=>done(true));
            overlay.addEventListener('click',e=>{ if(e.target===overlay) done(false); });
            actions.append(cancel,ok); card.append(title,body,actions); overlay.appendChild(card); document.body.appendChild(overlay); cancel.focus();
        });
    }

    function limpiarMenusGruposPersonalizados() {
        document.querySelectorAll('.viena-custom-template-group-menu').forEach(el => el.remove());
    }

    function crearMenuGrupoPersonalizado(grupo, boton) {
        const menu = document.createElement('div');
        menu.className = 'viena-custom-template-group-menu viena-completar-menu';
        menu.dataset.groupId = grupo.id;
        menu.style.cssText = `
            display:none; position:fixed; top:0; left:0; z-index:2147483647;
            box-sizing:border-box; width:320px; max-width:calc(100vw - 16px); padding:8px 10px;
            background:#fff; border:1px solid rgba(15,23,42,.08); border-radius:12px;
            box-shadow:0 12px 28px rgba(15,23,42,.18),0 2px 7px rgba(15,23,42,.08);
            overflow:hidden; font-family:Arial,Helvetica,sans-serif;
        `;
        aislarSuperficieInteractiva(menu);

        const posicionar = () => {
            const r = boton.getBoundingClientRect();
            let left = r.left;
            if (left + 320 > window.innerWidth - 8) left = window.innerWidth - 328;
            menu.style.left = `${Math.max(8, Math.round(left))}px`;
            menu.style.top = `${Math.round(r.bottom + 6)}px`;
        };

        grupo.plantillas.forEach((plantilla, indice) => {
            const item = document.createElement('div');
            item.className = 'viena-custom-template-group-item viena-completar-menu-item';
            item.setAttribute('role','button'); item.tabIndex=0;
            item.style.cssText = `box-sizing:border-box;min-height:52px;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:0 14px;cursor:pointer;background:#fff;border-bottom:${indice===grupo.plantillas.length-1?'none':'1px solid #e7ebf0'};border-radius:8px;color:#24324a;font:600 14px/1.2 Arial;user-select:none;`;
            const txt=document.createElement('span'); txt.textContent=plantilla.nombre; txt.style.cssText='min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
            const arrow=document.createElement('span'); arrow.textContent='›'; arrow.style.cssText='color:#53627a;font:400 27px/1 Arial;';
            item.append(txt,arrow);
            const on=()=>{item.style.background='#eaf4ff';item.style.color='#173f7a'; if (mostrarEditorPlantillaGlobal) mostrarEditorPlantillaGlobal(plantilla, menu);};
            const off=()=>{item.style.background='#fff';item.style.color='#24324a';};
            item.addEventListener('mouseenter',on); item.addEventListener('focus',on);
            item.addEventListener('mouseleave',off); item.addEventListener('blur',off);
            const ejecutar=e=>{
                e.stopPropagation(); activarFixZoomTemporal(); menu.style.display='none';
                if (ocultarEditorPlantillaGlobal) ocultarEditorPlantillaGlobal();
                ejecutarPlantilla(plantilla);
            };
            item.addEventListener('click',ejecutar);
            item.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();ejecutar(e);}});
            menu.appendChild(item);
        });
        document.body.appendChild(menu);
        boton.addEventListener('pointerdown', activarFixZoomTemporal, true);
        boton.addEventListener('click', e => {
            e.stopPropagation();
            const abrir = menu.style.display === 'none';
            document.querySelectorAll('.viena-custom-template-group-menu').forEach(m => { if (m !== menu) m.style.display='none'; });
            if (abrir) { posicionar(); menu.style.display='block'; }
            else { menu.style.display='none'; if (ocultarEditorPlantillaGlobal) ocultarEditorPlantillaGlobal(); }
            setTimeout(()=>{try{boton.blur();}catch(_){}},0);
        });
        return menu;
    }

    async function sincronizarBotonesPlantillasPersonalizadas() {
        // Compatibilidad: se elimina el antiguo host que creaba un botón por plantilla
        // junto a Crear tarea. v1.3.14 usa un botón-grupo con menú, igual a Completar Tarea.
        document.getElementById('viena-custom-template-buttons')?.remove();
        document.getElementById('viena-custom-template-groups')?.remove();
        limpiarMenusGruposPersonalizados();
        if (!ticketAbierto() || estadoTicketActual() !== 'INICIADA') return;
        if (!customTemplateGroupsCacheListo) await cargarGruposPersonalizados();
        const grupos = gruposPersonalizadosDelUsuario();
        if (!grupos.length) return;
        const panel = document.getElementById('panel-plantillas-viena');
        const gestor = document.getElementById('viena-custom-template-manager-btn');
        if (!panel || !gestor) return;

        const host=document.createElement('div');
        host.id='viena-custom-template-groups';
        Object.assign(host.style,{display:'inline-flex',alignItems:'center',gap:'7px',marginLeft:'7px'});
        for (const grupo of grupos) {
            const btn=document.createElement('button'); btn.type='button';
            btn.className='viena-custom-template-group-btn v-btn v-btn--is-elevated v-btn--has-bg theme--dark v-size--default';
            btn.title=`Botón personal: ${grupo.nombre}`;
            btn.innerHTML=`<span class="v-btn__content">${String(grupo.nombre).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</span>`;
            Object.assign(btn.style,{cursor:'pointer',background:'#355f82',color:'#fff',minWidth:'auto',padding:'0 13px',margin:'0'});
            host.appendChild(btn);
            crearMenuGrupoPersonalizado(grupo, btn);
        }
        panel.insertBefore(host, gestor);
    }

    function aislarSuperficieInteractiva(superficie) {
        if (!superficie || superficie.dataset.vienaInteractiveSurface === '1') return superficie;
        superficie.dataset.vienaInteractiveSurface = '1';

        // Reutilizamos el mismo fix temporal que evita el salto/mini-zoom del menú
        // original de Completar Tarea, pero ahora en CADA interacción de las superficies
        // portalizadas (textarea, inputs y botones incluidos).
        superficie.addEventListener('pointerdown', activarFixZoomTemporal, true);
        superficie.addEventListener('focusin', activarFixZoomTemporal, true);

        // Sólo cortamos propagación hacia VIENA/Vuetify. No preventDefault(): el foco,
        // selección de texto, escritura y click nativo de botones deben seguir intactos.
        for (const tipo of [
            'pointerdown','pointerup','mousedown','mouseup','click','dblclick',
            'keydown','keypress','keyup','input','change','focusin','focusout'
        ]) superficie.addEventListener(tipo, event => event.stopPropagation());
        return superficie;
    }

    async function abrirGestorPlantillasPersonalizadas() {
        if (!customTemplateGroupsCacheListo) await cargarGruposPersonalizados();
        const user=normalizarClaveUsuario(usuarioPlantillasCache);
        if(user==='__sin_usuario__'){
            mostrarToastPlantillas('No pude identificar tu usuario VIENA. Revisá “Usuario VIENA” en el panel de la extensión.','error');
            return;
        }
        document.getElementById('viena-custom-template-manager-overlay')?.remove();
        const overlay=document.createElement('div'); overlay.id='viena-custom-template-manager-overlay';
        Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'2147483647',background:'rgba(15,23,42,.58)',display:'flex',alignItems:'center',justifyContent:'center',padding:'18px'});
        // El backdrop también debe quedar aislado. Si el operador hace varios clicks
        // fuera de la tarjeta, esos eventos no deben llegar al v-dialog de VIENA,
        // porque Vuetify puede reactivar su animación/transform y producir mini-zoom.
        // No usamos preventDefault: el modal sigue siendo persistente y los controles
        // internos conservan foco, selección y escritura normales.
        aislarSuperficieInteractiva(overlay);
        const card=document.createElement('div');
        Object.assign(card.style,{position:'relative',width:'min(980px,96vw)',maxHeight:'92vh',overflow:'auto',background:'#fff',borderRadius:'14px',boxShadow:'0 22px 70px rgba(15,23,42,.34)',padding:'28px',fontFamily:'Arial,sans-serif',color:'#1f2937'});
        aislarSuperficieInteractiva(card);
        const closeTop=document.createElement('button'); closeTop.type='button'; closeTop.setAttribute('aria-label','Cerrar Editor de botones'); closeTop.title='Cerrar'; closeTop.textContent='×'; Object.assign(closeTop.style,{position:'absolute',top:'7px',right:'9px',width:'48px',height:'48px',display:'grid',placeItems:'center',border:'1px solid #cbd5e1',background:'#fff',color:'#475569',borderRadius:'9px',fontSize:'24px',lineHeight:'1',fontWeight:'700',cursor:'pointer',padding:'0',zIndex:'2'}); card.appendChild(closeTop);
        const title=document.createElement('div'); title.textContent='Editor de botones'; Object.assign(title.style,{fontSize:'24px',fontWeight:'800',color:'#173f7a',marginBottom:'5px',paddingRight:'58px'});
        const help=document.createElement('div'); help.textContent='Administrá el botón del sistema y tus botones personales desde un solo lugar. Podés cambiar nombres, editar plantillas y crear nuevos botones sin afectar la función base de cierre.'; Object.assign(help.style,{fontSize:'15px',lineHeight:'1.5',color:'#52657a',marginBottom:'18px'});

        const label=document.createElement('label'); Object.assign(label.style,{display:'grid',gap:'7px',fontSize:'14px',fontWeight:'800',color:'#334155',marginBottom:'15px'});
        const span=document.createElement('span'); span.textContent='Nombre del botón';
        const inputGrupo=document.createElement('input'); inputGrupo.type='text'; inputGrupo.maxLength=28; inputGrupo.placeholder='Ej. CIERRES HFC';
        Object.assign(inputGrupo.style,{boxSizing:'border-box',width:'100%',border:'1px solid #b8c7d9',borderRadius:'8px',padding:'11px 12px',font:'16px/1.45 Arial',color:'#1f2937',outline:'none',background:'#fff'});
        label.append(span,inputGrupo);

        const subt=document.createElement('div'); subt.textContent='Plantillas dentro de este botón'; Object.assign(subt.style,{fontSize:'15px',fontWeight:'800',color:'#173f7a',margin:'4px 0 9px'});
        const templatesHost=document.createElement('div'); Object.assign(templatesHost.style,{display:'grid',gap:'12px'});
        const addTemplate=document.createElement('button'); addTemplate.type='button'; addTemplate.textContent='＋ Agregar plantilla'; Object.assign(addTemplate.style,{justifySelf:'start',marginTop:'10px',border:'1px solid #8fb4d7',background:'#eef6ff',color:'#174f80',borderRadius:'8px',padding:'9px 13px',fontSize:'14px',fontWeight:'800',cursor:'pointer'});
        const estado=document.createElement('div'); Object.assign(estado.style,{minHeight:'20px',fontSize:'13px',fontWeight:'700',color:'#b42318',margin:'10px 0 6px'});
        const actions=document.createElement('div'); Object.assign(actions.style,{display:'flex',justifyContent:'flex-end',gap:'9px',marginBottom:'20px'});
        const cancel=document.createElement('button'); cancel.type='button'; cancel.textContent='Cerrar';
        const save=document.createElement('button'); save.type='button'; save.textContent='Crear botón';
        Object.assign(cancel.style,{border:'1px solid #cbd5e1',background:'#fff',color:'#334155',borderRadius:'8px',padding:'10px 15px',fontSize:'14px',fontWeight:'700',cursor:'pointer'});
        Object.assign(save.style,{border:'1px solid #0f5aa9',background:'#1268c4',color:'#fff',borderRadius:'8px',padding:'10px 17px',fontSize:'14px',fontWeight:'800',cursor:'pointer'});
        actions.append(cancel,save);
        const divider=document.createElement('div'); divider.textContent='Botones disponibles'; Object.assign(divider.style,{borderTop:'1px solid #e2e8f0',paddingTop:'16px',fontSize:'15px',fontWeight:'800',color:'#173f7a',marginBottom:'9px'});
        const list=document.createElement('div'); Object.assign(list.style,{display:'grid',gap:'8px'});
        let editId='';
        let editandoSistema=false;

        function crearFilaPlantilla(datos={}) {
            const row=document.createElement('div'); row.className='viena-custom-group-template-row'; row.dataset.templateId=String(datos.id||'');
            row.dataset.motivoContiene=JSON.stringify(Array.isArray(datos.motivoContiene)?datos.motivoContiene:[]);
            Object.assign(row.style,{border:'1px solid #dbe4ee',borderRadius:'10px',padding:'13px',background:'#f8fbff'});
            const head=document.createElement('div'); Object.assign(head.style,{display:'flex',justifyContent:'space-between',alignItems:'center',gap:'10px',marginBottom:'10px'});
            const heading=document.createElement('div'); heading.textContent='Plantilla'; Object.assign(heading.style,{fontSize:'14px',fontWeight:'800',color:'#243b57'});
            const remove=document.createElement('button'); remove.type='button'; remove.textContent='Quitar'; Object.assign(remove.style,{border:'1px solid #fecaca',background:'#fff',color:'#b91c1c',borderRadius:'7px',padding:'6px 9px',fontSize:'13px',fontWeight:'700',cursor:'pointer'});
            head.append(heading,remove);
            const grid=document.createElement('div'); Object.assign(grid.style,{display:'grid',gridTemplateColumns:'1fr 1fr',gap:'10px'});
            const n=document.createElement('input'); n.type='text'; n.maxLength=32; n.placeholder='Nombre de la plantilla'; n.value=String(datos.nombre||'');
            const m=document.createElement('input'); m.type='text'; m.placeholder='Motivo base opcional - los aprendidos se conservan por tipificación'; m.value=String(datos.motivo||(Array.isArray(datos.motivoContiene)?datos.motivoContiene.join(' | '):''));
            const ta=document.createElement('textarea'); ta.rows=3; ta.placeholder='Mensaje de cierre'; ta.value=String(datos.mensaje||'');
            for(const el of [n,m,ta]) Object.assign(el.style,{boxSizing:'border-box',width:'100%',border:'1px solid #b8c7d9',borderRadius:'8px',padding:'10px 11px',font:'16px/1.45 Arial',color:'#1f2937',outline:'none',background:'#fff'});
            ta.style.gridColumn='1 / -1'; ta.style.minHeight='76px'; ta.style.resize='vertical';
            grid.append(n,m,ta);

            const motivosConocidos=motivosUnicos(Array.isArray(datos.motivosConocidos)?datos.motivosConocidos:[]);
            if(motivosConocidos.length){
                const motivosBox=document.createElement('div');
                motivosBox.className='viena-template-known-reasons';
                Object.assign(motivosBox.style,{gridColumn:'1 / -1',border:'1px solid #dbe4ee',borderRadius:'8px',background:'#fff',padding:'9px 10px'});
                const motivosTitle=document.createElement('div');
                motivosTitle.textContent=`Motivos conocidos (${motivosConocidos.length})`;
                Object.assign(motivosTitle.style,{fontSize:'12px',fontWeight:'800',color:'#52657a',marginBottom:'7px'});
                const motivosList=document.createElement('div');
                Object.assign(motivosList.style,{display:'flex',flexWrap:'wrap',gap:'6px'});
                motivosConocidos.forEach(texto=>{
                    const chip=document.createElement('span');
                    chip.textContent=texto;
                    chip.title=texto;
                    Object.assign(chip.style,{display:'inline-flex',alignItems:'center',maxWidth:'100%',border:'1px solid #b9d4ee',background:'#eef6ff',color:'#174f80',borderRadius:'999px',padding:'5px 8px',fontSize:'12px',fontWeight:'700',lineHeight:'1.25',whiteSpace:'normal'});
                    motivosList.appendChild(chip);
                });
                motivosBox.append(motivosTitle,motivosList);
                grid.appendChild(motivosBox);
            }

            row.append(head,grid); templatesHost.appendChild(row);
            remove.addEventListener('click',()=>{ if(templatesHost.querySelectorAll('.viena-custom-group-template-row').length<=1){mostrarToastPlantillas('El botón necesita al menos una plantilla.','error');return;} row.remove(); });
            return row;
        }
        addTemplate.addEventListener('click',()=>{ const r=crearFilaPlantilla(); r.querySelector('input')?.focus(); });
        const leerPlantillas=()=>Array.from(templatesHost.querySelectorAll('.viena-custom-group-template-row')).map(r=>({id:r.dataset.templateId||'',nombre:r.querySelectorAll('input')[0]?.value||'',motivo:r.querySelectorAll('input')[1]?.value||'',motivoContiene:(()=>{try{return JSON.parse(r.dataset.motivoContiene||'[]')}catch(_){return[]}})(),mensaje:r.querySelector('textarea')?.value||''}));
        const cerrar=()=>overlay.remove();
        // Modal persistente: un click accidental fuera NO debe descartar todo lo escrito.
        // Sólo se cierra con el botón Cerrar o después de guardar correctamente.
        cancel.addEventListener('click',cerrar);
        closeTop.addEventListener('click',cerrar);
        const reset=()=>{editId='';editandoSistema=false;inputGrupo.value='';templatesHost.innerHTML='';crearFilaPlantilla();save.textContent='Crear botón';estado.textContent='';};

        const renderLista=async()=>{
            list.innerHTML='';
            if (!systemCompleteConfigCacheListo) await cargarConfigCompletarSistema();
            const sistema=configCompletarSistemaDelUsuario();
            {
                const row=document.createElement('div');Object.assign(row.style,{display:'grid',gridTemplateColumns:'1fr auto',gap:'10px',alignItems:'center',border:'1px solid #9fc4e6',borderRadius:'9px',padding:'11px 12px',background:'#eef6ff'});
                const info=document.createElement('div');
                const encabezado=document.createElement('div');Object.assign(encabezado.style,{display:'flex',alignItems:'center',gap:'8px'});
                const n=document.createElement('div');n.textContent=sistema.nombre;Object.assign(n.style,{fontSize:'14px',fontWeight:'800',color:'#173f7a'});
                const badge=document.createElement('span');badge.textContent='SISTEMA';Object.assign(badge.style,{fontSize:'10px',fontWeight:'900',letterSpacing:'.05em',color:'#0f5aa9',background:'#fff',border:'1px solid #9fc4e6',borderRadius:'999px',padding:'3px 6px'});
                encabezado.append(n,badge);
                const d=document.createElement('div');d.textContent=`${sistema.plantillas.length} plantilla${sistema.plantillas.length===1?'':'s'} · función base protegida`;Object.assign(d.style,{fontSize:'13px',color:'#52657a',marginTop:'3px'});
                info.append(encabezado,d);
                const bs=document.createElement('div');Object.assign(bs.style,{display:'flex',gap:'6px'});
                const edit=document.createElement('button');edit.type='button';edit.textContent='Editar';
                Object.assign(edit.style,{border:'1px solid #6ea3d3',background:'#fff',color:'#174f80',borderRadius:'7px',padding:'8px 11px',fontSize:'13px',fontWeight:'700',cursor:'pointer'});
                edit.addEventListener('click',async()=>{
                    editandoSistema=true;editId='__system_complete__';inputGrupo.value=sistema.nombre;templatesHost.innerHTML='';estado.textContent='Cargando configuración...';
                    const filas=[];
                    for(const p of sistema.plantillas){
                        const [mensaje,motivo,motivosConocidos]=await Promise.all([
                            mensajeConfigurado(p),
                            motivoConfigurado(p),
                            motivosConfiguradosParaEditor(p)
                        ]);
                        filas.push({...p,mensaje,motivo:motivo || p.motivo || '',motivosConocidos});
                    }
                    filas.forEach(p=>crearFilaPlantilla(p));
                    save.textContent='Guardar cambios';estado.textContent='';inputGrupo.focus();card.scrollTop=0;
                });
                bs.append(edit);row.append(info,bs);list.appendChild(row);
            }

            const grupos=gruposPersonalizadosDelUsuario();
            if(!grupos.length){
                const empty=document.createElement('div');empty.textContent='Todavía no creaste botones personales.';Object.assign(empty.style,{fontSize:'14px',color:'#64748b',padding:'8px 0'});list.appendChild(empty);return;
            }
            for(const g of grupos){
                const row=document.createElement('div');Object.assign(row.style,{display:'grid',gridTemplateColumns:'1fr auto',gap:'10px',alignItems:'center',border:'1px solid #dbe4ee',borderRadius:'9px',padding:'11px 12px',background:'#f8fbff'});
                const info=document.createElement('div'); const n=document.createElement('div');n.textContent=g.nombre;Object.assign(n.style,{fontSize:'14px',fontWeight:'800',color:'#243b57'}); const d=document.createElement('div');d.textContent=`${g.plantillas.length} plantilla${g.plantillas.length===1?'':'s'} en el menú`;Object.assign(d.style,{fontSize:'13px',color:'#64748b',marginTop:'3px'});info.append(n,d);
                const bs=document.createElement('div');Object.assign(bs.style,{display:'flex',gap:'6px'}); const edit=document.createElement('button');edit.type='button';edit.textContent='Editar'; const del=document.createElement('button');del.type='button';del.textContent='Eliminar';
                Object.assign(edit.style,{border:'1px solid #93b5d7',background:'#fff',color:'#174f80',borderRadius:'7px',padding:'8px 11px',fontSize:'13px',fontWeight:'700',cursor:'pointer'}); Object.assign(del.style,{border:'1px solid #fecaca',background:'#fff',color:'#b91c1c',borderRadius:'7px',padding:'8px 11px',fontSize:'13px',fontWeight:'700',cursor:'pointer'});
                edit.addEventListener('click',async()=>{
                    editandoSistema=false;editId=g.id;inputGrupo.value=g.nombre;templatesHost.innerHTML='';estado.textContent='Cargando motivos...';
                    const filas=[];
                    for(const p of g.plantillas){
                        const motivosConocidos=await motivosConfiguradosParaEditor(p);
                        filas.push({...p,motivosConocidos});
                    }
                    filas.forEach(p=>crearFilaPlantilla(p));
                    save.textContent='Guardar cambios';estado.textContent='';inputGrupo.focus();card.scrollTop=0;
                });
                del.addEventListener('click',async()=>{if(!await confirmarEliminarGrupoPersonalizado(g.nombre))return;try{await eliminarGrupoPersonalizado(g.id);if(editId===g.id)reset();await renderLista();await sincronizarBotonesPlantillasPersonalizadas();mostrarToastPlantillas('Botón personal eliminado.','success');}catch(error){mostrarToastPlantillas(error.message||'No se pudo eliminar el botón.','error');}});
                bs.append(edit,del);row.append(info,bs);list.appendChild(row);
            }
        };
        save.addEventListener('click',async()=>{save.disabled=true;estado.textContent='';try{
            if(editandoSistema){
                const guardado=await guardarConfigCompletarSistema({nombre:inputGrupo.value,plantillas:leerPlantillas()});
                mostrarToastPlantillas('Botón del sistema actualizado: '+guardado.nombre,'success');
            }else{
                const guardado=await guardarGrupoPersonalizado({nombre:inputGrupo.value,plantillas:leerPlantillas()},editId);
                await sincronizarBotonesPlantillasPersonalizadas();
                mostrarToastPlantillas((editId?'Botón actualizado: ':'Botón creado: ')+guardado.nombre,'success');
            }
            cerrar();
        }catch(error){estado.textContent=error.message||'No se pudo guardar el botón.';}finally{save.disabled=false;}});
        card.append(title,help,label,subt,templatesHost,addTemplate,estado,actions,divider,list);overlay.appendChild(card);document.body.appendChild(overlay);
        crearFilaPlantilla(); await renderLista(); inputGrupo.focus();
    }

    document.addEventListener('viena:custom-template-groups-changed',()=>{void sincronizarBotonesPlantillasPersonalizadas();});
    document.addEventListener('viena:system-complete-config-changed',()=>{
        const panel=document.getElementById('panel-plantillas-viena');
        document.getElementById('viena-completar-menu-principal')?.remove();
        document.getElementById('viena-completar-message-editor')?.remove();
        panel?.remove();
        mostrarEditorPlantillaGlobal=null;
        ocultarEditorPlantillaGlobal=null;
        setTimeout(crearPanel,0);
    });

    // ------------------------------------------------------------------
    // PANEL FLOTANTE
    // ------------------------------------------------------------------

    function obtenerFilaAccionesTicket() {
        // La fila superior del detalle se identifica sólo por los botones nativos.
        // NO depende de PRE-ASIGNAR ni del instante en que Vue haya montado Estado.
        const botones = Array.from(document.querySelectorAll('button'));
        const crear = botones.find(btn => normalizarTexto(btn.textContent) === 'crear tarea');
        const cambiar = botones.find(btn => normalizarTexto(btn.textContent) === 'cambiar estado');
        if (!crear || !cambiar) return null;
        const filaCrear = crear.closest('.row');
        const filaCambiar = cambiar.closest('.row');
        if (!filaCrear || filaCrear !== filaCambiar) return null;
        // Evitar botones residuales de un ticket ya cerrado en una transición SPA.
        if (!(filaCrear.offsetWidth || filaCrear.offsetHeight || filaCrear.getClientRects().length)) return null;
        return filaCrear;
    }

    function estadoTicketActual() {
        // DOM real confirmado de VIENA: label exacto Estado -> input readonly.
        // El ID input-XXXX es dinámico y no se usa.
        for (const label of Array.from(document.querySelectorAll('.v-text-field__slot > label'))) {
            if (normalizarTexto(label.textContent) !== 'estado') continue;
            const slot = label.closest('.v-text-field__slot');
            const input = slot?.querySelector('input[readonly]');
            if (!input) continue;
            const field = input.closest('.v-input') || slot;
            if (!(field.offsetWidth || field.offsetHeight || field.getClientRects().length)) continue;
            const valor = String(input.value || '').replace(/\s+/g, ' ').trim();
            if (valor) return valor.toUpperCase();
        }
        return '';
    }

    function ticketAbierto() {
        return !!obtenerFilaAccionesTicket();
    }

    function crearPanel() {
        const existente = document.getElementById('panel-plantillas-viena');
        const menuExistente = document.getElementById('viena-completar-menu-principal');
        const editorExistente = document.getElementById('viena-completar-message-editor');
        const personalizadosExistentes = document.getElementById('viena-custom-template-groups') || document.getElementById('viena-custom-template-buttons');

        // Completar Tarea sólo debe existir dentro de un ticket cuyo Estado sea INICIADA.
        if (!ticketAbierto() || estadoTicketActual() !== 'INICIADA') {
            if (existente) existente.remove();
            if (menuExistente) menuExistente.remove();
            if (editorExistente) editorExistente.remove();
            if (personalizadosExistentes) personalizadosExistentes.remove();
            limpiarMenusGruposPersonalizados();
            // El Editor de botones global puede abrirse sin ticket iniciado.
            // No desmontarlo cuando crearPanel limpia la UI contextual del ticket;
            // de lo contrario cualquier refresh/mutación de la SPA lo haría aparecer
            // y desaparecer inmediatamente al abrirlo desde el popup.
            mostrarEditorPlantillaGlobal = null;
            ocultarEditorPlantillaGlobal = null;
            return;
        }

        if (existente) {
            // El panel ya está montado. No resincronizar los botones personales en cada
            // mutación/refresh de la SPA: sincronizar elimina y recrea sus menús portalizados
            // y podía cerrar el menú/editor mientras el operador hacía click o escribía.
            // Los cambios reales de grupos ya disparan su evento dedicado y sincronizan allí.
            return;
        }


        // --------------------------------------------------------------
        // ESTILO EXCLUSIVO DEL BOTÓN DEL PANEL
        // --------------------------------------------------------------

        const estilo =
            document.createElement('style');


        estilo.textContent = `

            #panel-plantillas-viena button,
            #panel-plantillas-viena button:active,
            #panel-plantillas-viena button:focus,
            #panel-plantillas-viena button:hover {

                transform: none !important;
                scale: 1 !important;
                zoom: 1 !important;
                transition: none !important;
                animation: none !important;
                outline: none !important;
            }

            /* Las superficies propias viven portalizadas en <body>, fuera del panel.
               Aislamos su escala para que focus/click no reactive transformaciones del
               diálogo Vuetify ni el efecto de mini-zoom que ya se corrigió en el panel. */
            .viena-completar-menu,
            .viena-completar-menu *,
            #viena-completar-message-editor,
            #viena-completar-message-editor *,
            #viena-custom-template-manager-overlay,
            #viena-custom-template-manager-overlay *,
            .viena-custom-template-group-menu,
            .viena-custom-template-group-menu * {
                transform: none !important;
                scale: 1 !important;
                zoom: 1 !important;
                transition: none !important;
                animation: none !important;
                -webkit-text-size-adjust: 100% !important;
            }

        `;


        document.head.appendChild(estilo);


        // --------------------------------------------------------------
        // PANEL
        // --------------------------------------------------------------

        const panel =
            document.createElement('div');


        panel.id =
            'panel-plantillas-viena';


        panel.style.cssText = `

            position: relative;
            display: inline-flex;
            align-items: center;
            overflow: visible;
            z-index: 999999;
            font-family: Arial, sans-serif;

        `;


        // --------------------------------------------------------------
        // BOTÓN COMPLETAR TAREA
        // --------------------------------------------------------------

        const boton =
            document.createElement('button');


        boton.type = 'button';

        boton.className = 'viena-completar-top-btn mx-3 v-btn v-btn--is-elevated v-btn--has-bg theme--dark v-size--default primary';

        const contenidoCompletar = document.createElement('span');
        contenidoCompletar.className = 'v-btn__content';
        const iconoCompletar = document.createElement('span');
        iconoCompletar.setAttribute('aria-hidden', 'true');
        iconoCompletar.style.marginRight = '6px';
        iconoCompletar.textContent = '✓';
        contenidoCompletar.append(iconoCompletar, document.createTextNode(' ' + nombreCompletarActivo() + ' '));
        boton.replaceChildren(contenidoCompletar);


        boton.style.cssText = `
            cursor: pointer;
        `;

        const botonNuevaPlantilla = document.createElement('button');
        botonNuevaPlantilla.type = 'button';
        botonNuevaPlantilla.id = 'viena-custom-template-manager-btn';
        botonNuevaPlantilla.className = 'viena-custom-template-manager-btn v-btn v-btn--is-elevated v-btn--has-bg theme--dark v-size--default';
        botonNuevaPlantilla.innerHTML = '<span class="v-btn__content"><span aria-hidden="true" style="margin-right:5px">✎</span> Editor de botones </span>';
        botonNuevaPlantilla.title = 'Administrar Completar Tarea y tus botones personales';
        Object.assign(botonNuevaPlantilla.style, {
            cursor:'pointer', background:'#355f82', color:'#fff', marginLeft:'7px'
        });
        botonNuevaPlantilla.addEventListener('pointerdown', activarFixZoomTemporal, true);
        botonNuevaPlantilla.addEventListener('click', e => {
            e.stopPropagation();
            activarFixZoomTemporal();
            void abrirGestorPlantillasPersonalizadas();
            setTimeout(() => { try { botonNuevaPlantilla.blur(); } catch (_) {} }, 0);
        });


        // --------------------------------------------------------------
        // MENÚ
        // --------------------------------------------------------------

        const menu =
            document.createElement('div');


        menu.id = 'viena-completar-menu-principal';
        menu.className = 'viena-completar-menu';
        menu.style.cssText = `
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            bottom: auto;
            right: auto;
            z-index: 2147483647;
            box-sizing: border-box;
            width: 320px;
            max-width: calc(100vw - 16px);
            padding: 8px 10px;
            background: #ffffff;
            border: 1px solid rgba(15, 23, 42, 0.08);
            border-radius: 12px;
            box-shadow: 0 12px 28px rgba(15, 23, 42, 0.18), 0 2px 7px rgba(15, 23, 42, 0.08);
            overflow: hidden;
            font-family: Arial, Helvetica, sans-serif;
        `;


        // --------------------------------------------------------------
        // PREVISUALIZACIÓN / EDICIÓN DEL MENSAJE
        // --------------------------------------------------------------

        const editorMensaje = document.createElement('div');
        editorMensaje.id = 'viena-completar-message-editor';
        editorMensaje.className = 'viena-completar-message-editor';
        editorMensaje.style.cssText = `
            display: none;
            position: fixed;
            z-index: 2147483647;
            box-sizing: border-box;
            width: 500px;
            max-width: calc(100vw - 16px);
            padding: 18px;
            background: #ffffff;
            border: 1px solid #cbd8e6;
            border-top: 4px solid #1769aa;
            border-radius: 12px;
            box-shadow: 0 14px 34px rgba(15, 35, 60, .22);
            font-family: Arial, Helvetica, sans-serif;
            color: #24324a;
        `;

        const editorTitulo = document.createElement('div');
        editorTitulo.style.cssText = 'font-size:17px;font-weight:800;color:#173f7a;margin-bottom:4px;';

        const editorAyuda = document.createElement('div');
        editorAyuda.textContent = 'Mensaje que se completará en la tarea. Podés personalizarlo y guardarlo para tus próximos cierres.';
        editorAyuda.style.cssText = 'font-size:13px;line-height:1.45;color:#64748b;margin-bottom:9px;';

        const editorTextarea = document.createElement('textarea');
        editorTextarea.rows = 7;
        editorTextarea.style.cssText = `
            box-sizing: border-box;
            width: 100%;
            min-height: 150px;
            resize: vertical;
            border: 1px solid #b8c7d9;
            border-radius: 8px;
            padding: 10px 11px;
            font: 16px/1.45 Arial, Helvetica, sans-serif;
            color: #1f2937;
            background: #fff;
            outline: none;
        `;

        const editorEstado = document.createElement('div');
        editorEstado.style.cssText = 'min-height:18px;margin-top:6px;font-size:12px;font-weight:700;color:#64748b;';

        const editorAcciones = document.createElement('div');
        editorAcciones.style.cssText = 'display:flex;justify-content:flex-end;gap:8px;margin-top:10px;';

        const btnRestaurarMensaje = document.createElement('button');
        btnRestaurarMensaje.type = 'button';
        btnRestaurarMensaje.textContent = 'Restaurar original';
        btnRestaurarMensaje.style.cssText = 'border:1px solid #b8c7d9;background:#fff;color:#334155;border-radius:7px;padding:8px 10px;font:700 14px Arial;cursor:pointer;';

        const btnGuardarMensaje = document.createElement('button');
        btnGuardarMensaje.type = 'button';
        btnGuardarMensaje.textContent = 'Guardar mensaje';
        btnGuardarMensaje.style.cssText = 'border:1px solid #0f5aa9;background:#1268c4;color:#fff;border-radius:7px;padding:8px 12px;font:700 14px Arial;cursor:pointer;';

        editorAcciones.append(btnRestaurarMensaje, btnGuardarMensaje);
        editorMensaje.append(editorTitulo, editorAyuda, editorTextarea, editorEstado, editorAcciones);
        aislarSuperficieInteractiva(editorMensaje);
        document.body.appendChild(editorMensaje);

        let plantillaEditorActiva = null;
        let tokenEditor = 0;
        let timerOcultarEditor = 0;

        const cancelarOcultarEditor = () => {
            if (timerOcultarEditor) clearTimeout(timerOcultarEditor);
            timerOcultarEditor = 0;
        };

        const ocultarEditor = () => {
            cancelarOcultarEditor();
            editorMensaje.style.display = 'none';
            plantillaEditorActiva = null;
        };

        const programarOcultarEditor = () => {
            cancelarOcultarEditor();
            timerOcultarEditor = setTimeout(() => {
                const tieneFoco = editorMensaje.contains(document.activeElement);
                if (!editorMensaje.matches(':hover') && !tieneFoco) ocultarEditor();
            }, 420);
        };

        let menuEditorAncla = menu;
        const posicionarEditor = () => {
            if (editorMensaje.style.display === 'none') return;
            const mr = (menuEditorAncla || menu).getBoundingClientRect();
            const er = editorMensaje.getBoundingClientRect();
            const gap = 8;
            let left = mr.right + gap;
            if (left + er.width > window.innerWidth - 8) left = mr.left - er.width - gap;
            left = Math.max(8, Math.min(left, window.innerWidth - er.width - 8));
            let top = mr.top;
            if (top + er.height > window.innerHeight - 8) top = window.innerHeight - er.height - 8;
            editorMensaje.style.left = `${Math.max(8, Math.round(left))}px`;
            editorMensaje.style.top = `${Math.max(8, Math.round(top))}px`;
        };

        const mostrarEditor = async (plantilla, menuAncla = menu) => {
            cancelarOcultarEditor();
            menuEditorAncla = menuAncla || menu;
            const token = ++tokenEditor;
            plantillaEditorActiva = plantilla;
            editorTitulo.textContent = plantilla.nombre + ' · Mensaje de cierre';
            editorEstado.textContent = 'Cargando mensaje...';
            editorTextarea.value = '';
            editorMensaje.style.display = 'block';
            posicionarEditor();
            const valor = await mensajeConfigurado(plantilla);
            if (token !== tokenEditor || plantillaEditorActiva !== plantilla) return;
            editorTextarea.value = valor;
            const personalizado = valor !== String(plantilla.mensaje || '').trim();
            editorEstado.textContent = personalizado ? 'Mensaje personalizado guardado para tu usuario.' : 'Usando el mensaje predeterminado.';
            posicionarEditor();
        };

        mostrarEditorPlantillaGlobal = mostrarEditor;
        ocultarEditorPlantillaGlobal = ocultarEditor;

        editorMensaje.addEventListener('mouseenter', cancelarOcultarEditor);
        editorMensaje.addEventListener('mouseleave', programarOcultarEditor);
        editorMensaje.addEventListener('focusin', cancelarOcultarEditor);
        editorMensaje.addEventListener('focusout', programarOcultarEditor);

        btnGuardarMensaje.addEventListener('click', async () => {
            if (!plantillaEditorActiva) return;
            const plantilla = plantillaEditorActiva;
            const texto = editorTextarea.value;
            btnGuardarMensaje.disabled = true;
            try {
                const guardado = await guardarMensajePersonalizado(plantilla, texto);
                editorTextarea.value = guardado;
                editorEstado.textContent = 'Mensaje personalizado guardado para tu usuario.';
                mostrarToastPlantillas('Mensaje de ' + plantilla.nombre + ' guardado para tus próximos cierres.', 'success');
            } catch (error) {
                mostrarToastPlantillas(error.message || 'No se pudo guardar el mensaje.', 'error');
            } finally {
                btnGuardarMensaje.disabled = false;
            }
        });

        btnRestaurarMensaje.addEventListener('click', async () => {
            if (!plantillaEditorActiva) return;
            const plantilla = plantillaEditorActiva;
            btnRestaurarMensaje.disabled = true;
            try {
                const original = await restaurarMensajePredeterminado(plantilla);
                editorTextarea.value = original;
                editorEstado.textContent = 'Se restauró el mensaje predeterminado.';
                mostrarToastPlantillas('Mensaje predeterminado restaurado.', 'success');
            } catch (_) {
                mostrarToastPlantillas('No se pudo restaurar el mensaje predeterminado.', 'error');
            } finally {
                btnRestaurarMensaje.disabled = false;
            }
        });

        editorTextarea.addEventListener('keydown', e => {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                btnGuardarMensaje.click();
            }
        });

        // --------------------------------------------------------------
        // ITEMS DE LAS PLANTILLAS
        // --------------------------------------------------------------

        const plantillasActivas = plantillasCompletarActivas();
        plantillasActivas.forEach((plantilla, indice) => {
            const item = document.createElement('div');
            item.className = 'viena-completar-menu-item';
            item.setAttribute('role', 'button');
            item.tabIndex = 0;
            item.style.cssText = `
                box-sizing: border-box;
                min-height: 52px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 14px;
                padding: 0 14px;
                cursor: pointer;
                background: #ffffff;
                border-bottom: ${indice === plantillasActivas.length - 1 ? 'none' : '1px solid #e7ebf0'};
                border-radius: 8px;
                color: #24324a;
                font-family: Arial, Helvetica, sans-serif;
                font-size: 14px;
                font-weight: 600;
                line-height: 1.2;
                letter-spacing: 0.01em;
                user-select: none;
                transition: background-color 90ms ease, color 90ms ease;
            `;

            const texto = document.createElement('span');
            texto.textContent = plantilla.nombre;
            texto.style.cssText = `
                min-width: 0;
                flex: 1 1 auto;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            `;

            const flecha = document.createElement('span');
            flecha.textContent = '›';
            flecha.setAttribute('aria-hidden', 'true');
            flecha.style.cssText = `
                flex: 0 0 auto;
                color: #53627a;
                font-family: Arial, Helvetica, sans-serif;
                font-size: 27px;
                font-weight: 400;
                line-height: 1;
                margin-top: -2px;
            `;

            item.append(texto, flecha);

            const activarHover = () => {
                item.style.background = '#eaf4ff';
                item.style.color = '#173f7a';
            };
            const quitarHover = () => {
                item.style.background = '#ffffff';
                item.style.color = '#24324a';
            };
            item.addEventListener('mouseenter', () => {
                activarHover();
                mostrarEditor(plantilla);
            });
            item.addEventListener('mouseleave', () => {
                quitarHover();
                programarOcultarEditor();
            });
            item.addEventListener('focus', () => {
                activarHover();
                mostrarEditor(plantilla);
            });
            item.addEventListener('blur', () => {
                quitarHover();
                programarOcultarEditor();
            });

            const ejecutar = (e) => {
                e.stopPropagation();
                activarFixZoomTemporal();
                menu.style.display = 'none';
                ocultarEditor();
                ejecutarPlantilla(plantilla);
            };
            item.addEventListener('click', ejecutar);
            item.addEventListener('keydown', (e) => {
                if (e.key !== 'Enter' && e.key !== ' ') return;
                e.preventDefault();
                ejecutar(e);
            });

            menu.appendChild(item);
        });


        // --------------------------------------------------------------
        // FIX ZOOM
        //
        // Se activa en POINTERDOWN:
        // justo cuando presionás nuestro botón.
        //
        // Para ese momento el diálogo de VIENA ya existe y está
        // completamente cargado.
        // --------------------------------------------------------------

        boton.addEventListener(
            'pointerdown',
            () => {

                activarFixZoomTemporal();

            },
            true
        );


        // --------------------------------------------------------------
        // ABRIR / CERRAR MENÚ
        // --------------------------------------------------------------

        boton.onclick = (e) => {

            e.stopPropagation();

            const abrir = menu.style.display === 'none';
            if (abrir) {
                const r = boton.getBoundingClientRect();
                menu.style.left = `${Math.max(8, Math.round(r.left))}px`;
                menu.style.top = `${Math.round(r.bottom + 6)}px`;
                menu.style.display = 'block';
            } else {
                menu.style.display = 'none';
                ocultarEditor();
            }
            setTimeout(() => { try { boton.blur(); } catch (_) {} }, 0);
        };


        // Portal al body: dentro del v-banner/v-dialog el menú era recortado por
        // overflow del contenedor aunque tuviera z-index alto. En body + fixed queda
        // siempre visible debajo del botón.
        document.body.appendChild(menu);

        panel.append(boton, botonNuevaPlantilla);

        // Completar Tarea se agrega al FINAL de la fila nativa de acciones del ticket.
        // No depende de PRE-ASIGNAR. RESINCRONIZAR usa position:absolute, por lo que
        // appendChild mantiene Completar como último botón del flujo normal de la fila.
        const filaAcciones = obtenerFilaAccionesTicket();
        if (!filaAcciones) {
            panel.remove();
            return;
        }
        filaAcciones.appendChild(panel);
        void sincronizarBotonesPlantillasPersonalizadas();


        // --------------------------------------------------------------
        // CLICK FUERA
        // --------------------------------------------------------------

        document.addEventListener(
            'click',
            (e) => {

                const dentroSuperficiePropia = e.target?.closest?.(
                    '#panel-plantillas-viena, .viena-completar-menu, #viena-completar-message-editor, #viena-custom-template-manager-overlay, #viena-custom-template-groups, .viena-custom-template-group-menu'
                );
                if (!dentroSuperficiePropia) {
                    menu.style.display = 'none';
                    document.querySelectorAll('.viena-custom-template-group-menu').forEach(m => m.style.display = 'none');
                    ocultarEditor();
                }
            }
        );
    }


    // Acceso global desde el popup de la extensión. No depende de ticketAbierto()
    // ni del Estado INICIADA: sólo reutiliza el mismo editor y el mismo storage.
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
        if (msg?.type !== 'VIENA_OPEN_BUTTON_EDITOR') return;
        (async () => {
            await abrirGestorPlantillasPersonalizadas();
            return { ok: true };
        })().then(sendResponse).catch(error => sendResponse({
            ok: false,
            detail: String(error?.message || error || 'No se pudo abrir el Editor de botones.')
        }));
        return true;
    });

    // ------------------------------------------------------------------
    // INICIAR
    // ------------------------------------------------------------------

    crearPanel();


    // VIENA es SPA:
    // si reconstruye partes del DOM, recuperamos el panel.

    let timerPanel = null;
    // El módulo principal avisa cada detección SPA; esto evita depender del instante
    // exacto en que Vue creó el input Estado.
    document.addEventListener('viena:ui-refresh', () => {
        clearTimeout(timerPanel);
        timerPanel = setTimeout(crearPanel, 0);
    });
    new MutationObserver(mutations => {
        const esSuperficiePropia = node => {
            const el = node?.nodeType === 1 ? node : node?.parentElement;
            return !!el?.closest?.(
                '#panel-plantillas-viena, .viena-completar-menu, #viena-completar-message-editor, ' +
                '#viena-custom-template-manager-overlay, #viena-custom-template-confirm-overlay, ' +
                '#viena-custom-template-groups, .viena-custom-template-group-menu'
            );
        };
        const relevante = mutations.some(m => {
            const target = m.target?.nodeType === 1 ? m.target : m.target?.parentElement;
            if (esSuperficiePropia(target)) return false;
            if (m.type === 'childList') {
                const nodos = [...m.addedNodes, ...m.removedNodes];
                if (!nodos.length) return false;
                // Si el único cambio fue montar/desmontar UI propia portalizada en body,
                // no reejecutar crearPanel. Esto evita el ciclo sync -> DOM -> sync.
                if (nodos.every(esSuperficiePropia)) return false;
                return true;
            }
            // Sólo observar cambios de value: permite reaccionar al Estado sin
            // volver a escuchar los miles de cambios de style/class de Vuetify.
            return m.type === 'attributes' && m.attributeName === 'value';
        });
        if (!relevante) return;
        clearTimeout(timerPanel);
        timerPanel = setTimeout(crearPanel, 35);
    }).observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['value']
    });

    // Vue puede cambiar input.value como propiedad JS sin mutar el atributo value.
    // Safety watcher mínimo y acotado al detalle visible; crearPanel es idempotente.
    let ultimoEstadoCompletar = '';
    setInterval(() => {
        if (!ticketAbierto()) {
            ultimoEstadoCompletar = '';
            return;
        }
        const estado = estadoTicketActual();
        const panelExiste = !!document.getElementById('panel-plantillas-viena');
        if (estado !== ultimoEstadoCompletar || (estado === 'INICIADA' && !panelExiste)) {
            ultimoEstadoCompletar = estado;
            crearPanel();
        }
    }, 50);

})();

// ============================================================================
// ASIGNACIONES — plantillas de Tipificación de tarea (Tareas Internas)
// ============================================================================
(() => {
    'use strict';

    if (window.__VIENA_ASSIGNMENTS_UI_V2__) return;
    window.__VIENA_ASSIGNMENTS_UI_V2__ = true;

    // Catálogo compartido incluido en la extensión. Cada operador puede crear
    // overrides locales (nombre/códigos) sin modificar la plantilla base del resto.
    const SHARED_ASSIGNMENTS = [
        {
            id: 'diagnos-caidas',
            name: 'Diagnos Caídas',
            codes: ['DCE','DCF','DSA','CSH','FEV','CSF','CHZ','CEH','DEF','SDH','EVT','CMH','DFF'],
            shared: true
        }
    ];

    const STORAGE_KEY = 'viena_assignments_templates_v2';
    const BTN_ID = 'viena-assignments-header-btn';
    const BTN_LABEL_ID = 'viena-assignments-header-label';
    const MENU_ID = 'viena-assignments-menu';
    const LIST_ID = 'viena-assignments-list';
    const EDITOR_ID = 'viena-assignments-editor';
    const STATUS_ID = 'viena-assignments-status';
    const LOAD_EVENT = 'VIENA_NOC_TYPIFICATIONS_PROGRESS';
    const LOAD_REQUEST_EVENT = 'VIENA_NOC_TYPIFICATIONS_PROGRESS_REQUEST';

    let applying = false;
    let refreshTimer = 0;
    let storeLoaded = false;
    let store = { custom: [], overrides: {}, hidden: [] };
    let queuedAction = null;
    let editorState = null;
    const typificationLabels = new Map();
    // Estado efímero de intención: distingue una plantilla activada por click
    // de otra que sólo quedó completa por solapamiento de códigos.
    const explicitlyActivatedTemplates = new Set();
    let loadState = {
        seen: false,
        ready: false,
        page: 0,
        totalPages: 17,
        startedAt: 0,
        lastProgressAt: 0,
        finishedAt: 0,
        fallbackTimer: 0
    };

    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

    function internalTasksView() {
        if (!/^\/tasks\/intern(?:\/|$)/.test(location.pathname)) return false;
        return [...document.querySelectorAll('header .v-toolbar__title')]
            .some(el => /TAREAS\s*\|\s*TAREAS INTERNAS|TAREAS INTERNAS/i.test(el.textContent || ''));
    }

    function storageGet(key) {
        return new Promise(resolve => {
            try {
                chrome.storage.local.get([key], data => {
                    const err = chrome.runtime?.lastError;
                    if (err) return resolve(null);
                    resolve(data?.[key] ?? null);
                });
            } catch (_) { resolve(null); }
        });
    }

    function storageSet(key, value) {
        return new Promise(resolve => {
            try {
                chrome.storage.local.set({ [key]: value }, () => resolve(!chrome.runtime?.lastError));
            } catch (_) { resolve(false); }
        });
    }

    function normalizeCodes(codes) {
        const out = [];
        const seen = new Set();
        for (const raw of Array.isArray(codes) ? codes : []) {
            const code = String(raw || '').trim().toUpperCase();
            if (!/^[A-Z0-9]{2,8}$/.test(code) || seen.has(code)) continue;
            seen.add(code);
            out.push(code);
        }
        return out;
    }

    function normalizeLabelMap(raw, codes = []) {
        const allowed = new Set(normalizeCodes(codes));
        const out = {};
        if (!raw || typeof raw !== 'object') return out;
        for (const [key, value] of Object.entries(raw)) {
            const code = String(key || '').trim().toUpperCase();
            const label = String(value || '').replace(/\s+/g, ' ').trim();
            if (!allowed.has(code) || !label) continue;
            out[code] = label.slice(0, 220);
        }
        return out;
    }

    function rememberTypificationLabel(code, label) {
        const c = String(code || '').trim().toUpperCase();
        const l = String(label || '').replace(/\s+/g, ' ').trim();
        if (!/^[A-Z0-9]{2,8}$/.test(c) || !l) return;
        typificationLabels.set(c, l.slice(0, 220));
    }

    function rememberOptionsFromList(list) {
        if (!list) return;
        for (const option of list.querySelectorAll('[role="option"]')) {
            const text = String(option.textContent || '').replace(/\s+/g, ' ').trim();
            const m = text.match(/^\(\s*([A-Z0-9]{2,8})\s*\)\s*(.*)$/i);
            if (!m) continue;
            rememberTypificationLabel(m[1], m[2] || text);
        }
    }

    function captureLabelsForCodes(codes, seed = {}) {
        const normalized = normalizeCodes(codes);
        const out = normalizeLabelMap(seed, normalized);

        const field = getTypificationField();
        const list = listboxForField(field);
        if (list) rememberOptionsFromList(list);

        for (const code of normalized) {
            const known = typificationLabels.get(code);
            if (known) out[code] = known;
        }
        return out;
    }

    function slugify(value) {
        return String(value || '')
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
            .slice(0, 48) || `plantilla-${Date.now()}`;
    }

    async function loadStore() {
        if (storeLoaded) return store;
        const raw = await storageGet(STORAGE_KEY);
        if (raw && typeof raw === 'object') {
            store = {
                custom: Array.isArray(raw.custom) ? raw.custom.map(t => ({
                    id: String(t?.id || '').trim() || `local-${Date.now()}`,
                    name: String(t?.name || 'Plantilla').trim() || 'Plantilla',
                    codes: normalizeCodes(t?.codes),
                    labels: normalizeLabelMap(t?.labels, t?.codes),
                    shared: false
                })).filter(t => t.codes.length) : [],
                overrides: raw.overrides && typeof raw.overrides === 'object' ? raw.overrides : {},
                hidden: Array.isArray(raw.hidden) ? raw.hidden.map(String) : []
            };
        }
        storeLoaded = true;
        return store;
    }

    async function saveStore() {
        await storageSet(STORAGE_KEY, store);
    }

    function allAssignments() {
        const hidden = new Set(store.hidden || []);
        const shared = SHARED_ASSIGNMENTS
            .filter(t => !hidden.has(t.id))
            .map(base => {
                const ov = store.overrides?.[base.id];
                return {
                    ...base,
                    name: String(ov?.name || base.name).trim() || base.name,
                    codes: normalizeCodes(ov?.codes?.length ? ov.codes : base.codes),
                    labels: normalizeLabelMap(ov?.labels || base.labels || {}, ov?.codes?.length ? ov.codes : base.codes),
                    overridden: !!ov
                };
            });
        return [...shared, ...store.custom.map(t => ({ ...t, shared: false }))];
    }

    function assignmentById(id) {
        return allAssignments().find(t => t.id === id) || null;
    }

    function getTypificationField() {
        const direct = document.querySelector('.v-input[filter-param="taskTypificationCodes"]');
        if (direct) return direct;

        // Fallback resistente a cambios de atributos/IDs de Vuetify: ubica el
        // v-input por el texto visible del filtro. VIENA regenera los IDs en cada carga.
        for (const field of document.querySelectorAll('.v-input')) {
            const text = String(field.textContent || '').replace(/\s+/g, ' ').trim();
            if (/Tipif(?:icaci[oó]n)?\.?\s+de\s+tarea/i.test(text)) return field;
        }
        return null;
    }

    async function ensureTypificationField() {
        let field = getTypificationField();
        if (field) return field;

        const filtersHeader = [...document.querySelectorAll('.v-expansion-panel-header')]
            .find(el => /FILTROS DE TABLA/i.test(el.textContent || ''));
        if (filtersHeader) {
            const panel = filtersHeader.closest('.v-expansion-panel');
            if (!panel?.classList.contains('v-expansion-panel--active')) filtersHeader.click();
            try {
                field = await waitFor(() => getTypificationField(), 1800, 25);
                if (field) return field;
            } catch (_) {}
        }
        throw new Error('No encontré el filtro “Tipificación de tarea”.');
    }

    async function ensureTypificationFieldVisible() {
        const filtersHeader = [...document.querySelectorAll('.v-expansion-panel-header')]
            .find(el => /FILTROS DE TABLA/i.test(el.textContent || ''));
        const panel = filtersHeader?.closest('.v-expansion-panel') || null;
        const wasOpen = !!panel?.classList.contains('v-expansion-panel--active');

        if (filtersHeader && !wasOpen) {
            filtersHeader.click();
            try {
                await waitFor(() => {
                    const f = getTypificationField();
                    const input = f?.querySelector('input[type="text"]');
                    const r = input?.getBoundingClientRect?.();
                    return f && input && r && r.width > 20 && r.height > 10 ? f : null;
                }, 2200, 20);
            } catch (_) {}
        }

        const field = await ensureTypificationField();
        return {
            field,
            restore: () => {
                if (!wasOpen && panel?.classList.contains('v-expansion-panel--active')) {
                    try { filtersHeader?.click(); } catch (_) {}
                }
            }
        };
    }

    function getSelectedCodes() {
        const field = getTypificationField();
        const hidden = field?.querySelector('input[type="hidden"]');
        return new Set(String(hidden?.value || '')
            .split(',')
            .map(v => v.trim().toUpperCase())
            .filter(Boolean));
    }

    function templateState(template) {
        const selected = getSelectedCodes();
        const count = template.codes.filter(code => selected.has(code)).length;
        return { count, total: template.codes.length, active: count === template.codes.length };
    }

    function setStatus(message, type = 'info') {
        const el = document.getElementById(STATUS_ID);
        if (!el) return;
        const palette = {
            info: ['#eef5ff', '#315b86'],
            ok: ['#edf8f1', '#216a42'],
            error: ['#fff1f1', '#a13232'],
            wait: ['#fff8e8', '#805a13']
        }[type] || ['#eef5ff', '#315b86'];
        el.textContent = message || '';
        el.style.background = palette[0];
        el.style.color = palette[1];
        el.style.display = message ? 'block' : 'none';
    }

    function updateHeaderLoadState() {
        const btn = document.getElementById(BTN_ID);
        const label = document.getElementById(BTN_LABEL_ID);
        if (!btn || !label) return;
        if (!loadState.ready) {
            const progress = loadState.page
                ? (loadState.totalPages ? `${loadState.page}/${loadState.totalPages}` : `${loadState.page}`)
                : '';
            label.textContent = progress
                ? `Asignaciones - Cargando ${progress}…`
                : 'Asignaciones - Cargando…';
            btn.title = 'VIENA está cargando las Tipificaciones de tarea. Podés abrir el menú y dejar una plantilla en cola.';
            btn.style.opacity = '.92';
        } else {
            label.textContent = 'Asignaciones ✓';
            btn.title = 'Aplicar y administrar plantillas de Tipificación de tarea';
            btn.style.opacity = '1';
        }
        updateLoadBanner();
    }

    function updateLoadBanner() {
        const banner = document.getElementById('viena-assignments-load-banner');
        if (!banner) return;
        if (loadState.ready) {
            banner.style.display = 'none';
            return;
        }
        banner.style.display = 'block';
        banner.textContent = loadState.page
            ? `VIENA está cargando Tipificaciones de tarea · página ${loadState.page}${loadState.totalPages ? `/${loadState.totalPages}` : ''}…`
            : 'VIENA está cargando Tipificaciones de tarea…';
    }

    async function markLoadReady() {
        if (loadState.ready) return;
        loadState.ready = true;
        loadState.finishedAt = Date.now();
        clearTimeout(loadState.fallbackTimer);
        updateHeaderLoadState();
        refreshTemplateRows();
        if (queuedAction && !applying) {
            const pending = queuedAction;
            queuedAction = null;
            const template = assignmentById(pending.id);
            if (template) {
                setStatus(`Carga completa. Ejecutando ${template.name}…`, 'info');
                await sleep(80);
                void setTemplate(template, pending.enable);
            }
        }
    }

    async function primeTypificationCatalog() {
        if (!internalTasksView() || getTypificationField()) return true;

        const filtersHeader = [...document.querySelectorAll('.v-expansion-panel-header')]
            .find(el => /FILTROS DE TABLA/i.test(el.textContent || ''));
        if (!filtersHeader) return false;

        const panel = filtersHeader.closest('.v-expansion-panel');
        const estabaAbierto = !!panel?.classList.contains('v-expansion-panel--active');
        if (!estabaAbierto) {
            // VIENA sólo inicia la carga paginada de Tipificaciones cuando monta
            // el contenido de Filtros de tabla. Lo hacemos una vez por código y
            // restauramos el panel para no obligar al operador a abrirlo manualmente.
            filtersHeader.click();
        }

        try {
            await waitFor(() => getTypificationField(), 2600, 25);
        } catch (_) {
            return false;
        }

        if (!estabaAbierto && panel?.classList.contains('v-expansion-panel--active')) {
            // Dar un pequeño margen para que Vue/Apollo dispare la primera consulta
            // antes de devolver el panel a su estado original.
            await sleep(180);
            filtersHeader.click();
        }
        return true;
    }

    function scheduleLoadFallback(delay = 700) {
        clearTimeout(loadState.fallbackTimer);
        loadState.fallbackTimer = setTimeout(() => {
            if (loadState.ready || !internalTasksView()) return;
            const now = Date.now();
            const fieldReady = !!getTypificationField();
            const elapsed = loadState.startedAt ? now - loadState.startedAt : 0;

            // IMPORTANTE: desde el primer evento de paginación, la única señal válida
            // de catálogo completo es hasMorePages === false / done === true.
            // No usar silencios ni timeouts: entre páginas VIENA puede quedar más de
            // 1.6 s sin emitir nada y eso fue exactamente lo que liberaba CIERRE antes
            // de tiempo (2/7 en el primer intento, 7/7 cuando la carga ya había acabado).
            if (loadState.seen) {
                scheduleLoadFallback(750);
                return;
            }

            // Fallback sólo para instalaciones donde el bridge de progreso no llegue
            // a emitir ningún evento. Se espera bastante más que antes y sólo se usa
            // si el campo nativo existe. Una vez visto cualquier evento, este camino
            // queda deshabilitado para toda la carga.
            if (fieldReady && elapsed >= 6000) {
                // Nunca liberar por tiempo solamente. Si el bridge no respondió,
                // reactivar la carga y pedir el snapshot acumulado.
                try { document.dispatchEvent(new CustomEvent(LOAD_REQUEST_EVENT)); } catch (_) {}
                void primeTypificationCatalog();
                scheduleLoadFallback(1200);
                return;
            }
            scheduleLoadFallback(750);
        }, delay);
    }

    function resetLoadStateForView() {
        clearTimeout(loadState.fallbackTimer);
        const now = Date.now();
        loadState = { seen: false, ready: false, page: 0, totalPages: 17, startedAt: now, lastProgressAt: 0, finishedAt: 0, fallbackTimer: 0 };

        // Pedir al bridge MAIN el estado acumulado. Así, si VIENA empezó a paginar
        // antes de que este listener estuviera listo, recuperamos currentPage/total
        // y no habilitamos Asignaciones por un falso "no vi eventos".
        try { document.dispatchEvent(new CustomEvent(LOAD_REQUEST_EVENT)); } catch (_) {}

        // No depender de una acción manual sobre “Filtros de tabla”.
        void primeTypificationCatalog();
        scheduleLoadFallback(500);
        updateHeaderLoadState();
    }

    function refreshTemplateRows() {
        const menu = document.getElementById(MENU_ID);
        if (!menu) return;
        const assignments = allAssignments();

        // Si una plantilla explícita dejó de estar completa (por otra plantilla,
        // por un cambio manual en VIENA o por Limpiar filtros), deja de considerarse
        // explícitamente activa. Si vuelve a completarse después, se mostrará como
        // "Incluida" salvo que el operador vuelva a activarla directamente.
        for (const template of assignments) {
            const state = templateState(template);
            if (!state.active) explicitlyActivatedTemplates.delete(template.id);
        }

        for (const template of assignments) {
            const row = menu.querySelector(`[data-viena-assignment="${template.id}"]`);
            if (!row) continue;
            const { count, total, active } = templateState(template);
            const queued = queuedAction?.id === template.id;
            const explicit = active && explicitlyActivatedTemplates.has(template.id);
            const included = active && !explicit;

            row.dataset.active = explicit ? '1' : '0';
            row.dataset.included = included ? '1' : '0';

            if (explicit) {
                row.style.background = '#e9f3ff';
                row.style.borderColor = '#2f7fc5';
            } else if (included) {
                row.style.background = '#f4f8fc';
                row.style.borderColor = '#9ab6cf';
            } else if (queued) {
                row.style.background = '#fff8e8';
                row.style.borderColor = '#d2a94c';
            } else {
                row.style.background = '#fff';
                row.style.borderColor = '#d7e0ea';
            }

            const mark = row.querySelector('.viena-assignment-mark');
            if (mark) {
                mark.textContent = explicit ? '✓' : (included ? '↳' : (queued ? '…' : (count ? '–' : '')));
                mark.style.background = explicit ? '#1976d2'
                    : included ? '#eef5fb'
                    : queued ? '#fff0bf'
                    : count ? '#dbe9f6'
                    : '#fff';
                mark.style.color = explicit ? '#fff'
                    : included ? '#315b86'
                    : '#48657f';
                mark.style.borderColor = explicit ? '#1976d2'
                    : included ? '#7fa4c4'
                    : queued ? '#d2a94c'
                    : '#9fb3c7';
            }

            const meta = row.querySelector('.viena-assignment-meta');
            if (meta) {
                meta.textContent = queued
                    ? 'En cola · se ejecutará al terminar la carga'
                    : explicit
                        ? `${total} seleccionadas`
                        : included
                            ? `Incluida · ${total}/${total} seleccionadas`
                            : (count ? `${count}/${total} seleccionadas` : `${total} tipificaciones`);
            }
        }
    }

    function waitFor(test, timeout = 1800, step = 20) {
        return new Promise((resolve, reject) => {
            const started = performance.now();
            const tick = () => {
                let value = null;
                try { value = test(); } catch (_) {}
                if (value) return resolve(value);
                if (performance.now() - started >= timeout) return reject(new Error('Tiempo de espera agotado.'));
                setTimeout(tick, step);
            };
            tick();
        });
    }

    function listboxForField(field) {
        const combo = field?.querySelector('[role="combobox"][aria-owns]');
        const listId = combo?.getAttribute('aria-owns');
        if (!listId) return null;
        return document.getElementById(listId);
    }

    function nativeSetInputValue(input, value) {
        const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
        descriptor?.set?.call(input, value);
    }

    function setSearchValue(input, value) {
        nativeSetInputValue(input, String(value || ''));
        input.dispatchEvent(new Event('input', { bubbles: true }));
    }

    function clickAutocompleteInput(input) {
        if (!input) return;
        try { input.focus({ preventScroll: true }); } catch (_) { try { input.focus(); } catch (_) {} }
        const r = input.getBoundingClientRect();
        const init = { bubbles: true, cancelable: true, view: window, clientX: r.left + Math.max(1, r.width / 2), clientY: r.top + Math.max(1, r.height / 2), button: 0, buttons: 1 };
        input.dispatchEvent(new MouseEvent('mousedown', init));
        input.dispatchEvent(new MouseEvent('mouseup', { ...init, buttons: 0 }));
        input.dispatchEvent(new MouseEvent('click', { ...init, buttons: 0 }));
    }

    function optionForCode(list, code) {
        rememberOptionsFromList(list);
        const re = new RegExp(`^\\(\\s*${code}\\s*\\)`, 'i');
        return [...list.querySelectorAll('[role="option"]')]
            .find(option => re.test(String(option.textContent || '').trim())) || null;
    }

    async function openTypificationSearch(code) {
        const field = await ensureTypificationField();
        const combo = field.querySelector('[role="combobox"][aria-owns]');
        const search = field.querySelector('input[type="text"]');
        if (!combo || !search) throw new Error('VIENA no expuso el selector de Tipificación de tarea.');

        clickAutocompleteInput(search);
        setSearchValue(search, code);

        const findContext = () => {
            const list = listboxForField(field);
            if (!list) return null;
            const option = optionForCode(list, code);
            return option ? { field, combo, search, list, option } : null;
        };

        // Camino rápido: si VIENA ya tiene esa tipificación en memoria, aparece
        // en pocos milisegundos y seguimos sin agregar delay.
        try {
            return await waitFor(findContext, 450, 12);
        } catch (_) {}

        // Camino lento: algunas tipificaciones no están en el lote/cache actual.
        // En ese caso VIENA resuelve el autocomplete contra su catálogo y puede
        // tardar más de 1.3 s. Es importante NO limpiar/re-escribir el código en
        // ese intervalo porque eso cancela/reinicia la búsqueda (caso ACI/ACE
        // observado en el trace de plantillas creadas por el operador).
        return waitFor(findContext, loadState.ready ? 4800 : 6500, 25);
    }

    function clearTypificationSearch() {
        const field = getTypificationField();
        const search = field?.querySelector('input[type="text"]');
        if (!search || !search.value) return;
        setSearchValue(search, '');
    }

    async function removeSelectedCodeFromChip(code) {
        const normalized = String(code || '').trim().toUpperCase();
        if (!normalized || !getSelectedCodes().has(normalized)) return true;

        const field = await ensureTypificationField();
        const chipCandidates = [...field.querySelectorAll('.v-chip')];
        const codeRe = new RegExp(`(?:^|[\\s(])${normalized}(?:[\\s)]|$)`, 'i');
        const chip = chipCandidates.find(el => codeRe.test(String(el.textContent || '').trim()));
        if (!chip) return false;

        const close = chip.querySelector(
            '.v-chip__close, .v-chip__close i, button[aria-label*="close" i], button[aria-label*="cerrar" i], [role="button"][aria-label*="close" i], [role="button"][aria-label*="cerrar" i]'
        );
        if (!close) return false;

        const clickable = close.closest('.v-chip__close,button,[role="button"]') || close;
        try { clickable.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window, button: 0 })); } catch (_) {}
        try { clickable.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window, button: 0 })); } catch (_) {}
        try { clickable.click(); } catch (_) {}

        try {
            await waitFor(() => !getSelectedCodes().has(normalized), 900, 12);
            return true;
        } catch (_) {
            return false;
        }
    }

    function normalizeSearchToken(value) {
        return String(value || '')
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-zA-Z0-9]+/g, ' ')
            .trim();
    }

    function commonSearchCandidates(template) {
        const out = [];
        const seen = new Set();
        const push = value => {
            const q = normalizeSearchToken(value);
            if (q.length < 4) return;
            const key = q.toLowerCase();
            if (seen.has(key)) return;
            seen.add(key);
            out.push(q);
        };

        // El nombre elegido por el operador suele ser el filtro natural de grupo
        // (ej. CIERRE). Si no coincide, se prueban términos comunes de las etiquetas.
        push(template?.name);

        const labels = template?.labels && typeof template.labels === 'object' ? template.labels : {};
        const tokenSets = [];
        for (const code of normalizeCodes(template?.codes)) {
            const label = labels[code] || typificationLabels.get(code) || '';
            if (!label) continue;
            const tokens = normalizeSearchToken(label).toLowerCase().split(/\s+/)
                .filter(t => t.length >= 4 && !/^\d+$/.test(t));
            if (tokens.length) tokenSets.push(new Set(tokens));
        }
        if (tokenSets.length >= Math.max(2, Math.min(3, normalizeCodes(template?.codes).length))) {
            let common = [...tokenSets[0]];
            for (const set of tokenSets.slice(1)) common = common.filter(t => set.has(t));
            common.sort((a,b) => b.length - a.length);
            common.slice(0, 4).forEach(push);
        }
        return out.slice(0, 5);
    }

    async function tryBulkTemplateSelection(template, shouldBeSelected) {
        const desired = !!shouldBeSelected;
        const codes = normalizeCodes(template?.codes);
        if (codes.length < 2) return false;

        const field = getTypificationField();
        const search = field?.querySelector('input[type="text"]');
        if (!field || !search) return false;

        for (const query of commonSearchCandidates(template)) {
            try {
                clickAutocompleteInput(search);
                setSearchValue(search, query);

                const ctx = await waitFor(() => {
                    const list = listboxForField(field);
                    if (!list) return null;
                    rememberOptionsFromList(list);
                    const found = codes.filter(code => !!optionForCode(list, code));
                    return found.length === codes.length ? { list, found } : null;
                }, 1300, 18);

                // Igual que el trace manual correcto: una sola búsqueda y clicks
                // reales sobre las opciones Vuetify que pertenecen a la plantilla.
                for (const code of codes) {
                    if (getSelectedCodes().has(code) === desired) continue;
                    const option = optionForCode(ctx.list, code);
                    if (!option) throw new Error(`bulk_missing_${code}`);
                    option.click();
                    await waitFor(() => getSelectedCodes().has(code) === desired, 900, 12);
                }
                clearTypificationSearch();
                return codes.every(code => getSelectedCodes().has(code) === desired);
            } catch (_) {
                clearTypificationSearch();
                await sleep(35);
            }
        }
        return false;
    }

    async function openTypificationSearchSmart(code, template = null) {
        const knownLabel = template?.labels?.[code] || typificationLabels.get(code) || '';
        const queries = [];
        const seen = new Set();
        const add = q => {
            q = String(q || '').replace(/\s+/g, ' ').trim();
            if (!q) return;
            const key = q.toLowerCase();
            if (seen.has(key)) return;
            seen.add(key);
            queries.push(q);
        };

        // Primero una consulta corta por código; si VIENA no la resuelve enseguida,
        // usar la descripción conocida del catálogo en lugar de esperar 5 segundos.
        add(code);
        if (knownLabel) {
            add(knownLabel);
            const words = normalizeSearchToken(knownLabel).split(/\s+/).filter(w => w.length >= 5);
            if (words.length) add(words.slice(-2).join(' '));
        }

        let lastError = null;
        for (let i = 0; i < queries.length; i++) {
            const q = queries[i];
            try {
                const field = await ensureTypificationField();
                const combo = field.querySelector('[role="combobox"][aria-owns]');
                const search = field.querySelector('input[type="text"]');
                if (!combo || !search) throw new Error('VIENA no expuso el selector de Tipificación de tarea.');

                clickAutocompleteInput(search);
                setSearchValue(search, q);
                const findContext = () => {
                    const list = listboxForField(field);
                    if (!list) return null;
                    const option = optionForCode(list, code);
                    return option ? { field, combo, search, list, option } : null;
                };
                return await waitFor(findContext, i === 0 && queries.length > 1 ? 420 : 1800, 18);
            } catch (error) {
                lastError = error;
                clearTypificationSearch();
            }
        }
        if (lastError) throw lastError;
        return openTypificationSearch(code);
    }

    async function clickCodeUntilState(code, shouldBeSelected, template = null) {
        const desired = !!shouldBeSelected;

        // Para QUITAR una tipificación ya seleccionada, el chip visible es la
        // fuente más estable: no depende de que el autocomplete vuelva a ofrecer
        // el código. VIENA no devuelve ACI/ACE al buscar aunque estén seleccionadas.
        // Diagnos y el resto conservan el flujo anterior como fallback.
        if (!desired && getSelectedCodes().has(code)) {
            const removed = await removeSelectedCodeFromChip(code);
            if (removed && !getSelectedCodes().has(code)) return true;
        }

        // Una búsqueda sostenida es más estable que tres búsquedas cortas. El
        // segundo intento queda sólo como recuperación ante un cierre/re-render
        // excepcional del autocomplete de VIENA.
        for (let attempt = 0; attempt < 2; attempt++) {
            if (getSelectedCodes().has(code) === desired) return true;
            try {
                const ctx = await openTypificationSearchSmart(code, template);
                const option = ctx.option;
                if (!option) throw new Error(`No apareció ${code}`);
                option.click();
                await waitFor(() => getSelectedCodes().has(code) === desired, 1200, 12);
                clearTypificationSearch();
                // Sólo un frame corto para permitir que Vuetify consolide el siguiente filtro.
                await sleep(16);
                return true;
            } catch (_) {
                clearTypificationSearch();
                if (attempt === 0) await sleep(90);
            }
        }
        return false;
    }

    async function closeNativeTypificationList() {
        const field = getTypificationField();
        const combo = field?.querySelector('[role="combobox"][aria-owns]');
        const input = field?.querySelector('input[type="text"]');

        if (input) {
            // Dejar el buscador vacío y cerrar el menú de Vuetify por el mismo
            // mecanismo que usa un operador: Escape + pérdida de foco.
            if (input.value) setSearchValue(input, '');

            for (const type of ['keydown', 'keyup']) {
                input.dispatchEvent(new KeyboardEvent(type, {
                    key: 'Escape',
                    code: 'Escape',
                    keyCode: 27,
                    which: 27,
                    bubbles: true,
                    cancelable: true
                }));
            }

            try { input.blur(); } catch (_) {}
        }

        // El menú de v-autocomplete vive fuera del expansion-panel. Esperamos a
        // que Vuetify lo retire/oculte; si queda activo, un click real fuera del
        // campo cierra el overlay sin modificar clases ni estado artificialmente.
        const owns = combo?.getAttribute('aria-owns') || '';
        const menuVisible = () => {
            const list = owns ? document.getElementById(owns) : null;
            const menu = list?.closest('.v-menu__content.v-autocomplete__content');
            return !!(menu && menu.isConnected &&
                menu.classList.contains('menuable__content__active') &&
                menu.getClientRects().length);
        };

        const inicio = Date.now();
        while (menuVisible() && Date.now() - inicio < 260) {
            await sleep(20);
        }

        if (menuVisible()) {
            const outside = document.querySelector('#viena-assignments-header-btn') ||
                document.querySelector('main') ||
                document.body;
            try {
                outside?.dispatchEvent(new MouseEvent('mousedown', {
                    bubbles: true, cancelable: true, view: window, button: 0
                }));
                outside?.dispatchEvent(new MouseEvent('mouseup', {
                    bubbles: true, cancelable: true, view: window, button: 0
                }));
                outside?.dispatchEvent(new MouseEvent('click', {
                    bubbles: true, cancelable: true, view: window, button: 0
                }));
            } catch (_) {}
        }
    }

    async function setTemplate(template, enable) {
        if (applying) return;
        if (!loadState.ready) {
            queuedAction = { id: template.id, enable: !!enable };
            setStatus(`${template.name} quedó en cola. Se ejecutará cuando VIENA termine de cargar las tipificaciones.`, 'wait');
            refreshTemplateRows();
            return;
        }

        applying = true;
        refreshTemplateRows();
        setStatus(enable ? `Aplicando ${template.name}…` : `Quitando ${template.name}…`, 'info');

        const failed = [];
        let visibleSession = null;
        try {
            // El trace mostró que el input existe aun plegado, pero queda 0x0 y
            // Vuetify no abre el autocomplete. Mantener Filtros visible durante
            // toda la operación y restaurarlo al final.
            visibleSession = await ensureTypificationFieldVisible();

            const bulkOk = await tryBulkTemplateSelection(template, enable);
            if (!bulkOk) {
                for (const code of template.codes) {
                    const ok = await clickCodeUntilState(code, enable, template);
                    if (!ok) failed.push(code);
                }
            }

            const selected = getSelectedCodes();
            const mismatches = template.codes.filter(code => selected.has(code) !== enable);
            for (const code of mismatches) if (!failed.includes(code)) failed.push(code);

            refreshTemplateRows();
            if (failed.length) {
                setStatus(`VIENA no confirmó: ${failed.join(', ')}. No se forzó ningún estado visual.`, 'error');
            } else {
                if (enable) explicitlyActivatedTemplates.add(template.id);
                else explicitlyActivatedTemplates.delete(template.id);
                // Refrescar después de registrar la intención explícita para que
                // sólo el botón pulsado muestre ✓; los subconjuntos completos
                // por solapamiento se muestran como "Incluida".
                refreshTemplateRows();
                setStatus(enable ? `${template.name} aplicada.` : `${template.name} quitada.`, 'ok');
            }
        } catch (error) {
            setStatus(String(error?.message || error || 'No se pudo aplicar la asignación.'), 'error');
        } finally {
            await closeNativeTypificationList();
            try { visibleSession?.restore?.(); } catch (_) {}
            // El collapse del panel puede provocar un último ciclo de Vuetify;
            // confirmar otra vez que el overlay quedó cerrado.
            await sleep(40);
            await closeNativeTypificationList();
            applying = false;
            refreshTemplateRows();
        }
    }

    function makeButton(text, secondary = false) {
        const b = document.createElement('button');
        b.type = 'button';
        b.textContent = text;
        b.style.cssText = `
            border:${secondary ? '1px solid #cbd5e1' : '1px solid #1976d2'};
            background:${secondary ? '#fff' : '#1976d2'}; color:${secondary ? '#334155' : '#fff'};
            border-radius:8px; padding:8px 10px; font-size:13px; line-height:1.2;
            font-weight:700; cursor:pointer; font-family:Arial,Helvetica,sans-serif;
        `;
        return b;
    }

    function closeEditor() {
        editorState = null;
        const editor = document.getElementById(EDITOR_ID);
        if (editor) editor.style.display = 'none';
    }

    function renderEditor() {
        const editor = document.getElementById(EDITOR_ID);
        if (!editor || !editorState) return;
        editor.innerHTML = '';
        editor.style.display = 'block';

        const title = document.createElement('div');
        title.textContent = editorState.mode === 'create' ? 'Crear desde selección actual' : 'Editar plantilla';
        title.style.cssText = 'font-size:15px;font-weight:800;color:#173f7a;margin-bottom:8px;';

        const label = document.createElement('label');
        label.textContent = 'Nombre';
        label.style.cssText = 'display:block;font-size:13px;font-weight:700;color:#334155;margin-bottom:5px;';
        const input = document.createElement('input');
        input.type = 'text';
        input.value = editorState.name || '';
        input.maxLength = 48;
        input.placeholder = 'Ej.: Diagnos Caídas';
        input.style.cssText = 'width:100%;box-sizing:border-box;border:1px solid #b8c6d6;border-radius:8px;padding:9px 10px;font-size:14px;color:#1f2937;outline:none;font-family:Arial,Helvetica,sans-serif;';
        input.addEventListener('input', () => { editorState.name = input.value; });

        const codeTitle = document.createElement('div');
        codeTitle.style.cssText = 'font-size:13px;font-weight:700;color:#334155;margin:10px 0 6px;';
        codeTitle.textContent = `Tipificaciones (${editorState.codes.length})`;

        const chips = document.createElement('div');
        chips.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;max-height:115px;overflow:auto;padding:2px 1px 4px;';
        for (const code of editorState.codes) {
            const chip = document.createElement('button');
            chip.type = 'button';
            chip.title = `Quitar ${code} de la plantilla`;
            chip.textContent = `${code} ×`;
            chip.style.cssText = 'border:1px solid #c8d6e5;background:#f7fafc;color:#26435f;border-radius:999px;padding:5px 8px;font-size:12px;font-weight:700;cursor:pointer;';
            chip.addEventListener('click', () => {
                editorState.codes = editorState.codes.filter(c => c !== code);
                renderEditor();
            });
            chips.appendChild(chip);
        }
        if (!editorState.codes.length) {
            const empty = document.createElement('div');
            empty.textContent = 'No hay tipificaciones en esta plantilla.';
            empty.style.cssText = 'font-size:12px;color:#7b8794;padding:4px 0;';
            chips.appendChild(empty);
        }

        const replace = makeButton(`Usar selección actual (${getSelectedCodes().size})`, true);
        replace.style.width = '100%';
        replace.style.marginTop = '8px';
        replace.addEventListener('click', () => {
            const selected = [...getSelectedCodes()];
            if (!selected.length) {
                setStatus('No hay Tipificaciones de tarea seleccionadas en VIENA.', 'error');
                return;
            }
            editorState.codes = normalizeCodes(selected);
            editorState.labels = captureLabelsForCodes(editorState.codes, editorState.labels || {});
            renderEditor();
            setStatus(`Se copiaron ${selected.length} tipificaciones de la selección actual.`, 'ok');
        });

        const hint = document.createElement('div');
        hint.textContent = 'Para agregar o quitar varias: ajustá la selección en VIENA y usá “Usar selección actual”. También podés quitar códigos tocando ×.';
        hint.style.cssText = 'font-size:12px;line-height:1.4;color:#64748b;margin-top:7px;';

        const actions = document.createElement('div');
        actions.style.cssText = 'display:flex;gap:7px;justify-content:flex-end;margin-top:11px;flex-wrap:wrap;';
        const cancel = makeButton('Cancelar', true);
        const save = makeButton('Guardar');
        cancel.addEventListener('click', closeEditor);
        save.addEventListener('click', async () => {
            const name = String(editorState.name || '').trim();
            const codes = normalizeCodes(editorState.codes);
            if (!name) return setStatus('Escribí un nombre para la plantilla.', 'error');
            if (!codes.length) return setStatus('La plantilla necesita al menos una tipificación.', 'error');

            if (editorState.mode === 'create') {
                let idBase = `local-${slugify(name)}`;
                let id = idBase;
                let n = 2;
                const ids = new Set(allAssignments().map(t => t.id));
                while (ids.has(id)) id = `${idBase}-${n++}`;
                store.custom.push({ id, name, codes, labels: captureLabelsForCodes(codes, editorState.labels || {}), shared: false });
                await saveStore();
                closeEditor();
                renderAssignmentList();
                setStatus(`${name} creada con ${codes.length} tipificaciones.`, 'ok');
                return;
            }

            const target = assignmentById(editorState.id);
            if (!target) return;
            if (target.shared) {
                store.overrides[target.id] = { name, codes, labels: captureLabelsForCodes(codes, editorState.labels || target.labels || {}) };
            } else {
                const idx = store.custom.findIndex(t => t.id === target.id);
                if (idx >= 0) store.custom[idx] = { ...store.custom[idx], name, codes, labels: captureLabelsForCodes(codes, editorState.labels || target.labels || {}) };
            }
            await saveStore();
            closeEditor();
            renderAssignmentList();
            setStatus(`${name} actualizada.`, 'ok');
        });

        if (editorState.mode === 'edit') {
            const target = assignmentById(editorState.id);
            if (target) {
                const remove = makeButton(target.shared ? 'Ocultar para mí' : 'Eliminar', true);
                remove.style.color = '#9f2f2f';
                remove.style.borderColor = '#e3b7b7';
                remove.addEventListener('click', async () => {
                    if (target.shared) {
                        if (!store.hidden.includes(target.id)) store.hidden.push(target.id);
                        delete store.overrides[target.id];
                    } else {
                        store.custom = store.custom.filter(t => t.id !== target.id);
                    }
                    await saveStore();
                    closeEditor();
                    renderAssignmentList();
                    setStatus(target.shared ? `${target.name} se ocultó sólo para este operador.` : `${target.name} eliminada.`, 'ok');
                });
                actions.appendChild(remove);

                if (target.shared && target.overridden) {
                    const restore = makeButton('Restaurar original', true);
                    restore.addEventListener('click', async () => {
                        delete store.overrides[target.id];
                        await saveStore();
                        closeEditor();
                        renderAssignmentList();
                        setStatus('Plantilla compartida restaurada a su versión original.', 'ok');
                    });
                    actions.appendChild(restore);
                }
            }
        }
        actions.append(cancel, save);
        editor.append(title, label, input, codeTitle, chips, replace, hint, actions);
        setTimeout(() => { try { input.focus({ preventScroll: true }); } catch (_) {} }, 0);
    }

    function openCreateFromCurrent() {
        const codes = [...getSelectedCodes()];
        if (!codes.length) {
            setStatus('Primero seleccioná en VIENA las Tipificaciones de tarea que querés guardar.', 'error');
            return;
        }
        editorState = { mode: 'create', id: null, name: '', codes: normalizeCodes(codes), labels: captureLabelsForCodes(codes) };
        renderEditor();
        setStatus(`Se detectaron ${codes.length} tipificaciones seleccionadas.`, 'info');
    }

    function openEdit(template) {
        editorState = { mode: 'edit', id: template.id, name: template.name, codes: [...template.codes], labels: captureLabelsForCodes(template.codes, template.labels || {}) };
        renderEditor();
    }

    function renderAssignmentList() {
        const list = document.getElementById(LIST_ID);
        if (!list) return;
        list.innerHTML = '';
        const assignments = allAssignments();
        if (!assignments.length) {
            const empty = document.createElement('div');
            empty.textContent = 'No hay plantillas visibles.';
            empty.style.cssText = 'font-size:13px;color:#64748b;padding:10px 3px;';
            list.appendChild(empty);
            return;
        }

        for (const template of assignments) {
            const wrap = document.createElement('div');
            wrap.style.cssText = 'display:grid;grid-template-columns:minmax(0,1fr) 38px;gap:6px;margin-top:7px;';

            const row = document.createElement('button');
            row.type = 'button';
            row.dataset.vienaAssignment = template.id;
            row.style.cssText = `
                width:100%; display:flex; align-items:center; gap:10px; text-align:left;
                border:1px solid #d7e0ea; border-radius:9px; padding:10px 11px;
                background:#fff; color:#24324a; cursor:pointer; font-family:Arial,Helvetica,sans-serif;
                min-height:57px;
            `;
            const mark = document.createElement('span');
            mark.className = 'viena-assignment-mark';
            mark.style.cssText = 'flex:0 0 20px;width:20px;height:20px;border:1px solid #9fb3c7;border-radius:5px;display:inline-flex;align-items:center;justify-content:center;font-weight:900;box-sizing:border-box;';
            const text = document.createElement('span');
            text.style.cssText = 'display:flex;flex-direction:column;min-width:0;';
            const name = document.createElement('span');
            name.textContent = template.name;
            name.style.cssText = 'font-size:14px;font-weight:800;color:#173f7a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
            const meta = document.createElement('span');
            meta.className = 'viena-assignment-meta';
            meta.style.cssText = 'font-size:12px;color:#6b7c8f;margin-top:3px;line-height:1.25;';
            text.append(name, meta);
            row.append(mark, text);
            row.addEventListener('click', e => {
                e.preventDefault();
                e.stopPropagation();
                if (applying) return;
                const current = assignmentById(template.id);
                if (!current) return;
                const state = templateState(current);
                void setTemplate(current, !state.active);
            });

            const edit = document.createElement('button');
            edit.type = 'button';
            edit.textContent = '✎';
            edit.title = `Editar ${template.name}`;
            edit.setAttribute('aria-label', `Editar ${template.name}`);
            edit.style.cssText = 'border:1px solid #d7e0ea;border-radius:9px;background:#f8fafc;color:#315b86;font-size:18px;font-weight:800;cursor:pointer;min-height:57px;';
            edit.addEventListener('click', e => {
                e.preventDefault(); e.stopPropagation();
                openEdit(assignmentById(template.id) || template);
            });
            wrap.append(row, edit);
            list.appendChild(wrap);
        }
        refreshTemplateRows();
    }

    function positionMenu() {
        const btn = document.getElementById(BTN_ID);
        const menu = document.getElementById(MENU_ID);
        if (!btn || !menu || menu.style.display === 'none') return;
        const r = btn.getBoundingClientRect();
        const width = Math.min(390, Math.max(310, window.innerWidth - 16));
        let left = r.left + (r.width / 2) - (width / 2);
        left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
        menu.style.width = `${width}px`;
        menu.style.left = `${Math.round(left)}px`;
        menu.style.top = `${Math.round(r.bottom + 8)}px`;
    }

    function ensureMenu() {
        let menu = document.getElementById(MENU_ID);
        if (menu) return menu;

        menu = document.createElement('div');
        menu.id = MENU_ID;
        menu.style.cssText = `
            display:none; position:fixed; z-index:2147483646; box-sizing:border-box;
            width:370px; max-width:calc(100vw - 16px); padding:12px;
            background:#fff; border:1px solid rgba(15,23,42,.10); border-radius:12px;
            box-shadow:0 12px 28px rgba(15,23,42,.18),0 2px 7px rgba(15,23,42,.08);
            font-family:Arial,Helvetica,sans-serif; color:#24324a; max-height:min(620px,calc(100vh - 90px)); overflow:auto;
        `;

        const title = document.createElement('div');
        title.textContent = 'Asignaciones';
        title.style.cssText = 'font-size:17px;font-weight:800;color:#173f7a;margin:1px 2px 3px;';
        const help = document.createElement('div');
        help.textContent = 'Aplicá plantillas de Tipificación de tarea o creá una usando la selección actual de VIENA.';
        help.style.cssText = 'font-size:13px;line-height:1.4;color:#64748b;margin:0 2px 9px;';

        const loadBanner = document.createElement('div');
        loadBanner.id = 'viena-assignments-load-banner';
        loadBanner.style.cssText = 'display:none;background:#fff8e8;color:#805a13;border:1px solid #f0d79b;border-radius:8px;padding:8px 9px;font-size:12px;line-height:1.35;margin-bottom:9px;';

        const create = makeButton('＋ Crear desde selección actual', true);
        create.style.width = '100%';
        create.style.fontSize = '13px';
        create.style.padding = '9px 10px';
        create.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); openCreateFromCurrent(); });

        const list = document.createElement('div');
        list.id = LIST_ID;
        const editor = document.createElement('div');
        editor.id = EDITOR_ID;
        editor.style.cssText = 'display:none;margin-top:10px;padding:10px;border:1px solid #dbe4ee;border-radius:10px;background:#fbfdff;';

        const status = document.createElement('div');
        status.id = STATUS_ID;
        status.style.cssText = 'display:none;margin-top:9px;border-radius:8px;padding:8px 9px;font-size:12px;line-height:1.4;';

        menu.append(title, help, loadBanner, create, list, editor, status);
        document.body.appendChild(menu);
        renderAssignmentList();
        updateLoadBanner();
        return menu;
    }

    function toggleMenu() {
        const menu = ensureMenu();
        const opening = menu.style.display === 'none';
        menu.style.display = opening ? 'block' : 'none';
        if (opening) {
            if (!editorState) setStatus('', 'info');
            renderAssignmentList();
            updateLoadBanner();
            positionMenu();
        } else {
            closeEditor();
        }
    }

    function ensureHeaderButton() {
        const existing = document.getElementById(BTN_ID);
        if (!internalTasksView()) {
            existing?.remove();
            const menu = document.getElementById(MENU_ID);
            if (menu) menu.style.display = 'none';
            queuedAction = null;
            return;
        }
        if (existing?.isConnected) return;

        const toolbar = [...document.querySelectorAll('header.v-app-bar .v-toolbar__content')]
            .find(el => /TAREAS INTERNAS/i.test(el.textContent || ''));
        if (!toolbar) return;
        if (getComputedStyle(toolbar).position === 'static') toolbar.style.position = 'relative';

        const btn = document.createElement('button');
        btn.id = BTN_ID;
        btn.type = 'button';
        btn.className = 'v-btn v-btn--is-elevated v-btn--has-bg theme--dark v-size--default primary';
        btn.innerHTML = '<span class="v-btn__content"><span aria-hidden="true" style="margin-right:6px">☑</span><span id="viena-assignments-header-label">Asignaciones · cargando…</span></span>';
        btn.style.cssText = `
            position:absolute; left:50%; top:50%; transform:translate(-50%,-50%);
            z-index:4; cursor:pointer; white-space:nowrap; min-width:178px;
            font-size:13px;
        `;
        btn.addEventListener('click', e => {
            e.preventDefault();
            e.stopPropagation();
            toggleMenu();
            setTimeout(() => { try { btn.blur(); } catch (_) {} }, 0);
        });
        toolbar.appendChild(btn);
        updateHeaderLoadState();
    }

    document.addEventListener(LOAD_EVENT, event => {
        const d = event.detail || {};
        const page = Number(d.currentPage || 0);
        const totalPages = Number(d.totalPages || 0);
        for (const item of Array.isArray(d.items) ? d.items : []) {
            rememberTypificationLabel(item?.code, item?.label);
        }
        const now = Date.now();
        if (!loadState.startedAt) loadState.startedAt = now;
        loadState.seen = true;
        loadState.lastProgressAt = now;
        if (Number.isFinite(page) && page > loadState.page) loadState.page = page;
        if (Number.isFinite(totalPages) && totalPages > 0) loadState.totalPages = Math.max(loadState.totalPages || 0, totalPages);
        scheduleLoadFallback(750);
        updateHeaderLoadState();
        if (
            d.done === true ||
            d.hasMorePages === false ||
            (loadState.totalPages > 0 && loadState.page >= loadState.totalPages)
        ) {
            // ÚNICA liberación normal: VIENA confirmó la última página. Damos un
            // margen corto a Vue/Apollo para consolidar el catálogo y recién ahí
            // ejecutamos cualquier plantilla que haya quedado en cola.
            clearTimeout(loadState.fallbackTimer);
            setTimeout(() => { void markLoadReady(); }, 180);
        }
    });

    document.addEventListener('pointerdown', e => {
        const menu = document.getElementById(MENU_ID);
        if (!menu || menu.style.display === 'none' || applying) return;
        if (e.target?.closest?.(`#${MENU_ID}, #${BTN_ID}`)) return;
        const field = getTypificationField();
        const list = listboxForField(field);
        if (list && (e.target === list || list.contains(e.target))) return;
        menu.style.display = 'none';
        closeEditor();
    }, true);

    window.addEventListener('resize', positionMenu, { passive: true });
    window.addEventListener('scroll', positionMenu, { passive: true, capture: true });

    let lastInternal = false;
    function syncViewState() {
        const isInternal = internalTasksView();
        if (isInternal && !lastInternal) resetLoadStateForView();
        if (!isInternal && lastInternal) {
            clearTimeout(loadState.fallbackTimer);
            queuedAction = null;
        }
        lastInternal = isInternal;
        ensureHeaderButton();
        refreshTemplateRows();
        positionMenu();
    }

    document.addEventListener('viena:ui-refresh', () => {
        clearTimeout(refreshTimer);
        refreshTimer = setTimeout(syncViewState, 25);
    });

    const observer = new MutationObserver(mutations => {
        if (!mutations.some(m => [...m.addedNodes, ...m.removedNodes].some(n => n?.nodeType === 1))) return;
        clearTimeout(refreshTimer);
        refreshTimer = setTimeout(syncViewState, 70);
    });
    observer.observe(document.body, { childList: true, subtree: true });

    loadStore().finally(() => {
        syncViewState();
        const menu = document.getElementById(MENU_ID);
        if (menu) renderAssignmentList();
    });
})();
