(function(){
'use strict';
const KEY='viena_usuario';
let lastSent='';
let debounce=null;
function valid(v){return /^[a-z][a-z0-9._-]{2,30}$/i.test(String(v||'').trim())&&!/^(rol|owner)$/i.test(String(v||'').trim());}
function detectar(){
  const seen=[];
  for(const item of Array.from(document.querySelectorAll('.v-list-item__content'))){
    for(const el of Array.from(item.querySelectorAll('.v-list-item__subtitle'))){
      const v=String(el.textContent||'').trim(); if(valid(v)) seen.push(v);
    }
  }
  // Fallback conservador para variantes de layout de VIENA: sólo textos cortos con formato de usuario
  // dentro de menús/listas de cuenta, nunca inputs/tickets/contenido operativo.
  if(!seen.length){
    const roots=document.querySelectorAll('.v-menu__content .v-list-item__subtitle,.v-navigation-drawer .v-list-item__subtitle,.v-toolbar .v-list-item__subtitle');
    for(const el of roots){const v=String(el.textContent||'').trim(); if(valid(v)) seen.push(v);}
  }
  return seen.length?seen[0].toLowerCase():'';
}
async function persist(usuario,reason='auto_detect'){
  if(!usuario) return '';
  await chrome.storage.local.set({[KEY]:usuario,viena_usuario_origen:'auto'}).catch(()=>{});
  if(lastSent!==usuario){
    lastSent=usuario;
    try{await chrome.runtime.sendMessage({type:'VIENA_INSTALL_REGISTRY_SYNC_NOW',reason});}catch(_){ }
  }
  return usuario;
}
async function detectAndPersist(reason='auto_detect'){
  const usuario=detectar(); if(usuario) await persist(usuario,reason); return usuario;
}
function schedule(){clearTimeout(debounce);debounce=setTimeout(()=>void detectAndPersist('dom_detect'),250);}
const current=detectar();
globalThis.VienaUserConfig={current,detectar,detectAndPersist};
if(current) void persist(current,'initial_detect');
else {
  const obs=new MutationObserver(schedule);
  const start=()=>{if(document.documentElement) obs.observe(document.documentElement,{subtree:true,childList:true,characterData:true});};
  start(); setTimeout(()=>obs.disconnect(),20000);
  setTimeout(()=>void detectAndPersist('retry_2s'),2000);
  setTimeout(()=>void detectAndPersist('retry_6s'),6000);
  setTimeout(()=>void detectAndPersist('retry_12s'),12000);
}
// Todo ingreso a VIENA fuerza un heartbeat aun sin usuario; el background intentará detectarlo y,
// si no puede, registrará SIN_DETECTAR en vez de perder por completo la instalación.
setTimeout(()=>{try{chrome.runtime.sendMessage({type:'VIENA_INSTALL_REGISTRY_SYNC_NOW',reason:'viena_page'}).catch(()=>{});}catch(_){}},1500);
if(chrome?.runtime?.onMessage){
  chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
    if(msg?.type!=='VIENA_GET_DETECTED_USER') return;
    detectAndPersist('message_detect').then(usuario=>sendResponse({ok:true,usuario:usuario||''})).catch(()=>sendResponse({ok:true,usuario:''}));
    return true;
  });
}
})();
