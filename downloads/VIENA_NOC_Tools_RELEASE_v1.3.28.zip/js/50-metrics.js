(function () {
    'use strict';

    // =========================================================
    // CONFIGURACIÓN
    // =========================================================

    // Al cargar/recargar Métricas dejamos al operador directamente en la
    // pestaña Estadísticas, que es la vista operativa usada por la extensión.
    // El elemento puede aparecer unos instantes después del document_idle,
    // por eso se reintenta durante una ventana acotada y se hace un solo click.
    let estadisticasAutoActivada = false;
    function activarEstadisticasAlCargar() {
        if (estadisticasAutoActivada) return true;
        const enlace = document.querySelector(
            'li#li_estadisticas > a[href="#tabpanel_estadisticas"], a[href="#tabpanel_estadisticas"][data-toggle="tab"]'
        );
        if (!enlace) return false;
        estadisticasAutoActivada = true;
        try { enlace.click(); } catch (_) {}
        return true;
    }

    function asegurarVistaEstadisticas() {
        if (activarEstadisticasAlCargar()) return;
        let intentos = 0;
        const timer = setInterval(() => {
            intentos += 1;
            if (activarEstadisticasAlCargar() || intentos >= 80) clearInterval(timer);
        }, 250);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', asegurarVistaEstadisticas, { once: true });
    } else {
        asegurarVistaEstadisticas();
    }

    let MI_USUARIO = '';

    // La identidad propia sigue usando el azul histórico. Para el resto de
    // operadores se conserva un color estable por usuario para que dos
    // banderas de personas distintas no queden visualmente iguales.
    const BANDERA_COLOR_MAP_KEY = 'metricas_bandera_colores_usuarios_v1';
    const PALETA_BANDERAS_OTROS = [
        '#f4b183', // durazno
        '#c6e0b4', // verde suave
        '#ffd966', // amarillo
        '#d9e1f2', // azul grisáceo
        '#e4dfec', // lavanda
        '#f8cbad', // salmón
        '#b4c6e7', // periwinkle
        '#d5a6bd', // rosa malva
        '#b6d7a8', // verde
        '#ffe599', // ámbar claro
        '#cfe2f3', // celeste claro
        '#d9d2e9', // violeta claro
        '#fce5cd', // crema
        '#ead1dc', // rosa claro
        '#b7d7d8', // turquesa gris
        '#d0e0e3'  // gris azulado
    ];
    let mapaColoresBandera = {};
    let mapaColoresBanderaCargado = false;

    chrome.storage.local.get(['viena_usuario', BANDERA_COLOR_MAP_KEY]).then(r => {
        MI_USUARIO = String(r.viena_usuario || '').trim().toLowerCase();
        mapaColoresBandera = (r[BANDERA_COLOR_MAP_KEY] && typeof r[BANDERA_COLOR_MAP_KEY] === 'object')
            ? { ...r[BANDERA_COLOR_MAP_KEY] }
            : {};
        mapaColoresBanderaCargado = true;
        procesarTabla();
    });
    chrome.storage.onChanged.addListener((c,a) => {
        if (a === 'local' && c.viena_usuario) {
            MI_USUARIO = String(c.viena_usuario.newValue || '').trim().toLowerCase();
            procesarTabla();
        }
        if (a === 'local' && c[BANDERA_COLOR_MAP_KEY]) {
            const nuevo = c[BANDERA_COLOR_MAP_KEY].newValue;
            if (nuevo && typeof nuevo === 'object') mapaColoresBandera = { ...nuevo };
        }
    });

    // Colores de estado de fila
    const COLOR_VERDE = '#b7e4c7';
    const COLOR_AMARILLO = '#fff3a3';
    const COLOR_NARANJA = '#ffb347';
    const COLOR_VIOLETA = '#d8b4fe';

    // Color de celda de bandera según usuario
    const COLOR_MI_BANDERA = '#8ecae6';

    // Borde de fila seleccionada
    const COLOR_SELECCION = '#0066ff';

    // Historial local
    const STORAGE_KEY = 'metricas_nodos_vts_v7__dev';

    // Selectores reales
    const SELECTOR_TOTAL =
        'td[aria-describedby="grid-estadisticas-nodos-general_vttotal.valorActual"]';

    const SELECTOR_PROBLEMA =
        'td[aria-describedby="grid-estadisticas-nodos-general_vtproblseñal.valorActual"]';

    const SELECTOR_BANDERA =
        'span.glyphicon.glyphicon-flag';


    // =========================================================
    // STORAGE
    // =========================================================

    function cargarHistorial() {
        try {
            return JSON.parse(
                localStorage.getItem(STORAGE_KEY)
            ) || {};
        } catch (e) {
            return {};
        }
    }

    function guardarHistorial(historial) {
        try {
            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(historial)
            );
        } catch (e) {
            console.warn('No se pudo guardar historial VTS:', e);
        }
    }


    // =========================================================
    // LECTURA DE DATOS
    // =========================================================

    function obtenerValores(fila) {
        const celdaTotal = fila.querySelector(SELECTOR_TOTAL);
        const celdaProblema = fila.querySelector(SELECTOR_PROBLEMA);

        if (!celdaTotal || !celdaProblema) {
            return null;
        }

        const total = parseInt(
            celdaTotal.textContent.trim(),
            10
        );

        const problema = parseInt(
            celdaProblema.textContent.trim(),
            10
        );

        return {
            total: Number.isNaN(total) ? 0 : total,
            problema: Number.isNaN(problema) ? 0 : problema
        };
    }


    function obtenerNodo(fila) {

        // Intento 1: columna nodo por aria-describedby
        let celdaNodo = fila.querySelector(
            'td[aria-describedby="grid-estadisticas-nodos-general_nodo"]'
        );

        // Intento 2: cualquier aria que termine en _nodo
        if (!celdaNodo) {
            celdaNodo = fila.querySelector(
                'td[aria-describedby$="_nodo"]'
            );
        }

        if (celdaNodo) {
            const texto = celdaNodo.textContent.trim();

            if (texto) {
                return texto;
            }
        }

        // Intento 3: buscar una celda con formato de nodo
        const celdas = Array.from(
            fila.querySelectorAll('td')
        );

        for (const td of celdas) {
            const texto = td.textContent.trim();

            if (/^[A-Z]{1,4}\d+[A-Z0-9]*$/i.test(texto)) {
                return texto;
            }
        }

        return null;
    }


    function obtenerBandera(fila) {
        return fila.querySelector(SELECTOR_BANDERA);
    }


    function obtenerUsuarioBandera(bandera) {

        if (!bandera) {
            return null;
        }

        /*
         * VIENA/Métricas puede dejar el tooltip en el icono, en un <a>/<span>
         * contenedor o mover `title` a `data-original-title` al inicializar el
         * tooltip. Recorremos sólo la celda de bandera para no tomar datos de
         * otra columna.
         *
         * Ejemplo esperado:
         * efoschi - Foschi, Emanuel Gaston - 12/09/2026 14:03
         */
        const celda = bandera.closest('td');
        const candidatos = [bandera];
        let parent = bandera.parentElement;
        while (parent && parent !== celda) {
            candidatos.push(parent);
            parent = parent.parentElement;
        }
        if (celda) {
            candidatos.push(celda);
            candidatos.push(...Array.from(celda.querySelectorAll('[title], [data-original-title], [aria-label], [data-user], [data-usuario]')));
        }

        const textos = [];
        for (const el of candidatos) {
            if (!el) continue;
            for (const attr of ['title', 'data-original-title', 'aria-label', 'data-user', 'data-usuario']) {
                const value = String(el.getAttribute?.(attr) || '').trim();
                if (value) textos.push(value);
            }
        }

        for (const texto of textos) {
            const primero = texto.split(/\s+-\s+/)[0].trim().toLowerCase();
            if (/^[a-z][a-z0-9._-]{2,40}$/i.test(primero)) return primero;

            const match = texto.match(/(?:^|\s)([a-z][a-z0-9._-]{2,40})\s+-\s+/i);
            if (match?.[1]) return match[1].toLowerCase();
        }

        return null;
    }

    function hashUsuarioBandera(texto) {
        let hash = 2166136261;
        const value = String(texto || '');
        for (let i = 0; i < value.length; i++) {
            hash ^= value.charCodeAt(i);
            hash = Math.imul(hash, 16777619);
        }
        return hash >>> 0;
    }

    function guardarMapaColoresBandera() {
        if (!mapaColoresBanderaCargado) return;
        chrome.storage.local.set({ [BANDERA_COLOR_MAP_KEY]: mapaColoresBandera }).catch(() => {});
    }

    function colorBanderaPorUsuario(usuario) {
        const user = String(usuario || '').trim().toLowerCase();
        if (!user) return '#e2e8f0';

        // La bandera propia conserva el celeste definido históricamente.
        if (MI_USUARIO && user === MI_USUARIO) {
            return COLOR_MI_BANDERA;
        }

        const guardado = Number(mapaColoresBandera[user]);
        if (
            Number.isInteger(guardado) &&
            guardado >= 0 &&
            guardado < PALETA_BANDERAS_OTROS.length
        ) {
            return PALETA_BANDERAS_OTROS[guardado];
        }

        // Antes de completar la carga del storage usamos un color determinista
        // sin escribir nada. Al terminar la carga, procesarTabla() vuelve a
        // aplicar el mapa persistente.
        const inicial = hashUsuarioBandera(user) % PALETA_BANDERAS_OTROS.length;
        if (!mapaColoresBanderaCargado) {
            return PALETA_BANDERAS_OTROS[inicial];
        }

        // Evitar colisiones entre los operadores ya conocidos siempre que haya
        // colores disponibles. El mapa queda persistido para que cada usuario
        // conserve su color en futuras aperturas.
        const usados = new Set(
            Object.entries(mapaColoresBandera)
                .filter(([otro]) => otro !== user)
                .map(([, indice]) => Number(indice))
                .filter(indice => Number.isInteger(indice) && indice >= 0 && indice < PALETA_BANDERAS_OTROS.length)
        );

        let indice = inicial;
        for (let paso = 0; paso < PALETA_BANDERAS_OTROS.length; paso++) {
            const candidato = (inicial + paso) % PALETA_BANDERAS_OTROS.length;
            if (!usados.has(candidato)) {
                indice = candidato;
                break;
            }
        }

        mapaColoresBandera[user] = indice;
        guardarMapaColoresBandera();
        return PALETA_BANDERAS_OTROS[indice];
    }


    // =========================================================
    // COLORES DE FILA
    // =========================================================

    function limpiarColorFila(fila) {

        fila.querySelectorAll('td').forEach(td => {
            td.style.removeProperty('background-color');
        });
    }


    function aplicarColorFila(fila, color) {

        fila.querySelectorAll('td').forEach(td => {
            td.style.setProperty(
                'background-color',
                color,
                'important'
            );
        });
    }


    // =========================================================
    // COLOR DE BANDERA SEGÚN USUARIO
    // =========================================================

    function aplicarColorBandera(fila, bandera) {

        if (!bandera) {
            return;
        }

        const usuario =
            obtenerUsuarioBandera(bandera);

        const celdaBandera =
            bandera.closest('td');

        if (!celdaBandera) {
            return;
        }

        const color = colorBanderaPorUsuario(usuario);

        celdaBandera.style.setProperty(
            'background-color',
            color,
            'important'
        );

        // Dejamos trazabilidad visual/DOM sin modificar el title original.
        celdaBandera.dataset.vienaBanderaUsuario = usuario || '';
        celdaBandera.dataset.vienaBanderaColor = color;
        bandera.style.setProperty('color', '#22313f', 'important');
    }


    // =========================================================
    // SELECCIÓN DE FILA
    // =========================================================

    function quitarSeleccionAnterior() {

        document.querySelectorAll(
            'tr[data-fila-seleccionada="1"]'
        ).forEach(fila => {

            delete fila.dataset.filaSeleccionada;

            fila.querySelectorAll('td').forEach(td => {
                td.style.removeProperty('box-shadow');
            });
        });
    }


    function dibujarSeleccion(fila) {

        const celdas =
            fila.querySelectorAll('td');

        celdas.forEach((td, index) => {

            let sombra = '';

            if (index === 0) {
                sombra =
                    `inset 3px 0 0 ${COLOR_SELECCION}, ` +
                    `inset 0 2px 0 ${COLOR_SELECCION}, ` +
                    `inset 0 -2px 0 ${COLOR_SELECCION}`;
            }

            else if (index === celdas.length - 1) {
                sombra =
                    `inset -3px 0 0 ${COLOR_SELECCION}, ` +
                    `inset 0 2px 0 ${COLOR_SELECCION}, ` +
                    `inset 0 -2px 0 ${COLOR_SELECCION}`;
            }

            else {
                sombra =
                    `inset 0 2px 0 ${COLOR_SELECCION}, ` +
                    `inset 0 -2px 0 ${COLOR_SELECCION}`;
            }

            td.style.setProperty(
                'box-shadow',
                sombra,
                'important'
            );
        });
    }


    function aplicarSeleccion(fila) {

        quitarSeleccionAnterior();

        fila.dataset.filaSeleccionada = '1';

        dibujarSeleccion(fila);
    }


    function restaurarSeleccionSiCorresponde(fila) {

        if (
            fila.dataset.filaSeleccionada === '1'
        ) {
            dibujarSeleccion(fila);
        }
    }


    // =========================================================
    // MENSAJE DE CONFIRMACIÓN
    // =========================================================

    function mostrarAvisoRevision(nodo, valores) {

        const anterior =
            document.getElementById(
                'aviso-metricas-vts'
            );

        if (anterior) {
            anterior.remove();
        }

        const aviso =
            document.createElement('div');

        aviso.id =
            'aviso-metricas-vts';

        aviso.textContent = '';
        aviso.append(document.createTextNode('✓ '));
        const nodoFuerte = document.createElement('strong');
        nodoFuerte.textContent = String(nodo ?? '');
        aviso.append(
            nodoFuerte,
            document.createTextNode(' revisado'),
            document.createElement('br'),
            document.createTextNode('VTS actual: ' + String(valores?.total ?? '') + ' | Problema señal: ' + String(valores?.problema ?? ''))
        );

        aviso.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 999999;
            background: #198754;
            color: white;
            padding: 12px 18px;
            border-radius: 6px;
            font-size: 14px;
            font-family: Arial, sans-serif;
            box-shadow: 0 3px 10px rgba(0,0,0,0.30);
            pointer-events: none;
        `;

        document.body.appendChild(aviso);

        setTimeout(function () {

            aviso.style.transition =
                'opacity 0.3s';

            aviso.style.opacity =
                '0';

            setTimeout(function () {
                aviso.remove();
            }, 300);

        }, 2500);
    }


    // =========================================================
    // PROCESAR UNA FILA
    // =========================================================

    function procesarFila(fila, historial) {

        const valores =
            obtenerValores(fila);

        if (!valores) {
            return false;
        }

        const bandera =
            obtenerBandera(fila);

        const tieneBandera =
            bandera !== null;

        let cambioHistorial = false;

        // Recalcular visual desde cero
        limpiarColorFila(fila);


        // =====================================================
        // SIN BANDERA
        // =====================================================

        if (!tieneBandera) {

            const nodo =
                obtenerNodo(fila);

            // Si antes tenía bandera y ahora no, borrar referencia
            if (
                nodo &&
                historial[nodo]
            ) {
                delete historial[nodo];
                cambioHistorial = true;
            }

            delete fila.dataset.nuevosVts;

            const maximo =
                Math.max(
                    valores.total,
                    valores.problema
                );

            // 🟧 4 o más
            if (maximo >= 4) {

                aplicarColorFila(
                    fila,
                    COLOR_NARANJA
                );
            }

            // 🟨 exactamente 3
            else if (maximo === 3) {

                aplicarColorFila(
                    fila,
                    COLOR_AMARILLO
                );
            }

            restaurarSeleccionSiCorresponde(
                fila
            );

            return cambioHistorial;
        }


        // =====================================================
        // CON BANDERA
        // =====================================================

        const nodo =
            obtenerNodo(fila);

        // Si no identifica el nodo, igual lo tratamos como seguido
        if (!nodo) {

            aplicarColorFila(
                fila,
                COLOR_VERDE
            );

            aplicarColorBandera(
                fila,
                bandera
            );

            restaurarSeleccionSiCorresponde(
                fila
            );

            return cambioHistorial;
        }


        // Primera vez que esta versión detecta la bandera
        if (!historial[nodo]) {

            historial[nodo] = {
                total: valores.total,
                problema: valores.problema
            };

            cambioHistorial = true;

            delete fila.dataset.nuevosVts;

            // 🟩 seguimiento normal
            aplicarColorFila(
                fila,
                COLOR_VERDE
            );
        }

        else {

            const base =
                historial[nodo];

            const aumentoTotal =
                valores.total > base.total;

            const aumentoProblema =
                valores.problema > base.problema;

            // 🟪 entraron nuevos VTS
            if (
                aumentoTotal ||
                aumentoProblema
            ) {

                fila.dataset.nuevosVts = '1';

                aplicarColorFila(
                    fila,
                    COLOR_VIOLETA
                );
            }

            // 🟩 sigue igual
            else {

                delete fila.dataset.nuevosVts;

                aplicarColorFila(
                    fila,
                    COLOR_VERDE
                );
            }
        }


        // Celda de bandera según usuario
        aplicarColorBandera(
            fila,
            bandera
        );


        // Restaurar borde si está seleccionada
        restaurarSeleccionSiCorresponde(
            fila
        );


        return cambioHistorial;
    }


    // =========================================================
    // PROCESAR TABLA
    // =========================================================

    function procesarTabla() {

        const historial =
            cargarHistorial();

        let cambioHistorial = false;

        const celdasTotales =
            document.querySelectorAll(
                SELECTOR_TOTAL
            );

        celdasTotales.forEach(celda => {

            const fila =
                celda.closest('tr');

            if (!fila) {
                return;
            }

            const cambio =
                procesarFila(
                    fila,
                    historial
                );

            if (cambio) {
                cambioHistorial = true;
            }
        });


        if (cambioHistorial) {
            guardarHistorial(
                historial
            );
        }
    }


    // =========================================================
    // CLICK NORMAL = SELECCIONAR FILA
    // =========================================================

    document.addEventListener(
        'click',
        function (e) {

            const fila =
                e.target.closest('tr');

            if (!fila) {
                return;
            }

            // Solo filas reales
            if (
                !fila.querySelector(
                    SELECTOR_TOTAL
                )
            ) {
                return;
            }

            // Un click normal SOLO selecciona
            aplicarSeleccion(fila);
        }
    );


    // =========================================================
    // CTRL + DOBLE CLICK = MARCAR COMO REVISADO
    // =========================================================

    document.addEventListener(
        'dblclick',
        function (e) {

            // Obligatorio mantener CTRL
            if (!e.ctrlKey) {
                return;
            }

            const fila =
                e.target.closest('tr');

            if (!fila) {
                return;
            }

            // Solo filas reales
            if (
                !fila.querySelector(
                    SELECTOR_TOTAL
                )
            ) {
                return;
            }

            // Solo se confirma si está violeta
            if (
                fila.dataset.nuevosVts !== '1'
            ) {
                return;
            }

            const nodo =
                obtenerNodo(fila);

            const valores =
                obtenerValores(fila);

            const bandera =
                obtenerBandera(fila);

            if (
                !nodo ||
                !valores ||
                !bandera
            ) {
                return;
            }

            const historial =
                cargarHistorial();

            /*
             * Los valores actuales pasan
             * a ser la nueva referencia.
             */
            historial[nodo] = {
                total: valores.total,
                problema: valores.problema
            };

            guardarHistorial(
                historial
            );

            delete fila.dataset.nuevosVts;

            // Volver inmediatamente a verde
            aplicarColorFila(
                fila,
                COLOR_VERDE
            );

            // Mantener color de la bandera
            aplicarColorBandera(
                fila,
                bandera
            );

            // Dejarla seleccionada
            aplicarSeleccion(fila);

            // Mostrar confirmación
            mostrarAvisoRevision(
                nodo,
                valores
            );
        }
    );


    // =========================================================
    // EJECUCIÓN
    // =========================================================

    setTimeout(
        procesarTabla,
        300
    );

    setTimeout(
        procesarTabla,
        800
    );

    setTimeout(
        procesarTabla,
        1500
    );

    setTimeout(
        procesarTabla,
        3000
    );


    // jqGrid se actualiza dinámicamente
    setInterval(
        procesarTabla,
        1500
    );

})();