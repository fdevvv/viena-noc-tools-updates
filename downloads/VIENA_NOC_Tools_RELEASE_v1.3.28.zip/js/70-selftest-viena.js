(() => {
'use strict';
if (location.hostname !== 'viena.telecentro.net.ar' || window.__VIENA_SELFTEST__) return;
window.__VIENA_SELFTEST__ = true;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const visible = el => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
const norm = v => String(v || '').trim().toUpperCase().replace(/\s+/g, '');
const valueFrom = btn => {
  const t = String(btn?.textContent || '').trim();
  const m = t.match(/-\s*([A-Z0-9]+)\s*$/i);
  return m ? norm(m[1]) : '';
};
const save = async state => chrome.storage.local.set({viena_selftest_state: state});
async function inspect(spec, timeout=35000) {
  const start=Date.now(); let last=null;
  while(Date.now()-start<timeout){
    try { last=await chrome.runtime.sendMessage({type:'VIENA_SELFTEST_INSPECT',spec}); } catch(e){ last={ok:false,detail:String(e?.message||e)}; }
    if(last?.ok) return last;
    await sleep(250);
  }
  return last || {ok:false,detail:'Timeout sin respuesta del destino'};
}
function classify(btn){
  const expected=valueFrom(btn); if(!expected)return null;
  const c=btn.classList;
  if(c.contains('viena-fuentes-nodo-action-btn')) return {name:'Fuentes → Nodo',target:'fuentes',mode:'fuentes',expected};
  if(c.contains('viena-optico-nodo-action-btn')) return {name:'Óptico → Nodo',target:'fuentes',mode:'opticos',expected};
  if(c.contains('viena-rphy-nodo-action-btn')) return {name:'RPHY → Nodo',target:'fuentes',mode:'rphy',expected};
  if(c.contains('viena-moica-nodo-action-btn')) return {name:'MOICA2 → Nodo',target:'moica',mode:'nodo',expected};
  if(c.contains('viena-edificio-m5-action-btn')) return {name:'MIRA5 → Edificio',target:'mira-cm',mode:'edificio',expected};
  if(c.contains('viena-efs-edificio-gpon-action-btn')) return {name:'GPON → Edificio',target:'gpon',mode:'edificio',expected};
  if(c.contains('viena-efs-cliente-action-btn')) return c.contains('viena-gpon-action-btn')
    ? {name:'GPON → Cliente',target:'gpon',mode:'cliente',expected}
    : {name:'MIRA5 → Cliente',target:'mira-cm',mode:'cliente',expected};
  if(c.contains('viena-gpon-action-btn')) return {name:'GPON → Nodo',target:'gpon',mode:'nodo',expected};
  if(c.contains('viena-mira5-action-btn')) return {name:'MIRA5 → Nodo',target:'mira-stats',mode:'nodo',expected};
  return null;
}
function buttons(){
  const selector=[
    '.viena-fuentes-nodo-action-btn','.viena-optico-nodo-action-btn','.viena-rphy-nodo-action-btn','.viena-moica-nodo-action-btn',
    '.viena-edificio-m5-action-btn','.viena-efs-edificio-gpon-action-btn','.viena-efs-cliente-action-btn',
    '.viena-gpon-action-btn','.viena-mira5-action-btn'
  ].join(',');
  const seen=new Set(), out=[];
  document.querySelectorAll(selector).forEach(btn=>{ if(seen.has(btn)||!visible(btn))return; seen.add(btn); const s=classify(btn); if(s)out.push({btn,s}); });
  return out;
}
async function runOne(item,label){
  const started=Date.now();
  item.btn.click();
  const r=await inspect(item.s);
  return {name:label||item.s.name,ok:!!r?.ok,detail:r?.detail||'',ms:Date.now()-started};
}
async function run(){
  const cfg=await chrome.storage.local.get(['viena_usuario']);
  if(String(cfg.viena_usuario||'').toLowerCase()!=='efoschi') return {ok:false,error:'Test Operativo habilitado sólo para efoschi.'};
  const found=buttons();
  if(!found.length)return {ok:false,error:'No hay botones operativos visibles en el ticket actual.'};
  const state={running:true,startedAt:Date.now(),ticket:(document.body.innerText.match(/TICKET:\s*([^\s]+)/i)||[])[1]||'',total:found.length,done:0,results:[]};
  await save(state);
  for(const item of found){
    const result=await runOne(item); state.results.push(result); state.done++; await save({...state});
  }
  // Regresiones de alternancia: sólo se ejecutan si esos botones están visibles en ESTE ticket.
  const byMode=m=>found.find(x=>x.s.target==='fuentes'&&x.s.mode===m);
  const f=byMode('fuentes'), o=byMode('opticos'), r=byMode('rphy');
  const seqs=[];
  if(f&&o) seqs.push({name:'Regresión Óptico → Fuentes → Óptico',items:[o,f,o]},{name:'Regresión Fuentes → Óptico → Fuentes',items:[f,o,f]});
  if(f&&r) seqs.push({name:'Regresión RPHY → Fuentes → RPHY',items:[r,f,r]},{name:'Regresión Fuentes → RPHY → Fuentes',items:[f,r,f]});
  state.total += seqs.length;
  await save({...state});
  for(const seq of seqs){
    let ok=true, detail='', ms=0;
    for(const item of seq.items){const rr=await runOne(item);ms+=rr.ms;if(!rr.ok){ok=false;detail=`Falló ${item.s.name}: ${rr.detail}`;break;}}
    state.results.push({name:seq.name,ok,detail,ms});state.done++;await save({...state});
  }
  state.running=false;state.finishedAt=Date.now();state.ok=state.results.every(x=>x.ok);await save({...state});
  return {ok:true,state};
}
chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg?.type!=='VIENA_SELFTEST_RUN')return;
  run().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
  return true;
});
})();
