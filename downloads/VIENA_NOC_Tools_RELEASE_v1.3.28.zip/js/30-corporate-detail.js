(function () {
    'use strict';

    // ================================================================
    // AVISOS DE DESTINO — LIMPIEZA AL CAMBIAR DE CONTEXTO
    // ================================================================
    // Si un aviso quedó visible y el operador realiza cualquier otra acción
    // (abrir/cerrar un ticket, cambiar de fila, tocar otro botón, etc.),
    // se elimina antes de procesar esa nueva acción. Esto evita que el popup
    // de una vista quede flotando sobre la siguiente. No altera búsquedas,
    // validaciones, Bridge, filtros ni la lógica existente de los botones.
    document.addEventListener('pointerdown', event => {
        if (event.target?.closest?.('.viena-destino-aviso')) return;
        document.querySelectorAll('.viena-destino-aviso').forEach(aviso => aviso.remove());
    }, true);

    // ================================================================
    // CONFIGURACIÓN
    // ================================================================

    const CAMPOS = [
        'Nodo',
        'Nodo CMTS'
    ];

    const KEY_HEARTBEAT_STATS = 'VIENA_NOC_BRIDGE_HEARTBEAT_STATS';
    const KEY_HEARTBEAT_EDIFICIO = 'VIENA_NOC_BRIDGE_HEARTBEAT_EDIFICIO';
    const KEY_HEARTBEAT_GPON = 'VIENA_NOC_BRIDGE_HEARTBEAT_GPON';
    const KEY_HEARTBEAT_FUENTES = 'VIENA_FUENTES_HEARTBEAT';
    // v1.5.44 — validación activa de la pestaña Fuentes.
    const KEY_PING_FUENTES = 'VIENA_FUENTES_PING';
    const KEY_PONG_FUENTES = 'VIENA_FUENTES_PONG';
    const KEY_PING_MOICA = 'VIENA_MOICA_PING';
    const KEY_PONG_MOICA = 'VIENA_MOICA_PONG';
    const KEY_ORDEN_MOICA = 'VIENA_MOICA_ORDEN';
    const HEARTBEAT_MAX_AGE = 5500;


    // ================================================================
    // CSS
    // ================================================================

    const style = document.createElement('style');

    style.id = 'viena-copy-node-corporate-v14';

    style.textContent = `

        /* ============================================================
           CAMPO
           ============================================================ */

        .viena-copy-field .v-text-field__slot {
            position: relative !important;
            padding-right: 40px !important;
        }

        /*
         * Dejamos espacio para que el valor del Nodo nunca quede
         * debajo del botón.
         */

        .viena-copy-field input {
            padding-right: 36px !important;
        }


        /* ============================================================
           BOTÓN COPIAR
           ============================================================ */

        .viena-copy-btn {

            position: absolute !important;

            right: 5px !important;
            top: 50% !important;

            transform: translateY(-50%) !important;

            width: 28px !important;
            height: 28px !important;

            min-width: 28px !important;

            display: flex !important;
            align-items: center !important;
            justify-content: center !important;

            padding: 0 !important;
            margin: 0 !important;

            border:
                1px solid #dbe7f3 !important;

            border-radius:
                6px !important;

            background:
                #f4f8fc !important;

            color:
                #1976d2 !important;

            cursor:
                pointer !important;

            z-index:
                9999 !important;

            box-shadow:
                none !important;

            opacity:
                1 !important;

            visibility:
                visible !important;

            outline:
                none !important;

            transition:
                background-color .15s ease,
                border-color .15s ease,
                color .15s ease,
                box-shadow .15s ease,
                transform .1s ease
                !important;
        }


        /* ============================================================
           ICONO
           ============================================================ */

        .viena-copy-btn .mdi {

            font-size:
                17px !important;

            line-height:
                1 !important;

            color:
                inherit !important;

            pointer-events:
                none !important;
        }


        /* ============================================================
           HOVER
           ============================================================ */

        .viena-copy-btn:hover {

            background:
                #e8f2fc !important;

            border-color:
                #90caf9 !important;

            color:
                #1565c0 !important;

            box-shadow:
                0 2px 5px
                rgba(25, 118, 210, .12)
                !important;
        }


        /* ============================================================
           CLICK
           ============================================================ */

        .viena-copy-btn:active {

            transform:
                translateY(-50%)
                scale(.92)
                !important;

            background:
                #dbeafe !important;
        }


        /* ============================================================
           COPIADO CORRECTAMENTE
           ============================================================ */

        .viena-copy-btn.viena-copiado {

            background:
                #ecfdf5 !important;

            border-color:
                #a7f3d0 !important;

            color:
                #059669 !important;

            box-shadow:
                none !important;
        }


        /* ============================================================
           ERROR
           ============================================================ */

        .viena-copy-btn.viena-copy-error {

            background:
                #fef2f2 !important;

            border-color:
                #fecaca !important;

            color:
                #dc2626 !important;

            box-shadow:
                none !important;
        }


        /* ============================================================
           SIN ZOOM / SALTO AL HACER CLICK
           ============================================================ */

        .viena-copy-btn,
        .viena-copy-btn:hover,
        .viena-copy-btn:focus,
        .viena-copy-btn:active {
            transform: none !important;
            scale: 1 !important;
            zoom: 1 !important;
            outline: none !important;
        }

        .viena-copy-btn:active {
            box-shadow: none !important;
        }

        /* ============================================================
           BOTÓN DINÁMICO IR A MIRA 5
           ============================================================ */

        .viena-mira5-action-host {
            position: relative !important;
            overflow: visible !important;
        }

        .viena-mira5-action-wrap {
            position: absolute !important;
            left: 0 !important;
            top: calc(100% + 8px) !important;
            z-index: 50 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: flex-start !important;
            width: max-content !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        .viena-mira5-action-btn,
        .viena-edificio-m5-action-btn {
            min-height: 34px !important;
            padding: 15px 18px !important;
            margin: 0 !important;
            margin-left: 10px !important;
            border: 1px solid #e88900 !important;
            border-radius: 6px !important;
            background: #ff9800 !important;
            color: #fff !important;
            font: 700 15px/1 system-ui, -apple-system, "Segoe UI", sans-serif !important;
            cursor: pointer !important;
            box-shadow: 0 1px 3px rgba(0,0,0,.14) !important;
            transition: background-color .15s ease, border-color .15s ease, box-shadow .15s ease !important;
            transform: none !important;
            scale: 1 !important;
            zoom: 1 !important;
            outline: none !important;
        }

        .viena-mira5-action-btn:hover,
        .viena-edificio-m5-action-btn:hover {
            background: #f28c00 !important;
            border-color: #df8500 !important;
            box-shadow: 0 2px 5px rgba(0,0,0,.16) !important;
        }

        .viena-mira5-action-btn:focus,
        .viena-mira5-action-btn:active,
        .viena-edificio-m5-action-btn:focus,
        .viena-edificio-m5-action-btn:active {
            transform: none !important;
            scale: 1 !important;
            zoom: 1 !important;
            outline: none !important;
        }


        /* MIRA 5 — menú compacto por hover. No modifica la fila ni el tamaño
           del botón principal; el listado flota por encima del contenido. */
        .viena-mira5-menu-anchor { position: relative !important; display: inline-flex !important; }
        .viena-mira5-hover-menu {
            display: none !important; position: absolute !important; left: 10px !important;
            top: calc(100% - 1px) !important; min-width: 245px !important; padding: 6px !important;
            border: 1px solid #e0e0e0 !important; border-radius: 7px !important;
            background: #fff !important; box-shadow: 0 6px 18px rgba(0,0,0,.20) !important;
            z-index: 2147483000 !important;
        }
        .viena-mira5-hover-menu.viena-mira5-menu-up { top: auto !important; bottom: calc(100% - 1px) !important; }
        .viena-mira5-menu-anchor:hover > .viena-mira5-hover-menu,
        .viena-mira5-menu-anchor:focus-within > .viena-mira5-hover-menu,
        .viena-mira5-menu-anchor.viena-mira5-menu-open > .viena-mira5-hover-menu { display: block !important; }
        .viena-mira5-hover-item {
            display: block !important; width: 100% !important; min-height: 34px !important;
            margin: 0 0 6px 0 !important; padding: 11px 14px !important;
            border: 1px solid #e88900 !important; border-radius: 6px !important;
            background: #ff9800 !important; color: #fff !important; text-align: left !important;
            font: 700 15px/1 system-ui,-apple-system,"Segoe UI",sans-serif !important;
            cursor: pointer !important; white-space: nowrap !important;
            box-shadow: 0 1px 3px rgba(0,0,0,.14) !important;
            transition: background-color .15s ease, border-color .15s ease, box-shadow .15s ease !important;
            transform: none !important; scale: 1 !important; zoom: 1 !important; outline: none !important;
        }
        .viena-mira5-hover-item:last-child { margin-bottom: 0 !important; }
        .viena-mira5-hover-item:hover {
            background: #f28c00 !important; border-color: #df8500 !important; color: #fff !important;
            box-shadow: 0 2px 5px rgba(0,0,0,.16) !important;
        }
        .viena-mira5-hover-item:focus, .viena-mira5-hover-item:active {
            transform: none !important; scale: 1 !important; zoom: 1 !important; outline: none !important;
        }
        .viena-mira5-menu-secondary-hidden { display: none !important; }


        /* ============================================================
           TICKETS COMPLETADA — REEMPLAZO DE "PERSONA COMPLETADO"
           ============================================================ */

        .viena-completada-action-host {
            position: relative !important;
            overflow: visible !important;
            min-height: 56px !important;
            display: flex !important;
            align-items: center !important;
        }

        .viena-completada-action-host > .viena-mira5-action-wrap {
            position: relative !important;
            left: auto !important;
            top: auto !important;
            z-index: 50 !important;
            display: flex !important;
            align-items: center !important;
            justify-content: flex-start !important;
            width: max-content !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        /* ============================================================
           BOTÓN MONITOREO GPON / FTTH
           Mismo tamaño y posición que MIRA5; cambia sólo el color.
           ============================================================ */

        .viena-gpon-action-btn {
            min-height: 34px !important;
            padding: 15px 18px !important;
            margin: 0 !important;
            margin-left: 10px !important;
            border: 1px solid #667085 !important;
            border-radius: 6px !important;
            background: #667085 !important;
            color: #fff !important;
            font: 700 15px/1 system-ui, -apple-system, "Segoe UI", sans-serif !important;
            cursor: pointer !important;
            box-shadow: 0 1px 3px rgba(0,0,0,.14) !important;
            transition: background-color .15s ease, border-color .15s ease, box-shadow .15s ease !important;
            transform: none !important;
            scale: 1 !important;
            zoom: 1 !important;
            outline: none !important;
        }

        .viena-gpon-action-btn:hover {
            background: #596273 !important;
            border-color: #596273 !important;
            box-shadow: 0 2px 5px rgba(0,0,0,.16) !important;
        }

        .viena-gpon-action-btn:focus,
        .viena-gpon-action-btn:active {
            transform: none !important;
            scale: 1 !important;
            zoom: 1 !important;
            outline: none !important;
        }

        /* ============================================================
           BOTÓN FUENTES
           Mismas dimensiones que MIRA 5. Se ubica a su derecha.
           ============================================================ */

        .viena-fuentes-action-btn {
            min-height: 34px !important;
            padding: 15px 18px !important;
            margin: 0 0 0 10px !important;
            border: 1px solid #667085 !important;
            border-radius: 6px !important;
            background: #667085 !important;
            color: #fff !important;
            font: 700 15px/1 system-ui, -apple-system, "Segoe UI", sans-serif !important;
            cursor: pointer !important;
            box-shadow: 0 1px 3px rgba(0,0,0,.14) !important;
            transition: background-color .15s ease, border-color .15s ease, box-shadow .15s ease !important;
            transform: none !important;
            scale: 1 !important;
            zoom: 1 !important;
            outline: none !important;
        }

        .viena-fuentes-action-btn:hover {
            background: #596273 !important;
            border-color: #596273 !important;
            box-shadow: 0 2px 5px rgba(0,0,0,.16) !important;
        }

        .viena-fuentes-action-btn:focus,
        .viena-fuentes-action-btn:active {
            transform: none !important;
            scale: 1 !important;
            zoom: 1 !important;
            outline: none !important;
        }

        /* Iconos reales de cada plataforma mediante el favicon que Chrome ya
           conoce para esa aplicación. No se descargan assets externos. */
        .viena-mira5-action-btn,
        .viena-edificio-m5-action-btn:not(.viena-mira5-menu-secondary-hidden),
        .viena-gpon-action-btn,
        .viena-fuentes-action-btn,
        .viena-mira5-hover-item {
            display: inline-flex !important;
            align-items: center !important;
            gap: 7px !important;
        }
        /* Debe ganar también frente a la regla de iconos: los accesos M5
           secundarios viven en DOM para reutilizar sus handlers, pero no
           pueden volver a aparecer como botones separados en la fila. */
        .viena-mira5-menu-secondary-hidden { display: none !important; }
        .viena-platform-icon {
            width: 16px !important;
            height: 16px !important;
            min-width: 16px !important;
            flex: 0 0 16px !important;
            object-fit: contain !important;
            border: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            pointer-events: none !important;
        }
        .viena-platform-label { pointer-events: none !important; }

    `;

    document.head.appendChild(style);

    const VIENA_PLATFORM_ICON_PAGES = Object.freeze({
        mira: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
        gpon: 'https://monitoreogpon.telecentro.net.ar/#/listOnts',
        // Fuentes, Óptico y RPHY son módulos de la misma plataforma y usan
        // exactamente su mismo favicon, tal como se ve en la aplicación.
        fuentes: 'https://fuentes.telecentro.net.ar/webs/home.php',
        moica: 'https://moica2.telecentro.net.ar/buscarTicket.php',
        grafana: 'https://grafana-telemetria.telecentro.net.ar/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e?orgId=1'
    });

    const VIENA_PLATFORM_FAVICON_CACHE = new Map();

    function faviconDirecto(pageUrl) {
        try { return new URL('/favicon.ico', pageUrl).href; } catch (_) { return ''; }
    }

    async function faviconChromeComoBlob(pageUrl) {
        if (!pageUrl || !globalThis.chrome?.runtime?.sendMessage) return null;
        if (VIENA_PLATFORM_FAVICON_CACHE.has(pageUrl)) return VIENA_PLATFORM_FAVICON_CACHE.get(pageUrl);
        const promesa = (async () => {
            try {
                const result = await chrome.runtime.sendMessage({
                    type: 'VIENA_GET_FAVICON_BYTES',
                    pageUrl
                });
                if (!result?.ok || !Array.isArray(result.bytes) || !result.bytes.length) {
                    throw new Error(result?.detail || 'favicon sin bytes');
                }
                return new Blob([new Uint8Array(result.bytes)], { type: result.mime || 'image/png' });
            } catch (error) {
                console.warn('[VIENA ICONOS] No se pudo obtener favicon', { pageUrl, error: String(error?.message || error) });
                return null;
            }
        })();
        VIENA_PLATFORM_FAVICON_CACHE.set(pageUrl, promesa);
        return promesa;
    }


    async function dibujarFaviconEnCanvas(canvas, pageUrl) {
        try {
            const blob = await faviconChromeComoBlob(pageUrl);
            if (!blob || !canvas?.isConnected) return false;
            const bitmap = await createImageBitmap(blob);
            if (!canvas.isConnected) { try { bitmap.close(); } catch (_) {} return false; }
            canvas.width = 16;
            canvas.height = 16;
            const ctx = canvas.getContext('2d');
            if (!ctx) return false;
            ctx.clearRect(0, 0, 16, 16);
            ctx.drawImage(bitmap, 0, 0, 16, 16);
            try { bitmap.close(); } catch (_) {}
            canvas.dataset.vienaIconReady = '1';
            return true;
        } catch (error) {
            console.warn('[VIENA ICONOS] No se pudo dibujar favicon', { pageUrl, error: String(error?.message || error) });
            return false;
        }
    }

    function aplicarIconoPlataforma(boton, texto, plataforma) {
        if (!boton) return;
        const label = String(texto || '');
        const pageUrl = VIENA_PLATFORM_ICON_PAGES[plataforma];
        const renderKey = `${String(plataforma || '')}|${label}`;

        /*
         * VIENA es una SPA muy activa: abrir/cerrar modales, cambiar pestañas o
         * actualizar bloques del ticket dispara detectarCampos() nuevamente.
         * Antes vaciábamos y reconstruíamos SIEMPRE el contenido del botón, incluso
         * cuando plataforma + texto no habían cambiado. Eso recreaba el canvas del
         * favicon y producía un pequeño "titileo" visual del botón MIRA5.
         *
         * Si el render actual ya es correcto, no tocamos el DOM del botón.
         */
        const labelActual = boton.querySelector(':scope > .viena-platform-label');
        const iconoActual = boton.querySelector(':scope > .viena-platform-icon');
        const estructuraEstable =
            boton.dataset.vienaPlatformRenderKey === renderKey &&
            labelActual?.textContent === label &&
            (pageUrl ? !!iconoActual : !iconoActual);

        boton.setAttribute('aria-label', label);
        if (estructuraEstable) return;

        boton.textContent = '';
        boton.dataset.vienaPlatformRenderKey = renderKey;

        if (pageUrl) {
            // Dibujar los píxeles en un canvas evita que el CSP de VIENA bloquee
            // chrome-extension://, data: o el favicon remoto insertado como <img>.
            const canvas = document.createElement('canvas');
            canvas.className = 'viena-platform-icon';
            canvas.width = 16;
            canvas.height = 16;
            canvas.setAttribute('aria-hidden', 'true');
            boton.appendChild(canvas);
            dibujarFaviconEnCanvas(canvas, pageUrl);
        }

        const span = document.createElement('span');
        span.className = 'viena-platform-label';
        span.textContent = label;
        boton.appendChild(span);
    }


    // ================================================================
    // RESINCRONIZAR TICKET — acción manual de recuperación
    // ================================================================
    const styleSync = document.createElement('style');
    styleSync.id = 'viena-ticket-resync-style';
    styleSync.textContent = `
        /* RESINCRONIZAR usa exactamente la fila y el aspecto de los botones nativos.
           Nada de position:fixed: queda alineado con CREAR TAREA / ASIGNAR USUARIO. */
        .viena-ticket-resync-btn {
            margin-left: 12px !important;
        }
        .viena-ticket-resync-btn:disabled { opacity: .7; cursor: wait !important; }
        .viena-ticket-resync-btn.viena-sync-ok { background: #2e7d32 !important; }
    `;
    document.head.appendChild(styleSync);




    // ================================================================
    // ICONOS
    // ================================================================

    const ICONO_COPIAR =
        '<i class="mdi mdi-content-copy" aria-hidden="true"></i>';

    const ICONO_OK =
        '<i class="mdi mdi-check" aria-hidden="true"></i>';

    const ICONO_ERROR =
        '<i class="mdi mdi-alert-circle-outline" aria-hidden="true"></i>';


    // ================================================================
    // COPIAR AL PORTAPAPELES
    // ================================================================

    async function copiar(texto) {

        if (!texto) {
            return false;
        }


        // ------------------------------------------------------------
        // Clipboard API
        // ------------------------------------------------------------

        try {

            if (
                navigator.clipboard &&
                window.isSecureContext
            ) {

                await navigator.clipboard.writeText(
                    texto
                );

                return true;
            }

        } catch (error) {

            console.warn(
                '[VIENA COPY] Clipboard API bloqueada. Usando fallback.',
                error
            );
        }


        // ------------------------------------------------------------
        // FALLBACK
        // ------------------------------------------------------------

        const textarea =
            document.createElement(
                'textarea'
            );

        textarea.value =
            texto;

        textarea.setAttribute(
            'readonly',
            ''
        );

        textarea.style.position =
            'fixed';

        textarea.style.left =
            '-9999px';

        textarea.style.top =
            '-9999px';

        textarea.style.opacity =
            '0';


        document.body.appendChild(
            textarea
        );


        textarea.focus();

        textarea.select();


        let resultado =
            false;


        try {

            resultado =
                document.execCommand(
                    'copy'
                );

        } catch (error) {

            console.error(
                '[VIENA COPY] Error en fallback:',
                error
            );
        }


        textarea.remove();


        return resultado;
    }


    // ================================================================
    // FEEDBACK: COPIADO
    // ================================================================

    function feedbackCopiado(
        boton
    ) {

        clearTimeout(
            boton.__vienaTimer
        );


        boton.classList.remove(
            'viena-copy-error'
        );


        boton.classList.add(
            'viena-copiado'
        );


        boton.innerHTML =
            ICONO_OK;


        boton.title =
            'Copiado';


        boton.setAttribute(
            'aria-label',
            'Copiado'
        );


        boton.__vienaTimer =
            setTimeout(() => {

                boton.classList.remove(
                    'viena-copiado'
                );


                boton.innerHTML =
                    ICONO_COPIAR;


                boton.title =
                    'Copiar';


                boton.setAttribute(
                    'aria-label',
                    'Copiar'
                );

            }, 1100);
    }


    // ================================================================
    // FEEDBACK: ERROR
    // ================================================================

    function feedbackError(
        boton
    ) {

        clearTimeout(
            boton.__vienaTimer
        );


        boton.classList.remove(
            'viena-copiado'
        );


        boton.classList.add(
            'viena-copy-error'
        );


        boton.innerHTML =
            ICONO_ERROR;


        boton.title =
            'No se pudo copiar';


        boton.__vienaTimer =
            setTimeout(() => {

                boton.classList.remove(
                    'viena-copy-error'
                );


                boton.innerHTML =
                    ICONO_COPIAR;


                boton.title =
                    'Copiar';

            }, 1200);
    }


    // ================================================================
    // CREAR BOTÓN
    // ================================================================

    function obtenerTipificacion() {
        const labels = document.querySelectorAll('.v-text-field__slot > label');

        for (const label of labels) {
            const nombre = String(label.textContent || '')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();

            if (nombre !== 'tipificación de la tarea' &&
                nombre !== 'tipificacion de la tarea') {
                continue;
            }

            const campo = label.closest('.v-input');
            const input = campo?.querySelector('.v-text-field__slot > input');

            if (input) {
                return String(input.value || '').trim();
            }
        }

        return '';
    }

    function esTicketFTTH() {
        const tipificacion = obtenerTipificacion().toUpperCase();

        // Regla solicitada: cualquier tipificación que contenga
        // FTTH o SPLITTER se trata como red GPON.
        return (
            tipificacion.includes('FTTH') ||
            tipificacion.includes('SPLITTER')
        );
    }

    function esTicketFallaComponentesFuente() {
        const tipificacion = obtenerTipificacion()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();

        const tipificacionesFuentes = new Set([
            'diagnostico falla componentes de fuente',
            'hfc diagnostico de exceso de visitas tecnicas',
            'hfc - diagnostico de caida de modems',
            'hfc - diagnostico de caida de edifico',
            'segundo diagnostico caidas',
            'hfc - diagnostico de caida de zona tecnica'
        ]);

        return tipificacionesFuentes.has(tipificacion);
    }

    function esTicketCaidaEdificioHFC() {
        const tipificacion = obtenerTipificacion()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();

        return tipificacion === 'hfc - diagnostico de caida de edifico';
    }

    function obtenerIdEdificioTareaInterna() {
        /*
         * v1.5.28
         * El ID Edificio NO depende del estado del ticket.
         *
         * Orden de búsqueda:
         * 1) Fila del ticket actual en Tareas Internas:
         *    .viena-copy-value[data-copy-value]
         * 2) Texto .viena-copy-text / columna ID Edificio de esa misma fila.
         * 3) Mensaje del ticket:
         *    "afectando al siguiente elemento: 50113"
         *
         * Importante: si la fila no está disponible en el DOM, NO retornamos
         * vacío inmediatamente; continuamos al fallback del Mensaje.
         */

        const textoPagina = String(document.body?.innerText || '');

        const matchTicket = textoPagina.match(
            /TICKET:\s*([A-Z0-9_-]+)/i
        );

        const ticketActual = String(matchTicket?.[1] || '')
            .trim()
            .toUpperCase();

        // ------------------------------------------------------------
        // 1 y 2) TAREAS INTERNAS — sólo la fila del ticket ABIERTO
        // ------------------------------------------------------------

        if (ticketActual) {
            const filas = Array.from(document.querySelectorAll('tr'));

            const filaActual = filas.find(fila => {
                const texto = String(fila.textContent || '')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .toUpperCase();

                return texto.includes(ticketActual);
            });

            if (filaActual) {
                const botonCopiar = filaActual.querySelector(
                    'button.viena-table-copy[title="Copiar ID Edificio"], ' +
                    'button.viena-table-copy[aria-label="Copiar ID Edificio"]'
                );

                if (botonCopiar) {
                    const contenedorValor = botonCopiar.closest(
                        '.viena-copy-value[data-copy-value]'
                    );

                    const valorData = String(
                        contenedorValor?.dataset?.copyValue ||
                        contenedorValor?.getAttribute?.('data-copy-value') ||
                        ''
                    )
                        .replace(/\s+/g, '')
                        .trim();

                    if (valorData) {
                        return valorData;
                    }

                    const textoValor = String(
                        contenedorValor?.querySelector('.viena-copy-text')?.textContent ||
                        ''
                    )
                        .replace(/\s+/g, '')
                        .trim();

                    if (textoValor) {
                        return textoValor;
                    }
                }

                const tabla = filaActual.closest('table');

                if (tabla) {
                    const headers = Array.from(
                        tabla.querySelectorAll('thead th')
                    );

                    const indiceEdificio = headers.findIndex(th => {
                        const texto = String(th.textContent || '')
                            .replace(/\s+/g, ' ')
                            .trim()
                            .toLowerCase();

                        return (
                            texto === 'id edificio' ||
                            texto.includes('id edificio')
                        );
                    });

                    if (indiceEdificio >= 0) {
                        const celdas = Array.from(filaActual.querySelectorAll('td'));
                        const celda = celdas[indiceEdificio];

                        if (celda) {
                            const valorDirecto = celda.querySelector(
                                '.viena-copy-value[data-copy-value]'
                            );

                            const valorData = String(
                                valorDirecto?.dataset?.copyValue ||
                                valorDirecto?.getAttribute?.('data-copy-value') ||
                                ''
                            )
                                .replace(/\s+/g, '')
                                .trim();

                            if (valorData) {
                                return valorData;
                            }

                            const clon = celda.cloneNode(true);
                            clon.querySelectorAll('button, i, svg').forEach(el => el.remove());

                            const valorTexto = String(clon.textContent || '')
                                .replace(/\s+/g, '')
                                .trim();

                            if (valorTexto) {
                                return valorTexto;
                            }
                        }
                    }
                }
            }
        }

        // ------------------------------------------------------------
        // 3) FALLBACK UNIVERSAL DESDE "MENSAJE"
        // ------------------------------------------------------------
        // EXT v1.0.1 — fallback universal desde el textarea/Mensaje.
        // Cubre MM/PD y cualquier ticket HFC donde el ID figure como
        // "ID Edificio: 12345", "ID de Edificio 12345" o "Edificio: 12345".
        {
            const labelsMensaje = Array.from(
                document.querySelectorAll('.v-text-field__slot > label')
            );

            let textoMensaje = '';

            const labelMensaje = labelsMensaje.find(label => {
                return String(label.textContent || '')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .toLowerCase() === 'mensaje';
            });

            if (labelMensaje) {
                const campoMensaje = labelMensaje.closest('.v-input');

                const controlMensaje = campoMensaje?.querySelector(
                    'textarea, input'
                );

                textoMensaje = String(
                    controlMensaje?.value ||
                    controlMensaje?.textContent ||
                    ''
                );
            }

            // Algunas variantes de VIENA no exponen Mensaje como v-input.
            if (!textoMensaje) {
                textoMensaje = String(document.body?.innerText || '');
            }

            const matchElemento = textoMensaje.match(
                /(?:id\s*(?:de|del)?\s*edificio|id\s*edificio|edificio|(?:siguiente\s+)?elemento)\s*:?\s*(\d+)/i
            );

            const idDesdeMensaje = String(matchElemento?.[1] || '').trim();

            if (idDesdeMensaje) {
                return idDesdeMensaje;
            }
        }

        return '';
    }

    function limpiarValor(valor) {
        return String(valor || '')
            .replace(/[\s\u00A0\u2007\u202F]+/g, '');
    }

    function buscarCampoPorNombre(nombreBuscado) {
        const labels = document.querySelectorAll('.v-text-field__slot > label');

        for (const label of labels) {
            const nombre = String(label.textContent || '')
                .replace(/\s+/g, ' ')
                .trim();

            if (nombre !== nombreBuscado) continue;

            const campo = label.closest('.v-input');
            const input = campo?.querySelector('.v-text-field__slot > input');

            if (campo && input) {
                return { campo, input };
            }
        }

        return null;
    }

    function eliminarBotonesAccion() {
        document.querySelectorAll(
            '.viena-mira5-action-wrap, .viena-gpon-action-wrap'
        ).forEach(wrap => wrap.remove());
    }

    async function asegurarPaginaDestino(target) {
        try {
            return await chrome.runtime.sendMessage({
                type: 'VIENA_ENSURE_DESTINATION',
                target
            });
        } catch (error) {
            console.warn('[VIENA DESTINO] No se pudo validar/abrir destino:', target, error);
            return { ok: false, opened: false };
        }
    }

    async function validarFuentesActivo(boton) {
        const pingFuentes = async (timeoutMs = 2200) => {
            const ping = {
                id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
                ts: Date.now()
            };

            return await new Promise(async resolve => {
                let terminado = false;
                let listenerId = null;
                let timeoutId = null;

                const finalizar = ok => {
                    if (terminado) return;
                    terminado = true;
                    if (timeoutId !== null) clearTimeout(timeoutId);
                    if (listenerId !== null && typeof GM_removeValueChangeListener === 'function') {
                        try { GM_removeValueChangeListener(listenerId); } catch (_) {}
                    }
                    resolve(Boolean(ok));
                };

                try {
                    listenerId = GM_addValueChangeListener(
                        KEY_PONG_FUENTES,
                        (_nombre, _anterior, pong) => {
                            if (!pong || pong.id !== ping.id) return;
                            console.log('[VIENA FUENTES] PONG recibido:', pong);
                            finalizar(true);
                        }
                    );
                    await GM_setValue(KEY_PING_FUENTES, ping);
                    console.log('[VIENA FUENTES] PING enviado:', ping);
                    timeoutId = setTimeout(() => finalizar(false), timeoutMs);
                } catch (error) {
                    console.warn('[VIENA FUENTES] Error validando PING/PONG:', error);
                    finalizar(false);
                }
            });
        };

        if (await pingFuentes(2200)) return true;

        const ensured = await asegurarPaginaDestino('fuentes');
        if (!ensured?.ok) {
            avisoDestino(boton, 'No se pudo abrir Fuentes.');
            return false;
        }

        if (!ensured.opened) {
            avisoDestino(
                boton,
                'Fuentes ya está abierto, pero no respondió. Verificá la sesión o recargá esa pestaña.'
            );
            return false;
        }

        const inicio = Date.now();
        while (Date.now() - inicio < 18000) {
            await new Promise(resolve => setTimeout(resolve, 300));
            if (await pingFuentes(900)) return true;
        }

        avisoDestino(
            boton,
            'Fuentes se abrió, pero no quedó disponible a tiempo. Verificá la sesión o recargá esa pestaña.'
        );
        return false;
    }

    async function enviarAFuentes(nodo, boton, modo = 'fuentes') {
        try {
            const result=await chrome.runtime.sendMessage({type:'VIENA_FUENTES_SEARCH',nodo,modo});
            if(result?.ok){
                console.log('[VIENA FUENTES] Orden dirigida a una sola pestaña:', modo, nodo, result.tabId);
                return true;
            }
            avisoDestino(boton, result?.code==='receiver_unavailable' ? 'Fuentes está abierto, pero no respondió. Verificá la sesión o recargá esa pestaña.' : 'No se pudo abrir o automatizar Fuentes.');
            return false;
        } catch (error) {
            console.warn('[VIENA FUENTES] Error en envío dirigido:', error);
            avisoDestino(boton, 'No se pudo contactar Fuentes.');
            return false;
        }
    }

    async function validarMoicaActivo(boton, mostrarAviso = true) {
        const pingMoica = async (timeoutMs = 2600) => {
            const ping = { id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, ts: Date.now() };
            return await new Promise(async resolve => {
                let done = false, listenerId = null, timeoutId = null;
                const finish = ok => {
                    if (done) return;
                    done = true;
                    if (timeoutId) clearTimeout(timeoutId);
                    if (listenerId !== null && typeof GM_removeValueChangeListener === 'function') {
                        try { GM_removeValueChangeListener(listenerId); } catch (_) {}
                    }
                    resolve(Boolean(ok));
                };
                try {
                    listenerId = GM_addValueChangeListener(KEY_PONG_MOICA, (_n,_a,pong) => {
                        if (pong?.id === ping.id) finish(true);
                    });
                    await GM_setValue(KEY_PING_MOICA, ping);
                    timeoutId = setTimeout(() => finish(false), timeoutMs);
                } catch (_) { finish(false); }
            });
        };

        if (await pingMoica(2600)) return true;

        // Si MOICA estaba cerrado, limpiar una orden vieja ANTES de abrir una pestaña nueva.
        // Evita que el receptor recupere una orden de <30 s al iniciar y luego procese otra vez
        // la orden actual enviada por VIENA.
        try { await GM_setValue(KEY_ORDEN_MOICA, null); } catch (_) {}

        const ensured = await asegurarPaginaDestino('moica');
        if (!ensured?.ok) {
            if (mostrarAviso) avisoDestino(boton, 'No se pudo abrir MOICA.');
            return false;
        }

        if (!ensured.opened && !ensured.navigated) {
            if (mostrarAviso) avisoDestino(
                boton,
                'MOICA ya está abierto, pero no respondió. Verificá la sesión o recargá esa pestaña.'
            );
            return false;
        }

        const inicio = Date.now();
        while (Date.now() - inicio < 18000) {
            await new Promise(resolve => setTimeout(resolve, 300));
            if (await pingMoica(900)) return true;
        }

        if (mostrarAviso) avisoDestino(
            boton,
            'MOICA se abrió, pero no quedó disponible a tiempo. Verificá la sesión o recargá esa pestaña.'
        );
        return false;
    }

    async function enviarAMoica(nodo, boton) {
        nodo = limpiarValor(nodo).toUpperCase();
        if (!nodo) return false;

        console.log('[VIENA MOICA] Solicitud desde ticket:', { nodo });

        // FIX 14: el runtime pasa a ser el camino primario para asegurar la pestaña.
        // Así, si MOICA está cerrado, se abre /buscarTicket.php de inmediato; si está
        // en /home.php, el background reutiliza esa pestaña y navega al Buscar.
        // El canal GM histórico queda intacto como fallback, no se elimina.
        try {
            const directo = await chrome.runtime.sendMessage({ type: 'VIENA_MOICA_SEARCH', nodo });
            if (directo?.ok) {
                console.log('[VIENA MOICA] Orden enviada:', {
                    nodo, receptorActivo: true, canal: 'runtime',
                    opened: !!directo.opened, navigated: !!directo.navigated
                });
                return true;
            }
            console.warn('[VIENA MOICA] Runtime no completó la entrega; se usa fallback GM:', directo);
        } catch (error) {
            console.warn('[VIENA MOICA] Runtime no disponible; se usa fallback GM:', error);
        }

        // Fallback histórico: conserva exactamente el PING/PONG + KEY_ORDEN que ya
        // funcionaba antes. Sólo se ejecuta si la vía runtime no pudo completar.
        const activo = await validarMoicaActivo(boton, false);
        if (activo) {
            await GM_setValue(KEY_ORDEN_MOICA, { nodo, ts: Date.now(), nonce: Math.random().toString(36).slice(2) });
            console.log('[VIENA MOICA] Orden enviada:', { nodo, receptorActivo: true, canal: 'GM-fallback' });
            return true;
        }

        avisoDestino(boton, 'MOICA no está disponible. Verificá la sesión o recargá esa pestaña.');
        return false;
    }

    // FIX MOICA click delegado: VIENA/Vuetify puede reconstruir el botón dentro del
    // diálogo y dejar registrado el click en el DOM sin ejecutar la propiedad onclick
    // del nodo inyectado. Capturamos el click por clase a nivel document y usamos el
    // nodo autoritativo persistido en data-viena-moica-nodo. Sólo afecta a MOICA2.
    if (!globalThis.__vienaMoicaNodoDelegatedBound) {
        globalThis.__vienaMoicaNodoDelegatedBound = true;
        document.addEventListener('click', event => {
            const btn = event.target?.closest?.('.viena-moica-nodo-action-btn');
            if (!btn) return;

            event.preventDefault();
            event.stopPropagation();

            const nodo = String(
                esTicketFallaComponentesFuente()
                    ? (obtenerNodoFuenteDesdeMensaje() || btn.dataset?.vienaMoicaNodo || '')
                    : (btn.dataset?.vienaMoicaNodo || limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value) || '')
            )
                .replace(/[\s\u00A0\u2007\u202F]+/g, '')
                .toUpperCase();

            console.log('[VIENA MOICA] Click delegado capturado:', { nodo });
            if (!nodo) {
                avisoDestino(btn, 'No se pudo determinar el nodo para MOICA. Resincronizá el ticket y volvé a intentar.');
                return;
            }

            void enviarAMoica(nodo, btn).catch(error => {
                console.error('[VIENA MOICA] Error en click delegado:', error);
                avisoDestino(btn, 'No se pudo ejecutar MOICA. Verificá la sesión o recargá la pestaña de MOICA.');
            });
        }, true);
    }

    async function enviarAGrafanaVccap(nodo, cos, boton) {
        nodo = limpiarValor(nodo).toUpperCase();
        cos = String(cos || '').trim();
        if (!nodo || !cos) {
            avisoDestino(boton, 'No se encontró el COS asociado al nodo VCCAP.');
            return false;
        }

        try {
            const resultado = await chrome.runtime.sendMessage({
                type: 'VIENA_GRAFANA_VCCAP_SEARCH',
                nodo,
                cos
            });

            if (resultado?.ok) {
                console.log('[VIENA GRAFANA] Búsqueda enviada:', { nodo, cos });
                return true;
            }

            avisoDestino(
                boton,
                resultado?.mensaje ||
                'Grafana no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
            );
            return false;
        } catch (error) {
            console.warn('[VIENA GRAFANA] Error enviando búsqueda:', error);
            avisoDestino(
                boton,
                'Grafana no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
            );
            return false;
        }
    }

    function obtenerEstadoTicket() {
        const labels = document.querySelectorAll('.v-text-field__slot > label');

        for (const label of labels) {
            const nombre = String(label.textContent || '')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();

            if (nombre !== 'estado') continue;

            const campo = label.closest('.v-input');
            const input = campo?.querySelector('.v-text-field__slot > input');

            if (input) {
                return String(input.value || '')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .toUpperCase();
            }
        }

        return '';
    }

    function buscarCampoPersonaCompletado() {
        const labels = document.querySelectorAll('.v-text-field__slot > label');

        for (const label of labels) {
            const nombre = String(label.textContent || '')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();

            if (nombre !== 'persona completado') continue;

            const campo = label.closest('.v-input');
            if (campo) return campo;
        }

        return null;
    }

    function prepararHostAcciones(nodoCmts) {
        const completada = obtenerEstadoTicket() === 'COMPLETADA';

        if (!completada) {
            // En tickets normales conservamos EXACTAMENTE el host que ya funcionaba.
            return nodoCmts.campo.parentElement || nodoCmts.campo;
        }

        /*
         * En COMPLETADA reemplazamos visualmente "Persona completado" por el
         * contenedor de acciones. No dependemos del input vacío ni de su ID dinámico.
         */
        const persona = buscarCampoPersonaCompletado();

        if (!persona) {
            return nodoCmts.campo.parentElement || nodoCmts.campo;
        }

        let host = document.querySelector('.viena-completada-action-host');

        if (!host) {
            host = document.createElement('div');
            host.className = 'viena-completada-action-host';

            const contenedorPersona =
                persona.parentElement || persona;

            contenedorPersona.insertAdjacentElement('afterend', host);
        }

        // Ocultamos sólo el campo "Persona completado", sin tocar los demás campos.
        persona.style.display = 'none';

        return host;
    }

    // ================================================================
    // AVISO ANCLADO AL BOTÓN + VALIDACIÓN RÁPIDA
    // No altera el layout del ticket y no aplica transform/zoom.
    // Click sobre el aviso = cerrar.
    // ================================================================

    function cerrarAvisoDestino() {
        document.querySelectorAll('.viena-destino-aviso').forEach(el => el.remove());
    }

    function avisoDestino(boton, mensaje, tipo = 'error') {
        cerrarAvisoDestino();

        if (!boton || !document.documentElement.contains(boton)) return;

        const aviso = document.createElement('div');
        aviso.className = 'viena-destino-aviso';
        aviso.setAttribute('role', 'alert');
        aviso.title = 'Click para cerrar';

        const texto = document.createElement('span');
        texto.textContent = mensaje;
        aviso.appendChild(texto);

        Object.assign(aviso.style, {
            position: 'fixed',
            zIndex: '2147483647',
            maxWidth: '390px',
            padding: '10px 13px',
            borderRadius: '7px',
            border: tipo === 'ok'
                ? '1px solid rgba(255,255,255,.25)'
                : '1px solid rgba(255,255,255,.28)',
            background: tipo === 'ok' ? '#166534' : '#b42318',
            color: '#fff',
            font: '600 13px/1.35 system-ui, -apple-system, "Segoe UI", sans-serif',
            boxShadow: '0 5px 16px rgba(0,0,0,.24)',
            cursor: 'pointer',
            userSelect: 'none',
            margin: '0',
            transform: 'none',
            scale: '1',
            zoom: '1'
        });

        document.body.appendChild(aviso);

        const posicionar = () => {
            if (!document.documentElement.contains(aviso) ||
                !document.documentElement.contains(boton)) {
                aviso.remove();
                return;
            }

            const r = boton.getBoundingClientRect();
            const a = aviso.getBoundingClientRect();

            let left = r.left + (r.width / 2) - (a.width / 2);
            left = Math.max(8, Math.min(left, window.innerWidth - a.width - 8));

            let top = r.top - a.height - 9;

            // Si no entra arriba, lo mostramos debajo del botón.
            if (top < 8) {
                top = r.bottom + 9;
            }

            aviso.style.left = `${Math.round(left)}px`;
            aviso.style.top = `${Math.round(top)}px`;
        };

        posicionar();

        // El aviso no debe disparar acciones del ticket ni producir zoom.
        const cerrar = event => {
            event.preventDefault();
            event.stopPropagation();
            aviso.remove();
        };

        aviso.addEventListener('mousedown', cerrar);
        aviso.addEventListener('click', cerrar);

        const cerrarPorMovimiento = () => {
            if (document.documentElement.contains(aviso)) posicionar();
        };

        window.addEventListener('resize', cerrarPorMovimiento, { passive: true });
        window.addEventListener('scroll', cerrarPorMovimiento, { passive: true, capture: true });

        setTimeout(() => {
            window.removeEventListener('resize', cerrarPorMovimiento);
            window.removeEventListener('scroll', cerrarPorMovimiento, true);
            aviso.remove();
        }, tipo === 'ok' ? 2500 : 6500);
    }

    async function heartbeatVivo(key) {
        try {
            const hb = await GM_getValue(key, null);
            return Boolean(
                hb &&
                Number.isFinite(Number(hb.ts)) &&
                Date.now() - Number(hb.ts) <= HEARTBEAT_MAX_AGE
            );
        } catch (_) {
            return false;
        }
    }

    async function validarDestinoRapido(boton, key, nombreDestino) {
        const vivo = await heartbeatVivo(key);

        if (vivo) return true;

        avisoDestino(
            boton,
            `${nombreDestino} no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.`
        );

        return false;
    }

    function interpretarResultadoBridge(boton, resultado, nombreDestino) {
        // Compatibilidad defensiva con respuestas booleanas.
        if (resultado === true) return true;

        if (resultado && typeof resultado === 'object') {
            if (resultado.ok) return true;

            avisoDestino(
                boton,
                resultado.mensaje ||
                `${nombreDestino} recibió la orden pero no pudo completar la operación.`
            );
            return false;
        }

        avisoDestino(
            boton,
            `${nombreDestino} no respondió correctamente. Revisá la sesión y el estado de la página.`
        );
        return false;
    }


    // ================================================================
    // EFS — DETECCIÓN GD/PD + NÚMERO DE CLIENTE
    // ================================================================

    function obtenerMensajeTicket() {
        const labels = Array.from(document.querySelectorAll('.v-text-field__slot > label'));
        const label = labels.find(el =>
            String(el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase() === 'mensaje'
        );

        if (label) {
            const campo = label.closest('.v-input');
            const control = campo?.querySelector('textarea, input');
            const valor = String(control?.value || control?.textContent || '').trim();
            if (valor) return valor;
        }

        const textarea = document.querySelector('textarea[readonly]');
        return String(textarea?.value || textarea?.textContent || '').trim();
    }

    function normalizarContextoTicket(valor) {
        return String(valor || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();
    }

    function extraerNodosCampo(valor) {
        const tokens = String(valor || '')
            .toUpperCase()
            .split(/\s*[|;,/]\s*/g)
            .map(v => v.trim())
            .filter(v => /^[A-Z0-9_-]+$/.test(v));
        return [...new Set(tokens)];
    }

    function esTicketFibraOptica() {
        const mensaje = obtenerMensajeTicket();
        const textoPagina = String(document.body?.innerText || '');
        const msg = normalizarContextoTicket(mensaje);
        const pagina = normalizarContextoTicket(textoPagina);

        // Señales explícitas observadas en tickets de alarmas de fibra/FO.
        // No clasificamos todo VCCAP como fibra: VCCAP normal conserva sus accesos.
        const fiberCut = /\bfiber\s+cut\b/.test(msg);
        const fiberBreak = /\bfiber\s+break\b/.test(msg) || /root\s+cause\s*:\s*fiber/.test(msg);
        const eventoFO = /\b\d{6}fo\d+\b/i.test(textoPagina);
        const asuntoFibra = /tareas?\s+fibra\s+optica/.test(pagina);
        const alarmaVccapFibra = /changed\s+(?:critical|major|minor)?\s*alarm/.test(msg) &&
            /link\s*['"]?vccap_/.test(msg) && (fiberCut || fiberBreak);
        const onmsiFibra = /\bonmsi\b/.test(pagina) &&
            (fiberCut || fiberBreak || asuntoFibra || /vccap_\s*\[/.test(msg));

        return fiberCut || fiberBreak || eventoFO || asuntoFibra || alarmaVccapFibra || onmsiFibra;
    }

    function obtenerNodoFuenteDesdeMensaje() {
        const texto = obtenerMensajeTicket();

        // Formato original de Diagnóstico Falla componentes de fuente.
        // Si existe una línea explícita `Nodo: XXXXX`, sigue teniendo prioridad.
        const matchNodo = texto.match(/^\s*Nodo\s*:\s*([A-Z0-9_-]+)\s*$/im);
        const nodoExplicito = String(matchNodo?.[1] || '').trim().toUpperCase();
        if (nodoExplicito) return nodoExplicito;

        // HFC - Diagnostico de Caida de Modems (y tipificaciones equivalentes)
        // informa el nodo dentro de una o más líneas `Fuente [NODO] ...`.
        // Sólo usamos ese dato si TODAS las fuentes del mensaje apuntan al mismo
        // nodo. Si aparecen nodos diferentes, no adivinamos: se conserva el
        // fallback seguro al campo Nodo de VIENA.
        const nodosFuente = Array.from(
            texto.matchAll(/Fuente\s*\[\s*([A-Z0-9_-]+)\s*\]/gi),
            match => String(match?.[1] || '').trim().toUpperCase()
        ).filter(Boolean);
        const unicos = [...new Set(nodosFuente)];
        return unicos.length === 1 ? unicos[0] : '';
    }

    function obtenerNumeroClienteTicket() {
        const texto = obtenerMensajeTicket();

        const match = texto.match(
            /(?:(?:n(?:[°º]|ro\.?)?|n[uú]mero|num\.?|id)\s*(?:de\s*)?cliente|cliente)\s*:?\s*([0-9]+)/i
        );

        return String(match?.[1] || '').trim();
    }

    function obtenerIdEdificioEFS(contexto = null) {
        // A) Fuente más inmediata: Mensaje del ticket abierto.
        const mensaje = obtenerMensajeTicket();
        const matchMensaje = mensaje.match(
            /(?:id\s*(?:del|de)?\s*edificio|id\s*edificio|edificio)\s*:?\s*([0-9]+)/i
        );
        const desdeMensaje = String(matchMensaje?.[1] || '').trim();
        if (desdeMensaje) return desdeMensaje;

        // B) Tareas Internas: buscar la fila del evento GD/GE relacionado,
        // no la fila EFS. Esto cubre los casos donde el ID sólo figura allí.
        const ticketRed = String(
            contexto?.ticketRed ||
            obtenerContextoEFS?.()?.ticketRed ||
            ''
        ).replace(/\s+/g, '').trim().toUpperCase();

        if (ticketRed) {
            for (const fila of Array.from(document.querySelectorAll('tr'))) {
                const textoFila = String(fila.textContent || '')
                    .replace(/\s+/g, '')
                    .trim()
                    .toUpperCase();

                if (!textoFila.includes(ticketRed)) continue;

                const tabla = fila.closest('table');
                if (!tabla) continue;

                const headers = Array.from(tabla.querySelectorAll('thead th'));
                const indiceEdificio = headers.findIndex(th =>
                    String(th.textContent || '')
                        .replace(/\s+/g, ' ')
                        .trim()
                        .toLowerCase()
                        .includes('id edificio')
                );

                if (indiceEdificio < 0) continue;

                const celda = Array.from(fila.querySelectorAll('td'))[indiceEdificio];
                if (!celda) continue;

                const valorWrap = celda.querySelector(
                    '.viena-copy-value[data-copy-value]'
                );

                const valorData = String(
                    valorWrap?.dataset?.copyValue ||
                    valorWrap?.getAttribute?.('data-copy-value') ||
                    ''
                ).replace(/\s+/g, '').trim();

                if (valorData) return valorData;

                const valorTexto = String(
                    celda.querySelector('.viena-copy-text')?.textContent ||
                    celda.textContent ||
                    ''
                ).replace(/\D+/g, '').trim();

                if (valorTexto) return valorTexto;
            }
        }

        // C) Mantener intacto el mecanismo estable anterior como último fallback.
        return obtenerIdEdificioTareaInterna();
    }

    // Cache por ticket EFS: permite restaurar la pestaña NOTAS y conservar
    // inmediatamente la clasificación obtenida desde EVENTOS RELACIONADOS.
    const cacheRedEFS = new Map();
    const cargaEventosEFS = new Set();

    function obtenerTicketAbiertoEFS() {
        // PERF: body.innerText fuerza cálculo de layout de TODA la vista y esta función
        // se consulta varias veces durante el montaje SPA. Buscar sólo en el encabezado
        // visible evita bloquear Vue mientras abre/cierra un ticket.
        const candidatos = document.querySelectorAll(
            '.v-toolbar__title, .v-toolbar, .v-app-bar, header, [role="banner"], h1, h2, h3, h4'
        );
        for (const el of candidatos) {
            // Al cerrar un ticket Vuetify conserva durante la transición el diálogo viejo
            // en el DOM. No debe seguir contando como ticket abierto si ya no es visible.
            if (!visibleRapid(el)) continue;
            const dialogContent = el.closest('.v-dialog__content');
            if (dialogContent && !dialogContent.classList.contains('v-dialog__content--active')) continue;
            const texto = String(el.textContent || '');
            const match = texto.match(/TICKET:\s*([A-Z0-9_-]+)/i);
            if (match) return String(match[1] || '').trim().toUpperCase();
        }
        return '';
    }

    function leerRedDesdeEventosRelacionados() {
        const tablas = Array.from(document.querySelectorAll('table'));

        for (const tabla of tablas) {
            const headers = Array.from(tabla.querySelectorAll('thead th')).map(th =>
                String(th.textContent || '')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .toLowerCase()
            );

            const iEvento = headers.findIndex(h => h === 'nro evento' || h.includes('nro evento'));
            if (iEvento < 0) continue;

            const iTipoRed = headers.findIndex(h => h === 'tipo de red' || h.includes('tipo de red'));
            const iTipoZona = headers.findIndex(h => h === 'tipo de zona' || h.includes('tipo de zona'));
            const filas = Array.from(tabla.querySelectorAll('tbody tr'));

            for (const fila of filas) {
                const celdas = Array.from(fila.querySelectorAll('td'));
                const nroEvento = String(celdas[iEvento]?.textContent || '')
                    .replace(/\s+/g, '')
                    .trim()
                    .toUpperCase();

                const tipoRedTabla = iTipoRed >= 0
                    ? String(celdas[iTipoRed]?.textContent || '').trim().toUpperCase()
                    : '';
                const tipoZonaTabla = iTipoZona >= 0
                    ? String(celdas[iTipoZona]?.textContent || '').trim().toUpperCase()
                    : '';

                const match = nroEvento.match(/\b\d{6}(GD|GE|PD|EP|EE)\d+\b/);
                if (match) {
                    const tipoEvento = match[1];
                    const tecnologiaPorTabla =
                        tipoRedTabla === 'FTTH' ? 'FTTH' :
                        tipoRedTabla === 'HFC' ? 'HFC' : '';

                    return {
                        ticket: match[0],
                        tipo: tipoEvento,
                        // EE (Energía/Fuente) usa primero la clasificación real de
                        // la fila. Si VIENA todavía no la expuso, se conserva HFC
                        // como fallback operativo para habilitar Fuentes.
                        tecnologia: tecnologiaPorTabla ||
                            (tipoEvento === 'PD' || tipoEvento === 'EP' || tipoEvento === 'EE'
                                ? 'HFC'
                                : 'FTTH'),
                        tipoRedTabla,
                        tipoZonaTabla
                    };
                }

                // Segunda validación: si Viena informa FTTH/HFC pero el código
                // todavía no está visible, conservamos la tecnología.
                if (tipoRedTabla === 'FTTH' || tipoRedTabla === 'HFC') {
                    return {
                        ticket: nroEvento,
                        tipo: tipoRedTabla === 'FTTH' ? 'FTTH' : 'HFC',
                        tecnologia: tipoRedTabla,
                        tipoRedTabla,
                        tipoZonaTabla
                    };
                }
            }
        }

        return null;
    }

    function obtenerTicketRedDesdeNotas() {
        const tablas = Array.from(document.querySelectorAll('table'));

        for (const tabla of tablas) {
            const headers = Array.from(tabla.querySelectorAll('thead th'));
            const indiceMensaje = headers.findIndex(th =>
                String(th.textContent || '')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .toLowerCase()
                    .startsWith('mensaje')
            );

            if (indiceMensaje < 0) continue;

            const filas = Array.from(tabla.querySelectorAll('tbody tr'));

            for (const fila of filas) {
                const celdas = Array.from(fila.querySelectorAll('td'));
                const texto = String(celdas[indiceMensaje]?.textContent || '')
                    .replace(/\s+/g, '')
                    .trim()
                    .toUpperCase();

                const match = texto.match(/\b\d{6}(GD|GE|PD|EP)\d+\b/);
                if (match) {
                    return {
                        ticket: match[0],
                        tipo: match[1],
                        tecnologia: (match[1] === 'PD' || match[1] === 'EP') ? 'HFC' : 'FTTH'
                    };
                }
            }
        }

        return null;
    }

    function buscarTabPorTexto(textoBuscado) {
        const buscado = textoBuscado.toLowerCase();
        return Array.from(document.querySelectorAll(
            '.v-tabs a, .v-tabs .v-tab, [role="tab"], a, button'
        )).find(el =>
            String(el.textContent || '')
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase() === buscado
        ) || null;
    }

    function precargarEventosRelacionadosEFS() {
        const ticket = obtenerTicketAbiertoEFS();
        if (!ticket || cargaEventosEFS.has(ticket)) return;

        // Si la tabla ya está montada no tocamos ninguna pestaña.
        const yaDisponible = leerRedDesdeEventosRelacionados();
        if (yaDisponible) {
            cacheRedEFS.set(ticket, yaDisponible);
            setTimeout(asegurarBotonAccion, 0);
            return;
        }

        const tabEventos = buscarTabPorTexto('eventos relacionados');
        if (!tabEventos) return;

        cargaEventosEFS.add(ticket);

        // VIENA carga esta tabla de forma lazy. La abrimos sólo para provocar
        // su carga y dejamos EVENTOS RELACIONADOS seleccionado; la clasificación queda cacheada.
        tabEventos.click();

        let intentos = 0;
        const timer = setInterval(() => {
            intentos++;

            const red = leerRedDesdeEventosRelacionados();
            if (red) {
                cacheRedEFS.set(ticket, red);
                clearInterval(timer);
setTimeout(asegurarBotonAccion, 60);
                return;
            }

            if (intentos >= 30) {
                clearInterval(timer);

                // Permitimos reintentar si VIENA todavía no terminó de montar
                // Eventos Relacionados.
                cargaEventosEFS.delete(ticket);
setTimeout(asegurarBotonAccion, 150);
            }
        }, 100);
    }

    function obtenerContextoEFS() {
        const ticket = obtenerTicketAbiertoEFS();

        let red = leerRedDesdeEventosRelacionados();
        if (red && ticket) cacheRedEFS.set(ticket, red);

        if (!red && ticket) red = cacheRedEFS.get(ticket) || null;

        if (ticket) {
            /*
             * v1.5.43 — cualquier TAREA INTERNA puede tener como evento
             * relacionado PD/EP/GD/GE. El código de la tarea puede ser EFS,
             * ACE u otro; NO sirve para decidir HFC/FTTH.
             *
             * La fuente autoritativa para los botones MIRA5/GPON es siempre
             * Eventos Relacionados. Si aún no cargó, provocamos su carga.
             */
            if (!red) {
                setTimeout(precargarEventosRelacionadosEFS, 0);
            }
        } else if (!red) {
            red = obtenerTicketRedDesdeNotas();
        }

        let tipo = String(red?.tipo || '').toUpperCase();
        let tecnologia = String(red?.tecnologia || '').toUpperCase();

        // EXT v1.0.1 — MM y PD son búsquedas HFC/MIRA5.
        // Si Eventos Relacionados todavía no aportó clasificación, el código
        // del ticket abierto permite habilitar correctamente las acciones M5.
        const codigoTicketAbierto = String(ticket || '').toUpperCase();
        const matchTipoDirecto = codigoTicketAbierto.match(/\b\d{6}(MM|PD)\d+\b/);
        if (!tecnologia && matchTipoDirecto) {
            tipo = tipo || matchTipoDirecto[1];
            tecnologia = 'HFC';
        }

        /*
         * v1.5.42:
         * Para tickets EFS NO inferimos HFC/FTTH desde Nodo/Nodo CMTS.
         * La tecnología sale únicamente de la clasificación real ya leída
         * desde Eventos Relacionados (o de su cache por ticket).
         *
         * Esto evita que un GD/GE muestre MIRA 5 durante la carga inicial.
         */

        return {
            tipoRed: tipo,
            ticketRed: red?.ticket || '',
            tecnologia,
            tipoZona: String(red?.tipoZonaTabla || '').toUpperCase(),
            esFTTH: tecnologia === 'FTTH' || tipo === 'GD' || tipo === 'GE',
            esHFC: tecnologia === 'HFC' || tipo === 'PD' || tipo === 'EP',
            cliente: obtenerNumeroClienteTicket()
        };
    }

    function asegurarBotonAccion() {
        const contextoEFS = obtenerContextoEFS();
        const ticketEFS = obtenerTicketAbiertoEFS();
        // El identificador de la TAREA (EFS/ACE/etc.) no define la red.
        // Si estamos dentro de cualquier detalle TICKET, esperamos primero
        // la clasificación del evento relacionado.
        const esTicketInterno = !!ticketEFS;

        /*
         * v1.5.41:
         * En cualquier ticket interno esperamos la clasificación real de Eventos Relacionados antes
         * de decidir MIRA 5/GPON. La función obtenerContextoEFS() ya dispara
         * precargarEventosRelacionadosEFS(), que abre Eventos, lee PD/EP/GD/GE,
         * lo guarda en cache, vuelve a NOTAS y vuelve a ejecutar este render.
         *
         * Mientras eso ocurre NO mostramos un botón provisional incorrecto.
         */
        if (esTicketInterno && !contextoEFS.esFTTH && !contextoEFS.esHFC) {
            // Eliminar sólo acciones MIRA/GPON que hayan quedado de un render
            // provisional anterior. No tocamos Fuentes ni otros botones.
            document.querySelectorAll(
                '.viena-mira5-action-wrap, .viena-gpon-action-wrap'
            ).forEach(el => el.remove());

            setTimeout(precargarEventosRelacionadosEFS, 0);
            return;
        }

        const ftth = contextoEFS.esFTTH
            ? true
            : (contextoEFS.esHFC ? false : esTicketFTTH());

        const fallaFuente = esTicketFallaComponentesFuente();
        const nodo = buscarCampoPorNombre('Nodo');
        const nodoCmts = buscarCampoPorNombre('Nodo CMTS');

        if (!nodo || !nodoCmts) return;

        const host = prepararHostAcciones(nodoCmts);
        host.classList.add('viena-mira5-action-host');

        const claseDeseada = ftth
            ? 'viena-gpon-action-wrap'
            : 'viena-mira5-action-wrap';

        let wrap = host.querySelector(`:scope > .${claseDeseada}`);

        document.querySelectorAll(
            ftth ? '.viena-mira5-action-wrap:not(.viena-gpon-action-wrap)'
                 : '.viena-gpon-action-wrap'
        ).forEach(elemento => elemento.remove());

        if (!wrap) {
            wrap = document.createElement('div');
            wrap.className = ftth
                ? 'viena-mira5-action-wrap viena-gpon-action-wrap'
                : 'viena-mira5-action-wrap';
            host.appendChild(wrap);
        }

        let botonPrincipal = wrap.querySelector(
            '.viena-mira5-action-btn, .viena-gpon-action-btn'
        );

        if (!botonPrincipal) {
            botonPrincipal = document.createElement('button');
            botonPrincipal.type = 'button';
            wrap.prepend(botonPrincipal);
        }

        botonPrincipal.className = ftth
            ? 'viena-gpon-action-btn'
            : 'viena-mira5-action-btn';

        const valorNodo = limpiarValor(nodo?.input?.value);
        const valorNodoCmts = limpiarValor(nodoCmts?.input?.value);
        const valor = ftth ? valorNodo : (valorNodoCmts || valorNodo);
        const clienteEFS = contextoEFS.cliente;

        aplicarIconoPlataforma(
            botonPrincipal,
            ftth ? (valor ? `Ir a GPON - ${valor}` : 'Ir a GPON') : 'Ir a MIRA 5',
            ftth ? 'gpon' : 'mira'
        );

        botonPrincipal.onmousedown = event => {
            event.preventDefault();
            event.stopPropagation();
        };

        botonPrincipal.onclick = async event => {
            event.preventDefault();
            event.stopPropagation();

            const nodoActual = buscarCampoPorNombre('Nodo');
            const nodoCmtsActual = buscarCampoPorNombre('Nodo CMTS');
            const valorNodoActual = limpiarValor(nodoActual?.input?.value);
            const valorNodoCmtsActual = limpiarValor(nodoCmtsActual?.input?.value);
            const valorActual = ftth
                ? valorNodoActual
                : (valorNodoCmtsActual || valorNodoActual);

            const contextoActual = obtenerContextoEFS();
            const clienteActual = contextoActual.cliente;

            if (!valorActual && !(clienteActual && contextoActual.tipoRed === 'GD')) {
                console.warn(ftth
                    ? '[VIENA GPON] Nodo vacío'
                    : '[VIENA MIRA5] Nodo CMTS vacío');
                return;
            }

            const heartbeatKey = ftth
                ? KEY_HEARTBEAT_GPON
                : KEY_HEARTBEAT_STATS;

            const destinoRapido = ftth
                ? 'GPON'
                : 'MIRA 5 Estadísticas';

            // MIRA5/GPON pertenecen al userscript Bridge, por eso la
            // disponibilidad se consulta al Bridge y NO al storage GM_*
            // de Corporate (son almacenamientos separados).
            const bridgeDisponibilidad =
                (typeof unsafeWindow !== 'undefined' && unsafeWindow.VienaNocBridge)
                || window.VienaNocBridge;

            if (
                !bridgeDisponibilidad ||
                typeof bridgeDisponibilidad.disponible !== 'function' ||
                !await bridgeDisponibilidad.disponible(
                    'nodo',
                    ftth ? 'FTTH' : 'HFC'
                )
            ) {
                avisoDestino(
                    botonPrincipal,
                    `${destinoRapido} no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.`
                );
                return;
            }

            // Este userscript usa GM_* para Fuentes, por lo que Tampermonkey
            // lo ejecuta en sandbox. El Bridge Universal publica VienaNocBridge
            // en unsafeWindow (la ventana real de VIENA), no en window.
            const bridge =
                (typeof unsafeWindow !== 'undefined' && unsafeWindow.VienaNocBridge)
                || window.VienaNocBridge;
            if (!bridge || typeof bridge.buscar !== 'function') {
                console.error(ftth
                    ? '[VIENA GPON] VienaNocBridge no está disponible'
                    : '[VIENA MIRA5] VienaNocBridge no está disponible');
                avisoDestino(
                    botonPrincipal,
                    'El Bridge de VIENA no está disponible. Revisá que "VIENA NOC Bridge Universal" esté habilitado en Tampermonkey.'
                );
                return;
            }

            try {
                const ok = await bridge.buscar(
                    'nodo',
                    ftth ? 'FTTH' : 'HFC',
                    valorActual
                );
                const destino = ftth ? 'GPON' : 'MIRA 5 Estadísticas';
                const correcto = interpretarResultadoBridge(botonPrincipal, ok, destino);

                console.log(
                    ftth ? '[VIENA GPON] Resultado:' : '[VIENA MIRA5] Resultado:',
                    ok,
                    valorActual
                );

                if (!correcto) return;
            } catch (error) {
                console.error(
                    ftth ? '[VIENA GPON] Error:' : '[VIENA MIRA5] Error:',
                    error
                );
            }
        };

        // ========================================================
        // EFS GD / GE / PD — BOTONES ADICIONALES
        // El botón principal de Nodo queda intacto.
        // GD/GE: Nodo + Cliente + Edificio en GPON.
        // PD:    Nodo + Cliente en MIRA 5.
        // ========================================================

        let botonClienteEFS = wrap.querySelector('.viena-efs-cliente-action-btn');
        let botonEdificioGPON = wrap.querySelector('.viena-efs-edificio-gpon-action-btn');

        const esRedEFSReconocida = contextoEFS.esFTTH || contextoEFS.esHFC;

        if (esRedEFSReconocida && clienteEFS) {
            if (!botonClienteEFS) {
                botonClienteEFS = document.createElement('button');
                botonClienteEFS.type = 'button';
                botonClienteEFS.className = ftth
                    ? 'viena-gpon-action-btn viena-efs-cliente-action-btn'
                    : 'viena-mira5-action-btn viena-efs-cliente-action-btn';
                wrap.appendChild(botonClienteEFS);
            }

            botonClienteEFS.className = ftth
                ? 'viena-gpon-action-btn viena-efs-cliente-action-btn'
                : 'viena-mira5-action-btn viena-efs-cliente-action-btn';

            aplicarIconoPlataforma(
                botonClienteEFS,
                ftth ? `Ir a Cliente GPON - ${clienteEFS}` : `Ir a Cliente M5 - ${clienteEFS}`,
                ftth ? 'gpon' : 'mira'
            );

            botonClienteEFS.onmousedown = event => {
                event.preventDefault();
                event.stopPropagation();
            };

            botonClienteEFS.onclick = async event => {
                event.preventDefault();
                event.stopPropagation();

                const contextoActual = obtenerContextoEFS();
                const clienteActual = contextoActual.cliente;
                const nodoActual = buscarCampoPorNombre('Nodo');
                const nodoCmtsActual = buscarCampoPorNombre('Nodo CMTS');
                const valorNodoActual = limpiarValor(nodoActual?.input?.value);
                const valorNodoCmtsActual = limpiarValor(nodoCmtsActual?.input?.value);
                const nodoBusqueda = ftth
                    ? valorNodoActual
                    : (valorNodoCmtsActual || valorNodoActual);

                if (!clienteActual) return;

                const bridge =
                    (typeof unsafeWindow !== 'undefined' && unsafeWindow.VienaNocBridge)
                    || window.VienaNocBridge;

                if (
                    !bridge ||
                    typeof bridge.disponible !== 'function' ||
                    !await bridge.disponible('cliente', ftth ? 'FTTH' : 'HFC')
                ) {
                    avisoDestino(
                        botonClienteEFS,
                        ftth
                            ? 'GPON no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                            : 'MIRA 5 Cable Modem no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                    );
                    return;
                }

                if (typeof bridge.buscarCliente !== 'function') {
                    avisoDestino(
                        botonClienteEFS,
                        'El Bridge de VIENA no está disponible o no soporta búsqueda por cliente.'
                    );
                    return;
                }

                try {
                    const ok = await bridge.buscarCliente(
                        ftth ? 'FTTH' : 'HFC',
                        clienteActual,
                        nodoBusqueda
                    );

                    interpretarResultadoBridge(
                        botonClienteEFS,
                        ok,
                        ftth ? 'GPON' : 'MIRA 5 Cable Modem'
                    );
                } catch (error) {
                    console.error('[VIENA EFS CLIENTE] Error:', error);
                }
            };
        } else if (botonClienteEFS) {
            botonClienteEFS.remove();
        }

        if (contextoEFS.esFTTH) {
            const idEdificioGPON = obtenerIdEdificioEFS(contextoEFS);

            if (idEdificioGPON) {
                if (!botonEdificioGPON) {
                    botonEdificioGPON = document.createElement('button');
                    botonEdificioGPON.type = 'button';
                    botonEdificioGPON.className =
                        'viena-gpon-action-btn viena-efs-edificio-gpon-action-btn';
                    wrap.appendChild(botonEdificioGPON);
                }

                aplicarIconoPlataforma(
                    botonEdificioGPON,
                    `Ir a Edificio GPON - ${idEdificioGPON}`,
                    'gpon'
                );

                botonEdificioGPON.onmousedown = event => {
                    event.preventDefault();
                    event.stopPropagation();
                };

                botonEdificioGPON.onclick = async event => {
                    event.preventDefault();
                    event.stopPropagation();

                    const idActual = obtenerIdEdificioEFS(obtenerContextoEFS());
                    if (!idActual) return;

                    const bridge =
                        (typeof unsafeWindow !== 'undefined' && unsafeWindow.VienaNocBridge)
                        || window.VienaNocBridge;

                    if (
                        !bridge ||
                        typeof bridge.disponible !== 'function' ||
                        !await bridge.disponible('edificio', 'FTTH')
                    ) {
                        avisoDestino(
                            botonEdificioGPON,
                            'GPON no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                        );
                        return;
                    }

                    if (typeof bridge.buscar !== 'function') {
                        avisoDestino(
                            botonEdificioGPON,
                            'El Bridge de VIENA no está disponible.'
                        );
                        return;
                    }

                    try {
                        const ok = await bridge.buscar(
                            'edificio',
                            'FTTH',
                            idActual
                        );

                        interpretarResultadoBridge(
                            botonEdificioGPON,
                            ok,
                            'GPON'
                        );
                    } catch (error) {
                        console.error('[VIENA EFS EDIFICIO GPON] Error:', error);
                    }
                };
            } else if (botonEdificioGPON) {
                botonEdificioGPON.remove();
            }
        } else if (botonEdificioGPON) {
            botonEdificioGPON.remove();
        }


        // ========================================================
        // EDIFICIO M5
        // Sólo para: HFC - Diagnostico de caida de edifico
        // Se coloca entre MIRA 5 y Fuentes.
        // ========================================================

        const caidaEdificioHFC = esTicketCaidaEdificioHFC();
        const edificioEFSHFC =
            !ftth &&
            contextoEFS.tipoRed === 'EP' &&
            contextoEFS.tipoZona === 'EDIFICIO';

        // EXT v1.0.1 — MM/PD (y cualquier HFC) muestran Edificio M5 si
        // realmente existe un ID en Tareas Internas o en el textarea.
        const idEdificioHFCDetectado = !ftth
            ? (obtenerIdEdificioEFS(contextoEFS) || obtenerIdEdificioTareaInterna())
            : '';

        let botonEdificioM5 = wrap.querySelector('.viena-edificio-m5-action-btn');

        if ((caidaEdificioHFC || edificioEFSHFC || idEdificioHFCDetectado) && !ftth) {
            if (!botonEdificioM5) {
                botonEdificioM5 = document.createElement('button');
                botonEdificioM5.type = 'button';
                botonEdificioM5.className = 'viena-edificio-m5-action-btn';

                // Siempre inmediatamente después de MIRA 5.
                botonPrincipal.insertAdjacentElement(
                    'afterend',
                    botonEdificioM5
                );
            }

            const idEdificio =
                obtenerIdEdificioEFS(contextoEFS) ||
                obtenerIdEdificioTareaInterna();

            aplicarIconoPlataforma(
                botonEdificioM5,
                idEdificio ? `Ir a Edificio M5 - ${idEdificio}` : 'Ir a Edificio M5',
                'mira'
            );

            botonEdificioM5.onmousedown = event => {
                event.preventDefault();
                event.stopPropagation();
            };

            botonEdificioM5.onclick = async event => {
                event.preventDefault();
                event.stopPropagation();

                const idActual =
                    obtenerIdEdificioEFS(obtenerContextoEFS()) ||
                    obtenerIdEdificioTareaInterna();

                if (!idActual) {
                    console.warn(
                        '[VIENA EDIFICIO M5] No se encontró ID Edificio en Tareas Internas'
                    );
                    return;
                }

                const bridgeDisponibilidad =
                    (typeof unsafeWindow !== 'undefined' && unsafeWindow.VienaNocBridge)
                    || window.VienaNocBridge;

                if (
                    !bridgeDisponibilidad ||
                    typeof bridgeDisponibilidad.disponible !== 'function' ||
                    !await bridgeDisponibilidad.disponible('edificio', 'HFC')
                ) {
                    avisoDestino(
                        botonEdificioM5,
                        'MIRA 5 Cable Modem no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                    );
                    return;
                }

                const bridge =
                    (typeof unsafeWindow !== 'undefined' && unsafeWindow.VienaNocBridge)
                    || window.VienaNocBridge;

                if (!bridge || typeof bridge.buscar !== 'function') {
                    console.error(
                        '[VIENA EDIFICIO M5] VienaNocBridge no está disponible'
                    );
                    avisoDestino(
                        botonEdificioM5,
                        'El Bridge de VIENA no está disponible. Revisá que "VIENA NOC Bridge Universal" esté habilitado en Tampermonkey.'
                    );
                    return;
                }

                try {
                    // Misma orden "edificio / HFC" que usa la funcionalidad
                    // de ID Edificio. El destino del Bridge es:
                    // https://mira5-gdt.telecentro.net.ar/cablemodem_frontend.php
                    const ok = await bridge.buscar(
                        'edificio',
                        'HFC',
                        idActual
                    );

                    const correcto = interpretarResultadoBridge(
                        botonEdificioM5,
                        ok,
                        'MIRA 5 Cable Modem'
                    );

                    console.log(
                        '[VIENA EDIFICIO M5] Resultado:',
                        ok,
                        idActual
                    );

                    if (!correcto) return;
                } catch (error) {
                    console.error(
                        '[VIENA EDIFICIO M5] Error:',
                        error
                    );
                }
            };
        } else if (botonEdificioM5) {
            botonEdificioM5.remove();
        }


        // ========================================================
        // NODO CMTS EN MIRA 5 CABLE MODEM
        // Sólo: HFC Caída de Cable Modems / HFC Caída de Zona Técnica.
        // Usa la misma pestaña que Edificio M5, escribe Nodo CMTS + Enter.
        // ========================================================
        const tipifNodoCableM5 = normRapid(obtenerTipificacion());
        const habilitaNodoCableM5 = !ftth && (
            tipifNodoCableM5.includes('HFC - DIAGNOSTICO DE CAIDA DE CABLE MODEMS') ||
            tipifNodoCableM5.includes('HFC - CAIDA DE CABLE MODEMS') ||
            tipifNodoCableM5.includes('HFC - DIAGNOSTICO DE CAIDA DE ZONA TECNICA') ||
            tipifNodoCableM5.includes('HFC - CAIDA DE ZONA TECNICA')
        );
        let botonNodoCableM5 = wrap.querySelector('.viena-nodocm-m5-action-btn');
        if (habilitaNodoCableM5) {
            if (!botonNodoCableM5) {
                botonNodoCableM5 = document.createElement('button');
                botonNodoCableM5.type = 'button';
                botonNodoCableM5.className = 'viena-edificio-m5-action-btn viena-nodocm-m5-action-btn';
                const anchor = botonEdificioM5 || botonPrincipal;
                anchor.insertAdjacentElement('afterend', botonNodoCableM5);
            }
            const nodoCable = limpiarValor(nodoCmts?.input?.value) || limpiarValor(nodo?.input?.value);
            aplicarIconoPlataforma(
                botonNodoCableM5,
                nodoCable ? `Ir a Nodo M5 - ${nodoCable}` : 'Ir a Nodo M5',
                'mira'
            );
            botonNodoCableM5.onclick = async event => {
                event.preventDefault(); event.stopPropagation();
                const actual = limpiarValor(buscarCampoPorNombre('Nodo CMTS')?.input?.value) || limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value);
                if (!actual) return avisoDestino(botonNodoCableM5, 'Nodo CMTS vacío.');
                const bridge = (typeof unsafeWindow !== 'undefined' && unsafeWindow.VienaNocBridge) || window.VienaNocBridge;
                if (!bridge || typeof bridge.disponible !== 'function' || !await bridge.disponible('nodocm', 'HFC')) {
                    return avisoDestino(botonNodoCableM5, 'MIRA 5 Cable Modem no está disponible. Verificá que la pestaña esté abierta y con sesión iniciada.');
                }
                try {
                    const ok = await bridge.buscar('nodocm', 'HFC', actual);
                    interpretarResultadoBridge(botonNodoCableM5, ok, 'MIRA 5 Cable Modem');
                } catch (error) {
                    console.error('[VIENA NODO M5] Error:', error);
                }
            };
        } else if (botonNodoCableM5) {
            botonNodoCableM5.remove();
        }

        // ========================================================
        // MIRA 5 — MENÚ HOVER UNIFICADO
        // Mantiene el botón principal intacto. Al hacer hover despliega:
        // Nodo (Stats), List CMs (Cable Modem + Nodo CMTS + Filtrar),
        // Edificio y Cliente. Los dos últimos reutilizan exactamente sus
        // handlers existentes para no duplicar ni alterar lógica estable.
        // ========================================================
        if (!ftth) {
            let anchorMenu = wrap.querySelector('.viena-mira5-menu-anchor');
            if (!anchorMenu) {
                anchorMenu = document.createElement('span');
                anchorMenu.className = 'viena-mira5-menu-anchor';
                botonPrincipal.parentNode.insertBefore(anchorMenu, botonPrincipal);
                anchorMenu.appendChild(botonPrincipal);
            }

            let menu = anchorMenu.querySelector('.viena-mira5-hover-menu');
            if (!menu) {
                menu = document.createElement('div');
                menu.className = 'viena-mira5-hover-menu';
                anchorMenu.appendChild(menu);
            }


            // El :hover CSS puede perderse durante los rerenders de Vuetify. Mantener
            // además un estado explícito por pointerenter/pointerleave hace que el menú
            // abra de forma determinista y permite cruzar del botón al listado sin que
            // desaparezca en el pequeño espacio entre ambos.
            if (!anchorMenu.dataset.vienaM5HoverBound) {
                anchorMenu.dataset.vienaM5HoverBound = '1';
                let cerrarTimer = null;
                const ajustarDireccion = () => {
                    // Si no entra debajo del botón, desplegar hacia arriba. Esto evita
                    // zonas muertas cuando el acceso está cerca del borde inferior.
                    menu.classList.remove('viena-mira5-menu-up');
                    const r = anchorMenu.getBoundingClientRect();
                    const alto = Math.max(menu.scrollHeight || 0, 180);
                    const espacioAbajo = window.innerHeight - r.bottom;
                    const espacioArriba = r.top;
                    if (espacioAbajo < alto && espacioArriba > espacioAbajo) {
                        menu.classList.add('viena-mira5-menu-up');
                    }
                };
                const abrirMenu = () => {
                    if (cerrarTimer) { clearTimeout(cerrarTimer); cerrarTimer = null; }
                    ajustarDireccion();
                    anchorMenu.classList.add('viena-mira5-menu-open');
                };
                const cerrarMenu = () => {
                    anchorMenu.classList.remove('viena-mira5-menu-open');
                    cerrarTimer = null;
                };
                const programarCierre = () => {
                    if (cerrarTimer) clearTimeout(cerrarTimer);
                    // Gracia suficiente para movimientos rápidos/diagonales. El menú
                    // y el botón se solapan 1px, por lo que no existe hueco físico.
                    cerrarTimer = setTimeout(cerrarMenu, 320);
                };
                anchorMenu.addEventListener('pointerenter', abrirMenu);
                anchorMenu.addEventListener('pointerleave', programarCierre);
                anchorMenu.addEventListener('focusin', abrirMenu);
                anchorMenu.addEventListener('focusout', programarCierre);
                menu.addEventListener('pointerenter', abrirMenu);
                menu.addEventListener('pointerleave', programarCierre);
            }

            const asegurarItem = (key, texto) => {
                let b = menu.querySelector(`[data-viena-m5-menu="${key}"]`);
                if (!b) {
                    b = document.createElement('button');
                    b.type = 'button';
                    b.className = 'viena-mira5-hover-item';
                    b.dataset.vienaM5Menu = key;
                    menu.appendChild(b);
                }
                aplicarIconoPlataforma(b, texto, 'mira');
                return b;
            };

            const itemNodo = asegurarItem('nodo', 'Nodo');
            itemNodo.disabled = false;
            itemNodo.onclick = e => { e.preventDefault(); e.stopPropagation(); botonPrincipal.click(); };

            const itemList = asegurarItem('list-cms', 'List CMs');
            itemList.disabled = false;
            itemList.onclick = async e => {
                e.preventDefault(); e.stopPropagation();
                const actual = limpiarValor(buscarCampoPorNombre('Nodo CMTS')?.input?.value)
                    || limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value);
                if (!actual) return avisoDestino(itemList, 'Nodo CMTS vacío.');
                const bridge = (typeof unsafeWindow !== 'undefined' && unsafeWindow.VienaNocBridge) || window.VienaNocBridge;
                if (!bridge || typeof bridge.disponible !== 'function' || !await bridge.disponible('nodolist', 'HFC')) {
                    return avisoDestino(itemList, 'MIRA 5 Cable Modem no está disponible. Verificá que la pestaña esté abierta y con sesión iniciada.');
                }
                try {
                    const ok = await bridge.buscar('nodolist', 'HFC', actual);
                    interpretarResultadoBridge(itemList, ok, 'MIRA 5 Cable Modem');
                } catch (error) { console.error('[VIENA LIST CMS] Error:', error); }
            };

            // Edificio y Cliente conservan EXACTAMENTE la detección previa:
            // el menú sólo los muestra cuando su botón estable original existe.
            // No duplicamos ni reinterpretamos las reglas de tipificación/datos.
            let itemEdificio = menu.querySelector('[data-viena-m5-menu="edificio"]');
            if (botonEdificioM5) {
                // No reutilizar `idEdificio` del bloque de creación del botón: ese
                // const es local a dicho bloque y provocaba ReferenceError aquí.
                // Leer el dato nuevamente con los mismos extractores estables.
                const idEdificioMenu =
                    obtenerIdEdificioEFS(contextoEFS) ||
                    obtenerIdEdificioTareaInterna();
                itemEdificio = asegurarItem('edificio', `Edificio - ${idEdificioMenu || ''}`.trim().replace(/\s*-\s*$/, ''));
                itemEdificio.onclick = e => { e.preventDefault(); e.stopPropagation(); botonEdificioM5.click(); };
            } else if (itemEdificio) {
                itemEdificio.remove();
            }

            let itemCliente = menu.querySelector('[data-viena-m5-menu="cliente"]');
            if (botonClienteEFS && !contextoEFS.esFTTH) {
                itemCliente = asegurarItem('cliente', `Cliente - ${clienteEFS || ''}`.trim().replace(/\s*-\s*$/, ''));
                itemCliente.onclick = e => { e.preventDefault(); e.stopPropagation(); botonClienteEFS.click(); };
            } else if (itemCliente) {
                itemCliente.remove();
            }

            // Los accesos M5 secundarios dejan de ocupar ancho en la fila; siguen
            // vivos en DOM y conservan sus handlers para que el menú los reutilice.
            if (botonEdificioM5) botonEdificioM5.classList.add('viena-mira5-menu-secondary-hidden');
            if (botonNodoCableM5) botonNodoCableM5.classList.add('viena-mira5-menu-secondary-hidden');
            if (botonClienteEFS && !contextoEFS.esFTTH) botonClienteEFS.classList.add('viena-mira5-menu-secondary-hidden');
        }

        // ========================================================
        // ACCESOS POR TECNOLOGÍA REAL DEL NODO
        // La base sólo habilita familias; la lógica MIRA/GPON existente
        // sigue decidiendo qué acciones concretas puede usar el ticket.
        // ========================================================
        const nodoValorAcciones = limpiarValor(nodo.input.value);
        const nodosAcciones = extraerNodosCampo(nodoValorAcciones);
        const nodoAmbiguo = nodosAcciones.length > 1;
        const nodoUnicoAcciones = nodosAcciones.length === 1 ? nodosAcciones[0] : '';
        const ticketFibraOptica = esTicketFibraOptica();

        // Diagnóstico Falla componentes de fuente: para las acciones de Fuentes
        // la fuente autoritativa es el Mensaje (`Nodo: XXXXX`). El campo Nodo de
        // VIENA puede contener varios nodos concatenados y NO debe usarse para
        // decidir Óptico/RPHY. MIRA5 conserva su flujo independiente por Nodo CMTS.
        const nodoFuenteMensaje = fallaFuente ? obtenerNodoFuenteDesdeMensaje() : '';
        const nodoTecnologiaFuentes = nodoFuenteMensaje || nodoUnicoAcciones;
        const tecnologiaNodo = String(
            globalThis.VienaNodeTech?.get?.(nodoTecnologiaFuentes) || ''
        ).trim().toUpperCase();

        // Si el nodo no está en la base ACTIVA (por ejemplo un Legacy histórico
        // con Proceso Baja=1), no dejamos al ticket HFC sin accesos. En ese caso
        // conservamos el fallback operativo histórico: HFC sin tecnología activa
        // se trata como Legacy para Fuentes/Óptico. El estado COMPLETADA de la
        // tarea no participa de esta decisión.
        const sinTecnologiaActiva = !tecnologiaNodo;

        // v1.0.6.9 — fallback operativo desde el propio Mensaje del ticket.
        // Hay nodos HFC históricos que ya no figuran en la base activa (ej. MT91D),
        // pero VIENA expone explícitamente "Fuente [NODO]" en el diagnóstico.
        // En ese caso el ticket sigue necesitando Fuentes + Óptico aunque la base
        // no pueda clasificar el nodo. Sólo aplica si el nodo actual coincide.
        const textoTicketParaFuente = String(document.body?.innerText || '');
        const nodoRegexFuente = nodoValorAcciones.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const fuenteDelNodoEnMensaje = !!nodoValorAcciones && new RegExp(
            `Fuente\\s*\\[\\s*${nodoRegexFuente}\\s*\\]`, 'i'
        ).test(textoTicketParaFuente);

        // v1.0.6.11 — el contexto REAL del ticket manda sobre una clasificación
        // histórica de la base. Ejemplo validado: MT91D figura como MINIHUB en la
        // base, pero el ticket actual es HFC y su Mensaje expone `Fuente [MT91D]`.
        // Para ese caso operativo necesitamos Fuentes + Óptico. No convertimos
        // todos los MINIHUB: el override exige HFC real + Fuente del MISMO nodo.
        const minihubConFuenteHfc = tecnologiaNodo === 'MINIHUB' && !ftth &&
            contextoEFS.esHFC && fuenteDelNodoEnMensaje;
        const hfcOFuenteSinBase = !nodoAmbiguo && sinTecnologiaActiva &&
            (contextoEFS.esHFC || fuenteDelNodoEnMensaje);
        const legacyPorFallbackHfc = !ftth &&
            (hfcOFuenteSinBase || minihubConFuenteHfc);
        const esLegacy = tecnologiaNodo === 'LEGACY' || legacyPorFallbackHfc;
        const esRphy = tecnologiaNodo === 'RPHY';
        const esVccap = tecnologiaNodo === 'VCCAP';
        const cosVccap = esVccap
            ? String(globalThis.VienaNodeTech?.cos?.(nodoValorAcciones) || '').trim()
            : '';
        const esHfcBase = esLegacy || esRphy || esVccap;
        const esHfcOperativo = !ftth && (contextoEFS.esHFC || esHfcBase);

        // Los tickets FO/RPHY siguen necesitando las herramientas operativas
        // de la plataforma Fuentes. La marca "fibra/FO" no debe ocultar
        // Fuentes ni RPHY cuando la tecnología real del nodo es RPHY.
        // Conservamos el comportamiento previo para otras tecnologías de fibra.
        const permitirFuentesEnFibraRphy = ticketFibraOptica && !ftth && esRphy;

        // Regla FO por tecnología real del nodo:
        // - FO + VCCAP: NO mostrar Fuentes/RPHY.
        // - FO + RPHY: RPHY debe mostrarse siempre.
        // La visibilidad de RPHY no debe depender de la heurística de "ticket fibra";
        // únicamente de que la red no sea FTTH y la base clasifique el nodo como RPHY.
        const habilitaRphyNodo = !ftth && esRphy;

        // Los eventos EE / zona FUENTE son una señal operativa explícita:
        // deben ofrecer acceso a Fuentes aunque otra heurística de la página
        // haya marcado el ticket como fibra o el nodo no esté en la base activa.
        const ticketEnergiaFuente =
            contextoEFS.tipoRed === 'EE' ||
            contextoEFS.tipoZona === 'FUENTE';

        const habilitaFuentesNodo =
            !ftth &&
            (esHfcBase || ticketEnergiaFuente) &&
            (!ticketFibraOptica || permitirFuentesEnFibraRphy || ticketEnergiaFuente);

        const estadoAccesos = {
            nodo: nodoValorAcciones,
            nodosDetectados: nodosAcciones,
            nodoAmbiguo,
            fibraOptica: ticketFibraOptica,
            nodoFuente: nodoFuenteMensaje || '(usa Nodo)',
            nodoTecnologiaFuentes,
            tecnologiaBase: tecnologiaNodo || '(sin base)',
            ticketHFC: contextoEFS.esHFC,
            ticketFTTH: ftth,
            fuenteMismoNodo: fuenteDelNodoEnMensaje,
            overrideMinihubHFC: minihubConFuenteHfc,
            legacy: esLegacy,
            rphy: esRphy,
            vccap: esVccap,
            cosVccap: cosVccap || '(sin COS)',
            grafanaVccap: !!ticketEFS && esVccap && !!cosVccap,
            energiaFuente: ticketEnergiaFuente,
            fuentes: habilitaFuentesNodo,
            optico: !ticketFibraOptica && !ftth && esLegacy,
            rphyFuentesEnFO: permitirFuentesEnFibraRphy,
            rphyVisible: habilitaRphyNodo
        };

        // El observer SPA puede volver a detectar el mismo ticket varias veces
        // mientras Vue/Vuetify termina de montar la vista. Logueamos sólo cuando
        // cambia realmente el estado de accesos para no inundar la consola.
        const firmaAccesos = JSON.stringify(estadoAccesos);
        if (detectarCampos._ultimaFirmaAccesos !== firmaAccesos) {
            detectarCampos._ultimaFirmaAccesos = firmaAccesos;
            console.log('[VIENA ACCESOS]', estadoAccesos);
        }

        function asegurarBotonHerramienta(clase, texto, visible, plataforma, onClick) {
            let btn = wrap.querySelector(`.${clase}`);
            if (!visible) { if (btn) btn.remove(); return null; }
            if (!btn) {
                btn = document.createElement('button');
                btn.type = 'button';
                btn.className = `viena-fuentes-action-btn ${clase}`;
                wrap.appendChild(btn);
            }
            aplicarIconoPlataforma(btn, texto, plataforma);
            // Volvemos al comportamiento estable previo: no interceptar pointerdown.
            // Sólo evitamos que mousedown burbujee al contenedor de VIENA.
            btn.onpointerdown = null;
            btn.onmousedown = event => { event.stopPropagation(); };
            btn.style.removeProperty('transform');
            btn.style.removeProperty('scale');
            btn.style.removeProperty('zoom');
            btn.onclick = async event => {
                event.preventDefault(); event.stopPropagation();
                const actual = limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value);
                if (!actual) return;
                await onClick(actual, btn);
            };
            return btn;
        }

        // Fuentes → Nodo: Legacy, RPHY y VCCAP, excepto tickets identificados como fibra/FO.
        // En "Diagnóstico Falla componentes de fuente" el Nodo/Nodo CMTS de
        // VIENA puede traer varios nodos unidos por `|`. Para Fuentes manda el
        // nodo único declarado en el textarea Mensaje (ej. `Nodo: TR08BA`).
        const nodoDestinoFuentes = nodoFuenteMensaje || nodoValorAcciones;
        asegurarBotonHerramienta(
            'viena-fuentes-nodo-action-btn',
            nodoDestinoFuentes ? `Fuentes → Nodo - ${nodoDestinoFuentes}` : 'Fuentes → Nodo',
            habilitaFuentesNodo,
            'fuentes',
            (_actual, btn) => {
                const destinoActual = esTicketFallaComponentesFuente()
                    ? (obtenerNodoFuenteDesdeMensaje() || extraerNodosCampo(limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value))[0] || '')
                    : (extraerNodosCampo(limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value)).length === 1
                        ? extraerNodosCampo(limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value))[0]
                        : '');
                return enviarAFuentes(destinoActual, btn, 'fuentes');
            }
        );

        // Óptico → Nodo: exclusivamente Legacy y nunca en tickets de fibra/FO.
        asegurarBotonHerramienta(
            'viena-optico-nodo-action-btn',
            nodoTecnologiaFuentes ? `Óptico → Nodo - ${nodoTecnologiaFuentes}` : 'Óptico → Nodo',
            !ticketFibraOptica && !ftth && esLegacy,
            'fuentes',
            (_actual, btn) => enviarAFuentes(nodoTecnologiaFuentes, btn, 'opticos')
        );

        // RPHY → Nodo: exclusivamente RPHY. En tickets de falla de fuente también
        // usa el Nodo único del Mensaje, nunca el campo concatenado de VIENA.
        asegurarBotonHerramienta(
            'viena-rphy-nodo-action-btn',
            nodoTecnologiaFuentes ? `RPHY → Nodo - ${nodoTecnologiaFuentes}` : 'RPHY → Nodo',
            habilitaRphyNodo,
            'fuentes',
            (_actual, btn) => enviarAFuentes(nodoTecnologiaFuentes, btn, 'rphy')
        );

        // Grafana - Nodo: sólo en Tarea Interna cuando el Nodo figura como VCCAP
        // en la base activa y tiene COS/Equipo(OLT/CMTS) asociado. La pestaña
        // del dashboard Harmonic VCCAP debe estar abierta; no se abre una nueva.
        asegurarBotonHerramienta(
            'viena-grafana-vccap-action-btn',
            nodoValorAcciones ? `Grafana - ${nodoValorAcciones}` : 'Grafana - Nodo',
            !!ticketEFS && esVccap && !!cosVccap,
            'grafana',
            (actual, btn) => enviarAGrafanaVccap(actual, globalThis.VienaNodeTech?.cos?.(actual), btn)
        );

        // MOICA2 → Nodo: disponible tanto en HFC como en FTTH/GPON.
        // En "Diagnóstico Falla componentes de fuente" VIENA puede concatenar varios
        // nodos en Nodo/Nodo CMTS (ej. TI60A|TI60B). En ese caso la fuente autoritativa
        // es la línea explícita `Nodo: TI60A` del textarea Mensaje, igual que para
        // Fuentes/Óptico/RPHY. En el resto de tickets se conserva el flujo histórico.
        const nodoDestinoMoica = fallaFuente && nodoFuenteMensaje
            ? nodoFuenteMensaje
            : nodoValorAcciones;
        const botonMoicaNodo = asegurarBotonHerramienta(
            'viena-moica-nodo-action-btn',
            nodoDestinoMoica ? `MOICA2 → Nodo - ${nodoDestinoMoica}` : 'MOICA2 → Nodo',
            !!nodoDestinoMoica && (esHfcOperativo || ftth),
            'moica',
            (_actual, btn) => {
                const destinoActual = esTicketFallaComponentesFuente()
                    ? (obtenerNodoFuenteDesdeMensaje() || '')
                    : limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value);
                return enviarAMoica(destinoActual, btn);
            }
        );
        if (botonMoicaNodo) {
            // Guardamos en el propio botón el nodo ya resuelto por la lógica de VIENA.
            // Esto evita depender sólo del input readonly de Vuetify al ejecutar el click.
            botonMoicaNodo.dataset.vienaMoicaNodo = String(nodoDestinoMoica || '').trim().toUpperCase();
        }
    }

    function crearBoton(campo, input, nombre) {
        // Se mantiene esta función para no alterar la estructura de la base.
        // La decisión HFC/FTTH y la ubicación se resuelven de forma central.
        asegurarBotonAccion();
    }



    function buscarBotonSuperiorPorTexto(texto) {
        const esperado = String(texto || '').replace(/\s+/g, ' ').trim().toUpperCase();
        return Array.from(document.querySelectorAll('button')).find(btn =>
            String(btn.textContent || '').replace(/\s+/g, ' ').trim().toUpperCase() === esperado
        ) || null;
    }

    function asegurarBotonResincronizar() {
        const ticket = obtenerTicketAbiertoEFS();
        let btn = document.querySelector('.viena-ticket-resync-btn');

        if (!ticket) {
            if (btn) btn.remove();
            return;
        }

        // Anclarlo a la MISMA fila nativa de acciones del ticket. PRE-ASIGNAR es
        // el ancla estable: su parentElement contiene CREAR TAREA / ASIGNAR USUARIO / etc.
        const ancla = buscarBotonSuperiorPorTexto('PRE-ASIGNAR')
            || buscarBotonSuperiorPorTexto('CAMBIAR ESTADO')
            || buscarBotonSuperiorPorTexto('ASIGNAR USUARIO');
        const filaAcciones = ancla?.parentElement || null;

        if (!filaAcciones) {
            if (btn) btn.remove();
            return;
        }

        if (!btn) {
            btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'viena-ticket-resync-btn mx-3 v-btn v-btn--is-elevated v-btn--has-bg theme--dark v-size--default primary';
            btn.title = 'Recalcular herramientas y botones de este ticket';
        }

        // Misma altura que la fila nativa, fijado en la esquina derecha del encabezado.
        // margin-left:auto no sirve en esta vista porque el contenedor nativo no ocupa todo el ancho.
        if (btn.parentElement !== filaAcciones) filaAcciones.appendChild(btn);
        if (getComputedStyle(filaAcciones).position === 'static') filaAcciones.style.position = 'relative';
        filaAcciones.style.paddingRight = '150px';
        btn.style.position = 'absolute';
        btn.style.right = '12px';
        btn.style.top = '0';
        btn.style.marginLeft = 'auto';
        btn.style.marginRight = '0';
        if (!btn.disabled && !btn.classList.contains('viena-sync-ok')) {
            btn.innerHTML = '<span class="v-btn__content"> Resincronizar </span>';
        }

        btn.onclick = async event => {
            event.preventDefault();
            event.stopPropagation();
            if (btn.disabled) return;

            const ticketActual = obtenerTicketAbiertoEFS();
            const nodoActual = limpiarValor(buscarCampoPorNombre('Nodo')?.input?.value).toUpperCase();
            btn.disabled = true;
            btn.classList.remove('viena-sync-ok');
            btn.innerHTML = '<span class="v-btn__content"> Sincronizando... </span>';

            console.group(`[VIENA SYNC] ${ticketActual || 'ticket'} — resincronización manual`);
            console.log('[VIENA SYNC] Nodo leído:', nodoActual || '(vacío)');

            try {
                // Recalcular desde el DOM real. No cambia estado, motivo, notas ni datos del ticket.
                eliminarBotonesAccion();
                document.querySelectorAll('.viena-completada-action-host').forEach(el => el.remove());

                if (ticketActual) {
                    cacheRedEFS.delete(ticketActual);
                    cargaEventosEFS.delete(ticketActual);
                }

                // Primera lectura inmediata + reintentos mientras VIENA termina de montar
                // Eventos Relacionados / Nodo / Nodo CMTS.
                detectarCampos();
                setTimeout(precargarEventosRelacionadosEFS, 0);
                [120, 350, 700, 1200, 2000].forEach(ms => {
                    setTimeout(() => {
                        detectarCampos();
                        asegurarBotonAccion();
                    }, ms);
                });

                await dormir(1250);
                const ctx = obtenerContextoEFS();
                const botones = Array.from(document.querySelectorAll(
                    '.viena-mira5-action-btn, .viena-gpon-action-btn, .viena-fuentes-action-btn'
                )).map(x => String(x.textContent || '').replace(/\s+/g, ' ').trim());
                console.log('[VIENA SYNC] Contexto recalculado:', ctx);
                console.log('[VIENA SYNC] Botones detectados:', botones);

                btn.classList.add('viena-sync-ok');
                btn.innerHTML = '<span class="v-btn__content"> Resincronizado </span>';
                setTimeout(() => {
                    if (!document.documentElement.contains(btn)) return;
                    btn.classList.remove('viena-sync-ok');
                    btn.innerHTML = '<span class="v-btn__content"> Resincronizar </span>';
                }, 1400);
            } catch (error) {
                console.error('[VIENA SYNC] Error:', error);
                btn.innerHTML = '<span class="v-btn__content"> Error sync </span>';
            } finally {
                btn.disabled = false;
                console.groupEnd();
            }
        };
    }

    // ================================================================
    // DETECTAR NODO / NODO CMTS
    // ================================================================

    function detectarCampos() {

        asegurarBotonResincronizar();
        asegurarIniciarTareaTicket();
        asegurarAccionesRapidasListado();
        document.dispatchEvent(new CustomEvent('viena:ui-refresh'));

        /*
         * No usamos IDs como:
         *
         * input-593
         * input-594
         *
         * porque Vuetify puede cambiarlos.
         *
         * Detectamos por el texto estable del label.
         */

        const labels =
            document.querySelectorAll(
                '.v-text-field__slot > label'
            );


        labels.forEach(
            label => {

                const nombre =
                    label.textContent
                        .replace(
                            /\s+/g,
                            ' '
                        )
                        .trim();


                if (
                    !CAMPOS.includes(
                        nombre
                    )
                ) {

                    return;
                }


                const campo =
                    label.closest(
                        '.v-input'
                    );


                if (!campo) {
                    return;
                }


                const input =
                    campo.querySelector(
                        '.v-text-field__slot > input'
                    );


                if (!input) {
                    return;
                }


                crearBoton(
                    campo,
                    input,
                    nombre
                );
            }
        );
    }


    // ================================================================
    // RECEPTOR FUENTES — PESTAÑA YA ABIERTA
    // ================================================================

    function dormir(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function esperarElemento(selector, timeout = 15000) {
        const inicio = Date.now();

        while (Date.now() - inicio < timeout) {
            const elemento = document.querySelector(selector);
            if (elemento) return elemento;
            await dormir(100);
        }

        return null;
    }

    async function esperarCondicion(fn, timeout = 15000, intervalo = 60) {
        const inicio = Date.now();
        while (Date.now() - inicio < timeout) {
            const valor = fn();
            if (valor) return valor;
            await dormir(intervalo);
        }
        return null;
    }

    function normalizarNodo(valor) {
        return String(valor || '')
            .replace(/\s+/g, '')
            .trim()
            .toUpperCase();
    }

    // ================================================================
    // FUENTES v1.5.17 — FILTRO JQGRID + SECUENCIA SIN CARRERAS
    // ================================================================

    let fuentesEjecucionId = 0;

    function expandirFiltroNodos() {
        // v1.5.20:
        // NO redimensionar jqGrid. El resize sintético rompe el ancho/alineación
        // de las columnas de Fuentes. La búsqueda funciona sin modificar tamaños.
        return;
    }

    function normalizarTextoNodo(valor) {
        return String(valor || '')
            .trim()
            .toUpperCase()
            .replace(/\s+/g, '');
    }

    async function activarTabFuentes(modo, ejecucionId) {
        const href = modo === 'opticos' ? '#opticos' : (modo === 'rphy' ? '#rphy' : '#fuentes');
        const link = await esperarElemento(`a[href="${href}"][data-toggle="tab"]`, 10000);
        if (!link || ejecucionId !== fuentesEjecucionId) return false;
        const pane = document.querySelector(href);
        if (!pane?.classList.contains('active')) {
            try {
                if (window.jQuery && typeof jQuery(link).tab === 'function') jQuery(link).tab('show');
                else link.click();
            } catch (_) { link.click(); }
        }
        const inicio = Date.now();
        while (Date.now() - inicio < 10000) {
            if (ejecucionId !== fuentesEjecucionId) return false;
            if (document.querySelector(href)?.classList.contains('active')) return true;
            await dormir(60);
        }
        return false;
    }

    const CFG_FUENTES = {
        fuentes: {
            input:'#gs_nodosAlimenta', grid:'#grid-fuentes', nodo:'grid-fuentes_nodosAlimenta', detalle:'grid-fuentes_detalle',
            grafico:'a[href="#tabpanel-fuente-graficos-detalle-fuentes"]', detalleContainer:'#detalle-fuente-grid-fuentes', abrirGrafico:true
        },
        opticos: {
            input:'#gs_nodoAlimenta', grid:'#grid-opticos', nodo:'grid-opticos_nodoAlimenta', detalle:'grid-opticos_detalle',
            grafico:'a[href="#tabpanel-optico-graficos-detalle-opticos"]', detalleContainer:'#detalle-optico-grid-opticos', abrirGrafico:true
        },
        rphy: {
            input:'#gs_nodoRPHY', grid:'#grid-nodos-rphy', nodo:'grid-nodos-rphy_nodoRPHY', detalle:'grid-nodos-rphy_detalle',
            grafico:null, detalleContainer:'#detalle-nodo-rphy-grid-nodos-rphy', abrirGrafico:false
        }
    };

    function dispararEnter(input) {
        if (window.jQuery) {
            const $input = jQuery(input);
            for (const tipo of ['keydown','keypress','keyup']) {
                const ev=jQuery.Event(tipo); ev.which=13; ev.keyCode=13; ev.key='Enter'; ev.code='Enter'; $input.trigger(ev);
            }
        }
        for (const tipo of ['keydown','keypress','keyup']) {
            input.dispatchEvent(new KeyboardEvent(tipo,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true,cancelable:true}));
        }
    }

    async function aplicarFiltroGenerico(cfg, input, nodo, ejecucionId) {
        if (ejecucionId !== fuentesEjecucionId) return false;
        const grid=document.querySelector(cfg.grid); if(!grid) return false;
        // Armamos el observador ANTES del Enter. Al alternar tabs, jqGrid puede
        // conservar la fila de la búsqueda anterior; no debemos tomarla como
        // resultado de la nueva orden hasta que el grid realmente se recargue.
        let gridMutado = false;
        const obsGrid = new MutationObserver(() => { gridMutado = true; });
        obsGrid.observe(grid, {childList:true, subtree:true, characterData:true});
        input.focus();
        if (window.jQuery) {
            const $i=jQuery(input); $i.val('').trigger('input').trigger('change');
            input.value='';
            await dormir(35); if(ejecucionId!==fuentesEjecucionId)return false;
            $i.val(nodo).trigger('input').trigger('change'); input.value=nodo;
        } else {
            input.value=''; input.dispatchEvent(new Event('input',{bubbles:true})); input.dispatchEvent(new Event('change',{bubbles:true}));
            await dormir(35); if(ejecucionId!==fuentesEjecucionId)return false;
            input.value=nodo; input.dispatchEvent(new Event('input',{bubbles:true})); input.dispatchEvent(new Event('change',{bubbles:true}));
        }
        dispararEnter(input);
        try { if(window.jQuery && typeof jQuery(cfg.grid).triggerToolbar==='function') jQuery(cfg.grid).triggerToolbar(); } catch(_){}

        // Esperar el ciclo REAL de jqGrid. Se acepta una mutación del grid o el
        // loading overlay visible→oculto. Esto evita seleccionar una fila stale.
        const loadId = '#load_' + cfg.grid.replace(/^#/, '');
        let vioLoading = false;
        const recargado = await esperarCondicion(() => {
            if (ejecucionId !== fuentesEjecucionId) return false;
            const load = document.querySelector(loadId);
            const visible = !!(load && getComputedStyle(load).display !== 'none' && load.getClientRects().length);
            if (visible) vioLoading = true;
            return gridMutado || (vioLoading && !visible);
        }, 15000, 50);
        obsGrid.disconnect();
        return !!recargado && ejecucionId === fuentesEjecucionId;
    }

    function obtenerFilasCfg(cfg) {
        return Array.from(document.querySelectorAll(`${cfg.grid} tr.jqgrow, ${cfg.grid} tbody tr[id]`));
    }

    function filaNodoCfg(fila,cfg,esperado) {
        const celda=fila.querySelector(`td[aria-describedby="${cfg.nodo}"]`); if(!celda)return false;
        const bruto=String(celda.getAttribute('title')||celda.textContent||'').trim();
        if(normalizarTextoNodo(bruto)===esperado)return true;
        return bruto.toUpperCase().split(/[^A-Z0-9]+/).filter(Boolean).includes(esperado);
    }

    async function esperarFilaCfg(cfg,nodo,ejecucionId,timeout=30000) {
        const esperado=normalizarTextoNodo(nodo), inicio=Date.now(); let ultimoRefuerzo=0;
        while(Date.now()-inicio<timeout){
            if(ejecucionId!==fuentesEjecucionId)return null;
            const fila=obtenerFilasCfg(cfg).find(f=>filaNodoCfg(f,cfg,esperado)); if(fila)return fila;
            if(Date.now()-ultimoRefuerzo>1800){
                ultimoRefuerzo=Date.now(); const input=document.querySelector(cfg.input);
                if(input&&normalizarTextoNodo(input.value)===esperado) dispararEnter(input);
            }
            await dormir(80);
        }
        return null;
    }

    async function clickDetalleCfg(cfg,fila,nodo,ejecucionId) {
        if(ejecucionId!==fuentesEjecucionId)return false;
        try { if(window.jQuery&&fila.id) jQuery(cfg.grid).jqGrid('setSelection',fila.id,false); } catch(_){}
        const td=fila.querySelector(`td[aria-describedby="${cfg.detalle}"]`);
        const ojo=td?.querySelector('.glyphicon-eye-open'); if(!td||!ojo)return false;

        // Al alternar Fuentes / Ópticos / RPHY puede quedar visible el detalle de
        // la operación anterior. El BODY real demuestra que el click del ojo
        // vacía el contenedor y lo repuebla por AJAX. Exigimos esa transición
        // antes de abrir gráficos para no reutilizar un detalle stale.
        const contenedor = cfg.detalleContainer ? document.querySelector(cfg.detalleContainer) : null;
        let detalleMutado = false;
        let detalleVacio = false;
        let obsDetalle = null;
        if (contenedor) {
            // El AJAX de Fuentes/Ópticos primero vacía el contenedor y luego puede
            // volver a insertar EXACTAMENTE el mismo HTML. Comparar htmlAnterior
            // falla en búsquedas repetidas. Observamos el ciclo real de mutación.
            obsDetalle = new MutationObserver(() => {
                detalleMutado = true;
                if (!String(contenedor.innerHTML || '').trim()) detalleVacio = true;
            });
            obsDetalle.observe(contenedor, {childList:true, subtree:true, characterData:true});
        }
        if(window.jQuery) jQuery(ojo).trigger('click'); else ojo.click();

        if (contenedor) {
            const detalleNuevo = await esperarCondicion(() => {
                if (ejecucionId !== fuentesEjecucionId) return false;
                const lleno = !!String(contenedor.innerHTML || '').trim();
                return detalleMutado && lleno;
            }, 15000, 40);
            obsDetalle?.disconnect();
            if (!detalleNuevo || ejecucionId !== fuentesEjecucionId) return false;
        }

        if(!cfg.abrirGrafico) return true;

        const inicio=Date.now(); let tab=null;
        while(Date.now()-inicio<10000){
            if(ejecucionId!==fuentesEjecucionId)return false;
            tab=document.querySelector(cfg.grafico);
            if(tab&&tab.getClientRects().length>0)break;
            await dormir(70);
        }
        if(!tab){
            if(window.jQuery)jQuery(td).trigger('click');else td.click();
            const re=Date.now(); while(Date.now()-re<7000){tab=document.querySelector(cfg.grafico);if(tab&&tab.getClientRects().length>0)break;await dormir(70);}
        }
        if(!tab)return false;
        try { if(window.jQuery&&typeof jQuery(tab).tab==='function')jQuery(tab).tab('show');else tab.click(); } catch(_){tab.click();}
        return true;
    }

    async function automatizarFuentes(nodo, modo='fuentes') {
        nodo=normalizarTextoNodo(nodo); modo=String(modo||'fuentes').toLowerCase();
        const cfg=CFG_FUENTES[modo]; if(!nodo||!cfg)return;
        const ejecucionId=++fuentesEjecucionId;
        if(!await activarTabFuentes(modo,ejecucionId))return;
        const input=await esperarElemento(cfg.input,15000); if(!input||ejecucionId!==fuentesEjecucionId)return;
        if(!await aplicarFiltroGenerico(cfg,input,nodo,ejecucionId))return;
        const fila=await esperarFilaCfg(cfg,nodo,ejecucionId,30000); if(!fila||ejecucionId!==fuentesEjecucionId)return;
        await clickDetalleCfg(cfg,fila,nodo,ejecucionId);
    }

    function iniciarReceptorFuentes() {
        if (location.hostname !== 'fuentes.telecentro.net.ar') return false;

        // Evita registrar dos listeners en la misma pestaña.
        if (window.__VIENA_FUENTES_RECEPTOR_ACTIVO__) {
            return true;
        }

        window.__VIENA_FUENTES_RECEPTOR_ACTIVO__ = true;

        console.log('[VIENA FUENTES] Receptor único activo');

        const marcarPestanaFuentes = () => {
            const original=String(document.title||'');
            clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);
            clearTimeout(globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__);
            let on=false;
            const pulse=()=>{on=!on;document.title=on?`● VN · Fuentes · ${original}`:original;};
            pulse();
            globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__=setInterval(pulse,450);
            globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__=setTimeout(()=>{
                clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);
                document.title=original;
            },6000);
        };

        chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
            if(msg?.type!=='VIENA_FUENTES_RUN') return;
            const nodo=String(msg.nodo||'').trim().toUpperCase();
            const modo=String(msg.modo||'fuentes').toLowerCase();
            if(!nodo){sendResponse({ok:false,code:'invalid_node'});return;}
            marcarPestanaFuentes();
            automatizarFuentes(nodo,modo).then(()=>sendResponse({ok:true})).catch(error=>sendResponse({ok:false,code:'automation_failed',detail:String(error?.message||error)}));
            return true;
        });

        const publicarHeartbeatFuentes = () => {
            GM_setValue(KEY_HEARTBEAT_FUENTES, {
                ts: Date.now(),
                path: location.pathname
            });
        };

        // Sólo presencia. No toca jqGrid ni dispara automatizaciones.
        // Se conserva como diagnóstico/compatibilidad.
        publicarHeartbeatFuentes();
        setInterval(publicarHeartbeatFuentes, 2000);

        // v1.5.44 — respuesta activa a VIENA.
        // Recibir un PING NO toca filtros, jqGrid, filas ni gráficos.
        // Únicamente confirma que este userscript está vivo en Fuentes.
        GM_addValueChangeListener(
            KEY_PING_FUENTES,
            async (_nombre, _anterior, ping) => {
                if (!ping || !ping.id) return;

                try {
                    publicarHeartbeatFuentes();

                    await GM_setValue(KEY_PONG_FUENTES, {
                        id: ping.id,
                        ts: Date.now(),
                        path: location.pathname
                    });

                    console.log('[VIENA FUENTES] PING respondido:', ping.id);
                } catch (error) {
                    console.warn('[VIENA FUENTES] No se pudo responder PING:', error);
                }
            }
        );

        GM_addValueChangeListener(
            'viena_fuentes_orden',
            (_nombre, _anterior, orden, remoto) => {
                if (!orden || !orden.nodo) return;

                console.log(
                    '[VIENA FUENTES] Orden recibida:',
                    orden.nodo,
                    'remota:',
                    remoto
                );

                automatizarFuentes(orden.nodo, orden.modo || 'fuentes');
            }
        );

        const aplicarAncho = () => expandirFiltroNodos();

        if (document.readyState === 'loading') {
            document.addEventListener(
                'DOMContentLoaded',
                aplicarAncho,
                { once: true }
            );
        } else {
            aplicarAncho();
        }

        // Sólo observa reconstrucciones de jqGrid y con debounce amplio.
        // No ejecuta la automatización ni genera loops.
        let timerAncho = null;

        const observer = new MutationObserver(() => {
            clearTimeout(timerAncho);
            timerAncho = setTimeout(aplicarAncho, 300);
        });

        const arrancarObserver = () => {
            const gridBox = document.querySelector('#gbox_grid-fuentes') || document.body;

            if (gridBox) {
                observer.observe(gridBox, {
                    childList: true,
                    subtree: true
                });
            }
        };

        if (document.body) {
            arrancarObserver();
        } else {
            document.addEventListener(
                'DOMContentLoaded',
                arrancarObserver,
                { once: true }
            );
        }

        return true;
    }



    // ================================================================
    // ACCIONES RÁPIDAS — LISTADO DE TAREAS INTERNAS
    // ================================================================
    const RAPID_ASSIGN_KEY = 'viena_asignar_multiple_filtro';

    const sleepRapid = ms => new Promise(r => setTimeout(r, ms));
    const normRapid = v => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toUpperCase();
    const visibleRapid = el => !!(el && el.isConnected && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));

    function findTextRapid(selector, text) {
        const wanted = normRapid(text);
        return Array.from(document.querySelectorAll(selector)).find(el => visibleRapid(el) && normRapid(el.textContent) === wanted) || null;
    }

    async function waitRapid(fn, timeout = 7000, step = 30) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            const v = fn();
            if (v) return v;
            await sleepRapid(step);
        }
        return null;
    }

    function clickRapid(el) {
        if (!el) return false;
        el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
        el.click();
        return true;
    }

    function rowTaskSelected(row) {
        if (!row) return false;

        // Fuente de verdad pedida para Tareas Internas: el checkbox visual de
        // Vuetify. Un ticket seleccionado contiene el icono mdi-checkbox-marked
        // dentro de .v-input--selection-controls__input. No dependemos de
        // input.checked porque VIENA puede no reflejar ahí el estado durante rerenders.
        const visual = row.querySelector(
            '.v-input--selection-controls__input .v-icon.mdi-checkbox-marked, ' +
            '.v-input--selection-controls__input i.mdi-checkbox-marked'
        );
        if (visual) return true;

        // Fallback conservador por compatibilidad si VIENA vuelve a renderizar un
        // checkbox nativo, sin considerar ripple/dirty como selección por sí solos.
        const cb = row.querySelector('input[type="checkbox"]');
        return !!(cb && (cb.checked || cb.getAttribute('aria-checked') === 'true'));
    }

    function selectedTaskRows() {
        return Array.from(document.querySelectorAll('tbody tr')).filter(rowTaskSelected);
    }


    function obtenerHostToastSeguro() {
        // Los v-dialog persistent de Vuetify animan/escalean cuando reciben un click
        // "afuera". Un toast agregado a document.body cuenta como click externo.
        // Montarlo dentro del dialog activo de mayor z-index evita ese mini-zoom.
        const activos = Array.from(document.querySelectorAll('.v-dialog__content.v-dialog__content--active'))
            .map(content => ({
                content,
                dialog: content.querySelector('.v-dialog.v-dialog--active')
            }))
            .filter(({dialog}) => dialog && dialog.isConnected && getComputedStyle(dialog).display !== 'none')
            .sort((a, b) => {
                const za = Number.parseInt(getComputedStyle(a.content).zIndex || '0', 10) || 0;
                const zb = Number.parseInt(getComputedStyle(b.content).zIndex || '0', 10) || 0;
                return za - zb;
            });
        return activos.length ? activos[activos.length - 1].dialog : document.body;
    }

    function notifyRapid(message, type = 'error') {
        console.warn('[VIENA RAPID]', message);
        const ID = 'viena-corporate-toast';
        document.getElementById(ID)?.remove();
        const palette = {
            error:   { accent: '#c62828', icon: '!', title: 'VIENA NOC Tools' },
            warning: { accent: '#b26a00', icon: '!', title: 'VIENA NOC Tools' },
            success: { accent: '#2e7d32', icon: '✓', title: 'VIENA NOC Tools' },
            info:    { accent: '#1565c0', icon: 'i', title: 'VIENA NOC Tools' }
        };
        const cfg = palette[type] || palette.error;
        const toast = document.createElement('div');
        toast.id = ID;
        toast.setAttribute('role', type === 'error' ? 'alert' : 'status');
        toast.setAttribute('aria-live', type === 'error' ? 'assertive' : 'polite');
        Object.assign(toast.style, {
            position:'fixed', top:'18px', right:'18px', zIndex:'2147483647',
            width:'min(430px, calc(100vw - 32px))', background:'#fff', color:'#1f2937',
            border:'1px solid #d7e0ea', borderLeft:`5px solid ${cfg.accent}`, borderRadius:'10px',
            boxShadow:'0 12px 34px rgba(15,35,60,.24)', fontFamily:'Arial, sans-serif',
            display:'flex', alignItems:'flex-start', gap:'11px', padding:'13px 14px',
            opacity:'0', transform:'translateY(-8px)', transition:'opacity .16s ease, transform .16s ease'
        });
        const icon = document.createElement('div');
        icon.textContent = cfg.icon;
        Object.assign(icon.style, {width:'28px',height:'28px',minWidth:'28px',borderRadius:'50%',background:cfg.accent,color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:'17px',fontWeight:'800',lineHeight:'1'});
        const content = document.createElement('div');
        content.style.flex = '1';
        const title = document.createElement('div');
        title.textContent = cfg.title;
        Object.assign(title.style, {fontSize:'13px',fontWeight:'800',color:'#183b63',marginBottom:'2px'});
        const body = document.createElement('div');
        body.textContent = String(message || '');
        Object.assign(body.style, {fontSize:'14px',fontWeight:'600',lineHeight:'1.4'});
        content.append(title, body);
        const close = document.createElement('button');
        close.type = 'button'; close.textContent = '×'; close.setAttribute('aria-label','Cerrar notificación');
        Object.assign(close.style, {border:'0',background:'transparent',color:'#64748b',fontSize:'21px',lineHeight:'1',padding:'0 2px',cursor:'pointer'});
        toast.append(icon, content, close);
        const toastHost = obtenerHostToastSeguro();
        toast.dataset.vienaToastHost = toastHost === document.body ? 'body' : 'active-dialog';
        toastHost.appendChild(toast);
        let timer = 0;
        const remove = () => {
            if (!toast.isConnected) return;
            if (timer) clearTimeout(timer);
            toast.style.opacity = '0'; toast.style.transform = 'translateY(-8px)';
            setTimeout(() => toast.remove(), 180);
        };
        close.tabIndex = -1;
        close.addEventListener('pointerdown', event => { event.preventDefault(); event.stopPropagation(); }, true);
        close.addEventListener('mousedown', event => { event.preventDefault(); event.stopPropagation(); }, true);
        close.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); remove(); });
        toast.addEventListener('click', event => event.stopPropagation());
        requestAnimationFrame(() => { toast.style.opacity = '1'; toast.style.transform = 'translateY(0)'; });
        timer = setTimeout(remove, type === 'error' ? 5200 : 3600);
    }

    function rapidActiveOptionItems() {
        // IMPORTANTE: el drawer lateral de VIENA también usa role=listbox.
        // Nunca buscar opciones globalmente en [role=listbox], porque la primera
        // opción puede ser "Tareas de Campo" y provocar una navegación accidental.
        const overlays = Array.from(document.querySelectorAll('.v-menu__content')).filter(visibleRapid);
        const items = [];
        for (const overlay of overlays) {
            Array.from(overlay.querySelectorAll('.v-list-item')).filter(visibleRapid).forEach(i => items.push(i));
        }
        return items;
    }

    async function chooseVisibleListItem(text) {
        const wanted = normRapid(text);
        const item = await waitRapid(() => {
            // Prioridad absoluta a overlays Vuetify realmente visibles.
            const overlayItem = rapidActiveOptionItems().find(i => {
                const title = i.querySelector('.v-list-item__title');
                return title && normRapid(title.textContent) === wanted;
            });
            if (overlayItem) return overlayItem;

            // Fallback sólo dentro del diálogo activo; nunca en el drawer lateral.
            const scope = rapidDialogScope();
            if (scope === document) return null;
            return Array.from(scope.querySelectorAll('.v-list-item')).filter(visibleRapid).find(i => {
                const title = i.querySelector('.v-list-item__title');
                return title && normRapid(title.textContent) === wanted;
            }) || null;
        });
        if (!item) return false;
        return clickRapid(item);
    }

    async function chooseVisibleListItemAny(texts, timeout = 7000) {
        const wanted = (Array.isArray(texts) ? texts : [texts]).map(normRapid).filter(Boolean);
        if (!wanted.length) return '';

        const item = await waitRapid(() => {
            const overlayItem = rapidActiveOptionItems().find(i => {
                const title = i.querySelector('.v-list-item__title');
                return title && wanted.includes(normRapid(title.textContent));
            });
            if (overlayItem) return overlayItem;

            const scope = rapidDialogScope();
            if (scope === document) return null;
            return Array.from(scope.querySelectorAll('.v-list-item')).filter(visibleRapid).find(i => {
                const title = i.querySelector('.v-list-item__title');
                return title && wanted.includes(normRapid(title.textContent));
            }) || null;
        }, timeout, 30);

        if (!item) return '';
        const title = item.querySelector('.v-list-item__title');
        const elegido = String(title?.textContent || '').replace(/\s+/g, ' ').trim();
        clickRapid(item);
        return elegido;
    }

    async function seleccionarMotivoInicioTicket() {
        // VIENA usa dos etiquetas equivalentes según la tipificación/ticket.
        // Preferimos "Diagnóstico en curso" cuando existe y aceptamos
        // "Tarea Iniciada" como la misma intención operativa de iniciar el ticket.
        return await chooseVisibleListItemAny([
            'Diagnóstico en curso',
            'Tarea Iniciada'
        ], 7000);
    }

    function rapidDialogScope() {
        const dialogs = Array.from(document.querySelectorAll('.v-dialog')).filter(visibleRapid);
        return dialogs.length ? dialogs[dialogs.length - 1] : document;
    }

    function rapidSelects(scope = rapidDialogScope()) {
        return Array.from(scope.querySelectorAll('.v-input.v-select')).filter(visibleRapid);
    }

    function rapidSelectLabel(select) {
        return normRapid(select?.querySelector('label')?.textContent || '');
    }

    function rapidSelectValue(select) {
        return normRapid(Array.from(select?.querySelectorAll('.v-select__selection, .v-select__selection--comma') || [])
            .map(x => x.textContent || '').join(' '));
    }

    function openRapidSelect(select) {
        if (!select) return false;
        const target = select.querySelector('.v-input__append-inner, .v-input__icon--append, .v-select__slot, .v-select__selections') || select;
        return clickRapid(target);
    }

    async function openSelectByIndex(index) {
        const selects = rapidSelects();
        return openRapidSelect(selects[index]);
    }

    async function abrirSelectPorLabelExacto(labelTexto, timeout = 7000) {
        const wanted = normRapid(labelTexto);
        const select = await waitRapid(() => {
            const scope = rapidDialogScope();
            const labels = Array.from(scope.querySelectorAll('.v-select__slot > label, .v-input.v-select label')).filter(visibleRapid);
            const label = labels.find(l => normRapid(l.textContent) === wanted);
            return label?.closest('.v-input.v-select') || label?.closest('.v-input') || null;
        }, timeout, 35);
        if (!select) return false;
        const input = select.querySelector('.v-select__selections input, input[readonly]');
        const icon = select.querySelector('.v-input__icon--append, .mdi-menu-down');
        const slot = select.querySelector('.v-select__slot');
        // Vuetify 2 abre de forma más fiable desde el input/slot que desde el wrapper append-inner.
        for (const target of [input, slot, icon, select]) {
            if (!target) continue;
            target.dispatchEvent(new MouseEvent('mousedown', { bubbles:true, cancelable:true, view:window }));
            target.dispatchEvent(new MouseEvent('mouseup', { bubbles:true, cancelable:true, view:window }));
            target.click();
            await sleepRapid(15);
            if (rapidActiveOptionItems().length) return true;
        }
        return false;
    }

    async function seleccionarPrimeraOpcionVisible() {
        const item = await waitRapid(() =>
            rapidActiveOptionItems().find(i => i.querySelector('.v-list-item__title')) || null
        , 7000, 40);
        if (!item) return false;
        return clickRapid(item);
    }

    async function openRapidSelectFor({ labels = [], excludeValues = [], preferEmpty = false, fallbackIndex = null } = {}) {
        const wantedLabels = labels.map(normRapid);
        const excluded = excludeValues.map(normRapid);
        const select = await waitRapid(() => {
            const sels = rapidSelects();
            let candidates = sels.filter(sel => !excluded.includes(rapidSelectValue(sel)));
            if (wantedLabels.length) {
                const byLabel = candidates.find(sel => wantedLabels.some(label => rapidSelectLabel(sel).includes(label)));
                if (byLabel) return byLabel;
            }
            if (preferEmpty) {
                const empty = candidates.find(sel => !rapidSelectValue(sel));
                if (empty) return empty;
            }
            if (fallbackIndex !== null && sels[fallbackIndex]) return sels[fallbackIndex];
            return candidates[0] || null;
        }, 5000, 60);
        return openRapidSelect(select);
    }

    async function iniciarTareaSeleccionada() {
        // Iniciar Tarea vive únicamente dentro del detalle del ticket ASIGNADA.
        // El ticket ya está abierto: NO depende de checkboxes del listado ni vuelve a pulsar el ojo.
        const cambiar = await waitRapid(() => findTextRapid('button .v-btn__content', 'Cambiar Estado'));
        if (!cambiar) { notifyRapid('No apareció Cambiar Estado.'); return; }
        clickRapid(cambiar.closest('button'));

        if (!await chooseVisibleListItem('INICIADA')) { notifyRapid('No apareció el estado INICIADA.'); return; }
        await sleepRapid(150);

        // El diálogo de cambio de estado muestra el selector de motivo luego del estado.
        const motivoSelect = await waitRapid(() => {
            const dialogs = Array.from(document.querySelectorAll('.v-dialog')).filter(visibleRapid);
            const scope = dialogs.length ? dialogs[dialogs.length - 1] : document;
            const sels = Array.from(scope.querySelectorAll('.v-select__selections')).filter(visibleRapid);
            return sels[sels.length - 1] || null;
        });
        if (!motivoSelect) { notifyRapid('No apareció el selector de motivo.'); return; }
        clickRapid(motivoSelect);
        if (!await seleccionarMotivoInicioTicket()) {
            notifyRapid('No apareció un motivo válido para iniciar la tarea (Diagnóstico en curso / Tarea Iniciada).');
            return;
        }

        const textarea = await waitRapid(() => {
            const dialogs = Array.from(document.querySelectorAll('.v-dialog')).filter(visibleRapid);
            const scope = dialogs.length ? dialogs[dialogs.length - 1] : document;
            return Array.from(scope.querySelectorAll('textarea')).find(visibleRapid) || null;
        });
        if (!textarea) { notifyRapid('No apareció el campo Mensaje.'); return; }
        textarea.focus();
        const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
        setter ? setter.call(textarea, 'Se inicia diagnostico de ticket.') : (textarea.value = 'Se inicia diagnostico de ticket.');
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));

        const confirmar = await waitRapid(() => findTextRapid('button .v-btn__content', 'Confirmar'));
        if (!confirmar) { notifyRapid('No apareció Confirmar.'); return; }
        clickRapid(confirmar.closest('button'));
    }

    async function openMultipleAction(label, nombreAccion = 'esta acción múltiple') {
        const cantidad = selectedTaskRows().length;
        if (cantidad < 2) {
            notifyRapid(`Tenés que seleccionar 2 tickets o más para ${nombreAccion}.`);
            return false;
        }
        const action = await waitRapid(() => findTextRapid('button .v-btn__content', 'Acción multiple'));
        if (!action) { notifyRapid('No encontré Acción multiple.'); return false; }
        clickRapid(action.closest('button'));
        if (!await chooseVisibleListItem(label)) { notifyRapid(`No apareció ${label}.`); return false; }
        return true;
    }

    async function refreshTaskListAfterMultiple() {
        await sleepRapid(2000);
        const refresh = Array.from(document.querySelectorAll('button')).find(btn =>
            visibleRapid(btn) && btn.querySelector('.material-icons') && normRapid(btn.querySelector('.material-icons').textContent) === 'REFRESH'
        );
        if (refresh) clickRapid(refresh);
        else console.warn('[VIENA RAPID] No encontré el botón refresh del listado.');
    }

    async function iniciarMultiple() {
        if (!await openMultipleAction('Cambiar estado', 'Iniciar Multiple')) return;
        if (!await openRapidSelectFor({ labels: ['Estado'], preferEmpty: true, fallbackIndex: 0 })) { notifyRapid('No encontré el selector de Estado.'); return; }
        if (!await chooseVisibleListItem('INICIADA')) { notifyRapid('No apareció INICIADA.'); return; }
        // El tracer real confirma que VIENA etiqueta este control como
        // "Razón de cambio de estado". Buscar "Motivo" hacía agotar 2500 ms
        // antes de caer al fallback. Esperamos directamente el label real: el XHR
        // carga las razones y, apenas Vue monta el select, lo abrimos sin sleep fijo.
        let motivoAbierto = await abrirSelectPorLabelExacto('Razón de cambio de estado', 7000);
        if (!motivoAbierto) motivoAbierto = await openRapidSelectFor({ labels: ['Razón de cambio de estado'], excludeValues: ['INICIADA'], preferEmpty: true, fallbackIndex: 1 });
        if (!motivoAbierto) { notifyRapid('No encontré el selector de Motivo.'); return; }
        if (!await chooseVisibleListItem('Tarea Iniciada')) { notifyRapid('No apareció Tarea Iniciada.'); return; }
        const enviar = await waitRapid(() => findTextRapid('button .v-btn__content', 'Enviar'));
        if (!enviar) { notifyRapid('No apareció Enviar.'); return; }
        clickRapid(enviar.closest('button'));
        await refreshTaskListAfterMultiple();
    }

    async function getAssignFilter() {
        // La configuración se hace desde el panel de la extensión. Conservamos
        // local/sync y el antiguo localStorage sólo como respaldo de migración.
        const cfg = await chrome.storage.local.get([RAPID_ASSIGN_KEY]);
        let syncCfg = {};
        try { syncCfg = await chrome.storage.sync.get([RAPID_ASSIGN_KEY]); } catch (_) {}
        let siteValue = '';
        try { siteValue = String(localStorage.getItem(RAPID_ASSIGN_KEY + '__dev') || '').trim(); } catch (_) {}
        const value = String(cfg[RAPID_ASSIGN_KEY] || syncCfg[RAPID_ASSIGN_KEY] || siteValue || '').trim();
        if (!value) {
            notifyRapid('Configurá primero tu apellido en el panel de VIENA NOC Tools, en “Apellido para asignación”.', 'warning');
            return '';
        }
        await guardarAssignFilter(value);
        return value;
    }

    async function guardarAssignFilter(value) {
        value = String(value || '').trim();
        if (!value) return '';
        await chrome.storage.local.set({ [RAPID_ASSIGN_KEY]: value });
        try { await chrome.storage.sync.set({ [RAPID_ASSIGN_KEY]: value }); } catch (_) {}
        try { localStorage.setItem(RAPID_ASSIGN_KEY + '__dev', value); } catch (_) {}
        return value;
    }

    async function seleccionarTipificacionAsignarMultiple() {
        // FIX tracer 2026-09-18: el menú "Asignar usuario" puede seguir visible
        // unos milisegundos después de abrir el diálogo. No usar el primer overlay
        // visible: hay que abrir Tipificaciones y consumir EXCLUSIVAMENTE su listbox.
        const select = await waitRapid(() => {
            const scope = rapidDialogScope();
            if (scope === document) return null;
            const labels = Array.from(scope.querySelectorAll('.v-select__slot > label, .v-input.v-select label')).filter(visibleRapid);
            const lab = labels.find(l => normRapid(l.textContent) === 'TIPIFICACIONES');
            return lab?.closest('.v-input.v-select') || null;
        }, 7000, 25);
        if (!select) return false;

        const slot = select.querySelector('.v-input__slot[aria-owns], .v-select__slot');
        const input = select.querySelector('.v-select__selections input[readonly], input[readonly]');
        const owns = slot?.getAttribute('aria-owns') || input?.getAttribute('aria-owns') || '';
        if (!slot) return false;

        // Un solo click real. No reutilizamos clickRapid acá porque su mousedown
        // adicional no es necesario para este v-select y puede duplicar acciones.
        slot.click();

        const list = await waitRapid(() => {
            const byOwns = owns ? document.getElementById(owns) : null;
            if (byOwns && visibleRapid(byOwns)) return byOwns;
            // Vuetify usa list-<numero del input> cuando aria-owns no está en el input.
            const derived = input?.id ? document.getElementById(`list-${input.id.replace(/^input-/, '')}`) : null;
            return derived && visibleRapid(derived) ? derived : null;
        }, 7000, 25);
        if (!list) return false;

        const option = await waitRapid(() =>
            Array.from(list.querySelectorAll('[role="option"].v-list-item, .v-list-item[role="option"]'))
                .find(el => visibleRapid(el) && el.querySelector('.v-list-item__title')) || null
        , 7000, 25);
        if (!option) return false;

        // Snapshot justo ANTES del click que dispara la carga de usuarios.
        // Resource Timing incorpora la entrada cuando el request termina, incluso si
        // los detalles cross-origin quedan opacos. Comparar cantidad evita confundir
        // una carga anterior con la que acabamos de disparar.
        let usersResourceCountBefore = 0;
        try {
            usersResourceCountBefore = (performance.getEntriesByType?.('resource') || [])
                .filter(e => String(e?.name || '').includes('/users/typification/')).length;
        } catch (_) {}
        const usersRequestClickedAt = performance.now();

        option.click();

        // No avanzar a Usuarios hasta que el propio control de Tipificaciones
        // muestre la selección. La aparición del input Usuarios se espera después.
        const selected = !!(await waitRapid(() => {
            const txt = Array.from(select.querySelectorAll('.v-select__selection, .v-select__selection--comma'))
                .map(x => String(x.textContent || '').trim()).filter(Boolean).join(' ');
            return txt || false;
        }, 5000, 25));
        if (!selected) return false;
        return { usersResourceCountBefore, usersRequestClickedAt };
    }

    async function asignarMultiple() {
        // Guardar la selección antes de leer la configuración: Vuetify puede reconstruir
        // la tabla al perder foco y desmarcar visualmente los checkboxes.
        const seleccionInicial = selectedTaskRows();
        if (seleccionInicial.length < 2) { notifyRapid('Tenés que seleccionar 2 tickets o más para Asignar Multiple.'); return; }
        const seleccion = seleccionInicial.map(row => {
            const texto = String(row.textContent || '').replace(/\s+/g, ' ').trim();
            const ticket = (texto.match(/\b26\d{8,}\b/) || [])[0] || '';
            return { ticket, texto };
        });

        let filter = await getAssignFilter();
        if (!filter) return;

        // Si un rerender dejó sin selección visual, restaurar exactamente las filas
        // que el operador ya había seleccionado y continuar en ESTE mismo click.
        if (!selectedTaskRows().length) {
            const rows = Array.from(document.querySelectorAll('tbody tr'));
            for (const sel of seleccion) {
                const row = rows.find(r => {
                    const t = String(r.textContent || '').replace(/\s+/g, ' ').trim();
                    return sel.ticket ? t.includes(sel.ticket) : t === sel.texto;
                });
                const cb = row?.querySelector('input[type="checkbox"]');
                const control = row?.querySelector('.v-input--selection-controls__input');
                if (row && !rowTaskSelected(row)) clickRapid(cb || control);
            }
            await sleepRapid(120);
        }

        if (!await openMultipleAction('Asignar usuario', 'Asignar Multiple')) return;

        // Primer selector: tipificación. VIENA puede cambiar los IDs y el orden,
        // por eso se abre por label y, como fallback, el primer v-select vacío.
        // El DOM real usa label exacto "Tipificaciones" y un input readonly dinámico (input-####).
        // Abrimos ese v-select por label, nunca por ID ni por posición.
        const tipificacionLoad = await seleccionarTipificacionAsignarMultiple();
        if (!tipificacionLoad) {
            notifyRapid('No pude abrir/seleccionar Tipificaciones en su menú correcto.'); return;
        }

        // FASE 1 obligatoria: VIENA debe registrar la tipificación ANTES de tocar Usuarios.
        const tipificacionConfirmada = await waitRapid(() => {
            const scope = rapidDialogScope();
            const labels = Array.from(scope.querySelectorAll('label')).filter(visibleRapid);
            const lab = labels.find(l => normRapid(l.textContent) === 'TIPIFICACIONES');
            const control = lab?.closest('.v-input.v-select') || lab?.closest('.v-input');
            if (!control) return false;
            const seleccion = Array.from(control.querySelectorAll('.v-select__selection, .v-select__selection--comma'))
                .map(x => String(x.textContent || '').trim()).filter(Boolean).join(' ');
            return seleccion ? control : false;
        }, 5000, 25);
        if (!tipificacionConfirmada) {
            notifyRapid('VIENA no confirmó la tipificación; no se continuó con la asignación.'); return;
        }

        // MISMO PRINCIPIO que el fix estable de Asignar e Iniciar: no escribimos
        // absolutamente nada en Usuarios hasta que terminó la carga que provoca el
        // montaje definitivo del autocomplete. Primero esperamos la NUEVA respuesta
        // /users/typification disparada por el click anterior; recién después buscamos
        // el input definitivo y escribimos el apellido una sola vez.
        await esperarCargaUsuariosTipificacionRapid(tipificacionLoad, 5000);

        const userInputReady = await waitRapidDom(() => {
            const scope = rapidDialogScope();
            if (scope === document) return null;
            const labels = Array.from(scope.querySelectorAll('label')).filter(visibleRapid);
            const lab = labels.find(l => ['USUARIO','USUARIOS'].includes(normRapid(l.textContent)) || normRapid(l.textContent).includes('USUARIO'));
            const control = lab?.closest('.v-input');
            const input = control?.querySelector('input:not([readonly]):not([disabled])');
            if (!input || !visibleRapid(input)) return null;
            if (control?.classList.contains('v-input--is-loading')) return null;
            if (control?.querySelector('.v-progress-linear--active, .v-progress-circular')) return null;
            return input;
        }, 7000);
        if (!userInputReady) { notifyRapid('VIENA no terminó de habilitar el buscador de Usuario.'); return; }

        // FASE 2: una sola escritura sobre el autocomplete definitivo.
        await escribirUsuarioRapid(userInputReady, filter);

        // No usar jamás "primer item visible" como fallback: el tracer mostró que
        // mientras VIENA consulta /users/typification todavía puede quedar visible el
        // menú de Tipificaciones, y ese fallback terminaba pulsando una tipificación
        // en lugar del usuario. Esperamos exclusivamente una opción del autocomplete
        // Usuarios cuyo texto contenga el filtro configurado.
        let activeMultipleUserInput = userInputReady;
        const buscarUsuarioAsignarMultiple = () => waitRapid(() => {
            const current = Array.from(rapidDialogScope().querySelectorAll('.v-autocomplete input:not([readonly]):not([disabled]), input[type="text"]:not([readonly]):not([disabled])')).find(inp => {
                if (!visibleRapid(inp)) return false;
                const label = inp.closest('.v-input')?.querySelector('label');
                return label && normRapid(label.textContent).includes('USUARIO');
            }) || activeMultipleUserInput;
            if (current && current !== activeMultipleUserInput) activeMultipleUserInput = current;
            const control = activeMultipleUserInput.closest('.v-input.v-autocomplete, .v-input.v-select') || activeMultipleUserInput.closest('.v-input');
            const owns = control?.querySelector('[aria-owns]')?.getAttribute('aria-owns') || activeMultipleUserInput.getAttribute('aria-owns');
            const derivedListId = activeMultipleUserInput.id ? `list-${activeMultipleUserInput.id.replace(/^input-/, '')}` : '';
            let candidates = [];
            const list = (owns && document.getElementById(owns)) || (derivedListId && document.getElementById(derivedListId));
            if (list && visibleRapid(list)) candidates = Array.from(list.querySelectorAll('.v-list-item[role="option"], .v-list-item'));
            const wanted = normRapid(filter);
            return candidates.find(item => {
                if (!visibleRapid(item)) return false;
                const title = item.querySelector('.v-list-item__title');
                return title && normRapid(title.textContent).includes(wanted);
            }) || null;
        }, 10000, 50);

        let userItem = await buscarUsuarioAsignarMultiple();
        if (!userItem) {
            notifyRapid(`No apareció ningún usuario que coincida con "${filter}". Revisá “Apellido para asignación” en el panel de VIENA NOC Tools y volvé a intentar.`, 'error');
            return;
        }
        clickRapid(userItem);

        // Confirmar el DOM REAL de Vuetify después de seleccionar Usuario.
        // En este autocomplete VIENA NO crea .v-select__selection: renderiza dos
        // <span> con nombre/grupo y un hidden con [object Object]. El tracer 18/09
        // confirmó exactamente esa estructura. No bloqueamos Enviar esperando una
        // clase que nunca existe.
        const usuarioSeleccionado = await waitRapid(() => {
            const control = activeMultipleUserInput.closest('.v-input');
            if (!control) return false;
            const hidden = control.querySelector('input[type="hidden"]');
            const spans = Array.from(control.querySelectorAll('.v-select__selections span'))
                .map(el => String(el.textContent || '').trim())
                .filter(Boolean);
            const hiddenOk = String(hidden?.value || '') === '[object Object]';
            const nombreOk = spans.some(t => normRapid(t).includes(normRapid(filter)));
            return hiddenOk && nombreOk;
        }, 2500, 40);
        if (!usuarioSeleccionado) { notifyRapid('VIENA no confirmó la selección del usuario; no se envió la asignación.'); return; }

        const enviar = await waitRapid(() => findTextRapid('button .v-btn__content', 'Enviar'));
        if (!enviar) { notifyRapid('No apareció Enviar.'); return; }
        clickRapid(enviar.closest('button'));
        await refreshTaskListAfterMultiple();
    }

    async function waitRapidDom(fn, timeout = 12000) {
        // Reactivo: comprueba inmediatamente y después sólo cuando cambia el DOM.
        // Un fallback corto cubre cambios de propiedades Vue que no generan mutación.
        const initial = fn();
        if (initial) return initial;
        return await new Promise(resolve => {
            let done = false;
            let observer = null;
            let fallback = null;
            let timer = null;
            const finish = value => {
                if (done) return;
                done = true;
                try { observer?.disconnect(); } catch (_) {}
                if (fallback) clearInterval(fallback);
                if (timer) clearTimeout(timer);
                resolve(value || null);
            };
            const check = () => {
                try {
                    const value = fn();
                    if (value) finish(value);
                } catch (_) {}
            };
            observer = new MutationObserver(check);
            observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
            fallback = setInterval(check, 25);
            timer = setTimeout(() => finish(null), timeout);
            check();
        });
    }

    async function esperarCargaUsuariosTipificacionRapid(marker = {}, timeout = 5000) {
        // La primera implementación miraba sólo si existía ALGUNA entrada
        // /users/typification posterior a un timestamp amplio. Eso podía coincidir
        // con una carga previa del diálogo y liberar la escritura demasiado pronto.
        // Ahora tomamos un snapshot justo antes del click en la tipificación y esperamos
        // que aparezca una entrada NUEVA. Resource Timing publica esa entrada al finalizar
        // el request; no dependemos de responseEnd, que puede ocultarse por TAO/CORS.
        const before = Number(marker?.usersResourceCountBefore || 0);
        const clickedAt = Number(marker?.usersRequestClickedAt || 0);
        const until = Date.now() + timeout;
        while (Date.now() < until) {
            try {
                const matches = (performance.getEntriesByType?.('resource') || [])
                    .filter(e => String(e?.name || '').includes('/users/typification/'));
                if (matches.length > before) return true;
                const hit = matches.slice().reverse().find(e =>
                    clickedAt && Number(e?.startTime || 0) >= clickedAt - 25
                );
                if (hit) return true;
            } catch (_) {}
            await sleepRapid(25);
        }
        return false;
    }

    async function esperarCargaUsuariosRapid(ticket, startedAt = 0, timeout = 12000) {
        // VIENA monta el autocomplete antes de terminar GET /users/task/<ticket>.
        // Si escribimos antes, Vue puede reemplazar el input al llegar la respuesta y
        // borrar el filtro, obligando a escribir dos veces. Esperamos la finalización
        // real del recurso cuando Resource Timing la expone; si no está disponible,
        // dejamos actuar el fallback seguro existente que reacopla el input.
        const marker = `/users/task/${String(ticket || '').trim()}`;
        if (!marker || marker.endsWith('/')) return false;
        const began = Number(startedAt || 0);
        const until = Date.now() + timeout;
        while (Date.now() < until) {
            try {
                const entries = performance.getEntriesByType?.('resource') || [];
                const hit = entries.slice().reverse().find(e =>
                    String(e?.name || '').includes(marker) &&
                    (!began || Number(e?.startTime || 0) >= began - 250)
                );
                if (hit) return true;
            } catch (_) {}
            await sleepRapid(25);
        }
        return false;
    }

    async function escribirUsuarioRapid(input, texto) {
        input.focus();
        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
        setter ? setter.call(input, '') : (input.value = '');
        input.dispatchEvent(new Event('input', { bubbles: true }));
        let escrito = '';
        for (const ch of String(texto || '')) {
            input.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true, cancelable: true }));
            input.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: ch, bubbles: true, cancelable: true }));
            escrito += ch;
            setter ? setter.call(input, escrito) : (input.value = escrito);
            input.dispatchEvent(new InputEvent('input', { inputType: 'insertText', data: ch, bubbles: true }));
            input.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true, cancelable: true }));
            // Sólo separación mínima entre teclas para reproducir escritura real; no espera backend.
            await sleepRapid(12);
        }
    }

    function opcionUsuarioDeInputRapid(userInput, filter) {
        const control = userInput?.closest('.v-input.v-autocomplete, .v-input.v-select') || userInput?.closest('.v-input');
        if (!control) return null;
        const owns = control.querySelector('[aria-owns]')?.getAttribute('aria-owns') || userInput.getAttribute('aria-owns') || '';
        const derived = userInput.id ? `list-${userInput.id.replace(/^input-/, '')}` : '';
        const list = (owns && document.getElementById(owns)) || (derived && document.getElementById(derived));
        if (!list || !visibleRapid(list)) return null;
        const wanted = normRapid(filter);
        return Array.from(list.querySelectorAll('.v-list-item[role="option"], [role="option"].v-list-item'))
            .find(item => visibleRapid(item) && normRapid(item.textContent).includes(wanted)) || null;
    }

    function primeraFilaNoAsignadaRapid() {
        // Asignar e Iniciar NO depende de checkboxes: toma siempre el primer match
        // visible de la tabla cuyo campo "Asignado a" sea exactamente "No asignada".
        // Corporate UI ya marca ese valor con .viena-user-libre; mantenemos un
        // fallback semántico al texto por si la tabla todavía no terminó de decorar.
        const rows = Array.from(document.querySelectorAll('.v-data-table tbody tr, tbody tr')).filter(visibleRapid);
        return rows.find(row => {
            const libre = row.querySelector('.viena-user-badge.viena-user-libre');
            if (libre && normRapid(libre.textContent) === 'NO ASIGNADA') return true;

            const cells = Array.from(row.querySelectorAll('td'));
            return cells.some(td => normRapid(td.textContent) === 'NO ASIGNADA');
        }) || null;
    }

    async function asignarEIniciar() {
        // Siempre trabajar sobre el PRIMER ticket No asignada según el orden
        // actualmente visible de Tareas Internas. No requiere selección manual.
        const row = primeraFilaNoAsignadaRapid();
        if (!row) {
            notifyRapid('No encontré ningún ticket en estado No asignada.');
            return;
        }
        const rowText = String(row.textContent || '').replace(/\s+/g, ' ').trim();
        const ticketEsperado = (rowText.match(/\b26\d{8,}\b/) || [])[0] || '';
        let filter = await getAssignFilter();
        if (!filter) return;

        // Abrir el ticket seleccionado usando el mismo ojo nativo del listado.
        const eye = row.querySelector('button.mdi-eye, .v-icon.mdi-eye, button .mdi-eye');
        const eyeButton = eye?.closest?.('button') || eye;
        if (!eyeButton) { notifyRapid('No encontré el botón para abrir el ticket seleccionado.'); return; }
        clickRapid(eyeButton);

        const ticketAbierto = await waitRapidDom(() => {
            const actual = obtenerTicketAbiertoEFS();
            if (!actual) return false;
            return (!ticketEsperado || actual === ticketEsperado) ? actual : false;
        }, 10000);
        if (!ticketAbierto) { notifyRapid('El ticket seleccionado no terminó de abrirse.'); return; }

        // FASE ASIGNAR: flujo individual del tracer (/users/task/<ticket>), sin Tipificaciones.
        const asignar = await waitRapidDom(() => findTextRapid('button .v-btn__content', 'Asignar usuario'), 7000);
        if (!asignar) { notifyRapid('No apareció Asignar usuario.'); return; }
        const asignarStartedAt = performance.now();
        clickRapid(asignar.closest('button'));

        // No hay delay fijo de 3 s: VIENA monta/habilita el autocomplete cuando termina
        // de cargar /users/task/<ticket>. Continuamos en el primer cambio de DOM que lo deje listo.
        const userInput = await waitRapidDom(() => {
            const scope = rapidDialogScope();
            if (scope === document) return null;
            const labels = Array.from(scope.querySelectorAll('label')).filter(visibleRapid);
            const lab = labels.find(l => normRapid(l.textContent).includes('USUARIO'));
            const control = lab?.closest('.v-input');
            const input = control?.querySelector('input[type="text"]:not([readonly]):not([disabled])') ||
                Array.from(scope.querySelectorAll('.v-autocomplete input[type="text"]:not([readonly]):not([disabled])')).find(visibleRapid);
            if (!input || !visibleRapid(input)) return null;
            if (control?.classList.contains('v-input--is-loading')) return null;
            if (control?.querySelector('.v-progress-linear--active, .v-progress-circular')) return null;
            return input;
        }, 12000);
        if (!userInput) { notifyRapid('VIENA no terminó de habilitar el buscador de Usuario.'); return; }

        // El tracer real mostró que el input aparece antes de finalizar /users/task.
        // Esperamos esa respuesta antes de la PRIMERA escritura para evitar que Vue
        // limpie/reemplace el autocomplete y obligue a reescribir el apellido.
        await esperarCargaUsuariosRapid(ticketAbierto, asignarStartedAt, 3000);
        const userInputReady = await waitRapidDom(() => {
            const scope = rapidDialogScope();
            if (scope === document) return null;
            return Array.from(scope.querySelectorAll('.v-autocomplete input[type="text"]:not([readonly]):not([disabled]), input[type="text"]:not([readonly]):not([disabled])')).find(inp => {
                if (!visibleRapid(inp)) return false;
                const control = inp.closest('.v-input');
                const label = control?.querySelector('label');
                return label && normRapid(label.textContent).includes('USUARIO');
            }) || null;
        }, 3000) || userInput;

        await escribirUsuarioRapid(userInputReady, filter);

        // /users/task puede terminar DESPUÉS de que VIENA ya haya montado el input.
        // Además Vue puede reemplazar el autocomplete al llegar la respuesta. No nos
        // quedamos atados a la referencia vieja: si aparece un input nuevo, volvemos
        // a aplicar el filtro guardado inmediatamente y esperamos su opción real.
        let activeUserInput = userInputReady;
        let writingUserInput = false;
        let userItem = await new Promise(resolve => {
            let done = false, observer = null, fallback = null, timer = null;
            const finish = value => {
                if (done) return;
                done = true;
                try { observer?.disconnect(); } catch (_) {}
                if (fallback) clearInterval(fallback);
                if (timer) clearTimeout(timer);
                resolve(value || null);
            };
            const check = async () => {
                if (done || writingUserInput) return;
                const scope = rapidDialogScope();
                if (scope === document) return;
                const inputs = Array.from(scope.querySelectorAll('.v-autocomplete input[type="text"]:not([readonly]):not([disabled]), input[type="text"]:not([readonly]):not([disabled])')).filter(visibleRapid);
                const current = inputs.find(inp => {
                    const c = inp.closest('.v-input');
                    const label = c?.querySelector('label');
                    return label && normRapid(label.textContent).includes('USUARIO');
                }) || null;
                if (!current) return;
                activeUserInput = current;
                const item = opcionUsuarioDeInputRapid(current, filter);
                if (item) { finish(item); return; }
                if (normRapid(current.value) !== normRapid(filter)) {
                    writingUserInput = true;
                    try { await escribirUsuarioRapid(current, filter); } finally { writingUserInput = false; }
                    const after = opcionUsuarioDeInputRapid(current, filter);
                    if (after) finish(after);
                }
            };
            observer = new MutationObserver(() => { void check(); });
            observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
            fallback = setInterval(() => { void check(); }, 25);
            timer = setTimeout(() => finish(null), 15000);
            void check();
        });
        if (!userItem) {
            notifyRapid(`No apareció ningún usuario que coincida con "${filter}". Revisá “Apellido para asignación” en el panel de VIENA NOC Tools y volvé a intentar.`, 'error');
            return;
        }
        clickRapid(userItem);

        const usuarioSeleccionado = await waitRapidDom(() => {
            const control = activeUserInput?.closest('.v-input');
            if (!control) return false;
            const hidden = control.querySelector('input[type="hidden"]');
            const txt = normRapid(control.textContent);
            return String(hidden?.value || '') === '[object Object]' && txt.includes(normRapid(filter));
        }, 3000);
        if (!usuarioSeleccionado) { notifyRapid('VIENA no confirmó el usuario seleccionado.'); return; }

        const confirmarAsignacion = await waitRapidDom(() => {
            const scope = rapidDialogScope();
            if (scope === document) return null;
            return Array.from(scope.querySelectorAll('button')).find(b => visibleRapid(b) && normRapid(b.textContent) === 'CONFIRMAR') || null;
        }, 5000);
        if (!confirmarAsignacion) { notifyRapid('No apareció Confirmar en Asignar usuario.'); return; }
        clickRapid(confirmarAsignacion);

        // El tracer mostró que el PUT /assign/user puede terminar y VIENA recién después
        // reconstruye el ticket. La señal más segura de que esa reconstrucción terminó
        // es nuestro botón Iniciar Tarea visible (sólo existe con Estado=ASIGNADA).
        // Lo esperamos de forma reactiva y reutilizamos SU flujo ya estable, en vez de
        // mantener una segunda implementación de Cambiar Estado dentro de este botón.
        const iniciarBtn = await waitRapidDom(() => {
            const btn = document.querySelector('.viena-ticket-start-btn');
            return btn && visibleRapid(btn) && !btn.disabled ? btn : null;
        }, 30000);
        if (!iniciarBtn) { notifyRapid('VIENA asignó el ticket, pero no terminó de habilitar Iniciar Tarea.'); return; }
        clickRapid(iniciarBtn);
    }

    async function iniciarTareaTicketAbierto() {
        if (obtenerEstadoTicket() !== 'ASIGNADA') {
            notifyRapid('Iniciar Tarea sólo está disponible cuando el ticket está ASIGNADA.');
            return;
        }
        const cambiar = await waitRapid(() => findTextRapid('button .v-btn__content', 'Cambiar Estado'));
        if (!cambiar) { notifyRapid('No apareció Cambiar Estado.'); return; }
        clickRapid(cambiar.closest('button'));
        if (!await chooseVisibleListItem('INICIADA')) { notifyRapid('No apareció el estado INICIADA.'); return; }

        // En algunos puestos Vue tarda más en montar/habilitar el segundo select.
        // No usamos un sleep fijo ni el "último .v-select__selections": esperamos
        // el control semántico exacto que muestra VIENA y lo abrimos en cuanto existe.
        let motivoAbierto = await abrirSelectPorLabelExacto('MOTIVO DE CAMBIO DE ESTADO', 10000);
        if (!motivoAbierto) {
            // Compatibilidad con variantes de VIENA que rotulan el mismo control como Razón.
            motivoAbierto = await abrirSelectPorLabelExacto('RAZÓN DE CAMBIO DE ESTADO', 3000);
        }
        if (!motivoAbierto) {
            // Último fallback acotado al diálogo activo; nunca selecciona controles fuera de él.
            motivoAbierto = await openRapidSelectFor({
                labels: ['Motivo de cambio de estado', 'Razón de cambio de estado'],
                excludeValues: ['INICIADA'],
                preferEmpty: true,
                fallbackIndex: 1
            });
        }
        if (!motivoAbierto) { notifyRapid('No apareció el selector de motivo.'); return; }
        if (!await seleccionarMotivoInicioTicket()) {
            notifyRapid('No apareció un motivo válido para iniciar la tarea (Diagnóstico en curso / Tarea Iniciada).');
            return;
        }
        const textarea = await waitRapid(() => {
            const dialogs = Array.from(document.querySelectorAll('.v-dialog')).filter(visibleRapid);
            const scope = dialogs.length ? dialogs[dialogs.length - 1] : document;
            return Array.from(scope.querySelectorAll('textarea')).find(visibleRapid) || null;
        });
        if (!textarea) { notifyRapid('No apareció el campo Mensaje.'); return; }
        textarea.focus();
        const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
        setter ? setter.call(textarea, 'Se inicia diagnostico de ticket.') : (textarea.value = 'Se inicia diagnostico de ticket.');
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        textarea.dispatchEvent(new Event('change', { bubbles: true }));
        const confirmar = await waitRapid(() => findTextRapid('button .v-btn__content', 'Confirmar'));
        if (!confirmar) { notifyRapid('No apareció Confirmar.'); return; }
        clickRapid(confirmar.closest('button'));
    }

    function asegurarIniciarTareaTicket() {
        const ticket = obtenerTicketAbiertoEFS();
        const asignada = obtenerEstadoTicket() === 'ASIGNADA';
        let btn = document.querySelector('.viena-ticket-start-btn');
        if (!ticket || !asignada) { if (btn) btn.remove(); return; }
        const preAsignar = buscarBotonSuperiorPorTexto('PRE-ASIGNAR');
        if (!preAsignar) return;
        if (!btn) {
            btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'viena-ticket-start-btn mx-3 v-btn v-btn--is-elevated v-btn--has-bg theme--dark v-size--default primary';
            btn.innerHTML = '<span class="v-btn__content"> Iniciar Tarea </span>';
            preAsignar.insertAdjacentElement('afterend', btn);
        } else if (btn.previousElementSibling !== preAsignar) {
            preAsignar.insertAdjacentElement('afterend', btn);
        }
        btn.onclick = async e => {
            e.preventDefault(); e.stopPropagation();
            if (btn.disabled) return;
            btn.disabled = true;
            try { await iniciarTareaTicketAbierto(); }
            finally { btn.disabled = false; setTimeout(() => detectarCampos(), 350); }
        };
    }

    function vistaTareasInternasActiva() {
        const activos = Array.from(document.querySelectorAll('.v-list-item--active .v-list-item__title, .v-item--active .v-list-item__title'));
        if (activos.some(el => normRapid(el.textContent) === 'TAREAS INTERNAS')) return true;
        if (activos.some(el => normRapid(el.textContent) === 'TAREAS DE CAMPO')) return false;
        return /\/tasks\/intern(?:\/|$|\?)/i.test(location.pathname + location.search);
    }

    function obtenerTablaTareasInternasRapid() {
        // No tomar la primera tabla de la página: con Filtros desplegado puede haber
        // otros bloques antes. Identificamos la tabla real por sus encabezados.
        return Array.from(document.querySelectorAll('.v-data-table table, table')).find(table => {
            const headers = Array.from(table.querySelectorAll('thead th')).map(th => normRapid(th.textContent));
            return headers.some(t => t.includes('TICKET EVENTO')) &&
                   headers.some(t => t === 'NODO' || t.includes('NODO')) &&
                   headers.some(t => t.includes('ASIGNADO A'));
        }) || null;
    }

    function tablaTareasInternasVisibleRapid(table) {
        if (!table) return false;
        const r = table.getBoundingClientRect();
        const vh = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
        if (!vh || r.bottom <= 0 || r.top >= vh) return false;

        // No alcanza con que asome una fila al pie de la pantalla: eso era lo que
        // hacía aparecer los botones sobre Tareas Internas cuando Filtros de tabla
        // seguía ocupando casi todo el viewport. Exigimos que el usuario haya
        // scrolleado hasta la tabla y que ésta ocupe una porción útil de la vista.
        // Es proporcional al viewport, por lo que mantiene el criterio con zoom.
        const visibleTop = Math.max(0, r.top);
        const visibleBottom = Math.min(vh, r.bottom);
        const visiblePx = Math.max(0, visibleBottom - visibleTop);
        const minVisiblePx = Math.min(r.height, vh * 0.45);
        return visiblePx >= minVisiblePx;
    }

    function posicionarAccionesRapidas(host, table) {
        if (!host) return;
        const drawer = document.querySelector('nav.v-navigation-drawer.v-navigation-drawer--open');
        const ancho = drawer ? Math.round(drawer.getBoundingClientRect().width) : 56;
        const visible = tablaTareasInternasVisibleRapid(table || obtenerTablaTareasInternasRapid());

        host.style.setProperty('position', 'fixed', 'important');
        host.style.setProperty('left', `${Math.max(70, ancho + 14)}px`, 'important');
        host.style.setProperty('bottom', '18px', 'important');
        host.style.setProperty('top', 'auto', 'important');
        host.style.setProperty('right', 'auto', 'important');
        host.style.setProperty('z-index', '999998', 'important');
        host.style.setProperty('transform', 'none', 'important');
        host.style.setProperty('display', visible ? 'flex' : 'none', 'important');
    }

    function asegurarAccionesRapidasListado() {
        const hostExistente = document.querySelector('.viena-rapid-actions');
        // Exclusivo de Tareas Internas. Si se abre ticket o se cambia a Tareas de Campo,
        // desaparece inmediatamente y vuelve solo al regresar al listado interno.
        if (obtenerTicketAbiertoEFS() || !vistaTareasInternasActiva()) {
            if (hostExistente) hostExistente.remove();
            return;
        }
        const table = obtenerTablaTareasInternasRapid();
        if (!table) { if (hostExistente) hostExistente.remove(); return; }
        if (hostExistente) { posicionarAccionesRapidas(hostExistente, table); return; }

        const host = document.createElement('div');
        host.className = 'viena-rapid-actions';
        host.style.cssText = 'position:fixed;left:70px;bottom:18px;z-index:999998;display:none;gap:8px;align-items:center;transition:left .2s ease;';
        posicionarAccionesRapidas(host, table);
        const defs = [
            ['Iniciar Multiple', iniciarMultiple],
            ['Asignar Multiple', asignarMultiple],
            ['Asignar e Iniciar', asignarEIniciar]
        ];
        defs.forEach(([label, fn]) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.textContent = label;
            b.style.cssText = 'background:#1976d2;color:#fff;border:0;border-radius:6px;padding:11px 16px;font:700 13px Arial,sans-serif;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.25);';
            b.onclick = async e => { e.preventDefault(); e.stopPropagation(); b.disabled = true; try { await fn(); } finally { b.disabled = false; setTimeout(() => { try { b.blur(); } catch (_) {} }, 0); } };
            host.appendChild(b);
        });
        document.body.appendChild(host);
        posicionarAccionesRapidas(host, table);
    }

    // Sin polling: reaccionar al hover real del drawer y a la navegación lateral.
    // Así los botones acompañan la animación 56px↔drawer expandido y desaparecen
    // al seleccionar Tareas de Campo.
    if (!window.__VIENA_RAPID_NAV_HOOKS__) {
        window.__VIENA_RAPID_NAV_HOOKS__ = true;
        document.addEventListener('mouseover', e => {
            if (!e.target?.closest?.('nav.v-navigation-drawer')) return;
            [0, 80, 180, 280].forEach(ms => setTimeout(() => asegurarAccionesRapidasListado(), ms));
        }, true);
        document.addEventListener('mouseout', e => {
            if (!e.target?.closest?.('nav.v-navigation-drawer')) return;
            [0, 80, 180, 280].forEach(ms => setTimeout(() => asegurarAccionesRapidasListado(), ms));
        }, true);
        document.addEventListener('click', e => {
            const item = e.target?.closest?.('nav.v-navigation-drawer .v-list-item');
            if (!item) return;
            const txt = normRapid(item.textContent);
            if (!txt.includes('TAREAS INTERNAS') && !txt.includes('TAREAS DE CAMPO')) return;
            [0, 60, 180, 350].forEach(ms => setTimeout(() => asegurarAccionesRapidasListado(), ms));
        }, true);
    }

    if (!window.__VIENA_RAPID_VIEWPORT_HOOKS__) {
        window.__VIENA_RAPID_VIEWPORT_HOOKS__ = true;
        let rapidViewportRaf = 0;
        const actualizarRapidViewport = () => {
            if (rapidViewportRaf) return;
            rapidViewportRaf = requestAnimationFrame(() => {
                rapidViewportRaf = 0;
                try { asegurarAccionesRapidasListado(); } catch (_) {}
            });
        };
        window.addEventListener('scroll', actualizarRapidViewport, { passive: true, capture: true });
        window.addEventListener('resize', actualizarRapidViewport, { passive: true });
    }

    // Guardia liviana para el ciclo ticket -> cerrar -> Tareas Internas.
    // Vue puede reemplazar la vista sin una navegación que nuestros hooks detecten.
    // Sólo verifica/recrea los dos botones; no ejecuta la detección pesada del ticket.
    if (!window.__VIENA_RAPID_LIST_HEARTBEAT__) {
        window.__VIENA_RAPID_LIST_HEARTBEAT__ = setInterval(() => {
            try { asegurarAccionesRapidasListado(); } catch (_) {}
        }, 350);
    }

    // ================================================================
    // INICIALIZAR — REAPERTURA SPA SIN CAMBIAR EL BOTÓN
    // ================================================================

    function iniciar() {

        let timer = null;
        let ultimaUrl = location.href;

        // Importante: los reintentos NO se cancelan entre mutaciones.
        // VIENA es una SPA muy activa y cancelar el lote anterior puede impedir
        // que detectarCampos llegue a ejecutarse cuando el ticket termina de montar.
        // El spam de consola ya está resuelto por la firma de accesos, por lo que
        // podemos conservar la estrategia estable de reintentos independientes.
        function programarDetecciones(delays) {
            delays.forEach(ms => setTimeout(ejecutarDeteccion, ms));
        }

        function ejecutarDeteccion() {
            detectarCampos();
        }

        // La detección original de v1.5.4, que sí mostraba correctamente
        // el botón, se conserva intacta.
        ejecutarDeteccion();

        let firmaVista = '';
        let refuerzoVista = null;

        function firmaVistaActual() {
            const ticket = obtenerTicketAbiertoEFS();
            if (ticket) return `ticket:${ticket}`;
            return document.querySelector('table') ? 'listado' : 'otra';
        }

        const observer =
            new MutationObserver(mutations => {
                const relevante = mutations.some(m => {
                    if (m.type !== 'childList' || (!m.addedNodes.length && !m.removedNodes.length)) return false;
                    const target = m.target?.nodeType === 1 ? m.target : m.target?.parentElement;
                    // Nuestros propios botones/menús no deben volver a disparar una detección global.
                    if (target?.closest?.('[class*="viena-"], #panel-plantillas-viena')) return false;
                    return true;
                });
                if (!relevante) return;

                const nuevaFirma = firmaVistaActual();
                const cambioVista = nuevaFirma !== firmaVista;
                firmaVista = nuevaFirma;

                clearTimeout(timer);
                timer = setTimeout(ejecutarDeteccion, cambioVista ? 20 : 90);

                // Un único refuerzo al cambiar lista↔ticket. Antes se generaban
                // 4 timers por CADA mutación, acumulando trabajo mientras Vue montaba.
                if (cambioVista) {
                    clearTimeout(refuerzoVista);
                    refuerzoVista = setTimeout(ejecutarDeteccion, 320);
                }
            });

        observer.observe(
            document.body,
            {
                childList: true,
                subtree: true
            }
        );

        // Detectar navegación SPA sin recorrer el DOM permanentemente.
        const pushStateOriginal = history.pushState;
        const replaceStateOriginal = history.replaceState;

        function despuesDeNavegar() {
            ultimaUrl = location.href;
            detectarCampos._ultimaFirmaAccesos = '';
            [0, 80, 220, 500].forEach(ms => setTimeout(ejecutarDeteccion, ms));
        }

        history.pushState = function (...args) {
            const r = pushStateOriginal.apply(this, args);
            despuesDeNavegar();
            return r;
        };

        history.replaceState = function (...args) {
            const r = replaceStateOriginal.apply(this, args);
            despuesDeNavegar();
            return r;
        };

        window.addEventListener('popstate', despuesDeNavegar);
        window.addEventListener('hashchange', despuesDeNavegar);

        // Refuerzo inicial finito de la base estable.
        [120, 420].forEach(ms => setTimeout(ejecutarDeteccion, ms));
    }


    
    // Evitar que Vuetify deje visualmente un botón superior en estado focus/active.
    document.addEventListener('click', event => {
        const btn = event.target?.closest?.('button');
        if (!btn) return;
        const txt = String(btn.textContent || '').replace(/\s+/g, ' ').trim().toUpperCase();
        if (!['CREAR TAREA','ASIGNAR USUARIO','CAMBIAR ESTADO','PRE-ASIGNAR','INICIAR TAREA','RESINCRONIZAR','COMPLETAR TAREA','INICIAR MULTIPLE','ASIGNAR MULTIPLE'].includes(txt) && !btn.querySelector('.material-icons')) return;
        setTimeout(() => { try { btn.blur(); } catch (_) {} }, 0);
    }, true);

    // ================================================================
    // ARRANQUE
    // ================================================================

    if (iniciarReceptorFuentes()) {
        return;
    }

    if (
        document.readyState ===
        'loading'
    ) {

        document.addEventListener(
            'DOMContentLoaded',
            iniciar
        );

    } else {

        iniciar();
    }

})();
