(function(){
'use strict';
if(globalThis.__VIENA_GRAFANA_VCCAP__) return;
globalThis.__VIENA_GRAFANA_VCCAP__=true;

const DASHBOARD_PATH='/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const norm=v=>String(v||'').replace(/\s+/g,' ').trim().toUpperCase();

function esDashboardVccap(){
  return location.hostname==='grafana-telemetria.telecentro.net.ar' && location.pathname.startsWith(DASHBOARD_PATH);
}

async function waitFor(fn,timeout=10000,step=50){
  const start=Date.now();
  while(Date.now()-start<timeout){
    const value=fn();
    if(value) return value;
    await sleep(step);
  }
  return null;
}

function click(el){
  if(!el) return false;
  el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));
  el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));
  el.click();
  return true;
}

function setInputValue(input,value){
  if(!input) return false;
  const proto=Object.getPrototypeOf(input);
  const desc=Object.getOwnPropertyDescriptor(proto,'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
  if(desc?.set) desc.set.call(input,value); else input.value=value;
  input.dispatchEvent(new Event('input',{bubbles:true}));
  input.dispatchEvent(new Event('change',{bubbles:true}));
  return true;
}

function visible(el){
  return !!el && el.getClientRects().length>0 && getComputedStyle(el).display!=='none' && getComputedStyle(el).visibility!=='hidden';
}

function rpdInteractivo(){
  const el=document.querySelector('#var-rpd');
  if(!el || !el.isConnected || !visible(el)) return null;
  // Durante el recálculo del Cluster, Grafana reemplaza temporalmente el selector
  // por un DIV con spinner y el mismo id=var-rpd. No es clickeable como dropdown.
  if(el.tagName!=='BUTTON') return null;
  const control=String(el.getAttribute('aria-controls')||'').trim();
  if(control!=='options-var-rpd' && control!=='options-rpd') return null;
  if(el.querySelector('[aria-label="Loading indicator"], .spin-clockwise')) return null;
  return el;
}

async function esperarRpdInteractivo(timeout=15000){
  return waitFor(()=>rpdInteractivo(),timeout,60);
}

async function abrirVariable(buttonId,optionsId){
  const button=await waitFor(()=>document.querySelector(`#${buttonId}`),12000);
  if(!button) throw new Error(`No encontré ${buttonId}`);
  if(button.getAttribute('aria-expanded')!=='true') click(button);
  const input=await waitFor(()=>{
    const el=document.querySelector(`input[aria-controls="${optionsId}"], input[aria-controls="options-${optionsId.replace(/^options-/, '')}"]`);
    return visible(el)?el:null;
  },5000);
  if(!input) throw new Error(`No apareció el input de ${buttonId}`);
  return {button,input};
}

function valorVariable(buttonId){
  const b=document.querySelector(`#${buttonId}`);
  return norm(b?.getAttribute('title')||b?.textContent);
}

async function esperarRehidratacionRpd(valorAntes,timeout=9000){
  const anterior=norm(valorAntes);
  // El trace real muestra que seleccionar Cluster dispara la actualización de la
  // variable dependiente RPD y recién después cambia #var-rpd al valor por defecto
  // del nuevo COS. No debemos abrir RPD mientras siga mostrando el valor anterior.
  const actualizado=await waitFor(()=>{
    const btn=rpdInteractivo();
    if(!btn) return null;
    const actual=norm(btn.getAttribute('title')||btn.textContent);
    if(!actual) return null;
    return actual!==anterior ? btn : null;
  },timeout,60);
  return !!actualizado;
}

async function elegirCluster(cos){
  const btn=await waitFor(()=>document.querySelector('#var-cluster'),12000);
  if(!btn) throw new Error('No encontré el filtro Cluster');
  if(norm(btn.getAttribute('title')||btn.textContent)===norm(cos)) return {cambio:false};

  const rpdAntes=valorVariable('var-rpd');
  const {input}=await abrirVariable('var-cluster','options-cluster');
  setInputValue(input,cos);
  const opcion=await waitFor(()=>Array.from(document.querySelectorAll(
    '#options-cluster button, #options-var-cluster button, button[data-testid="data-testid variable-option"], button[role="checkbox"]'
  )).find(b=>visible(b)&&norm(b.textContent)===norm(cos)),7000,40);
  if(!opcion) throw new Error(`No apareció el COS ${cos} en Grafana`);
  click(opcion);
  const aplicado=await waitFor(()=>{
    const b=document.querySelector('#var-cluster');
    return b && norm(b.getAttribute('title')||b.textContent)===norm(cos);
  },6000,50);
  if(!aplicado) throw new Error(`Grafana no confirmó el COS ${cos}`);

  // Esperar a que Grafana termine de recalcular la variable RPD dependiente.
  // Si el valor anterior estaba vacío, alcanza con que #var-rpd tenga un valor.
  if(rpdAntes){
    await esperarRehidratacionRpd(rpdAntes,9000);
  }else{
    await waitFor(()=>{ const b=rpdInteractivo(); return b && valorVariable('var-rpd') ? b : null; },15000,60);
  }
  const rpdListo=await esperarRpdInteractivo(15000);
  if(!rpdListo) throw new Error('Grafana no terminó de habilitar el selector Nodo/RPD después de cambiar el COS');
  return {cambio:true,rpdAntes};
}

function inputRpdActual(){
  const candidates=Array.from(document.querySelectorAll(
    'input.gf-form-input[aria-controls="options-rpd"], input.gf-form-input[aria-controls="options-var-rpd"], input[aria-controls="options-rpd"], input[aria-controls="options-var-rpd"]'
  ));
  return candidates.find(el=>el.isConnected && visible(el)) || candidates.find(el=>el.isConnected) || null;
}

function botonesMenuNodo(input){
  const actual=input?.isConnected ? input : inputRpdActual();
  const control=String(actual?.getAttribute('aria-controls')||'').trim();
  const menus=[];
  if(control){
    const exact=document.getElementById(control);
    if(exact) menus.push(exact);
  }
  for(const id of ['options-rpd','options-var-rpd']){
    const el=document.getElementById(id);
    if(el && !menus.includes(el)) menus.push(el);
  }
  const local=menus.flatMap(menu=>Array.from(menu.querySelectorAll(
    'button[data-testid="data-testid variable-option"], button[role="checkbox"], button'
  )));
  if(local.length) return local;
  return Array.from(document.querySelectorAll(
    'button[data-testid="data-testid variable-option"], button[role="checkbox"]'
  ));
}

function cerrarVariableRpd(input){
  const actual=inputRpdActual() || input;
  try{
    actual?.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true}));
    actual?.dispatchEvent(new KeyboardEvent('keyup',{key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true}));
  }catch(_){}
  try{ actual?.blur(); }catch(_){}
  const btn=document.querySelector('#var-rpd');
  if(btn?.getAttribute('aria-expanded')==='true') click(btn);
}

function opcionNodoExacta(node,input){
  const n=norm(node);
  const candidatas=botonesMenuNodo(input).filter(b=>{
    const t=norm(b.textContent);
    return b.isConnected && !b.disabled && (t===n || t.startsWith(n+' - '));
  });
  return candidatas.find(visible) || candidatas[0] || null;
}

async function esperarInputRpd(timeout=6000){
  return waitFor(()=>inputRpdActual(),timeout,40);
}

async function abrirRpdConInput(timeout=15000){
  const start=Date.now();
  let intento=0;
  while(Date.now()-start<timeout && intento<4){
    intento++;

    // IMPORTANTE: #var-rpd no siempre es un botón. Mientras Grafana recalcula la
    // variable dependiente del Cluster usa temporalmente un DIV con spinner y el
    // mismo id. Esperar el BUTTON real evita hacer click sobre el estado loading.
    const btn=await esperarRpdInteractivo(Math.min(6000,Math.max(1000,timeout-(Date.now()-start))));
    if(!btn) continue;

    let input=inputRpdActual();
    if(input) return {btn,input};

    if(btn.getAttribute('aria-expanded')==='true'){
      // Estado expanded sin portal/input: normalizar y reabrir sobre el BUTTON real.
      click(btn);
      await waitFor(()=>{
        const actual=rpdInteractivo();
        return actual && actual.getAttribute('aria-expanded')!=='true' ? actual : null;
      },1800,40);
    }

    const btnActual=await esperarRpdInteractivo(2500);
    if(!btnActual) continue;
    if(btnActual && btnActual.getAttribute('aria-expanded')!=='true') click(btnActual);

    input=await esperarInputRpd(3000);
    if(input) return {btn:rpdInteractivo()||btnActual,input};

    await sleep(150);
  }
  return null;
}

async function esperarListaRpdParaCluster(node,timeout=9000){
  const start=Date.now();
  const esperado=norm(node);
  let lastInput=null;
  while(Date.now()-start<timeout){
    const input=inputRpdActual();
    if(input){
      if(input!==lastInput){
        lastInput=input;
        // React puede reemplazar el input al terminar de hidratar la variable.
        // Cada input nuevo debe recibir nuevamente el filtro.
        setInputValue(input,String(node||'').toLowerCase());
      }
      const opcion=opcionNodoExacta(node,input);
      if(opcion) return {input,opcion};

      // Si el menú ya tiene opciones pero todavía no la del nodo, re-aplicar el
      // valor sobre EL INPUT ACTUAL. Esto evita escribir sobre un nodo DOM viejo.
      const opciones=botonesMenuNodo(input).filter(b=>b.isConnected && !b.disabled);
      if(opciones.length){
        const valor=String(input.value||'').trim().toUpperCase();
        if(valor!==esperado){
          setInputValue(input,String(node||'').toLowerCase());
        } else {
          // Volver a disparar el input sin vaciarlo: Grafana conserva el binding
          // React y filtra la lista recién hidratada.
          input.dispatchEvent(new Event('input',{bubbles:true}));
        }
      }
    }
    await sleep(80);
  }
  return null;
}

async function abrirRpdYSeleccionar(node,timeout=10000){
  const abierto=await abrirRpdConInput(9000);
  if(!abierto) throw new Error('No apareció el input de Nodo/RPD después de reabrir el selector');

  let input=abierto.input;
  setInputValue(input,String(node||'').toLowerCase());

  const encontrado=await esperarListaRpdParaCluster(node,timeout);
  if(!encontrado) return false;

  // Usar la referencia recién obtenida: nunca hacer click sobre una opción de
  // un portal viejo que React haya desmontado durante el cambio de Cluster.
  click(encontrado.opcion);
  const aplicado=await waitFor(()=>{
    const b=document.querySelector('#var-rpd');
    const t=norm(b?.getAttribute('title')||b?.textContent);
    return t===norm(node) || t.startsWith(norm(node)+' - ');
  },8000,60);
  return !!aplicado;
}

async function elegirNodo(node){
  const btn=await esperarRpdInteractivo(15000);
  if(!btn) throw new Error('No apareció el selector Nodo/RPD interactivo');
  const actual=norm(btn.getAttribute('title')||btn.textContent);
  if(actual===norm(node) || actual.startsWith(norm(node)+' - ')) return true;

  // El cambio de Cluster hace que Grafana re-renderice el input RPD. El bug real
  // era conservar la referencia del primer input; cuando React lo reemplazaba,
  // los reintentos seguían escribiendo en un elemento desconectado. Cada ciclo
  // vuelve a adquirir input + menú y reproduce automáticamente el segundo click
  // que el operador comprobó que funciona.
  for(let ciclo=1;ciclo<=3;ciclo++){
    if(await abrirRpdYSeleccionar(node,ciclo===1?12000:9000)) return true;
    cerrarVariableRpd(inputRpdActual());
    await waitFor(()=>{
      const b=document.querySelector('#var-rpd');
      return b && b.getAttribute('aria-expanded')!=='true' ? b : null;
    },2500,50);
    await sleep(120);
  }

  throw new Error(`No apareció o no se confirmó el nodo ${node} en Grafana después de reabrir RPD`);
}

async function buscarVccap(nodo,cos){
  nodo=norm(nodo).replace(/\s+/g,'');
  cos=String(cos||'').trim();
  if(!nodo||!cos) return {ok:false,mensaje:'Nodo o COS inválido.'};
  if(!esDashboardVccap()) return {ok:false,mensaje:'La pestaña abierta de Grafana no está en el dashboard VCCAP requerido.'};
  try{
    await elegirCluster(cos);
    await elegirNodo(nodo);
    return {ok:true,nodo,cos};
  }catch(error){
    console.error('[VIENA GRAFANA] Error:',error);
    return {ok:false,mensaje:String(error?.message||error)};
  }
}

chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg?.type!=='VIENA_GRAFANA_VCCAP_RUN') return;
  const originalTitle=String(document.title||'');
  clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);
  clearTimeout(globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__);
  let blinkOn=false;
  const blink=()=>{blinkOn=!blinkOn;document.title=blinkOn?`● VN · Grafana · ${originalTitle}`:originalTitle;};
  blink();
  globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__=setInterval(blink,450);
  globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__=setTimeout(()=>{clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);document.title=originalTitle;},6000);

  buscarVccap(msg.nodo,msg.cos).then(sendResponse).catch(error=>sendResponse({ok:false,mensaje:String(error?.message||error)}));
  return true;
});

console.log('[VIENA GRAFANA] Receptor VCCAP listo', {dashboard:esDashboardVccap()});
})();
