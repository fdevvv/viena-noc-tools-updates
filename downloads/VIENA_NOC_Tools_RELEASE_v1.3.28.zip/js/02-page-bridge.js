(() => {
  'use strict';
  let seq = 0;
  globalThis.VienaPageBridge = {
    call(action, payload = {}, timeout = 10000) {
      return new Promise(resolve => {
        const id = `${Date.now()}-${++seq}-${Math.random().toString(36).slice(2)}`;
        let timer;
        const onResponse = event => {
          const d = event.detail || {};
          if (d.id !== id) return;
          document.removeEventListener('VIENA_NOC_EXT_PAGE_RESPONSE', onResponse);
          clearTimeout(timer);
          resolve(d);
        };
        document.addEventListener('VIENA_NOC_EXT_PAGE_RESPONSE', onResponse);
        timer = setTimeout(() => {
          document.removeEventListener('VIENA_NOC_EXT_PAGE_RESPONSE', onResponse);
          resolve({ id, ok: false, error: 'Timeout page helper' });
        }, timeout);
        document.dispatchEvent(new CustomEvent('VIENA_NOC_EXT_PAGE_REQUEST', {
          detail: { id, action, payload }
        }));
      });
    }
  };
})();
