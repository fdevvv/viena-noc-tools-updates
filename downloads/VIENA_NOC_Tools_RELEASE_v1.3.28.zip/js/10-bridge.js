(function () {
    'use strict';

    const KEY_COMANDO = 'VIENA_NOC_BRIDGE_COMMAND';
    const KEY_ULTIMO_PROCESADO = 'VIENA_NOC_BRIDGE_LAST_PROCESSED';
    const KEY_RESPUESTA = 'VIENA_NOC_BRIDGE_RESPONSE';
    const KEY_HEARTBEAT_STATS = 'VIENA_NOC_BRIDGE_HEARTBEAT_STATS';
    const KEY_HEARTBEAT_EDIFICIO = 'VIENA_NOC_BRIDGE_HEARTBEAT_EDIFICIO';
    const KEY_HEARTBEAT_GPON = 'VIENA_NOC_BRIDGE_HEARTBEAT_GPON';
    // v1.0.19 — validación ACTIVA bajo demanda.
    // Evita falsos "no disponible" cuando Chrome ralentiza timers de pestañas
    // en segundo plano y el heartbeat queda viejo aunque la pestaña siga viva.
    const KEY_PING = 'VIENA_NOC_BRIDGE_PING';
    const KEY_PONG = 'VIENA_NOC_BRIDGE_PONG';
    const URL_HFC_NODO = 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php';
    const URL_HFC_EDIFICIO = 'https://mira5-gdt.telecentro.net.ar/cablemodem_frontend.php';
    const DEBUG = true;

    const ES_VIENA = location.hostname === 'viena.telecentro.net.ar';
    const ES_MIRA5 = location.hostname === 'mira5-gdt.telecentro.net.ar';
    const ES_GPON = location.hostname === 'monitoreogpon.telecentro.net.ar';

    function log(...args) {
        if (DEBUG) console.log('[VIENA NOC Bridge]', ...args);
    }

    function limpiar(valor) {
        return String(valor || '').replace(/\s+/g, '');
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function esperarElemento(selector, timeout = 15000) {
        const inicio = Date.now();
        while (Date.now() - inicio < timeout) {
            const elemento = document.querySelector(selector);
            if (elemento) return elemento;
            await sleep(150);
        }
        return null;
    }

    function establecerValor(input, valor) {
        valor = limpiar(valor);
        if (!input || !valor) return false;

        input.focus();

        const descriptor = Object.getOwnPropertyDescriptor(
            HTMLInputElement.prototype,
            'value'
        );

        if (descriptor?.set) {
            descriptor.set.call(input, valor);
        } else {
            input.value = valor;
        }

        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
    }

    function textoMiraNormalizado(valor) {
        return String(valor || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
            .toUpperCase();
    }

    async function navegarMira5ADestino(target) {
        if (!ES_MIRA5) return { ok: false, code: 'not_mira5' };

        if (target === 'mira-stats') {
            if (location.pathname.includes('stats_frontend.php')) {
                return { ok: true, already: true };
            }

            const inicio = Date.now();
            while (Date.now() - inicio < 15000) {
                const boton = Array.from(document.querySelectorAll('button')).find(btn => {
                    if (!btn.isConnected || btn.disabled) return false;
                    const texto = textoMiraNormalizado(btn.textContent);
                    return texto.includes('ESTADISTICAS');
                });

                if (boton) {
                    log('🧭 MIRA5 landing detectado: entrando a Estadísticas');
                    boton.click();
                    return { ok: true, navigating: true };
                }

                await sleep(150);
            }

            return { ok: false, code: 'stats_button_not_found' };
        }

        return { ok: false, code: 'unsupported_target' };
    }

    if (ES_MIRA5 && chrome?.runtime?.onMessage) {
        chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
            if (msg?.type !== 'VIENA_MIRA5_NAVIGATE') return;
            navegarMira5ADestino(String(msg.target || ''))
                .then(sendResponse)
                .catch(error => sendResponse({ ok: false, code: 'error', detail: String(error?.message || error) }));
            return true;
        });
    }

    function crearComando(tipo, tecnologia, valor, extra = {}) {
        return {
            id: Date.now().toString() + '-' + Math.random().toString(36).slice(2, 8),
            tipo: String(tipo || '').toLowerCase(),
            tecnologia: String(tecnologia || '').toUpperCase(),
            valor: limpiar(valor),
            nodo: limpiar(extra.nodo || ''),
            timestamp: Date.now()
        };
    }

    // ================================================================
    // VIENA — EMISOR
    // ================================================================

    if (ES_VIENA) {
        unsafeWindow.VienaNocBridge = {
            limpiar,

            // Consulta el heartbeat DESDE EL MISMO userscript Bridge.
            // Esto es importante porque el storage GM_* no se comparte
            // entre userscripts distintos.
            async disponible(tipo, tecnologia) {
                tipo = String(tipo || '').toLowerCase();
                tecnologia = String(tecnologia || '').toUpperCase();

                let destino = null;
                let target = null;

                if (tecnologia === 'FTTH') {
                    destino = 'GPON';
                    target = 'gpon';
                } else if (
                    tecnologia === 'HFC' &&
                    (tipo === 'edificio' || tipo === 'cliente' || tipo === 'nodocm' || tipo === 'nodolist')
                ) {
                    destino = 'MIRA5_CABLEMODEM';
                    target = 'mira-cm';
                } else if (tecnologia === 'HFC' && tipo === 'nodo') {
                    destino = 'MIRA5_STATS';
                    target = 'mira-stats';
                }

                if (!destino || !target) return false;

                try {
                    const direct = await chrome.runtime.sendMessage({ type: 'VIENA_BRIDGE_AVAILABLE', target });
                    return Boolean(direct?.ok);
                } catch (_) {
                    return false;
                }

                const pingActivo = async (timeoutMs = 2200) => {
                    const ping = {
                        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
                        destino,
                        ts: Date.now()
                    };

                    return await new Promise(async resolve => {
                        let terminado = false;
                        let listenerId = null;
                        let timeoutId = null;

                        const finalizar = ok => {
                            if (terminado) return;
                            terminado = true;
                            if (timeoutId !== null) clearTimeout(timeoutId);
                            if (listenerId !== null && typeof GM_removeValueChangeListener === 'function') {
                                try { GM_removeValueChangeListener(listenerId); } catch (_) {}
                            }
                            resolve(Boolean(ok));
                        };

                        try {
                            listenerId = GM_addValueChangeListener(
                                KEY_PONG,
                                (_nombre, _anterior, pong) => {
                                    if (!pong || pong.id !== ping.id) return;
                                    if (pong.destino !== destino) return;
                                    log('💓 PONG recibido:', pong);
                                    finalizar(true);
                                }
                            );

                            await GM_setValue(KEY_PING, ping);
                            log('💓 PING enviado:', ping);
                            timeoutId = setTimeout(() => finalizar(false), timeoutMs);
                        } catch (_) {
                            finalizar(false);
                        }
                    });
                };

                // 1) Si la página correcta ya está abierta y operativa, seguimos sin tocar pestañas.
                if (await pingActivo(2200)) return true;

                // 2) Si no respondió, distinguimos entre "cerrada" y "abierta pero con error".
                //    Sólo abrimos automáticamente cuando NO existe la página exacta del botón.
                let ensured = null;
                try {
                    ensured = await chrome.runtime.sendMessage({
                        type: 'VIENA_ENSURE_DESTINATION',
                        target
                    });
                } catch (_) {
                    return false;
                }

                if (!ensured?.ok) return false;

                // Si la página exacta ya estaba abierta pero no respondió, no abrimos duplicados.
                // Excepción: MIRA5 puede estar en index.php y haber sido navegado por el
                // botón nativo Estadísticas; en ese caso esperamos que termine la navegación.
                if (!ensured.opened && !ensured.navigated) return false;

                // Se abrió o se navegó ahora: damos tiempo a que cargue el receptor exacto y
                // reintentamos hasta que quede listo, sin usar sleeps fijos largos.
                const inicio = Date.now();
                while (Date.now() - inicio < 18000) {
                    await sleep(300);
                    if (await pingActivo(900)) return true;
                }

                return false;
            },

            async buscar(tipo, tecnologia, valor) {
                tipo = String(tipo || '').toLowerCase();
                tecnologia = String(tecnologia || '').toUpperCase();
                valor = limpiar(valor);

                if (tipo !== 'nodo' && tipo !== 'edificio' && tipo !== 'cliente' && tipo !== 'nodocm' && tipo !== 'nodolist') {
                    console.error('[VIENA NOC Bridge] Tipo inválido:', tipo);
                    return false;
                }

                if (tecnologia !== 'HFC' && tecnologia !== 'FTTH') {
                    console.error('[VIENA NOC Bridge] Tecnología inválida:', tecnologia);
                    return false;
                }

                if (!valor) {
                    console.error('[VIENA NOC Bridge] Valor vacío');
                    return false;
                }

                const comando = crearComando(tipo, tecnologia, valor);

                log('📤 Enviando:', comando);

                try {
                    return await chrome.runtime.sendMessage({ type: 'VIENA_BRIDGE_SEARCH', command: comando });
                } catch (error) {
                    return { ok: false, estado: 'sin_respuesta', mensaje: String(error?.message || 'No se pudo contactar la página destino.') };
                }

                // Fallback histórico no alcanzable en MV3; se conserva debajo para trazabilidad.
                // Esperamos una respuesta REAL del receptor. Esto permite
                // distinguir "orden escrita" de "pestaña abierta y operativa".
                return await new Promise(async resolve => {
                    let terminado = false;
                    let listenerId = null;

                    const finalizar = resultado => {
                        if (terminado) return;
                        terminado = true;

                        if (listenerId !== null && typeof GM_removeValueChangeListener === 'function') {
                            try { GM_removeValueChangeListener(listenerId); } catch (_) {}
                        }

                        resolve(resultado);
                    };

                    listenerId = GM_addValueChangeListener(
                        KEY_RESPUESTA,
                        (_nombre, _anterior, respuesta) => {
                            if (!respuesta || respuesta.id !== comando.id) return;

                            log('📥 Respuesta recibida:', respuesta);

                            if (respuesta.estado === 'ok') {
                                finalizar({
                                    ok: true,
                                    estado: 'ok',
                                    mensaje: respuesta.mensaje || 'Operación realizada correctamente.'
                                });
                                return;
                            }

                            if (respuesta.estado === 'error') {
                                finalizar({
                                    ok: false,
                                    estado: 'error',
                                    mensaje: respuesta.mensaje || 'La página destino recibió la orden pero no pudo completarla.'
                                });
                            }
                        }
                    );

                    await GM_setValue(KEY_COMANDO, comando);
                    log('📡 Orden enviada:', tecnologia, tipo, valor);

                    // Si nadie responde, la pestaña correcta no está abierta,
                    // Tampermonkey no está activo allí o la sesión/página quedó inutilizable.
                    setTimeout(() => {
                        finalizar({
                            ok: false,
                            estado: 'sin_respuesta',
                            mensaje: tecnologia === 'FTTH'
                                ? 'GPON no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                                : ((tipo === 'edificio' || tipo === 'nodocm' || tipo === 'nodolist')
                                    ? 'MIRA 5 Cable Modem no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                                    : 'MIRA 5 Estadísticas no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.')
                        });
                    }, 12000);
                });
            },

            async buscarCliente(tecnologia, cliente, nodo = '') {
                tecnologia = String(tecnologia || '').toUpperCase();
                cliente = limpiar(cliente);
                nodo = limpiar(nodo).toUpperCase();

                if (!cliente) {
                    return { ok: false, estado: 'error', mensaje: 'No se encontró Número de Cliente en el ticket.' };
                }

                const comando = crearComando('cliente', tecnologia, cliente, { nodo });

                try {
                    return await chrome.runtime.sendMessage({ type: 'VIENA_BRIDGE_SEARCH', command: comando });
                } catch (error) {
                    return { ok: false, estado: 'sin_respuesta', mensaje: String(error?.message || 'No se pudo contactar la página destino.') };
                }

                return await new Promise(async resolve => {
                    let terminado = false;
                    let listenerId = null;

                    const finalizar = resultado => {
                        if (terminado) return;
                        terminado = true;
                        if (listenerId !== null && typeof GM_removeValueChangeListener === 'function') {
                            try { GM_removeValueChangeListener(listenerId); } catch (_) {}
                        }
                        resolve(resultado);
                    };

                    listenerId = GM_addValueChangeListener(
                        KEY_RESPUESTA,
                        (_nombre, _anterior, respuesta) => {
                            if (!respuesta || respuesta.id !== comando.id) return;
                            finalizar({
                                ok: respuesta.estado === 'ok',
                                estado: respuesta.estado,
                                mensaje: respuesta.mensaje || ''
                            });
                        }
                    );

                    await GM_setValue(KEY_COMANDO, comando);

                    setTimeout(() => finalizar({
                        ok: false,
                        estado: 'sin_respuesta',
                        mensaje: tecnologia === 'FTTH'
                            ? 'GPON no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                            : 'MIRA 5 Cable Modem no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                    }), 12000);
                });
            }
        };

        log('🚀 Emisor VIENA activo');
    }

    // ================================================================
    // MIRA5 — HFC
    // ================================================================

    async function esperarJQuery(timeout = 10000) {
        const inicio = Date.now();
        while (Date.now() - inicio < timeout) {
            const r = await globalThis.VienaPageBridge.call('jquery-ready', {}, 1200);
            if (r && r.ok) return true;
            await sleep(150);
        }
        return false;
    }

    async function esperarNodoHFC(nodo, timeout = 15000) {
        nodo = limpiar(nodo).toUpperCase();
        const inicio = Date.now();

        while (Date.now() - inicio < timeout) {
            const celdas = [
                ...document.querySelectorAll(
                    'td[aria-describedby="gridStatsNodosCmts_nodoCmts"]'
                )
            ];

            const celda = celdas.find(
                td => limpiar(td.textContent).toUpperCase() === nodo
            );

            if (celda) return celda;
            await sleep(200);
        }

        return null;
    }

    async function buscarNodoHFC(valor) {
        valor = limpiar(valor).toUpperCase();

        const nodos = valor
            .split('|')
            .map(n => limpiar(n).toUpperCase())
            .filter(Boolean);

        const valorBusqueda = valor;
        const primerNodo = nodos[0] || valor;

        log('🔎 HFC Nodo:', valorBusqueda, nodos);

        const input = await esperarElemento('#gs_nodoCmts');
        if (!input) {
            log('❌ No encontré #gs_nodoCmts');
            return false;
        }

        const jqueryDisponible = await esperarJQuery();
        if (!jqueryDisponible) {
            log('❌ jQuery no disponible en la página');
            return false;
        }

        /*
         * EXT v1.0.1
         * jqGrid y los handlers jQuery de MIRA5 viven en el MAIN world.
         * Ejecutamos allí la secuencia estable completa:
         * escribir -> Enter -> esperar filtro -> setSelection -> Gráficos.
         */
        const resultado = await globalThis.VienaPageBridge.call(
            'stats-filter-select-graphs',
            { valor: valorBusqueda, nodos: nodos.length ? nodos : [primerNodo] },
            30000
        );

        if (!resultado?.ok) {
            log('❌ Falló automatización Nodo MIRA5:', resultado?.error);
            return false;
        }

        log('📊 Nodo MIRA5 filtrado y Gráficos abierto:', resultado.data);
        return true;
    }

    async function limpiarFiltrosCableModem() {
        // Selector exacto confirmado en MIRA 5:
        // <button type="button" class="btn btn-default" filter-cleaner>...Limpiar</button>
        const botonLimpiar = await esperarElemento('button[filter-cleaner]', 2500);

        if (!botonLimpiar) {
            log('❌ No encontré button[filter-cleaner] de MIRA 5');
            return false;
        }

        log('🧹 Ejecutando botón Limpiar de MIRA 5');
        botonLimpiar.click();

        // Esperar a que la propia web vacíe ambos filtros.
        const inicio = Date.now();
        while (Date.now() - inicio < 2500) {
            const inputEdificio = document.querySelector('input[name="idedificio"]');
            const inputNodo = document.querySelector('input[name="nodocmts"]');

            const edificioVacio =
                !inputEdificio || String(inputEdificio.value || '').trim() === '';
            const nodoVacio =
                !inputNodo || String(inputNodo.value || '').trim() === '';

            if (edificioVacio && nodoVacio) {
                log('✅ Filtros MIRA 5 vacíos');
                return true;
            }

            await sleep(75);
        }

        const inputEdificio = document.querySelector('input[name="idedificio"]');
        const inputNodo = document.querySelector('input[name="nodocmts"]');

        log(
            '❌ El botón Limpiar fue ejecutado pero quedaron valores.',
            'ID Edificio:', inputEdificio?.value,
            'NodoCmts:', inputNodo?.value
        );
        return false;
    }

    async function buscarEdificioHFC(valor) {
        valor = limpiar(valor);

        log('🏢 HFC Edificio:', valor);

        if (!await limpiarFiltrosCableModem()) {
            return false;
        }

        const input = await esperarElemento(
            'input[name="idedificio"]'
        );

        if (!input) {
            log('❌ No encontré input[name="idedificio"]');
            return false;
        }

        // Reemplaza completamente cualquier ID anterior.
        establecerValor(input, valor);

        await sleep(150);

        // Método validado manualmente con ID 23934.
        const boton = [
            ...document.querySelectorAll(
                'button.btn.btn-primary'
            )
        ].find(
            elemento =>
                elemento.textContent.trim().toLowerCase() === 'filtrar'
        );

        if (!boton) {
            log('❌ No encontré el botón Filtrar');
            return false;
        }

        boton.click();

        log('✅ Edificio HFC filtrado:', valor);

        return true;
    }

    // ================================================================
    // GPON / FTTH
    // ================================================================

    function buscarInputGPON(labelBuscado) {
        const objetivo = String(labelBuscado)
            .trim()
            .toLowerCase();

        const contenedores = [
            ...document.querySelectorAll('.v-input')
        ];

        const contenedor = contenedores.find(elemento => {
            const label = elemento.querySelector('label');

            if (!label) return false;

            const texto = label.textContent
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();

            return texto === objetivo;
        });

        return contenedor?.querySelector('input') || null;
    }

    async function esperarInputGPON(label, timeout = 15000) {
        const inicio = Date.now();

        while (Date.now() - inicio < timeout) {
            const input = buscarInputGPON(label);

            if (input) return input;

            await sleep(150);
        }

        return null;
    }

    function enterGPON(input) {
        // Método validado manualmente:
        // keyup + Enter.
        const evento = new KeyboardEvent('keyup', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true
        });

        input.dispatchEvent(evento);
    }

    async function limpiarFiltrosGPON() {
        // Cada acción iniciada desde VIENA debe arrancar desde un formulario GPON
        // completamente limpio. No alcanza con Nodo/IdCliente/IdEdificio: si el
        // operador dejó CUALQUIER otro filtro textual activo, la consulta puede
        // devolver cero resultados o combinar criterios de forma incorrecta.

        // 1) Si la propia pantalla ofrece un botón nativo de limpieza, usarlo.
        const normalizarTexto = valor => String(valor || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();

        const botonLimpiar = Array.from(document.querySelectorAll('button'))
            .find(btn => {
                if (!btn?.isConnected || btn.disabled || btn.offsetParent === null) return false;
                const texto = normalizarTexto(btn.textContent);
                return texto === 'limpiar' ||
                    texto === 'limpiar filtros' ||
                    texto === 'borrar filtros' ||
                    texto === 'reset filtros';
            });

        if (botonLimpiar) {
            try {
                botonLimpiar.click();
                await sleep(120);
            } catch (_) {}
        }

        // 2) Defensa adicional: vaciar TODOS los controles textuales de filtros
        // Vuetify que sigan teniendo valor. Se omiten hidden/checkbox/radio y
        // controles disabled. El setter nativo + input/change actualiza el modelo Vue.
        const candidatos = Array.from(document.querySelectorAll(
            '.v-input input, .v-input textarea, input[type="text"], input[type="search"], input[type="number"], textarea'
        ));

        let encontrados = 0;
        for (const input of candidatos) {
            if (!input?.isConnected || input.disabled) continue;
            const tipo = String(input.type || '').toLowerCase();
            if (['hidden', 'checkbox', 'radio', 'button', 'submit'].includes(tipo)) continue;

            const valorActual = String(input.value ?? '');
            if (!valorActual) continue;

            encontrados++;

            try { input.focus({ preventScroll: true }); } catch (_) {}

            const proto = input instanceof HTMLTextAreaElement
                ? HTMLTextAreaElement.prototype
                : HTMLInputElement.prototype;
            const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');

            if (descriptor?.set) descriptor.set.call(input, '');
            else input.value = '';

            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }

        // 3) Verificación específica de los tres campos que usamos desde tickets.
        // Si alguno conserva valor por un rerender de Vue, se vuelve a vaciar.
        for (const label of ['Nodo', 'IdCliente', 'IdEdificio']) {
            const input = buscarInputGPON(label);
            if (!input || !String(input.value || '')) continue;

            const descriptor = Object.getOwnPropertyDescriptor(
                HTMLInputElement.prototype,
                'value'
            );
            if (descriptor?.set) descriptor.set.call(input, '');
            else input.value = '';
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }

        try { document.activeElement?.blur?.(); } catch (_) {}
        await sleep(120);

        log('🧹 GPON: limpieza total de filtros completada', {
            botonNativo: Boolean(botonLimpiar),
            camposVaciados: encontrados
        });

        // Que no haya filtros con texto también es un resultado válido.
        return true;
    }

    async function buscarNodoFTTH(valor) {
        valor = limpiar(valor).toUpperCase();

        log('🔎 FTTH Nodo:', valor);

        await limpiarFiltrosGPON();
        const input = await esperarInputGPON('Nodo');

        if (!input) {
            log('❌ No encontré Nodo GPON');
            return false;
        }

        // Reemplaza completamente cualquier nodo anterior.
        establecerValor(input, valor);

        await sleep(150);

        enterGPON(input);

        log('✅ Nodo FTTH filtrado:', valor);

        return true;
    }

    async function buscarEdificioFTTH(valor) {
        valor = limpiar(valor);

        log('🏢 FTTH Edificio:', valor);

        await limpiarFiltrosGPON();
        const input = await esperarInputGPON('IdEdificio');

        if (!input) {
            log('❌ No encontré IdEdificio GPON');
            return false;
        }

        // Reemplaza completamente cualquier ID anterior.
        establecerValor(input, valor);

        await sleep(150);

        enterGPON(input);

        log('✅ Edificio FTTH filtrado:', valor);

        return true;
    }


    async function buscarClienteFTTH(valor) {
        valor = limpiar(valor);

        log('👤 FTTH Cliente:', valor);

        await limpiarFiltrosGPON();
        const input = await esperarInputGPON('IdCliente');

        if (!input) {
            log('❌ No encontré IdCliente GPON');
            return false;
        }

        establecerValor(input, valor);
        await sleep(150);
        enterGPON(input);

        log('✅ Cliente FTTH filtrado:', valor);
        return true;
    }

    async function buscarNodoCableModemHFC(nodo) {
        nodo = limpiar(nodo).toUpperCase();
        log('🧩 HFC Nodo en Cable Modem:', nodo);

        if (!nodo || !await limpiarFiltrosCableModem()) return false;

        const input = await esperarElemento('input[name="nodocmts"]');
        if (!input) {
            log('❌ No encontré input[name="nodocmts"]');
            return false;
        }

        establecerValor(input, nodo);
        await sleep(150);
        ['keydown', 'keypress', 'keyup'].forEach(tipo => {
            input.dispatchEvent(new KeyboardEvent(tipo, {
                key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
                bubbles: true, cancelable: true
            }));
        });
        log('✅ Nodo CMTS escrito + Enter en Cable Modem:', nodo);
        return true;
    }

    async function buscarNodoListCMsHFC(nodo) {
        nodo = limpiar(nodo).toUpperCase();
        log('📋 HFC Nodo List CMs:', nodo);

        if (!nodo || !await limpiarFiltrosCableModem()) return false;

        const inputNodo = await esperarElemento('input[name="nodocmts"]');
        if (!inputNodo) {
            log('❌ No encontré input[name="nodocmts"] para List CMs');
            return false;
        }

        establecerValor(inputNodo, nodo);

        // Mismo mecanismo validado por Ir a Cliente: Nodo CMTS + botón Filtrar.
        const botonFiltrar = [...document.querySelectorAll('button.btn.btn-primary')]
            .find(elemento => limpiar(elemento.textContent).toLowerCase() === 'filtrar');
        if (!botonFiltrar) {
            log('❌ No encontré el botón Filtrar para List CMs');
            return false;
        }

        botonFiltrar.click();
        log('🔎 List CMs filtrado por Nodo CMTS:', nodo);
        return true;
    }

    async function buscarClienteHFC(cliente, nodo) {
        cliente = limpiar(cliente);
        nodo = limpiar(nodo).toUpperCase();

        log('👤 HFC Cliente:', cliente, 'Nodo:', nodo);

        if (!await limpiarFiltrosCableModem()) {
            return false;
        }

        const inputNodo = await esperarElemento('input[name="nodocmts"]');

        if (!inputNodo) {
            log('❌ No encontré input[name="nodocmts"]');
            return false;
        }

        if (nodo) {
            establecerValor(inputNodo, nodo);
            await sleep(150);

            // Cable Modem no siempre ejecuta el filtro con un Enter sintético.
            // Usamos el mismo botón Filtrar ya validado por la búsqueda de Edificio.
            const botonFiltrar = [
                ...document.querySelectorAll('button.btn.btn-primary')
            ].find(elemento =>
                elemento.textContent.trim().toLowerCase() === 'filtrar'
            );

            if (!botonFiltrar) {
                log('❌ No encontré el botón Filtrar para Cliente HFC');
                return false;
            }

            botonFiltrar.click();
            log('🔎 Filtro de NodoCmts ejecutado para Cliente HFC:', nodo);

            // Dejamos que jqGrid/listado reciba la nueva consulta. El bucle
            // posterior continúa esperando hasta 12 s por el cliente.
            await sleep(700);
        }

        // No intentamos automatizar Ctrl+F del navegador: JavaScript de página
        // no puede escribir de forma fiable en la UI del navegador.
        // En su lugar localizamos el cliente en la tabla y lo llevamos a pantalla.
        const inicio = Date.now();
        while (Date.now() - inicio < 12000) {
            const celdas = Array.from(document.querySelectorAll('td'));
            const celda = celdas.find(td =>
                limpiar(td.textContent) === cliente
            );

            if (celda) {
                celda.scrollIntoView({ block: 'center', inline: 'center' });
                const previo = celda.style.outline;
                const previoOffset = celda.style.outlineOffset;
                celda.style.outline = '3px solid #ff9800';
                celda.style.outlineOffset = '-2px';
                setTimeout(() => {
                    celda.style.outline = previo;
                    celda.style.outlineOffset = previoOffset;
                }, 6000);

                log('✅ Cliente HFC localizado en listado:', cliente);

                celda.click();
                log('🖱️ Click en cliente HFC:', cliente);

                const inicioGraficos = Date.now();
                while (Date.now() - inicioGraficos < 6000) {
                    const botonGraficos = Array.from(document.querySelectorAll(
                        'a[name="BOTON-CM-GRAF"][flag="gral"], a[href="#CM-DESC-gral-TAB-GRAF"]'
                    )).find(a => a.offsetParent !== null);

                    if (botonGraficos) {
                        botonGraficos.click();
                        log('📈 Gráficos del cliente HFC abiertos:', cliente);
                        return true;
                    }

                    await sleep(150);
                }

                log('⚠️ Cliente seleccionado, pero no apareció el tab Gráficos');
                return true;
            }

            await sleep(250);
        }

        log('❌ Cliente HFC no encontrado en el listado:', cliente);
        return false;
    }

    // ================================================================
    // HEARTBEAT DE PESTAÑAS DESTINO
    // Sólo informa que la página receptora está viva.
    // NO ejecuta búsquedas, NO toca filtros y NO reprocesa comandos.
    // ================================================================

    function heartbeatKeyActual() {
        if (ES_GPON) {
            return KEY_HEARTBEAT_GPON;
        }

        if (ES_MIRA5 && location.pathname.includes('cablemodem_frontend.php')) {
            return KEY_HEARTBEAT_EDIFICIO;
        }

        if (ES_MIRA5 && location.pathname.includes('stats_frontend.php')) {
            return KEY_HEARTBEAT_STATS;
        }

        return null;
    }

    async function publicarHeartbeat() {
        const key = heartbeatKeyActual();
        if (!key) return;

        try {
            await GM_setValue(key, {
                ts: Date.now(),
                path: location.pathname
            });
        } catch (_) {}
    }

    // ================================================================
    // PROCESAMIENTO DE COMANDOS
    // v1.0.8: cola de una orden + deduplicación
    // ================================================================

    let procesando = false;
    let ultimoComando = null;
    let comandoEnProcesoId = null;
    let comandoPendiente = null;

    function mismoComando(a, b) {
        if (!a || !b) return false;

        if (a.id && b.id) {
            return a.id === b.id;
        }

        return (
            String(a.tipo || '') === String(b.tipo || '') &&
            String(a.tecnologia || '') === String(b.tecnologia || '') &&
            limpiar(a.valor) === limpiar(b.valor)
        );
    }

    const directCommandWaiters = new Map();

    function marcarPestanaAutomatizacion(etiqueta='VIENA NOC Tools') {
        const original=String(document.title||'');
        clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);
        clearTimeout(globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__);
        let on=false;
        const pulse=()=>{on=!on;document.title=on?`● VN · ${etiqueta} · ${original}`:original;};
        pulse();
        globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__=setInterval(pulse,450);
        globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__=setTimeout(()=>{
            clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);
            document.title=original;
        },6000);
    }

    async function responderComando(comando, estado, mensaje) {
        if (!comando?.id) return;
        const direct=directCommandWaiters.get(comando.id);
        if(direct){
            directCommandWaiters.delete(comando.id);
            direct({ok:estado==='ok',estado,mensaje:String(mensaje||'')});
        }

        await GM_setValue(KEY_RESPUESTA, {
            id: comando.id,
            estado,
            mensaje: String(mensaje || ''),
            timestamp: Date.now()
        });
    }

    async function ejecutarComando(comando) {
        const tipo = String(
            comando.tipo || ''
        ).toLowerCase();

        const tecnologia = String(
            comando.tecnologia || ''
        ).toUpperCase();

        const valor = limpiar(comando.valor);
        const nodoComando = limpiar(comando.nodo || '').toUpperCase();

        if (!valor) return;

        log(
            '📨 Comando recibido:',
            {
                tipo,
                tecnologia,
                valor
            }
        );

        // ========================================================
        // MIRA5 / HFC
        // ========================================================

        if (
            ES_MIRA5 &&
            tecnologia === 'HFC'
        ) {

            if (tipo === 'nodo') {

                if (
                    !location.pathname.includes(
                        'stats_frontend.php'
                    )
                ) {
                    log(
                        '⏭️ Nodo HFC ignorado: esta pestaña MIRA5 no es Estadísticas'
                    );
                    return;
                }

                const ok =
                    await buscarNodoHFC(valor);

                if (ok) {
                    ultimoComando = comando.id || null;

                    if (comando.id) {
                        await GM_setValue(
                            KEY_ULTIMO_PROCESADO,
                            comando.id
                        );
                    }

                    await responderComando(
                        comando,
                        'ok',
                        'MIRA 5 procesó correctamente la búsqueda.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'MIRA 5 recibió la orden pero no pudo completar la búsqueda. Revisá la sesión o el estado de la página.'
                    );
                }

                return;
            }

            if (tipo === 'nodocm') {
                if (!location.pathname.includes('cablemodem_frontend.php')) {
                    log('⏭️ Nodo Cable Modem ignorado: esta pestaña MIRA5 no es Cablemodem');
                    return;
                }
                const ok = await buscarNodoCableModemHFC(valor);
                if (ok) {
                    ultimoComando = comando.id || null;
                    if (comando.id) await GM_setValue(KEY_ULTIMO_PROCESADO, comando.id);
                    await responderComando(comando, 'ok', 'MIRA 5 Cable Modem cargó Nodo CMTS y ejecutó Enter.');
                } else {
                    await responderComando(comando, 'error', 'MIRA 5 Cable Modem no pudo cargar Nodo CMTS.');
                }
                return;
            }

            if (tipo === 'nodolist') {
                if (!location.pathname.includes('cablemodem_frontend.php')) {
                    log('⏭️ List CMs ignorado: esta pestaña MIRA5 no es Cablemodem');
                    return;
                }
                const ok = await buscarNodoListCMsHFC(valor);
                if (ok) {
                    ultimoComando = comando.id || null;
                    if (comando.id) await GM_setValue(KEY_ULTIMO_PROCESADO, comando.id);
                    await responderComando(comando, 'ok', 'MIRA 5 Cable Modem filtró List CMs por Nodo CMTS.');
                } else {
                    await responderComando(comando, 'error', 'MIRA 5 Cable Modem no pudo filtrar List CMs por Nodo CMTS.');
                }
                return;
            }

            if (tipo === 'cliente') {

                if (!location.pathname.includes('cablemodem_frontend.php')) {
                    log('⏭️ Cliente HFC ignorado: esta pestaña MIRA5 no es Cablemodem');
                    return;
                }

                const ok = await buscarClienteHFC(valor, nodoComando);

                if (ok) {
                    ultimoComando = comando.id || null;
                    if (comando.id) await GM_setValue(KEY_ULTIMO_PROCESADO, comando.id);
                    await responderComando(
                        comando,
                        'ok',
                        'MIRA 5 filtró el nodo y localizó el cliente en el listado.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'MIRA 5 recibió la orden pero no pudo localizar el cliente en el listado.'
                    );
                }

                return;
            }

            if (tipo === 'edificio') {

                if (
                    !location.pathname.includes(
                        'cablemodem_frontend.php'
                    )
                ) {
                    log(
                        '⏭️ Edificio HFC ignorado: esta pestaña MIRA5 no es Cablemodem'
                    );
                    return;
                }

                const ok =
                    await buscarEdificioHFC(valor);

                if (ok) {
                    ultimoComando = comando.id || null;

                    if (comando.id) {
                        await GM_setValue(
                            KEY_ULTIMO_PROCESADO,
                            comando.id
                        );
                    }

                    await responderComando(
                        comando,
                        'ok',
                        'MIRA 5 procesó correctamente la búsqueda.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'MIRA 5 recibió la orden pero no pudo completar la búsqueda. Revisá la sesión o el estado de la página.'
                    );
                }

                return;
            }
        }

        // ========================================================
        // GPON / FTTH
        // ========================================================

        if (
            ES_GPON &&
            tecnologia === 'FTTH'
        ) {

            if (
                location.hash !== '#/listOnts'
            ) {
                log(
                    '➡️ Cambiando GPON a List ONTs'
                );

                location.hash = '#/listOnts';

                await sleep(1000);
            }

            if (tipo === 'cliente') {
                const ok = await buscarClienteFTTH(valor);

                if (ok) {
                    ultimoComando = comando.id || null;
                    if (comando.id) await GM_setValue(KEY_ULTIMO_PROCESADO, comando.id);
                    await responderComando(
                        comando,
                        'ok',
                        'GPON filtró correctamente por IdCliente.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'GPON recibió la orden pero no pudo filtrar por IdCliente.'
                    );
                }

                return;
            }

            if (tipo === 'nodo') {
                const ok =
                    await buscarNodoFTTH(valor);

                if (ok) {
                    ultimoComando = comando.id || null;

                    if (comando.id) {
                        await GM_setValue(
                            KEY_ULTIMO_PROCESADO,
                            comando.id
                        );
                    }

                    await responderComando(
                        comando,
                        'ok',
                        'GPON procesó correctamente la búsqueda.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'GPON recibió la orden pero no pudo completar la búsqueda. Revisá la sesión o el estado de la página.'
                    );
                }

                return;
            }

            if (tipo === 'edificio') {
                const ok =
                    await buscarEdificioFTTH(valor);

                if (ok) {
                    ultimoComando = comando.id || null;

                    if (comando.id) {
                        await GM_setValue(
                            KEY_ULTIMO_PROCESADO,
                            comando.id
                        );
                    }

                    await responderComando(
                        comando,
                        'ok',
                        'GPON procesó correctamente la búsqueda.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'GPON recibió la orden pero no pudo completar la búsqueda. Revisá la sesión o el estado de la página.'
                    );
                }

                return;
            }
        }
    }

    async function procesarComando(comando) {
        if (!comando || typeof comando !== 'object') {
            return;
        }

        const ultimoProcesadoPersistente =
            await GM_getValue(
                KEY_ULTIMO_PROCESADO,
                null
            );

        if (
            comando.id &&
            (
                comando.id === ultimoComando ||
                comando.id === ultimoProcesadoPersistente ||
                comando.id === comandoEnProcesoId
            )
        ) {
            log(
                '⏭️ Orden duplicada ignorada:',
                comando.id
            );
            return;
        }

        // Si llega una orden mientras MIRA5/GPON todavía está trabajando,
        // no se pierde. Se conserva únicamente la más reciente.
        if (procesando) {

            if (
                comandoPendiente &&
                mismoComando(
                    comandoPendiente,
                    comando
                )
            ) {
                log(
                    '⏭️ Orden pendiente duplicada ignorada:',
                    comando.id || limpiar(comando.valor)
                );
                return;
            }

            comandoPendiente = comando;

            log(
                '🕒 Nueva orden guardada en cola:',
                limpiar(comando.valor)
            );

            return;
        }

        procesando = true;
        comandoEnProcesoId = comando.id || null;

        try {
            await ejecutarComando(comando);

        } catch (error) {
            console.error(
                '[VIENA NOC Bridge] ERROR:',
                error
            );

        } finally {
            procesando = false;
            comandoEnProcesoId = null;

            // Si durante la búsqueda llegó otro ticket, procesarlo ahora.
            const siguiente = comandoPendiente;
            comandoPendiente = null;

            if (siguiente) {
                log(
                    '▶️ Procesando orden pendiente:',
                    limpiar(siguiente.valor)
                );

                // Liberamos primero el lock y arrancamos la siguiente orden
                // en un nuevo turno para no superponer automatizaciones.
                setTimeout(
                    () => procesarComando(siguiente),
                    0
                );
            }
        }
    }


    // ================================================================
    // v1.0.19 — RECEPTOR DE PING ACTIVO
    // ================================================================

    function destinoPingActual() {
        if (ES_GPON) {
            return 'GPON';
        }

        if (ES_MIRA5 && location.pathname.includes('cablemodem_frontend.php')) {
            return 'MIRA5_CABLEMODEM';
        }

        if (ES_MIRA5 && location.pathname.includes('stats_frontend.php')) {
            return 'MIRA5_STATS';
        }

        return null;
    }

    async function responderPing(ping) {
        if (!ping || !ping.id || !ping.destino) return;

        const actual = destinoPingActual();
        if (!actual || actual !== ping.destino) return;

        try {
            // También renovamos heartbeat como dato diagnóstico, pero la
            // disponibilidad ya no depende de su antigüedad.
            await publicarHeartbeat();

            await GM_setValue(KEY_PONG, {
                id: ping.id,
                destino: actual,
                ts: Date.now(),
                path: location.pathname
            });

            log('💓 PING respondido:', actual);
        } catch (_) {}
    }

    // ================================================================
    // MIRA5 CABLE MODEMS — COPIAR DATOS DE EDIFICIO
    // v1.3.9: helper local. No altera el submit ni el filtrado nativo.
    // ================================================================

    if (ES_MIRA5 && location.pathname.includes('cablemodem_frontend.php')) {
        const EDIF_BTN_ID = 'viena-copiar-datos-edificio';
        const EDIF_MODAL_ID = 'viena-modal-datos-edificio';
        const EDIF_TOAST_ID = 'viena-toast-datos-edificio';

        function valorCeldaFila(row, campo) {
            const td = row?.querySelector(`td[aria-describedby="grid_cm_gral_${campo}"]`);
            return String(td?.textContent || '').replace(/\s+/g, ' ').trim();
        }

        function filasCableModem() {
            return Array.from(document.querySelectorAll('#grid_cm_gral tbody tr.jqgrow'));
        }

        function datosEdificioActual() {
            const idInput = document.querySelector('#CMS-FORM-FILTRO input[name="idedificio"]');
            const idFiltro = String(idInput?.value || '').trim();
            if (!idFiltro) return { ok: false, error: 'Ingresá o filtrá un ID Edificio primero.' };

            const rows = filasCableModem().filter(row => {
                const idFila = valorCeldaFila(row, 'infocliente.edificio.idedificio');
                return !idFila || idFila === idFiltro;
            });
            if (!rows.length) return { ok: false, error: 'No hay resultados cargados para ese edificio.' };

            const conteoNodos = new Map();
            const direcciones = new Set();
            for (const row of rows) {
                const nodo = valorCeldaFila(row, 'cmNodo.nodoCmts').toUpperCase();
                if (nodo) conteoNodos.set(nodo, (conteoNodos.get(nodo) || 0) + 1);

                // Calle + altura evita que piso/depto de distintos abonados del mismo
                // edificio convierta una misma dirección en varias direcciones distintas.
                const calle = valorCeldaFila(row, 'infocliente.calle');
                const nro = valorCeldaFila(row, 'infocliente.nro');
                const direccion = [calle, nro].filter(Boolean).join(' ').trim() ||
                    valorCeldaFila(row, '__DireccionCliente');
                if (direccion) direcciones.add(direccion);
            }

            if (!conteoNodos.size) {
                return { ok: false, error: 'No pude identificar el Nodo CMTS.' };
            }

            // Un mismo edificio puede devolver CMs asociados a más de un Nodo CMTS.
            // En ese caso usamos el nodo modal: el que aparece en más filas del jqGrid.
            // Si hay empate en el máximo, no adivinamos y pedimos revisión manual.
            const nodosOrdenados = Array.from(conteoNodos.entries())
                .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
            const maxRepeticiones = nodosOrdenados[0][1];
            const nodosMasFrecuentes = nodosOrdenados.filter(([, cantidad]) => cantidad === maxRepeticiones);
            if (nodosMasFrecuentes.length !== 1) {
                return {
                    ok: false,
                    error: 'El edificio tiene más de un Nodo CMTS con la misma cantidad de CMs. Revisá los resultados antes de copiar.'
                };
            }
            const nodoCmtsPrincipal = nodosMasFrecuentes[0][0];

            if (direcciones.size !== 1) {
                return { ok: false, error: direcciones.size ? 'El edificio devuelve más de una dirección. Revisá los resultados antes de copiar.' : 'No pude identificar la dirección.' };
            }

            return {
                ok: true,
                idEdificio: idFiltro,
                nodoCmts: nodoCmtsPrincipal,
                direccion: Array.from(direcciones)[0]
            };
        }

        async function copiarTexto(texto) {
            try {
                await navigator.clipboard.writeText(texto);
                return true;
            } catch (_) {
                const ta = document.createElement('textarea');
                ta.value = texto;
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                let ok = false;
                try { ok = document.execCommand('copy'); } catch (_) {}
                ta.remove();
                return ok;
            }
        }

        function cerrarModalEdificio() {
            document.getElementById(EDIF_MODAL_ID)?.remove();
        }


        function obtenerHostToastSeguro() {
            // Los v-dialog persistent de Vuetify animan/escalean cuando reciben un click
            // "afuera". Un toast agregado a document.body cuenta como click externo.
            // Montarlo dentro del dialog activo de mayor z-index evita ese mini-zoom.
            const activos = Array.from(document.querySelectorAll('.v-dialog__content.v-dialog__content--active'))
                .map(content => ({
                content,
                dialog: content.querySelector('.v-dialog.v-dialog--active')
            }))
                .filter(({dialog}) => dialog && dialog.isConnected && getComputedStyle(dialog).display !== 'none')
                .sort((a, b) => {
                    const za = Number.parseInt(getComputedStyle(a.content).zIndex || '0', 10) || 0;
                    const zb = Number.parseInt(getComputedStyle(b.content).zIndex || '0', 10) || 0;
                    return za - zb;
                });
            return activos.length ? activos[activos.length - 1].dialog : document.body;
        }

        function mostrarToastEdificio(mensaje, tipo = 'success') {
            document.getElementById(EDIF_TOAST_ID)?.remove();

            const palette = tipo === 'error'
                ? { accent: '#c62828', icon: '!', title: 'MIRA5 · VIENA NOC Tools' }
                : { accent: '#28a745', icon: '✓', title: 'MIRA5 · VIENA NOC Tools' };

            const toast = document.createElement('div');
            toast.id = EDIF_TOAST_ID;
            toast.setAttribute('role', 'status');
            toast.setAttribute('aria-live', 'polite');
            toast.style.cssText = [
                'position:fixed',
                'top:22px',
                'right:22px',
                'z-index:2147483647',
                'width:min(420px,calc(100vw - 32px))',
                'background:#fff',
                'color:#333',
                'border:1px solid rgba(0,0,0,.12)',
                `border-left:5px solid ${palette.accent}`,
                'border-radius:8px',
                'box-shadow:0 10px 30px rgba(0,0,0,.22)',
                'font-family:Arial,sans-serif',
                'display:flex',
                'align-items:center',
                'gap:11px',
                'padding:13px 14px',
                'opacity:0',
                'transform:translateY(-10px)',
                'transition:opacity .18s ease,transform .18s ease'
            ].join(';');

            const icono = document.createElement('div');
            icono.textContent = palette.icon;
            icono.setAttribute('aria-hidden', 'true');
            icono.style.cssText = `width:28px;height:28px;min-width:28px;border-radius:50%;background:${palette.accent};color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:700;line-height:1;`;

            const contenido = document.createElement('div');
            contenido.style.cssText = 'flex:1;min-width:0;';
            const titulo = document.createElement('div');
            titulo.textContent = palette.title;
            titulo.style.cssText = 'font-size:12px;font-weight:700;color:#1f4f7d;margin-bottom:2px;';
            const texto = document.createElement('div');
            texto.textContent = mensaje;
            texto.style.cssText = 'font-size:14px;font-weight:600;line-height:1.35;';
            contenido.append(titulo, texto);

            const cerrar = document.createElement('button');
            cerrar.type = 'button';
            cerrar.setAttribute('aria-label', 'Cerrar notificación');
            cerrar.textContent = '×';
            cerrar.style.cssText = 'border:0;background:transparent;color:#777;font-size:22px;line-height:1;padding:0 2px;cursor:pointer;';

            toast.append(icono, contenido, cerrar);
            const toastHost = obtenerHostToastSeguro();
            toast.dataset.vienaToastHost = toastHost === document.body ? 'body' : 'active-dialog';
            toastHost.appendChild(toast);

            let timer = 0;
            const quitar = () => {
                if (!toast.isConnected) return;
                if (timer) clearTimeout(timer);
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(-10px)';
                setTimeout(() => toast.remove(), 190);
            };

            cerrar.tabIndex = -1;
            cerrar.addEventListener('pointerdown', event => { event.preventDefault(); event.stopPropagation(); }, true);
            cerrar.addEventListener('mousedown', event => { event.preventDefault(); event.stopPropagation(); }, true);
            cerrar.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); quitar(); });
            toast.addEventListener('click', event => event.stopPropagation());
            requestAnimationFrame(() => {
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            });
            timer = setTimeout(quitar, 3000);
        }

        function escaparHtmlSeguro(valor) {
            return String(valor ?? '').replace(/[&<>"']/g, c => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
            }[c]));
        }

        function abrirModalEdificio(datos) {
            cerrarModalEdificio();
            const idEdificioSeguro = escaparHtmlSeguro(datos?.idEdificio);
            const nodoCmtsSeguro = escaparHtmlSeguro(datos?.nodoCmts);
            const direccionSegura = escaparHtmlSeguro(datos?.direccion);
            const overlay = document.createElement('div');
            overlay.id = EDIF_MODAL_ID;
            overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,.42);display:flex;align-items:center;justify-content:center;padding:20px;';
            overlay.innerHTML = `
                <div style="width:min(520px,96vw);background:#fff;border-radius:7px;box-shadow:0 12px 38px rgba(0,0,0,.3);font-family:Arial,sans-serif;overflow:hidden;">
                    <div style="padding:14px 18px;background:#337ab7;color:#fff;font-size:17px;font-weight:600;">Copiar datos del edificio</div>
                    <div style="padding:18px;">
                        <div style="font-size:13px;color:#555;margin-bottom:12px;line-height:1.5;">
                            <b>ID Edificio:</b> ${idEdificioSeguro}<br>
                            <b>Nodo CMTS:</b> ${nodoCmtsSeguro}<br>
                            <b>Dirección:</b> ${direccionSegura}
                        </div>
                        <label for="viena-falla-edificio" style="display:block;font-weight:600;margin-bottom:6px;">Falla detectada</label>
                        <textarea id="viena-falla-edificio" class="form-control" rows="4" placeholder="Indicá la falla detectada..." style="resize:vertical;"></textarea>
                        <div id="viena-edif-error" style="min-height:20px;color:#a94442;font-size:12px;margin-top:5px;"></div>
                        <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:8px;">
                            <button type="button" class="btn btn-default" data-viena-cancelar>Cerrar</button>
                            <button type="button" class="btn btn-primary" data-viena-copiar>Copiar datos</button>
                        </div>
                    </div>
                </div>`;
            document.body.appendChild(overlay);
            const textarea = overlay.querySelector('#viena-falla-edificio');
            setTimeout(() => textarea?.focus(), 0);
            // Modal persistente: no cerrar al hacer click en el fondo. El operador puede
            // seleccionar/escribir sin riesgo de perder el texto; sólo Cerrar lo descarta.
            overlay.querySelector('[data-viena-cancelar]')?.addEventListener('click', cerrarModalEdificio);
            overlay.querySelector('[data-viena-copiar]')?.addEventListener('click', async () => {
                const falla = String(textarea?.value || '').trim();
                const error = overlay.querySelector('#viena-edif-error');
                if (!falla) {
                    if (error) error.textContent = 'Completá la falla detectada para continuar.';
                    textarea?.focus();
                    return;
                }
                const template = `ID EDIFICIO: ${datos.idEdificio}\nNODO CMTS: ${datos.nodoCmts}\nDIRECCION: ${datos.direccion}\nFALLA DETECTADA: ${falla}`;
                const ok = await copiarTexto(template);
                if (!ok) {
                    if (error) error.textContent = 'No se pudo copiar al portapapeles.';
                    return;
                }
                cerrarModalEdificio();
                mostrarToastEdificio('Datos del edificio copiados al portapapeles.');
            });
        }

        function actualizarBotonEdificio() {
            const form = document.getElementById('CMS-FORM-FILTRO');
            if (!form) return;
            const submit = form.querySelector('button[type="submit"].btn-primary');
            const idInput = form.querySelector('input[name="idedificio"]');
            if (!submit || !idInput) return;

            const id = String(idInput.value || '').trim();
            let btn = document.getElementById(EDIF_BTN_ID);
            if (!id) {
                btn?.remove();
                return;
            }
            if (!btn) {
                btn = document.createElement('button');
                btn.type = 'button';
                btn.id = EDIF_BTN_ID;
                btn.className = 'btn btn-success';
                btn.style.marginLeft = '8px';
                btn.addEventListener('click', () => {
                    const datos = datosEdificioActual();
                    if (!datos.ok) {
                        mostrarToastEdificio(datos.error, 'error');
                        return;
                    }
                    abrirModalEdificio(datos);
                });
                submit.insertAdjacentElement('afterend', btn);
            }
            const textoBoton = `Copiar datos Edif - ${id}`;
            if (btn.textContent !== textoBoton) btn.textContent = textoBoton;
        }

        document.addEventListener('input', e => {
            if (e.target?.matches?.('#CMS-FORM-FILTRO input[name="idedificio"]')) actualizarBotonEdificio();
        }, true);
        document.addEventListener('change', e => {
            if (e.target?.matches?.('#CMS-FORM-FILTRO input[name="idedificio"]')) actualizarBotonEdificio();
        }, true);

        const observerEdificio = new MutationObserver(actualizarBotonEdificio);
        observerEdificio.observe(document.documentElement, { childList: true, subtree: true });
        actualizarBotonEdificio();
    }

    // ================================================================
    // MIRA5 / GPON — ESCUCHAR ÓRDENES
    // ================================================================

    if (
        ES_MIRA5 ||
        ES_GPON
    ) {

        if (chrome?.runtime?.onMessage) {
            chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
                if(msg?.type==='VIENA_BRIDGE_PING_DIRECT'){
                    const target=String(msg.target||'');
                    const actual=destinoPingActual();
                    const expected=target==='gpon'?'GPON':target==='mira-cm'?'MIRA5_CABLEMODEM':target==='mira-stats'?'MIRA5_STATS':'';
                    sendResponse({ok:Boolean(actual&&actual===expected),destino:actual||''});
                    return;
                }
                if(msg?.type!=='VIENA_BRIDGE_RUN') return;
                const comando=msg.command;
                const target=String(msg.target||'');
                const actual=destinoPingActual();
                const expected=target==='gpon'?'GPON':target==='mira-cm'?'MIRA5_CABLEMODEM':target==='mira-stats'?'MIRA5_STATS':'';
                if(!comando?.id || !actual || actual!==expected){ sendResponse({ok:false,estado:'error',mensaje:'Pestaña destino incorrecta.'}); return; }
                marcarPestanaAutomatizacion(actual);
                let done=false;
                const finish=result=>{ if(done)return; done=true; directCommandWaiters.delete(comando.id); sendResponse(result); };
                directCommandWaiters.set(comando.id,finish);
                procesarComando(comando).catch(error=>finish({ok:false,estado:'error',mensaje:String(error?.message||error)}));
                setTimeout(()=>finish({ok:false,estado:'sin_respuesta',mensaje:'La automatización no terminó a tiempo.'}),20000);
                return true;
            });
        }

        // Presencia de la pestaña: se conserva como diagnóstico.
        publicarHeartbeat();
        setInterval(publicarHeartbeat, 2000);

        // Validación real bajo demanda. Esto funciona aunque el heartbeat haya
        // quedado viejo por throttling de Chrome en pestañas de fondo.
        GM_addValueChangeListener(
            KEY_PING,
            (_nombre, _anterior, ping) => {
                responderPing(ping);
            }
        );

        GM_addValueChangeListener(
            KEY_COMANDO,

            (
                nombre,
                anterior,
                nuevo,
                remoto
            ) => {
                if (!nuevo) return;

                // El listener puede dispararse más de una vez según las
                // pestañas/actualizaciones de Tampermonkey. procesarComando()
                // deduplica por id y encola una orden nueva si corresponde.
                log('📡 Nueva orden recibida');

                procesarComando(nuevo);
            }
        );

        // v1.0.7:
        // NO reprocesar KEY_COMANDO al cargar/refrescar MIRA5 o GPON.
        // Las órdenes se ejecutan exclusivamente cuando VIENA genera una
        // orden NUEVA y GM_addValueChangeListener la recibe.
        // Esto evita que F5 vuelva a filtrar el último nodo/edificio.
        // La pestaña destino debe estar abierta antes de pulsar el botón en VIENA.

        log(
            ES_MIRA5
                ? '🚀 Receptor MIRA5 activo'
                : '🚀 Receptor GPON activo'
        );
    }

})();
