(() => {
  'use strict';
  if (window.__VIENA_NOC_PAGE_HELPER__) return;
  window.__VIENA_NOC_PAGE_HELPER__ = true;

  const REQUEST = 'VIENA_NOC_EXT_PAGE_REQUEST';
  const RESPONSE = 'VIENA_NOC_EXT_PAGE_RESPONSE';

  // VIENA Tareas Internas — señal de progreso real para la carga paginada de
  // Tipificaciones de tarea. Se instala en MAIN world antes que la aplicación
  // para observar, sin modificar, las respuestas JSON que contienen
  // data.typifications.paginatorInfo. El contenido-script usa este evento para
  // habilitar Asignaciones sólo cuando VIENA terminó de cargar su catálogo.
  function instalarProgresoTipificacionesViena() {
    if (location.hostname !== 'viena.telecentro.net.ar') return false;
    if (window.__VIENA_TYPIFICATIONS_PROGRESS_BRIDGE__) return true;
    window.__VIENA_TYPIFICATIONS_PROGRESS_BRIDGE__ = true;

    let maxPage = 0;
    let totalPages = 0;
    let done = false;
    const rememberedItems = new Map();
    const EVENT_NAME = 'VIENA_NOC_TYPIFICATIONS_PROGRESS';
    const REQUEST_EVENT = 'VIENA_NOC_TYPIFICATIONS_PROGRESS_REQUEST';
    const EXPECTED_TOTAL_PAGES = 17;

    const normalizarEntradaTipificacion = item => {
      if (!item || typeof item !== 'object') return null;
      const codeKeys = ['code','codigo','cod','shortCode','typificationCode','taskTypificationCode'];
      const labelKeys = ['description','descripcion','name','nombre','label','title','text'];

      let code = '';
      for (const key of codeKeys) {
        const value = String(item?.[key] ?? '').trim().toUpperCase();
        if (/^[A-Z0-9]{2,8}$/.test(value)) { code = value; break; }
      }
      if (!code) {
        for (const value of Object.values(item)) {
          if (typeof value !== 'string') continue;
          const candidate = value.trim().toUpperCase();
          if (/^[A-Z]{2,8}$/.test(candidate)) { code = candidate; break; }
        }
      }
      if (!code) return null;

      let label = '';
      for (const key of labelKeys) {
        const value = String(item?.[key] ?? '').replace(/\s+/g, ' ').trim();
        if (value && value.toUpperCase() !== code) { label = value; break; }
      }
      if (!label) {
        const strings = Object.values(item)
          .filter(v => typeof v === 'string')
          .map(v => v.replace(/\s+/g, ' ').trim())
          .filter(v => v && v.toUpperCase() !== code && v.length <= 220)
          .sort((a,b) => b.length - a.length);
        label = strings[0] || '';
      }
      return { code, label };
    };

    const extraerEntradasTipificacion = typ => {
      const raw = Array.isArray(typ?.data) ? typ.data
        : Array.isArray(typ?.items) ? typ.items
        : Array.isArray(typ?.nodes) ? typ.nodes
        : Array.isArray(typ?.results) ? typ.results
        : [];
      const out = [];
      const seen = new Set();
      for (const item of raw) {
        const entry = normalizarEntradaTipificacion(item);
        if (!entry || seen.has(entry.code)) continue;
        seen.add(entry.code);
        out.push(entry);
      }
      return out;
    };

    const emitir = (page, hasMorePages, items = [], reportedTotalPages = 0) => {
      const n = Number(page || 0);
      const total = Number(reportedTotalPages || 0);
      if (Number.isFinite(n) && n > 0) maxPage = Math.max(maxPage, n);
      if (Number.isFinite(total) && total > 0) totalPages = Math.max(totalPages, total);

      for (const item of Array.isArray(items) ? items : []) {
        const code = String(item?.code || '').trim().toUpperCase();
        if (code) rememberedItems.set(code, item);
      }

      if (hasMorePages === false) {
        done = true;
        if (!totalPages && maxPage) totalPages = maxPage;
      }

      document.dispatchEvent(new CustomEvent(EVENT_NAME, {
        detail: {
          currentPage: maxPage || n || 0,
          totalPages: totalPages || 0,
          hasMorePages: hasMorePages !== false,
          done,
          items: [...rememberedItems.values()].slice(0, 1000),
          ts: Date.now()
        }
      }));
    };

    const revisarObjeto = obj => {
      if (!obj || typeof obj !== 'object') return false;
      const candidatos = [];
      if (obj?.data?.typifications) candidatos.push(obj.data.typifications);
      if (Array.isArray(obj)) {
        for (const item of obj) if (item?.data?.typifications) candidatos.push(item.data.typifications);
      }
      let encontrado = false;
      for (const typ of candidatos) {
        const pi = typ?.paginatorInfo;
        if (!pi || typeof pi !== 'object') continue;
        encontrado = true;
        const reportedTotalPages = Number(
          pi.lastPage ?? pi.totalPages ?? pi.total_pages ?? pi.last_page ?? 0
        );
        emitir(pi.currentPage, pi.hasMorePages, extraerEntradasTipificacion(typ), reportedTotalPages);
      }
      return encontrado;
    };

    const revisarTexto = text => {
      if (!text || typeof text !== 'string' || !text.includes('typifications')) return;
      try { revisarObjeto(JSON.parse(text)); } catch (_) {}
    };

    document.addEventListener(REQUEST_EVENT, () => {
      emitir(maxPage, !done, [], totalPages);
    });

    // Fallback autoritativo adicional: VIENA ya informa cada página en consola
    // como "Respuesta de tipificaciones, página", N, response.
    // El tracer validó 17 páginas. Esto evita depender únicamente de interceptar
    // fetch/XHR y permite que Asignaciones muestre 1/17 ... 17/17.
    if (!console.log.__VIENA_TYPIFICATIONS_PROGRESS__) {
      const originalLog = console.log.bind(console);
      const wrappedLog = function(...args) {
        try {
          if (
            String(args[0] || '').includes('Respuesta de tipificaciones') &&
            String(args[0] || '').includes('página')
          ) {
            const page = Number(args[1] || 0);
            const response = args[2];
            let hasMore = page < EXPECTED_TOTAL_PAGES;
            let items = [];
            try {
              const typ = response?.data?.typifications;
              if (typ) {
                items = extraerEntradasTipificacion(typ);
                if (typeof typ?.paginatorInfo?.hasMorePages === 'boolean') {
                  hasMore = typ.paginatorInfo.hasMorePages;
                }
              }
            } catch (_) {}
            emitir(
              page,
              page >= EXPECTED_TOTAL_PAGES ? false : hasMore,
              items,
              EXPECTED_TOTAL_PAGES
            );
          }
        } catch (_) {}
        return originalLog(...args);
      };
      wrappedLog.__VIENA_TYPIFICATIONS_PROGRESS__ = true;
      console.log = wrappedLog;
    }

    if (typeof window.fetch === 'function' && !window.fetch.__VIENA_TYPIFICATIONS_PROGRESS__) {
      const originalFetch = window.fetch;
      const wrappedFetch = function(...args) {
        return originalFetch.apply(this, args).then(response => {
          try {
            const type = String(response?.headers?.get?.('content-type') || '').toLowerCase();
            if (!type || type.includes('json')) {
              response.clone().text().then(revisarTexto).catch(() => {});
            }
          } catch (_) {}
          return response;
        });
      };
      try { Object.assign(wrappedFetch, originalFetch); } catch (_) {}
      wrappedFetch.__VIENA_TYPIFICATIONS_PROGRESS__ = true;
      wrappedFetch.__VIENA_ORIGINAL__ = originalFetch;
      window.fetch = wrappedFetch;
    }

    if (typeof window.XMLHttpRequest === 'function' && !window.XMLHttpRequest.prototype.__VIENA_TYPIFICATIONS_PROGRESS__) {
      const proto = window.XMLHttpRequest.prototype;
      const originalOpen = proto.open;
      const originalSend = proto.send;
      proto.open = function(...args) {
        try { this.__vienaTypUrl = String(args[1] || ''); } catch (_) {}
        return originalOpen.apply(this, args);
      };
      proto.send = function(...args) {
        if (!this.__vienaTypProgressBound) {
          this.__vienaTypProgressBound = true;
          this.addEventListener('loadend', () => {
            try {
              if (this.responseType && this.responseType !== 'text' && this.responseType !== 'json') return;
              if (this.responseType === 'json') revisarObjeto(this.response);
              else revisarTexto(String(this.responseText || ''));
            } catch (_) {}
          }, { once: true });
        }
        return originalSend.apply(this, args);
      };
      proto.__VIENA_TYPIFICATIONS_PROGRESS__ = true;
    }

    return true;
  }

  instalarProgresoTipificacionesViena();


  // MOICA v1.0.6.25 — saneo definitivo en el límite del jqGrid.
  // Evidencia TRACE: buscarParametrosBusqueda() puede generar filtros fantasma vacíos
  // incluso en una página recién abierta: region:{"$in":[""]}, tipoRed:"",
  // category_id:{"$in":[""]}. En vez de perseguir el estado de bootstrap-select o
  // interceptar el botón Buscar, saneamos la URL EXACTA que jqGrid va a guardar/enviar.
  // Sólo quitamos esos tres criterios cuando son semánticamente vacíos; cualquier filtro
  // real elegido por el operador se conserva. También sincronizamos findAnt con la URL
  // saneada para que la siguiente búsqueda nativa pueda reemplazar el filtro anterior.
  function instalarSaneoJqGridMoica() {
    if (!/\/buscarTicket\.php/i.test(location.pathname)) return false;
    const $ = window.jQuery;
    if (!$ || !$.fn || typeof $.fn.jqGrid !== 'function') return false;
    if ($.fn.jqGrid.__VIENA_MOICA_GHOST_FILTER_FIX__) return true;

    const originalJqGrid = $.fn.jqGrid;
    const esVacio = valor => {
      if (valor == null) return true;
      if (typeof valor === 'string') return valor.trim() === '';
      if (Array.isArray(valor)) return valor.length === 0 || valor.every(esVacio);
      if (typeof valor === 'object' && Array.isArray(valor.$in)) return esVacio(valor.$in);
      return false;
    };
    const sanearUrl = url => {
      if (typeof url !== 'string' || !url.includes('defaultFilter=')) return { url, changed: false, find: null };
      const marker = 'defaultFilter=';
      const ini = url.indexOf(marker) + marker.length;
      const fin = url.indexOf('&', ini);
      const raw = url.slice(ini, fin >= 0 ? fin : url.length);
      let decoded = raw;
      try { decoded = decodeURIComponent(raw); } catch (_) {}
      let filtro;
      try { filtro = JSON.parse(decoded); } catch (_) { return { url, changed: false, find: null }; }

      let changed = false;
      for (const key of ['region', 'tipoRed', 'category_id']) {
        if (Object.prototype.hasOwnProperty.call(filtro, key) && esVacio(filtro[key])) {
          delete filtro[key];
          changed = true;
        }
      }
      const limpio = JSON.stringify(filtro);
      const usaEncoding = raw.includes('%22') || raw.includes('%7B') || raw.includes('%7b');
      const reemplazo = usaEncoding ? encodeURIComponent(limpio) : limpio;
      const nuevaUrl = url.slice(0, ini) + reemplazo + (fin >= 0 ? url.slice(fin) : '');
      return { url: nuevaUrl, changed, find: limpio.slice(1, -1), filtro };
    };

    function jqGridViena(...args) {
      if (args[0] === 'setGridParam' && args[1] && typeof args[1] === 'object' && typeof args[1].url === 'string') {
        const esGridMoica = this && Array.from(this).some(el => el?.id === 'grid_TktsBuscar');
        if (esGridMoica) {
          const saneado = sanearUrl(args[1].url);
          if (saneado.changed) {
            args[1] = { ...args[1], url: saneado.url };
            window.findAnt = saneado.find;
            console.log('[VIENA MOICA] 1.0.6.25 filtros fantasma eliminados antes del request', {
              urlOriginal: arguments[1]?.url,
              urlLimpia: saneado.url,
              findAnt: saneado.find
            });
          }
        }
      }
      return originalJqGrid.apply(this, args);
    }
    // Conservar propiedades/plugins que jqGrid pudiera haber colgado de la función.
    Object.assign(jqGridViena, originalJqGrid);
    jqGridViena.__VIENA_MOICA_GHOST_FILTER_FIX__ = true;
    jqGridViena.__VIENA_MOICA_ORIGINAL__ = originalJqGrid;
    $.fn.jqGrid = jqGridViena;

    // v1.0.6.28 — último límite antes de salir a red. El TRACE 6 demuestra que,
    // después del flujo automático, buscarParametrosBusqueda() vuelve a construir
    // region=[''], tipoRed='' y category_id=[''] y jqGrid puede enviarlos sin pasar
    // por nuestro setGridParam envuelto. El prefilter cubre cualquier camino interno
    // de jqGrid y sólo modifica requests de grid_TktsBuscar con fantasmas vacíos.
    if (!window.__VIENA_MOICA_AJAX_GHOST_FILTER_FIX__) {
      window.__VIENA_MOICA_AJAX_GHOST_FILTER_FIX__ = true;
      $.ajaxPrefilter((options) => {
        const url = String(options?.url || '');
        if (!url.includes('gridController.php') || !url.includes('grid=grid_TktsBuscar') || !url.includes('defaultFilter=')) return;
        const saneado = sanearUrl(url);
        if (!saneado.changed) return;
        options.url = saneado.url;
        window.findAnt = saneado.find;
        const grid = $('#grid_TktsBuscar');
        if (grid.length) originalJqGrid.call(grid, 'setGridParam', { url: saneado.url });
        console.log('[VIENA MOICA] 1.0.6.28 request final saneado', { urlLimpia: saneado.url, findAnt: saneado.find });
      });
    }

    // v1.0.6.27 — compatibilidad definitiva búsqueda manual DESPUÉS de una búsqueda automática.
    // MOICA nativo reemplaza el filtro anterior con String.replace(findAnt, find). Después de
    // recargas/sort/paginado jqGrid puede dejar defaultFilter URL-encoded, por lo que el findAnt
    // raw ya no existe literalmente en la URL y MOICA reutiliza el nodo anterior. En el click
    // manual sincronizamos URL + findAnt a una representación raw equivalente ANTES de dejar
    // ejecutar buscarParametrosBusqueda(). No ejecutamos búsquedas ni tocamos los valores UI.
    if (!window.__VIENA_MOICA_NATIVE_MANUAL_SYNC__) {
      window.__VIENA_MOICA_NATIVE_MANUAL_SYNC__ = true;
      document.addEventListener('click', event => {
        const boton = event.target?.closest?.('button[onclick*="buscarParametrosBusqueda"]');
        if (!boton) return;
        const grid = $('#grid_TktsBuscar');
        if (!grid.length) return;
        const url = String(originalJqGrid.call(grid, 'getGridParam', 'url') || '');
        const marker = 'defaultFilter=';
        const ini = url.indexOf(marker);
        if (ini < 0) return;
        const desde = ini + marker.length;
        const fin = url.indexOf('&', desde);
        const raw = url.slice(desde, fin >= 0 ? fin : url.length);
        let decoded = raw;
        try { decoded = decodeURIComponent(raw); } catch (_) {}
        let filtro;
        try { filtro = JSON.parse(decoded); } catch (_) { return; }
        // También eliminamos únicamente fantasmas ya existentes; filtros reales se preservan.
        for (const key of ['region', 'tipoRed', 'category_id']) {
          if (Object.prototype.hasOwnProperty.call(filtro, key) && esVacio(filtro[key])) delete filtro[key];
        }
        const limpio = JSON.stringify(filtro);
        const urlRaw = url.slice(0, desde) + limpio + (fin >= 0 ? url.slice(fin) : '');
        originalJqGrid.call(grid, 'setGridParam', { url: urlRaw });
        window.findAnt = limpio.slice(1, -1);
        console.log('[VIENA MOICA] 1.0.6.27 estado nativo sincronizado antes de Buscar manual', {
          findAnt: window.findAnt, url: urlRaw
        });
      }, true);
    }

    console.log('[VIENA MOICA] Fix 1.0.6.27 jqGrid + búsqueda manual activo');
    return true;
  }

  if (/\/buscarTicket\.php/i.test(location.pathname)) {
    if (!instalarSaneoJqGridMoica()) {
      const timerFixJqGrid = setInterval(() => {
        if (instalarSaneoJqGridMoica()) clearInterval(timerFixJqGrid);
      }, 50);
      setTimeout(() => clearInterval(timerFixJqGrid), 20000);
    }
  }

  function reply(id, ok, data = null, error = null) {
    document.dispatchEvent(new CustomEvent(RESPONSE, { detail: { id, ok, data, error } }));
  }

  document.addEventListener(REQUEST, async event => {
    const msg = event.detail || {};
    const id = msg.id;
    if (!id) return;
    try {
      const $ = window.jQuery;
      if (!$ || typeof $.Event !== 'function') {
        reply(id, false, null, 'jQuery no disponible');
        return;
      }
      if (msg.action === 'jquery-ready') {
        reply(id, true, true);
        return;
      }
      if (msg.action === 'moica-normalize-empty-filters') {
        // limpiarParametrosBusqueda() usa $('select').val(''), pero en estos filtros
        // MOICA interpreta '' / [''] como filtros REALES (region/tipoRed/category_id).
        // Una pantalla limpia manualmente los deja en null. Reproducimos ese estado.
        const selectors = ['#TKT-BUSCAR-REGION', '#TKT-BUSCAR-TIPO-RED', '#TKT-BUSCAR-CATEGORIA'];
        const values = {};
        for (const selector of selectors) {
          const el = $(selector);
          if (!el.length) continue;
          el.val(null);
          if (typeof el.selectpicker === 'function' && el.hasClass('selectpicker')) {
            try { el.selectpicker('refresh'); } catch (_) {}
          }
          values[selector] = el.val();
        }
        console.log('[VIENA MOICA] Filtros vacíos normalizados a null:', values);
        reply(id, true, values);
        return;
      }

      if (msg.action === 'moica-select-node') {
        const esperado = String(msg.payload?.nodo || '').trim().toUpperCase();
        const input = $('#TKT-BUSCAR-NODO-autocom');
        const log = (...a) => console.log('[VIENA MOICA]', ...a);
        const fail = (mensaje, data = null) => { console.error('[VIENA MOICA]', mensaje, data || ''); reply(id, false, data, mensaje); };
        if (!esperado || !input.length || typeof input.autocomplete !== 'function') {
          fail('Autocomplete de Nodo no disponible');
          return;
        }

        const normalizar = v => String(v || '').trim().toUpperCase().replace(/\s+/g, '').replace(/[,，]$/, '');
        const dormir = ms => new Promise(r => setTimeout(r, ms));
        const opcionesVisibles = () => Array.from(document.querySelectorAll('ul.ui-autocomplete li.ui-menu-item a')).filter(a => {
          const ul = a.closest('ul.ui-autocomplete');
          return !!ul && ul.getClientRects().length > 0 && getComputedStyle(ul).display !== 'none';
        });
        const exactaVisible = () => opcionesVisibles().find(a => normalizar(a.textContent) === normalizar(esperado)) || null;
        const esperarExacta = async timeout => {
          const inicio = Date.now();
          while (Date.now() - inicio < timeout) {
            const visibles = opcionesVisibles();
            if (visibles.length) log('UL visible. Opciones:', visibles.map(a => String(a.textContent || '').trim()));
            const a = visibles.find(x => normalizar(x.textContent) === normalizar(esperado));
            if (a) return a;
            await dormir(80);
          }
          return null;
        };
        const setValorComoPegado = valor => {
          const el = input[0];
          el.focus();
          const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
          if (setter) setter.call(el, valor); else el.value = valor;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          log('Nodo escrito en input:', JSON.stringify(el.value));
        };
        const teclaYValor = (key, code, keyCode, valor) => {
          const el = input[0];
          el.focus();
          el.dispatchEvent(new KeyboardEvent('keydown', { key, code, keyCode, which: keyCode, bubbles: true }));
          const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
          if (setter) setter.call(el, valor); else el.value = valor;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new KeyboardEvent('keyup', { key, code, keyCode, which: keyCode, bubbles: true }));
        };
        const fallbackEspacioYBorrar = async () => {
          const base = String(input.val() || '').trimEnd();
          teclaYValor(' ', 'Space', 32, base + ' ');
          log('Fallback: agregado UN espacio:', JSON.stringify(input.val()));
          // Optimización DEV: MOICA necesita un pequeño intervalo para procesar el Space,
          // pero 1.5 s era conservador. Probamos 100 ms.
          // La espera inicial exacta también queda en 100 ms en esta DEV.
          await dormir(100);
          teclaYValor('Backspace', 'Backspace', 8, base);
          log('Fallback: 100ms después se borró el espacio. Esperando UL:', JSON.stringify(input.val()));
        };

        try {
          log('PASO NODO: click/focus sobre input');
          input[0].click(); input[0].focus();
          log('PASO NODO: pegar/escribir nodo', esperado);
          setValorComoPegado(esperado);
          log('PASO NODO: esperando UL');
          let opcion = await esperarExacta(100);

          if (!opcion) {
            log('A los 100ms no apareció el match exacto. Fallback DEV: espacio -> esperar 100ms -> borrar espacio -> esperar UL.');
            await fallbackEspacioYBorrar();
            opcion = await esperarExacta(30000);
          }

          if (!opcion) {
            fail('No apareció el UL con la sugerencia exacta del nodo', { value: input.val(), opciones: opcionesVisibles().map(a => a.textContent) });
            return;
          }

          log('MATCH exacto encontrado en UL:', String(opcion.textContent || '').trim());
          const li = opcion.closest('li.ui-menu-item');
          if (!li) { fail('La sugerencia exacta no pertenece al menú de autocomplete'); return; }
          // jQuery UI 1.x necesita que el item quede ACTIVO antes del click; un click sintético directo
          // deja menu.active=null y provoca el error ui.item/data visto en consola.
          // Reproducir la secuencia observada en el TRACE manual de MOICA:
          // activar item -> mousedown -> blur del input -> click -> focus.
          // Además activamos explícitamente el item en el menú de jQuery UI para que
          // el handler select reciba ui.item y no quede menu.active=null.
          const ac = input.data('autocomplete') || input.data('ui-autocomplete');
          try {
            if (ac?.menu?.activate) ac.menu.activate($.Event('mouseenter'), $(li));
          } catch (e) { log('Aviso activando menu item:', String(e?.message || e)); }
          $(li).trigger('mouseenter');
          $(opcion).trigger('mouseenter');
          await dormir(80);
          const ul = opcion.closest('ul.ui-autocomplete');
          log('Item activo antes de seleccionar:', ul?.getAttribute('aria-activedescendant') || '(sin aria-activedescendant)');
          $(opcion).trigger('mousedown');
          input[0].blur();
          await dormir(30);
          $(opcion).trigger('click');
          await dormir(30);
          input[0].focus();
          log('Secuencia manual mousedown -> blur -> click -> focus ejecutada sobre opción exacta');

          const limite = Date.now() + 5000;
          let value = '';
          while (Date.now() < limite) {
            value = String(input.val() || '');
            if (/[,，]\s*$/.test(value) && normalizar(value) === normalizar(esperado)) break;
            await dormir(50);
          }
          const ok = /[,，]\s*$/.test(value) && normalizar(value) === normalizar(esperado);
          log('Valor final tras seleccionar:', JSON.stringify(value), 'comaConfirmada=', ok);
          if (!ok) { fail('El click del UL no dejó el nodo seleccionado con coma final', { value }); return; }
          reply(id, true, { nodo: esperado, value });
        } catch (error) {
          fail('Excepción seleccionando nodo: ' + String(error?.message || error));
        }
        return;
      }
      if (msg.action === 'moica-search-node') {
        const esperado = String(msg.payload?.nodo || '').trim().toUpperCase();
        const input = $('#TKT-BUSCAR-NODO-autocom');
        const grid = $('#grid_TktsBuscar');
        if (!esperado || !input.length || !grid.length) {
          reply(id, false, null, 'Búsqueda MOICA no disponible');
          return;
        }
        try {
          // CRITICAL: después de seleccionar el autocomplete NO tocar el valor,
          // findAnt ni la URL del jqGrid. El flujo manual que funciona deja
          // exactamente "NODO, " y pulsa el botón Buscar real. Reproducimos eso.
          const visual = String(input.val() || '');
          const normalizar = v => String(v || '').trim().toUpperCase().replace(/\s+/g, '');
          const seleccionado = /[,，]\s*$/.test(visual) &&
            normalizar(visual.replace(/[,，]\s*$/, '')) === normalizar(esperado);
          if (!seleccionado) {
            reply(id, false, { value: visual }, 'El nodo no quedó seleccionado por el autocomplete nativo');
            return;
          }
          const boton = Array.from(document.querySelectorAll('button')).find(b =>
            String(b.getAttribute('onclick') || '').includes('buscarParametrosBusqueda')
          );
          if (!boton) {
            reply(id, false, null, 'Botón Buscar de MOICA no disponible');
            return;
          }
          // Enganchamos los eventos ANTES del click real. Así no confundimos un cambio
          // visual del grid con una búsqueda que todavía no salió a MOICA.
          const urlAntes = String(grid.jqGrid('getGridParam', 'url') || '');
          const findAntAntes = typeof window.findAnt !== 'undefined' ? String(window.findAnt) : null;
          let beforeRequest = false;
          let loadComplete = false;
          let gridComplete = false;
          let filasLoad = null;
          const ns = '.vienaMoicaSearch' + Date.now();
          grid.on('jqGridBeforeRequest' + ns, () => { beforeRequest = true; console.log('[VIENA MOICA] MAIN jqGrid beforeRequest'); });
          grid.on('jqGridLoadComplete' + ns, data => {
            loadComplete = true;
            filasLoad = Array.isArray(data?.rows) ? data.rows.length : null;
            console.log('[VIENA MOICA] MAIN jqGrid loadComplete', { filasRespuesta: filasLoad });
          });
          grid.on('jqGridGridComplete' + ns, () => { gridComplete = true; });

          // FIX RAIZ 1.0.6.19: no delegar la construcción del filtro a
          // buscarParametrosBusqueda(), porque MOICA convierte selects vacíos en filtros reales.
          // Conservamos la URL/modelo del jqGrid y reemplazamos SOLO defaultFilter por los dos
          // criterios válidos de esta automatización: estados + nodo seleccionado por autocomplete.
          const estados = ($('#TKT-BUSCAR-ESTADO').val() || []).filter(v => String(v || '').trim());
          const filtroCorrecto = {
            'estado_actual.estado': { '$in': estados },
            'nodoRef': { '$elemMatch': { '$eq': visual } }
          };
          const defaultFilterCorrecto = JSON.stringify(filtroCorrecto);
          const findCorrecto = defaultFilterCorrecto.slice(1, -1);
          const reemplazarDefaultFilter = (url, filtro) => {
            const marker = 'defaultFilter=';
            const ini = url.indexOf(marker);
            if (ini < 0) return url + (url.includes('?') ? '&' : '?') + marker + filtro;
            const desde = ini + marker.length;
            const fin = url.indexOf('&', desde);
            return url.slice(0, desde) + filtro + (fin >= 0 ? url.slice(fin) : '');
          };
          const urlCorregida = reemplazarDefaultFilter(urlAntes, defaultFilterCorrecto);

          // Mantener sincronizado el global que MOICA usa como filtro anterior para que la próxima
          // búsqueda no vuelva a partir del filtro fantasma. No tocamos el valor visual del nodo.
          window.findAnt = findCorrecto;
          console.log('[VIENA MOICA] FIX 1.0.6.19 búsqueda limpia', {
            value: visual, estados, urlAntes, urlCorregida, findAntAntes, findCorrecto
          });
          grid.jqGrid('setGridParam', { url: urlCorregida, page: 1, datatype: 'json' }).trigger('reloadGrid');

          const limiteCarga = Date.now() + 15000;
          while (Date.now() < limiteCarga && !loadComplete) await new Promise(r => setTimeout(r, 50));
          const urlDespues = String(grid.jqGrid('getGridParam', 'url') || '');
          const findAntDespues = typeof window.findAnt !== 'undefined' ? String(window.findAnt) : null;
          const filasDOM = document.querySelectorAll('#grid_TktsBuscar tr.jqgrow').length;
          console.log('[VIENA MOICA] MAIN después de Buscar', { beforeRequest, loadComplete, gridComplete, filasLoad, filasDOM, urlDespues, findAntDespues });
          grid.off(ns);
          if (!beforeRequest || !loadComplete) {
            reply(id, false, { value: visual, beforeRequest, loadComplete, urlAntes, urlDespues, findAntAntes, findAntDespues }, 'Buscar no completó una recarga real de jqGrid');
            return;
          }
          reply(id, true, { nodo: esperado, value: visual, filasDOM, filasLoad, urlAntes, urlDespues, findAntAntes, findAntDespues });
        } catch (error) {
          reply(id, false, null, String(error?.message || error));
        }
        return;
      }
      if (msg.action === 'reset-stats-grid') {
        const grid = $('#gridStatsNodosCmts');
        if (!grid.length || typeof grid.jqGrid !== 'function') {
          reply(id, false, null, 'jqGrid no disponible');
          return;
        }
        grid.jqGrid('resetSelection');
        reply(id, true, true);
        return;
      }
      if (msg.action === 'trigger-nodocmts-enter') {
        const input = document.querySelector('#gs_nodoCmts');
        if (!input) {
          reply(id, false, null, '#gs_nodoCmts no disponible');
          return;
        }
        const e = $.Event('keypress');
        e.which = 13; e.keyCode = 13; e.key = 'Enter';
        $(input).trigger(e);
        reply(id, true, true);
        return;
      }
      if (msg.action === 'stats-filter-select-graphs') {
        const valor = String(msg.payload?.valor || '').trim().toUpperCase();
        const nodos = Array.isArray(msg.payload?.nodos)
          ? msg.payload.nodos.map(v => String(v || '').trim().toUpperCase()).filter(Boolean)
          : [];
        const input = document.querySelector('#gs_nodoCmts');
        const grid = $('#gridStatsNodosCmts');

        if (!valor || !input) {
          reply(id, false, null, 'Nodo/#gs_nodoCmts no disponible');
          return;
        }
        if (!grid.length || typeof grid.jqGrid !== 'function') {
          reply(id, false, null, 'jqGrid no disponible');
          return;
        }

        try {
          grid.jqGrid('resetSelection');

          // Replicar la escritura real del userscript estable dentro del mundo MAIN.
          input.focus();
          input.value = valor;
          $(input).val(valor);
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));

          // MIRA5 históricamente escucha keypress; enviamos además keydown/keyup
          // para tolerar cambios del handler sin alterar el comportamiento.
          for (const tipo of ['keydown', 'keypress', 'keyup']) {
            const e = $.Event(tipo);
            e.which = 13;
            e.keyCode = 13;
            e.key = 'Enter';
            $(input).trigger(e);
          }

          const esperados = new Set((nodos.length ? nodos : [valor]).map(v => v.toUpperCase()));
          const inicio = Date.now();
          let celda = null;

          while (Date.now() - inicio < 15000) {
            const celdas = Array.from(document.querySelectorAll(
              'td[aria-describedby="gridStatsNodosCmts_nodoCmts"]'
            ));
            celda = celdas.find(td => esperados.has(String(td.textContent || '').trim().toUpperCase()));
            if (celda) break;
            await new Promise(r => setTimeout(r, 200));
          }

          if (!celda) {
            reply(id, false, null, 'El filtro no devolvió el nodo esperado');
            return;
          }

          const rowId = celda.closest('tr')?.id;
          if (!rowId) {
            reply(id, false, null, 'Fila jqGrid sin ID');
            return;
          }

          grid.jqGrid('resetSelection');
          await new Promise(r => setTimeout(r, 250));
          grid.jqGrid('setSelection', rowId, true);

          const inicioGraf = Date.now();
          let graficos = null;
          while (Date.now() - inicioGraf < 10000) {
            graficos = document.querySelector('#BOTON-NODOCMTS-CHART-GRAL');
            if (graficos) break;
            await new Promise(r => setTimeout(r, 150));
          }
          if (!graficos) {
            reply(id, false, null, 'No apareció Gráficos Generales');
            return;
          }

          await new Promise(r => setTimeout(r, 350));
          graficos.click();
          reply(id, true, { nodo: String(celda.textContent || '').trim(), rowId });
        } catch (error) {
          reply(id, false, null, String(error?.message || error));
        }
        return;
      }
      reply(id, false, null, 'Acción desconocida');
    } catch (error) {
      reply(id, false, null, String(error && error.message || error));
    }
  });
})();
