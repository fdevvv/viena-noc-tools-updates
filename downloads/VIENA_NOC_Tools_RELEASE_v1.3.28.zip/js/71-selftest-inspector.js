(() => {
'use strict';
if(window.__VIENA_SELFTEST_INSPECTOR__)return; window.__VIENA_SELFTEST_INSPECTOR__=true;
const norm=v=>String(v||'').trim().toUpperCase().replace(/\s+/g,'').replace(/,\s*$/,'');
const text=el=>norm(el?.getAttribute?.('title')||el?.textContent||el?.value||'');
const visible=el=>!!el&&el.getClientRects().length>0;
function rows(grid){return Array.from(document.querySelectorAll(`${grid} tr.jqgrow, ${grid} tbody tr[id]`));}
function exactRow(grid,aria,expected){return rows(grid).find(tr=>Array.from(tr.querySelectorAll(`td[aria-describedby="${aria}"]`)).some(td=>{const raw=String(td.getAttribute('title')||td.textContent||'').toUpperCase();return norm(raw)===expected||raw.split(/[^A-Z0-9]+/).filter(Boolean).includes(expected);}));}
function inspect(s){
 const e=norm(s.expected), host=location.hostname;
 if(s.target==='mira-stats'){
   const input=document.querySelector('#gs_nodoCmts'); const row=exactRow('#gridStatsNodosCmts','gridStatsNodosCmts_nodoCmts',e);
   return {ok:norm(input?.value)===e&&!!row,detail:!input?'Falta #gs_nodoCmts':norm(input.value)!==e?`Filtro actual: ${input.value||'vacío'}`:!row?'No apareció la fila exacta del nodo':'Filtro y fila exacta OK'};
 }
 if(s.target==='mira-cm'){
   const name=s.mode==='edificio'?'idedificio':(s.mode==='cliente'?'nodo':'nodocmts'); const input=document.querySelector(`#CMS-FORM-FILTRO input[name="${name}"], input[name="${name}"]`);
   const graph=document.querySelector('#CM-DESC-gral-TAB-GRAF');
   return {ok:norm(input?.value)===e&&!!graph,detail:!input?`Falta input ${name}`:norm(input.value)!==e?`Filtro actual: ${input.value||'vacío'}`:!graph?'No se cargó el panel de gráficos':'Filtro y gráficos OK'};
 }
 if(s.target==='gpon'){
   const wanted=s.mode==='cliente'?['ID CLIENTE','IDCLIENTE']:s.mode==='edificio'?['ID EDIFICIO','IDEDIFICIO']:['NODO'];
   const boxes=Array.from(document.querySelectorAll('.v-input')); let input=null;
   for(const b of boxes){const lab=norm(b.querySelector('label')?.textContent);if(wanted.some(w=>lab===norm(w))){input=b.querySelector('input');break;}}
   return {ok:norm(input?.value)===e,detail:!input?'No se encontró el campo GPON':`Valor GPON: ${input.value||'vacío'}`};
 }
 if(s.target==='fuentes'){
   const cfg=s.mode==='opticos'?{input:'#gs_nodoAlimenta',grid:'#grid-opticos',aria:'grid-opticos_nodoAlimenta',detail:'#detalle-optico-grid-opticos',pane:'#tabpanel-optico-graficos-detalle-opticos'}:s.mode==='rphy'?{input:'#gs_nodoRPHY',grid:'#grid-nodos-rphy',aria:'grid-nodos-rphy_nodoRPHY',detail:'#detalle-nodo-rphy-grid-nodos-rphy'}:{input:'#gs_nodosAlimenta',grid:'#grid-fuentes',aria:'grid-fuentes_nodosAlimenta',detail:'#detalle-fuente-grid-fuentes',pane:'#tabpanel-fuente-graficos-detalle-fuentes'};
   const input=document.querySelector(cfg.input), row=exactRow(cfg.grid,cfg.aria,e), detail=document.querySelector(cfg.detail); const detailOk=!!String(detail?.innerHTML||'').trim();
   let graphOk=true;if(cfg.pane){const pane=document.querySelector(cfg.pane);graphOk=!!pane&&(pane.classList.contains('active')||visible(pane));}
   const ok=norm(input?.value)===e&&!!row&&detailOk&&graphOk;
   return {ok,detail:!input?'Falta input':norm(input.value)!==e?`Filtro actual: ${input.value||'vacío'}`:!row?'No apareció fila exacta':!detailOk?'No cargó el detalle':!graphOk?'No abrió gráficos':'Filtro, fila, detalle y destino OK'};
 }
 if(s.target==='moica'){
   const input=document.querySelector('#TKT-BUSCAR-NODO-autocom'); const inputOk=norm(input?.value)===e;
   const rs=rows('#grid_TktsBuscar');
   const nodeCells=Array.from(document.querySelectorAll('#grid_TktsBuscar tr.jqgrow td[aria-describedby="grid_TktsBuscar_nodoRef"]'));
   const exact=nodeCells.length ? nodeCells.some(td=>String(td.textContent||td.title||'').toUpperCase().split(/[^A-Z0-9]+/).filter(Boolean).includes(e)) : rs.length>0;
   return {ok:inputOk&&rs.length>0&&exact,detail:!inputOk?`Nodo actual: ${input?.value||'vacío'}`:!rs.length?'El jqGrid quedó sin tickets':!exact?'El jqGrid cargó pero no corresponde al nodo esperado':'Nodo seleccionado y jqGrid con tickets asociados'};
 }
 return {ok:false,detail:'Inspector desconocido'};
}
chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{if(msg?.type!=='VIENA_SELFTEST_INSPECT_PAGE')return;try{sendResponse(inspect(msg.spec||{}));}catch(e){sendResponse({ok:false,detail:String(e?.message||e)});}return true;});
})();
