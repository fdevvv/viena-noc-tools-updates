(function () {
    'use strict';

    // ================================================================
    // AVISOS DE DESTINO — LIMPIEZA AL CAMBIAR DE CONTEXTO
    // ================================================================
    // Si un aviso quedó visible y el operador realiza cualquier otra acción
    // (abrir/cerrar un ticket, cambiar de fila, tocar otro botón, etc.),
    // se elimina antes de procesar esa nueva acción. Esto evita que el popup
    // de una vista quede flotando sobre la siguiente. No altera búsquedas,
    // validaciones, Bridge, filtros ni la lógica existente de los botones.
    document.addEventListener('pointerdown', event => {
        if (event.target?.closest?.('.viena-destino-aviso-tabla')) return;
        document.querySelectorAll('.viena-destino-aviso-tabla').forEach(aviso => aviso.remove());
    }, true);

    // ================================================================
    // CONFIG
    // ================================================================

    const MI_USUARIO = String(globalThis.VienaUserConfig?.current || '').trim().toLowerCase();

    const COLUMNAS = {
        estado: 'Estado',
        ticket: 'Ticket evento',
        nodo: 'Nodo',
        edificio: 'ID Edificio',
        tipificacion: 'Tipif. de tarea',
        asignado: 'Asignado a',
        creado: 'Creado',
        acciones: 'Acciones',
        rt: 'RT',
        rtAcumulado: 'cant RTs Acumulados'
    };

    const PALETA_TIPIFICACIONES = [
        '#3B82F6',
        '#8B5CF6',
        '#14B8A6',
        '#F59E0B',
        '#EC4899',
        '#06B6D4',
        '#6366F1',
        '#10B981',
        '#F97316',
        '#64748B'
    ];

    const cacheColores = new Map();

    // Colores de operador en Tareas Internas. El mapa persistido evita que
    // dos operadores distintos terminen con la misma familia cromática.
    // En DEV queda aislado del canal RELEASE.
    const USER_COLOR_MAP_KEY = 'viena_tareas_colores_usuarios_v1__dev';
    const HUES_USUARIO = [
        210, 12, 132, 282, 42, 174, 330, 96,
        252, 24, 192, 306, 60, 150, 228, 348,
        114, 270, 6, 162, 318, 78, 240, 36
    ];
    let mapaColoresUsuario = {};
    let mapaColoresUsuarioCargado = false;

    chrome.storage.local.get([USER_COLOR_MAP_KEY]).then(r => {
        const saved = r?.[USER_COLOR_MAP_KEY];
        mapaColoresUsuario = saved && typeof saved === 'object' ? { ...saved } : {};
        mapaColoresUsuarioCargado = true;
        reaplicarUI(false);
    }).catch(() => {
        mapaColoresUsuarioCargado = true;
    });

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local' || !changes[USER_COLOR_MAP_KEY]) return;
        const next = changes[USER_COLOR_MAP_KEY].newValue;
        if (next && typeof next === 'object') mapaColoresUsuario = { ...next };
    });


    // ================================================================
    // CSS
    // ================================================================

    const style = document.createElement('style');
    style.id = 'viena-corporate-ui-2026';

    style.textContent = `

        /* ============================================================
           CONTENEDOR
           ============================================================ */

        .viena-corporate-table {
            border: 1px solid #e2e8f0 !important;
            border-radius: 10px !important;
            overflow: hidden !important;

            box-shadow:
                0 1px 2px rgba(15, 23, 42, .04),
                0 4px 12px rgba(15, 23, 42, .04)
                !important;

            background: #ffffff !important;
        }

        .viena-corporate-table.elevation-4 {
            box-shadow:
                0 1px 2px rgba(15, 23, 42, .04),
                0 4px 12px rgba(15, 23, 42, .04)
                !important;
        }


        /* ============================================================
           TOOLBAR
           ============================================================ */

        .viena-corporate-table > header.v-toolbar {
            background: #ffffff !important;
            border-bottom: 1px solid #e8edf3 !important;
        }

        .viena-corporate-table .v-toolbar__title {
            color: #0f172a !important;
            font-weight: 650 !important;
            letter-spacing: -0.2px !important;
        }


        /* ============================================================
           HEADER
           ============================================================ */

        .viena-corporate-table thead {
            background: #f8fafc !important;
        }

        .viena-corporate-table thead th {
            background: #f8fafc !important;
            color: #64748b !important;

            font-size: 12px !important;
            font-weight: 700 !important;

            letter-spacing: .025em !important;

            border-bottom:
                1px solid #dfe6ee !important;

            height: 40px !important;
        }

        .viena-corporate-table
        .v-data-table-header__icon {
            color: #94a3b8 !important;
            opacity: .75 !important;
        }


        /* ============================================================
           FILAS
           ============================================================ */

        .viena-corporate-table tbody tr {
            position: relative;

            background: #ffffff;

            transition:
                background-color .12s ease,
                box-shadow .12s ease !important;
        }

        .viena-corporate-table tbody tr:hover {
            background: #f8fbff !important;
        }

        .viena-corporate-table tbody td {
            height: 48px !important;

            border-bottom:
                1px solid #edf1f5 !important;

            color: #334155 !important;

            font-size: 13.5px !important;

            vertical-align: middle !important;
        }

        .viena-corporate-table tbody tr:last-child td {
            border-bottom: none !important;
        }


        /* ============================================================
           MIS TICKETS
           ============================================================ */

        .viena-corporate-table
        tbody tr.viena-mio {
            background: #f8fbff !important;
        }

        .viena-corporate-table
        tbody tr.viena-mio:hover {
            background: #f1f7ff !important;
        }

        .viena-corporate-table
        tbody tr.viena-mio
        td:first-child {
            box-shadow:
                inset 4px 0 0 #1976d2 !important;
        }


        /* ============================================================
           BADGES
           ============================================================ */

        .viena-status-badge,
        .viena-user-badge {
            display: inline-flex;

            align-items: center;
            justify-content: center;

            gap: 6px;

            min-height: 27px;

            padding: 4px 11px;

            border-radius: 999px;

            font-size: 12px;

            font-weight: 700;

            line-height: 1;

            white-space: nowrap;

            box-sizing: border-box;
        }


        /* ============================================================
           ESTADOS
           ============================================================ */

        .viena-status-badge::before {
            content: '';

            width: 6px;
            height: 6px;

            border-radius: 50%;

            background: currentColor;

            opacity: .85;
        }

        .viena-status-iniciada {
            color: #047857;
            background: #ecfdf5;
            border: 1px solid #a7f3d0;
        }

        .viena-status-asignada {
            color: #475569;
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
        }

        .viena-status-pendiente {
            color: #b45309;
            background: #fffbeb;
            border: 1px solid #fde68a;
        }

        .viena-status-completada {
            color: #0369a1;
            background: #f0f9ff;
            border: 1px solid #bae6fd;
        }

        .viena-status-cancelada {
            color: #64748b;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
        }

        .viena-status-default {
            color: #475569;
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
        }


        /* ============================================================
           TIPIFICACIÓN
           ============================================================ */

        .viena-tipificacion {
            position: relative;

            display: inline-flex;
            align-items: center;

            min-height: 28px;

            padding:
                4px 10px
                4px 13px;

            border-radius: 5px;

            background: #f8fafc;

            color: #334155;

            font-weight: 500;
            font-size: 13px !important;

            text-align: left;

            line-height: 1.3;

            box-sizing: border-box;
        }

        .viena-tipificacion::before {
            content: '';

            position: absolute;

            left: 0;

            top: 4px;
            bottom: 4px;

            width: 4px;

            border-radius: 4px;

            background:
                var(--viena-tip-color);
        }


        /* ============================================================
           USUARIOS
           ============================================================ */

        .viena-user-badge {
            font-size: 12.5px !important;
        }

        .viena-user-mio {
            color: var(--viena-user-fg, #075ea8);
            background: var(--viena-user-bg, #eaf4ff);
            border: 1px solid var(--viena-user-border, #bfdbfe);
        }

        .viena-user-mio::before {
            content: '★';
            font-size: 10px;
        }

        .viena-user-otro {
            color: var(--viena-user-fg, #475569);
            background: var(--viena-user-bg, #f8fafc);
            border: 1px solid var(--viena-user-border, #e2e8f0);
            font-weight: 600;
        }

        .viena-user-libre {
            color: #a16207;
            background: #fffbeb;
            border: 1px solid #fde68a;
        }

        .viena-user-libre::before {
            content: '○';
            font-size: 12px;
        }


        /* ============================================================
           TICKET / NODO / EDIFICIO
           ============================================================ */

        .viena-ticket {
            color: #334155 !important;
            font-weight: 600 !important;
            font-size: 13px !important;
        }

        .viena-nodo {
            color: #475569 !important;
            font-weight: 600 !important;
            font-size: 13px !important;
        }

        .viena-edificio {
            color: #475569 !important;
            font-weight: 500 !important;
            font-size: 13px !important;
        }


        /* ============================================================
           VALORES COPIABLES
           ============================================================ */

        .viena-copy-value {
            display: inline-flex;
            align-items: center;

            gap: 5px;

            white-space: nowrap;
        }


        /* ============================================================
           BOTÓN COPIAR DE LA TABLA
           ============================================================ */

        .viena-table-copy {
            width: 34px !important;
            height: 34px !important;
            min-width: 34px !important;

            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;

            padding: 0 !important;
            margin: 0 !important;

            border: 1px solid #e2e8f0 !important;
            border-radius: 8px !important;

            background: #f8fafc !important;

            color: #94a3b8 !important;

            cursor: pointer !important;

            opacity: .92;

            outline: none !important;

            vertical-align: middle !important;

            transition:
                color .14s ease,
                background-color .14s ease,
                border-color .14s ease,
                opacity .14s ease,
                transform .1s ease
                !important;
        }

        .viena-table-copy .mdi {
            font-size: 21px !important;
            line-height: 1 !important;

            color: inherit !important;

            pointer-events: none !important;
        }


        /* El botón gana presencia cuando estamos sobre el dato */

        .viena-copy-value:hover
        .viena-table-copy {
            opacity: 1;

            color: #1976d2 !important;

            background: #eaf4ff !important;

            border-color: #dbeafe !important;
        }


        /* Hover directo */

        .viena-table-copy:hover {
            opacity: 1 !important;

            color: #1565c0 !important;

            background: #e3f0fc !important;

            border-color: #bfdbfe !important;
        }


        /* Click */

        .viena-table-copy:active {
            transform: scale(.88) !important;
        }


        /* Copiado */

        .viena-table-copy.viena-copy-ok {
            opacity: 1 !important;

            color: #059669 !important;

            background: #ecfdf5 !important;

            border-color: #a7f3d0 !important;
        }


        /* Error */

        .viena-table-copy.viena-copy-error {
            opacity: 1 !important;

            color: #dc2626 !important;

            background: #fef2f2 !important;

            border-color: #fecaca !important;
        }


        /* ============================================================
           FECHA
           ============================================================ */

        .viena-created {
            color: #64748b !important;
            font-size: 12px !important;
        }


        /* ============================================================
           ACCIONES
           ============================================================ */

        .viena-corporate-table
        td.viena-actions-cell
        button.v-icon {
            width: 30px !important;
            height: 30px !important;

            border-radius: 7px !important;

            margin-right: 3px !important;

            transition:
                background-color .12s ease,
                transform .12s ease !important;
        }

        .viena-corporate-table
        td.viena-actions-cell
        button.v-icon:hover {
            background: #eaf4ff !important;
        }


        /* ============================================================
           RT
           ============================================================ */

        .viena-corporate-table
        .viena-rt-zero .v-chip {
            background: #f1f5f9 !important;

            color: #94a3b8 !important;

            font-weight: 600 !important;
            font-size: 12px !important;

            box-shadow: none !important;
        }

        .viena-corporate-table
        .viena-rt-active .v-chip {
            background: #fff7ed !important;

            color: #c2410c !important;

            border:
                1px solid #fed7aa !important;

            font-weight: 700 !important;
            font-size: 12px !important;

            box-shadow: none !important;
        }


        /* ============================================================
           FOOTER
           ============================================================ */

        .viena-corporate-table
        .v-data-footer {
            border-top:
                1px solid #e8edf3 !important;

            background:
                #fafbfc !important;

            color:
                #64748b !important;

            font-size: 12px !important;
        }


        /* ============================================================
           CHECKBOX
           ============================================================ */

        .viena-corporate-table
        .v-simple-checkbox
        .v-icon {
            font-size: 20px !important;
        }

    `;

    document.head.appendChild(style);


    // ================================================================
    // ICONOS
    // ================================================================

    const ICONO_COPIAR =
        '<i class="mdi mdi-content-copy" aria-hidden="true"></i>';

    const ICONO_OK =
        '<i class="mdi mdi-check" aria-hidden="true"></i>';

    const ICONO_ERROR =
        '<i class="mdi mdi-alert-circle-outline" aria-hidden="true"></i>';


    // ================================================================
    // HELPERS
    // ================================================================

    function normalizar(texto) {
        return String(texto || '')
            .trim()
            .toLowerCase();
    }


    function hashString(str) {
        let hash = 0;

        for (let i = 0; i < str.length; i++) {
            hash =
                (hash << 5) -
                hash +
                str.charCodeAt(i);

            hash |= 0;
        }

        return Math.abs(hash);
    }


    function colorTipificacion(texto) {
        const clave =
            String(texto || '').trim();

        if (!clave) {
            return '#64748B';
        }

        if (cacheColores.has(clave)) {
            return cacheColores.get(clave);
        }

        const indice =
            hashString(
                'VIENA_' + clave
            ) %
            PALETA_TIPIFICACIONES.length;

        const color =
            PALETA_TIPIFICACIONES[indice];

        cacheColores.set(
            clave,
            color
        );

        return color;
    }


    function hashUsuario(texto) {
        // FNV-1a + avalanche. El hash anterior (tipo Java) dejaba usernames
        // distintos pero parecidos en tonos casi iguales (efoschi=173°,
        // learguello=180°). Esta mezcla distribuye mucho mejor los usernames.
        let h = 0x811c9dc5;
        const str = 'VIENA_USER_' + String(texto || '');
        for (let i = 0; i < str.length; i++) {
            h ^= str.charCodeAt(i);
            h = Math.imul(h, 0x01000193);
        }
        h ^= h >>> 16;
        h = Math.imul(h, 0x7feb352d);
        h ^= h >>> 15;
        h = Math.imul(h, 0x846ca68b);
        h ^= h >>> 16;
        return h >>> 0;
    }

    function guardarMapaColoresUsuario() {
        if (!mapaColoresUsuarioCargado) return;
        chrome.storage.local.set({ [USER_COLOR_MAP_KEY]: mapaColoresUsuario }).catch(() => {});
    }

    function colorUsuario(texto) {
        const clave = normalizar(texto);
        if (!clave || esNoAsignada(clave)) return null;

        const hash = hashUsuario(clave);
        let indice = Number(mapaColoresUsuario[clave]);

        if (!(Number.isInteger(indice) && indice >= 0 && indice < HUES_USUARIO.length)) {
            const inicial = hash % HUES_USUARIO.length;

            // Antes de cargar storage no escribimos nada; apenas termina la carga,
            // reaplicarUI() asigna un índice libre y estable.
            if (!mapaColoresUsuarioCargado) {
                indice = inicial;
            } else {
                const usados = new Set(
                    Object.entries(mapaColoresUsuario)
                        .filter(([otro]) => otro !== clave)
                        .map(([, value]) => Number(value))
                        .filter(value => Number.isInteger(value) && value >= 0 && value < HUES_USUARIO.length)
                );

                indice = inicial;
                for (let paso = 0; paso < HUES_USUARIO.length; paso++) {
                    const candidato = (inicial + paso) % HUES_USUARIO.length;
                    if (!usados.has(candidato)) {
                        indice = candidato;
                        break;
                    }
                }

                mapaColoresUsuario[clave] = indice;
                guardarMapaColoresUsuario();
            }
        }

        const hue = HUES_USUARIO[indice];
        const sat = 76 + ((indice % 3) * 2);
        const bgLight = 89 + (indice % 2);
        return {
            fg: `hsl(${hue} ${Math.max(56, sat - 14)}% 25%)`,
            bg: `hsl(${hue} ${sat}% ${bgLight}%)`,
            border: `hsl(${hue} ${Math.max(52, sat - 18)}% 68%)`
        };
    }


    function esNoAsignada(texto) {
        const valor =
            normalizar(texto);

        return (
            valor === '' ||
            valor === 'no asignada' ||
            valor === 'no asignado' ||
            valor === 'sin asignar'
        );
    }


    // ================================================================
    // CLIPBOARD
    // ================================================================

    async function copiarAlPortapapeles(texto) {
        if (!texto) {
            return false;
        }

        try {
            if (
                navigator.clipboard &&
                window.isSecureContext
            ) {
                await navigator.clipboard.writeText(
                    texto
                );

                return true;
            }
        } catch (error) {
            console.warn(
                '[VIENA Corporate UI] Clipboard API bloqueada.',
                error
            );
        }


        // Fallback

        const textarea =
            document.createElement('textarea');

        textarea.value = texto;

        textarea.setAttribute(
            'readonly',
            ''
        );

        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        textarea.style.top = '-9999px';
        textarea.style.opacity = '0';

        document.body.appendChild(
            textarea
        );

        textarea.focus();
        textarea.select();

        let resultado = false;

        try {
            resultado =
                document.execCommand(
                    'copy'
                );
        } catch (error) {
            console.error(
                '[VIENA Corporate UI] Error copiando:',
                error
            );
        }

        textarea.remove();

        return resultado;
    }


    // ================================================================
    // FEEDBACK BOTÓN COPIAR
    // ================================================================

    function feedbackCopiado(boton) {
        clearTimeout(
            boton.__vienaTimer
        );

        boton.classList.remove(
            'viena-copy-error'
        );

        boton.classList.add(
            'viena-copy-ok'
        );

        boton.innerHTML =
            ICONO_OK;

        boton.title =
            'Copiado';

        boton.__vienaTimer =
            setTimeout(() => {

                boton.classList.remove(
                    'viena-copy-ok'
                );

                boton.innerHTML =
                    ICONO_COPIAR;

                boton.title =
                    'Copiar';

            }, 1000);
    }


    function feedbackError(boton) {
        clearTimeout(
            boton.__vienaTimer
        );

        boton.classList.remove(
            'viena-copy-ok'
        );

        boton.classList.add(
            'viena-copy-error'
        );

        boton.innerHTML =
            ICONO_ERROR;

        boton.title =
            'No se pudo copiar';

        boton.__vienaTimer =
            setTimeout(() => {

                boton.classList.remove(
                    'viena-copy-error'
                );

                boton.innerHTML =
                    ICONO_COPIAR;

                boton.title =
                    'Copiar';

            }, 1200);
    }


    // ================================================================
    // ENCONTRAR TABLA
    // ================================================================

    function encontrarTabla() {
        const tablas =
            document.querySelectorAll(
                '.v-data-table'
            );

        for (const contenedor of tablas) {
            const headers =
                Array.from(
                    contenedor.querySelectorAll(
                        'thead th span'
                    )
                )
                .map(
                    el =>
                        el.textContent.trim()
                );

            if (
                headers.includes(COLUMNAS.estado) &&
                headers.includes(COLUMNAS.ticket) &&
                headers.includes(COLUMNAS.tipificacion) &&
                headers.includes(COLUMNAS.asignado)
            ) {
                return contenedor;
            }
        }

        return null;
    }


    function obtenerIndices(tabla) {
        const resultado = {};

        const headers =
            Array.from(
                tabla.querySelectorAll(
                    'thead th'
                )
            );

        headers.forEach(
            (th, index) => {

                const texto =
                    th.querySelector('span')
                        ?.textContent
                        ?.trim();

                if (!texto) {
                    return;
                }

                for (
                    const [clave, nombre]
                    of Object.entries(COLUMNAS)
                ) {
                    if (texto === nombre) {
                        resultado[clave] =
                            index;
                    }
                }
            }
        );

        return resultado;
    }


    // ================================================================
    // WRAPPER NORMAL
    // ================================================================

    function envolverTexto(
        celda,
        clase,
        texto
    ) {
        let wrapper =
            celda.querySelector(
                ':scope > .viena-ui-wrapper'
            );

        if (!wrapper) {
            celda.textContent = '';

            wrapper =
                document.createElement(
                    'span'
                );

            wrapper.className =
                'viena-ui-wrapper';

            celda.appendChild(
                wrapper
            );
        }

        const claseEsperada =
            `viena-ui-wrapper ${clase}`;

        const textoEsperado =
            String(texto || '').trim();

        // v2.6.1 — No reconstruir un wrapper que ya está correcto.
        // Esto conserva la selección de texto del usuario mientras
        // MutationObserver/Vuetify realizan pasadas de actualización.
        if (wrapper.className !== claseEsperada) {
            wrapper.className = claseEsperada;
        }

        if (wrapper.textContent !== textoEsperado) {
            wrapper.textContent = textoEsperado;
        }

        return wrapper;
    }


    // ================================================================
    // BRIDGE: DETECTAR HFC / FTTH DESDE LA TIPIFICACIÓN
    // ================================================================

    function tecnologiaDesdeFila(fila) {
        const tipificacion =
            String(fila?.dataset?.vienaTipificacion || '')
                .trim()
                .toUpperCase();

        if (tipificacion.includes('FTTH')) {
            return 'FTTH';
        }

        if (tipificacion.includes('HFC')) {
            return 'HFC';
        }

        return '';
    }

    // ================================================================
    // AVISO DE DESTINO — MISMO COMPORTAMIENTO QUE LOS BOTONES DEL TICKET
    // ================================================================

    function cerrarAvisoDestinoTabla() {
        document.querySelectorAll('.viena-destino-aviso-tabla').forEach(el => el.remove());
    }

    function avisoDestinoTabla(boton, mensaje) {
        cerrarAvisoDestinoTabla();

        if (!boton || !document.documentElement.contains(boton)) return;

        const aviso = document.createElement('div');
        aviso.className = 'viena-destino-aviso-tabla';
        aviso.setAttribute('role', 'alert');
        aviso.title = 'Click para cerrar';
        aviso.textContent = mensaje;

        Object.assign(aviso.style, {
            position: 'fixed',
            zIndex: '2147483647',
            maxWidth: '390px',
            padding: '10px 13px',
            borderRadius: '7px',
            border: '1px solid rgba(255,255,255,.28)',
            background: '#b42318',
            color: '#fff',
            font: '600 13px/1.35 system-ui, -apple-system, "Segoe UI", sans-serif',
            boxShadow: '0 5px 16px rgba(0,0,0,.24)',
            cursor: 'pointer',
            userSelect: 'none',
            margin: '0',
            transform: 'none',
            scale: '1',
            zoom: '1'
        });

        document.body.appendChild(aviso);

        const posicionar = () => {
            if (!document.documentElement.contains(aviso) ||
                !document.documentElement.contains(boton)) {
                aviso.remove();
                return;
            }

            const r = boton.getBoundingClientRect();
            const a = aviso.getBoundingClientRect();

            let left = r.left + (r.width / 2) - (a.width / 2);
            left = Math.max(8, Math.min(left, window.innerWidth - a.width - 8));

            let top = r.top - a.height - 9;
            if (top < 8) top = r.bottom + 9;

            aviso.style.left = `${Math.round(left)}px`;
            aviso.style.top = `${Math.round(top)}px`;
        };

        posicionar();

        const cerrar = event => {
            event.preventDefault();
            event.stopPropagation();
            aviso.remove();
        };

        aviso.addEventListener('mousedown', cerrar);
        aviso.addEventListener('click', cerrar);

        const reposicionar = () => {
            if (document.documentElement.contains(aviso)) posicionar();
        };

        window.addEventListener('resize', reposicionar, { passive: true });
        window.addEventListener('scroll', reposicionar, { passive: true, capture: true });

        setTimeout(() => {
            window.removeEventListener('resize', reposicionar);
            window.removeEventListener('scroll', reposicionar, true);
            aviso.remove();
        }, 6500);
    }

    function nombreDestinoTabla(tipo, tecnologia) {
        if (tecnologia === 'FTTH') return 'GPON';
        if (tipo === 'edificio') return 'MIRA 5 Cable Modem';
        return 'MIRA 5 Estadísticas';
    }

    async function buscarConBridge(fila, tipo, valor, botonAviso = null) {
        const tecnologia = tecnologiaDesdeFila(fila);

        if (!tecnologia) {
            console.warn(
                '[VIENA Corporate UI] No se pudo determinar HFC/FTTH:',
                fila?.dataset?.vienaTipificacion
            );
            return false;
        }

        const bridge = window.VienaNocBridge;
        const destino = nombreDestinoTabla(tipo, tecnologia);

        if (!bridge || typeof bridge.buscar !== 'function') {
            console.error(
                '[VIENA Corporate UI] VienaNocBridge no está disponible'
            );

            avisoDestinoTabla(
                botonAviso,
                `${destino} no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.`
            );
            return false;
        }

        // Validación instantánea mediante el mismo Bridge estable v1.0.13.
        // No modifica filtros, colas ni búsquedas existentes.
        if (typeof bridge.disponible === 'function') {
            let disponible = false;

            try {
                disponible = await bridge.disponible(tipo, tecnologia);
            } catch (_) {
                disponible = false;
            }

            if (!disponible) {
                avisoDestinoTabla(
                    botonAviso,
                    `${destino} no está disponible. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.`
                );
                return false;
            }
        }

        // Limpieza total de espacios antes de enviar.
        const limpio = String(valor || '').replace(/\s+/g, '');

        if (!limpio) {
            return false;
        }

        await bridge.buscar(tipo, tecnologia, limpio);

        console.log(
            `[VIENA Corporate UI] Búsqueda enviada → ${tipo} / ${tecnologia}:`,
            limpio
        );

        return true;
    }


    // ================================================================
    // WRAPPER COPIABLE
    // ================================================================

    function convertirEnCopiable(
        celda,
        valor,
        tipo
    ) {
        if (!celda) {
            return;
        }

        valor =
            String(valor || '').replace(/\s+/g, '');


        /*
         * Si está vacío, no mostramos un botón inútil.
         */

        if (!valor) {
            celda.textContent = '';
            return;
        }


        let wrapper =
            celda.querySelector(
                ':scope > .viena-copy-value'
            );


        if (!wrapper) {
            celda.textContent = '';

            wrapper =
                document.createElement(
                    'span'
                );

            wrapper.className =
                'viena-copy-value';


            const texto =
                document.createElement(
                    'span'
                );

            texto.className =
                'viena-copy-text';


            const boton =
                document.createElement(
                    'button'
                );

            boton.type =
                'button';

            boton.className =
                'viena-table-copy';

            boton.innerHTML =
                ICONO_COPIAR;


            boton.addEventListener(
                'mousedown',
                event => {
                    event.preventDefault();
                    event.stopPropagation();
                }
            );


            boton.addEventListener(
                'click',
                async event => {

                    event.preventDefault();
                    event.stopPropagation();


                    /*
                     * Leemos del wrapper, no de una variable vieja.
                     * Esto hace que siga funcionando si Vuetify
                     * reutiliza/modifica la fila.
                     */

                    const actual =
                        wrapper.dataset.copyValue ||
                        '';


                    if (!actual) {
                        return;
                    }


                    try {
                        const ok =
                            await copiarAlPortapapeles(
                                actual
                            );

                        if (ok) {
                            // FIX-FEATURE-001: este botón es exclusivamente COPY.
                            // No debe navegar ni emitir acciones al bridge/destinos.
                            feedbackCopiado(
                                boton
                            );
                        } else {
                            feedbackError(
                                boton
                            );
                        }

                    } catch (error) {
                        feedbackError(
                            boton
                        );

                        console.error(
                            '[VIENA Corporate UI]',
                            error
                        );
                    }
                }
            );


            wrapper.appendChild(
                texto
            );

            wrapper.appendChild(
                boton
            );

            celda.appendChild(
                wrapper
            );
        }


        const texto =
            wrapper.querySelector(
                '.viena-copy-text'
            );

        const boton =
            wrapper.querySelector(
                '.viena-table-copy'
            );


        wrapper.dataset.copyValue =
            valor;


        if (texto) {
            texto.textContent =
                valor;
        }


        if (boton) {
            boton.title =
                `Copiar ${tipo}`;

            boton.setAttribute(
                'aria-label',
                `Copiar ${tipo}`
            );
        }
    }


    // ================================================================
    // ESTADOS
    // ================================================================

    function claseEstado(estado) {
        const e =
            normalizar(estado);

        if (e === 'iniciada') {
            return 'viena-status-iniciada';
        }

        if (e === 'asignada') {
            return 'viena-status-asignada';
        }

        if (
            e.includes('pendiente')
        ) {
            return 'viena-status-pendiente';
        }

        if (e === 'completada') {
            return 'viena-status-completada';
        }

        if (e === 'cancelada') {
            return 'viena-status-cancelada';
        }

        return 'viena-status-default';
    }


    // ================================================================
    // RT
    // ================================================================

    function estilizarRT(celda) {
        if (!celda) {
            return;
        }

        const valor =
            parseInt(
                celda.textContent.trim(),
                10
            ) || 0;

        celda.classList.remove(
            'viena-rt-zero',
            'viena-rt-active'
        );

        celda.classList.add(
            valor > 0
                ? 'viena-rt-active'
                : 'viena-rt-zero'
        );
    }


    // ================================================================
    // PROCESAR FILA
    // ================================================================

    function procesarFila(
        fila,
        idx
    ) {
        const celdas =
            fila.children;

        const celdaEstado =
            celdas[idx.estado];

        const celdaTicket =
            celdas[idx.ticket];

        const celdaNodo =
            celdas[idx.nodo];

        const celdaEdificio =
            idx.edificio !== undefined
                ? celdas[idx.edificio]
                : null;

        const celdaTipificacion =
            celdas[idx.tipificacion];

        const celdaAsignado =
            celdas[idx.asignado];

        const celdaCreado =
            celdas[idx.creado];

        const celdaAcciones =
            celdas[idx.acciones];

        const celdaRT =
            celdas[idx.rt];

        const celdaRTAcumulado =
            celdas[idx.rtAcumulado];


        if (
            !celdaEstado ||
            !celdaTipificacion ||
            !celdaAsignado
        ) {
            return;
        }


        // ============================================================
        // VALORES ORIGINALES
        // ============================================================

        const estado =
            fila.dataset.vienaEstado ??
            celdaEstado.textContent.trim();

        const tipificacion =
            fila.dataset.vienaTipificacion ??
            celdaTipificacion.textContent.trim();

        const usuario =
            fila.dataset.vienaUsuario ??
            celdaAsignado.textContent.trim();

        const nodo =
            fila.dataset.vienaNodo ??
            (
                celdaNodo
                    ? celdaNodo.textContent.trim()
                    : ''
            );

        const edificio =
            fila.dataset.vienaEdificio ??
            (
                celdaEdificio
                    ? celdaEdificio.textContent.trim()
                    : ''
            );


        fila.dataset.vienaEstado =
            estado;

        fila.dataset.vienaTipificacion =
            tipificacion;

        fila.dataset.vienaUsuario =
            usuario;

        fila.dataset.vienaNodo =
            nodo;

        fila.dataset.vienaEdificio =
            edificio;


        const esMio =
            normalizar(usuario) ===
            normalizar(MI_USUARIO);


        // ============================================================
        // FILA MÍA
        // ============================================================

        fila.classList.toggle(
            'viena-mio',
            esMio
        );


        // ============================================================
        // ESTADO
        // ============================================================

        envolverTexto(
            celdaEstado,
            `viena-status-badge ${claseEstado(estado)}`,
            estado
        );


        // ============================================================
        // TIPIFICACIÓN
        // ============================================================

        const tip =
            envolverTexto(
                celdaTipificacion,
                'viena-tipificacion',
                tipificacion
            );

        tip.style.setProperty(
            '--viena-tip-color',
            colorTipificacion(
                tipificacion
            )
        );


        // ============================================================
        // ASIGNADO
        // ============================================================

        let claseUsuario;

        if (esMio) {
            claseUsuario =
                'viena-user-badge viena-user-mio';

        } else if (
            esNoAsignada(usuario)
        ) {
            claseUsuario =
                'viena-user-badge viena-user-libre';

        } else {
            claseUsuario =
                'viena-user-badge viena-user-otro';
        }


        const badgeUsuario = envolverTexto(
            celdaAsignado,
            claseUsuario,
            usuario || 'Sin asignar'
        );

        // Los usuarios asignados tienen un color estable derivado de su username.
        // `esMio` sólo agrega la estrella; nunca cambia el color del operador.
        const paletaUsuario = colorUsuario(usuario);
        if (badgeUsuario && paletaUsuario) {
            badgeUsuario.style.setProperty('--viena-user-fg', paletaUsuario.fg);
            badgeUsuario.style.setProperty('--viena-user-bg', paletaUsuario.bg);
            badgeUsuario.style.setProperty('--viena-user-border', paletaUsuario.border);
        }


        // ============================================================
        // TICKET
        // ============================================================

        if (celdaTicket) {
            celdaTicket.classList.add(
                'viena-ticket'
            );
        }


        // ============================================================
        // NODO + COPIAR
        // ============================================================

        if (celdaNodo) {
            celdaNodo.classList.add(
                'viena-nodo'
            );

            convertirEnCopiable(
                celdaNodo,
                nodo,
                'Nodo'
            );
        }


        // ============================================================
        // ID EDIFICIO + COPIAR
        // ============================================================

        if (celdaEdificio) {
            celdaEdificio.classList.add(
                'viena-edificio'
            );

            convertirEnCopiable(
                celdaEdificio,
                edificio,
                'ID Edificio'
            );
        }


        // ============================================================
        // CREADO
        // ============================================================

        if (celdaCreado) {
            celdaCreado.classList.add(
                'viena-created'
            );
        }


        // ============================================================
        // ACCIONES
        // ============================================================

        if (celdaAcciones) {
            celdaAcciones.classList.add(
                'viena-actions-cell'
            );
        }


        // ============================================================
        // RT
        // ============================================================

        estilizarRT(
            celdaRT
        );

        estilizarRT(
            celdaRTAcumulado
        );
    }


    // ================================================================
    // APLICAR UI
    // ================================================================

    function aplicarUI() {
        const contenedor =
            encontrarTabla();

        if (!contenedor) {
            return;
        }


        contenedor.classList.add(
            'viena-corporate-table'
        );


        const tabla =
            contenedor.querySelector(
                'table'
            );

        if (!tabla) {
            return;
        }


        const idx =
            obtenerIndices(
                tabla
            );


        if (
            idx.estado === undefined ||
            idx.tipificacion === undefined ||
            idx.asignado === undefined
        ) {
            return;
        }


        tabla
            .querySelectorAll(
                'tbody tr'
            )
            .forEach(
                fila =>
                    procesarFila(
                        fila,
                        idx
                    )
            );

        // Inicialización de orden. La función se autolimita a una sola vez
        // por instancia de tabla, por lo que no interfiere con clicks manuales.
        aplicarOrdenInicialCreado();
    }


    // ================================================================
    // ORDEN INICIAL DE "CREADO" — MÁS VIEJO → MÁS NUEVO
    // ================================================================
    // Solo se fuerza al aparecer una NUEVA instancia de la tabla.
    // Después, si el usuario toca "Creado", el orden queda manual y
    // este script NO vuelve a cambiarlo en esa misma tabla.
    const tablasConOrdenCreadoInicial = new WeakSet();
    const intentosOrdenCreado = new WeakMap();

    function aplicarOrdenInicialCreado() {
        const contenedor = encontrarTabla();

        if (!contenedor) return;

        const tabla = contenedor.querySelector('table');

        if (!tabla || tablasConOrdenCreadoInicial.has(tabla)) return;

        const thCreado = Array.from(
            tabla.querySelectorAll('thead th')
        ).find(th =>
            th.querySelector('span')?.textContent?.trim() === COLUMNAS.creado
        );

        if (!thCreado) return;

        // Esperamos a que Vuetify haya inicializado realmente el header.
        if (!thCreado.classList.contains('sortable')) return;

        const ariaSort = String(
            thCreado.getAttribute('aria-sort') || ''
        ).toLowerCase();

        const esAscendente =
            ariaSort === 'ascending' ||
            (
                thCreado.classList.contains('active') &&
                thCreado.classList.contains('asc')
            );

        // Ascendente = fecha más vieja arriba / más nueva abajo.
        // Sólo marcamos la tabla como inicializada DESPUÉS de comprobar el resultado.
        // En F5 Vuetify puede mostrar el header antes de que su handler de sort quede listo.
        if (esAscendente) {
            tablasConOrdenCreadoInicial.add(tabla);
            return;
        }

        const intentos = intentosOrdenCreado.get(tabla) || 0;
        if (intentos >= 10) return;
        intentosOrdenCreado.set(tabla, intentos + 1);
        thCreado.click();

        // Verificación corta: si el primer click ocurrió durante hidratación, reintenta.
        setTimeout(() => aplicarOrdenInicialCreado(), 35);
    }


    // ================================================================
    // INICIO / VUETIFY / SPA - REAPLICACIÓN ROBUSTA
    // ================================================================

    let timer = null;
    let ultimoHref = location.href;

    let uiRaf = 0;
    let uiRefuerzo = 0;

    function reaplicarUI(reforzar = false) {
        clearTimeout(timer);
        if (!uiRaf) {
            uiRaf = requestAnimationFrame(() => {
                uiRaf = 0;
                aplicarUI();
            });
        }
        // Sólo las transiciones SPA necesitan un segundo pase. No lanzar cuatro
        // recorridos completos del DOM por cada mutación de Vue/Vuetify.
        if (reforzar) {
            clearTimeout(uiRefuerzo);
            uiRefuerzo = setTimeout(aplicarUI, 180);
        }
    }

    // Aplicación inicial + enganches de primera carga. En F5 VIENA hidrata Vuetify
    // por etapas; cada evento sólo pide una pasada idempotente y el observer termina
    // de reaccionar apenas aparece/reemplaza la tabla.
    reaplicarUI();
    document.addEventListener('DOMContentLoaded', () => reaplicarUI(true), { once: true });
    window.addEventListener('load', () => reaplicarUI(true), { once: true });
    window.addEventListener('pageshow', () => reaplicarUI(true), { once: true });


    // ================================================================
    // MUTATION OBSERVER
    // ================================================================

    const observer =
        new MutationObserver(mutations => {

            // Nos interesa especialmente cuando Vue agrega/reemplaza nodos.
            const huboCambioEstructural =
                mutations.some(m =>
                    m.type === 'childList' &&
                    (m.addedNodes.length || m.removedNodes.length)
                );

            if (!huboCambioEstructural) {
                return;
            }

            clearTimeout(timer);

            // v2.6.1 — Si el usuario está seleccionando texto dentro de la
            // tabla, no tocar su DOM hasta que termine la selección.
            const seleccion = window.getSelection();
            const nodoSeleccion =
                seleccion && !seleccion.isCollapsed
                    ? seleccion.anchorNode
                    : null;
            const elementoSeleccion =
                nodoSeleccion?.nodeType === Node.ELEMENT_NODE
                    ? nodoSeleccion
                    : nodoSeleccion?.parentElement;

            if (elementoSeleccion?.closest?.('.viena-corporate-table')) {
                timer = setTimeout(() => reaplicarUI(false), 180);
                return;
            }

            timer = setTimeout(() => reaplicarUI(false), 20);
        });


    observer.observe(
        document.body,
        {
            childList: true,
            subtree: true
        }
    );


    // ================================================================
    // NAVEGACIÓN SPA / VOLVER DEL OJO
    // ================================================================

    function comprobarNavegacion() {
        if (location.href !== ultimoHref) {
            ultimoHref = location.href;
            reaplicarUI(true);
        }
    }

    window.addEventListener('popstate', () => {
        setTimeout(() => reaplicarUI(true), 0);
    });

    window.addEventListener('hashchange', () => {
        setTimeout(() => reaplicarUI(true), 0);
    });

    // VIENA puede cambiar la vista sin disparar popstate/hashchange.
    // Este chequeo liviano detecta el regreso a Tareas Internas.
    setInterval(() => {
        comprobarNavegacion();

        // Si la tabla existe pero perdió la clase porque Vue la reemplazó,
        // la restauramos inmediatamente.
        const tabla = encontrarTabla();

        if (
            tabla &&
            !tabla.classList.contains('viena-corporate-table')
        ) {
            reaplicarUI(false);
        }
    }, 300);

})();