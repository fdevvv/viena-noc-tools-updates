'use strict';

(() => {
  const DB_NAME = 'viena-noc-tools-local-updater';
  const DB_VERSION = 1;
  const STORE_NAME = 'handles';
  const HANDLE_KEY = 'installation-directory-v1';
  const APP_PREFIX = 'VIENA NOC Tools';
  const META_KEY = 'viena_local_install_folder_meta_v1';
  const UPDATER_CONTRACT_VERSION = 2;
  const UPDATE_LOCK_KEY = 'viena_local_update_lock_v1';
  const UPDATE_JOURNAL_KEY = 'viena_local_update_journal_v1';
  const UPDATE_LAST_RESULT_KEY = 'viena_local_update_last_result_v1';
  const UPDATE_LOCK_TTL_MS = 15 * 60 * 1000;
  const REQUIRED_PACKAGE_FILES = new Set([
    'manifest.json', 'build.json', 'background.js', 'popup.html', 'popup.js',
    'icon128.png', 'integrity-manifest.json'
  ]);

  const OPTIONAL_COMPAT_PACKAGE_FILES = new Set(['updater.html', 'updater.js']);

  const PAGE_WINDOW = typeof window !== 'undefined' ? window : null;

  function storageSupported() {
    return typeof indexedDB !== 'undefined';
  }

  function supported() {
    return Boolean(PAGE_WINDOW && typeof PAGE_WINDOW.showDirectoryPicker === 'function' && storageSupported());
  }

  function backgroundSupported() {
    return storageSupported();
  }

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('No se pudo abrir IndexedDB.'));
    });
  }

  async function idbGet(key) {
    const db = await openDb();
    try {
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readonly');
        const req = tx.objectStore(STORE_NAME).get(key);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error || new Error('No se pudo leer la carpeta vinculada.'));
      });
    } finally { db.close(); }
  }

  async function idbSet(key, value) {
    const db = await openDb();
    try {
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).put(value, key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error || new Error('No se pudo guardar la carpeta vinculada.'));
        tx.onabort = () => reject(tx.error || new Error('Se canceló el guardado de la carpeta vinculada.'));
      });
    } finally { db.close(); }
  }

  async function idbDelete(key) {
    const db = await openDb();
    try {
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).delete(key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error || new Error('No se pudo desvincular la carpeta.'));
      });
    } finally { db.close(); }
  }

  function isSafeRelativePath(path) {
    const value = String(path || '');
    if (!value || value.startsWith('/') || value.startsWith('\\') || value.includes('\\')) return false;
    if (value.split('/').some(part => !part || part === '.' || part === '..')) return false;
    if (/^[A-Za-z]:/.test(value)) return false;
    if (REQUIRED_PACKAGE_FILES.has(value) || OPTIONAL_COMPAT_PACKAGE_FILES.has(value)) return true;
    return /^js\/[A-Za-z0-9._-]+\.js$/.test(value);
  }

  function bytesToHex(buffer) {
    return [...new Uint8Array(buffer)].map(v => v.toString(16).padStart(2, '0')).join('');
  }

  async function sha256Bytes(bytes) {
    const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    return bytesToHex(await crypto.subtle.digest('SHA-256', view));
  }

  function decodeBase64(value) {
    const raw = atob(String(value || ''));
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    return bytes;
  }

  function decodeUtf8(bytes) {
    return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  }

  function compareVersions(a, b) {
    const pa = String(a || '').split('.').map(n => Number.parseInt(n, 10) || 0);
    const pb = String(b || '').split('.').map(n => Number.parseInt(n, 10) || 0);
    const max = Math.max(pa.length, pb.length);
    for (let i = 0; i < max; i++) {
      const x = pa[i] || 0, y = pb[i] || 0;
      if (x !== y) return x > y ? 1 : -1;
    }
    return 0;
  }

  function newUpdateToken() {
    try { if (crypto?.randomUUID) return crypto.randomUUID(); } catch (_) {}
    return `update-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
  }

  async function readUpdateJournal() {
    try {
      const data = await chrome.storage.local.get([UPDATE_JOURNAL_KEY]);
      return data?.[UPDATE_JOURNAL_KEY] || null;
    } catch (_) { return null; }
  }

  async function writeUpdateJournal(value) {
    const next = { schema: 1, updaterContract: UPDATER_CONTRACT_VERSION, ...(value || {}), updatedAt: Date.now() };
    await chrome.storage.local.set({ [UPDATE_JOURNAL_KEY]: next });
    return next;
  }

  async function updateJournalStage(patch) {
    const current = await readUpdateJournal();
    if (!current) return null;
    return writeUpdateJournal({ ...current, ...(patch || {}) });
  }

  async function clearUpdateJournal() {
    try { await chrome.storage.local.remove([UPDATE_JOURNAL_KEY]); } catch (_) {}
  }

  async function recordUpdateResult(value) {
    try {
      await chrome.storage.local.set({
        [UPDATE_LAST_RESULT_KEY]: {
          updaterContract: UPDATER_CONTRACT_VERSION,
          ...(value || {}),
          recordedAt: Date.now()
        }
      });
    } catch (_) {}
  }

  async function getRecoveryStatus() {
    try {
      const data = await chrome.storage.local.get([UPDATE_JOURNAL_KEY, UPDATE_LOCK_KEY, UPDATE_LAST_RESULT_KEY]);
      return {
        updaterContract: UPDATER_CONTRACT_VERSION,
        journal: data?.[UPDATE_JOURNAL_KEY] || null,
        lock: data?.[UPDATE_LOCK_KEY] || null,
        lastResult: data?.[UPDATE_LAST_RESULT_KEY] || null
      };
    } catch (_) {
      return { updaterContract: UPDATER_CONTRACT_VERSION, journal: null, lock: null, lastResult: null };
    }
  }

  async function acquirePersistentUpdateLock(target = {}) {
    const now = Date.now();
    const data = await chrome.storage.local.get([UPDATE_LOCK_KEY]);
    const existing = data?.[UPDATE_LOCK_KEY] || null;
    const age = existing ? now - Number(existing.startedAt || 0) : Number.POSITIVE_INFINITY;
    if (existing && age >= 0 && age < UPDATE_LOCK_TTL_MS) {
      throw new Error(`Ya hay una actualización en curso (${existing.targetBuild || existing.targetVersion || 'destino pendiente'}).`);
    }
    if (existing) {
      try { await chrome.storage.local.remove([UPDATE_LOCK_KEY]); } catch (_) {}
    }
    const token = newUpdateToken();
    const value = {
      token,
      startedAt: now,
      targetVersion: String(target.targetVersion || ''),
      targetBuild: String(target.targetBuild || ''),
      targetChannel: String(target.targetChannel || '')
    };
    await chrome.storage.local.set({ [UPDATE_LOCK_KEY]: value });
    const confirm = await chrome.storage.local.get([UPDATE_LOCK_KEY]);
    if (confirm?.[UPDATE_LOCK_KEY]?.token !== token) throw new Error('No se pudo obtener el bloqueo exclusivo de actualización.');
    return token;
  }

  async function releasePersistentUpdateLock(token, { force = false } = {}) {
    try {
      const data = await chrome.storage.local.get([UPDATE_LOCK_KEY]);
      const current = data?.[UPDATE_LOCK_KEY];
      if (force || !current || current.token === token) await chrome.storage.local.remove([UPDATE_LOCK_KEY]);
    } catch (_) {}
  }

  async function withExclusiveUpdateLock(target, fn) {
    const run = async () => {
      const token = await acquirePersistentUpdateLock(target);
      let keepPersistentLock = false;
      try {
        const result = await fn(token);
        const journal = await readUpdateJournal();
        keepPersistentLock = Boolean(journal?.stage === 'awaiting_reload' && journal?.lockToken === token);
        return result;
      } finally {
        if (!keepPersistentLock) await releasePersistentUpdateLock(token);
      }
    };
    if (globalThis.navigator?.locks?.request) {
      return navigator.locks.request('viena-noc-tools-local-update', { mode: 'exclusive', ifAvailable: true }, async lock => {
        if (!lock) throw new Error('Ya hay otra actualización ejecutándose en otra ventana.');
        return run();
      });
    }
    return run();
  }

  async function getFileHandleForPath(root, path, { create = false } = {}) {
    const parts = String(path).split('/');
    const fileName = parts.pop();
    let dir = root;
    for (const part of parts) dir = await dir.getDirectoryHandle(part, { create });
    return dir.getFileHandle(fileName, { create });
  }

  async function readFileBytes(root, path) {
    const handle = await getFileHandleForPath(root, path, { create: false });
    const file = await handle.getFile();
    return new Uint8Array(await file.arrayBuffer());
  }

  async function readJson(root, path) {
    return JSON.parse(decodeUtf8(await readFileBytes(root, path)));
  }

  async function readMaybe(root, path) {
    try { return { exists: true, bytes: await readFileBytes(root, path) }; }
    catch (error) {
      if (error?.name === 'NotFoundError') return { exists: false, bytes: null };
      throw error;
    }
  }

  async function writeFileBytes(root, path, bytes) {
    const handle = await getFileHandleForPath(root, path, { create: true });
    const writable = await handle.createWritable();
    try { await writable.write(bytes); }
    finally { await writable.close(); }
  }

  async function deleteFile(root, path) {
    const parts = String(path).split('/');
    const fileName = parts.pop();
    let dir = root;
    for (const part of parts) dir = await dir.getDirectoryHandle(part, { create: false });
    try { await dir.removeEntry(fileName); }
    catch (error) { if (error?.name !== 'NotFoundError') throw error; }
  }

  async function getRuntimeIdentity() {
    const provider = globalThis.__VIENA_UPDATER_RUNTIME_IDENTITY;
    if (provider) {
      try {
        const supplied = typeof provider === 'function' ? await provider() : provider;
        if (supplied?.build) {
          return {
            name: String(supplied.name || chrome.runtime.getManifest()?.name || ''),
            version: String(supplied.version || chrome.runtime.getManifest()?.version || ''),
            build: String(supplied.build || ''),
            channel: String(supplied.channel || '').toUpperCase(),
            updaterContract: Number(supplied.updaterContract || UPDATER_CONTRACT_VERSION)
          };
        }
      } catch (_) {}
    }
    const manifest = chrome.runtime.getManifest();
    let status = null;
    try { status = await chrome.runtime.sendMessage({ type: 'VIENA_GET_OPERATIONAL_STATUS' }); } catch (_) {}
    const runtimeBuild = String(status?.runtimeBuild || '').trim();
    const ownBuildUrl = `${chrome.runtime.getURL('build.json')}?_=${Date.now()}`;
    let buildJson = null;
    try {
      const response = await fetch(ownBuildUrl, { cache: 'no-store' });
      if (response.ok) buildJson = await response.json();
    } catch (_) {}
    return {
      name: String(manifest?.name || ''),
      version: String(manifest?.version || ''),
      build: runtimeBuild || String(buildJson?.build || ''),
      channel: /\bDEV\b/i.test(String(manifest?.name || '')) ? 'DEV' : 'RELEASE',
      updaterContract: Number(buildJson?.updater_contract || 0)
    };
  }

  async function inspectDirectory(handle) {
    const [manifest, build] = await Promise.all([
      readJson(handle, 'manifest.json'),
      readJson(handle, 'build.json')
    ]);
    return {
      name: String(manifest?.name || ''),
      version: String(manifest?.version || ''),
      build: String(build?.build || ''),
      buildVersion: String(build?.version || ''),
      channel: String(build?.channel || '').toUpperCase(),
      updaterContract: Number(build?.updater_contract || 0)
    };
  }

  async function permissionState(handle, mode = 'readwrite') {
    if (!handle?.queryPermission) return 'prompt';
    try { return await handle.queryPermission({ mode }); }
    catch (_) { return 'prompt'; }
  }

  async function ensurePermission(handle, { prompt = false } = {}) {
    let state = await permissionState(handle, 'readwrite');
    if (state === 'granted') return true;
    if (!prompt || !handle?.requestPermission) return false;
    try { state = await handle.requestPermission({ mode: 'readwrite' }); }
    catch (_) { return false; }
    return state === 'granted';
  }

  async function validateSelectedDirectory(handle, { requireRuntimeMatch = true } = {}) {
    const identity = await inspectDirectory(handle);
    const runtime = await getRuntimeIdentity();
    if (!identity.name.startsWith(APP_PREFIX)) throw new Error('La carpeta seleccionada no corresponde a VIENA NOC Tools.');
    if (!/^\d+\.\d+\.\d+$/.test(identity.version) || identity.version !== identity.buildVersion) {
      throw new Error('La carpeta tiene una identidad de versión inválida.');
    }
    if (!['DEV', 'RELEASE'].includes(identity.channel)) throw new Error('La carpeta no tiene un canal DEV/RELEASE válido.');
    if (identity.channel !== runtime.channel) throw new Error(`Seleccionaste una carpeta ${identity.channel}; esta extensión es ${runtime.channel}.`);
    if (requireRuntimeMatch && identity.version !== runtime.version) {
      throw new Error(`La carpeta contiene v${identity.version}, pero el runtime activo es v${runtime.version}.`);
    }
    return { identity, runtime };
  }

  async function getStoredHandle() {
    if (!storageSupported()) return null;
    try { return await idbGet(HANDLE_KEY); } catch (_) { return null; }
  }

  async function getStoredMeta() {
    try {
      const data = await chrome.storage.local.get([META_KEY]);
      return data?.[META_KEY] || null;
    } catch (_) { return null; }
  }

  async function saveMeta(handle, identity) {
    try {
      await chrome.storage.local.set({
        [META_KEY]: {
          name: String(handle?.name || 'carpeta'),
          identity: identity || null,
          savedAt: Date.now()
        }
      });
    } catch (_) {}
  }

  async function getLinkStatus() {
    if (!supported()) return { supported: false, linked: false, permission: 'unsupported' };
    const [handle, meta] = await Promise.all([getStoredHandle(), getStoredMeta()]);
    if (!handle) {
      if (meta) {
        return {
          supported: true, linked: true, permission: 'relink', valid: false,
          name: String(meta.name || 'carpeta'), identity: meta.identity || null,
          error: 'La carpeta quedó recordada, pero Chrome perdió el identificador de acceso. Volvé a autorizarla una vez.'
        };
      }
      return { supported: true, linked: false, permission: 'none' };
    }
    const permission = await permissionState(handle, 'readwrite');
    let valid = false, identity = null, error = '';
    if (permission === 'granted') {
      try {
        ({ identity } = await validateSelectedDirectory(handle, { requireRuntimeMatch: false }));
        valid = true;
        await saveMeta(handle, identity);
      } catch (e) { error = String(e?.message || e); }
    }
    return { supported: true, linked: true, permission, valid, name: handle.name || meta?.name || 'carpeta', identity: identity || meta?.identity || null, error };
  }

  async function pickAndLink({ requireRuntimeMatch = true } = {}) {
    if (!supported()) throw new Error('Este Chrome no ofrece File System Access en esta página de la extensión.');
    const handle = await PAGE_WINDOW.showDirectoryPicker({ id: 'viena-noc-tools-install', mode: 'readwrite', startIn: 'desktop' });
    if (!await ensurePermission(handle, { prompt: true })) throw new Error('No se otorgó permiso de escritura sobre la carpeta.');
    const result = await validateSelectedDirectory(handle, { requireRuntimeMatch });
    await idbSet(HANDLE_KEY, handle);
    await saveMeta(handle, result.identity);
    return { handle, name: handle.name || 'carpeta', ...result };
  }

  async function requestStoredPermission() {
    if (!supported()) throw new Error('File System Access no está disponible en este Chrome.');
    const handle = await getStoredHandle();
    if (!handle) throw new Error('Chrome no conserva el acceso a la carpeta. Seleccionala nuevamente.');
    if (!await ensurePermission(handle, { prompt: true })) throw new Error('No se otorgó permiso de escritura sobre la carpeta.');
    const result = await validateSelectedDirectory(handle, { requireRuntimeMatch: false });
    await saveMeta(handle, result.identity);
    return { handle, name: handle.name || 'carpeta', ...result };
  }

  async function getStoredHandleForUi() {
    return await getStoredHandle();
  }

  async function authorizeStoredHandleFromGesture(handle) {
    if (!supported()) throw new Error('File System Access no está disponible en este Chrome.');
    if (!handle) throw new Error('Chrome no conserva el acceso a la carpeta. Seleccionala nuevamente.');

    // IMPORTANTE: requestPermission debe ser la primera operación sensible de este flujo.
    // El popup precarga el handle y llama esta función directamente desde el click del usuario,
    // evitando perder la activación transitoria requerida por Chrome.
    let state = 'prompt';
    try { state = await handle.requestPermission({ mode: 'readwrite' }); }
    catch (error) {
      throw new Error(`Chrome no pudo solicitar permiso de escritura: ${String(error?.message || error)}`);
    }
    if (state !== 'granted') throw new Error('No se otorgó permiso de escritura sobre la carpeta.');

    const result = await validateSelectedDirectory(handle, { requireRuntimeMatch: false });
    await saveMeta(handle, result.identity);
    return { handle, name: handle.name || 'carpeta', ...result };
  }

  async function unlink() {
    await idbDelete(HANDLE_KEY);
    try { await chrome.storage.local.remove([META_KEY]); } catch (_) {}
    return { ok: true };
  }

  async function fetchVerifiedPackage(packageUrl, expectedPackageSha256 = '') {
    const url = new URL(String(packageUrl || ''));
    if (url.protocol !== 'https:' || url.hostname !== 'raw.githubusercontent.com') {
      throw new Error('Origen del paquete de actualización no autorizado.');
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    let bytes;
    try {
      const response = await fetch(`${url.href}${url.search ? '&' : '?'}_=${Date.now()}`, {
        cache: 'no-store',
        signal: controller.signal,
        headers: { 'Cache-Control': 'no-cache' }
      });
      if (!response.ok) throw new Error(`Paquete HTTP ${response.status}`);
      bytes = new Uint8Array(await response.arrayBuffer());
    } finally { clearTimeout(timer); }

    const packageSha256 = await sha256Bytes(bytes);
    const expected = String(expectedPackageSha256 || '').trim().toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(expected)) throw new Error('El canal no publicó un SHA-256 válido para el paquete.');
    if (packageSha256 !== expected) throw new Error('El SHA-256 del paquete no coincide con el publicado.');

    let pkg;
    try { pkg = JSON.parse(decodeUtf8(bytes)); }
    catch (_) { throw new Error('El paquete de actualización no es JSON válido.'); }
    return { pkg, packageSha256 };
  }

  async function validatePackage(pkg, { expectedVersion = '', expectedBuild = '', expectedChannel = '' } = {}) {
    if (Number(pkg?.schema) !== 1 || pkg?.app !== APP_PREFIX) throw new Error('Formato de paquete no compatible.');
    const version = String(pkg?.version || '').trim();
    const build = String(pkg?.build || '').trim();
    const channel = String(pkg?.channel || '').trim().toUpperCase();
    if (!/^\d+\.\d+\.\d+$/.test(version) || !build || !['DEV', 'RELEASE'].includes(channel)) throw new Error('Identidad del paquete inválida.');
    if (expectedVersion && version !== String(expectedVersion)) throw new Error(`El paquete es v${version} y el canal anunció v${expectedVersion}.`);
    if (expectedBuild && build !== String(expectedBuild)) throw new Error('El build del paquete no coincide con el anunciado.');
    if (expectedChannel && channel !== String(expectedChannel).toUpperCase()) throw new Error('El canal del paquete no coincide con el esperado.');

    const mode = String(pkg?.mode || 'full');
    if (!['full', 'dev-delta'].includes(mode)) throw new Error('Modo de paquete no compatible.');
    if (mode === 'dev-delta' && channel !== 'DEV') throw new Error('Los paquetes delta de prueba sólo están permitidos en DEV.');
    if (!Array.isArray(pkg.files) || !pkg.files.length) throw new Error('El paquete no contiene archivos.');
    const files = new Map();
    for (const item of pkg.files) {
      const path = String(item?.path || '');
      if (!isSafeRelativePath(path)) throw new Error(`Ruta no autorizada en el paquete: ${path || '(vacía)'}`);
      if (files.has(path)) throw new Error(`Archivo duplicado en el paquete: ${path}`);
      const bytes = decodeBase64(item?.content_base64);
      const expectedHash = String(item?.sha256 || '').toLowerCase();
      if (!/^[a-f0-9]{64}$/.test(expectedHash)) throw new Error(`SHA-256 inválido para ${path}.`);
      const got = await sha256Bytes(bytes);
      if (got !== expectedHash) throw new Error(`Integridad inválida en ${path}.`);
      if (Number(item?.size) !== bytes.byteLength) throw new Error(`Tamaño inválido en ${path}.`);
      files.set(path, { path, bytes, sha256: got });
    }
    for (const required of ['build.json', 'integrity-manifest.json']) if (!files.has(required)) throw new Error(`Falta ${required} en el paquete.`);

    const parseFileJson = (path) => JSON.parse(decodeUtf8(files.get(path).bytes));
    const manifest = files.has('manifest.json') ? parseFileJson('manifest.json') : null;
    const buildJson = parseFileJson('build.json');
    const integrity = parseFileJson('integrity-manifest.json');
    if (manifest && String(manifest?.version || '') !== version) throw new Error('manifest.json no coincide con la versión del paquete.');
    if (String(buildJson?.version || '') !== version || String(buildJson?.build || '') !== build || String(buildJson?.channel || '').toUpperCase() !== channel) {
      throw new Error('build.json no coincide con la identidad del paquete.');
    }
    if (String(integrity?.version || '') !== version || String(integrity?.build || '') !== build || String(integrity?.channel || '').toUpperCase() !== channel) {
      throw new Error('integrity-manifest.json no coincide con la identidad del paquete.');
    }
    const integrityFiles = integrity?.files;
    if (!integrityFiles || typeof integrityFiles !== 'object') throw new Error('El inventario de integridad del paquete es inválido.');
    for (const [path, hash] of Object.entries(integrityFiles)) {
      if (!isSafeRelativePath(path)) throw new Error(`Ruta inválida en integrity-manifest: ${path}`);
      const entry = files.get(path);
      if (entry && entry.sha256 !== String(hash || '').toLowerCase()) throw new Error(`El inventario no coincide para ${path}.`);
    }
    if (mode === 'full') {
      for (const path of Object.keys(integrityFiles)) if (!files.has(path)) throw new Error(`Paquete full incompleto: falta ${path}.`);
      for (const required of REQUIRED_PACKAGE_FILES) if (!files.has(required)) throw new Error(`Paquete full incompleto: falta ${required}.`);
    }

    const patches = Array.isArray(pkg.patches) ? pkg.patches : [];
    if (patches.length && mode !== 'dev-delta') throw new Error('Los parches de texto sólo están permitidos en paquetes DEV de prueba.');
    const normalizedPatches = patches.map((patch) => {
      const path = String(patch?.path || '');
      const find = String(patch?.find || '');
      const replace = String(patch?.replace || '');
      const oldSha256 = String(patch?.old_sha256 || '').toLowerCase();
      const newSha256 = String(patch?.new_sha256 || '').toLowerCase();
      if (!isSafeRelativePath(path) || !/\.js$/.test(path)) throw new Error(`Patch no autorizado: ${path || '(vacío)'}`);
      if (!find || find.length > 500 || replace.length > 500) throw new Error(`Patch inválido para ${path}.`);
      if (!/^[a-f0-9]{64}$/.test(oldSha256) || !/^[a-f0-9]{64}$/.test(newSha256)) throw new Error(`SHA inválido en patch ${path}.`);
      return { path, find, replace, oldSha256, newSha256 };
    });

    const remove = Array.isArray(pkg.remove) ? pkg.remove.map(String) : [];
    for (const path of remove) if (!isSafeRelativePath(path) || REQUIRED_PACKAGE_FILES.has(path)) throw new Error(`No se permite eliminar ${path}.`);
    return { version, build, channel, mode, files, patches: normalizedPatches, remove, manifest, buildJson, integrity };
  }

  async function verifyDirectoryAgainstIntegrity(handle, integrityFiles) {
    try {
      const entries = Object.entries(integrityFiles || {});
      if (!entries.length) return { ok: false, reason: 'integrity_files_empty' };
      for (const [path, expectedHash] of entries) {
        const got = await sha256Bytes(await readFileBytes(handle, path));
        if (got !== String(expectedHash || '').toLowerCase()) return { ok: false, reason: `integrity_mismatch:${path}` };
      }
      return { ok: true, count: entries.length };
    } catch (error) {
      return { ok: false, reason: String(error?.message || error) };
    }
  }

  async function rollbackTouchedFiles(handle, touched, backup) {
    const errors = [];
    const unique = [...new Set(touched)].reverse();
    for (const path of unique) {
      const prev = backup.get(path);
      try {
        if (prev?.exists) await writeFileBytes(handle, path, prev.bytes);
        else await deleteFile(handle, path);
      } catch (error) {
        errors.push(`restore:${path}:${String(error?.message || error)}`);
      }
    }
    for (const path of unique) {
      const prev = backup.get(path);
      try {
        if (prev?.exists) {
          const got = await sha256Bytes(await readFileBytes(handle, path));
          const wanted = await sha256Bytes(prev.bytes);
          if (got !== wanted) errors.push(`verify:${path}`);
        } else {
          const state = await readMaybe(handle, path);
          if (state.exists) errors.push(`verify_absent:${path}`);
        }
      } catch (error) {
        errors.push(`verify:${path}:${String(error?.message || error)}`);
      }
    }
    return { ok: errors.length === 0, errors };
  }

  async function installPackageLocked(args, lockToken) {
    const {
      packageUrl, packageSha256,
      expectedVersion = '', expectedBuild = '', expectedChannel = '',
      onProgress = null
    } = args || {};
    if (!storageSupported()) throw new Error('File System Access no está disponible.');
    const progress = async state => {
      if (typeof onProgress !== 'function') return;
      try { await onProgress(state || {}); } catch (_) {}
    };
    await progress({ stage: 'preparing', step: 1, totalSteps: 5, label: 'Preparando archivos…' });
    const handle = await getStoredHandle();
    if (!handle) throw new Error('Primero vinculá la carpeta donde está instalada la extensión.');
    if (!await ensurePermission(handle, { prompt: false })) throw new Error('Chrome perdió el permiso de escritura. Volvé a vincular la carpeta y repetí la actualización.');

    const runtime = await getRuntimeIdentity();
    const existingJournal = await readUpdateJournal();
    const pendingStages = new Set(['prepared', 'writing', 'verifying', 'rollback_incomplete', 'awaiting_reload']);
    const likelyRecovery = Boolean(
      existingJournal &&
      pendingStages.has(String(existingJournal.stage || '')) &&
      String(existingJournal.packageSha256 || '').toLowerCase() === String(packageSha256 || '').toLowerCase() &&
      (!expectedVersion || String(existingJournal.targetVersion || '') === String(expectedVersion)) &&
      (!expectedBuild || String(existingJournal.targetBuild || '') === String(expectedBuild)) &&
      (!expectedChannel || String(existingJournal.targetChannel || '').toUpperCase() === String(expectedChannel).toUpperCase())
    );

    let currentFolder = null;
    if (likelyRecovery) {
      if (existingJournal.folderName && String(handle.name || '') !== String(existingJournal.folderName)) {
        throw new Error('La recuperación pertenece a otra carpeta de instalación. Volvé a vincular la carpeta correcta.');
      }
      if (existingJournal.targetChannel && runtime.channel !== String(existingJournal.targetChannel).toUpperCase()) {
        throw new Error('La recuperación pendiente pertenece a otro canal.');
      }
      try { currentFolder = await inspectDirectory(handle); }
      catch (_) { currentFolder = existingJournal.fromFolderIdentity || null; }
    } else {
      ({ identity: currentFolder } = await validateSelectedDirectory(handle, { requireRuntimeMatch: true }));
    }

    await progress({ stage: 'downloading', step: 2, totalSteps: 5, label: 'Descargando actualización…' });
    const { pkg, packageSha256: verifiedPackageSha256 } = await fetchVerifiedPackage(packageUrl, packageSha256);
    await progress({ stage: 'verifying', step: 3, totalSteps: 5, label: 'Verificando integridad…' });
    const validated = await validatePackage(pkg, { expectedVersion, expectedBuild, expectedChannel: expectedChannel || runtime.channel });
    if (validated.channel !== runtime.channel) throw new Error(`No se puede instalar ${validated.channel} desde un runtime ${runtime.channel}.`);
    if (!likelyRecovery && validated.channel !== currentFolder?.channel) throw new Error(`No se puede instalar ${validated.channel} sobre una carpeta ${currentFolder?.channel || 'sin canal válido'}.`);

    const versionCmp = compareVersions(validated.version, runtime.version);
    if (versionCmp < 0) throw new Error(`Se bloqueó un downgrade: runtime v${runtime.version} → paquete v${validated.version}.`);
    if (validated.channel === 'RELEASE' && versionCmp === 0 && validated.build !== runtime.build) {
      throw new Error('Una RELEASE no puede reemplazarse por otra build con el mismo número de versión. Publicá una versión superior.');
    }
    const replaySafeDevDelta = validated.mode === 'dev-delta' && validated.channel === 'DEV' && validated.patches.length === 0 && validated.remove.length === 0 && validated.files.has('build.json') && validated.files.has('integrity-manifest.json') && [...validated.files.entries()].every(([path, entry]) => path === 'integrity-manifest.json' || String(validated.integrity?.files?.[path] || '').toLowerCase() === entry.sha256) && Object.keys(validated.integrity?.files || {}).every(path => validated.files.has(path));
    if (likelyRecovery && validated.mode !== 'full' && !replaySafeDevDelta) throw new Error('Una recuperacion interrumpida requiere FULL o DEV portable replay-safe.');

    if (likelyRecovery && existingJournal.stage === 'awaiting_reload') {
      let finalIdentity = null;
      try { finalIdentity = await inspectDirectory(handle); } catch (_) {}
      const inventory = await verifyDirectoryAgainstIntegrity(handle, validated.integrity.files);
      if (inventory.ok && finalIdentity?.build === validated.build && finalIdentity?.version === validated.version && finalIdentity?.channel === validated.channel) {
        await writeUpdateJournal({ ...existingJournal, stage: 'awaiting_reload', lockToken, verifiedAt: Date.now() });
        return { ok: true, awaitingReload: true, version: validated.version, build: validated.build, channel: validated.channel, files: validated.files.size, packageSha256: verifiedPackageSha256, folderName: handle.name || 'carpeta' };
      }
    }

    if (validated.build === runtime.build) {
      const inventory = await verifyDirectoryAgainstIntegrity(handle, validated.integrity.files);
      if (inventory.ok) {
        await clearUpdateJournal();
        await releasePersistentUpdateLock(lockToken, { force: true });
        await recordUpdateResult({ ok: true, status: 'already_current_verified', version: validated.version, build: validated.build, channel: validated.channel });
        return { ok: true, alreadyCurrent: true, version: validated.version, build: validated.build };
      }
    }
    if (validated.version !== runtime.version && !validated.files.has('manifest.json')) throw new Error('Una actualización de versión debe incluir manifest.json.');

    const effectiveFiles = new Map(validated.files);
    for (const patch of validated.patches) {
      const currentBytes = await readFileBytes(handle, patch.path);
      if (await sha256Bytes(currentBytes) !== patch.oldSha256) throw new Error(`El archivo base no coincide para aplicar patch: ${patch.path}.`);
      const currentText = decodeUtf8(currentBytes);
      const first = currentText.indexOf(patch.find);
      if (first < 0 || currentText.indexOf(patch.find, first + patch.find.length) >= 0) throw new Error(`El patch no encuentra una coincidencia única en ${patch.path}.`);
      const nextBytes = new TextEncoder().encode(currentText.slice(0, first) + patch.replace + currentText.slice(first + patch.find.length));
      if (await sha256Bytes(nextBytes) !== patch.newSha256) throw new Error(`El resultado del patch no coincide para ${patch.path}.`);
      effectiveFiles.set(patch.path, { path: patch.path, bytes: nextBytes, sha256: patch.newSha256 });
    }

    const journalBase = {
      stage: 'prepared',
      lockToken,
      packageUrl: String(packageUrl || ''),
      packageSha256: verifiedPackageSha256,
      fromRuntime: runtime,
      fromFolderIdentity: currentFolder || existingJournal?.fromFolderIdentity || null,
      targetVersion: validated.version,
      targetBuild: validated.build,
      targetChannel: validated.channel,
      folderName: String(handle.name || existingJournal?.folderName || 'carpeta'),
      startedAt: Number(existingJournal?.startedAt || Date.now()),
      recoveryAttempt: Number(existingJournal?.recoveryAttempt || 0) + (likelyRecovery ? 1 : 0),
      mode: validated.mode
    };
    await writeUpdateJournal(journalBase);

    const pathsToBackup = [...new Set([...effectiveFiles.keys(), ...validated.remove])];
    const backup = new Map();
    for (const path of pathsToBackup) backup.set(path, await readMaybe(handle, path));

    const delayed = new Set(['manifest.json', 'integrity-manifest.json', 'build.json']);
    const writeOrder = [...effectiveFiles.keys()].filter(p => !delayed.has(p));
    for (const p of ['manifest.json', 'integrity-manifest.json', 'build.json']) if (effectiveFiles.has(p)) writeOrder.push(p);
    const touched = [];
    let writtenCount = 0;

    const totalWrites = validated.remove.length + writeOrder.length;
    await progress({ stage: 'applying', step: 4, totalSteps: 5, label: 'Aplicando actualización…', writtenCount: 0, totalWrites });
    await updateJournalStage({ stage: 'writing', totalWrites, writtenCount: 0 });

    try {
      for (const path of validated.remove) {
        await deleteFile(handle, path);
        touched.push(path);
        writtenCount++;
        await updateJournalStage({ stage: 'writing', lastPath: path, writtenCount });
        await progress({ stage: 'applying', step: 4, totalSteps: 5, label: 'Aplicando actualización…', writtenCount, totalWrites, lastPath: path });
      }
      for (const path of writeOrder) {
        await writeFileBytes(handle, path, effectiveFiles.get(path).bytes);
        touched.push(path);
        writtenCount++;
        await updateJournalStage({ stage: 'writing', lastPath: path, writtenCount });
        await progress({ stage: 'applying', step: 4, totalSteps: 5, label: 'Aplicando actualización…', writtenCount, totalWrites, lastPath: path });
      }

      await updateJournalStage({ stage: 'verifying', writtenCount, verifyStartedAt: Date.now() });

      for (const [path, entry] of effectiveFiles) {
        const got = await sha256Bytes(await readFileBytes(handle, path));
        if (got !== entry.sha256) throw new Error(`Verificación posterior falló en ${path}.`);
      }
      const inventory = await verifyDirectoryAgainstIntegrity(handle, validated.integrity.files);
      if (!inventory.ok) throw new Error(`La carpeta final no coincide con el inventario: ${inventory.reason}.`);

      const finalIdentity = await inspectDirectory(handle);
      if (finalIdentity.build !== validated.build || finalIdentity.version !== validated.version || finalIdentity.channel !== validated.channel) {
        throw new Error('La identidad final de la carpeta no coincide con el paquete instalado.');
      }

      await updateJournalStage({
        stage: 'awaiting_reload',
        writtenCount,
        copiedAt: Date.now(),
        finalIdentity,
        integrityFiles: inventory.count
      });
      await progress({ stage: 'restarting', step: 5, totalSteps: 5, label: 'Reiniciando extensión…', writtenCount, totalWrites });
      await recordUpdateResult({
        ok: true,
        status: 'copied_awaiting_reload',
        version: validated.version,
        build: validated.build,
        channel: validated.channel,
        packageSha256: verifiedPackageSha256
      });

      return {
        ok: true,
        version: validated.version,
        build: validated.build,
        channel: validated.channel,
        files: effectiveFiles.size,
        packageSha256: verifiedPackageSha256,
        folderName: handle.name || 'carpeta',
        awaitingReload: true
      };
    } catch (error) {
      const rollback = await rollbackTouchedFiles(handle, touched, backup);
      if (rollback.ok) {
        await recordUpdateResult({
          ok: false,
          status: 'failed_rolled_back_verified',
          targetVersion: validated.version,
          targetBuild: validated.build,
          targetChannel: validated.channel,
          error: String(error?.message || error).slice(0, 400)
        });
        await clearUpdateJournal();
      } else {
        await updateJournalStage({
          stage: 'rollback_incomplete',
          error: String(error?.message || error).slice(0, 400),
          rollbackErrors: rollback.errors.slice(0, 20)
        });
        await recordUpdateResult({
          ok: false,
          status: 'rollback_incomplete',
          targetVersion: validated.version,
          targetBuild: validated.build,
          targetChannel: validated.channel,
          error: String(error?.message || error).slice(0, 400),
          rollbackErrors: rollback.errors.slice(0, 20)
        });
      }
      throw new Error(`La actualización se canceló. Rollback ${rollback.ok ? 'verificado correctamente' : 'incompleto; se reintentará la recuperación'}: ${String(error?.message || error)}`);
    }
  }

  async function installPackage(args) {
    const target = {
      targetVersion: String(args?.expectedVersion || ''),
      targetBuild: String(args?.expectedBuild || ''),
      targetChannel: String(args?.expectedChannel || '')
    };
    try {
      return await withExclusiveUpdateLock(target, token => installPackageLocked(args || {}, token));
    } catch (error) {
      const journal = await readUpdateJournal();
      await recordUpdateResult({
        ok: false,
        status: journal?.stage || 'preflight_failed',
        targetVersion: String(args?.expectedVersion || journal?.targetVersion || ''),
        targetBuild: String(args?.expectedBuild || journal?.targetBuild || ''),
        targetChannel: String(args?.expectedChannel || journal?.targetChannel || ''),
        error: String(error?.message || error).slice(0, 400)
      });
      throw error;
    }
  }

  async function resumePendingUpdate() {
    const journal = await readUpdateJournal();
    if (!journal) return { ok: true, skipped: true, reason: 'no_pending_update' };
    if (!journal.packageUrl || !/^[a-f0-9]{64}$/i.test(String(journal.packageSha256 || ''))) {
      throw new Error('El journal de recuperación no contiene un paquete verificable.');
    }
    if (journal.stage === 'awaiting_reload') {
      return { ok: true, awaitingReload: true, version: journal.targetVersion, build: journal.targetBuild, channel: journal.targetChannel };
    }
    return installPackage({
      packageUrl: journal.packageUrl,
      packageSha256: journal.packageSha256,
      expectedVersion: journal.targetVersion,
      expectedBuild: journal.targetBuild,
      expectedChannel: journal.targetChannel
    });
  }

  const api = Object.freeze({
    supported,
    backgroundSupported,
    getRuntimeIdentity,
    getLinkStatus,
    getStoredHandleForUi,
    pickAndLink,
    requestStoredPermission,
    authorizeStoredHandleFromGesture,
    unlink,
    installPackage,
    resumePendingUpdate,
    getRecoveryStatus,
    validatePackage,
    isSafeRelativePath,
    updaterContractVersion: UPDATER_CONTRACT_VERSION
  });
  globalThis.VienaLocalUpdater = api;
  if (PAGE_WINDOW) PAGE_WINDOW.VienaLocalUpdater = api;
})();
