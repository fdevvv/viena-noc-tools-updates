(() => {
  'use strict';

  const SELECTOR_FIJO = 'textarea[name="input-7-4"]';
  const SELECTOR_EDITABLE = 'textarea[rows="5"]:not([readonly])';
  const MARCA = 'data-viena-initial-height';
  let raf = 0;

  function aplicarAlturaInicial(el, height) {
    if (!el || el.hasAttribute(MARCA)) return;

    // Sólo definimos el tamaño inicial. No usamos !important y no volvemos a
    // escribir height después: así el resize manual nativo del textarea queda libre.
    el.style.height = height;
    el.style.resize = 'vertical';
    el.setAttribute(MARCA, height);
  }

  function aplicar() {
    raf = 0;

    // Textarea principal del ticket: editable, abre a 400 px.
    document.querySelectorAll(SELECTOR_EDITABLE).forEach(el => {
      // El textarea fijo tiene su propia regla de 500 px.
      if (el.matches(SELECTOR_FIJO)) return;
      aplicarAlturaInicial(el, '400px');
    });

    // Mensaje/textarea histórico readonly: conserva 500 px iniciales,
    // pero el usuario puede redimensionarlo manualmente.
    document.querySelectorAll(SELECTOR_FIJO).forEach(el => {
      aplicarAlturaInicial(el, '500px');
    });
  }

  function programar() {
    if (raf) return;
    raf = requestAnimationFrame(aplicar);
  }

  aplicar();

  // Sólo reaccionamos cuando Vue agrega nodos. No observamos style/attributes,
  // para no pisar un tamaño elegido manualmente ni agregar carga a VIENA.
  const observer = new MutationObserver(mutations => {
    if (mutations.some(m => m.type === 'childList' && m.addedNodes.length)) programar();
  });
  observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
})();
