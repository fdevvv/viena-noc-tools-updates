(function(){
'use strict';
if(window.__VIENA_MOICA_RECEPTOR__) return;
window.__VIENA_MOICA_RECEPTOR__=true;
const PROBLEMA_SORT_KEY='vienaMoicaProblemaOrdenado';
// v1.0.6.28: cualquier click real del operador en Problema cuenta como el único click.
// Capture permite registrarlo aunque jqGrid re-renderice el encabezado después.
document.addEventListener('click',event=>{
 const objetivo=event.target?.closest?.('#jqgh_grid_TktsBuscar_problemas, #grid_TktsBuscar_problemas .ui-jqgrid-sortable');
 if(objetivo){
  sessionStorage.setItem(PROBLEMA_SORT_KEY,'1');
  console.log('[VIENA MOICA] Problema ya fue clickeado en esta pestaña; queda registrado');
 }
},true);

const KEY_PING='VIENA_MOICA_PING', KEY_PONG='VIENA_MOICA_PONG', KEY_ORDEN='VIENA_MOICA_ORDEN';
let runId=0, observer=null;
let ultimaOrdenProcesada='';
const firmaOrden=o=>o?.nonce?`nonce:${o.nonce}`:(o?.nodo?`legacy:${String(o.nodo).toUpperCase()}:${Number(o.ts||0)}`:'');
function procesarOrden(o,origen='listener'){
 const firma=firmaOrden(o);
 if(!o?.nodo||!firma)return false;
 if(firma===ultimaOrdenProcesada){
  console.log('[VIENA MOICA] Orden duplicada ignorada:',{origen,nodo:o.nodo,firma});
  return false;
 }
 ultimaOrdenProcesada=firma;
 console.log('[VIENA MOICA] Procesando orden:',{origen,nodo:o.nodo,firma});
 buscar(o.nodo);
 return true;
}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const norm=v=>String(v||'').trim().toUpperCase().replace(/\s+/g,'');
async function waitFor(fn,timeout=30000,step=60){const t=Date.now();while(Date.now()-t<timeout){const v=fn();if(v)return v;await sleep(step)}return null}
function click(el){if(!el)return false;el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true}));el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true}));el.click();return true}
function buttonByOnclick(name){return document.querySelector(`button[onclick*="${name}"]`)}
async function limpiar(id){
 console.log('[VIENA MOICA] PASO 1: limpiar búsqueda anterior');
 const b=await waitFor(()=>buttonByOnclick('limpiarParametrosBusqueda'),10000);
 if(!b||id!==runId){console.error('[VIENA MOICA] FALLA limpiando');return false}
 click(b);
 await sleep(120);
 // Hallazgo TRACE v2: limpiarParametrosBusqueda() deja algunos selects como '' / [''].
 // buscarParametrosBusqueda() los toma como filtros reales y genera region:[''], tipoRed:'', category_id:[''],
 // lo que devuelve 0 tickets. La búsqueda manual exitosa los mantiene en null.
 const bridge=globalThis.VienaPageBridge;
 if(!bridge?.call){console.error('[VIENA MOICA] FALLA: bridge no disponible para normalizar filtros');return false}
 const normalizados=await bridge.call('moica-normalize-empty-filters',{},5000);
 if(!normalizados?.ok||id!==runId){console.error('[VIENA MOICA] FALLA normalizando filtros vacíos:',normalizados);return false}
 console.log('[VIENA MOICA] Limpieza OK + filtros null',normalizados.data||{});
 return true;
}
async function estados(id){
 console.log('[VIENA MOICA] PASO 2: seleccionar estados Abierto, Completado, En Curso y Pausado');
 const select=await waitFor(()=>document.querySelector('#TKT-BUSCAR-ESTADO'),10000); if(!select||id!==runId)return false;
 const group=select.nextElementSibling?.classList.contains('bootstrap-select')?select.nextElementSibling:select.parentElement?.querySelector('.bootstrap-select');
 const toggle=group?.querySelector('button[data-id="TKT-BUSCAR-ESTADO"]'); if(!group||!toggle)return false;
 if(!group.classList.contains('open')) click(toggle);
 const wanted=new Set(['0','2','3','4']);
 for(const li of group.querySelectorAll('ul.dropdown-menu.inner > li[data-original-index]')){
   const idx=li.getAttribute('data-original-index'); const should=wanted.has(idx); const is=li.classList.contains('selected');
   if(should!==is) click(li.querySelector('a'));
 }
 // Verificación por el select real, no sólo por clases visuales.
 const ok=Array.from(select.options).filter(o=>o.selected).map(o=>o.value);
 if(!['Abierto','Completado','En Curso','Pausado'].every(v=>ok.includes(v))){console.error('[VIENA MOICA] FALLA estados. Seleccionados:',ok);return false;} console.log('[VIENA MOICA] Estados OK:',ok);
 if(group.classList.contains('open')) click(toggle);
 return true;
}
async function seleccionarNodo(nodo,id){
 console.log('[VIENA MOICA] PASO 3: seleccionar nodo por autocomplete:',nodo);
 if(id!==runId)return false;
 const bridge=globalThis.VienaPageBridge;
 if(!bridge?.call)return false;
 const r=await bridge.call('moica-select-node',{nodo},35000);
 if(id!==runId||!r?.ok){console.error('[VIENA MOICA] FALLA selección nodo:',r);return false;}
 // El helper MAIN sólo responde OK si el callback real de MOICA dejó NODO, .
 return norm(String(r.data?.value||'').replace(/,\s*$/,''))===nodo && /,\s*$/.test(String(r.data?.value||''));
}

async function esperarRecargaGrid(id,estadoAntes,timeout=30000,quietMs=650){
 const grid=await waitFor(()=>document.querySelector('#grid_TktsBuscar'),10000); if(!grid)return false;
 const load=()=>document.querySelector('#load_grid_TktsBuscar');
 const firma=()=>grid.innerHTML;
 const filas=()=>grid.querySelectorAll('tr.jqgrow').length;
 const t=Date.now(); let huboActividad=false, ultimaActividad=Date.now(), firmaAnterior=firma();
 while(Date.now()-t<timeout){
   if(id!==runId)return false;
   const l=load(); const cargando=!!l&&getComputedStyle(l).display!=='none';
   const actual=firma();
   if(cargando || actual!==firmaAnterior || actual!==estadoAntes){
     if(cargando || actual!==firmaAnterior) ultimaActividad=Date.now();
     huboActividad=true;
     firmaAnterior=actual;
   }
   // El TRACE manual demostró que gridComplete puede ocurrir antes de que el DOM quede
   // realmente estable. No avanzamos a 100/Problema hasta tener una ventana sin cambios.
   if(huboActividad && !cargando && Date.now()-ultimaActividad>=quietMs){
     console.log('[VIENA MOICA] jqGrid estable', {filas:filas(), quietMs});
     return true;
   }
   await sleep(70);
 }
 return false;
}
function resaltarEnCurso(){
 document.querySelectorAll('#grid_TktsBuscar tr.jqgrow td[aria-describedby="grid_TktsBuscar_estado_actual.estado"]').forEach(td=>{
   const en=String(td.textContent||'').replace(/\s+/g,' ').trim().toLowerCase()==='en curso';
   if(en){td.style.setProperty('background-color','#fff3a3','important');td.style.setProperty('font-weight','700','important');td.dataset.vienaMoicaEnCurso='1';}
   else if(td.dataset.vienaMoicaEnCurso==='1'){td.style.removeProperty('background-color');td.style.removeProperty('font-weight');delete td.dataset.vienaMoicaEnCurso;}
 });
}
function observar(){if(observer)observer.disconnect();const grid=document.querySelector('#grid_TktsBuscar');if(!grid)return;observer=new MutationObserver(resaltarEnCurso);observer.observe(grid,{childList:true,subtree:true,characterData:true});resaltarEnCurso()}
async function buscar(nodo){
 nodo=norm(nodo);if(!nodo)return;const id=++runId; console.log('[VIENA MOICA] ===== NUEVA BÚSQUEDA =====', {nodo,id});
 if(!await limpiar(id))return;
 if(!await estados(id))return;
 if(!await seleccionarNodo(nodo,id))return;
 // El helper MAIN ya responde OK sólo cuando el autocomplete dejó "NODO, ".
 // En vez de sumar una espera fija de 900 ms, avanzamos apenas se cumplen las
 // dos señales reales de readiness: valor seleccionado + menú autocomplete cerrado.
 const listoBuscar=await waitFor(()=>{
  if(id!==runId)return false;
  const input=document.querySelector('#TKT-BUSCAR-NODO-autocom');
  const visual=String(input?.value||'');
  const seleccionado=/[,，]\s*$/.test(visual)&&norm(visual.replace(/[,，]\s*$/,''))===nodo;
  const menus=[...document.querySelectorAll('ul.ui-autocomplete')];
  const menuAbierto=menus.some(ul=>ul.getClientRects().length&&getComputedStyle(ul).display!=='none');
  return seleccionado&&!menuAbierto;
 },3000,25);
 if(!listoBuscar||id!==runId){console.warn('[VIENA MOICA] El autocomplete no quedó listo para Buscar.');return;}
 const bridge=globalThis.VienaPageBridge;
 if(!bridge?.call||id!==runId)return;
 const grid=document.querySelector('#grid_TktsBuscar'); const estadoAntes=grid?grid.innerHTML:'';
 console.log('[VIENA MOICA] PASO 4: click Buscar con nodo ya seleccionado');
 const busqueda=await bridge.call('moica-search-node',{nodo},10000);
 if(!busqueda?.ok||id!==runId){console.warn('[VIENA MOICA] No se pudo aplicar filtro limpio:',busqueda);return;}
 console.log('[VIENA MOICA] Buscar completó recarga real', busqueda.data || {});
 // El helper MAIN ya esperó loadComplete. Leemos el DOM inmediatamente; sólo si
 // la respuesta declaró filas y el DOM todavía no las pintó, esperamos esa señal.
 let filasTrasBuscar=document.querySelectorAll('#grid_TktsBuscar tr.jqgrow').length;
 if(filasTrasBuscar===0&&Number(busqueda.data?.filasLoad||0)>0){
  const filas=await waitFor(()=>{
   const n=document.querySelectorAll('#grid_TktsBuscar tr.jqgrow').length;
   return n>0?n:false;
  },1200,25);
  filasTrasBuscar=Number(filas||0);
 }
 console.log('[VIENA MOICA] Listado tras Buscar', {filas:filasTrasBuscar});
 if(filasTrasBuscar===0){console.error('[VIENA MOICA] FALLA: MOICA respondió la búsqueda pero devolvió 0 filas. Se detiene antes de 100/Problema.', busqueda.data || {});return;}
 const sel=await waitFor(()=>document.querySelector('#gbox_grid_TktsBuscar select.ui-pg-selbox, #grid_TktsBuscar + * select.ui-pg-selbox, select.ui-pg-selbox'),10000);
 console.log('[VIENA MOICA] PASO 5: mostrar 100 filas');
 if(sel&&id===runId&&sel.value!=='100'){const antes100=document.querySelector('#grid_TktsBuscar')?.innerHTML||'';sel.value='100';sel.dispatchEvent(new Event('change',{bubbles:true}));await esperarRecargaGrid(id,antes100,30000)}
 if(id!==runId)return;
 console.log('[VIENA MOICA] PASO 6: ordenar por Problema sólo en el primer uso de esta pestaña y marcar En Curso');
 const gridActual=window.jQuery?.('#grid_TktsBuscar');
 const yaEstaOrdenadoPorProblema=gridActual?.length && String(gridActual.jqGrid('getGridParam','sortname')||'')==='problemas';
 if(yaEstaOrdenadoPorProblema) sessionStorage.setItem(PROBLEMA_SORT_KEY,'1');
 const problemaYaOrdenado=sessionStorage.getItem(PROBLEMA_SORT_KEY)==='1';
 if(!problemaYaOrdenado){
  const problema=document.getElementById('jqgh_grid_TktsBuscar_problemas') || document.querySelector('#grid_TktsBuscar_problemas .ui-jqgrid-sortable');
  if(problema){
   const antesSort=document.querySelector('#grid_TktsBuscar')?.innerHTML||'';
   console.log('[VIENA MOICA] Primer uso: click único en encabezado Problema');
   problema.click();
   sessionStorage.setItem(PROBLEMA_SORT_KEY,'1');
   await esperarRecargaGrid(id,antesSort,30000);
  }
 }else{
  console.log('[VIENA MOICA] Problema ya fue ordenado en esta pestaña; no se vuelve a hacer click');
 }
 observar();
}
// Fallback directo MV3: permite que VIENA ordene una búsqueda aunque el canal GM_*
// no haya respondido todavía. No reemplaza el flujo histórico; sólo da una vía adicional
// para primer acceso / pestaña recién montada.
if (chrome?.runtime?.onMessage) {
 chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg?.type!=='VIENA_MOICA_SEARCH_RUN')return;
  const originalTitle=String(document.title||'');
  clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);
  clearTimeout(globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__);
  let blinkOn=false;
  const blink=()=>{blinkOn=!blinkOn;document.title=blinkOn?`● VN · MOICA2 · ${originalTitle}`:originalTitle;};
  blink();
  globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__=setInterval(blink,450);
  globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__=setTimeout(()=>{clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);document.title=originalTitle;},6000);

  const nodo=norm(msg.nodo);
  if(!nodo){sendResponse({ok:false,code:'invalid_node'});return;}
  Promise.resolve().then(()=>buscar(nodo)).then(()=>sendResponse({ok:true,accepted:true,nodo})).catch(error=>sendResponse({ok:false,code:'search_error',detail:String(error?.message||error)}));
  return true;
 });
}
GM_addValueChangeListener(KEY_PING,async(_n,_a,ping)=>{if(!ping?.id)return;await GM_setValue(KEY_PONG,{id:ping.id,ts:Date.now(),path:location.pathname})});
GM_addValueChangeListener(KEY_ORDEN,(_n,_a,o)=>{procesarOrden(o,'listener')});
// Si el receptor se reinició justo después de una orden desde VIENA, podemos recuperar
// una orden reciente. EXCEPCIÓN: un F5/reload manual del operador debe resetear MOICA y
// nunca volver a ejecutar la última búsqueda automáticamente.
const navigationEntry=performance.getEntriesByType?.('navigation')?.[0];
const esReloadManual=navigationEntry?.type==='reload';
if(esReloadManual){
 console.log('[VIENA MOICA] Reload/F5 detectado: se descarta la última orden y no se reejecuta la búsqueda.');
 GM_setValue(KEY_ORDEN,null).catch(()=>{});
}else{
 GM_getValue(KEY_ORDEN,null).then(o=>{
  if(o?.nodo && Date.now()-Number(o.ts||0) < 30000){
   console.log('[VIENA MOICA] Recuperando orden reciente al iniciar:',o.nodo);
   procesarOrden(o,'startup-recovery');
  }
 }).catch(()=>{});
}
console.log('[VIENA MOICA] Receptor Buscar Ticket activo');
})();
