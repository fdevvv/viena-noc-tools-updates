'use strict';
const VIENA_BUILD_ID = '1.3.29-release-update-registry-assignments-candidate2';
const VIENA_BUILD_FILE = 'build.json';
globalThis.__VIENA_UPDATER_RUNTIME_IDENTITY = () => ({
  name: String(chrome.runtime.getManifest()?.name || ''),
  version: String(chrome.runtime.getManifest()?.version || ''),
  build: VIENA_BUILD_ID,
  channel: /\bDEV\b/i.test(String(chrome.runtime.getManifest()?.name || '')) ? 'DEV' : 'RELEASE',
  updaterContract: 2
});
try { importScripts('js/95-local-updater.js'); } catch (error) { console.error('VIENA updater worker load failed', error); }
const STATUS_BADGES = {
  reload: { text: 'RLD', color: '#B42318', title: 'VIENA NOC Tools — recargá la extensión' },
  tabs: { text: 'TAB', color: '#AD6B00', title: 'VIENA NOC Tools — recargá la pestaña operativa' },
  update: { text: 'UPD', color: '#D97706', title: 'VIENA NOC Tools — actualización disponible' },
  on: { text: 'ON', color: '#23833B', title: 'VIENA NOC Tools — activa' }
};
const WORK_HOSTS = new Set([
  'viena.telecentro.net.ar','mira5-gdt.telecentro.net.ar','mira5.telecentro.net.ar',
  'monitoreogpon.telecentro.net.ar','fuentes.telecentro.net.ar','moica2.telecentro.net.ar',
  'metricas-gdt.telecentro.net.ar','metricasnodos.telecentro.net.ar','grafana-telemetria.telecentro.net.ar'
]);
async function protect(tabId,url){
  try { const u=new URL(url||''); if(WORK_HOSTS.has(u.hostname)) await chrome.tabs.update(tabId,{autoDiscardable:false}); } catch(_){}
}
chrome.tabs.onUpdated.addListener((tabId,change,tab)=>protect(tabId,change.url||tab.url));
chrome.runtime.onInstalled.addListener(async(details)=>{
  for(const tab of await chrome.tabs.query({})) protect(tab.id,tab.url);
  await ensureUpdateAlarm();
  await ensureInstallRegistryAlarm();
  await ensureLocalBuildWatchAlarm();
  void checkUpdateInBackground();
  void sendInstallRegistryHeartbeat('installed');
  // En una actualización/recarga real de la extensión, refresca sólo la pestaña
  // primaria de cada plataforma abierta. Las duplicadas quedan intactas.
  if(details?.reason==='update') void reloadPrimaryOperationalTabs('runtime_update');
});
chrome.runtime.onStartup.addListener(async()=>{for(const tab of await chrome.tabs.query({})) protect(tab.id,tab.url); await ensureUpdateAlarm(); await ensureInstallRegistryAlarm(); await ensureLocalBuildWatchAlarm(); void checkUpdateInBackground(); void sendInstallRegistryHeartbeat('startup');});
chrome.tabs.onActivated.addListener(info=>{ void rememberPrimaryOperationalTab(info.tabId); void refreshActionBadge(info.tabId); });
chrome.tabs.onUpdated.addListener((tabId,change,tab)=>{ if(change.url && tab?.active) void rememberPrimaryOperationalTab(tabId); if(change.status==='complete'||change.url) void refreshActionBadge(tabId); });
chrome.tabs.onRemoved.addListener(tabId=>{ void forgetPrimaryOperationalTab(tabId); });
chrome.windows.onFocusChanged.addListener(()=>{ void refreshActionBadge(); });

// Comprobación periódica de actualizaciones y aviso al operador.
const VIENA_UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/fdevvv/viena-noc-tools-updates/refs/heads/main/release/latest.json';
const VIENA_DEV_UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/fdevvv/viena-noc-tools-updates/refs/heads/main/dev/self-update.json';
const IS_DEV_RUNTIME = /\bDEV\b/i.test(String(chrome.runtime.getManifest().name||''));
const UPDATE_ALARM = 'viena-update-check';
const UPDATE_CHECK_PERIOD_MINUTES = 5;
const LAST_NOTIFIED_VERSION_KEY = 'viena_last_notified_update_version';
const UPDATE_DOWNLOAD_URL_KEY = 'viena_last_update_download_url';
const UPDATE_STATE_KEY = 'viena_update_state';
const UPDATE_DISMISS_SESSION_KEY = 'viena_update_banner_dismissed';
const UPDATE_BADGE_TEXT = 'UPD';
const BACKGROUND_UPDATE_STATE_KEY = 'viena_background_update_state_v1';
const BACKGROUND_UPDATE_REQUEST_KEY = 'viena_background_update_request_v1';
const BACKGROUND_UPDATE_STALE_MS = 5 * 60 * 1000;
let detachedUpdatePromise = null;

// DEV 1.3.19 — registro técnico privado de instalaciones.
// Sólo envía metadatos técnicos; no tickets, nodos, búsquedas, URLs visitadas ni contenido operativo.
const INSTALL_REGISTRY_ENDPOINT = 'https://script.google.com/macros/s/AKfycbyDDLTQ5H3a2BMxlA_PPCiy958Jm0c5Lvu-QyoA5mUfvE3CdCvaRV8gnZgJ_Z9VItE6/exec';
const INSTALL_REGISTRY_KEY = '474fe6b9-fd2d-42ea-a14d-23d2fcb53348-f476e7ba00fe4bb68a606dc770fa1fc1';
const INSTALL_REGISTRY_ALARM = 'viena-install-registry-heartbeat';
const INSTALL_REGISTRY_RETRY_ALARM = 'viena-install-registry-retry';
const INSTALL_REGISTRY_PERIOD_MINUTES = 5;
const INSTALLATION_ID_KEY = 'viena_installation_id_v1';
const INSTALL_REGISTRY_LAST_OK_KEY = 'viena_install_registry_last_ok';
const INSTALL_REGISTRY_LAST_ERROR_KEY = 'viena_install_registry_last_error';
const INSTALL_REGISTRY_LAST_USER_KEY = 'viena_install_registry_last_user';
const INSTALL_REGISTRY_LAST_VERSION_KEY = 'viena_install_registry_last_version';
const INSTALL_REGISTRY_LAST_BUILD_KEY = 'viena_install_registry_last_build';
const INSTALL_REGISTRY_LAST_REASON_KEY = 'viena_install_registry_last_reason';


function updateProgressPreset(stage){
  const map={
    preparing:{step:1,totalSteps:5,label:'Preparando archivos…'},
    downloading:{step:2,totalSteps:5,label:'Descargando actualización…'},
    verifying:{step:3,totalSteps:5,label:'Verificando integridad…'},
    applying:{step:4,totalSteps:5,label:'Aplicando actualización…'},
    restarting:{step:5,totalSteps:5,label:'Reiniciando extensión…'},
    completed:{step:5,totalSteps:5,label:'¡Actualización completada!'},
    error:{step:0,totalSteps:5,label:'Error al actualizar'}
  };
  return map[String(stage||'')]||map.preparing;
}

async function broadcastBackgroundUpdateState(state){
  try{
    const tabs=await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'});
    await Promise.all(tabs.filter(t=>t.id).map(t=>chrome.tabs.sendMessage(t.id,{type:'VIENA_BACKGROUND_UPDATE_PROGRESS',state}).catch(()=>{})));
  }catch(_){}
}

async function setBackgroundUpdateState(patch){
  const saved=await chrome.storage.local.get([BACKGROUND_UPDATE_STATE_KEY]);
  const previous=saved[BACKGROUND_UPDATE_STATE_KEY]||{};
  const stage=String(patch?.stage||previous.stage||'preparing');
  const next={
    schema:1,
    ...previous,
    ...updateProgressPreset(stage),
    ...(patch||{}),
    stage,
    updatedAt:Date.now()
  };
  await chrome.storage.local.set({[BACKGROUND_UPDATE_STATE_KEY]:next});
  void broadcastBackgroundUpdateState(next);
  return next;
}

async function getBackgroundUpdateState(){
  const saved=await chrome.storage.local.get([BACKGROUND_UPDATE_STATE_KEY,BACKGROUND_UPDATE_REQUEST_KEY,UPDATE_JOURNAL_KEY]);
  let state=saved[BACKGROUND_UPDATE_STATE_KEY]||null;
  if(state?.expiresAt && Number(state.expiresAt)<Date.now()){
    await chrome.storage.local.remove([BACKGROUND_UPDATE_STATE_KEY]);
    return null;
  }
  if(state?.active && !detachedUpdatePromise){
    const age=Date.now()-Number(state.updatedAt||state.startedAt||0);
    const request=saved[BACKGROUND_UPDATE_REQUEST_KEY]||null;
    const journal=saved[UPDATE_JOURNAL_KEY]||null;
    if(age>BACKGROUND_UPDATE_STALE_MS){
      if(request && journal && ['prepared','writing','verifying','rollback_incomplete','awaiting_reload'].includes(String(journal.stage||''))){
        void resumeDetachedUpdateIfNeeded();
        state=await setBackgroundUpdateState({
          active:true,
          stage:journal.stage==='awaiting_reload'?'restarting':'preparing',
          label:'Recuperando actualización interrumpida…',
          detail:'El motor está retomando el proceso guardado.'
        });
      }else{
        state=await setBackgroundUpdateState({
          active:false,stage:'error',label:'Actualización interrumpida',
          error:'El proceso anterior dejó de ejecutarse. Volvé a vincular la carpeta si es necesario y repetí la actualización.',
          failedAt:Date.now(),expiresAt:Date.now()+120000
        });
      }
    }
  }
  return state;
}

function normalizeDetachedUpdateRequest(value){
  const request=value||{};
  const packageUrl=String(request.packageUrl||'');
  const packageSha256=String(request.packageSha256||'').toLowerCase();
  const expectedVersion=String(request.expectedVersion||'');
  const expectedBuild=String(request.expectedBuild||'');
  const expectedChannel=String(request.expectedChannel||'').toUpperCase();
  if(!validHttpsUrl(packageUrl) || !/^https:\/\/raw\.githubusercontent\.com\//.test(packageUrl)) throw new Error('URL de paquete no autorizada.');
  if(!/^[a-f0-9]{64}$/.test(packageSha256)) throw new Error('SHA-256 de actualización inválido.');
  if(!/^\d+\.\d+\.\d+$/.test(expectedVersion) || !['DEV','RELEASE'].includes(expectedChannel) || (expectedChannel==='DEV' && !expectedBuild)) throw new Error('Identidad de actualización inválida.');
  return {packageUrl,packageSha256,expectedVersion,expectedBuild,expectedChannel};
}

async function startDetachedUpdate(rawRequest,{resume=false}={}){
  if(detachedUpdatePromise) return {ok:true,accepted:true,alreadyRunning:true};
  const request=normalizeDetachedUpdateRequest(rawRequest);
  await chrome.storage.local.set({[BACKGROUND_UPDATE_REQUEST_KEY]:request});
  detachedUpdatePromise=(async()=>{
    try{
      const updater=globalThis.VienaLocalUpdater;
      if(!updater?.backgroundSupported?.()) throw new Error('El motor de actualización en segundo plano no está disponible.');
      await setBackgroundUpdateState({
        active:true,stage:'preparing',
        targetVersion:request.expectedVersion,targetBuild:request.expectedBuild,targetChannel:request.expectedChannel,
        startedAt:Date.now(),resume:Boolean(resume),error:''
      });
      const result=await updater.installPackage({
        ...request,
        onProgress: async progress => {
          await setBackgroundUpdateState({
            active:true,
            ...progress,
            targetVersion:request.expectedVersion,targetBuild:request.expectedBuild,targetChannel:request.expectedChannel
          });
        }
      });
      if(result?.alreadyCurrent){
        await setBackgroundUpdateState({
          active:false,stage:'completed',label:'La instalación ya estaba actualizada.',
          completedAt:Date.now(),expiresAt:Date.now()+10000
        });
        await chrome.storage.local.remove([BACKGROUND_UPDATE_REQUEST_KEY]);
        return result;
      }
      await setBackgroundUpdateState({
        active:true,stage:'restarting',step:5,totalSteps:5,
        label:'Reiniciando extensión…',detail:'Finalizando actualización.'
      });
      await checkLocalBuildForAutoReload('background_after_install');
      return result;
    }catch(error){
      await setBackgroundUpdateState({
        active:false,stage:'error',
        label:'Error al actualizar',
        error:String(error?.message||error).slice(0,500),
        failedAt:Date.now(),expiresAt:Date.now()+120000
      });
      throw error;
    }finally{
      detachedUpdatePromise=null;
    }
  })();
  detachedUpdatePromise.catch(()=>{});
  return {ok:true,accepted:true};
}

async function resumeDetachedUpdateIfNeeded(){
  try{
    const saved=await chrome.storage.local.get([BACKGROUND_UPDATE_REQUEST_KEY,UPDATE_JOURNAL_KEY,BACKGROUND_UPDATE_STATE_KEY]);
    const request=saved[BACKGROUND_UPDATE_REQUEST_KEY]||null;
    const journal=saved[UPDATE_JOURNAL_KEY]||null;
    const state=saved[BACKGROUND_UPDATE_STATE_KEY]||null;
    const runtimeVersion=String(chrome.runtime.getManifest()?.version||'');
    const pendingVersion=String(journal?.targetVersion||request?.expectedVersion||'');
    if(pendingVersion && compareVersions(runtimeVersion,pendingVersion)>0){
      await chrome.storage.local.remove([BACKGROUND_UPDATE_REQUEST_KEY,UPDATE_JOURNAL_KEY,UPDATE_LOCK_KEY]);
      await setBackgroundUpdateState({
        active:false,stage:'completed',label:'Recuperación anterior descartada.',
        detail:`La extensión ya está en v${runtimeVersion}, posterior al destino pendiente v${pendingVersion}.`,
        completedAt:Date.now(),expiresAt:Date.now()+12000
      });
      return;
    }
    if(journal?.stage==='awaiting_reload'){
      await setBackgroundUpdateState({active:true,stage:'restarting',label:'Reiniciando extensión…'});
      const reloadCheck=await checkLocalBuildForAutoReload('background_resume_awaiting_reload');
      if(reloadCheck?.changed===false && String(journal.targetBuild||'')!==VIENA_BUILD_ID){
        await setBackgroundUpdateState({
          active:false,stage:'error',label:'Actualización interrumpida',
          error:'Los archivos no llegaron al build esperado. Volvé a vincular la carpeta y repetí la actualización.',
          failedAt:Date.now(),expiresAt:Date.now()+120000
        });
      }
      return;
    }
    if(request && (state?.active || ['prepared','writing','verifying','rollback_incomplete'].includes(String(journal?.stage||'')))){
      await startDetachedUpdate(request,{resume:true});
    }
  }catch(error){
    await setBackgroundUpdateState({active:false,stage:'error',error:String(error?.message||error).slice(0,500),expiresAt:Date.now()+120000});
  }
}

async function finalizeBackgroundUpdateAfterReload(result){
  if(result?.status==='post_reload_verified'){
    await setBackgroundUpdateState({
      active:false,stage:'completed',label:'¡Actualización completada!',
      detail:'VIENA NOC Tools se actualizó correctamente.',
      completedAt:Date.now(),expiresAt:Date.now()+12000
    });
    await chrome.storage.local.remove([BACKGROUND_UPDATE_REQUEST_KEY]);
  }else if(result && result.ok===false && String(result.status||'').startsWith('post_reload_')){
    await setBackgroundUpdateState({
      active:false,stage:'error',label:'Error al verificar la actualización',
      error:String(result.detail||result.status||'Verificación post-reload fallida.').slice(0,500),
      expiresAt:Date.now()+120000
    });
  }
}

function compareVersions(a,b){
  const pa=String(a||'').split('.').map(n=>Number.parseInt(n,10)||0);
  const pb=String(b||'').split('.').map(n=>Number.parseInt(n,10)||0);
  const max=Math.max(pa.length,pb.length);
  for(let i=0;i<max;i++){
    const x=pa[i]||0,y=pb[i]||0;
    if(x!==y)return x>y?1:-1;
  }
  return 0;
}
function validHttpsUrl(value){try{return new URL(String(value||'')).protocol==='https:'}catch(_){return false}}

function installRegistryConfigured(){
  return /^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec(?:[?#].*)?$/.test(String(INSTALL_REGISTRY_ENDPOINT||''));
}

async function ensureInstallationId(){
  const saved=await chrome.storage.local.get([INSTALLATION_ID_KEY]);
  let id=String(saved[INSTALLATION_ID_KEY]||'').trim();
  if(id) return id;
  id=(globalThis.crypto?.randomUUID?.() || `viena-${Date.now()}-${Math.random().toString(36).slice(2,12)}`);
  await chrome.storage.local.set({[INSTALLATION_ID_KEY]:id});
  return id;
}

async function detectVienAUserFromOpenTab(){
  try{
    const tabs=await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'});
    const ordered=[...tabs].filter(t=>t.id).sort((a,b)=>{
      if(Boolean(a.active)!==Boolean(b.active)) return a.active?-1:1;
      return Number(b.lastAccessed||0)-Number(a.lastAccessed||0);
    });
    for(const tab of ordered){
      try{
        const result=await Promise.race([
          chrome.tabs.sendMessage(tab.id,{type:'VIENA_GET_DETECTED_USER'}),
          new Promise((_,reject)=>setTimeout(()=>reject(new Error('user_detect_timeout')),1200))
        ]);
        const usuario=String(result?.usuario||'').trim();
        if(usuario) return usuario;
      }catch(_){ }
    }
  }catch(_){ }
  return '';
}

let installRegistryHeartbeatInFlight = null;
let installRegistryLastStartedAt = 0;

async function sendInstallRegistryHeartbeat(reason='scheduled'){
  if(!installRegistryConfigured()) return {ok:false,disabled:true,reason:'endpoint_not_configured'};
  if(installRegistryHeartbeatInFlight) return installRegistryHeartbeatInFlight;
  const now=Date.now();
  if(now-installRegistryLastStartedAt<3000) return {ok:true,skipped:true,reason:'heartbeat_coalesced'};
  installRegistryLastStartedAt=now;
  installRegistryHeartbeatInFlight=(async()=>{
    try{
      const installationId=await ensureInstallationId();
      const stored=await chrome.storage.local.get(['viena_usuario']);
      let usuario=String(stored.viena_usuario||'').trim();
      if(!usuario){
        usuario=await detectVienAUserFromOpenTab();
        if(usuario) await chrome.storage.local.set({viena_usuario:usuario,viena_usuario_origen:'auto'});
      }
      if(!usuario) usuario='SIN_DETECTAR';

      const manifest=chrome.runtime.getManifest();
      const payload={
        registry_key:INSTALL_REGISTRY_KEY,
        installation_id:installationId,
        usuario_viena:usuario.slice(0,80),
        installed_version:String(manifest.version||''),
        build:VIENA_BUILD_ID,
        channel:/\bDEV\b/i.test(String(manifest.name||''))?'DEV':'RELEASE',
        reason:String(reason||'scheduled').slice(0,32),
        reported_at:new Date().toISOString()
      };

      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),7000);
      let response;
      try{
        response=await fetch(INSTALL_REGISTRY_ENDPOINT,{
          method:'POST',
          cache:'no-store',
          redirect:'follow',
          headers:{'Content-Type':'text/plain;charset=UTF-8'},
          body:JSON.stringify(payload),
          signal:controller.signal
        });
      } finally { clearTimeout(timer); }

      if(!response.ok) throw new Error(`HTTP ${response.status}`);
      let result={};
      try{ result=await response.json(); }catch(_){ result={ok:true}; }
      if(result?.ok===false) throw new Error(String(result?.error||'registry_rejected'));

      await chrome.storage.local.set({
        [INSTALL_REGISTRY_LAST_OK_KEY]:Date.now(),
        [INSTALL_REGISTRY_LAST_USER_KEY]:usuario,
        [INSTALL_REGISTRY_LAST_VERSION_KEY]:String(manifest.version||''),
        [INSTALL_REGISTRY_LAST_BUILD_KEY]:VIENA_BUILD_ID,
        [INSTALL_REGISTRY_LAST_REASON_KEY]:String(reason||'scheduled').slice(0,32)
      });
      await chrome.storage.local.remove([INSTALL_REGISTRY_LAST_ERROR_KEY]);
      try{ await chrome.alarms.clear(INSTALL_REGISTRY_RETRY_ALARM); }catch(_){}
      return {ok:true};
    }catch(error){
      const raw=String(error?.message||error);
      const normalized=(error?.name==='AbortError'||/aborted|abort/i.test(raw))?'timeout_temporal':raw.slice(0,200);
      await chrome.storage.local.set({[INSTALL_REGISTRY_LAST_ERROR_KEY]:normalized});
      await scheduleInstallRegistryRetry();
      return {ok:false,error:normalized,retryScheduled:true};
    }
  })();
  try{ return await installRegistryHeartbeatInFlight; }
  finally{ installRegistryHeartbeatInFlight=null; }
}

async function ensureInstallRegistryAlarm(){
  const existing=await chrome.alarms.get(INSTALL_REGISTRY_ALARM);
  const period=Number(existing?.periodInMinutes||0);
  if(!existing || period!==INSTALL_REGISTRY_PERIOD_MINUTES){
    if(existing) await chrome.alarms.clear(INSTALL_REGISTRY_ALARM);
    chrome.alarms.create(INSTALL_REGISTRY_ALARM,{delayInMinutes:1,periodInMinutes:INSTALL_REGISTRY_PERIOD_MINUTES});
  }
}
async function scheduleInstallRegistryRetry(){
  try{
    const existing=await chrome.alarms.get(INSTALL_REGISTRY_RETRY_ALARM);
    if(!existing) chrome.alarms.create(INSTALL_REGISTRY_RETRY_ALARM,{delayInMinutes:1});
  }catch(_){}
}

// CyBOK hardening B2: los mensajes internos privilegiados sólo se aceptan
// desde páginas de la propia extensión o content scripts en hosts operativos esperados.
// No cambia ningún flujo funcional; sólo rechaza orígenes fuera del perímetro.
function senderUrl(sender){ return String(sender?.tab?.url || sender?.url || ''); }
function senderHost(sender){ try { return new URL(senderUrl(sender)).hostname; } catch(_) { return ''; } }
function senderIsExtensionPage(sender){
  if(sender?.id!==chrome.runtime.id) return false;
  const url=senderUrl(sender);
  return Boolean(url) && url.startsWith(chrome.runtime.getURL(''));
}
function senderIsOperational(sender, allowedHosts=null){
  if(sender?.id!==chrome.runtime.id) return false;
  const host=senderHost(sender);
  if(!host) return false;
  if(Array.isArray(allowedHosts)) return allowedHosts.includes(host);
  return WORK_HOSTS.has(host);
}
function rejectUnauthorized(sendResponse){
  sendResponse?.({ok:false,code:'unauthorized_sender',detail:'Origen de mensaje no autorizado'});
}
function localDayKey(){
  const d=new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}


async function readPackageBuild(){
  try{
    const url=`${chrome.runtime.getURL(VIENA_BUILD_FILE)}?_${Date.now()}`;
    const response=await fetch(url,{cache:'no-store'});
    if(!response.ok) throw new Error(`HTTP ${response.status}`);
    const data=await response.json();
    return String(data?.build||'').trim();
  }catch(_){ return ''; }
}


// Auto-reload seguro para extensiones unpacked.
// Cuando el operador reemplaza los archivos de la carpeta, el runtime viejo detecta
// un build distinto en disco, valida que la copia esté estable y recién entonces se recarga.
const LOCAL_BUILD_WATCH_ALARM = 'viena-local-build-watch';
const LOCAL_BUILD_WATCH_PERIOD_MINUTES = 10 / 60;
const LOCAL_BUILD_STABILITY_DELAY_MS = 5 * 1000;
const AUTO_RELOAD_LAST_BUILD_KEY = 'viena_auto_reload_last_build';
const AUTO_RELOAD_CANDIDATE_KEY = 'viena_auto_reload_candidate';
const AUTO_RELOAD_LAST_ERROR_KEY = 'viena_auto_reload_last_error';
const AUTO_RELOAD_REFRESH_TABS_KEY = 'viena_auto_reload_refresh_primary_tabs';
const UPDATE_JOURNAL_KEY = 'viena_local_update_journal_v1';
const UPDATE_LOCK_KEY = 'viena_local_update_lock_v1';
const UPDATE_LAST_RESULT_KEY = 'viena_local_update_last_result_v1';
const UPDATER_CONTRACT_VERSION = 2;
let autoReloadVerificationPromise = null;

function waitMs(ms){ return new Promise(resolve=>setTimeout(resolve,ms)); }

async function readPackageJson(rel){
  const url=`${chrome.runtime.getURL(rel)}?_${Date.now()}`;
  const response=await fetch(url,{cache:'no-store'});
  if(!response.ok) throw new Error(`${rel}:HTTP_${response.status}`);
  return response.json();
}

async function readPackageBytes(rel){
  const url=`${chrome.runtime.getURL(rel)}?_${Date.now()}`;
  const response=await fetch(url,{cache:'no-store'});
  if(!response.ok) throw new Error(`${rel}:HTTP_${response.status}`);
  return response.arrayBuffer();
}

function bytesToHex(buffer){
  return [...new Uint8Array(buffer)].map(v=>v.toString(16).padStart(2,'0')).join('');
}

async function sha256PackageFile(rel){
  const bytes=await readPackageBytes(rel);
  return bytesToHex(await crypto.subtle.digest('SHA-256',bytes));
}

async function readPackageIdentity(){
  const [build,integrity]=await Promise.all([
    readPackageJson(VIENA_BUILD_FILE),
    readPackageJson('integrity-manifest.json')
  ]);
  return {
    build:String(build?.build||'').trim(),
    version:String(build?.version||'').trim(),
    channel:String(build?.channel||'').trim(),
    integrityBuild:String(integrity?.build||'').trim(),
    integrityVersion:String(integrity?.version||'').trim(),
    integrityChannel:String(integrity?.channel||'').trim(),
    integrity
  };
}

function packageIdentityMatchesCandidate(identity,candidate){
  return Boolean(
    identity?.build && identity.build===candidate &&
    identity.integrityBuild===candidate &&
    identity.version && identity.integrityVersion===identity.version &&
    identity.channel && identity.integrityChannel===identity.channel
  );
}

async function verifyPackageIntegrity(identity){
  const files=identity?.integrity?.files;
  if(!files || typeof files!=='object') return {ok:false,reason:'integrity_files_missing'};
  const entries=Object.entries(files);
  if(!entries.length) return {ok:false,reason:'integrity_files_empty'};
  for(const [rel,expected] of entries){
    const wanted=String(expected||'').trim().toLowerCase();
    if(!/^[a-f0-9]{64}$/.test(wanted)) return {ok:false,reason:`integrity_hash_invalid:${rel}`};
    let got='';
    try{ got=await sha256PackageFile(rel); }
    catch(error){ return {ok:false,reason:`integrity_read_failed:${rel}:${String(error?.message||error)}`}; }
    if(got!==wanted) return {ok:false,reason:`integrity_mismatch:${rel}`};
  }
  return {ok:true,count:entries.length};
}

async function reconcileUpdateJournalAfterRuntimeStart(reason='startup'){
  try{
    const stored=await chrome.storage.local.get([UPDATE_JOURNAL_KEY]);
    const journal=stored[UPDATE_JOURNAL_KEY];
    if(!journal) return {ok:true,skipped:true,reason:'no_journal'};
    if(String(journal.targetBuild||'')!==VIENA_BUILD_ID){
      return {ok:true,pending:true,reason:'runtime_not_target',targetBuild:String(journal.targetBuild||'')};
    }

    const identity=await readPackageIdentity();
    const manifestVersion=String(chrome.runtime.getManifest()?.version||'');
    if(!packageIdentityMatchesCandidate(identity,VIENA_BUILD_ID) || identity.version!==manifestVersion){
      const result={ok:false,status:'post_reload_identity_failed',build:VIENA_BUILD_ID,reason,finishedAt:Date.now(),updaterContract:UPDATER_CONTRACT_VERSION};
      await chrome.storage.local.set({[UPDATE_LAST_RESULT_KEY]:result});
      return result;
    }
    const integrity=await verifyPackageIntegrity(identity);
    if(!integrity.ok){
      const result={ok:false,status:'post_reload_integrity_failed',build:VIENA_BUILD_ID,detail:String(integrity.reason||'integrity_failed').slice(0,300),reason,finishedAt:Date.now(),updaterContract:UPDATER_CONTRACT_VERSION};
      await chrome.storage.local.set({[UPDATE_LAST_RESULT_KEY]:result});
      return result;
    }

    const result={
      ok:true,
      status:'post_reload_verified',
      version:manifestVersion,
      build:VIENA_BUILD_ID,
      channel:IS_DEV_RUNTIME?'DEV':'RELEASE',
      integrityFiles:integrity.count,
      reason,
      finishedAt:Date.now(),
      updaterContract:UPDATER_CONTRACT_VERSION
    };
    await chrome.storage.local.set({[UPDATE_LAST_RESULT_KEY]:result});
    await chrome.storage.local.remove([UPDATE_JOURNAL_KEY,UPDATE_LOCK_KEY]);
    return result;
  }catch(error){
    const result={ok:false,status:'post_reload_health_exception',build:VIENA_BUILD_ID,detail:String(error?.message||error).slice(0,300),reason,finishedAt:Date.now(),updaterContract:UPDATER_CONTRACT_VERSION};
    try{await chrome.storage.local.set({[UPDATE_LAST_RESULT_KEY]:result});}catch(_){}
    return result;
  }
}

async function ensureLocalBuildWatchAlarm(){
  const existing=await chrome.alarms.get(LOCAL_BUILD_WATCH_ALARM);
  const period=Number(existing?.periodInMinutes||0);
  if(!existing || period!==LOCAL_BUILD_WATCH_PERIOD_MINUTES){
    if(existing) await chrome.alarms.clear(LOCAL_BUILD_WATCH_ALARM);
    chrome.alarms.create(LOCAL_BUILD_WATCH_ALARM,{delayInMinutes:LOCAL_BUILD_WATCH_PERIOD_MINUTES,periodInMinutes:LOCAL_BUILD_WATCH_PERIOD_MINUTES});
  }
}

async function runStableBuildAutoReload(candidate){
  if(!candidate || candidate===VIENA_BUILD_ID) return {ok:false,reason:'no_new_build'};
  const saved=await chrome.storage.local.get([AUTO_RELOAD_LAST_BUILD_KEY]);
  if(saved[AUTO_RELOAD_LAST_BUILD_KEY]===candidate) return {ok:false,reason:'already_attempted'};

  await chrome.storage.local.set({[AUTO_RELOAD_CANDIDATE_KEY]:{build:candidate,detectedAt:Date.now()}});

  // 1ª comprobación: 5 segundos después de detectar el cambio.
  await waitMs(LOCAL_BUILD_STABILITY_DELAY_MS);
  let first;
  try{ first=await readPackageIdentity(); }
  catch(error){
    await chrome.storage.local.set({[AUTO_RELOAD_LAST_ERROR_KEY]:`first_check:${String(error?.message||error).slice(0,180)}`});
    return {ok:false,reason:'first_check_failed'};
  }
  if(!packageIdentityMatchesCandidate(first,candidate)){
    await chrome.storage.local.set({[AUTO_RELOAD_LAST_ERROR_KEY]:'first_check_build_changed'});
    return {ok:false,reason:'first_check_build_changed'};
  }

  // 2ª comprobación: otros 5 segundos después. Además valida todos los hashes
  // de integrity-manifest.json para no recargar una carpeta a medio copiar.
  await waitMs(LOCAL_BUILD_STABILITY_DELAY_MS);
  let second;
  try{ second=await readPackageIdentity(); }
  catch(error){
    await chrome.storage.local.set({[AUTO_RELOAD_LAST_ERROR_KEY]:`second_check:${String(error?.message||error).slice(0,180)}`});
    return {ok:false,reason:'second_check_failed'};
  }
  if(!packageIdentityMatchesCandidate(second,candidate)){
    await chrome.storage.local.set({[AUTO_RELOAD_LAST_ERROR_KEY]:'second_check_build_changed'});
    return {ok:false,reason:'second_check_build_changed'};
  }

  const integrity=await verifyPackageIntegrity(second);
  if(!integrity.ok){
    await chrome.storage.local.set({[AUTO_RELOAD_LAST_ERROR_KEY]:String(integrity.reason||'integrity_failed').slice(0,180)});
    return {ok:false,reason:integrity.reason||'integrity_failed'};
  }

  await chrome.storage.local.set({
    [AUTO_RELOAD_LAST_BUILD_KEY]:candidate,
    [AUTO_RELOAD_CANDIDATE_KEY]:{build:candidate,verifiedAt:Date.now(),integrityFiles:integrity.count},
    // El runtime nuevo consume esta marca una sola vez y recarga las páginas
    // operativas primarias que ya estaban abiertas.
    [AUTO_RELOAD_REFRESH_TABS_KEY]:{build:candidate,requestedAt:Date.now()}
  });
  await chrome.storage.local.remove([AUTO_RELOAD_LAST_ERROR_KEY]);
  chrome.runtime.reload();
  return {ok:true,reloading:true,build:candidate};
}

async function checkLocalBuildForAutoReload(reason='scheduled'){
  try{
    const diskBuild=await readPackageBuild();
    if(!diskBuild || diskBuild===VIENA_BUILD_ID) return {ok:true,changed:false};
    const saved=await chrome.storage.local.get([AUTO_RELOAD_LAST_BUILD_KEY]);
    if(saved[AUTO_RELOAD_LAST_BUILD_KEY]===diskBuild) return {ok:false,changed:true,reason:'already_attempted'};
    if(autoReloadVerificationPromise) return {ok:true,changed:true,reason:'verification_in_progress'};
    autoReloadVerificationPromise=runStableBuildAutoReload(diskBuild)
      .catch(error=>({ok:false,reason:String(error?.message||error)}))
      .finally(()=>{autoReloadVerificationPromise=null;});
    return {ok:true,changed:true,reason,build:diskBuild};
  }catch(error){
    await chrome.storage.local.set({[AUTO_RELOAD_LAST_ERROR_KEY]:String(error?.message||error).slice(0,180)});
    return {ok:false,reason:'watch_error'};
  }
}

function platformForUrl(raw){
  // MIRA5 tiene dos superficies operativas distintas para la extensión.
  // Cada una conserva su propia pestaña primaria para que una actualización
  // recargue Estadísticas y Listado de CMs de forma independiente.
  // MOICA2 sólo es operativa para la extensión en /buscarTicket.php.
  try{
    const u=new URL(raw||'');
    if(u.hostname==='viena.telecentro.net.ar') return 'viena';
    if(u.hostname==='mira5-gdt.telecentro.net.ar'||u.hostname==='mira5.telecentro.net.ar'){
      if(u.pathname.includes('stats_frontend.php')) return 'miraStats';
      if(u.pathname.includes('cablemodem_frontend.php')) return 'miraCm';
      return '';
    }
    if(u.hostname==='monitoreogpon.telecentro.net.ar') return 'gpon';
    if(u.hostname==='fuentes.telecentro.net.ar') return 'fuentes';
    if(u.hostname==='metricas-gdt.telecentro.net.ar'||u.hostname==='metricasnodos.telecentro.net.ar') return 'metricas';
    if(u.hostname==='moica2.telecentro.net.ar' && u.pathname==='/buscarTicket.php') return 'moica2';
    if(u.hostname==='grafana-telemetria.telecentro.net.ar') return 'grafana';
  }catch(_){}
  return '';
}


// Una sola pestaña primaria por plataforma. Si el operador activa otra pestaña
// de la misma plataforma, esa pasa a ser la primaria. Las duplicadas nunca se
// cierran ni se recargan en bloque.
const PRIMARY_TAB_BY_PLATFORM_KEY = 'viena_primary_tab_by_platform_v1';
const LAST_RUNTIME_BUILD_SEEN_KEY = 'viena_last_runtime_build_seen_v1';
const OPERATIONAL_PLATFORM_KEYS = ['viena','miraStats','miraCm','gpon','fuentes','moica2','grafana','metricas'];
const PLATFORM_DEFAULT_URLS = {
  viena: 'https://viena.telecentro.net.ar/',
  miraStats: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
  miraCm: 'https://mira5-gdt.telecentro.net.ar/cablemodem_frontend.php',
  gpon: 'https://monitoreogpon.telecentro.net.ar/#/listOnts',
  fuentes: 'https://fuentes.telecentro.net.ar/webs/home.php',
  moica2: 'https://moica2.telecentro.net.ar/buscarTicket.php',
  grafana: 'https://grafana-telemetria.telecentro.net.ar/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e?orgId=1',
  metricas: 'https://metricas-gdt.telecentro.net.ar/nodos/home.php'
};

async function getPrimaryTabMap(){
  const saved=await chrome.storage.local.get([PRIMARY_TAB_BY_PLATFORM_KEY]);
  const map=saved[PRIMARY_TAB_BY_PLATFORM_KEY];
  return map && typeof map==='object' ? {...map} : {};
}

async function setPrimaryOperationalTab(platform,tabId){
  if(!OPERATIONAL_PLATFORM_KEYS.includes(platform) || !Number.isInteger(Number(tabId))) return;
  const map=await getPrimaryTabMap();
  map[platform]=Number(tabId);
  await chrome.storage.local.set({[PRIMARY_TAB_BY_PLATFORM_KEY]:map});
}

async function rememberPrimaryOperationalTab(tabId){
  try{
    const tab=await chrome.tabs.get(tabId);
    const platform=platformForUrl(tab?.url);
    if(platform) await setPrimaryOperationalTab(platform,tabId);
  }catch(_){}
}

async function forgetPrimaryOperationalTab(tabId){
  try{
    const map=await getPrimaryTabMap();
    let changed=false;
    for(const key of Object.keys(map)){
      if(Number(map[key])===Number(tabId)){ delete map[key]; changed=true; }
    }
    if(changed) await chrome.storage.local.set({[PRIMARY_TAB_BY_PLATFORM_KEY]:map});
  }catch(_){}
}

async function selectPrimaryOperationalTab(platform,tabs=null){
  const all=Array.isArray(tabs)?tabs:await chrome.tabs.query({});
  const matches=all.filter(t=>t?.id && platformForUrl(t.url)===platform);
  if(!matches.length) return null;

  // El onActivated guarda cuál fue la última pestaña elegida por el operador.
  // Ese recuerdo tiene prioridad incluso si hay otras ventanas con una pestaña
  // técnicamente "active". Si no existe, usamos activa + lastAccessed.
  const map=await getPrimaryTabMap();
  const remembered=matches.find(t=>Number(t.id)===Number(map[platform]));
  if(remembered) return remembered;

  matches.sort((a,b)=>{
    if(Boolean(a.active)!==Boolean(b.active)) return a.active?-1:1;
    return Number(b.lastAccessed||0)-Number(a.lastAccessed||0) || Number(b.id||0)-Number(a.id||0);
  });
  const chosen=matches[0]||null;
  if(chosen?.id) await setPrimaryOperationalTab(platform,chosen.id);
  return chosen;
}

async function waitForTabComplete(tabId,timeout=18000,step=250){
  const start=Date.now();
  while(Date.now()-start<timeout){
    try{
      const tab=await chrome.tabs.get(tabId);
      if(tab?.status==='complete') return {ok:true,tab};
    }catch(_){ return {ok:false,code:'tab_unavailable'}; }
    await waitMs(step);
  }
  return {ok:false,code:'tab_load_timeout'};
}

async function ensureOperationalTabRuntimeCurrent(tabId){
  let tab;
  try{ tab=await chrome.tabs.get(tabId); }catch(_){ return {ok:false,code:'tab_unavailable'}; }
  const ping=await pingStatusTab(tab);
  if(ping.ok && !ping.stale) return {ok:true,reloaded:false};
  try{
    await chrome.tabs.reload(tabId);
    const loaded=await waitForTabComplete(tabId,18000,250);
    return loaded.ok ? {ok:true,reloaded:true} : loaded;
  }catch(_){ return {ok:false,code:'reload_failed'}; }
}

let reloadPrimaryOperationalTabsPromise = null;
let reloadPrimaryOperationalTabsStartedAt = 0;

async function reloadPrimaryOperationalTabs(reason='extension_reload'){
  if(reloadPrimaryOperationalTabsPromise) return reloadPrimaryOperationalTabsPromise;
  if(Date.now()-reloadPrimaryOperationalTabsStartedAt<3000) return {ok:true,reason,skipped:true,reloaded:[]};
  reloadPrimaryOperationalTabsStartedAt=Date.now();
  reloadPrimaryOperationalTabsPromise=(async()=>{
    const tabs=await chrome.tabs.query({});
    const reloaded=[];
    for(const platform of OPERATIONAL_PLATFORM_KEYS){
      const primary=await selectPrimaryOperationalTab(platform,tabs);
      if(!primary?.id) continue;
      try{
        await chrome.tabs.reload(primary.id);
        reloaded.push({platform,tabId:primary.id});
      }catch(_){}
    }
    return {ok:true,reason,reloaded};
  })();
  try{ return await reloadPrimaryOperationalTabsPromise; }
  finally{ reloadPrimaryOperationalTabsPromise=null; }
}

async function refreshTabsOnRuntimeBuildTransition(){
  try{
    const saved=await chrome.storage.local.get([LAST_RUNTIME_BUILD_SEEN_KEY]);
    const previous=String(saved[LAST_RUNTIME_BUILD_SEEN_KEY]||'').trim();
    if(!previous){
      await chrome.storage.local.set({[LAST_RUNTIME_BUILD_SEEN_KEY]:VIENA_BUILD_ID});
      // Primera ejecución de esta lógica: si las páginas ya estaban abiertas con
      // un content script viejo (por ejemplo DEV apagada mientras se copiaban
      // archivos), se recargan las primarias una sola vez.
      const tabs=await chrome.tabs.query({});
      let staleOpen=false;
      for(const platform of OPERATIONAL_PLATFORM_KEYS){
        const primary=await selectPrimaryOperationalTab(platform,tabs);
        if(!primary?.id) continue;
        const ping=await pingStatusTab(primary);
        if(!ping.ok || ping.stale){ staleOpen=true; break; }
      }
      return staleOpen ? reloadPrimaryOperationalTabs('first_runtime_reconcile') : {ok:true,firstRun:true};
    }
    if(previous===VIENA_BUILD_ID) return {ok:true,changed:false};
    await chrome.storage.local.set({[LAST_RUNTIME_BUILD_SEEN_KEY]:VIENA_BUILD_ID});
    return reloadPrimaryOperationalTabs('runtime_build_transition');
  }catch(_){ return {ok:false}; }
}

async function resumeOperationalTabsAfterSelfReload(){
  try{
    const saved=await chrome.storage.local.get([AUTO_RELOAD_REFRESH_TABS_KEY]);
    const marker=saved[AUTO_RELOAD_REFRESH_TABS_KEY];
    if(!marker || marker.build!==VIENA_BUILD_ID) return {ok:true,skipped:true};
    // One-shot: borrar antes de recargar pestañas evita repetirlo aunque el worker reinicie.
    await chrome.storage.local.remove([AUTO_RELOAD_REFRESH_TABS_KEY]);
    return reloadPrimaryOperationalTabs('self_reload');
  }catch(_){ return {ok:false}; }
}

async function focusOperationalTab(tabId){
  try{
    const tab=await chrome.tabs.update(tabId,{active:true});
    if(tab?.windowId!=null){ try{ await chrome.windows.update(tab.windowId,{focused:true}); }catch(_){} }
    return tab;
  }catch(_){ return null; }
}

async function openOperationalPlatform(platform,{background=false}={}){
  if(!OPERATIONAL_PLATFORM_KEYS.includes(platform)) return {ok:false,code:'invalid_platform'};

  const target = platform==='miraStats' ? 'mira-stats'
    : platform==='miraCm' ? 'mira-cm'
    : platform==='gpon' ? 'gpon'
    : platform==='fuentes' ? 'fuentes'
    : platform==='moica2' ? 'moica'
    : platform==='grafana' ? 'grafana-vccap' : '';

  if(target){
    const ensured=await ensureDestinationTab(target,{activate:!background});
    if(!ensured?.ok || !ensured.tabId) return {ok:false,code:ensured?.code||'open_failed'};
    await setPrimaryOperationalTab(platform,ensured.tabId);
    if(!background) await focusOperationalTab(ensured.tabId);
    return {ok:true,tabId:ensured.tabId,opened:Boolean(ensured.opened),navigated:Boolean(ensured.navigated),background:Boolean(background)};
  }

  const tabs=await chrome.tabs.query({});
  const existing=await selectPrimaryOperationalTab(platform,tabs);
  if(existing?.id){
    if(!background) await focusOperationalTab(existing.id);
    return {ok:true,tabId:existing.id,opened:false,background:Boolean(background)};
  }
  const url=PLATFORM_DEFAULT_URLS[platform];
  if(!url) return {ok:false,code:'no_default_url'};
  const created=await chrome.tabs.create({url,active:!background});
  if(!created?.id) return {ok:false,code:'open_failed'};
  await setPrimaryOperationalTab(platform,created.id);
  return {ok:true,tabId:created.id,opened:true,background:Boolean(background)};
}

async function reloadOperationalPlatform(platform){
  if(!OPERATIONAL_PLATFORM_KEYS.includes(platform)) return {ok:false,code:'invalid_platform'};
  const tabs=await chrome.tabs.query({});
  const primary=await selectPrimaryOperationalTab(platform,tabs);
  if(!primary?.id) return {ok:false,code:'closed'};
  try{
    await chrome.tabs.reload(primary.id);
    await setPrimaryOperationalTab(platform,primary.id);
    return {ok:true,tabId:primary.id};
  }catch(_){ return {ok:false,code:'reload_failed'}; }
}

const VIENA_STATUS_PING_TIMEOUT_MS = 1500;

async function sendTabStatusPing(tabId){
  let timer=0;
  try{
    return await Promise.race([
      chrome.tabs.sendMessage(tabId,{type:'VIENA_RUNTIME_STATUS_PING'}),
      new Promise((_,reject)=>{ timer=setTimeout(()=>reject(new Error('status_ping_timeout')),VIENA_STATUS_PING_TIMEOUT_MS); })
    ]);
  }finally{
    if(timer) clearTimeout(timer);
  }
}

async function pingStatusTab(tab){
  if(!tab?.id) return {ok:false,reason:'no_tab'};
  try{
    const result=await sendTabStatusPing(tab.id);
    if(!result?.ok) return {ok:false,reason:'no_receiver'};
    const runtimeVersion=chrome.runtime.getManifest().version;
    const stale=result.version!==runtimeVersion || result.build!==VIENA_BUILD_ID;
    return {ok:true,stale,version:result.version||'',build:result.build||'',href:result.href||tab.url||''};
  }catch(error){
    return {ok:false,reason:String(error?.message||error)==='status_ping_timeout'?'timeout':'no_receiver'};
  }
}

async function getOperationalStatus(){
  const runtimeVersion=chrome.runtime.getManifest().version;
  const diskBuild=await readPackageBuild();
  const extensionNeedsReload=Boolean(diskBuild && diskBuild!==VIENA_BUILD_ID);
  const tabs=await chrome.tabs.query({});
  const keys=['viena','miraStats','miraCm','gpon','fuentes','moica2','grafana','metricas'];
  const platforms={};
  await Promise.all(keys.map(async key=>{
    const matches=tabs.filter(t=>platformForUrl(t.url)===key && t.id);
    if(!matches.length){ platforms[key]={open:false,needsReload:false,tabs:0}; return; }
    const primary=await selectPrimaryOperationalTab(key,matches);
    const loading=Boolean(primary && primary.status!=='complete');
    const checked=loading ? {ok:true,stale:false,href:primary?.url||'',version:'',build:''} : (primary ? await pingStatusTab(primary) : {ok:false,reason:'no_tab'});
    platforms[key]={
      open:true,
      loading,
      needsReload:loading ? false : (!checked?.ok||Boolean(checked?.stale)),
      tabs:matches.length,
      tabId:primary?.id||matches[0].id,
      primaryTabId:primary?.id||matches[0].id,
      url:checked?.href||primary?.url||matches[0].url||'',
      version:checked?.version||'',
      build:checked?.build||'',
      statusReason:checked?.reason||''
    };
  }));
  return {ok:true,runtimeVersion,runtimeBuild:VIENA_BUILD_ID,diskBuild,extensionNeedsReload,platforms,checkedAt:Date.now()};
}

async function refreshActionBadge(tabId=null){
  try{
    const diskBuild=await readPackageBuild();
    if(diskBuild && diskBuild!==VIENA_BUILD_ID){
      const b=STATUS_BADGES.reload;
      await chrome.action.setBadgeText({text:b.text}); await chrome.action.setBadgeBackgroundColor({color:b.color}); await chrome.action.setTitle({title:b.title}); return;
    }
    let tab=null;
    if(tabId){ try{tab=await chrome.tabs.get(tabId);}catch(_){} }
    if(!tab){ const arr=await chrome.tabs.query({active:true,currentWindow:true}); tab=arr[0]||null; }
    if(tab && platformForUrl(tab.url)){
      const ping=await pingStatusTab(tab);
      if(!ping.ok||ping.stale){
        const b=STATUS_BADGES.tabs;
        await chrome.action.setBadgeText({text:b.text}); await chrome.action.setBadgeBackgroundColor({color:b.color}); await chrome.action.setTitle({title:b.title}); return;
      }
    }
    const state=await getUpdateState();
    if(state?.available){
      const b=STATUS_BADGES.update;
      await chrome.action.setBadgeText({text:b.text}); await chrome.action.setBadgeBackgroundColor({color:b.color}); await chrome.action.setTitle({title:`${b.title}: v${state.latest}`}); return;
    }
    if(tab && platformForUrl(tab.url)){
      const b=STATUS_BADGES.on;
      await chrome.action.setBadgeText({text:b.text}); await chrome.action.setBadgeBackgroundColor({color:b.color}); await chrome.action.setTitle({title:b.title}); return;
    }
    await chrome.action.setBadgeText({text:''});
    await chrome.action.setTitle({title:'VIENA NOC Tools'});
  }catch(_){ }
}

async function readRemoteUpdateManifest(){
  const controller=new AbortController();
  const timer=setTimeout(()=>controller.abort(),6000);
  try{
    const baseUrl=IS_DEV_RUNTIME?VIENA_DEV_UPDATE_MANIFEST_URL:VIENA_UPDATE_MANIFEST_URL;
    const freshUrl=`${baseUrl}${baseUrl.includes('?')?'&':'?'}_=${Date.now()}`;
    const response=await fetch(freshUrl,{cache:'no-store',signal:controller.signal,headers:{'Cache-Control':'no-cache'}});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    const data=await response.json();
    if(IS_DEV_RUNTIME){
      const latest=String(data?.version||'').trim();
      const latestBuild=String(data?.build||'').trim();
      const channel=String(data?.channel||'').toUpperCase();
      if(!/^\d+\.\d+\.\d+$/.test(latest) || !latestBuild || channel!=='DEV') throw new Error('manifest DEV inválido');
      return {...data,latest,latestBuild,channel:'DEV'};
    }
    const latest=String(data?.latest||'').trim();
    if(!/^\d+\.\d+\.\d+$/.test(latest))throw new Error('latest inválido');
    const latestBuild=String(data?.build||'').trim();
    return {...data,latest,latestBuild,channel:'RELEASE'};
  } finally { clearTimeout(timer); }
}

function updateNoticeKey(state){
  return String(state?.channel||'').toUpperCase()==='DEV'
    ? String(state?.latestBuild||state?.latest||'')
    : String(state?.latest||'');
}

async function isBannerDismissed(latest){
  try{
    const saved=await chrome.storage.session.get([UPDATE_DISMISS_SESSION_KEY]);
    const v=saved[UPDATE_DISMISS_SESSION_KEY];
    return v?.version===latest && v?.date===localDayKey();
  }catch(_){ return false; }
}

async function setUpdateState(state){
  await chrome.storage.local.set({[UPDATE_STATE_KEY]:state});
}

async function getUpdateState(){
  const saved=await chrome.storage.local.get([UPDATE_STATE_KEY]);
  return saved[UPDATE_STATE_KEY]||{available:false};
}

async function broadcastUpdateBanner(state,{force=false}={}){
  if(!force && (!state?.available || await isBannerDismissed(updateNoticeKey(state)))) return;
  const tabs=await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'});
  await Promise.allSettled(tabs.filter(t=>t.id).map(t=>chrome.tabs.sendMessage(t.id,{type:'VIENA_UPDATE_BANNER_SHOW',state,force})));
}

async function hideUpdateBannerEverywhere(){
  const tabs=await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'});
  await Promise.allSettled(tabs.filter(t=>t.id).map(t=>chrome.tabs.sendMessage(t.id,{type:'VIENA_UPDATE_BANNER_HIDE'})));
}

async function showUpdateNotification(latest,downloadUrl,{force=false}={}){
  const notificationId=`viena-update-${latest}`;
  const permissionLevel=await chrome.notifications.getPermissionLevel();
  if(permissionLevel!=='granted') return {created:false,permissionLevel};
  if(!force){
    const saved=await chrome.storage.local.get([LAST_NOTIFIED_VERSION_KEY]);
    if(saved[LAST_NOTIFIED_VERSION_KEY]===latest)return {created:false,permissionLevel};
  }
  if(validHttpsUrl(downloadUrl)) await chrome.storage.local.set({[UPDATE_DOWNLOAD_URL_KEY]:downloadUrl});
  await chrome.notifications.create(notificationId,{
    type:'basic',
    iconUrl:'icon128.png',
    title:'VIENA NOC Tools',
    message:force ? 'Prueba DEV: las notificaciones de actualización están funcionando.' : `Nueva versión ${latest} disponible. Abrí VIENA NOC Tools para actualizar.`,
    priority:2,
    requireInteraction:true
  });
  if(!force) await chrome.storage.local.set({[LAST_NOTIFIED_VERSION_KEY]:latest});
  return {created:true,permissionLevel};
}

async function checkUpdateInBackground(){
  try{
    const data=await readRemoteUpdateManifest();
    const installed=chrome.runtime.getManifest().version;
    const available=IS_DEV_RUNTIME
      ? String(data.latestBuild||'')!==VIENA_BUILD_ID
      : compareVersions(data.latest,installed)>0;
    if(!available){
      await setUpdateState({
        available:false,installed,latest:data.latest,latestBuild:data.latestBuild||'',channel:data.channel||'RELEASE',checkedAt:Date.now()
      });
      await refreshActionBadge();
      await hideUpdateBannerEverywhere();
      return {ok:true,state:await getUpdateState()};
    }
    const mandatory=!IS_DEV_RUNTIME && (data.mandatory===true || (data.minimum && compareVersions(installed,String(data.minimum))<0));
    const state={
      available:true,
      installed,
      latest:data.latest,
      latestBuild:data.latestBuild||'',
      channel:data.channel||(IS_DEV_RUNTIME?'DEV':'RELEASE'),
      mandatory:!!mandatory,
      downloadUrl:validHttpsUrl(data.download_url)?data.download_url:'',
      packageUrl:validHttpsUrl(data.package_url)?data.package_url:'',
      packageSha256:/^[a-f0-9]{64}$/i.test(String(data.package_sha256||''))?String(data.package_sha256).toLowerCase():'',
      notes:Array.isArray(data.notes)?data.notes.filter(Boolean).slice(0,4):[],
      checkedAt:Date.now()
    };
    await setUpdateState(state);
    if(state.downloadUrl) await chrome.storage.local.set({[UPDATE_DOWNLOAD_URL_KEY]:state.downloadUrl});
    await refreshActionBadge();
    await broadcastUpdateBanner(state);
    const noticeKey=updateNoticeKey(state);
    void showUpdateNotification(noticeKey,state.downloadUrl);
    return {ok:true,state};
  }catch(error){
    return {ok:false,error:String(error?.name==='AbortError'?'tiempo de espera agotado':error?.message||error||'error desconocido')};
  }
}

async function ensureUpdateAlarm(){
  const existing=await chrome.alarms.get(UPDATE_ALARM);
  const period=Number(existing?.periodInMinutes||0);
  if(!existing || period!==UPDATE_CHECK_PERIOD_MINUTES){
    if(existing) await chrome.alarms.clear(UPDATE_ALARM);
    chrome.alarms.create(UPDATE_ALARM,{delayInMinutes:1,periodInMinutes:UPDATE_CHECK_PERIOD_MINUTES});
  }
}

chrome.alarms.onAlarm.addListener(alarm=>{if(alarm?.name===UPDATE_ALARM)void checkUpdateInBackground(); if(alarm?.name===INSTALL_REGISTRY_ALARM)void sendInstallRegistryHeartbeat('alarm'); if(alarm?.name===INSTALL_REGISTRY_RETRY_ALARM)void sendInstallRegistryHeartbeat('retry'); if(alarm?.name===LOCAL_BUILD_WATCH_ALARM)void checkLocalBuildForAutoReload('alarm');});
chrome.notifications.onClicked.addListener(async id=>{
  if(!String(id||'').startsWith('viena-update-'))return;
  const saved=await chrome.storage.local.get([UPDATE_DOWNLOAD_URL_KEY]);
  const url=saved[UPDATE_DOWNLOAD_URL_KEY];
  if(validHttpsUrl(url)) await chrome.tabs.create({url});
});
void ensureUpdateAlarm();
void ensureInstallRegistryAlarm();
void ensureLocalBuildWatchAlarm();
void checkUpdateInBackground();
void checkLocalBuildForAutoReload('service_worker');
void sendInstallRegistryHeartbeat('service_worker');
void reconcileUpdateJournalAfterRuntimeStart('service_worker').then(finalizeBackgroundUpdateAfterReload).catch(()=>{});
void resumeDetachedUpdateIfNeeded();
void refreshTabsOnRuntimeBuildTransition();
void resumeOperationalTabsAfterSelfReload();

chrome.storage.onChanged.addListener((changes,area)=>{
  if(area==='local' && changes?.viena_usuario?.newValue) void sendInstallRegistryHeartbeat('usuario_changed');
});



chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg?.type==='VIENA_BACKGROUND_UPDATE_START'){
    if(!senderIsExtensionPage(sender)){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const request=normalizeDetachedUpdateRequest(msg.request);
      const current=await getBackgroundUpdateState();
      if(current?.active) return {ok:true,accepted:true,alreadyRunning:true,state:current};
      return startDetachedUpdate(request);
    })().then(sendResponse).catch(error=>sendResponse({ok:false,error:String(error?.message||error)}));
    return true;
  }
  if(msg?.type==='VIENA_BACKGROUND_UPDATE_RESUME'){
    if(!senderIsExtensionPage(sender)){ rejectUnauthorized(sendResponse); return; }
    resumeDetachedUpdateIfNeeded().then(()=>sendResponse({ok:true})).catch(error=>sendResponse({ok:false,error:String(error?.message||error)}));
    return true;
  }
  if(msg?.type==='VIENA_BACKGROUND_UPDATE_GET'){
    if(!senderIsExtensionPage(sender) && !senderIsOperational(sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    getBackgroundUpdateState().then(state=>sendResponse({ok:true,state})).catch(error=>sendResponse({ok:false,error:String(error?.message||error)}));
    return true;
  }
});

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg?.type!=='VIENA_TRIGGER_LOCAL_BUILD_CHECK') return;
  if(!senderIsExtensionPage(sender)){ rejectUnauthorized(sendResponse); return; }
  checkLocalBuildForAutoReload('popup_after_install')
    .then(sendResponse)
    .catch(error=>sendResponse({ok:false,reason:String(error?.message||error)}));
  return true;
});

const DESTINATION_CONFIGS = {
  'mira-stats': {
    url: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
    matches: u => u.hostname === 'mira5-gdt.telecentro.net.ar' && u.pathname.includes('stats_frontend.php')
  },
  'mira-cm': {
    url: 'https://mira5-gdt.telecentro.net.ar/cablemodem_frontend.php',
    matches: u => u.hostname === 'mira5-gdt.telecentro.net.ar' && u.pathname.includes('cablemodem_frontend.php')
  },
  'gpon': {
    url: 'https://monitoreogpon.telecentro.net.ar/#/listOnts',
    matches: u => u.hostname === 'monitoreogpon.telecentro.net.ar'
  },
  'fuentes': {
    url: 'https://fuentes.telecentro.net.ar/webs/home.php',
    matches: u => u.hostname === 'fuentes.telecentro.net.ar' && u.pathname.includes('/webs/home.php')
  },
  'moica': {
    url: 'https://moica2.telecentro.net.ar/buscarTicket.php',
    // Reutilizar únicamente la pantalla limpia de Buscar Ticket.
    // Una URL con ?ticket=... representa un ticket ya abierto y NO debe ser
    // secuestrada por una nueva búsqueda iniciada desde VIENA.
    matches: u =>
      u.hostname === 'moica2.telecentro.net.ar' &&
      u.pathname === '/buscarTicket.php' &&
      !u.search &&
      !u.hash
  },
  'grafana-vccap': {
    url: 'https://grafana-telemetria.telecentro.net.ar/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e?orgId=1',
    matches: u => u.hostname === 'grafana-telemetria.telecentro.net.ar' && u.pathname.startsWith('/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e')
  }
};

function preferredMatchingTab(tabs,cfg){
  const matches=tabs.filter(t=>{
    if(!t?.id) return false;
    try{return cfg.matches(new URL(t.url||''));}catch(_){return false;}
  });
  matches.sort((a,b)=>{
    if(Boolean(a.active)!==Boolean(b.active)) return a.active?-1:1;
    return Number(b.lastAccessed||0)-Number(a.lastAccessed||0) || Number(b.id||0)-Number(a.id||0);
  });
  return matches[0]||null;
}

function targetForBridgeCommand(command){
  const tipo=String(command?.tipo||'').toLowerCase();
  const tecnologia=String(command?.tecnologia||'').toUpperCase();
  if(tecnologia==='FTTH') return 'gpon';
  if(tecnologia==='HFC' && tipo==='nodo') return 'mira-stats';
  if(tecnologia==='HFC' && ['edificio','cliente','nodocm','nodolist'].includes(tipo)) return 'mira-cm';
  return '';
}

async function waitTabMatches(tabId,matches,timeout=18000,step=250){
  const start=Date.now();
  while(Date.now()-start<timeout){
    try{
      const tab=await chrome.tabs.get(tabId);
      const url=new URL(tab.url||'');
      if(matches(url)) return {ok:true,tab};
    }catch(_){ return {ok:false,code:'tab_unavailable'}; }
    await new Promise(r=>setTimeout(r,step));
  }
  return {ok:false,code:'navigation_timeout'};
}

async function prepareOpenedDestination(target,tabId){
  if(!tabId) return {ok:false,code:'missing_tab'};
  if(target!=='mira-stats' && target!=='moica') return {ok:true};

  const message=target==='mira-stats'
    ? {type:'VIENA_MIRA5_NAVIGATE',target}
    : {type:'VIENA_MOICA_NAVIGATE'};
  const delivered=await sendMessageWithRetry(tabId,message,{timeout:18000,step:300});
  if(!delivered.ok) return {ok:false,code:'receiver_unavailable'};
  if(!delivered.result?.ok) return {ok:false,code:delivered.result?.code||'navigation_failed'};

  const cfg=DESTINATION_CONFIGS[target];
  const reached=cfg ? await waitTabMatches(tabId,cfg.matches,18000,250) : {ok:true};
  return reached.ok ? {ok:true,navigated:Boolean(delivered.result?.navigated)} : reached;
}

async function ensureDestinationTab(target,{activate=true}={}){
  const cfg=DESTINATION_CONFIGS[target];
  if(!cfg) return {ok:false,code:'invalid_target'};
  const tabs=await chrome.tabs.query({});
  const existing=preferredMatchingTab(tabs,cfg);
  if(existing?.id){
    const current=await ensureOperationalTabRuntimeCurrent(existing.id);
    if(!current?.ok) return {ok:false,opened:false,navigated:false,tabId:existing.id,url:existing.url||cfg.url,code:current?.code||'reload_failed'};
    await rememberPrimaryOperationalTab(existing.id);
    return {ok:true,opened:false,navigated:false,reloaded:Boolean(current.reloaded),tabId:existing.id,url:existing.url||cfg.url};
  }

  // Primer acceso a MIRA5 puede redirigir stats_frontend.php al home/index.php.
  // Si ya existe ese landing, lo reutilizamos y entramos por el botón nativo Estadísticas.
  if(target==='mira-stats'){
    const landing=[...tabs].filter(t=>{
      try{
        const u=new URL(t.url||'');
        return t?.id && u.hostname==='mira5-gdt.telecentro.net.ar' && (u.pathname==='/' || u.pathname.endsWith('/index.php'));
      }catch(_){return false;}
    }).sort((a,b)=>Boolean(b.active)-Boolean(a.active) || Number(b.lastAccessed||0)-Number(a.lastAccessed||0))[0];
    if(landing?.id){
      const current=await ensureOperationalTabRuntimeCurrent(landing.id);
      if(!current?.ok) return {ok:false,opened:false,navigated:false,tabId:landing.id,url:landing.url||cfg.url,code:current?.code||'reload_failed'};
      const prepared=await prepareOpenedDestination(target,landing.id);
      if(prepared?.ok){
        return {ok:true,opened:false,navigated:true,tabId:landing.id,url:landing.url||cfg.url};
      }
    }
  }

  // Primer acceso a MOICA2 puede aterrizar en /home.php. Si existe ese landing,
  // reutilizamos la pestaña y tocamos el enlace nativo "Buscar" hacia buscarTicket.php.
  if(target==='moica'){
    const landing=[...tabs].filter(t=>{
      try{
        const u=new URL(t.url||'');
        return t?.id && u.hostname==='moica2.telecentro.net.ar' && (u.pathname==='/' || u.pathname.endsWith('/home.php'));
      }catch(_){return false;}
    }).sort((a,b)=>Boolean(b.active)-Boolean(a.active) || Number(b.lastAccessed||0)-Number(a.lastAccessed||0))[0];
    if(landing?.id){
      const current=await ensureOperationalTabRuntimeCurrent(landing.id);
      if(!current?.ok) return {ok:false,opened:false,navigated:false,tabId:landing.id,url:landing.url||cfg.url,code:current?.code||'reload_failed'};
      const prepared=await prepareOpenedDestination(target,landing.id);
      if(prepared?.ok){
        return {ok:true,opened:false,navigated:true,tabId:landing.id,url:cfg.url};
      }
    }
  }

  const created=await chrome.tabs.create({url:cfg.url,active:Boolean(activate)});
  if(!created?.id) return {ok:false,opened:false,navigated:false,tabId:null,url:cfg.url};

  const prepared=await prepareOpenedDestination(target,created.id);
  if(!prepared?.ok && (target==='mira-stats' || target==='moica')){
    return {ok:false,opened:true,navigated:false,tabId:created.id,url:cfg.url,code:prepared?.code||'navigation_failed'};
  }

  await rememberPrimaryOperationalTab(created.id);
  return {ok:true,opened:true,navigated:Boolean(target==='mira-stats' || target==='moica'),reloaded:false,tabId:created.id,url:cfg.url};
}

async function sendMessageWithRetry(tabId,message,{timeout=20000,step=300}={}){
  const start=Date.now();
  let lastError=null;
  while(Date.now()-start<timeout){
    try{
      const result=await chrome.tabs.sendMessage(tabId,message);
      return {ok:true,result};
    }catch(error){
      lastError=error;
      await new Promise(r=>setTimeout(r,step));
    }
  }
  return {ok:false,error:lastError};
}


async function getFaviconBytes(pageUrl){
  try{
    const parsed=new URL(String(pageUrl||''));
    if(parsed.protocol!=='https:') return {ok:false,detail:'URL de favicon inválida'};
    const faviconUrl=chrome.runtime.getURL(`/_favicon/?pageUrl=${encodeURIComponent(parsed.href)}&size=32`);
    const response=await fetch(faviconUrl);
    if(!response.ok) return {ok:false,detail:`favicon HTTP ${response.status}`};
    const buffer=await response.arrayBuffer();
    if(!buffer.byteLength) return {ok:false,detail:'favicon vacío'};
    return {ok:true,mime:response.headers.get('content-type')||'image/png',bytes:Array.from(new Uint8Array(buffer))};
  }catch(error){
    return {ok:false,detail:String(error?.message||error)};
  }
}

// Self-Test Operativo (efoschi): enruta inspecciones de sólo lectura al destino abierto.
chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg?.type==='VIENA_RUNTIME_STATUS_HELLO'){
    if(!senderIsOperational(_sender)){ rejectUnauthorized(sendResponse); return; }
    void refreshActionBadge(_sender?.tab?.id||null);
    sendResponse({ok:true});
    return;
  }
  if(msg?.type==='VIENA_GET_OPERATIONAL_STATUS'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    getOperationalStatus().then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_INSTALL_REGISTRY_HEARTBEAT_NOW' || msg?.type==='VIENA_INSTALL_REGISTRY_SYNC_NOW'){
    if(!senderIsExtensionPage(_sender) && !senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    sendInstallRegistryHeartbeat(String(msg.reason||'manual')).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_GET_INSTALL_REGISTRY_STATUS'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const keys=[INSTALL_REGISTRY_LAST_OK_KEY,INSTALL_REGISTRY_LAST_ERROR_KEY,INSTALL_REGISTRY_LAST_USER_KEY,INSTALL_REGISTRY_LAST_VERSION_KEY,INSTALL_REGISTRY_LAST_BUILD_KEY,INSTALL_REGISTRY_LAST_REASON_KEY,INSTALLATION_ID_KEY,'viena_usuario','viena_usuario_origen'];
      const st=await chrome.storage.local.get(keys);
      const alarm=await chrome.alarms.get(INSTALL_REGISTRY_ALARM);
      return {ok:true,lastOk:Number(st[INSTALL_REGISTRY_LAST_OK_KEY]||0),lastError:String(st[INSTALL_REGISTRY_LAST_ERROR_KEY]||''),lastUser:String(st[INSTALL_REGISTRY_LAST_USER_KEY]||''),lastVersion:String(st[INSTALL_REGISTRY_LAST_VERSION_KEY]||''),lastBuild:String(st[INSTALL_REGISTRY_LAST_BUILD_KEY]||''),lastReason:String(st[INSTALL_REGISTRY_LAST_REASON_KEY]||''),installationId:String(st[INSTALLATION_ID_KEY]||''),usuario:String(st.viena_usuario||''),origen:String(st.viena_usuario_origen||''),alarmNext:Number(alarm?.scheduledTime||0)};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_DETECT_USER_NOW'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const usuario=await detectVienAUserFromOpenTab();
      if(usuario) await chrome.storage.local.set({viena_usuario:usuario,viena_usuario_origen:'auto'});
      return {ok:true,usuario:usuario||''};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_PLATFORM_ACTION'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    const platform=String(msg.platform||'');
    const action=String(msg.action||'');
    const job=action==='open' ? openOperationalPlatform(platform,{background:Boolean(msg.background)})
      : action==='reload' ? reloadOperationalPlatform(platform)
      : Promise.resolve({ok:false,code:'invalid_action'});
    job.then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_REFRESH_ACTION_STATUS'){
    if(!senderIsExtensionPage(_sender) && !senderIsOperational(_sender)){ rejectUnauthorized(sendResponse); return; }
    refreshActionBadge(_sender?.tab?.id||null).then(()=>sendResponse({ok:true})).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_GET_FAVICON_BYTES'){
    if(!senderIsOperational(_sender)){ rejectUnauthorized(sendResponse); return; }
    getFaviconBytes(msg.pageUrl).then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_BRIDGE_AVAILABLE'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const target=String(msg.target||'');
      const ensured=await ensureDestinationTab(target);
      if(!ensured?.ok||!ensured.tabId) return {ok:false,code:ensured?.code||'open_failed'};
      const ping=await sendMessageWithRetry(ensured.tabId,{type:'VIENA_BRIDGE_PING_DIRECT',target},{timeout:ensured.opened||ensured.navigated||ensured.reloaded?18000:2500,step:250});
      return ping.ok && ping.result?.ok ? {ok:true,tabId:ensured.tabId,opened:!!ensured.opened,navigated:!!ensured.navigated} : {ok:false,code:'receiver_unavailable',tabId:ensured.tabId};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_BRIDGE_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const command=msg.command&&typeof msg.command==='object'?msg.command:null;
      const target=targetForBridgeCommand(command);
      if(!target) return {ok:false,estado:'error',mensaje:'Destino inválido.'};
      const ensured=await ensureDestinationTab(target);
      if(!ensured?.ok||!ensured.tabId) return {ok:false,estado:'sin_respuesta',mensaje:'No se pudo abrir la página destino.'};
      const delivered=await sendMessageWithRetry(ensured.tabId,{type:'VIENA_BRIDGE_RUN',command,target},{timeout:22000,step:250});
      if(!delivered.ok) return {ok:false,estado:'sin_respuesta',mensaje:'La página destino no respondió. Recargá esa pestaña.'};
      return {...(delivered.result||{ok:false,estado:'error'}),tabId:ensured.tabId,opened:!!ensured.opened,navigated:!!ensured.navigated};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,estado:'error',mensaje:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_FUENTES_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const nodo=String(msg.nodo||'').trim().toUpperCase();
      const modo=String(msg.modo||'fuentes').toLowerCase();
      if(!nodo) return {ok:false,code:'invalid_node'};
      const ensured=await ensureDestinationTab('fuentes');
      if(!ensured?.ok||!ensured.tabId) return {ok:false,code:ensured?.code||'open_failed'};
      const delivered=await sendMessageWithRetry(ensured.tabId,{type:'VIENA_FUENTES_RUN',nodo,modo},{timeout:22000,step:250});
      if(!delivered.ok) return {ok:false,code:'receiver_unavailable'};
      return {...(delivered.result||{ok:false}),tabId:ensured.tabId,opened:!!ensured.opened};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_ENSURE_DESTINATION'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    ensureDestinationTab(String(msg.target||'')).then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_MOICA_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const nodo=String(msg.nodo||'').trim().toUpperCase();
      if(!nodo)return {ok:false,code:'invalid_node',mensaje:'Nodo inválido para MOICA.'};
      const ensured=await ensureDestinationTab('moica');
      if(!ensured?.ok||!ensured.tabId){
        return {ok:false,code:ensured?.code||'open_failed',mensaje:'No se pudo abrir MOICA Buscar Ticket.'};
      }
      const delivered=await sendMessageWithRetry(ensured.tabId,{type:'VIENA_MOICA_SEARCH_RUN',nodo},{timeout:22000,step:250});
      if(!delivered.ok){
        return {ok:false,code:'receiver_unavailable',mensaje:'MOICA está abierto, pero el receptor de VIENA NOC Tools no respondió. Recargá esa pestaña.'};
      }
      return delivered.result?.ok ? {...delivered.result,opened:Boolean(ensured.opened),navigated:Boolean(ensured.navigated)} : {ok:false,code:delivered.result?.code||'search_failed',mensaje:delivered.result?.mensaje||'MOICA recibió la orden pero no pudo iniciar la búsqueda.'};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',mensaje:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_GRAFANA_VCCAP_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const nodo=String(msg.nodo||'').trim().toUpperCase();
      const cos=String(msg.cos||'').trim();
      if(!nodo||!cos)return {ok:false,code:'invalid',mensaje:'Nodo o COS inválido.'};

      const ensured=await ensureDestinationTab('grafana-vccap');
      if(!ensured?.ok||!ensured.tabId){
        return {ok:false,code:'open_failed',mensaje:'No se pudo abrir el dashboard VCCAP de Grafana.'};
      }

      const message={type:'VIENA_GRAFANA_VCCAP_RUN',nodo,cos};
      if(ensured.opened || ensured.reloaded){
        const delivered=await sendMessageWithRetry(ensured.tabId,message,{timeout:25000,step:300});
        if(!delivered.ok){
          return {ok:false,code:'receiver_unavailable',mensaje:'Grafana se abrió, pero el receptor de VIENA NOC Tools no quedó disponible a tiempo.'};
        }
        const result=delivered.result;
        return result?.ok ? result : {ok:false,code:'failed',mensaje:result?.mensaje||'Grafana recibió la orden pero no pudo completar el filtro.'};
      }

      try{
        const result=await chrome.tabs.sendMessage(ensured.tabId,message);
        return result?.ok ? result : {ok:false,code:'failed',mensaje:result?.mensaje||'Grafana recibió la orden pero no pudo completar el filtro.'};
      }catch(error){
        return {ok:false,code:'receiver_unavailable',mensaje:'Grafana ya está abierto, pero no respondió. Verificá la sesión o recargá esa pestaña.'};
      }
    })().then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',mensaje:String(e?.message||e)}));
    return true;
  }

  if(msg?.type==='VIENA_UPDATE_CHECK_NOW'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    checkUpdateInBackground().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_UPDATE_BANNER_GET_STATE'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const state=await getUpdateState();
      const dismissed=state?.available ? await isBannerDismissed(updateNoticeKey(state)) : false;
      return {ok:true,state,dismissed};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_UPDATE_BANNER_DISMISS'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    const latest=String(msg.latest||'').trim();
    if(latest) chrome.storage.session.set({[UPDATE_DISMISS_SESSION_KEY]:{version:latest,date:localDayKey()}}).then(()=>sendResponse({ok:true})).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    else sendResponse({ok:false,detail:'Versión inválida'});
    return true;
  }
  if(msg?.type==='VIENA_UPDATE_OPEN_DOWNLOAD'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const url=String(msg.url||'');
      if(!validHttpsUrl(url)) return {ok:false,detail:'URL inválida'};
      const state=await getUpdateState();
      const expected=String(state?.downloadUrl||'');
      if(!expected || url!==expected) return {ok:false,code:'untrusted_update_url',detail:'URL de actualización no autorizada'};
      await chrome.tabs.create({url});
      return {ok:true};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_DEV_TEST_UPDATE_BANNER'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    const testState={available:true,installed:chrome.runtime.getManifest().version,latest:chrome.runtime.getManifest().version,latestBuild:'DEV-TEST',channel:'DEV',mandatory:false,downloadUrl:'',notes:['Prueba visual del aviso dentro de VIENA.'],checkedAt:Date.now(),test:true};
    broadcastUpdateBanner(testState,{force:true}).then(()=>sendResponse({ok:true})).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type!=='VIENA_SELFTEST_INSPECT') return;
  if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
  (async()=>{
    const target=msg.spec?.target;
    const hosts= target==='mira-stats'||target==='mira-cm' ? ['mira5-gdt.telecentro.net.ar','mira5.telecentro.net.ar']
      : target==='gpon' ? ['monitoreogpon.telecentro.net.ar']
      : target==='fuentes' ? ['fuentes.telecentro.net.ar']
      : target==='moica' ? ['moica2.telecentro.net.ar'] : [];
    const tabs=await chrome.tabs.query({});
    const tab=tabs.find(t=>{try{return hosts.includes(new URL(t.url||'').hostname)}catch(_){return false}});
    if(!tab?.id)return {ok:false,detail:'Pestaña destino no está abierta'};
    try{return await chrome.tabs.sendMessage(tab.id,{type:'VIENA_SELFTEST_INSPECT_PAGE',spec:msg.spec});}
    catch(e){return {ok:false,detail:'Inspector no disponible en la pestaña destino'};}
  })().then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
  return true;
});
