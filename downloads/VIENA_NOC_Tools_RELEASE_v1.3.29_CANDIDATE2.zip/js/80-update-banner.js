(() => {
  'use strict';
  const HOST_ID='viena-noc-update-banner-host';
  let currentVersion='';
  let currentForce=false;
  const CONTENT_BUILD_ID='1.3.29-release-update-registry-assignments-candidate2';
  let dismissedDevBuild='';

  function removeBanner(){
    document.getElementById(HOST_ID)?.remove();
    currentVersion='';
    currentForce=false;
  }

  function safeText(v){return String(v??'').trim();}

  function renderBanner(state,{force=false}={}){
    if(!state?.available)return removeBanner();
    const version=safeText(state.latest);
    const isDev=String(state.channel||'').toUpperCase()==='DEV';
    const latestBuild=safeText(state.latestBuild);
    if(!version)return;
    if(document.getElementById(HOST_ID) && currentVersion===version && currentForce===force)return;
    removeBanner();
    currentVersion=version;
    currentForce=force;

    const host=document.createElement('div');
    host.id=HOST_ID;
    host.style.cssText='all:initial;position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483647;width:min(760px,calc(100vw - 28px));pointer-events:none;';
    const shadow=host.attachShadow({mode:'closed'});
    const wrap=document.createElement('div');
    wrap.setAttribute('role','status');
    wrap.style.cssText='box-sizing:border-box;pointer-events:auto;display:flex;align-items:center;gap:14px;width:100%;padding:12px 14px;border:1px solid #d7a72e;border-left:5px solid #d97706;border-radius:10px;background:#fff9e8;color:#253247;box-shadow:0 8px 28px rgba(20,38,63,.24);font:15px/1.4 Arial,Helvetica,sans-serif;';

    const text=document.createElement('div');
    text.style.cssText='flex:1;min-width:0;';
    const title=document.createElement('div');
    title.style.cssText='font-weight:700;font-size:18px;margin-bottom:3px;';
    title.textContent=state.test?'Prueba del aviso de actualización':(isDev?'Nuevo build DEV disponible':(state.mandatory?`Actualización requerida: v${version}`:`Nueva versión disponible: v${version}`));
    const sub=document.createElement('div');
    sub.style.cssText='font-size:14px;color:#536174;';
    sub.textContent=state.test?'Este aviso aparecerá dentro de VIENA cuando se publique una actualización del canal activo.':(isDev?`Build publicado: ${latestBuild||version}. Abrí el popup y usá Actualizar DEV.`:`Tenés instalada la v${safeText(state.installed)}. Actualizá cuando puedas para usar la última versión.`);
    text.append(title,sub);

    const actions=document.createElement('div');
    actions.style.cssText='display:flex;align-items:center;gap:8px;flex:0 0 auto;';
    if(state.downloadUrl){
      const download=document.createElement('button');
      download.type='button';
      download.textContent='Descargar actualización';
      download.style.cssText='border:0;border-radius:7px;padding:8px 11px;background:#0b5cab;color:white;font:600 13px Arial,Helvetica,sans-serif;cursor:pointer;';
      download.addEventListener('click',e=>{e.stopPropagation();void chrome.runtime.sendMessage({type:'VIENA_UPDATE_OPEN_DOWNLOAD',url:state.downloadUrl});});
      actions.appendChild(download);
    }
    const close=document.createElement('button');
    close.type='button';
    close.textContent='×';
    close.title='Cerrar aviso';
    close.setAttribute('aria-label','Cerrar aviso');
    close.style.cssText='border:0;background:transparent;color:#536174;font:700 20px/1 Arial,Helvetica,sans-serif;cursor:pointer;padding:4px 6px;';
    close.addEventListener('click',e=>{
      e.stopPropagation();
      removeBanner();
      if(!force && !state.test){
        if(isDev) dismissedDevBuild=latestBuild||version;
        void chrome.runtime.sendMessage({type:'VIENA_UPDATE_BANNER_DISMISS',latest:(isDev?(latestBuild||version):version)});
      }
    });
    actions.appendChild(close);
    wrap.append(text,actions);
    shadow.appendChild(wrap);
    (document.body||document.documentElement).appendChild(host);
  }

  chrome.runtime.onMessage.addListener(msg=>{
    if(msg?.type==='VIENA_UPDATE_BANNER_SHOW')renderBanner(msg.state,{force:!!msg.force});
    if(msg?.type==='VIENA_UPDATE_BANNER_HIDE'){removeBanner(); if(IS_DEV_CONTENT) setTimeout(()=>void checkDevChannel(),120);}
  });

  chrome.runtime.sendMessage({type:'VIENA_UPDATE_BANNER_GET_STATE'}).then(result=>{
    if(result?.ok && result.state?.available && !result.dismissed)renderBanner(result.state);
  }).catch(()=>{});

  async function checkDevChannel(){
    try{
      const result=await chrome.runtime.sendMessage({type:'VIENA_UPDATE_BANNER_GET_STATE'});
      if(!result?.ok)return;
      const state=result.state||{};
      if(!state?.available || String(state.channel||'').toUpperCase()!=='DEV' || result.dismissed){
        removeBanner();
        return;
      }
      const build=safeText(state.latestBuild);
      if(!build || build===CONTENT_BUILD_ID || build===dismissedDevBuild){
        if(build===CONTENT_BUILD_ID) removeBanner();
        return;
      }
      renderBanner(state);
    }catch(_){ }
  }

  const IS_DEV_CONTENT=CONTENT_BUILD_ID.includes('-dev-');
  if(IS_DEV_CONTENT){
    void checkDevChannel();
    setInterval(()=>void checkDevChannel(),5*60*1000);
  }
})();
