'use strict';
(() => {
  const BUILD_ID = '1.3.29-release-update-registry-assignments-candidate2';
  const VERSION = chrome.runtime.getManifest().version;
  const host = location.hostname;
  const UPDATE_HOST_ID = 'viena-noc-background-update-overlay';
  let completionTimer = 0;

  function platformFromHost() {
    if (host === 'viena.telecentro.net.ar') return 'viena';
    if (host === 'mira5-gdt.telecentro.net.ar') return 'mira5';
    if (host === 'monitoreogpon.telecentro.net.ar') return 'gpon';
    if (host === 'fuentes.telecentro.net.ar') return 'fuentes';
    if (host === 'metricas-gdt.telecentro.net.ar') return 'metricas';
    if (host === 'moica2.telecentro.net.ar') return 'moica2';
    if (host === 'grafana-telemetria.telecentro.net.ar') return 'grafana';
    return 'unknown';
  }

  function current() {
    return {
      ok: true,
      type: 'VIENA_RUNTIME_STATUS_PONG',
      version: VERSION,
      build: BUILD_ID,
      platform: platformFromHost(),
      href: location.href,
      title: document.title || '',
      ts: Date.now()
    };
  }

  function removeUpdateOverlay() {
    if (completionTimer) clearTimeout(completionTimer);
    completionTimer = 0;
    document.getElementById(UPDATE_HOST_ID)?.remove();
  }

  function stageCopy(state) {
    const stage = String(state?.stage || 'preparing');
    const presets = {
      preparing: ['Preparando archivos…','Iniciando proceso de actualización.'],
      downloading: ['Descargando actualización…','Obteniendo el paquete publicado.'],
      verifying: ['Verificando integridad…','Comprobando los archivos descargados.'],
      applying: ['Aplicando actualización…','Reemplazando y verificando archivos de la extensión.'],
      restarting: ['Reiniciando extensión…','Finalizando actualización.'],
      completed: ['¡Actualización completada!','VIENA NOC Tools se actualizó correctamente.'],
      error: ['Error al actualizar', String(state?.error || 'No se pudo completar la actualización.')]
    };
    return presets[stage] || presets.preparing;
  }

  function renderUpdateOverlay(state) {
    if (host !== 'viena.telecentro.net.ar') return;
    if (!state || (!state.active && !['completed','error'].includes(String(state.stage || '')))) return removeUpdateOverlay();

    removeUpdateOverlay();
    const stage = String(state.stage || 'preparing');
    const success = stage === 'completed';
    const failed = stage === 'error';
    const step = Math.max(0, Math.min(5, Number(state.step || (success ? 5 : 1))));
    let pct = step * 20;
    if (stage === 'applying' && Number(state.totalWrites) > 0) {
      pct = 60 + Math.round((Math.max(0, Number(state.writtenCount || 0)) / Number(state.totalWrites)) * 20);
    }
    if (success) pct = 100;
    const [title,detail] = stageCopy(state);

    const hostEl = document.createElement('div');
    hostEl.id = UPDATE_HOST_ID;
    hostEl.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;background:rgba(3,12,26,.76);backdrop-filter:blur(2px);pointer-events:auto;';
    const shadow = hostEl.attachShadow({mode:'closed'});
    shadow.innerHTML = `
      <style>
        *{box-sizing:border-box} .card{width:min(520px,calc(100vw - 32px));border:1px solid #2d4665;border-radius:15px;background:linear-gradient(180deg,#102238,#0b192b);color:#fff;box-shadow:0 24px 70px rgba(0,0,0,.45);padding:30px 34px;text-align:center;font:14px/1.45 Arial,Helvetica,sans-serif}
        .mark{width:58px;height:58px;margin:0 auto 16px;border-radius:13px;display:grid;place-items:center;background:linear-gradient(145deg,#2b7bd8,#0b4d9c);font-size:22px;font-weight:800;box-shadow:0 8px 24px rgba(16,103,207,.28)}
        h2{margin:0 0 8px;font-size:22px}.intro{color:#d9e5f2;margin:0 0 20px}.bar{height:10px;background:#43566e;border-radius:999px;overflow:hidden}.fill{height:100%;width:${pct}%;background:linear-gradient(90deg,#1f7cff,#43a0ff);border-radius:inherit;transition:width .25s ease}
        .meta{display:flex;justify-content:flex-end;margin-top:7px;color:#d4e1ef;font-weight:700}.status{margin-top:16px;font-weight:800;font-size:15px}.detail{margin-top:5px;color:#c8d5e3;font-size:13px}.ok{font-size:56px;color:#5ee49a;line-height:1}.err{font-size:48px;color:#ff6b6b;line-height:1}
        button{margin-top:18px;border:0;border-radius:8px;padding:10px 18px;background:#225d9e;color:#fff;font-weight:700;cursor:pointer}
      </style>
      <div class="card">
        ${success ? '<div class="ok">✓</div>' : failed ? '<div class="err">!</div>' : '<div class="mark">VN</div>'}
        <h2>${success ? '¡Actualización completada!' : failed ? 'Error al actualizar' : 'Actualizando VIENA NOC Tools'}</h2>
        ${!success && !failed ? '<p class="intro">No cierres esta pestaña.<br>Podés seguir usando el resto del navegador.</p>' : ''}
        ${!failed ? `<div class="bar"><div class="fill"></div></div><div class="meta">${success ? '5 / 5' : step + ' / 5'}</div>` : ''}
        <div class="status">${title}</div>
        <div class="detail">${detail}</div>
        ${failed ? '<button id="close">Cerrar</button>' : ''}
      </div>`;
    shadow.getElementById('close')?.addEventListener('click', removeUpdateOverlay);
    (document.documentElement || document.body).appendChild(hostEl);

    if (success) completionTimer = setTimeout(removeUpdateOverlay, 3200);
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === 'VIENA_RUNTIME_STATUS_PING') {
      sendResponse(current());
      return;
    }
    if (msg?.type === 'VIENA_BACKGROUND_UPDATE_PROGRESS') {
      renderUpdateOverlay(msg.state);
    }
  });

  try {
    chrome.runtime.sendMessage({ type: 'VIENA_RUNTIME_STATUS_HELLO', status: current() }).catch(() => {});
    if (host === 'viena.telecentro.net.ar') {
      chrome.runtime.sendMessage({ type: 'VIENA_BACKGROUND_UPDATE_GET' })
        .then(result => { if (result?.ok) renderUpdateOverlay(result.state); })
        .catch(() => {});
    }
  } catch (_) {}
})();
