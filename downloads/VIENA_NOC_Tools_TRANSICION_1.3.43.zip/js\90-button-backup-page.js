(() => {
  'use strict';
  if(new URLSearchParams(location.search).get('buttonsBackup')!=='1')return;
  function init(){
    document.title='Respaldo de botones · VIENA NOC Tools';document.documentElement.classList.add('button-backup-root');
    document.body.innerHTML='<style>html.button-backup-root,html.button-backup-root body{width:100%;min-width:0;max-width:none;margin:0;height:auto}html.button-backup-root body{box-sizing:border-box;padding:20px;background:#eef3f9;color:#183c63;font:16px/1.5 system-ui}.button-backup-root main{box-sizing:border-box;max-width:800px;margin:auto;padding:24px;background:white;border:1px solid #cbd9e9;border-radius:14px}.button-backup-root h1{margin-top:0;font-size:25px}.button-backup-root a{color:#174d85}.button-backup-root :focus-visible{outline:3px solid #eda02e;outline-offset:3px}@media(max-width:600px){html.button-backup-root body{padding:10px}.button-backup-root main{padding:18px}}</style><main><h1>Respaldo de botones</h1><p>Exportá o importá tus botones personales con sus plantillas y motivos. Abrí VIENA con tu usuario y guardá los cambios del editor antes de comenzar.</p><div id="buttonBackupHost"></div><a href="popup.html?full=1#personalization">Volver al panel</a></main>';
    let pending=null;
    async function message(payload){
      if(pending)throw Error('La operación anterior sigue pendiente. Esperá antes de reintentar.');
      const operation=(async()=>{const tabs=await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'}),tab=tabs.find(t=>t.id&&t.status==='complete')||tabs.find(t=>t.id);if(!tab?.id)throw Error('Abrí una pestaña de VIENA para respaldar tus botones.');const response=await chrome.tabs.sendMessage(tab.id,payload);if(!response?.ok)throw Error(response?.detail||'El editor de VIENA no respondió.');return response;})();
      pending=operation;void operation.then(()=>{if(pending===operation)pending=null},()=>{if(pending===operation)pending=null});let timer;
      try{return await Promise.race([operation,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('VIENA tardó demasiado. Revisá el resultado antes de reintentar.')),10000)})]);}finally{clearTimeout(timer);}
    }
    globalThis.VienaButtonBackup.mount(document.getElementById('buttonBackupHost'),{
      exportBackup:async()=> (await message({type:'VIENA_BUTTON_EDITOR_EXPORT'})).backup,
      previewImport:backup=>message({type:'VIENA_BUTTON_EDITOR_PREVIEW_IMPORT',backup}),
      importBackup:(backup,snapshot)=>message({type:'VIENA_BUTTON_EDITOR_IMPORT',backup,snapshot})
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
