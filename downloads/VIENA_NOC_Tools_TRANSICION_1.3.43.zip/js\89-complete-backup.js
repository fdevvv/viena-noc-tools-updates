(function(root){
  'use strict';
  const node=typeof module==='object'&&module.exports;
  const transfer=node?require('./82-installation-transfer.js'):root.VienaInstallationTransfer;
  const templates=node?require('./87-template-backup.js'):root.VienaTemplateBackup;
  const preferences=area=>Object.fromEntries(Object.entries(area).filter(([key])=>key!=='viena_installation_id_v1'));
  function validate(backup){
    transfer.validate(backup);
    if(['local','sync'].some(name=>Object.keys(backup[name]).some(key=>key.startsWith('viena_cws_'))))throw Error('El respaldo contiene estado interno de migración.');
    const picked={...backup,local:preferences(backup.local),sync:preferences(backup.sync)};
    transfer.summarizeMacros(picked);
    if(['local','sync'].some(name=>Object.keys(picked[name]).some(templates.allowed)))templates.validate(picked);
    return structuredClone(picked);
  }
  function makeBackup(local,sync,sourceId,version){return validate(transfer.makeBackup(preferences(local),preferences(sync),sourceId,version));}
  function summarize(backup){const picked=validate(backup),hasTemplates=['local','sync'].some(name=>Object.keys(picked[name]).some(templates.allowed));return {macros:transfer.summarizeMacros(picked),templates:hasTemplates?templates.summarize(picked):{task:0,building:0,cuadras:0,personal:0},local:Object.keys(picked.local).length,sync:Object.keys(picked.sync).length};}
  function mergeValue(current,incoming,stats){
    if(current===undefined)return structuredClone(incoming);
    if(transfer.equal(current,incoming))return structuredClone(current);
    if(Array.isArray(current)&&Array.isArray(incoming)){
      const result=structuredClone(current);
      for(const item of incoming){
        if(result.some(value=>transfer.equal(value,item)))continue;
        const index=item&&typeof item==='object'&&typeof item.id==='string'?result.findIndex(value=>value&&value.id===item.id):-1;
        if(index<0)result.push(structuredClone(item));
        else if(Array.isArray(item.plantillas)&&Array.isArray(result[index].plantillas))result[index]=mergeValue(result[index],item,stats);
        else stats.conflicts++;
      }
      return result;
    }
    if(current&&incoming&&typeof current==='object'&&typeof incoming==='object'&&!Array.isArray(current)&&!Array.isArray(incoming)){
      const result=structuredClone(current);
      for(const [key,value]of Object.entries(incoming))result[key]=mergeValue(result[key],value,stats);
      return result;
    }
    stats.conflicts++;return structuredClone(current);
  }
  let busy=false;
  async function restore(storage,backup){
    if(busy)throw Error('Ya hay una importación en curso.');busy=true;
    try{
      const incoming=validate(backup),merged={...incoming,local:{},sync:{}},stats={conflicts:0,changed:0};
      for(const area of ['local','sync']){
        const current=await storage[area].get(Object.keys(incoming[area]));
        for(const [key,value]of Object.entries(incoming[area])){
          const result=mergeValue(current[key],value,stats);
          if(!transfer.equal(current[key],result)){merged[area][key]=result;stats.changed++;}
        }
      }
      validate(merged);
      if(stats.changed)await transfer.restore(storage,merged);
      return stats;
    }finally{busy=false;}
  }
  const api={validate,makeBackup,summarize,restore};if(node)module.exports=api;else root.VienaCompleteBackup=api;
})(globalThis);
