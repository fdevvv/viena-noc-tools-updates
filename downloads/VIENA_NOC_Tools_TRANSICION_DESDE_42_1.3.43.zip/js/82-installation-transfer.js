(function(root){
  'use strict';
  // Portable preferences and identity; folder capabilities and running operations stay at source.
  const excluded=/^(?:viena_(?:local_update_|local_install_folder_|background_update_|auto_reload_|popup_dev_update_cache_|update_state$|last_notified_update_|last_update_download_|update_banner_dismissed$|primary_tab_by_platform_|last_runtime_build_seen_|tab_zoom_|install_registry_))/;
  const unsafe=new Set(['__proto__','constructor','prototype']);
  const clone=value=>JSON.parse(JSON.stringify(value));
  function checkValue(value,depth=0){
    if(depth>40)throw Error('El respaldo contiene una estructura demasiado profunda.');
    if(value===null||typeof value==='string'||typeof value==='boolean')return;
    if(typeof value==='number'&&Number.isFinite(value))return;
    if(Array.isArray(value)){value.forEach(v=>checkValue(v,depth+1));return;}
    if(value&&typeof value==='object'&&[Object.prototype,null].includes(Object.getPrototypeOf(value))){
      for(const [key,v] of Object.entries(value)){if(unsafe.has(key))throw Error('El respaldo contiene una propiedad inválida.');checkValue(v,depth+1);}return;
    }
    throw Error('El respaldo contiene datos no compatibles.');
  }
  function area(value){
    if(!value||Array.isArray(value)||typeof value!=='object')throw Error('Falta una sección de configuración.');
    checkValue(value);
    for(const key of Object.keys(value))if(excluded.test(key))throw Error('El archivo contiene estado de actualización o pestañas que no se puede trasladar.');
    return value;
  }
  function validate(backup){
    if(!backup||backup.format!=='VIENA_NOC_INSTALLATION'||backup.schema!==1)throw Error('Seleccioná un respaldo de instalación de VIENA NOC Tools.');
    area(backup.local);area(backup.sync);return backup;
  }
  function portable(value){return Object.fromEntries(Object.entries(value).filter(([k])=>!excluded.test(k)&&!k.startsWith('viena_cws_')));}
  function makeBackup(local,sync,sourceId,version){
    return validate({format:'VIENA_NOC_INSTALLATION',schema:1,exportedAt:new Date().toISOString(),sourceId,version,local:clone(portable(local)),sync:clone(portable(sync)),capabilities:'Folder handles and permissions stay in the original installation.'});
  }
  function summarizeMacros(backup){
    validate(backup);
    const count=key=>{
      const library=backup.local[key];
      if(library===undefined)return 0;
      if(!library||library.schema!==1||!Array.isArray(library.macros))throw Error('El respaldo contiene una biblioteca de macros incompatible.');
      return library.macros.length;
    };
    const viena=count('viena_ticket_macros_v1'),moica=count('moica_manual_macros_v1');
    return {viena,moica,total:viena+moica};
  }
  function stable(value){if(Array.isArray(value))return value.map(stable);if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(k=>[k,stable(value[k])]));return value;}
  const equal=(a,b)=>JSON.stringify(stable(a))===JSON.stringify(stable(b));
  let busy=false;
  async function restore(storage,backup){
    validate(backup);if(busy)throw Error('Ya hay una restauración en curso.');busy=true;
    const before={},written=[];
    try{
      for(const name of ['local','sync'])before[name]=await storage[name].get(Object.keys(backup[name]));
      for(const name of ['local','sync']){
        if(!Object.keys(backup[name]).length)continue;
        // Track before set: an API rejection may still have partially committed.
        written.push(name);await storage[name].set(backup[name]);
        if(!equal(await storage[name].get(Object.keys(backup[name])),backup[name]))throw Error('No se pudo verificar la configuración restaurada.');
      }
      return {local:Object.keys(backup.local).length,sync:Object.keys(backup.sync).length};
    }catch(error){
      const rollbackErrors=[];
      for(const name of written.reverse())try{
        await storage[name].set(before[name]);
        const added=Object.keys(backup[name]).filter(k=>!Object.hasOwn(before[name],k));
        if(added.length)await storage[name].remove(added);
        if(!equal(await storage[name].get(Object.keys(backup[name])),before[name]))throw Error('verificación');
      }catch(_){rollbackErrors.push(name);}
      if(rollbackErrors.length)throw Error('Restauración incompleta. Conservá la instalación original y el respaldo; revisá '+rollbackErrors.join(', ')+'.');
      throw Error('No se restauró la configuración; se recuperó el estado anterior. '+String(error.message||error));
    }finally{busy=false;}
  }
  const api={makeBackup,validate,restore,equal,summarizeMacros};
  if(typeof module==='object'&&module.exports)module.exports=api;else root.VienaInstallationTransfer=api;
})(globalThis);
