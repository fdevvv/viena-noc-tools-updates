(function () {
    'use strict';

    const KEY_COMANDO = 'VIENA_NOC_BRIDGE_COMMAND';
    const KEY_ULTIMO_PROCESADO = 'VIENA_NOC_BRIDGE_LAST_PROCESSED';
    const KEY_RESPUESTA = 'VIENA_NOC_BRIDGE_RESPONSE';
    const KEY_HEARTBEAT_STATS = 'VIENA_NOC_BRIDGE_HEARTBEAT_STATS';
    const KEY_HEARTBEAT_EDIFICIO = 'VIENA_NOC_BRIDGE_HEARTBEAT_EDIFICIO';
    const KEY_HEARTBEAT_GPON = 'VIENA_NOC_BRIDGE_HEARTBEAT_GPON';
    // v1.0.19 — validación ACTIVA bajo demanda.
    // Evita falsos "no disponible" cuando Chrome ralentiza timers de pestañas
    // en segundo plano y el heartbeat queda viejo aunque la pestaña siga viva.
    const KEY_PING = 'VIENA_NOC_BRIDGE_PING';
    const KEY_PONG = 'VIENA_NOC_BRIDGE_PONG';
    const URL_HFC_NODO = 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php';
    const URL_HFC_EDIFICIO = 'https://mira5-gdt.telecentro.net.ar/cablemodem_frontend.php';
    const DEBUG = true;

    const ES_VIENA = location.hostname === 'viena.telecentro.net.ar';
    const ES_MIRA5 = location.hostname === 'mira5-gdt.telecentro.net.ar';
    const ES_GPON = location.hostname === 'monitoreogpon.telecentro.net.ar';

    function log(...args) {
        if (DEBUG) console.log('[VIENA NOC Bridge]', ...args);
    }

    function limpiar(valor) {
        return String(valor || '').replace(/\s+/g, '');
    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function esperarElemento(selector, timeout = 15000) {
        const inicio = Date.now();
        while (Date.now() - inicio < timeout) {
            const elemento = document.querySelector(selector);
            if (elemento) return elemento;
            await sleep(150);
        }
        return null;
    }

    function establecerValor(input, valor) {
        valor = limpiar(valor);
        if (!input || !valor) return false;

        input.focus();

        const descriptor = Object.getOwnPropertyDescriptor(
            HTMLInputElement.prototype,
            'value'
        );

        if (descriptor?.set) {
            descriptor.set.call(input, valor);
        } else {
            input.value = valor;
        }

        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
    }

    function textoMiraNormalizado(valor) {
        return String(valor || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
            .toUpperCase();
    }

    async function navegarMira5ADestino(target) {
        if (!ES_MIRA5) return { ok: false, code: 'not_mira5' };

        if (target === 'mira-stats') {
            if (location.pathname.includes('stats_frontend.php')) {
                return { ok: true, already: true };
            }

            const inicio = Date.now();
            while (Date.now() - inicio < 15000) {
                const boton = Array.from(document.querySelectorAll('button')).find(btn => {
                    if (!btn.isConnected || btn.disabled) return false;
                    const texto = textoMiraNormalizado(btn.textContent);
                    return texto.includes('ESTADISTICAS');
                });

                if (boton) {
                    log('🧭 MIRA5 landing detectado: entrando a Estadísticas');
                    boton.click();
                    return { ok: true, navigating: true };
                }

                await sleep(150);
            }

            return { ok: false, code: 'stats_button_not_found' };
        }

        return { ok: false, code: 'unsupported_target' };
    }

    if (ES_MIRA5 && chrome?.runtime?.onMessage) {
        chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
            if (msg?.type !== 'VIENA_MIRA5_NAVIGATE') return;
            navegarMira5ADestino(String(msg.target || ''))
                .then(sendResponse)
                .catch(error => sendResponse({ ok: false, code: 'error', detail: String(error?.message || error) }));
            return true;
        });
    }

    function crearComando(tipo, tecnologia, valor, extra = {}) {
        return {
            id: Date.now().toString() + '-' + Math.random().toString(36).slice(2, 8),
            tipo: String(tipo || '').toLowerCase(),
            tecnologia: String(tecnologia || '').toUpperCase(),
            valor: limpiar(valor),
            nodo: limpiar(extra.nodo || ''),
            timestamp: Date.now()
        };
    }

    // ================================================================
    // VIENA — EMISOR
    // ================================================================

    if (ES_VIENA) {
        unsafeWindow.VienaNocBridge = {
            limpiar,

            // Consulta el heartbeat DESDE EL MISMO userscript Bridge.
            // Esto es importante porque el storage GM_* no se comparte
            // entre userscripts distintos.
            async disponible(tipo, tecnologia) {
                tipo = String(tipo || '').toLowerCase();
                tecnologia = String(tecnologia || '').toUpperCase();

                let destino = null;
                let target = null;

                if (tecnologia === 'FTTH') {
                    destino = 'GPON';
                    target = 'gpon';
                } else if (
                    tecnologia === 'HFC' &&
                    (tipo === 'edificio' || tipo === 'cliente' || tipo === 'nodocm' || tipo === 'nodolist')
                ) {
                    destino = 'MIRA5_CABLEMODEM';
                    target = 'mira-cm';
                } else if (tecnologia === 'HFC' && tipo === 'nodo') {
                    destino = 'MIRA5_STATS';
                    target = 'mira-stats';
                }

                if (!destino || !target) return false;

                try {
                    const direct = await chrome.runtime.sendMessage({ type: 'VIENA_BRIDGE_AVAILABLE', target });
                    return Boolean(direct?.ok);
                } catch (_) {
                    return false;
                }

                const pingActivo = async (timeoutMs = 2200) => {
                    const ping = {
                        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
                        destino,
                        ts: Date.now()
                    };

                    return await new Promise(async resolve => {
                        let terminado = false;
                        let listenerId = null;
                        let timeoutId = null;

                        const finalizar = ok => {
                            if (terminado) return;
                            terminado = true;
                            if (timeoutId !== null) clearTimeout(timeoutId);
                            if (listenerId !== null && typeof GM_removeValueChangeListener === 'function') {
                                try { GM_removeValueChangeListener(listenerId); } catch (_) {}
                            }
                            resolve(Boolean(ok));
                        };

                        try {
                            listenerId = GM_addValueChangeListener(
                                KEY_PONG,
                                (_nombre, _anterior, pong) => {
                                    if (!pong || pong.id !== ping.id) return;
                                    if (pong.destino !== destino) return;
                                    log('💓 PONG recibido:', pong);
                                    finalizar(true);
                                }
                            );

                            await GM_setValue(KEY_PING, ping);
                            log('💓 PING enviado:', ping);
                            timeoutId = setTimeout(() => finalizar(false), timeoutMs);
                        } catch (_) {
                            finalizar(false);
                        }
                    });
                };

                // 1) Si la página correcta ya está abierta y operativa, seguimos sin tocar pestañas.
                if (await pingActivo(2200)) return true;

                // 2) Si no respondió, distinguimos entre "cerrada" y "abierta pero con error".
                //    Sólo abrimos automáticamente cuando NO existe la página exacta del botón.
                let ensured = null;
                try {
                    ensured = await chrome.runtime.sendMessage({
                        type: 'VIENA_ENSURE_DESTINATION',
                        target
                    });
                } catch (_) {
                    return false;
                }

                if (!ensured?.ok) return false;

                // Si la página exacta ya estaba abierta pero no respondió, no abrimos duplicados.
                // Excepción: MIRA5 puede estar en index.php y haber sido navegado por el
                // botón nativo Estadísticas; en ese caso esperamos que termine la navegación.
                if (!ensured.opened && !ensured.navigated) return false;

                // Se abrió o se navegó ahora: damos tiempo a que cargue el receptor exacto y
                // reintentamos hasta que quede listo, sin usar sleeps fijos largos.
                const inicio = Date.now();
                while (Date.now() - inicio < 18000) {
                    await sleep(300);
                    if (await pingActivo(900)) return true;
                }

                return false;
            },

            async buscar(tipo, tecnologia, valor) {
                tipo = String(tipo || '').toLowerCase();
                tecnologia = String(tecnologia || '').toUpperCase();
                valor = limpiar(valor);

                if (tipo !== 'nodo' && tipo !== 'edificio' && tipo !== 'cliente' && tipo !== 'nodocm' && tipo !== 'nodolist') {
                    console.error('[VIENA NOC Bridge] Tipo inválido:', tipo);
                    return false;
                }

                if (tecnologia !== 'HFC' && tecnologia !== 'FTTH') {
                    console.error('[VIENA NOC Bridge] Tecnología inválida:', tecnologia);
                    return false;
                }

                if (!valor) {
                    console.error('[VIENA NOC Bridge] Valor vacío');
                    return false;
                }

                const comando = crearComando(tipo, tecnologia, valor);

                log('📤 Enviando:', comando);

                try {
                    return await chrome.runtime.sendMessage({ type: 'VIENA_BRIDGE_SEARCH', command: comando });
                } catch (error) {
                    return { ok: false, estado: 'sin_respuesta', mensaje: String(error?.message || 'No se pudo contactar la página destino.') };
                }

                // Fallback histórico no alcanzable en MV3; se conserva debajo para trazabilidad.
                // Esperamos una respuesta REAL del receptor. Esto permite
                // distinguir "orden escrita" de "pestaña abierta y operativa".
                return await new Promise(async resolve => {
                    let terminado = false;
                    let listenerId = null;

                    const finalizar = resultado => {
                        if (terminado) return;
                        terminado = true;

                        if (listenerId !== null && typeof GM_removeValueChangeListener === 'function') {
                            try { GM_removeValueChangeListener(listenerId); } catch (_) {}
                        }

                        resolve(resultado);
                    };

                    listenerId = GM_addValueChangeListener(
                        KEY_RESPUESTA,
                        (_nombre, _anterior, respuesta) => {
                            if (!respuesta || respuesta.id !== comando.id) return;

                            log('📥 Respuesta recibida:', respuesta);

                            if (respuesta.estado === 'ok') {
                                finalizar({
                                    ok: true,
                                    estado: 'ok',
                                    mensaje: respuesta.mensaje || 'Operación realizada correctamente.'
                                });
                                return;
                            }

                            if (respuesta.estado === 'error') {
                                finalizar({
                                    ok: false,
                                    estado: 'error',
                                    mensaje: respuesta.mensaje || 'La página destino recibió la orden pero no pudo completarla.'
                                });
                            }
                        }
                    );

                    await GM_setValue(KEY_COMANDO, comando);
                    log('📡 Orden enviada:', tecnologia, tipo, valor);

                    // Si nadie responde, la pestaña correcta no está abierta,
                    // Tampermonkey no está activo allí o la sesión/página quedó inutilizable.
                    setTimeout(() => {
                        finalizar({
                            ok: false,
                            estado: 'sin_respuesta',
                            mensaje: tecnologia === 'FTTH'
                                ? 'GPON no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                                : ((tipo === 'edificio' || tipo === 'nodocm' || tipo === 'nodolist')
                                    ? 'MIRA 5 Cable Modem no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                                    : 'MIRA 5 Estadísticas no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.')
                        });
                    }, 12000);
                });
            },

            async buscarCliente(tecnologia, cliente, nodo = '') {
                tecnologia = String(tecnologia || '').toUpperCase();
                cliente = limpiar(cliente);
                nodo = limpiar(nodo).toUpperCase();

                if (!cliente) {
                    return { ok: false, estado: 'error', mensaje: 'No se encontró Número de Cliente en el ticket.' };
                }

                const comando = crearComando('cliente', tecnologia, cliente, { nodo });

                try {
                    return await chrome.runtime.sendMessage({ type: 'VIENA_BRIDGE_SEARCH', command: comando });
                } catch (error) {
                    return { ok: false, estado: 'sin_respuesta', mensaje: String(error?.message || 'No se pudo contactar la página destino.') };
                }

                return await new Promise(async resolve => {
                    let terminado = false;
                    let listenerId = null;

                    const finalizar = resultado => {
                        if (terminado) return;
                        terminado = true;
                        if (listenerId !== null && typeof GM_removeValueChangeListener === 'function') {
                            try { GM_removeValueChangeListener(listenerId); } catch (_) {}
                        }
                        resolve(resultado);
                    };

                    listenerId = GM_addValueChangeListener(
                        KEY_RESPUESTA,
                        (_nombre, _anterior, respuesta) => {
                            if (!respuesta || respuesta.id !== comando.id) return;
                            finalizar({
                                ok: respuesta.estado === 'ok',
                                estado: respuesta.estado,
                                mensaje: respuesta.mensaje || ''
                            });
                        }
                    );

                    await GM_setValue(KEY_COMANDO, comando);

                    setTimeout(() => finalizar({
                        ok: false,
                        estado: 'sin_respuesta',
                        mensaje: tecnologia === 'FTTH'
                            ? 'GPON no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                            : 'MIRA 5 Cable Modem no respondió. Verificá que la pestaña esté abierta, con sesión iniciada y funcionando.'
                    }), 12000);
                });
            }
        };

        log('🚀 Emisor VIENA activo');
    }

    // ================================================================
    // MIRA5 — HFC
    // ================================================================

    async function esperarJQuery(timeout = 10000) {
        const inicio = Date.now();
        while (Date.now() - inicio < timeout) {
            const r = await globalThis.VienaPageBridge.call('jquery-ready', {}, 1200);
            if (r && r.ok) return true;
            await sleep(150);
        }
        return false;
    }

    async function esperarNodoHFC(nodo, timeout = 15000) {
        nodo = limpiar(nodo).toUpperCase();
        const inicio = Date.now();

        while (Date.now() - inicio < timeout) {
            const celdas = [
                ...document.querySelectorAll(
                    'td[aria-describedby="gridStatsNodosCmts_nodoCmts"]'
                )
            ];

            const celda = celdas.find(
                td => limpiar(td.textContent).toUpperCase() === nodo
            );

            if (celda) return celda;
            await sleep(200);
        }

        return null;
    }

    async function buscarNodoHFC(valor) {
        valor = limpiar(valor).toUpperCase();

        const nodos = valor
            .split('|')
            .map(n => limpiar(n).toUpperCase())
            .filter(Boolean);

        const valorBusqueda = valor;
        const primerNodo = nodos[0] || valor;

        log('🔎 HFC Nodo:', valorBusqueda, nodos);

        const input = await esperarElemento('#gs_nodoCmts');
        if (!input) {
            log('❌ No encontré #gs_nodoCmts');
            return false;
        }

        const jqueryDisponible = await esperarJQuery();
        if (!jqueryDisponible) {
            log('❌ jQuery no disponible en la página');
            return false;
        }

        /*
         * EXT v1.0.1
         * jqGrid y los handlers jQuery de MIRA5 viven en el MAIN world.
         * Ejecutamos allí la secuencia estable completa:
         * escribir -> Enter -> esperar filtro -> setSelection -> Gráficos.
         */
        const resultado = await globalThis.VienaPageBridge.call(
            'stats-filter-select-graphs',
            { valor: valorBusqueda, nodos: nodos.length ? nodos : [primerNodo] },
            30000
        );

        if (!resultado?.ok) {
            log('❌ Falló automatización Nodo MIRA5:', resultado?.error);
            return false;
        }

        log('📊 Nodo MIRA5 filtrado y Gráficos abierto:', resultado.data);
        return true;
    }

    async function limpiarFiltrosCableModem() {
        // Selector exacto confirmado en MIRA 5:
        // <button type="button" class="btn btn-default" filter-cleaner>...Limpiar</button>
        const botonLimpiar = await esperarElemento('button[filter-cleaner]', 2500);

        if (!botonLimpiar) {
            log('❌ No encontré button[filter-cleaner] de MIRA 5');
            return false;
        }

        log('🧹 Ejecutando botón Limpiar de MIRA 5');
        botonLimpiar.click();

        // Esperar a que la propia web vacíe ambos filtros.
        const inicio = Date.now();
        while (Date.now() - inicio < 2500) {
            const inputEdificio = document.querySelector('input[name="idedificio"]');
            const inputNodo = document.querySelector('input[name="nodocmts"]');

            const edificioVacio =
                !inputEdificio || String(inputEdificio.value || '').trim() === '';
            const nodoVacio =
                !inputNodo || String(inputNodo.value || '').trim() === '';

            if (edificioVacio && nodoVacio) {
                log('✅ Filtros MIRA 5 vacíos');
                return true;
            }

            await sleep(75);
        }

        const inputEdificio = document.querySelector('input[name="idedificio"]');
        const inputNodo = document.querySelector('input[name="nodocmts"]');

        log(
            '❌ El botón Limpiar fue ejecutado pero quedaron valores.',
            'ID Edificio:', inputEdificio?.value,
            'NodoCmts:', inputNodo?.value
        );
        return false;
    }

    async function buscarEdificioHFC(valor) {
        valor = limpiar(valor);

        log('🏢 HFC Edificio:', valor);

        if (!await limpiarFiltrosCableModem()) {
            return false;
        }

        const input = await esperarElemento(
            'input[name="idedificio"]'
        );

        if (!input) {
            log('❌ No encontré input[name="idedificio"]');
            return false;
        }

        // Reemplaza completamente cualquier ID anterior.
        establecerValor(input, valor);

        await sleep(150);

        // Método validado manualmente con ID 23934.
        const boton = [
            ...document.querySelectorAll(
                'button.btn.btn-primary'
            )
        ].find(
            elemento =>
                elemento.textContent.trim().toLowerCase() === 'filtrar'
        );

        if (!boton) {
            log('❌ No encontré el botón Filtrar');
            return false;
        }

        boton.click();

        log('✅ Edificio HFC filtrado:', valor);

        return true;
    }

    // ================================================================
    // GPON / FTTH
    // ================================================================

    function buscarInputGPON(labelBuscado) {
        const objetivo = String(labelBuscado)
            .trim()
            .toLowerCase();

        const contenedores = [
            ...document.querySelectorAll('.v-input')
        ];

        const contenedor = contenedores.find(elemento => {
            const label = elemento.querySelector('label');

            if (!label) return false;

            const texto = label.textContent
                .replace(/\s+/g, ' ')
                .trim()
                .toLowerCase();

            return texto === objetivo;
        });

        return contenedor?.querySelector('input') || null;
    }

    async function esperarInputGPON(label, timeout = 15000) {
        const inicio = Date.now();

        while (Date.now() - inicio < timeout) {
            const input = buscarInputGPON(label);

            if (input) return input;

            await sleep(150);
        }

        return null;
    }

    function enterGPON(input) {
        // Método validado manualmente:
        // keyup + Enter.
        const evento = new KeyboardEvent('keyup', {
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true,
            cancelable: true
        });

        input.dispatchEvent(evento);
    }

    async function limpiarFiltrosGPON() {
        // Cada acción iniciada desde VIENA debe arrancar desde un formulario GPON
        // completamente limpio. No alcanza con Nodo/IdCliente/IdEdificio: si el
        // operador dejó CUALQUIER otro filtro textual activo, la consulta puede
        // devolver cero resultados o combinar criterios de forma incorrecta.

        // 1) Si la propia pantalla ofrece un botón nativo de limpieza, usarlo.
        const normalizarTexto = valor => String(valor || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/\s+/g, ' ')
            .trim()
            .toLowerCase();

        const botonLimpiar = Array.from(document.querySelectorAll('button'))
            .find(btn => {
                if (!btn?.isConnected || btn.disabled || btn.offsetParent === null) return false;
                const texto = normalizarTexto(btn.textContent);
                return texto === 'limpiar' ||
                    texto === 'limpiar filtros' ||
                    texto === 'borrar filtros' ||
                    texto === 'reset filtros';
            });

        if (botonLimpiar) {
            try {
                botonLimpiar.click();
                await sleep(120);
            } catch (_) {}
        }

        // 2) Defensa adicional: vaciar TODOS los controles textuales de filtros
        // Vuetify que sigan teniendo valor. Se omiten hidden/checkbox/radio y
        // controles disabled. El setter nativo + input/change actualiza el modelo Vue.
        const candidatos = Array.from(document.querySelectorAll(
            '.v-input input, .v-input textarea, input[type="text"], input[type="search"], input[type="number"], textarea'
        ));

        let encontrados = 0;
        for (const input of candidatos) {
            if (!input?.isConnected || input.disabled) continue;
            const tipo = String(input.type || '').toLowerCase();
            if (['hidden', 'checkbox', 'radio', 'button', 'submit'].includes(tipo)) continue;

            const valorActual = String(input.value ?? '');
            if (!valorActual) continue;

            encontrados++;

            try { input.focus({ preventScroll: true }); } catch (_) {}

            const proto = input instanceof HTMLTextAreaElement
                ? HTMLTextAreaElement.prototype
                : HTMLInputElement.prototype;
            const descriptor = Object.getOwnPropertyDescriptor(proto, 'value');

            if (descriptor?.set) descriptor.set.call(input, '');
            else input.value = '';

            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }

        // 3) Verificación específica de los tres campos que usamos desde tickets.
        // Si alguno conserva valor por un rerender de Vue, se vuelve a vaciar.
        for (const label of ['Nodo', 'IdCliente', 'IdEdificio']) {
            const input = buscarInputGPON(label);
            if (!input || !String(input.value || '')) continue;

            const descriptor = Object.getOwnPropertyDescriptor(
                HTMLInputElement.prototype,
                'value'
            );
            if (descriptor?.set) descriptor.set.call(input, '');
            else input.value = '';
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }

        try { document.activeElement?.blur?.(); } catch (_) {}
        await sleep(120);

        log('🧹 GPON: limpieza total de filtros completada', {
            botonNativo: Boolean(botonLimpiar),
            camposVaciados: encontrados
        });

        // Que no haya filtros con texto también es un resultado válido.
        return true;
    }

    async function buscarNodoFTTH(valor) {
        valor = limpiar(valor).toUpperCase();

        log('🔎 FTTH Nodo:', valor);

        await limpiarFiltrosGPON();
        const input = await esperarInputGPON('Nodo');

        if (!input) {
            log('❌ No encontré Nodo GPON');
            return false;
        }

        // Reemplaza completamente cualquier nodo anterior.
        establecerValor(input, valor);

        await sleep(150);

        enterGPON(input);

        log('✅ Nodo FTTH filtrado:', valor);

        return true;
    }

    async function buscarEdificioFTTH(valor) {
        valor = limpiar(valor);

        log('🏢 FTTH Edificio:', valor);

        await limpiarFiltrosGPON();
        const input = await esperarInputGPON('IdEdificio');

        if (!input) {
            log('❌ No encontré IdEdificio GPON');
            return false;
        }

        // Reemplaza completamente cualquier ID anterior.
        establecerValor(input, valor);

        await sleep(150);

        enterGPON(input);

        log('✅ Edificio FTTH filtrado:', valor);

        return true;
    }


    async function buscarClienteFTTH(valor) {
        valor = limpiar(valor);

        log('👤 FTTH Cliente:', valor);

        await limpiarFiltrosGPON();
        const input = await esperarInputGPON('IdCliente');

        if (!input) {
            log('❌ No encontré IdCliente GPON');
            return false;
        }

        establecerValor(input, valor);
        await sleep(150);
        enterGPON(input);

        log('✅ Cliente FTTH filtrado:', valor);
        return true;
    }

    async function buscarNodoCableModemHFC(nodo) {
        nodo = limpiar(nodo).toUpperCase();
        log('🧩 HFC Nodo en Cable Modem:', nodo);

        if (!nodo || !await limpiarFiltrosCableModem()) return false;

        const input = await esperarElemento('input[name="nodocmts"]');
        if (!input) {
            log('❌ No encontré input[name="nodocmts"]');
            return false;
        }

        establecerValor(input, nodo);
        await sleep(150);
        ['keydown', 'keypress', 'keyup'].forEach(tipo => {
            input.dispatchEvent(new KeyboardEvent(tipo, {
                key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
                bubbles: true, cancelable: true
            }));
        });
        log('✅ Nodo CMTS escrito + Enter en Cable Modem:', nodo);
        return true;
    }

    async function buscarNodoListCMsHFC(nodo) {
        nodo = limpiar(nodo).toUpperCase();
        log('📋 HFC Nodo List CMs:', nodo);

        if (!nodo || !await limpiarFiltrosCableModem()) return false;

        const inputNodo = await esperarElemento('input[name="nodocmts"]');
        if (!inputNodo) {
            log('❌ No encontré input[name="nodocmts"] para List CMs');
            return false;
        }

        establecerValor(inputNodo, nodo);

        // Mismo mecanismo validado por Ir a Cliente: Nodo CMTS + botón Filtrar.
        const botonFiltrar = [...document.querySelectorAll('button.btn.btn-primary')]
            .find(elemento => limpiar(elemento.textContent).toLowerCase() === 'filtrar');
        if (!botonFiltrar) {
            log('❌ No encontré el botón Filtrar para List CMs');
            return false;
        }

        botonFiltrar.click();
        log('🔎 List CMs filtrado por Nodo CMTS:', nodo);
        return true;
    }

    async function buscarClienteHFC(cliente, nodo) {
        cliente = limpiar(cliente);
        nodo = limpiar(nodo).toUpperCase();

        log('👤 HFC Cliente:', cliente, 'Nodo:', nodo);

        if (!await limpiarFiltrosCableModem()) {
            return false;
        }

        const inputNodo = await esperarElemento('input[name="nodocmts"]');

        if (!inputNodo) {
            log('❌ No encontré input[name="nodocmts"]');
            return false;
        }

        if (nodo) {
            establecerValor(inputNodo, nodo);
            await sleep(150);

            // Cable Modem no siempre ejecuta el filtro con un Enter sintético.
            // Usamos el mismo botón Filtrar ya validado por la búsqueda de Edificio.
            const botonFiltrar = [
                ...document.querySelectorAll('button.btn.btn-primary')
            ].find(elemento =>
                elemento.textContent.trim().toLowerCase() === 'filtrar'
            );

            if (!botonFiltrar) {
                log('❌ No encontré el botón Filtrar para Cliente HFC');
                return false;
            }

            botonFiltrar.click();
            log('🔎 Filtro de NodoCmts ejecutado para Cliente HFC:', nodo);

            // Dejamos que jqGrid/listado reciba la nueva consulta. El bucle
            // posterior continúa esperando hasta 12 s por el cliente.
            await sleep(700);
        }

        // No intentamos automatizar Ctrl+F del navegador: JavaScript de página
        // no puede escribir de forma fiable en la UI del navegador.
        // En su lugar localizamos el cliente en la tabla y lo llevamos a pantalla.
        const inicio = Date.now();
        while (Date.now() - inicio < 12000) {
            const celdas = Array.from(document.querySelectorAll('td'));
            const celda = celdas.find(td =>
                limpiar(td.textContent) === cliente
            );

            if (celda) {
                celda.scrollIntoView({ block: 'center', inline: 'center' });
                const previo = celda.style.outline;
                const previoOffset = celda.style.outlineOffset;
                celda.style.outline = '3px solid #ff9800';
                celda.style.outlineOffset = '-2px';
                setTimeout(() => {
                    celda.style.outline = previo;
                    celda.style.outlineOffset = previoOffset;
                }, 6000);

                log('✅ Cliente HFC localizado en listado:', cliente);

                celda.click();
                log('🖱️ Click en cliente HFC:', cliente);

                const inicioGraficos = Date.now();
                while (Date.now() - inicioGraficos < 6000) {
                    const botonGraficos = Array.from(document.querySelectorAll(
                        'a[name="BOTON-CM-GRAF"][flag="gral"], a[href="#CM-DESC-gral-TAB-GRAF"]'
                    )).find(a => a.offsetParent !== null);

                    if (botonGraficos) {
                        botonGraficos.click();
                        log('📈 Gráficos del cliente HFC abiertos:', cliente);
                        return true;
                    }

                    await sleep(150);
                }

                log('⚠️ Cliente seleccionado, pero no apareció el tab Gráficos');
                return true;
            }

            await sleep(250);
        }

        log('❌ Cliente HFC no encontrado en el listado:', cliente);
        return false;
    }

    // ================================================================
    // HEARTBEAT DE PESTAÑAS DESTINO
    // Sólo informa que la página receptora está viva.
    // NO ejecuta búsquedas, NO toca filtros y NO reprocesa comandos.
    // ================================================================

    function heartbeatKeyActual() {
        if (ES_GPON) {
            return KEY_HEARTBEAT_GPON;
        }

        if (ES_MIRA5 && location.pathname.includes('cablemodem_frontend.php')) {
            return KEY_HEARTBEAT_EDIFICIO;
        }

        if (ES_MIRA5 && location.pathname.includes('stats_frontend.php')) {
            return KEY_HEARTBEAT_STATS;
        }

        return null;
    }

    async function publicarHeartbeat() {
        const key = heartbeatKeyActual();
        if (!key) return;

        try {
            await GM_setValue(key, {
                ts: Date.now(),
                path: location.pathname
            });
        } catch (_) {}
    }

    // ================================================================
    // PROCESAMIENTO DE COMANDOS
    // v1.0.8: cola de una orden + deduplicación
    // ================================================================

    let procesando = false;
    let ultimoComando = null;
    let comandoEnProcesoId = null;
    let comandoPendiente = null;

    function mismoComando(a, b) {
        if (!a || !b) return false;

        if (a.id && b.id) {
            return a.id === b.id;
        }

        return (
            String(a.tipo || '') === String(b.tipo || '') &&
            String(a.tecnologia || '') === String(b.tecnologia || '') &&
            limpiar(a.valor) === limpiar(b.valor)
        );
    }

    const directCommandWaiters = new Map();

    function marcarPestanaAutomatizacion(etiqueta='VIENA NOC Tools') {
        const original=String(document.title||'');
        clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);
        clearTimeout(globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__);
        let on=false;
        const pulse=()=>{on=!on;document.title=on?`● VN · ${etiqueta} · ${original}`:original;};
        pulse();
        globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__=setInterval(pulse,450);
        globalThis.__VIENA_AUTOMATION_TAB_BLINK_TIMEOUT__=setTimeout(()=>{
            clearInterval(globalThis.__VIENA_AUTOMATION_TAB_BLINK_INTERVAL__);
            document.title=original;
        },6000);
    }

    async function responderComando(comando, estado, mensaje) {
        if (!comando?.id) return;
        const direct=directCommandWaiters.get(comando.id);
        if(direct){
            directCommandWaiters.delete(comando.id);
            direct({ok:estado==='ok',estado,mensaje:String(mensaje||'')});
        }

        await GM_setValue(KEY_RESPUESTA, {
            id: comando.id,
            estado,
            mensaje: String(mensaje || ''),
            timestamp: Date.now()
        });
    }

    async function ejecutarComando(comando) {
        const tipo = String(
            comando.tipo || ''
        ).toLowerCase();

        const tecnologia = String(
            comando.tecnologia || ''
        ).toUpperCase();

        const valor = limpiar(comando.valor);
        const nodoComando = limpiar(comando.nodo || '').toUpperCase();

        if (!valor) return;

        log(
            '📨 Comando recibido:',
            {
                tipo,
                tecnologia,
                valor
            }
        );

        // ========================================================
        // MIRA5 / HFC
        // ========================================================

        if (
            ES_MIRA5 &&
            tecnologia === 'HFC'
        ) {

            if (tipo === 'nodo') {

                if (
                    !location.pathname.includes(
                        'stats_frontend.php'
                    )
                ) {
                    log(
                        '⏭️ Nodo HFC ignorado: esta pestaña MIRA5 no es Estadísticas'
                    );
                    return;
                }

                const ok =
                    await buscarNodoHFC(valor);

                if (ok) {
                    ultimoComando = comando.id || null;

                    if (comando.id) {
                        await GM_setValue(
                            KEY_ULTIMO_PROCESADO,
                            comando.id
                        );
                    }

                    await responderComando(
                        comando,
                        'ok',
                        'MIRA 5 procesó correctamente la búsqueda.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'MIRA 5 recibió la orden pero no pudo completar la búsqueda. Revisá la sesión o el estado de la página.'
                    );
                }

                return;
            }

            if (tipo === 'nodocm') {
                if (!location.pathname.includes('cablemodem_frontend.php')) {
                    log('⏭️ Nodo Cable Modem ignorado: esta pestaña MIRA5 no es Cablemodem');
                    return;
                }
                const ok = await buscarNodoCableModemHFC(valor);
                if (ok) {
                    ultimoComando = comando.id || null;
                    if (comando.id) await GM_setValue(KEY_ULTIMO_PROCESADO, comando.id);
                    await responderComando(comando, 'ok', 'MIRA 5 Cable Modem cargó Nodo CMTS y ejecutó Enter.');
                } else {
                    await responderComando(comando, 'error', 'MIRA 5 Cable Modem no pudo cargar Nodo CMTS.');
                }
                return;
            }

            if (tipo === 'nodolist') {
                if (!location.pathname.includes('cablemodem_frontend.php')) {
                    log('⏭️ List CMs ignorado: esta pestaña MIRA5 no es Cablemodem');
                    return;
                }
                const ok = await buscarNodoListCMsHFC(valor);
                if (ok) {
                    ultimoComando = comando.id || null;
                    if (comando.id) await GM_setValue(KEY_ULTIMO_PROCESADO, comando.id);
                    await responderComando(comando, 'ok', 'MIRA 5 Cable Modem filtró List CMs por Nodo CMTS.');
                } else {
                    await responderComando(comando, 'error', 'MIRA 5 Cable Modem no pudo filtrar List CMs por Nodo CMTS.');
                }
                return;
            }

            if (tipo === 'cliente') {

                if (!location.pathname.includes('cablemodem_frontend.php')) {
                    log('⏭️ Cliente HFC ignorado: esta pestaña MIRA5 no es Cablemodem');
                    return;
                }

                const ok = await buscarClienteHFC(valor, nodoComando);

                if (ok) {
                    ultimoComando = comando.id || null;
                    if (comando.id) await GM_setValue(KEY_ULTIMO_PROCESADO, comando.id);
                    await responderComando(
                        comando,
                        'ok',
                        'MIRA 5 filtró el nodo y localizó el cliente en el listado.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'MIRA 5 recibió la orden pero no pudo localizar el cliente en el listado.'
                    );
                }

                return;
            }

            if (tipo === 'edificio') {

                if (
                    !location.pathname.includes(
                        'cablemodem_frontend.php'
                    )
                ) {
                    log(
                        '⏭️ Edificio HFC ignorado: esta pestaña MIRA5 no es Cablemodem'
                    );
                    return;
                }

                const ok =
                    await buscarEdificioHFC(valor);

                if (ok) {
                    ultimoComando = comando.id || null;

                    if (comando.id) {
                        await GM_setValue(
                            KEY_ULTIMO_PROCESADO,
                            comando.id
                        );
                    }

                    await responderComando(
                        comando,
                        'ok',
                        'MIRA 5 procesó correctamente la búsqueda.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'MIRA 5 recibió la orden pero no pudo completar la búsqueda. Revisá la sesión o el estado de la página.'
                    );
                }

                return;
            }
        }

        // ========================================================
        // GPON / FTTH
        // ========================================================

        if (
            ES_GPON &&
            tecnologia === 'FTTH'
        ) {

            if (
                location.hash !== '#/listOnts'
            ) {
                log(
                    '➡️ Cambiando GPON a List ONTs'
                );

                location.hash = '#/listOnts';

                await sleep(1000);
            }

            if (tipo === 'cliente') {
                const ok = await buscarClienteFTTH(valor);

                if (ok) {
                    ultimoComando = comando.id || null;
                    if (comando.id) await GM_setValue(KEY_ULTIMO_PROCESADO, comando.id);
                    await responderComando(
                        comando,
                        'ok',
                        'GPON filtró correctamente por IdCliente.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'GPON recibió la orden pero no pudo filtrar por IdCliente.'
                    );
                }

                return;
            }

            if (tipo === 'nodo') {
                const ok =
                    await buscarNodoFTTH(valor);

                if (ok) {
                    ultimoComando = comando.id || null;

                    if (comando.id) {
                        await GM_setValue(
                            KEY_ULTIMO_PROCESADO,
                            comando.id
                        );
                    }

                    await responderComando(
                        comando,
                        'ok',
                        'GPON procesó correctamente la búsqueda.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'GPON recibió la orden pero no pudo completar la búsqueda. Revisá la sesión o el estado de la página.'
                    );
                }

                return;
            }

            if (tipo === 'edificio') {
                const ok =
                    await buscarEdificioFTTH(valor);

                if (ok) {
                    ultimoComando = comando.id || null;

                    if (comando.id) {
                        await GM_setValue(
                            KEY_ULTIMO_PROCESADO,
                            comando.id
                        );
                    }

                    await responderComando(
                        comando,
                        'ok',
                        'GPON procesó correctamente la búsqueda.'
                    );
                } else {
                    await responderComando(
                        comando,
                        'error',
                        'GPON recibió la orden pero no pudo completar la búsqueda. Revisá la sesión o el estado de la página.'
                    );
                }

                return;
            }
        }
    }

    async function procesarComando(comando) {
        if (!comando || typeof comando !== 'object') {
            return;
        }

        const ultimoProcesadoPersistente =
            await GM_getValue(
                KEY_ULTIMO_PROCESADO,
                null
            );

        if (
            comando.id &&
            (
                comando.id === ultimoComando ||
                comando.id === ultimoProcesadoPersistente ||
                comando.id === comandoEnProcesoId
            )
        ) {
            log(
                '⏭️ Orden duplicada ignorada:',
                comando.id
            );
            return;
        }

        // Si llega una orden mientras MIRA5/GPON todavía está trabajando,
        // no se pierde. Se conserva únicamente la más reciente.
        if (procesando) {

            if (
                comandoPendiente &&
                mismoComando(
                    comandoPendiente,
                    comando
                )
            ) {
                log(
                    '⏭️ Orden pendiente duplicada ignorada:',
                    comando.id || limpiar(comando.valor)
                );
                return;
            }

            comandoPendiente = comando;

            log(
                '🕒 Nueva orden guardada en cola:',
                limpiar(comando.valor)
            );

            return;
        }

        procesando = true;
        comandoEnProcesoId = comando.id || null;

        try {
            await ejecutarComando(comando);

        } catch (error) {
            console.error(
                '[VIENA NOC Bridge] ERROR:',
                error
            );

        } finally {
            procesando = false;
            comandoEnProcesoId = null;

            // Si durante la búsqueda llegó otro ticket, procesarlo ahora.
            const siguiente = comandoPendiente;
            comandoPendiente = null;

            if (siguiente) {
                log(
                    '▶️ Procesando orden pendiente:',
                    limpiar(siguiente.valor)
                );

                // Liberamos primero el lock y arrancamos la siguiente orden
                // en un nuevo turno para no superponer automatizaciones.
                setTimeout(
                    () => procesarComando(siguiente),
                    0
                );
            }
        }
    }


    // ================================================================
    // v1.0.19 — RECEPTOR DE PING ACTIVO
    // ================================================================

    function destinoPingActual() {
        if (ES_GPON) {
            return 'GPON';
        }

        if (ES_MIRA5 && location.pathname.includes('cablemodem_frontend.php')) {
            return 'MIRA5_CABLEMODEM';
        }

        if (ES_MIRA5 && location.pathname.includes('stats_frontend.php')) {
            return 'MIRA5_STATS';
        }

        return null;
    }

    async function responderPing(ping) {
        if (!ping || !ping.id || !ping.destino) return;

        const actual = destinoPingActual();
        if (!actual || actual !== ping.destino) return;

        try {
            // También renovamos heartbeat como dato diagnóstico, pero la
            // disponibilidad ya no depende de su antigüedad.
            await publicarHeartbeat();

            await GM_setValue(KEY_PONG, {
                id: ping.id,
                destino: actual,
                ts: Date.now(),
                path: location.pathname
            });

            log('💓 PING respondido:', actual);
        } catch (_) {}
    }

    // ================================================================
    // MIRA5 CABLE MODEMS — COPIAR DATOS DE EDIFICIO
    // v1.3.9: helper local. No altera el submit ni el filtrado nativo.
    // ================================================================

    if (ES_MIRA5 && location.pathname.includes('cablemodem_frontend.php')) {
        const EDIF_BTN_ID = 'viena-copiar-datos-edificio';
        const EDIF_MODAL_ID = 'viena-modal-datos-edificio';
        const EDIF_TOAST_ID = 'viena-toast-datos-edificio';
        const CM_ACTIONS_ID = 'viena-mira-cm-actions';
        const CUADRAS_BTN_ID = 'viena-seleccionar-cuadras';
        const CUADRAS_VISIBLE_ID = 'viena-seleccionar-cuadras-visibles';
        const CUADRAS_CANCEL_ID = 'viena-cancelar-seleccion-cuadras';
        const CUADRAS_MODAL_ID = 'viena-modal-cuadras';
        const CUADRAS_CHECK_CLASS = 'viena-cuadra-row-check';
        const CUADRAS_TEMPLATES_KEY = 'viena_cuadras_fallas_templates_v1';
        const CUADRAS_TEMPLATES_DEFAULT = [
            'Se verifica caida parcial de CMs sin patron de red.',
            'Se verifica conteo POST FEC DS QAM/ OFDM en cuadras',
            'Se verifica conteo POST FEC US QAM / OFDM en cuadras.',
            'Se verifica niveles de PWR DS bajos / fuera de rango.',
            'Se verifica niveles de SNR DS bajos / fuera de rango.',
            'Se verifica niveles de PWR US bajos / fuera de rango.'
        ];
        let modoSeleccionCuadras = false;
        const seleccionCuadras = new Map();
        let accionesCmRaf = 0;

        function valorCeldaFila(row, campo) {
            const td = row?.querySelector(`td[aria-describedby="grid_cm_gral_${campo}"]`);
            if (!td) return '';
            const titulo = String(td.getAttribute('title') || '')
                .replace(/\u00a0/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
            if (titulo && titulo !== '&nbsp;') return titulo;
            return String(td.textContent || '')
                .replace(/\u00a0/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        }

        function filasCableModem() {
            return Array.from(document.querySelectorAll('#grid_cm_gral tr.jqgrow'));
        }

        function normalizarCalleCuadra(valor) {
            return String(valor || '')
                .replace(/\s+/g, ' ')
                .trim()
                .toLocaleUpperCase('es-AR');
        }

        function alturaNumericaCuadra(valor) {
            const match = String(valor || '').match(/\d{1,6}/);
            if (!match) return null;
            const altura = Number.parseInt(match[0], 10);
            return Number.isFinite(altura) && altura >= 0 ? altura : null;
        }

        function datosDireccionFilaCuadra(row) {
            let calle = valorCeldaFila(row, 'infocliente.calle');
            let altura = alturaNumericaCuadra(valorCeldaFila(row, 'infocliente.nro'));
            const direccionVisible =
                valorCeldaFila(row, '__DireccionCliente') ||
                valorCeldaFila(row, 'infocliente.dirExtDireccion');

            if (!calle || altura === null) {
                const candidatos = [
                    direccionVisible,
                    valorCeldaFila(row, 'infocliente.dirExtDireccion')
                ].filter(Boolean);

                for (const texto of candidatos) {
                    const limpio = String(texto).replace(/\s+/g, ' ').trim();
                    const match = limpio.match(/^(.*?)[,\s]+(\d{1,6})(?:\D.*)?$/);
                    if (!match) continue;
                    if (!calle) calle = match[1];
                    if (altura === null) altura = Number.parseInt(match[2], 10);
                    if (calle && Number.isFinite(altura)) break;
                }
            }

            const calleNormalizada = normalizarCalleCuadra(calle);
            if (!calleNormalizada || !Number.isFinite(altura)) return null;

            const inicioCuadra = Math.floor(altura / 100) * 100;
            return {
                calle: calleNormalizada,
                altura,
                inicioCuadra,
                finCuadra: inicioCuadra + 100,
                direccion: direccionVisible || `${calleNormalizada} ${altura}`,
                nodoCmts: valorCeldaFila(row, 'cmNodo.nodoCmts').toUpperCase()
            };
        }

        function claveFilaCuadra(row, datos) {
            const idInterno = valorCeldaFila(row, '_id');
            const mac = valorCeldaFila(row, 'mac');
            const idCliente = valorCeldaFila(row, 'infocliente.idcliente');
            const base = idInterno || mac || idCliente || String(row?.id || '');
            return `${base}|${datos.calle}|${datos.altura}`;
        }

        function normalizarTemplateFallaCuadras(valor) {
            return String(valor || '').replace(/\s+/g, ' ').trim();
        }

        function templatesFallaCuadrasValidos(lista) {
            if (!Array.isArray(lista)) return null;
            const unicos = [];
            const vistos = new Set();
            for (const item of lista) {
                const texto = normalizarTemplateFallaCuadras(item);
                if (!texto || texto.length > 240) continue;
                const clave = texto.toLocaleLowerCase('es-AR');
                if (vistos.has(clave)) continue;
                vistos.add(clave);
                unicos.push(texto);
            }
            return unicos;
        }

        async function cargarTemplatesFallaCuadras() {
            try {
                const guardado = await chrome.storage.local.get([CUADRAS_TEMPLATES_KEY]);
                if (Object.prototype.hasOwnProperty.call(guardado, CUADRAS_TEMPLATES_KEY)) {
                    const validos = templatesFallaCuadrasValidos(guardado[CUADRAS_TEMPLATES_KEY]);
                    if (validos) return validos;
                }
                const defaults = [...CUADRAS_TEMPLATES_DEFAULT];
                await chrome.storage.local.set({ [CUADRAS_TEMPLATES_KEY]: defaults });
                return defaults;
            } catch (_) {
                return [...CUADRAS_TEMPLATES_DEFAULT];
            }
        }

        async function guardarTemplatesFallaCuadras(lista) {
            const validos = templatesFallaCuadrasValidos(lista) || [];
            await chrome.storage.local.set({ [CUADRAS_TEMPLATES_KEY]: validos });
            return validos;
        }

        function nodoCmtsSeleccionCuadras() {
            const conteo = new Map();
            for (const datos of seleccionCuadras.values()) {
                const nodo = String(datos?.nodoCmts || '').trim().toUpperCase();
                if (!nodo) continue;
                conteo.set(nodo, (conteo.get(nodo) || 0) + 1);
            }
            const nodos = Array.from(conteo.entries()).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
            if (!nodos.length) return '';
            if (nodos.length === 1) return nodos[0][0];
            return nodos.map(([nodo]) => nodo).join(' / ');
        }

        function textoInicialCuadras(resultado) {
            return [
                `NODO CMTS: ${nodoCmtsSeleccionCuadras()}`,
                'CUADRAS:',
                ...resultado.lineas,
                '',
                'FALLA DETECTADA:',
                '',
                'ESTADO DE FUENTE:'
            ].join('\n');
        }

        function lineaTemplateFallaCuadras(template) {
            return `- ${normalizarTemplateFallaCuadras(template)}`;
        }

        function limitesFallaCuadras(texto) {
            const lineas = String(texto || '').split('\n');
            const inicio = lineas.findIndex(linea => linea.trim() === 'FALLA DETECTADA:');
            if (inicio < 0) return { lineas, inicio: -1, fin: -1 };
            let fin = lineas.findIndex((linea, index) => index > inicio && linea.trim().startsWith('ESTADO DE FUENTE:'));
            if (fin < 0) fin = lineas.length;
            return { lineas, inicio, fin };
        }

        function tieneTemplateFallaCuadras(texto, template) {
            const { lineas, inicio, fin } = limitesFallaCuadras(texto);
            if (inicio < 0) return false;
            const objetivo = lineaTemplateFallaCuadras(template).trim();
            return lineas.slice(inicio + 1, fin).some(linea => linea.trim() === objetivo);
        }

        function alternarTemplateFallaCuadras(texto, template, activo) {
            const estado = limitesFallaCuadras(texto);
            if (estado.inicio < 0) return texto;
            const objetivo = lineaTemplateFallaCuadras(template);
            const existe = estado.lineas.slice(estado.inicio + 1, estado.fin).some(linea => linea.trim() === objetivo.trim());
            if (activo && !existe) {
                let insertarEn = estado.fin;
                while (insertarEn > estado.inicio + 1 && !estado.lineas[insertarEn - 1].trim()) insertarEn--;
                estado.lineas.splice(insertarEn, 0, objetivo);
            } else if (!activo && existe) {
                for (let i = estado.fin - 1; i > estado.inicio; i--) {
                    if (estado.lineas[i].trim() === objetivo.trim()) estado.lineas.splice(i, 1);
                }
            }
            return estado.lineas.join('\n').replace(/\n{3,}ESTADO DE FUENTE:/, '\n\nESTADO DE FUENTE:');
        }

        function reemplazarTemplateFallaCuadras(texto, anterior, nuevo) {
            const estado = limitesFallaCuadras(texto);
            if (estado.inicio < 0) return texto;
            const vieja = lineaTemplateFallaCuadras(anterior).trim();
            const nueva = lineaTemplateFallaCuadras(nuevo);
            for (let i = estado.inicio + 1; i < estado.fin; i++) {
                if (estado.lineas[i].trim() === vieja) estado.lineas[i] = nueva;
            }
            return estado.lineas.join('\n');
        }

        function construirRangosCuadras() {
            const porCalle = new Map();

            for (const datos of seleccionCuadras.values()) {
                if (!porCalle.has(datos.calle)) porCalle.set(datos.calle, new Set());
                porCalle.get(datos.calle).add(datos.inicioCuadra);
            }

            const rangos = [];
            let cuadrasUnicas = 0;

            for (const [calle, startsSet] of porCalle.entries()) {
                const starts = Array.from(startsSet).sort((a, b) => a - b);
                cuadrasUnicas += starts.length;
                if (!starts.length) continue;

                let inicio = starts[0];
                let ultimo = starts[0];

                for (let i = 1; i < starts.length; i++) {
                    const actual = starts[i];
                    if (actual === ultimo + 100) {
                        ultimo = actual;
                        continue;
                    }
                    rangos.push({ calle, inicio, fin: ultimo + 100 });
                    inicio = actual;
                    ultimo = actual;
                }

                rangos.push({ calle, inicio, fin: ultimo + 100 });
            }

            rangos.sort((a, b) =>
                a.calle.localeCompare(b.calle, 'es', { sensitivity: 'base' }) ||
                a.inicio - b.inicio ||
                a.fin - b.fin
            );

            const lineas = rangos.map(item => `${item.calle} ${item.inicio} - ${item.fin}`);

            return {
                lineas,
                texto: lineas.join('\n'),
                rangos: rangos.length,
                cuadras: cuadrasUnicas,
                seleccionadas: seleccionCuadras.size
            };
        }

        function cerrarModalCuadras() {
            document.getElementById(CUADRAS_MODAL_ID)?.remove();
        }

        function quitarChecksCuadras() {
            document.querySelectorAll('.viena-cuadra-check-hitbox').forEach(hitbox => hitbox.remove());
            document.querySelectorAll(`input.${CUADRAS_CHECK_CLASS}`).forEach(check => check.remove());
        }

        function actualizarChecksCuadras() {
            if (!modoSeleccionCuadras) {
                quitarChecksCuadras();
                return;
            }

            for (const row of filasCableModem()) {
                const celdaDireccion =
                    row.querySelector('td[aria-describedby="grid_cm_gral___DireccionCliente"]') ||
                    row.querySelector('td[aria-describedby$="__DireccionCliente"]') ||
                    row.querySelector('td[aria-describedby*="DireccionCliente"]') ||
                    Array.from(row.cells || []).find(td => /direccioncliente/i.test(String(td.getAttribute('aria-describedby') || ''))) ||
                    Array.from(row.cells || []).find(td => getComputedStyle(td).display !== 'none');
                if (!celdaDireccion) continue;

                const datos = datosDireccionFilaCuadra(row);
                let check = celdaDireccion.querySelector(`input.${CUADRAS_CHECK_CLASS}`);

                if (!check) {
                    const hitbox = document.createElement('span');
                    hitbox.className = 'viena-cuadra-check-hitbox';
                    hitbox.style.cssText = 'display:inline-flex!important;align-items:center;justify-content:center;width:24px;height:22px;margin:-4px 3px -4px -5px;vertical-align:middle;cursor:pointer;position:relative;z-index:3;box-sizing:border-box;';

                    check = document.createElement('input');
                    check.type = 'checkbox';
                    check.className = CUADRAS_CHECK_CLASS;
                    check.style.cssText = 'display:block!important;appearance:auto!important;width:14px;height:14px;margin:0;cursor:pointer;opacity:1;position:relative;z-index:4;';
                    check.title = 'Seleccionar dirección para generar cuadras';

                    const frenarEvento = event => event.stopPropagation();
                    ['pointerdown', 'mousedown', 'dblclick'].forEach(tipo => {
                        hitbox.addEventListener(tipo, frenarEvento);
                        check.addEventListener(tipo, frenarEvento);
                    });
                    hitbox.addEventListener('click', event => {
                        event.stopPropagation();
                        if (event.target === check || check.disabled) return;
                        check.checked = !check.checked;
                        check.dispatchEvent(new Event('change', { bubbles: true }));
                    });
                    check.addEventListener('click', event => event.stopPropagation());

                    hitbox.appendChild(check);
                    celdaDireccion.insertBefore(hitbox, celdaDireccion.firstChild);
                }

                if (!datos) {
                    check.disabled = true;
                    check.checked = false;
                    check.title = 'Esta fila no tiene calle y altura utilizables.';
                    continue;
                }

                const clave = claveFilaCuadra(row, datos);
                check.disabled = false;
                check.title = `${datos.calle} ${datos.altura} → ${datos.inicioCuadra} - ${datos.finCuadra}`;
                check.dataset.vienaCuadraKey = clave;
                check.checked = seleccionCuadras.has(clave);
                check.onchange = () => {
                    if (check.checked) {
                        seleccionCuadras.set(clave, datos);
                    } else {
                        seleccionCuadras.delete(clave);
                    }
                    actualizarBotonCuadras({ sincronizarChecks: false });
                };
            }
        }

        function limpiarSeleccionCuadras({ salir = false } = {}) {
            seleccionCuadras.clear();
            cerrarModalCuadras();
            if (salir) modoSeleccionCuadras = false;
            actualizarChecksCuadras();
            actualizarBotonCuadras();
        }

        function seleccionarVisiblesCuadras() {
            actualizarChecksCuadras();
            const checks = Array.from(document.querySelectorAll(`input.${CUADRAS_CHECK_CLASS}`))
                .filter(check => !check.disabled);
            if (!checks.length) {
                mostrarToastEdificio('No hay direcciones válidas cargadas para seleccionar.', 'error');
                return;
            }

            const todosMarcados = checks.every(check => check.checked);
            for (const check of checks) {
                const nuevo = !todosMarcados;
                if (check.checked === nuevo) continue;
                check.checked = nuevo;
                check.dispatchEvent(new Event('change', { bubbles: true }));
            }
            actualizarBotonCuadras();
        }

        async function abrirModalCuadras() {
            const resultado = construirRangosCuadras();
            if (!resultado.lineas.length) {
                mostrarToastEdificio('Seleccioná al menos una dirección válida del listado.', 'error');
                return;
            }

            const templatesIniciales = await cargarTemplatesFallaCuadras();
            cerrarModalCuadras();

            const overlay = document.createElement('div');
            overlay.id = CUADRAS_MODAL_ID;
            overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,.42);display:flex;align-items:center;justify-content:center;padding:20px;';
            overlay.innerHTML = `
                <div style="width:min(820px,96vw);max-height:92vh;background:#fff;border-radius:8px;box-shadow:0 12px 38px rgba(0,0,0,.3);font-family:Arial,sans-serif;overflow:hidden;display:flex;flex-direction:column;">
                    <div style="padding:14px 18px;background:#337ab7;color:#fff;font-size:17px;font-weight:600;">Vista previa de cuadras</div>
                    <div style="padding:18px;overflow:auto;">
                        <div data-viena-cuadras-resumen style="font-size:13px;color:#555;margin-bottom:12px;line-height:1.5;"></div>
                        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px;">
                            <button type="button" class="btn btn-default btn-sm" data-viena-cuadras-toggle-fallas aria-expanded="false" style="font-weight:700;">Fallas rápidas ▾</button>
                            <button type="button" class="btn btn-default btn-sm" data-viena-cuadras-gestionar aria-expanded="false">Administrar templates ▾</button>
                        </div>
                        <div data-viena-cuadras-templates hidden style="display:grid;gap:7px;margin-bottom:0;overflow:hidden;max-height:0;opacity:0;transform:translateY(-4px);transition:max-height 180ms ease,opacity 150ms ease,transform 180ms ease,margin-bottom 180ms ease;"></div>
                        <div data-viena-cuadras-manager hidden style="border:1px solid #d9e2ec;border-radius:6px;background:#f8fafc;padding:12px;margin-bottom:0;overflow:hidden;max-height:0;opacity:0;transform:translateY(-4px);transition:max-height 200ms ease,opacity 160ms ease,transform 200ms ease,margin-bottom 200ms ease;">
                            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px;">
                                <div style="font-weight:700;color:#26384a;">Administrar fallas predefinidas</div>
                                <button type="button" class="btn btn-default btn-xs" data-viena-cuadras-ocultar-manager>Ocultar</button>
                            </div>
                            <div data-viena-cuadras-manager-list style="display:grid;gap:8px;"></div>
                            <div style="display:flex;gap:8px;margin-top:10px;">
                                <input type="text" class="form-control input-sm" data-viena-cuadras-nueva placeholder="Nueva falla..." maxlength="240" style="flex:1;">
                                <button type="button" class="btn btn-success btn-sm" data-viena-cuadras-agregar>Agregar</button>
                                <button type="button" class="btn btn-default btn-sm" data-viena-cuadras-restaurar>Restaurar predeterminadas</button>
                            </div>
                        </div>
                        <textarea data-viena-cuadras-preview spellcheck="false" style="box-sizing:border-box;width:100%;min-height:245px;resize:vertical;padding:12px;border:1px solid #b8c5d1;border-radius:5px;background:#fff;color:#22313f;font:14px/1.55 Consolas,Monaco,monospace;"></textarea>
                        <div style="font-size:12px;color:#6b7785;margin-top:7px;">Podés editar libremente el texto antes de copiar. Los templates sólo agregan o quitan su propia línea.</div>
                        <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:14px;">
                            <button type="button" class="btn btn-default" data-viena-cuadras-cerrar>Cerrar</button>
                            <button type="button" class="btn btn-primary" data-viena-cuadras-copiar>Copiar datos</button>
                        </div>
                    </div>
                </div>
                <div data-viena-cuadras-confirm-restaurar style="display:none;position:absolute;inset:0;z-index:4;align-items:center;justify-content:center;padding:20px;background:rgba(15,23,42,.42);">
                    <div role="dialog" aria-modal="true" aria-labelledby="viena-restaurar-title" style="width:min(430px,92vw);background:#fff;border-radius:9px;box-shadow:0 18px 55px rgba(0,0,0,.35);overflow:hidden;font-family:Arial,sans-serif;">
                        <div id="viena-restaurar-title" style="padding:14px 17px;background:#f0ad4e;color:#3f2b08;font-size:16px;font-weight:700;">Restaurar templates predeterminados</div>
                        <div style="padding:17px;">
                            <div style="font-size:14px;line-height:1.5;color:#34495e;">¿Estás seguro de que querés restaurar los templates?</div>
                            <div style="font-size:12px;line-height:1.45;color:#6b7785;margin-top:7px;">Se reemplazará el listado actual por los templates originales. El texto que ya escribiste en la vista previa no se modificará.</div>
                            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px;">
                                <button type="button" class="btn btn-default" data-viena-cuadras-restaurar-cancelar>Cancelar</button>
                                <button type="button" class="btn btn-warning" data-viena-cuadras-restaurar-confirmar>Sí, restaurar</button>
                            </div>
                        </div>
                    </div>
                </div>`;
            document.body.appendChild(overlay);

            const resumen = overlay.querySelector('[data-viena-cuadras-resumen]');
            const preview = overlay.querySelector('[data-viena-cuadras-preview]');
            const templatesHost = overlay.querySelector('[data-viena-cuadras-templates]');
            const manager = overlay.querySelector('[data-viena-cuadras-manager]');
            const managerList = overlay.querySelector('[data-viena-cuadras-manager-list]');
            const nuevaInput = overlay.querySelector('[data-viena-cuadras-nueva]');
            const toggleFallasBtn = overlay.querySelector('[data-viena-cuadras-toggle-fallas]');
            const gestionarBtn = overlay.querySelector('[data-viena-cuadras-gestionar]');
            const confirmRestaurar = overlay.querySelector('[data-viena-cuadras-confirm-restaurar]');
            let templates = [...templatesIniciales];

            if (resumen) {
                const nodo = nodoCmtsSeleccionCuadras();
                resumen.textContent = `${resultado.seleccionadas} direcciones seleccionadas · ${resultado.cuadras} cuadras detectadas · ${resultado.rangos} rangos generados${nodo ? ` · Nodo ${nodo}` : ''}`;
            }
            if (preview) preview.value = textoInicialCuadras(resultado);

            const sincronizarChecks = () => {
                if (!templatesHost || !preview) return;
                templatesHost.querySelectorAll('input[type="checkbox"][data-template-index]').forEach(check => {
                    const index = Number(check.dataset.templateIndex);
                    check.checked = Number.isInteger(index) && templates[index] ? tieneTemplateFallaCuadras(preview.value, templates[index]) : false;
                });
            };

            const renderTemplates = () => {
                if (!templatesHost) return;
                templatesHost.replaceChildren();
                templates.forEach((template, index) => {
                    const label = document.createElement('label');
                    label.style.cssText = 'display:flex;align-items:flex-start;gap:8px;margin:0;padding:6px 8px;border:1px solid #e2e8ef;border-radius:5px;background:#fff;cursor:pointer;font-weight:400;';
                    const check = document.createElement('input');
                    check.type = 'checkbox';
                    check.dataset.templateIndex = String(index);
                    check.style.cssText = 'margin-top:2px;';
                    check.checked = preview ? tieneTemplateFallaCuadras(preview.value, template) : false;
                    const span = document.createElement('span');
                    span.textContent = template;
                    check.addEventListener('change', () => {
                        if (!preview) return;
                        preview.value = alternarTemplateFallaCuadras(preview.value, template, check.checked);
                        preview.dispatchEvent(new Event('input', { bubbles: true }));
                    });
                    label.append(check, span);
                    templatesHost.appendChild(label);
                });
                if (!templates.length) {
                    const empty = document.createElement('div');
                    empty.style.cssText = 'font-size:13px;color:#6b7785;padding:5px 0;';
                    empty.textContent = 'No hay templates creados. Podés agregarlos desde Administrar templates.';
                    templatesHost.appendChild(empty);
                }
            };

            const renderManager = () => {
                if (!managerList) return;
                managerList.replaceChildren();
                templates.forEach((template, index) => {
                    const row = document.createElement('div');
                    row.style.cssText = 'display:grid;grid-template-columns:1fr auto auto;gap:6px;align-items:center;';
                    const input = document.createElement('input');
                    input.type = 'text';
                    input.className = 'form-control input-sm';
                    input.maxLength = 240;
                    input.value = template;
                    const guardar = document.createElement('button');
                    guardar.type = 'button';
                    guardar.className = 'btn btn-primary btn-sm';
                    guardar.textContent = 'Guardar';
                    const eliminar = document.createElement('button');
                    eliminar.type = 'button';
                    eliminar.className = 'btn btn-danger btn-sm';
                    eliminar.textContent = 'Eliminar';

                    guardar.addEventListener('click', async () => {
                        const nuevo = normalizarTemplateFallaCuadras(input.value);
                        if (!nuevo) {
                            mostrarToastEdificio('El template no puede quedar vacío.', 'error');
                            input.focus();
                            return;
                        }
                        const duplicado = templates.some((item, i) => i !== index && item.toLocaleLowerCase('es-AR') === nuevo.toLocaleLowerCase('es-AR'));
                        if (duplicado) {
                            mostrarToastEdificio('Ya existe un template con ese texto.', 'error');
                            return;
                        }
                        const anterior = templates[index];
                        const estabaActivo = preview && tieneTemplateFallaCuadras(preview.value, anterior);
                        templates[index] = nuevo;
                        templates = await guardarTemplatesFallaCuadras(templates);
                        if (estabaActivo && preview) preview.value = reemplazarTemplateFallaCuadras(preview.value, anterior, nuevo);
                        renderTemplates();
                        renderManager();
                        sincronizarChecks();
                        mostrarToastEdificio('Template actualizado.');
                    });

                    eliminar.addEventListener('click', async () => {
                        const anterior = templates[index];
                        if (preview && tieneTemplateFallaCuadras(preview.value, anterior)) {
                            preview.value = alternarTemplateFallaCuadras(preview.value, anterior, false);
                        }
                        templates.splice(index, 1);
                        templates = await guardarTemplatesFallaCuadras(templates);
                        renderTemplates();
                        renderManager();
                        sincronizarChecks();
                        mostrarToastEdificio('Template eliminado.');
                    });

                    row.append(input, guardar, eliminar);
                    managerList.appendChild(row);
                });
            };

            renderTemplates();
            renderManager();
            preview?.addEventListener('input', sincronizarChecks);

            const animarPanel = (panel, abierto, margen = 12) => {
                if (!panel) return;
                panel.dataset.vienaOpen = abierto ? '1' : '0';
                if (abierto) {
                    panel.hidden = false;
                    panel.style.maxHeight = '0px';
                    panel.style.opacity = '0';
                    panel.style.transform = 'translateY(-4px)';
                    panel.style.marginBottom = '0px';
                    requestAnimationFrame(() => {
                        panel.style.maxHeight = `${panel.scrollHeight}px`;
                        panel.style.opacity = '1';
                        panel.style.transform = 'translateY(0)';
                        panel.style.marginBottom = `${margen}px`;
                    });
                    setTimeout(() => {
                        if (panel.dataset.vienaOpen === '1') panel.style.maxHeight = 'none';
                    }, 220);
                    return;
                }

                if (panel.hidden) return;
                panel.style.maxHeight = `${panel.scrollHeight}px`;
                requestAnimationFrame(() => {
                    panel.style.maxHeight = '0px';
                    panel.style.opacity = '0';
                    panel.style.transform = 'translateY(-4px)';
                    panel.style.marginBottom = '0px';
                });
                setTimeout(() => {
                    if (panel.dataset.vienaOpen !== '1') panel.hidden = true;
                }, 220);
            };

            const setFallasAbiertas = abierta => {
                if (!templatesHost) return;
                animarPanel(templatesHost, abierta);
                if (toggleFallasBtn) {
                    toggleFallasBtn.setAttribute('aria-expanded', String(abierta));
                    toggleFallasBtn.textContent = abierta ? 'Fallas rápidas ▴' : 'Fallas rápidas ▾';
                }
            };
            const setManagerAbierto = abierto => {
                if (!manager) return;
                if (abierto) renderManager();
                animarPanel(manager, abierto);
                if (gestionarBtn) {
                    gestionarBtn.setAttribute('aria-expanded', String(abierto));
                    gestionarBtn.textContent = abierto ? 'Administrar templates ▴' : 'Administrar templates ▾';
                }
            };

            toggleFallasBtn?.addEventListener('click', () => setFallasAbiertas(templatesHost?.dataset.vienaOpen !== '1'));
            gestionarBtn?.addEventListener('click', () => setManagerAbierto(manager?.dataset.vienaOpen !== '1'));
            overlay.querySelector('[data-viena-cuadras-ocultar-manager]')?.addEventListener('click', () => setManagerAbierto(false));

            overlay.querySelector('[data-viena-cuadras-agregar]')?.addEventListener('click', async () => {
                const nuevo = normalizarTemplateFallaCuadras(nuevaInput?.value);
                if (!nuevo) {
                    mostrarToastEdificio('Escribí el texto del nuevo template.', 'error');
                    nuevaInput?.focus();
                    return;
                }
                if (templates.some(item => item.toLocaleLowerCase('es-AR') === nuevo.toLocaleLowerCase('es-AR'))) {
                    mostrarToastEdificio('Ese template ya existe.', 'error');
                    return;
                }
                templates.push(nuevo);
                templates = await guardarTemplatesFallaCuadras(templates);
                if (nuevaInput) nuevaInput.value = '';
                renderTemplates();
                renderManager();
                mostrarToastEdificio('Template agregado.');
            });

            const mostrarConfirmacionRestaurar = mostrar => {
                if (!confirmRestaurar) return;
                if (mostrar) {
                    confirmRestaurar.style.display = 'flex';
                    requestAnimationFrame(() => confirmRestaurar.querySelector('[data-viena-cuadras-restaurar-cancelar]')?.focus());
                } else {
                    confirmRestaurar.style.display = 'none';
                }
            };

            overlay.querySelector('[data-viena-cuadras-restaurar]')?.addEventListener('click', () => {
                mostrarConfirmacionRestaurar(true);
            });
            overlay.querySelector('[data-viena-cuadras-restaurar-cancelar]')?.addEventListener('click', () => {
                mostrarConfirmacionRestaurar(false);
            });
            overlay.querySelector('[data-viena-cuadras-restaurar-confirmar]')?.addEventListener('click', async () => {
                templates = await guardarTemplatesFallaCuadras([...CUADRAS_TEMPLATES_DEFAULT]);
                renderTemplates();
                renderManager();
                sincronizarChecks();
                mostrarConfirmacionRestaurar(false);
                mostrarToastEdificio('Templates predeterminados restaurados.');
            });

            overlay.querySelector('[data-viena-cuadras-cerrar]')?.addEventListener('click', cerrarModalCuadras);
            overlay.querySelector('[data-viena-cuadras-copiar]')?.addEventListener('click', async () => {
                const texto = String(preview?.value || '').trimEnd();
                if (!texto) {
                    mostrarToastEdificio('No hay información para copiar.', 'error');
                    return;
                }
                const ok = await copiarTexto(texto);
                if (!ok) {
                    mostrarToastEdificio('No se pudo copiar al portapapeles.', 'error');
                    return;
                }
                cerrarModalCuadras();
                limpiarSeleccionCuadras({ salir: true });
                mostrarToastEdificio('Datos de cuadras copiados al portapapeles.');
            });
        }

        function datosEdificioActual() {
            const idInput = document.querySelector('#CMS-FORM-FILTRO input[name="idedificio"]');
            const idFiltro = String(idInput?.value || '').trim();
            if (!idFiltro) return { ok: false, error: 'Ingresá o filtrá un ID Edificio primero.' };

            const rows = filasCableModem().filter(row => {
                const idFila = valorCeldaFila(row, 'infocliente.edificio.idedificio');
                return !idFila || idFila === idFiltro;
            });
            if (!rows.length) return { ok: false, error: 'No hay resultados cargados para ese edificio.' };

            const conteoNodos = new Map();
            const direcciones = new Set();
            for (const row of rows) {
                const nodo = valorCeldaFila(row, 'cmNodo.nodoCmts').toUpperCase();
                if (nodo) conteoNodos.set(nodo, (conteoNodos.get(nodo) || 0) + 1);

                // Calle + altura evita que piso/depto de distintos abonados del mismo
                // edificio convierta una misma dirección en varias direcciones distintas.
                const calle = valorCeldaFila(row, 'infocliente.calle');
                const nro = valorCeldaFila(row, 'infocliente.nro');
                const direccion = [calle, nro].filter(Boolean).join(' ').trim() ||
                    valorCeldaFila(row, '__DireccionCliente');
                if (direccion) direcciones.add(direccion);
            }

            if (!conteoNodos.size) {
                return { ok: false, error: 'No pude identificar el Nodo CMTS.' };
            }

            // Un mismo edificio puede devolver CMs asociados a más de un Nodo CMTS.
            // En ese caso usamos el nodo modal: el que aparece en más filas del jqGrid.
            // Si hay empate en el máximo, no adivinamos y pedimos revisión manual.
            const nodosOrdenados = Array.from(conteoNodos.entries())
                .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
            const maxRepeticiones = nodosOrdenados[0][1];
            const nodosMasFrecuentes = nodosOrdenados.filter(([, cantidad]) => cantidad === maxRepeticiones);
            if (nodosMasFrecuentes.length !== 1) {
                return {
                    ok: false,
                    error: 'El edificio tiene más de un Nodo CMTS con la misma cantidad de CMs. Revisá los resultados antes de copiar.'
                };
            }
            const nodoCmtsPrincipal = nodosMasFrecuentes[0][0];

            if (direcciones.size !== 1) {
                return { ok: false, error: direcciones.size ? 'El edificio devuelve más de una dirección. Revisá los resultados antes de copiar.' : 'No pude identificar la dirección.' };
            }

            return {
                ok: true,
                idEdificio: idFiltro,
                nodoCmts: nodoCmtsPrincipal,
                direccion: Array.from(direcciones)[0]
            };
        }

        async function copiarTexto(texto) {
            try {
                await navigator.clipboard.writeText(texto);
                return true;
            } catch (_) {
                const ta = document.createElement('textarea');
                ta.value = texto;
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                let ok = false;
                try { ok = document.execCommand('copy'); } catch (_) {}
                ta.remove();
                return ok;
            }
        }

        function cerrarModalEdificio() {
            document.getElementById(EDIF_MODAL_ID)?.remove();
        }


        function obtenerHostToastSeguro() {
            // Los v-dialog persistent de Vuetify animan/escalean cuando reciben un click
            // "afuera". Un toast agregado a document.body cuenta como click externo.
            // Montarlo dentro del dialog activo de mayor z-index evita ese mini-zoom.
            const activos = Array.from(document.querySelectorAll('.v-dialog__content.v-dialog__content--active'))
                .map(content => ({
                content,
                dialog: content.querySelector('.v-dialog.v-dialog--active')
            }))
                .filter(({dialog}) => dialog && dialog.isConnected && getComputedStyle(dialog).display !== 'none')
                .sort((a, b) => {
                    const za = Number.parseInt(getComputedStyle(a.content).zIndex || '0', 10) || 0;
                    const zb = Number.parseInt(getComputedStyle(b.content).zIndex || '0', 10) || 0;
                    return za - zb;
                });
            return activos.length ? activos[activos.length - 1].dialog : document.body;
        }

        function mostrarToastEdificio(mensaje, tipo = 'success') {
            document.getElementById(EDIF_TOAST_ID)?.remove();

            const palette = tipo === 'error'
                ? { accent: '#c62828', icon: '!', title: 'MIRA5 · VIENA NOC Tools' }
                : { accent: '#28a745', icon: '✓', title: 'MIRA5 · VIENA NOC Tools' };

            const toast = document.createElement('div');
            toast.id = EDIF_TOAST_ID;
            toast.setAttribute('role', 'status');
            toast.setAttribute('aria-live', 'polite');
            toast.style.cssText = [
                'position:fixed',
                'top:22px',
                'right:22px',
                'z-index:2147483647',
                'width:min(420px,calc(100vw - 32px))',
                'background:#fff',
                'color:#333',
                'border:1px solid rgba(0,0,0,.12)',
                `border-left:5px solid ${palette.accent}`,
                'border-radius:8px',
                'box-shadow:0 10px 30px rgba(0,0,0,.22)',
                'font-family:Arial,sans-serif',
                'display:flex',
                'align-items:center',
                'gap:11px',
                'padding:13px 14px',
                'opacity:0',
                'transform:translateY(-10px)',
                'transition:opacity .18s ease,transform .18s ease'
            ].join(';');

            const icono = document.createElement('div');
            icono.textContent = palette.icon;
            icono.setAttribute('aria-hidden', 'true');
            icono.style.cssText = `width:28px;height:28px;min-width:28px;border-radius:50%;background:${palette.accent};color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:700;line-height:1;`;

            const contenido = document.createElement('div');
            contenido.style.cssText = 'flex:1;min-width:0;';
            const titulo = document.createElement('div');
            titulo.textContent = palette.title;
            titulo.style.cssText = 'font-size:12px;font-weight:700;color:#1f4f7d;margin-bottom:2px;';
            const texto = document.createElement('div');
            texto.textContent = mensaje;
            texto.style.cssText = 'font-size:14px;font-weight:600;line-height:1.35;';
            contenido.append(titulo, texto);

            const cerrar = document.createElement('button');
            cerrar.type = 'button';
            cerrar.setAttribute('aria-label', 'Cerrar notificación');
            cerrar.textContent = '×';
            cerrar.style.cssText = 'border:0;background:transparent;color:#777;font-size:22px;line-height:1;padding:0 2px;cursor:pointer;';

            toast.append(icono, contenido, cerrar);
            const toastHost = obtenerHostToastSeguro();
            toast.dataset.vienaToastHost = toastHost === document.body ? 'body' : 'active-dialog';
            toastHost.appendChild(toast);

            let timer = 0;
            const quitar = () => {
                if (!toast.isConnected) return;
                if (timer) clearTimeout(timer);
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(-10px)';
                setTimeout(() => toast.remove(), 190);
            };

            cerrar.tabIndex = -1;
            cerrar.addEventListener('pointerdown', event => { event.preventDefault(); event.stopPropagation(); }, true);
            cerrar.addEventListener('mousedown', event => { event.preventDefault(); event.stopPropagation(); }, true);
            cerrar.addEventListener('click', event => { event.preventDefault(); event.stopPropagation(); quitar(); });
            toast.addEventListener('click', event => event.stopPropagation());
            requestAnimationFrame(() => {
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            });
            timer = setTimeout(quitar, 3000);
        }

        function escaparHtmlSeguro(valor) {
            return String(valor ?? '').replace(/[&<>"']/g, c => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
            }[c]));
        }

        function abrirModalEdificio(datos) {
            cerrarModalEdificio();
            const idEdificioSeguro = escaparHtmlSeguro(datos?.idEdificio);
            const nodoCmtsSeguro = escaparHtmlSeguro(datos?.nodoCmts);
            const direccionSegura = escaparHtmlSeguro(datos?.direccion);
            const overlay = document.createElement('div');
            overlay.id = EDIF_MODAL_ID;
            overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483646;background:rgba(0,0,0,.42);display:flex;align-items:center;justify-content:center;padding:20px;';
            overlay.innerHTML = `
                <div style="width:min(520px,96vw);background:#fff;border-radius:7px;box-shadow:0 12px 38px rgba(0,0,0,.3);font-family:Arial,sans-serif;overflow:hidden;">
                    <div style="padding:14px 18px;background:#337ab7;color:#fff;font-size:17px;font-weight:600;">Copiar datos del edificio</div>
                    <div style="padding:18px;">
                        <div style="font-size:13px;color:#555;margin-bottom:12px;line-height:1.5;">
                            <b>ID Edificio:</b> ${idEdificioSeguro}<br>
                            <b>Nodo CMTS:</b> ${nodoCmtsSeguro}<br>
                            <b>Dirección:</b> ${direccionSegura}
                        </div>
                        <label for="viena-falla-edificio" style="display:block;font-weight:600;margin-bottom:6px;">Falla detectada</label>
                        <textarea id="viena-falla-edificio" class="form-control" rows="4" placeholder="Indicá la falla detectada..." style="resize:vertical;"></textarea>
                        <div id="viena-edif-error" style="min-height:20px;color:#a94442;font-size:12px;margin-top:5px;"></div>
                        <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:8px;">
                            <button type="button" class="btn btn-default" data-viena-cancelar>Cerrar</button>
                            <button type="button" class="btn btn-primary" data-viena-copiar>Copiar datos</button>
                        </div>
                    </div>
                </div>`;
            document.body.appendChild(overlay);
            const textarea = overlay.querySelector('#viena-falla-edificio');
            setTimeout(() => textarea?.focus(), 0);
            // Modal persistente: no cerrar al hacer click en el fondo. El operador puede
            // seleccionar/escribir sin riesgo de perder el texto; sólo Cerrar lo descarta.
            overlay.querySelector('[data-viena-cancelar]')?.addEventListener('click', cerrarModalEdificio);
            overlay.querySelector('[data-viena-copiar]')?.addEventListener('click', async () => {
                const falla = String(textarea?.value || '').trim();
                const error = overlay.querySelector('#viena-edif-error');
                if (!falla) {
                    if (error) error.textContent = 'Completá la falla detectada para continuar.';
                    textarea?.focus();
                    return;
                }
                const template = `ID EDIFICIO: ${datos.idEdificio}\nNODO CMTS: ${datos.nodoCmts}\nDIRECCION: ${datos.direccion}\nFALLA DETECTADA: ${falla}`;
                const ok = await copiarTexto(template);
                if (!ok) {
                    if (error) error.textContent = 'No se pudo copiar al portapapeles.';
                    return;
                }
                cerrarModalEdificio();
                mostrarToastEdificio('Datos del edificio copiados al portapapeles.');
            });
        }

        function asegurarHostAccionesCm() {
            const form = document.getElementById('CMS-FORM-FILTRO');
            if (!form) return null;
            const submit = form.querySelector('button[type="submit"].btn-primary');
            if (!submit) return null;

            let host = document.getElementById(CM_ACTIONS_ID);
            if (!host) {
                host = document.createElement('span');
                host.id = CM_ACTIONS_ID;
                host.style.cssText = 'display:inline-flex;align-items:center;gap:8px;margin-left:8px;vertical-align:middle;white-space:nowrap;';
                submit.insertAdjacentElement('afterend', host);
            } else if (host.parentElement !== submit.parentElement || host.previousElementSibling !== submit) {
                submit.insertAdjacentElement('afterend', host);
            }
            return host;
        }

        function actualizarBotonEdificio() {
            const form = document.getElementById('CMS-FORM-FILTRO');
            const host = asegurarHostAccionesCm();
            if (!form || !host) return;
            const idInput = form.querySelector('input[name="idedificio"]');
            if (!idInput) return;

            const id = String(idInput.value || '').trim();
            let btn = document.getElementById(EDIF_BTN_ID);

            if (!id) {
                btn?.remove();
                actualizarBotonCuadras();
                return;
            }

            if (!btn) {
                btn = document.createElement('button');
                btn.type = 'button';
                btn.id = EDIF_BTN_ID;
                btn.className = 'btn btn-success';
                btn.addEventListener('click', () => {
                    const datos = datosEdificioActual();
                    if (!datos.ok) {
                        mostrarToastEdificio(datos.error, 'error');
                        return;
                    }
                    abrirModalEdificio(datos);
                });
            }

            const textoBoton = `Copiar datos Edif - ${id}`;
            if (btn.textContent !== textoBoton) btn.textContent = textoBoton;
            host.appendChild(btn);
            actualizarBotonCuadras();
        }

        function actualizarBotonCuadras({ sincronizarChecks = true } = {}) {
            const host = asegurarHostAccionesCm();
            if (!host) return;

            let btn = document.getElementById(CUADRAS_BTN_ID);
            if (!btn) {
                btn = document.createElement('button');
                btn.type = 'button';
                btn.id = CUADRAS_BTN_ID;
                btn.className = 'btn btn-info';
            }

            btn.className = modoSeleccionCuadras ? 'btn btn-primary' : 'btn btn-info';
            const texto = modoSeleccionCuadras
                ? `Vista previa cuadras (${seleccionCuadras.size})`
                : 'Seleccionar cuadras';
            if (btn.textContent !== texto) btn.textContent = texto;

            btn.onclick = () => {
                if (!modoSeleccionCuadras) {
                    if (!filasCableModem().length) {
                        mostrarToastEdificio('No hay CMs cargados para seleccionar.', 'error');
                        return;
                    }
                    modoSeleccionCuadras = true;
                    seleccionCuadras.clear();
                    actualizarBotonCuadras();
                    return;
                }
                abrirModalCuadras();
            };

            const edif = document.getElementById(EDIF_BTN_ID);
            if (edif) host.appendChild(edif);
            host.appendChild(btn);

            let visibles = document.getElementById(CUADRAS_VISIBLE_ID);
            let cancelar = document.getElementById(CUADRAS_CANCEL_ID);

            if (!modoSeleccionCuadras) {
                visibles?.remove();
                cancelar?.remove();
                quitarChecksCuadras();
                return;
            }

            if (!visibles) {
                visibles = document.createElement('button');
                visibles.type = 'button';
                visibles.id = CUADRAS_VISIBLE_ID;
                visibles.className = 'btn btn-default';
                visibles.onclick = seleccionarVisiblesCuadras;
            }

            const checksValidos = Array.from(document.querySelectorAll(`input.${CUADRAS_CHECK_CLASS}`))
                .filter(check => !check.disabled);
            const todosMarcados = checksValidos.length > 0 && checksValidos.every(check => check.checked);
            visibles.textContent = todosMarcados ? 'Quitar visibles' : 'Seleccionar visibles';

            if (!cancelar) {
                cancelar = document.createElement('button');
                cancelar.type = 'button';
                cancelar.id = CUADRAS_CANCEL_ID;
                cancelar.className = 'btn btn-default';
                cancelar.textContent = 'Cancelar selección';
                cancelar.onclick = () => limpiarSeleccionCuadras({ salir: true });
            }

            host.append(visibles, cancelar);
            if (sincronizarChecks) actualizarChecksCuadras();
        }

        function programarActualizacionAccionesCm() {
            if (accionesCmRaf) return;
            accionesCmRaf = requestAnimationFrame(() => {
                accionesCmRaf = 0;
                actualizarBotonEdificio();
            });
        }

        document.addEventListener('input', e => {
            if (e.target?.matches?.('#CMS-FORM-FILTRO input[name="idedificio"]')) actualizarBotonEdificio();
        }, true);
        document.addEventListener('change', e => {
            if (e.target?.matches?.('#CMS-FORM-FILTRO input[name="idedificio"]')) actualizarBotonEdificio();
        }, true);

        document.addEventListener('submit', e => {
            if (!e.target?.matches?.('#CMS-FORM-FILTRO')) return;
            seleccionCuadras.clear();
            cerrarModalCuadras();
            programarActualizacionAccionesCm();
        }, true);
        document.addEventListener('click', e => {
            if (!e.target?.closest?.('#CMS-FORM-FILTRO button[type="submit"]')) return;
            seleccionCuadras.clear();
            cerrarModalCuadras();
        }, true);

        const observerEdificio = new MutationObserver(mutations => {
            const cambioRelevante = mutations.some(mutation =>
                Array.from(mutation.addedNodes || []).some(node =>
                    node?.nodeType === 1 && (
                        node.matches?.('#grid_cm_gral, #grid_cm_gral tbody, #grid_cm_gral tr.jqgrow, #CMS-FORM-FILTRO') ||
                        node.querySelector?.('#grid_cm_gral, #grid_cm_gral tr.jqgrow, #CMS-FORM-FILTRO')
                    )
                ) ||
                Array.from(mutation.removedNodes || []).some(node =>
                    node?.nodeType === 1 && (
                        node.matches?.('#grid_cm_gral, #grid_cm_gral tbody, #grid_cm_gral tr.jqgrow') ||
                        node.querySelector?.('#grid_cm_gral, #grid_cm_gral tr.jqgrow')
                    )
                )
            );
            if (cambioRelevante) programarActualizacionAccionesCm();
        });
        observerEdificio.observe(document.documentElement, { childList: true, subtree: true });
        actualizarBotonEdificio();
    }

    // ================================================================
    // MIRA5 / GPON — ESCUCHAR ÓRDENES
    // ================================================================

    if (
        ES_MIRA5 ||
        ES_GPON
    ) {

        if (chrome?.runtime?.onMessage) {
            chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
                if(msg?.type==='VIENA_BRIDGE_PING_DIRECT'){
                    const target=String(msg.target||'');
                    const actual=destinoPingActual();
                    const expected=target==='gpon'?'GPON':target==='mira-cm'?'MIRA5_CABLEMODEM':target==='mira-stats'?'MIRA5_STATS':'';
                    sendResponse({ok:Boolean(actual&&actual===expected),destino:actual||''});
                    return;
                }
                if(msg?.type!=='VIENA_BRIDGE_RUN') return;
                const comando=msg.command;
                const target=String(msg.target||'');
                const actual=destinoPingActual();
                const expected=target==='gpon'?'GPON':target==='mira-cm'?'MIRA5_CABLEMODEM':target==='mira-stats'?'MIRA5_STATS':'';
                if(!comando?.id || !actual || actual!==expected){ sendResponse({ok:false,estado:'error',mensaje:'Pestaña destino incorrecta.'}); return; }
                marcarPestanaAutomatizacion(actual);
                let done=false;
                const finish=result=>{ if(done)return; done=true; directCommandWaiters.delete(comando.id); sendResponse(result); };
                directCommandWaiters.set(comando.id,finish);
                procesarComando(comando).catch(error=>finish({ok:false,estado:'error',mensaje:String(error?.message||error)}));
                setTimeout(()=>finish({ok:false,estado:'sin_respuesta',mensaje:'La automatización no terminó a tiempo.'}),20000);
                return true;
            });
        }

        // Presencia de la pestaña: se conserva como diagnóstico.
        publicarHeartbeat();
        setInterval(publicarHeartbeat, 2000);

        // Validación real bajo demanda. Esto funciona aunque el heartbeat haya
        // quedado viejo por throttling de Chrome en pestañas de fondo.
        GM_addValueChangeListener(
            KEY_PING,
            (_nombre, _anterior, ping) => {
                responderPing(ping);
            }
        );

        GM_addValueChangeListener(
            KEY_COMANDO,

            (
                nombre,
                anterior,
                nuevo,
                remoto
            ) => {
                if (!nuevo) return;

                // El listener puede dispararse más de una vez según las
                // pestañas/actualizaciones de Tampermonkey. procesarComando()
                // deduplica por id y encola una orden nueva si corresponde.
                log('📡 Nueva orden recibida');

                procesarComando(nuevo);
            }
        );

        // v1.0.7:
        // NO reprocesar KEY_COMANDO al cargar/refrescar MIRA5 o GPON.
        // Las órdenes se ejecutan exclusivamente cuando VIENA genera una
        // orden NUEVA y GM_addValueChangeListener la recibe.
        // Esto evita que F5 vuelva a filtrar el último nodo/edificio.
        // La pestaña destino debe estar abierta antes de pulsar el botón en VIENA.

        log(
            ES_MIRA5
                ? '🚀 Receptor MIRA5 activo'
                : '🚀 Receptor GPON activo'
        );
    }

})();
