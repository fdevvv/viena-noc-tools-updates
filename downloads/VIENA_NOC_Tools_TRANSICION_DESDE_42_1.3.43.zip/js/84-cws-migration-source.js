(function(root){
  'use strict';
  const STORE_ID='kncbbeclddielngolalkmlclfljgaoje';
  function create(chrome,transfer){
    let pending=null;
    const bounded=async operation=>{let timer;try{return await Promise.race([operation,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('migration_read_timeout')),5000);})]);}finally{clearTimeout(timer);}};
    async function handle(message,sender){
      // Only the actual store extension may request data. Website senders are never accepted.
      if(sender?.id!==STORE_ID||sender?.url?.startsWith('http'))return null;
      const manifest=chrome.runtime.getManifest();
      if(message?.type==='VIENA_CWS_PROBE')return {protocol:1,sourceId:chrome.runtime.id,name:manifest.name,version:manifest.version};
      if(message?.type!=='VIENA_CWS_EXPORT')return null;
      if(pending)return pending;
      pending=(async()=>{const [local,sync]=await Promise.all([bounded(chrome.storage.local.get(null)),bounded(chrome.storage.sync.get(null))]);return {protocol:1,sourceId:chrome.runtime.id,backup:transfer.makeBackup(local,sync,chrome.runtime.id,manifest.version)};})();
      try{return await pending;}finally{pending=null;}
    }
    return {handle};
  }
  const api={STORE_ID,create};
  if(typeof module==='object'&&module.exports)module.exports=api;
  else {
    root.VienaCwsMigrationSource=api;
    const source=create(root.chrome,root.VienaInstallationTransfer);
    root.chrome.runtime.onMessageExternal.addListener((message,sender,respond)=>{
      if(sender?.id!==STORE_ID||!['VIENA_CWS_PROBE','VIENA_CWS_EXPORT'].includes(message?.type))return false;
      source.handle(message,sender).then(value=>respond(value),()=>respond({error:'No se pudo leer la configuración original. Reintentá sin desinstalarla.'}));
      return true;
    });
  }
})(globalThis);
