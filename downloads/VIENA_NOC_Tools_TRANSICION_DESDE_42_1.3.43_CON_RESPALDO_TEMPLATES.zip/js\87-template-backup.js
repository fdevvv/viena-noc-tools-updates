(function(root){
  'use strict';
  const transfer=typeof module==='object'&&module.exports?require('./82-installation-transfer.js'):root.VienaInstallationTransfer;
  const keys=new Set(['viena_custom_templates_v1','viena_custom_template_groups_v1','viena_system_complete_config_v1','viena_template_message_overrides_v1','viena_motivo_overrides_v1','viena_motivo_contextos_v2','viena_edificio_fallas_templates_v1','viena_cuadras_fallas_templates_v1','viena_cuadras_fallas_templates_v1_opciones']);
  const taskPrefix='viena_create_task_templates_v1:';
  const allowed=key=>keys.has(key)||(key.startsWith(taskPrefix)&&key.length>taskPrefix.length);
  const select=area=>Object.fromEntries(Object.entries(area).filter(([key])=>allowed(key)));
  const strings=value=>Array.isArray(value)&&value.every(v=>typeof v==='string');
  function validate(backup){
    transfer.validate(backup);
    const picked={...backup,local:select(backup.local),sync:select(backup.sync)};
    if(!Object.keys(picked.local).length&&!Object.keys(picked.sync).length)throw Error('Este archivo no contiene templates guardados.');
    for(const area of [picked.local,picked.sync])for(const [key,value]of Object.entries(area)){
      if(key.startsWith(taskPrefix)){
        if(value?.schema!==1||!Array.isArray(value.templates))throw Error('Biblioteca de tareas incompatible.');
        const ids=new Set();for(const t of value.templates){
          if(!t||typeof t.id!=='string'||!t.id||ids.has(t.id)||typeof t.name!=='string'||!t.name.trim()||typeof t.body!=='string'||!Array.isArray(t.fields)||!strings(t.associations))throw Error('Template de tareas inválido.');ids.add(t.id);
          for(const f of t.fields)if(!f||typeof f.label!=='string'||!f.label.trim()||!['single','multi','text'].includes(f.type)||!strings(f.options)||(f.type!=='text'&&!f.options.length)||(f.defaults!==undefined&&(!strings(f.defaults)||f.defaults.some(v=>f.type!=='text'&&!f.options.includes(v))||(f.type!=='multi'&&f.defaults.length>1))))throw Error('Opciones del template de tareas inválidas.');
        }
      }else if(key==='viena_edificio_fallas_templates_v1'){
        if(value?.schema!==1||!Array.isArray(value.templates))throw Error('Biblioteca de edificio incompatible.');
        const ids=new Set();for(const t of value.templates){if(!t||typeof t.id!=='string'||!t.id||ids.has(t.id)||typeof t.text!=='string'||!t.text.trim()||!strings(t.options))throw Error('Template de edificio inválido.');ids.add(t.id);}
      }else if(key==='viena_cuadras_fallas_templates_v1'){
        if(!strings(value)||value.some(v=>!v.trim())||new Set(value).size!==value.length)throw Error('Templates de cuadras inválidos.');
      }else if(key==='viena_cuadras_fallas_templates_v1_opciones'){
        if(!value||Array.isArray(value)||typeof value!=='object'||Object.values(value).some(v=>!strings(v)))throw Error('Opciones de cuadras inválidas.');
      }else if(!value||typeof value!=='object')throw Error('Configuración de templates incompatible.');
    }
    return structuredClone(picked);
  }
  function makeBackup(local,sync,sourceId,version){return validate(transfer.makeBackup(select(local),select(sync),sourceId,version));}
  function summarize(backup){
    const {local,sync}=validate(backup),area={...sync,...local};let task=0;
    for(const [key,value]of Object.entries(area))if(key.startsWith(taskPrefix))task+=value.templates.length;
    const count=value=>value&&typeof value==='object'?(typeof value.mensaje==='string'?1:Object.values(value).reduce((sum,v)=>sum+count(v),0)):0;
    return {task,building:area.viena_edificio_fallas_templates_v1?.templates.length||0,cuadras:area.viena_cuadras_fallas_templates_v1?.length||0,personal:count(area.viena_custom_template_groups_v1)+count(area.viena_custom_templates_v1),sections:Object.keys(local).length+Object.keys(sync).length};
  }
  async function restore(storage,backup){return transfer.restore(storage,validate(backup));}
  const api={makeBackup,validate,summarize,restore,allowed};if(typeof module==='object'&&module.exports)module.exports=api;else root.VienaTemplateBackup=api;
})(globalThis);
