(function () {
    'use strict';

    // =========================================================
    // CONFIGURACIÓN
    // =========================================================

    // Al cargar/recargar Métricas dejamos al operador directamente en la
    // pestaña Estadísticas, que es la vista operativa usada por la extensión.
    // El elemento puede aparecer unos instantes después del document_idle,
    // por eso se reintenta durante una ventana acotada y se hace un solo click.
    let estadisticasAutoActivada = false;
    function activarEstadisticasAlCargar() {
        if (estadisticasAutoActivada) return true;
        const enlace = document.querySelector(
            'li#li_estadisticas > a[href="#tabpanel_estadisticas"], a[href="#tabpanel_estadisticas"][data-toggle="tab"]'
        );
        if (!enlace) return false;
        estadisticasAutoActivada = true;
        try { enlace.click(); } catch (_) {}
        return true;
    }

    function asegurarVistaEstadisticas() {
        if (activarEstadisticasAlCargar()) return;
        let intentos = 0;
        const timer = setInterval(() => {
            intentos += 1;
            if (activarEstadisticasAlCargar() || intentos >= 80) clearInterval(timer);
        }, 250);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', asegurarVistaEstadisticas, { once: true });
    } else {
        asegurarVistaEstadisticas();
    }

    let MI_USUARIO = '';

    // La identidad propia sigue usando el azul histórico. Para el resto de
    // operadores se conserva un color estable por usuario para que dos
    // banderas de personas distintas no queden visualmente iguales.
    const BANDERA_COLOR_MAP_KEY = 'metricas_bandera_colores_usuarios_v1';
    const PALETA_BANDERAS_OTROS = [
        '#f4b183', // durazno
        '#c6e0b4', // verde suave
        '#ffd966', // amarillo
        '#d9e1f2', // azul grisáceo
        '#e4dfec', // lavanda
        '#f8cbad', // salmón
        '#b4c6e7', // periwinkle
        '#d5a6bd', // rosa malva
        '#b6d7a8', // verde
        '#ffe599', // ámbar claro
        '#cfe2f3', // celeste claro
        '#d9d2e9', // violeta claro
        '#fce5cd', // crema
        '#ead1dc', // rosa claro
        '#b7d7d8', // turquesa gris
        '#d0e0e3'  // gris azulado
    ];
    let mapaColoresBandera = {};
    let mapaColoresBanderaCargado = false;

    chrome.storage.local.get(['viena_usuario', BANDERA_COLOR_MAP_KEY]).then(r => {
        MI_USUARIO = String(r.viena_usuario || '').trim().toLowerCase();
        mapaColoresBandera = (r[BANDERA_COLOR_MAP_KEY] && typeof r[BANDERA_COLOR_MAP_KEY] === 'object')
            ? { ...r[BANDERA_COLOR_MAP_KEY] }
            : {};
        mapaColoresBanderaCargado = true;
        procesarTabla();
    });
    chrome.storage.onChanged.addListener((c,a) => {
        if (a === 'local' && c.viena_usuario) {
            MI_USUARIO = String(c.viena_usuario.newValue || '').trim().toLowerCase();
            procesarTabla();
        }
        if (a === 'local' && c[BANDERA_COLOR_MAP_KEY]) {
            const nuevo = c[BANDERA_COLOR_MAP_KEY].newValue;
            if (nuevo && typeof nuevo === 'object') mapaColoresBandera = { ...nuevo };
        }
    });

    // Colores de estado de fila
    const COLOR_VERDE = '#b7e4c7';
    const COLOR_AMARILLO = '#fff3a3';
    const COLOR_NARANJA = '#ffb347';
    const COLOR_VIOLETA = '#d8b4fe';

    // Color de celda de bandera según usuario
    const COLOR_MI_BANDERA = '#8ecae6';

    // Borde de fila seleccionada
    const COLOR_SELECCION = '#0066ff';

    // Historial local
    const STORAGE_KEY = 'metricas_nodos_vts_v7__dev';
    const STORAGE_DATE_KEY = 'metricas_nodos_vts_fecha_operativa_v1';

    // =========================================================
    // METRICAS_SYNC — FASE 3 (LECTURA SOLAMENTE)
    // =========================================================

    const METRICAS_SYNC_ENDPOINT =
        'https://script.google.com/macros/s/AKfycbxLKOhNj2nW8IQUVbxJK_i9j2xnIMYZQpDaecGpqhxWdB3Zld5Vi_ERWKqLsnFKdkVCFw/exec';

    const METRICAS_SYNC_POLL_MS = 10000;
    const METRICAS_SYNC_TIMEOUT_MS = 6000;
    const METRICAS_SYNC_INIT_RETRY_MS = 15000;
    const METRICAS_FLAG_REPLACEMENT_GRACE_MS = 12000;

    const METRICAS_SYNC_STATUS_ID =
        'viena-metricas-sync-status';

    const METRICAS_VIOLETA_TOAST_KEY =
        'viena_metricas_violeta_toast_v1';

    const METRICAS_VIOLETA_TOOLTIP =
        'Valor incrementado después del reconocimiento. Ctrl + doble click para volver a marcarla en verde.';

    const METRICAS_VIOLETA_TOAST =
        'Violeta = aumentó después de la última marca. Ctrl + doble click para reconocer el nuevo valor.';

    // En Fase 3 estos datos se cargan y validan, pero todavía NO participan
    // de procesarFila() ni modifican ningún color/estado visual.
    let metricasSyncEstados = new Map();
    let metricasSyncPendientes = new Map();
    let metricasSyncUltimoWriteMs = new Map();
    let metricasSyncInitEnCurso = new Set();
    let metricasSyncInitUltimoIntento = new Map();
    let metricasFlagAusenteDesde = new Map();
    let metricasSyncInFlight = false;
    let metricasSyncPrimerOkInformado = false;
    let metricasSyncMeta = {
        ok: false,
        fechaOperativa: '',
        updatedAt: 0,
        visibleNodes: 0,
        remoteStates: 0,
        lastError: ''
    };

    function normalizarNodoSync(value) {
        return String(value == null ? '' : value)
            .trim()
            .toUpperCase();
    }

    function asegurarEstadoSyncUi() {
        let badge =
            document.getElementById(
                METRICAS_SYNC_STATUS_ID
            );

        if (badge) {
            return badge;
        }

        badge =
            document.createElement('div');

        badge.id =
            METRICAS_SYNC_STATUS_ID;

        badge.setAttribute(
            'aria-live',
            'polite'
        );

        badge.style.cssText = [
            'position:fixed',
            'left:50%',
            'top:14px',
            'transform:translateX(-50%)',
            'z-index:999998',
            'padding:5px 10px',
            'border-radius:999px',
            'font:600 12px/1.2 Arial,sans-serif',
            'box-shadow:0 1px 4px rgba(0,0,0,.12)',
            'background:#f3f4f6',
            'color:#374151',
            'pointer-events:none',
            'user-select:none',
            'white-space:nowrap',
            'max-width:180px',
            'overflow:hidden',
            'text-overflow:ellipsis'
        ].join(';');

        document.body.appendChild(
            badge
        );

        return badge;
    }

    function actualizarEstadoSyncUi(estado) {
        const badge =
            asegurarEstadoSyncUi();

        if (estado === 'syncing') {
            badge.textContent =
                '↻ Sincronizando';

            badge.style.background =
                '#fff7ed';

            badge.style.color =
                '#9a3412';

            return;
        }

        if (estado === 'synced') {
            badge.textContent =
                '● Sincronizado';

            badge.style.background =
                '#ecfdf5';

            badge.style.color =
                '#166534';

            return;
        }

        badge.textContent =
            '○ Modo local';

        badge.style.background =
            '#f3f4f6';

        badge.style.color =
            '#4b5563';
    }

    function restaurarTooltipVioleta(fila) {
        if (!fila) return;

        fila.querySelectorAll(
            '[data-viena-violeta-tooltip="1"]'
        ).forEach(celda => {
            const previo =
                celda.dataset.vienaPrevTitle;

            if (typeof previo === 'string') {
                if (previo) {
                    celda.setAttribute(
                        'title',
                        previo
                    );
                } else {
                    celda.removeAttribute(
                        'title'
                    );
                }
            }

            delete celda.dataset.vienaPrevTitle;
            delete celda.dataset.vienaVioletaTooltip;
        });
    }

    function aplicarTooltipVioleta(fila) {
        if (!fila) return;

        [
            fila.querySelector(SELECTOR_TOTAL),
            fila.querySelector(SELECTOR_PROBLEMA)
        ].filter(Boolean).forEach(celda => {
            if (
                celda.dataset
                    .vienaVioletaTooltip !==
                '1'
            ) {
                celda.dataset.vienaPrevTitle =
                    celda.getAttribute('title') || '';

                celda.dataset.vienaVioletaTooltip =
                    '1';
            }

            celda.setAttribute(
                'title',
                METRICAS_VIOLETA_TOOLTIP
            );
        });
    }

    function mostrarAyudaVioletaUnaVez() {
        try {
            if (
                sessionStorage.getItem(
                    METRICAS_VIOLETA_TOAST_KEY
                ) === '1'
            ) {
                return;
            }

            sessionStorage.setItem(
                METRICAS_VIOLETA_TOAST_KEY,
                '1'
            );
        } catch (_) {}

        const anterior =
            document.getElementById(
                'viena-metricas-violeta-toast'
            );

        if (anterior) {
            return;
        }

        const toast =
            document.createElement('div');

        toast.id =
            'viena-metricas-violeta-toast';

        toast.textContent =
            METRICAS_VIOLETA_TOAST;

        toast.style.cssText = [
            'position:fixed',
            'right:14px',
            'bottom:52px',
            'z-index:999999',
            'max-width:420px',
            'padding:10px 14px',
            'border-radius:8px',
            'font:600 13px/1.35 Arial,sans-serif',
            'background:#6b21a8',
            'color:#fff',
            'box-shadow:0 3px 12px rgba(0,0,0,.28)',
            'pointer-events:none'
        ].join(';');

        document.body.appendChild(
            toast
        );

        setTimeout(() => {
            toast.style.transition =
                'opacity .25s';

            toast.style.opacity =
                '0';

            setTimeout(
                () => toast.remove(),
                300
            );
        }, 4200);
    }

    function nodosVisiblesNormalizados() {
        const nodos = new Set();

        document.querySelectorAll(SELECTOR_TOTAL).forEach(celda => {
            const fila = celda.closest('tr');
            if (!fila) return;

            const nodo = normalizarNodoSync(obtenerNodo(fila));
            if (nodo) nodos.add(nodo);
        });

        return nodos;
    }

    function validarEstadoCompartido(raw, fechaServidor) {
        if (!raw || typeof raw !== 'object') return null;

        const nodo = normalizarNodoSync(raw.nodo);
        if (!nodo) return null;

        const total = parseInt(raw.total_marcado, 10);
        const problema = parseInt(raw.problema_marcado, 10);
        const fecha = String(raw.fecha_operativa || '').trim();
        const updatedMs = Number(raw.updated_at_ms || 0);

        if (!Number.isFinite(total) || total < 0) return null;
        if (!Number.isFinite(problema) || problema < 0) return null;
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) return null;
        if (fechaServidor && fecha !== fechaServidor) return null;

        return {
            nodo,
            total_marcado: total,
            problema_marcado: problema,
            usuario: String(raw.usuario || '').trim().toLowerCase(),
            fecha_operativa: fecha,
            updated_at: String(raw.updated_at || ''),
            updated_at_ms: Number.isFinite(updatedMs) ? updatedMs : 0
        };
    }

    async function sincronizarEstadosCompartidos() {
        if (metricasSyncInFlight) return;
        metricasSyncInFlight = true;

        actualizarEstadoSyncUi(
            'syncing'
        );

        const controller = new AbortController();
        const timer = setTimeout(
            () => controller.abort(),
            METRICAS_SYNC_TIMEOUT_MS
        );

        try {
            const url =
                METRICAS_SYNC_ENDPOINT +
                '?op=GET_TODAY_STATES&_=' +
                Date.now();

            const response = await fetch(url, {
                method: 'GET',
                cache: 'no-store',
                signal: controller.signal
            });

            if (!response.ok) {
                throw new Error('HTTP ' + response.status);
            }

            const data = await response.json();

            if (!data || data.ok !== true || !Array.isArray(data.states)) {
                throw new Error('Respuesta METRICAS_SYNC inválida');
            }

            const fechaServidor =
                String(data.date || '').trim();

            const cambioDeDia =
                asegurarFechaOperativaLocal(
                    fechaServidor
                );

            const nuevos = new Map();

            data.states.forEach(raw => {
                const estado =
                    validarEstadoCompartido(
                        raw,
                        fechaServidor
                    );

                if (!estado) return;

                const previo =
                    nuevos.get(estado.nodo);

                if (
                    !previo ||
                    estado.updated_at_ms >=
                        previo.updated_at_ms
                ) {
                    nuevos.set(
                        estado.nodo,
                        estado
                    );
                }
            });

            // Evitar que una lectura GET que salió antes de un UPSERT
            // confirmado pise un estado más nuevo del mismo nodo.
            metricasSyncUltimoWriteMs.forEach((writeMs, nodo) => {
                const actual = metricasSyncEstados.get(nodo);
                const entrante = nuevos.get(nodo);

                if (
                    actual &&
                    Number(actual.updated_at_ms || 0) >= Number(writeMs || 0) &&
                    (
                        !entrante ||
                        Number(entrante.updated_at_ms || 0) <
                            Number(actual.updated_at_ms || 0)
                    )
                ) {
                    nuevos.set(
                        nodo,
                        actual
                    );
                }
            });

            metricasSyncEstados = nuevos;

            nuevos.forEach((_, nodo) => {
                metricasSyncInitEnCurso.delete(nodo);
                metricasSyncInitUltimoIntento.delete(nodo);
            });

            if (cambioDeDia) {
                metricasSyncPendientes = new Map();
                metricasSyncUltimoWriteMs = new Map();
                metricasSyncInitEnCurso = new Set();
                metricasSyncInitUltimoIntento = new Map();
                metricasFlagAusenteDesde = new Map();
            }

            metricasSyncPendientes.forEach((pendiente, nodo) => {
                const remoto = nuevos.get(nodo);
                if (
                    remoto &&
                    remoto.total_marcado === pendiente.total &&
                    remoto.problema_marcado === pendiente.problema
                ) {
                    metricasSyncPendientes.delete(nodo);
                }
            });

            const visibles =
                nodosVisiblesNormalizados();

            metricasSyncMeta = {
                ok: true,
                fechaOperativa: fechaServidor,
                updatedAt: Date.now(),
                visibleNodes: visibles.size,
                remoteStates: nuevos.size,
                lastError: '',
                dailyReset:
                    cambioDeDia === true
            };

            procesarTabla();

            actualizarEstadoSyncUi(
                'synced'
            );

            if (!metricasSyncPrimerOkInformado) {
                metricasSyncPrimerOkInformado = true;
                console.info(
                    '[VIENA][METRICAS_SYNC] lectura activa',
                    {
                        fechaOperativa:
                            metricasSyncMeta.fechaOperativa,
                        estados:
                            metricasSyncMeta.remoteStates,
                        nodosVisibles:
                            metricasSyncMeta.visibleNodes
                    }
                );
            }
        }

        catch (error) {
            metricasSyncMeta = {
                ...metricasSyncMeta,
                ok: false,
                updatedAt: Date.now(),
                lastError:
                    String(
                        error?.message ||
                        error ||
                        'sync_error'
                    )
            };

            actualizarEstadoSyncUi(
                'local'
            );
        }

        finally {
            clearTimeout(timer);
            metricasSyncInFlight = false;
        }
    }

    // Diagnóstico interno de Fase 3. No modifica la página ni expone datos
    // fuera del contexto aislado de la extensión.
    function obtenerDiagnosticoMetricasSync() {
        return {
            ...metricasSyncMeta,
            estados:
                Array.from(
                    metricasSyncEstados.values()
                )
        };
    }

    async function asegurarBaselineInicialCompartido(nodo, valores) {
        const nodoSync =
            normalizarNodoSync(nodo);

        if (!nodoSync || !valores) {
            return false;
        }

        if (metricasSyncEstados.has(nodoSync)) {
            return true;
        }

        if (metricasSyncInitEnCurso.has(nodoSync)) {
            return false;
        }

        const ahora =
            Date.now();

        const ultimoIntento =
            Number(
                metricasSyncInitUltimoIntento.get(nodoSync) ||
                0
            );

        if (
            ultimoIntento &&
            ahora - ultimoIntento <
                METRICAS_SYNC_INIT_RETRY_MS
        ) {
            return false;
        }

        const total =
            Math.max(
                0,
                parseInt(valores.total, 10) || 0
            );

        const problema =
            Math.max(
                0,
                parseInt(valores.problema, 10) || 0
            );

        metricasSyncInitEnCurso.add(
            nodoSync
        );

        metricasSyncInitUltimoIntento.set(
            nodoSync,
            ahora
        );

        actualizarEstadoSyncUi(
            'syncing'
        );

        const controller =
            new AbortController();

        const timer =
            setTimeout(
                () => controller.abort(),
                METRICAS_SYNC_TIMEOUT_MS
            );

        try {
            const response =
                await fetch(
                    METRICAS_SYNC_ENDPOINT,
                    {
                        method: 'POST',
                        cache: 'no-store',
                        headers: {
                            'Content-Type':
                                'text/plain;charset=UTF-8'
                        },
                        body: JSON.stringify({
                            op: 'INIT_STATE',
                            nodo: nodoSync,
                            total_marcado: total,
                            problema_marcado: problema,
                            usuario:
                                String(MI_USUARIO || '')
                                    .trim()
                                    .toLowerCase()
                        }),
                        signal: controller.signal
                    }
                );

            if (!response.ok) {
                throw new Error(
                    'HTTP ' + response.status
                );
            }

            const data =
                await response.json();

            if (
                !data ||
                data.ok !== true ||
                !data.state
            ) {
                throw new Error(
                    'INIT_STATE invalido'
                );
            }

            const estado =
                validarEstadoCompartido(
                    data.state,
                    String(
                        data.state.fecha_operativa ||
                        ''
                    )
                );

            if (!estado) {
                throw new Error(
                    'INIT_STATE sin estado valido'
                );
            }

            metricasSyncEstados.set(
                estado.nodo,
                estado
            );

            metricasSyncInitUltimoIntento.delete(
                estado.nodo
            );

            if (data.created === true) {
                metricasSyncUltimoWriteMs.set(
                    estado.nodo,
                    Number(
                        estado.updated_at_ms ||
                        0
                    )
                );
            }

            metricasSyncMeta = {
                ...metricasSyncMeta,
                ok: true,
                fechaOperativa:
                    estado.fecha_operativa,
                updatedAt: Date.now(),
                remoteStates:
                    metricasSyncEstados.size,
                lastError: ''
            };

            procesarTabla();

            actualizarEstadoSyncUi(
                'synced'
            );

            return true;
        }

        catch (error) {
            metricasSyncMeta = {
                ...metricasSyncMeta,
                ok: false,
                updatedAt: Date.now(),
                lastError:
                    String(
                        error?.message ||
                        error ||
                        'init_state_error'
                    )
            };

            actualizarEstadoSyncUi(
                'local'
            );

            return false;
        }

        finally {
            clearTimeout(timer);

            metricasSyncInitEnCurso.delete(
                nodoSync
            );
        }
    }

    // FASE 4: escritura global, sin bloquear el comportamiento local
    async function guardarEstadoCompartido(nodo, valores) {
        const nodoSync = normalizarNodoSync(nodo);
        if (!nodoSync || !valores) return false;

        actualizarEstadoSyncUi(
            'syncing'
        );
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), METRICAS_SYNC_TIMEOUT_MS);
        try {
            const response = await fetch(METRICAS_SYNC_ENDPOINT, {
                method: 'POST',
                cache: 'no-store',
                headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
                body: JSON.stringify({
                    op: 'UPSERT_STATE',
                    nodo: nodoSync,
                    total_marcado: Math.max(0, parseInt(valores.total, 10) || 0),
                    problema_marcado: Math.max(0, parseInt(valores.problema, 10) || 0),
                    usuario: String(MI_USUARIO || '').trim().toLowerCase()
                }),
                signal: controller.signal
            });
            if (!response.ok) throw new Error('HTTP ' + response.status);
            const data = await response.json();
            if (!data || data.ok !== true || !data.state) throw new Error('UPSERT_STATE invalido');
            const estado = validarEstadoCompartido(data.state, String(data.state.fecha_operativa || ''));
            if (estado) {
                metricasSyncEstados.set(estado.nodo, estado);
                metricasSyncPendientes.delete(estado.nodo);
                metricasSyncUltimoWriteMs.set(
                    estado.nodo,
                    Number(estado.updated_at_ms || 0)
                );
                metricasSyncMeta = {
                    ...metricasSyncMeta,
                    ok: true,
                    fechaOperativa: estado.fecha_operativa,
                    updatedAt: Date.now(),
                    remoteStates: metricasSyncEstados.size,
                    lastError: ''
                };
                procesarTabla();

                actualizarEstadoSyncUi(
                    'synced'
                );
            }
            return true;
        } catch (error) {
            // Si falla el UPSERT, no mantener indefinidamente una referencia
            // optimista que los demás operadores nunca recibieron.
            metricasSyncPendientes.delete(
                nodoSync
            );

            metricasSyncMeta = {
                ...metricasSyncMeta,
                ok: false,
                updatedAt: Date.now(),
                lastError: String(error?.message || error || 'upsert_error')
            };

            console.warn(
                '[VIENA][METRICAS_SYNC] no se pudo sincronizar revision',
                error
            );

            procesarTabla();

            actualizarEstadoSyncUi(
                'local'
            );

            return false;
        } finally {
            clearTimeout(timer);
        }
    }

    // Selectores reales
    const SELECTOR_TOTAL =
        'td[aria-describedby="grid-estadisticas-nodos-general_vttotal.valorActual"]';

    const SELECTOR_PROBLEMA =
        'td[aria-describedby="grid-estadisticas-nodos-general_vtproblseñal.valorActual"]';

    const SELECTOR_BANDERA =
        'span.glyphicon.glyphicon-flag';


    // =========================================================
    // STORAGE
    // =========================================================

    function cargarHistorial() {
        try {
            return JSON.parse(
                localStorage.getItem(STORAGE_KEY)
            ) || {};
        } catch (e) {
            return {};
        }
    }

    function guardarHistorial(historial) {
        try {
            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(historial)
            );
        } catch (e) {
            console.warn('No se pudo guardar historial VTS:', e);
        }
    }

    function fechaOperativaLocalGuardada() {
        try {
            return String(
                localStorage.getItem(
                    STORAGE_DATE_KEY
                ) || ''
            ).trim();
        } catch (_) {
            return '';
        }
    }

    function guardarFechaOperativaLocal(fecha) {
        try {
            localStorage.setItem(
                STORAGE_DATE_KEY,
                String(fecha || '')
            );
        } catch (_) {}
    }

    function resetearEstadoDiarioLocal(fechaServidor) {
        try {
            localStorage.removeItem(
                STORAGE_KEY
            );
        } catch (_) {}

        metricasSyncEstados = new Map();
        metricasSyncPendientes = new Map();
        metricasSyncUltimoWriteMs = new Map();
        metricasSyncInitEnCurso = new Set();
        metricasSyncInitUltimoIntento = new Map();
        metricasFlagAusenteDesde = new Map();

        document.querySelectorAll(
            'tr[data-nuevos-vts="1"], tr[data-viena-sync-base]'
        ).forEach(fila => {
            delete fila.dataset.nuevosVts;
            delete fila.dataset.vienaSyncBase;
        });

        guardarFechaOperativaLocal(
            fechaServidor
        );
    }

    function asegurarFechaOperativaLocal(fechaServidor) {
        const fecha =
            String(fechaServidor || '').trim();

        if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha)) {
            return false;
        }

        const guardada =
            fechaOperativaLocalGuardada();

        // Primera instalación de esta fase: preservar el historial actual
        // y empezar a etiquetarlo con la fecha operativa del servidor.
        if (!guardada) {
            guardarFechaOperativaLocal(fecha);
            return false;
        }

        if (guardada === fecha) {
            return false;
        }

        resetearEstadoDiarioLocal(fecha);

        console.info(
            '[VIENA][METRICAS_SYNC] nuevo día operativo',
            {
                anterior: guardada,
                actual: fecha
            }
        );

        return true;
    }


    // =========================================================
    // LECTURA DE DATOS
    // =========================================================

    function obtenerValores(fila) {
        const celdaTotal = fila.querySelector(SELECTOR_TOTAL);
        const celdaProblema = fila.querySelector(SELECTOR_PROBLEMA);

        if (!celdaTotal || !celdaProblema) {
            return null;
        }

        const total = parseInt(
            celdaTotal.textContent.trim(),
            10
        );

        const problema = parseInt(
            celdaProblema.textContent.trim(),
            10
        );

        return {
            total: Number.isNaN(total) ? 0 : total,
            problema: Number.isNaN(problema) ? 0 : problema
        };
    }


    function obtenerNodo(fila) {

        // Intento 1: columna nodo por aria-describedby
        let celdaNodo = fila.querySelector(
            'td[aria-describedby="grid-estadisticas-nodos-general_nodo"]'
        );

        // Intento 2: cualquier aria que termine en _nodo
        if (!celdaNodo) {
            celdaNodo = fila.querySelector(
                'td[aria-describedby$="_nodo"]'
            );
        }

        if (celdaNodo) {
            const texto = celdaNodo.textContent.trim();

            if (texto) {
                return texto;
            }
        }

        // Intento 3: buscar una celda con formato de nodo
        const celdas = Array.from(
            fila.querySelectorAll('td')
        );

        for (const td of celdas) {
            const texto = td.textContent.trim();

            if (/^[A-Z]{1,4}\d+[A-Z0-9]*$/i.test(texto)) {
                return texto;
            }
        }

        return null;
    }


    function obtenerBandera(fila) {
        return fila.querySelector(SELECTOR_BANDERA);
    }


    function obtenerUsuarioBandera(bandera) {

        if (!bandera) {
            return null;
        }

        /*
         * VIENA/Métricas puede dejar el tooltip en el icono, en un <a>/<span>
         * contenedor o mover `title` a `data-original-title` al inicializar el
         * tooltip. Recorremos sólo la celda de bandera para no tomar datos de
         * otra columna.
         *
         * Ejemplo esperado:
         * efoschi - Foschi, Emanuel Gaston - 12/09/2026 14:03
         */
        const celda = bandera.closest('td');
        const candidatos = [bandera];
        let parent = bandera.parentElement;
        while (parent && parent !== celda) {
            candidatos.push(parent);
            parent = parent.parentElement;
        }
        if (celda) {
            candidatos.push(celda);
            candidatos.push(...Array.from(celda.querySelectorAll('[title], [data-original-title], [aria-label], [data-user], [data-usuario]')));
        }

        const textos = [];
        for (const el of candidatos) {
            if (!el) continue;
            for (const attr of ['title', 'data-original-title', 'aria-label', 'data-user', 'data-usuario']) {
                const value = String(el.getAttribute?.(attr) || '').trim();
                if (value) textos.push(value);
            }
        }

        for (const texto of textos) {
            const primero = texto.split(/\s+-\s+/)[0].trim().toLowerCase();
            if (/^[a-z][a-z0-9._-]{2,40}$/i.test(primero)) return primero;

            const match = texto.match(/(?:^|\s)([a-z][a-z0-9._-]{2,40})\s+-\s+/i);
            if (match?.[1]) return match[1].toLowerCase();
        }

        return null;
    }

    function hashUsuarioBandera(texto) {
        let hash = 2166136261;
        const value = String(texto || '');
        for (let i = 0; i < value.length; i++) {
            hash ^= value.charCodeAt(i);
            hash = Math.imul(hash, 16777619);
        }
        return hash >>> 0;
    }

    function guardarMapaColoresBandera() {
        if (!mapaColoresBanderaCargado) return;
        chrome.storage.local.set({ [BANDERA_COLOR_MAP_KEY]: mapaColoresBandera }).catch(() => {});
    }

    function colorBanderaPorUsuario(usuario) {
        const user = String(usuario || '').trim().toLowerCase();
        if (!user) return '#e2e8f0';

        // La bandera propia conserva el celeste definido históricamente.
        if (MI_USUARIO && user === MI_USUARIO) {
            return COLOR_MI_BANDERA;
        }

        const guardado = Number(mapaColoresBandera[user]);
        if (
            Number.isInteger(guardado) &&
            guardado >= 0 &&
            guardado < PALETA_BANDERAS_OTROS.length
        ) {
            return PALETA_BANDERAS_OTROS[guardado];
        }

        // Antes de completar la carga del storage usamos un color determinista
        // sin escribir nada. Al terminar la carga, procesarTabla() vuelve a
        // aplicar el mapa persistente.
        const inicial = hashUsuarioBandera(user) % PALETA_BANDERAS_OTROS.length;
        if (!mapaColoresBanderaCargado) {
            return PALETA_BANDERAS_OTROS[inicial];
        }

        // Evitar colisiones entre los operadores ya conocidos siempre que haya
        // colores disponibles. El mapa queda persistido para que cada usuario
        // conserve su color en futuras aperturas.
        const usados = new Set(
            Object.entries(mapaColoresBandera)
                .filter(([otro]) => otro !== user)
                .map(([, indice]) => Number(indice))
                .filter(indice => Number.isInteger(indice) && indice >= 0 && indice < PALETA_BANDERAS_OTROS.length)
        );

        let indice = inicial;
        for (let paso = 0; paso < PALETA_BANDERAS_OTROS.length; paso++) {
            const candidato = (inicial + paso) % PALETA_BANDERAS_OTROS.length;
            if (!usados.has(candidato)) {
                indice = candidato;
                break;
            }
        }

        mapaColoresBandera[user] = indice;
        guardarMapaColoresBandera();
        return PALETA_BANDERAS_OTROS[indice];
    }


    // =========================================================
    // COLORES DE FILA
    // =========================================================

    function limpiarColorFila(fila) {

        fila.querySelectorAll('td').forEach(td => {
            td.style.removeProperty('background-color');
        });
    }


    function aplicarColorFila(fila, color) {

        fila.querySelectorAll('td').forEach(td => {
            td.style.setProperty(
                'background-color',
                color,
                'important'
            );
        });
    }


    // =========================================================
    // COLOR DE BANDERA SEGÚN USUARIO
    // =========================================================

    function aplicarColorBandera(fila, bandera) {

        if (!bandera) {
            return;
        }

        const usuario =
            obtenerUsuarioBandera(bandera);

        const celdaBandera =
            bandera.closest('td');

        if (!celdaBandera) {
            return;
        }

        const color = colorBanderaPorUsuario(usuario);

        celdaBandera.style.setProperty(
            'background-color',
            color,
            'important'
        );

        // Dejamos trazabilidad visual/DOM sin modificar el title original.
        celdaBandera.dataset.vienaBanderaUsuario = usuario || '';
        celdaBandera.dataset.vienaBanderaColor = color;
        bandera.style.setProperty('color', '#22313f', 'important');
    }


    // =========================================================
    // SELECCIÓN DE FILA
    // =========================================================

    function quitarSeleccionAnterior() {

        document.querySelectorAll(
            'tr[data-fila-seleccionada="1"]'
        ).forEach(fila => {

            delete fila.dataset.filaSeleccionada;

            fila.querySelectorAll('td').forEach(td => {
                td.style.removeProperty('box-shadow');
            });
        });
    }


    function dibujarSeleccion(fila) {

        const celdas =
            fila.querySelectorAll('td');

        celdas.forEach((td, index) => {

            let sombra = '';

            if (index === 0) {
                sombra =
                    `inset 3px 0 0 ${COLOR_SELECCION}, ` +
                    `inset 0 2px 0 ${COLOR_SELECCION}, ` +
                    `inset 0 -2px 0 ${COLOR_SELECCION}`;
            }

            else if (index === celdas.length - 1) {
                sombra =
                    `inset -3px 0 0 ${COLOR_SELECCION}, ` +
                    `inset 0 2px 0 ${COLOR_SELECCION}, ` +
                    `inset 0 -2px 0 ${COLOR_SELECCION}`;
            }

            else {
                sombra =
                    `inset 0 2px 0 ${COLOR_SELECCION}, ` +
                    `inset 0 -2px 0 ${COLOR_SELECCION}`;
            }

            td.style.setProperty(
                'box-shadow',
                sombra,
                'important'
            );
        });
    }


    function aplicarSeleccion(fila) {

        quitarSeleccionAnterior();

        fila.dataset.filaSeleccionada = '1';

        dibujarSeleccion(fila);
    }


    function restaurarSeleccionSiCorresponde(fila) {

        if (
            fila.dataset.filaSeleccionada === '1'
        ) {
            dibujarSeleccion(fila);
        }
    }


    // =========================================================
    // MENSAJE DE CONFIRMACIÓN
    // =========================================================

    function mostrarAvisoRevision(nodo, valores) {

        const anterior =
            document.getElementById(
                'aviso-metricas-vts'
            );

        if (anterior) {
            anterior.remove();
        }

        const aviso =
            document.createElement('div');

        aviso.id =
            'aviso-metricas-vts';

        aviso.textContent = '';
        aviso.append(document.createTextNode('✓ '));
        const nodoFuerte = document.createElement('strong');
        nodoFuerte.textContent = String(nodo ?? '');
        aviso.append(
            nodoFuerte,
            document.createTextNode(' revisado'),
            document.createElement('br'),
            document.createTextNode('VTS actual: ' + String(valores?.total ?? '') + ' | Problema señal: ' + String(valores?.problema ?? ''))
        );

        aviso.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 999999;
            background: #198754;
            color: white;
            padding: 12px 18px;
            border-radius: 6px;
            font-size: 14px;
            font-family: Arial, sans-serif;
            box-shadow: 0 3px 10px rgba(0,0,0,0.30);
            pointer-events: none;
        `;

        document.body.appendChild(aviso);

        setTimeout(function () {

            aviso.style.transition =
                'opacity 0.3s';

            aviso.style.opacity =
                '0';

            setTimeout(function () {
                aviso.remove();
            }, 300);

        }, 2500);
    }


    // =========================================================
    // PROCESAR UNA FILA
    // =========================================================

    function procesarFila(fila, historial) {

        const valores =
            obtenerValores(fila);

        if (!valores) {
            return false;
        }

        const bandera =
            obtenerBandera(fila);

        const tieneBandera =
            bandera !== null;

        let cambioHistorial = false;

        // Recalcular visual desde cero
        limpiarColorFila(fila);
        restaurarTooltipVioleta(fila);


        // =====================================================
        // SIN BANDERA
        // =====================================================

        if (!tieneBandera) {

            const nodo =
                obtenerNodo(fila);

            // Una bandera puede desaparecer unos segundos cuando otro
            // operador vuelve a iniciar/reasignar la misma métrica.
            // No borrar inmediatamente el baseline local: eso generaría
            // una falsa nueva referencia con los valores actuales.
            if (
                nodo &&
                historial[nodo]
            ) {
                const nodoSync =
                    normalizarNodoSync(nodo);

                const tieneBaselineGlobal =
                    nodoSync &&
                    metricasSyncEstados.has(
                        nodoSync
                    );

                if (tieneBaselineGlobal) {
                    metricasFlagAusenteDesde.delete(
                        nodoSync
                    );
                }

                else {
                    const ahora =
                        Date.now();

                    const ausenteDesde =
                        Number(
                            metricasFlagAusenteDesde.get(
                                nodoSync
                            ) || 0
                        );

                    if (!ausenteDesde) {
                        metricasFlagAusenteDesde.set(
                            nodoSync,
                            ahora
                        );
                    }

                    else if (
                        ahora - ausenteDesde >=
                            METRICAS_FLAG_REPLACEMENT_GRACE_MS
                    ) {
                        delete historial[nodo];

                        metricasFlagAusenteDesde.delete(
                            nodoSync
                        );

                        cambioHistorial = true;
                    }
                }
            }

            delete fila.dataset.nuevosVts;
            delete fila.dataset.vienaSyncBase;

            const maximo =
                Math.max(
                    valores.total,
                    valores.problema
                );

            // 🟧 4 o más
            if (maximo >= 4) {

                aplicarColorFila(
                    fila,
                    COLOR_NARANJA
                );
            }

            // 🟨 exactamente 3
            else if (maximo === 3) {

                aplicarColorFila(
                    fila,
                    COLOR_AMARILLO
                );
            }

            restaurarSeleccionSiCorresponde(
                fila
            );

            return cambioHistorial;
        }


        // =====================================================
        // CON BANDERA
        // =====================================================

        const nodo =
            obtenerNodo(fila);

        // Si no identifica el nodo, igual lo tratamos como seguido
        if (!nodo) {

            aplicarColorFila(
                fila,
                COLOR_VERDE
            );

            aplicarColorBandera(
                fila,
                bandera
            );

            restaurarSeleccionSiCorresponde(
                fila
            );

            return cambioHistorial;
        }


        // Primera vez que esta versión detecta la bandera
        // Fase 5: si existe una referencia compartida para este nodo,
        // usarla como fuente de verdad para el historial local.
        const nodoSync =
            normalizarNodoSync(nodo);

        if (nodoSync) {
            metricasFlagAusenteDesde.delete(
                nodoSync
            );
        }

        const referenciaPendiente =
            nodoSync
                ? metricasSyncPendientes.get(nodoSync)
                : null;

        const estadoCompartido =
            nodoSync
                ? metricasSyncEstados.get(nodoSync)
                : null;

        let referenciaSincronizada = null;
        let fuenteSincronizada = '';

        if (referenciaPendiente) {
            referenciaSincronizada = {
                total: referenciaPendiente.total,
                problema: referenciaPendiente.problema
            };
            fuenteSincronizada = 'pending';
        }

        else if (estadoCompartido) {
            referenciaSincronizada = {
                total:
                    estadoCompartido.total_marcado,
                problema:
                    estadoCompartido.problema_marcado
            };
            fuenteSincronizada = 'global';
        }

        if (referenciaSincronizada) {
            const referenciaLocal =
                historial[nodo];

            if (
                !referenciaLocal ||
                referenciaLocal.total !==
                    referenciaSincronizada.total ||
                referenciaLocal.problema !==
                    referenciaSincronizada.problema
            ) {
                historial[nodo] =
                    referenciaSincronizada;

                cambioHistorial = true;
            }

            fila.dataset.vienaSyncBase =
                fuenteSincronizada;
        }

        else {
            delete fila.dataset.vienaSyncBase;
        }

        if (
            !estadoCompartido &&
            !referenciaPendiente
        ) {
            const baselineInicial =
                historial[nodo]
                    ? {
                        total:
                            historial[nodo].total,
                        problema:
                            historial[nodo].problema
                    }
                    : valores;

            void asegurarBaselineInicialCompartido(
                nodo,
                baselineInicial
            );
        }

        if (!historial[nodo]) {

            historial[nodo] = {
                total: valores.total,
                problema: valores.problema
            };

            cambioHistorial = true;

            delete fila.dataset.nuevosVts;

            // 🟩 seguimiento normal
            aplicarColorFila(
                fila,
                COLOR_VERDE
            );
        }

        else {

            const base =
                historial[nodo];

            const aumentoTotal =
                valores.total > base.total;

            const aumentoProblema =
                valores.problema > base.problema;

            // 🟪 entraron nuevos VTS
            if (
                aumentoTotal ||
                aumentoProblema
            ) {

                fila.dataset.nuevosVts = '1';

                aplicarColorFila(
                    fila,
                    COLOR_VIOLETA
                );

                aplicarTooltipVioleta(
                    fila
                );

                mostrarAyudaVioletaUnaVez();
            }

            // 🟩 sigue igual
            else {

                delete fila.dataset.nuevosVts;

                aplicarColorFila(
                    fila,
                    COLOR_VERDE
                );
            }
        }


        // Celda de bandera según usuario
        aplicarColorBandera(
            fila,
            bandera
        );


        // Restaurar borde si está seleccionada
        restaurarSeleccionSiCorresponde(
            fila
        );


        return cambioHistorial;
    }


    // =========================================================
    // PROCESAR TABLA
    // =========================================================

    function procesarTabla() {

        const historial =
            cargarHistorial();

        let cambioHistorial = false;

        const celdasTotales =
            document.querySelectorAll(
                SELECTOR_TOTAL
            );

        celdasTotales.forEach(celda => {

            const fila =
                celda.closest('tr');

            if (!fila) {
                return;
            }

            const cambio =
                procesarFila(
                    fila,
                    historial
                );

            if (cambio) {
                cambioHistorial = true;
            }
        });


        if (cambioHistorial) {
            guardarHistorial(
                historial
            );
        }
    }


    // =========================================================
    // CLICK NORMAL = SELECCIONAR FILA
    // =========================================================

    document.addEventListener(
        'click',
        function (e) {

            const fila =
                e.target.closest('tr');

            if (!fila) {
                return;
            }

            // Solo filas reales
            if (
                !fila.querySelector(
                    SELECTOR_TOTAL
                )
            ) {
                return;
            }

            // Un click normal SOLO selecciona
            aplicarSeleccion(fila);
        }
    );


    // =========================================================
    // CTRL + DOBLE CLICK = MARCAR COMO REVISADO
    // =========================================================

    document.addEventListener(
        'dblclick',
        function (e) {

            // Obligatorio mantener CTRL
            if (!e.ctrlKey) {
                return;
            }

            const fila =
                e.target.closest('tr');

            if (!fila) {
                return;
            }

            // Solo filas reales
            if (
                !fila.querySelector(
                    SELECTOR_TOTAL
                )
            ) {
                return;
            }

            // Solo se confirma si está violeta
            if (
                fila.dataset.nuevosVts !== '1'
            ) {
                return;
            }

            const nodo =
                obtenerNodo(fila);

            const valores =
                obtenerValores(fila);

            const bandera =
                obtenerBandera(fila);

            if (
                !nodo ||
                !valores ||
                !bandera
            ) {
                return;
            }

            const historial =
                cargarHistorial();

            /*
             * Los valores actuales pasan
             * a ser la nueva referencia.
             */
            historial[nodo] = {
                total: valores.total,
                problema: valores.problema
            };

            guardarHistorial(
                historial
            );

            const nodoSync =
                normalizarNodoSync(nodo);

            if (nodoSync) {
                metricasSyncPendientes.set(
                    nodoSync,
                    {
                        total: valores.total,
                        problema: valores.problema,
                        createdAt: Date.now()
                    }
                );
            }

            // Local primero; sincronizacion global en segundo plano.
            void guardarEstadoCompartido(
                nodo,
                valores
            );

            delete fila.dataset.nuevosVts;

            // Volver inmediatamente a verde
            aplicarColorFila(
                fila,
                COLOR_VERDE
            );

            // Mantener color de la bandera
            aplicarColorBandera(
                fila,
                bandera
            );

            // Dejarla seleccionada
            aplicarSeleccion(fila);

            // Mostrar confirmación
            mostrarAvisoRevision(
                nodo,
                valores
            );
        }
    );


    // =========================================================
    // EJECUCIÓN
    // =========================================================

    // Fase 3: iniciar la lectura compartida en paralelo. Todavía no influye
    // en procesarTabla()/procesarFila() ni en los colores existentes.
    actualizarEstadoSyncUi(
        'syncing'
    );

    setTimeout(
        sincronizarEstadosCompartidos,
        500
    );

    setInterval(
        sincronizarEstadosCompartidos,
        METRICAS_SYNC_POLL_MS
    );

    setTimeout(
        procesarTabla,
        300
    );

    setTimeout(
        procesarTabla,
        800
    );

    setTimeout(
        procesarTabla,
        1500
    );

    setTimeout(
        procesarTabla,
        3000
    );


    // jqGrid se actualiza dinámicamente
    setInterval(
        procesarTabla,
        1500
    );

})();