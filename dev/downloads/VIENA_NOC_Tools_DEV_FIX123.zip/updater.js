'use strict';

const statusEl = document.getElementById('status');
const detailEl = document.getElementById('detail');
const selectBtn = document.getElementById('selectFolder');
const authorizeBtn = document.getElementById('authorizeFolder');
const unlinkBtn = document.getElementById('unlinkFolder');
const closeBtn = document.getElementById('closeTab');

function setStatus(text, cls='') {
  statusEl.textContent = text;
  statusEl.className = 'status' + (cls ? ` ${cls}` : '');
}

async function render() {
  const updater = window.VienaLocalUpdater;
  if (!updater?.supported()) {
    setStatus('Acceso a carpetas no disponible', 'error');
    detailEl.textContent = 'Este Chrome no habilitó File System Access para esta página de la extensión.';
    selectBtn.disabled = true;
    return;
  }
  const st = await updater.getLinkStatus();
  unlinkBtn.style.display = st.linked ? '' : 'none';
  authorizeBtn.style.display = st.linked && st.permission !== 'granted' && st.permission !== 'relink' ? '' : 'none';
  selectBtn.textContent = st.linked ? 'Cambiar / volver a seleccionar carpeta' : 'Seleccionar carpeta';

  if (!st.linked) {
    setStatus('Sin carpeta vinculada');
    detailEl.textContent = 'Seleccioná una carpeta una sola vez. Después el popup la reconocerá aunque se cierre y vuelva a abrir.';
    return;
  }
  if (st.permission === 'relink') {
    setStatus('Carpeta recordada · requiere volver a seleccionar', 'warn');
    detailEl.textContent = `${st.name || 'Carpeta'} quedó recordada, pero Chrome perdió el identificador de acceso. Volvé a seleccionarla para restaurarlo.`;
    return;
  }
  if (st.permission !== 'granted') {
    setStatus('Carpeta guardada · falta autorización', 'warn');
    detailEl.textContent = `${st.name || 'Carpeta'} está guardada. Tocá “Autorizar carpeta guardada”.`;
    return;
  }
  if (!st.valid) {
    setStatus('Carpeta vinculada · revisar', 'error');
    detailEl.textContent = st.error || 'La carpeta guardada ya no coincide con una instalación válida.';
    return;
  }
  setStatus('Carpeta vinculada correctamente', 'ok');
  detailEl.textContent = `${st.name} · ${st.identity?.channel || ''} · v${st.identity?.version || ''} · build ${st.identity?.build || ''}`;
}

selectBtn.addEventListener('click', async () => {
  selectBtn.disabled = true;
  try {
    const r = await window.VienaLocalUpdater.pickAndLink();
    setStatus('Carpeta guardada correctamente', 'ok');
    detailEl.textContent = `${r.name} · ${r.identity.channel} · v${r.identity.version} · build ${r.identity.build}`;
  } catch (e) {
    if (e?.name !== 'AbortError') {
      setStatus('No se pudo guardar la carpeta', 'error');
      detailEl.textContent = String(e?.message || e);
    }
  } finally {
    selectBtn.disabled = false;
    await render();
  }
});

authorizeBtn.addEventListener('click', async () => {
  authorizeBtn.disabled = true;
  try {
    await window.VienaLocalUpdater.requestStoredPermission();
  } catch (e) {
    setStatus('No se pudo autorizar la carpeta', 'error');
    detailEl.textContent = String(e?.message || e);
  } finally {
    authorizeBtn.disabled = false;
    await render();
  }
});

unlinkBtn.addEventListener('click', async () => {
  await window.VienaLocalUpdater.unlink();
  await render();
});

closeBtn.addEventListener('click', async () => {
  try {
    const tab = await chrome.tabs.getCurrent();
    if (tab?.id) await chrome.tabs.remove(tab.id);
    else window.close();
  } catch (_) { window.close(); }
});

void render();
