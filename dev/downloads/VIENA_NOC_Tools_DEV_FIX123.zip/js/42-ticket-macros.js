(function () {
    'use strict';

    if (globalThis.__VIENA_TICKET_MACROS_V1__) return;
    globalThis.__VIENA_TICKET_MACROS_V1__ = true;

    const STORAGE_KEY = 'viena_ticket_macros_v1';
    const MAX_MACROS = 50;
    const MAX_ACTIONS = 1000;
    const MAX_STORAGE_BYTES = 4 * 1024 * 1024;
    const SENSITIVE_NAME = /password|passwd|secret|token|authorization|otp|one.?time.?code/i;
    const UI_ATTRIBUTE = 'data-viena-macro-ui';
    const TEXT_NODE_TOKEN = '{{TICKET_NODE}}';
    const CMTS_NODE_TOKEN = '{{TICKET_NODE_CMTS}}';

    function escapeRegExp(value) {
        return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function replaceWholeIdentifier(text, value, token) {
        const escaped = escapeRegExp(value);
        return String(text).replace(
            new RegExp(`(^|[^A-Z0-9])${escaped}(?=$|[^A-Z0-9])`, 'ig'),
            (_match, prefix) => `${prefix}${token}`
        );
    }

    function tokenizeTicketValues(value, ticket = {}) {
        let result = String(value ?? '');
        const cmts = String(ticket.cmts || '').trim();
        const node = String(ticket.node || '').trim();
        // Resolve explicit labels first, even when Nodo and Nodo CMTS originally match.
        // Horizontal whitespace only: an empty label must never consume the next line.
        result = result.replace(
            /(\bNodo[ \t]+CMTS[ \t]*:[ \t]*)(?:[A-Z0-9][A-Z0-9_-]*)?/ig,
            (_match, label) => `${label}${CMTS_NODE_TOKEN}`
        );
        result = result.replace(
            /(\bNodo(?![ \t]+CMTS)[ \t]*:[ \t]*)(?:[A-Z0-9][A-Z0-9_-]*)?/ig,
            (_match, label) => `${label}${TEXT_NODE_TOKEN}`
        );
        if (cmts) result = replaceWholeIdentifier(result, cmts, CMTS_NODE_TOKEN);
        if (node) result = replaceWholeIdentifier(result, node, TEXT_NODE_TOKEN);
        return result;
    }

    function resolveTicketTemplate(value, ticket = {}) {
        let result = String(value ?? '');
        if (result.includes(CMTS_NODE_TOKEN)) {
            const cmts = String(ticket.cmts || '').trim();
            if (!cmts) return null;
            result = result.split(CMTS_NODE_TOKEN).join(cmts);
        }
        if (result.includes(TEXT_NODE_TOKEN)) {
            const node = String(ticket.node || '').trim();
            if (!node) return null;
            result = result.split(TEXT_NODE_TOKEN).join(node);
        }
        return result;
    }

    function shouldCollapseInputAction(previous, next) {
        return Boolean(previous && next
            && previous.type === next.type
            && (next.type === 'setValue' || next.type === 'setChecked')
            && previous.targetKey === next.targetKey);
    }

    function isSensitiveInput(target) {
        if (!target) return false;
        const type = String(target.type || target.getAttribute?.('type') || '').toLowerCase();
        const autocomplete = String(target.autocomplete || target.getAttribute?.('autocomplete') || '');
        const name = `${target.name || ''} ${target.id || ''} ${target.getAttribute?.('aria-label') || ''}`;
        return type === 'password' || type === 'file' || SENSITIVE_NAME.test(`${name} ${autocomplete}`);
    }

    function normalizeText(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function cssEscape(value) {
        if (globalThis.CSS?.escape) return globalThis.CSS.escape(String(value));
        return String(value).replace(/[^a-zA-Z0-9_-]/g, character => `\\${character.codePointAt(0).toString(16)} `);
    }

    function selectorFor(element) {
        if (element.id) return `#${cssEscape(element.id)}`;
        const parts = [];
        let current = element;
        while (current && current.nodeType === 1 && parts.length < 7) {
            let part = String(current.localName || current.tagName || '').toLowerCase();
            if (!part) break;
            const classes = Array.from(current.classList || [])
                .filter(name => !/^v-(input--is|menu--|dialog--|ripple)/.test(name))
                .slice(0, 2);
            if (classes.length) part += classes.map(name => `.${cssEscape(name)}`).join('');
            const parent = current.parentElement;
            if (parent) {
                const siblings = Array.from(parent.children).filter(child => child.localName === current.localName);
                if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
            }
            parts.unshift(part);
            if (parent?.id) {
                parts.unshift(`#${cssEscape(parent.id)}`);
                break;
            }
            current = parent;
        }
        return parts.join(' > ');
    }

    function elementLabel(element) {
        const aria = element.getAttribute?.('aria-label');
        if (aria) return normalizeText(aria).slice(0, 180);
        const labels = Array.from(element.labels || []).map(label => normalizeText(label.textContent)).filter(Boolean);
        if (labels.length) return labels.join(' ').slice(0, 180);
        const field = element.closest?.('.v-input');
        const label = field?.querySelector('label');
        return normalizeText(label?.textContent).slice(0, 180);
    }

    function interactiveText(element) {
        if (!element.matches?.('button,a,[role="button"],[role="menuitem"],[role="option"],[role="tab"],label,.v-list-item__title,.v-list-item__content,.v-btn__content')) return '';
        return normalizeText(element.innerText || element.textContent).slice(0, 180);
    }

    function safeHtmlSnapshot(element) {
        if (!element.matches?.('button,a,input,textarea,select,[role="button"],[role="menuitem"],[role="option"],[role="tab"],label,[contenteditable="true"]')) return '';
        const clone = element.cloneNode(true);
        const controls = [
            ...(clone.matches?.('input,textarea,select,[contenteditable="true"]') ? [clone] : []),
            ...clone.querySelectorAll('input,textarea,select,[contenteditable="true"]')
        ];
        for (const field of controls) {
            if (field.matches('textarea,[contenteditable="true"]')) field.textContent = '';
            else {
                field.removeAttribute('value');
                field.removeAttribute('checked');
                field.removeAttribute('selected');
            }
            if (field.matches('select')) {
                for (const option of field.querySelectorAll('option')) option.removeAttribute('value');
            }
        }
        const html = clone.outerHTML || '';
        return html.length > 1200 ? `${html.slice(0, 1200)}…` : html;
    }

    function descriptorFor(element) {
        const ancestors = [];
        let parent = element.parentElement;
        while (parent && ancestors.length < 4) {
            ancestors.push({
                tag: String(parent.localName || '').toLowerCase(),
                id: String(parent.id || ''),
                role: String(parent.getAttribute?.('role') || ''),
                label: elementLabel(parent),
                text: interactiveText(parent),
                classes: Array.from(parent.classList || []).slice(0, 12)
            });
            parent = parent.parentElement;
        }
        const attributes = {};
        for (const attribute of Array.from(element.attributes || []).slice(0, 40)) {
            const name = String(attribute.name || '').toLowerCase();
            if (!name || name === 'value' || name === 'style' || name === 'srcdoc' || name.startsWith('on')) continue;
            attributes[name] = String(attribute.value || '').slice(0, 500);
        }
        const descriptor = {
            tag: String(element.localName || element.tagName || '').toLowerCase(),
            id: String(element.id || ''),
            name: String(element.getAttribute?.('name') || ''),
            role: String(element.getAttribute?.('role') || ''),
            type: String(element.getAttribute?.('type') || ''),
            ariaLabel: String(element.getAttribute?.('aria-label') || ''),
            title: String(element.getAttribute?.('title') || ''),
            placeholder: String(element.getAttribute?.('placeholder') || ''),
            label: elementLabel(element),
            text: interactiveText(element),
            classes: Array.from(element.classList || []).slice(0, 24),
            attributes,
            selector: selectorFor(element),
            html: safeHtmlSnapshot(element),
            ancestors
        };
        const menu = element.closest?.('.v-menu__content');
        if (menu && isRelatedEventMenu(menu) && element.closest?.('.v-list-item,[role="menuitem"]')) {
            descriptor.contextTarget = 'related-event';
        }
        return descriptor;
    }

    function isRelatedEventMenu(menu) {
        return normalizeText(menu.textContent).startsWith('Seleccione el evento');
    }

    function isRelatedEventDescriptor(descriptor) {
        if (descriptor.contextTarget) return descriptor.contextTarget === 'related-event';
        // Compatibility for recordings made before contextual event targets.
        return isOptionDescriptor(descriptor) && [descriptor, ...(descriptor.ancestors || [])]
            .some(item => /^\d+[A-Z]+\d+$/i.test(normalizeText(item.text)));
    }

    function templateDescriptor(descriptor, ticket) {
        if (descriptor.contextTarget === 'related-event') {
            const number = [descriptor, ...(descriptor.ancestors || [])]
                .map(item => normalizeText(item.text)).find(text => /^\d+[A-Z]+\d+$/i.test(text));
            if (number) descriptor = JSON.parse(replaceWholeIdentifier(JSON.stringify(descriptor), number, '{{RELATED_EVENT}}'));
        }
        return {
            ...descriptor,
            ariaLabel: tokenizeTicketValues(descriptor.ariaLabel, ticket),
            title: tokenizeTicketValues(descriptor.title, ticket),
            placeholder: tokenizeTicketValues(descriptor.placeholder, ticket),
            label: tokenizeTicketValues(descriptor.label, ticket),
            text: tokenizeTicketValues(descriptor.text, ticket),
            attributes: Object.fromEntries(Object.entries(descriptor.attributes || {}).map(([name, value]) => [
                name,
                name === 'id' || name === 'name' || name === 'type' || name === 'role'
                    ? value
                    : tokenizeTicketValues(value, ticket)
            ])),
            ancestors: (descriptor.ancestors || []).map(ancestor => ({
                ...ancestor,
                label: tokenizeTicketValues(ancestor.label, ticket),
                text: tokenizeTicketValues(ancestor.text, ticket)
            }))
        };
    }

    function renderDescriptor(descriptor, ticket) {
        return {
            ...descriptor,
            currentEvent: descriptor.contextTarget === 'related-event' ? ticket.relatedEvent || '' : '',
            ariaLabel: resolveTicketTemplate(descriptor.ariaLabel, ticket),
            title: resolveTicketTemplate(descriptor.title, ticket),
            placeholder: resolveTicketTemplate(descriptor.placeholder, ticket),
            label: resolveTicketTemplate(descriptor.label, ticket),
            text: resolveTicketTemplate(descriptor.text, ticket),
            attributes: Object.fromEntries(Object.entries(descriptor.attributes || {}).map(([name, value]) => [
                name,
                name === 'id' || name === 'name' || name === 'type' || name === 'role'
                    ? value
                    : resolveTicketTemplate(value, ticket)
            ])),
            ancestors: (descriptor.ancestors || []).map(ancestor => ({
                ...ancestor,
                label: resolveTicketTemplate(ancestor.label, ticket),
                text: resolveTicketTemplate(ancestor.text, ticket)
            }))
        };
    }

    function scoreCandidate(candidate, descriptor) {
        if (!candidate || String(candidate.localName || '').toLowerCase() !== descriptor.tag) return -1;
        for (const name of ['v-list-item__title', 'v-list-item__content', 'v-btn__content', 'v-input__slot']) {
            if (descriptor.classes?.includes(name) && !candidate.classList?.contains(name)) return -1;
        }
        const candidateRole = candidate.getAttribute('role') || '';
        const candidateName = candidate.getAttribute('name') || '';
        const candidateType = candidate.getAttribute('type') || '';
        const candidateLabel = elementLabel(candidate);
        const candidateText = interactiveText(candidate);
        if (descriptor.role && candidateRole && candidateRole !== descriptor.role) return -1;
        if (descriptor.name && candidateName && candidateName !== descriptor.name) return -1;
        if (descriptor.type && candidateType && candidateType !== descriptor.type) return -1;
        if (descriptor.label && candidateLabel && candidateLabel !== descriptor.label) return -1;
        if (descriptor.text && candidateText && candidateText !== descriptor.text) return -1;
        let score = 0;
        if (descriptor.id && !/^(input|list-item|list)-\d+(?:-\d+)?$/.test(descriptor.id) && candidate.id === descriptor.id) score += 12;
        if (descriptor.role && candidateRole === descriptor.role) score += 5;
        if (descriptor.name && candidateName === descriptor.name) score += 6;
        if (descriptor.type && candidateType === descriptor.type) score += 4;
        if (descriptor.ariaLabel && normalizeText(candidate.getAttribute('aria-label')) === normalizeText(descriptor.ariaLabel)) score += 8;
        if (descriptor.title && normalizeText(candidate.getAttribute('title')) === normalizeText(descriptor.title)) score += 5;
        if (descriptor.placeholder && normalizeText(candidate.getAttribute('placeholder')) === normalizeText(descriptor.placeholder)) score += 5;
        if (descriptor.label && candidateLabel === descriptor.label) score += 9;
        if (descriptor.text && candidateText === descriptor.text) score += 8;
        const sharedClasses = (descriptor.classes || []).filter(name => candidate.classList?.contains(name)).length;
        score += Math.min(sharedClasses, 3);
        let ancestor = candidate.parentElement;
        for (const expected of descriptor.ancestors || []) {
            if (!ancestor) break;
            // Older inner-content recordings identify the option by its parent's text.
            // Generated IDs change on remount, and classes alone tie all dropdown choices.
            const ancestorText = interactiveText(ancestor);
            if (expected.text && ancestorText && expected.text !== ancestorText) return -1;
            if (expected.text && ancestorText === expected.text) score += 8;
            if (expected.tag && String(ancestor.localName || '').toLowerCase() === expected.tag) score += 1;
            if (expected.id && ancestor.id === expected.id) score += 5;
            if (expected.role && ancestor.getAttribute('role') === expected.role) score += 3;
            if (expected.label && elementLabel(ancestor) === expected.label) score += 4;
            const sharedAncestorClasses = (expected.classes || []).filter(name => ancestor.classList?.contains(name)).length;
            score += Math.min(sharedAncestorClasses, 2);
            ancestor = ancestor.parentElement;
        }
        return score;
    }

    function targetKeyFor(element) {
        return element.id ? `id:${element.id}` : `css:${selectorFor(element)}`;
    }

    function uniqueBestCandidate(candidates, descriptor) {
        const ranked = candidates
            .map(element => ({ element, score: scoreCandidate(element, descriptor) }))
            .filter(item => item.score > 0)
            .sort((a, b) => b.score - a.score);
        if (!ranked.length || (ranked[1] && ranked[1].score === ranked[0].score)) return null;
        return ranked[0].element;
    }

    function replaceMacroStep(macro, index, targetKey, target) {
        const previousAction = macro.actions[index];
        if (!previousAction) throw new Error('El paso de la macro ya no existe.');
        const previousTarget = JSON.stringify(previousAction.target);
        const actions = macro.actions.map((action, position) => position >= index
            && action.targetKey === previousAction.targetKey
            && JSON.stringify(action.target) === previousTarget
            ? { ...action, targetKey, target } : action);
        return { ...macro, actions, corrections: [...(macro.corrections || []), {
            step: index + 1, correctedAt: new Date().toISOString(), previousAction
        }] };
    }

    function isOptionDescriptor(descriptor) {
        return [descriptor, ...(descriptor.ancestors || [])].some(item =>
            ['option', 'menuitem'].includes(item.role) || item.classes?.includes('v-list-item'));
    }

    globalThis.VienaTicketMacroCore = Object.freeze({
        tokenizeTicketValues,
        resolveTicketTemplate,
        templateDescriptor,
        renderDescriptor,
        shouldCollapseInputAction,
        isSensitiveInput,
        selectorFor,
        descriptorFor,
        scoreCandidate,
        uniqueBestCandidate,
        findTarget,
        clickTarget,
        setNativeValue,
        playbackDelayMs,
        replaceMacroStep
    });

    if (typeof document === 'undefined' || !document.body || !globalThis.chrome?.storage?.local) return;

    const state = {
        button: null,
        menu: null,
        status: null,
        nameInput: null,
        recording: null,
        macros: [],
        pendingDelete: '',
        cancelPlayback: false,
        repair: null,
        playing: false,
        hidden: true
    };

    function visible(element) {
        return Boolean(element && (element.offsetWidth || element.offsetHeight || element.getClientRects().length));
    }

    function activeTicketDialog() {
        const candidates = Array.from(document.querySelectorAll('.v-dialog__content--active'))
            .filter(visible)
            .filter(dialog => /^TICKET\s*:/i.test(normalizeText(dialog.querySelector('.v-toolbar__title')?.textContent)));
        return candidates[candidates.length - 1] || null;
    }

    function labelledValue(root, labelText) {
        for (const label of Array.from(root.querySelectorAll('.v-text-field__slot > label, label'))) {
            if (normalizeText(label.textContent).toLowerCase() !== labelText.toLowerCase()) continue;
            const field = label.closest('.v-input') || label.parentElement;
            const input = field?.querySelector('input,textarea,select');
            if (input && visible(input)) return String(input.value || '').trim();
        }
        return '';
    }

    function ticketContext(root = activeTicketDialog()) {
        if (!root) return { node: '', cmts: '' };
        return {
            node: labelledValue(root, 'Nodo'),
            cmts: labelledValue(root, 'Nodo CMTS')
        };
    }

    function ticketIsInitiated(root) {
        return Boolean(root && labelledValue(root, 'Estado').toUpperCase() === 'INICIADA');
    }

    function setStatus(message, isError = false) {
        if (!state.status) return;
        state.status.textContent = String(message || '');
        state.status.dataset.state = isError ? 'error' : 'info';
    }

    function markUi(element) {
        element.setAttribute(UI_ATTRIBUTE, '1');
        return element;
    }

    function makeButton(text, className = '') {
        const button = markUi(document.createElement('button'));
        button.type = 'button';
        button.textContent = text;
        button.className = `viena-macro-control ${className}`.trim();
        return button;
    }

    function isolateInteractiveSurface(surface) {
        for (const type of [
            'pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'dblclick',
            'keydown', 'keypress', 'keyup', 'input', 'change', 'focusin', 'focusout'
        ]) {
            surface.addEventListener(type, event => event.stopPropagation());
        }
        return surface;
    }

    function createUi() {
        const style = document.createElement('style');
        style.id = 'viena-ticket-macros-style';
        style.textContent = `
            [data-viena-macro-actions] { position:relative; }
            #viena-ticket-macros-anchor { position:absolute; left:50%; top:50%; transform:translate(-50%,-50%); display:flex; align-items:center; z-index:1000000; }
            #viena-ticket-macros-button { margin:0 !important; }
            @media (max-width:1200px) { #viena-ticket-macros-anchor { position:static; transform:none; flex:0 0 100%; justify-content:center; padding:6px 0; } }
            #viena-ticket-macros-menu { position:fixed; z-index:2147483647; box-sizing:border-box; width:min(440px,calc(100vw - 20px)); max-height:min(78vh,680px); overflow:auto; padding:16px; border:1px solid #c7d5e4; border-radius:12px; background:#f8fafc; color:#24324a; box-shadow:0 14px 34px rgba(15,35,60,.22); font:14px/1.4 Arial,sans-serif; }
            #viena-ticket-macros-menu[hidden] { display:none !important; }
            #viena-ticket-macros-menu * { box-sizing:border-box; }
            #viena-ticket-macros-menu [data-viena-macro-row] { display:flex; flex-wrap:wrap; align-items:center; gap:8px; padding:12px; margin:8px 0; border:1px solid #e2e8f0; border-radius:9px; background:#fff; }
            #viena-ticket-macros-menu [data-viena-macro-row] > span { min-width:0; flex:1; overflow-wrap:anywhere; font-weight:700; }
            #viena-ticket-macros-menu input { width:100%; margin:8px 0; padding:11px; border:1px solid #aabbd0; border-radius:7px; background:#fff; color:#24324a; font:14px Arial,sans-serif; }
            #viena-ticket-macros-menu .viena-macro-header { display:flex; align-items:center; gap:12px; margin:-16px -16px 16px; padding:16px; background:linear-gradient(120deg,#173f7a,#0f5aa9); color:#fff; }
            #viena-ticket-macros-menu .viena-macro-header > div { flex:1; min-width:0; }
            #viena-ticket-macros-menu .viena-macro-header h3 { margin:2px 0 0; font-size:17px; color:#fff; overflow-wrap:anywhere; }
            .viena-macro-brand { font-size:10px; font-weight:700; letter-spacing:1px; text-transform:uppercase; opacity:.8; }
            #viena-ticket-macros-menu .viena-macro-description { display:block; margin-top:4px; font-size:12px; font-weight:400; color:#64748b; }
            #viena-ticket-macros-menu .viena-macro-control, #viena-ticket-macro-recording .viena-macro-control { border:1px solid #b8c7d9; border-radius:7px; background:#fff; color:#173f7a; padding:8px 11px; font:700 12px Arial,sans-serif; cursor:pointer; min-height:34px; }
            #viena-ticket-macros-menu .viena-macro-primary { background:#0f5aa9; color:#fff; border-color:#0f5aa9; }
            #viena-ticket-macro-recording .viena-macro-stop { background:#b42318; color:#fff; border-color:#b42318; }
            #viena-ticket-macros-menu .viena-macro-danger { color:#b42318; border-color:#efcbc8; }
            #viena-ticket-macros-menu button:disabled { opacity:.5; cursor:default; }
            #viena-ticket-macros-menu button:focus-visible, #viena-ticket-macro-recording button:focus-visible, #viena-ticket-macros-menu input:focus-visible { outline:2px solid #1769aa; outline-offset:3px; }
            #viena-ticket-macros-menu button:hover:not(:disabled), #viena-ticket-macro-recording button:hover { filter:brightness(.95); }
            #viena-ticket-macros-menu [data-state="error"] { color:#b42318; }
            #viena-ticket-macro-recording { position:fixed; z-index:2147483646; top:12px; right:12px; width:min(440px,calc(100vw - 24px)); box-sizing:border-box; padding:14px; border:1px solid #c7d5e4; border-top:4px solid #173f7a; border-radius:10px; background:#fff; color:#24324a; box-shadow:0 8px 26px rgba(15,35,60,.2); font:13px/1.4 Arial,sans-serif; }
            #viena-ticket-macro-recording .viena-macro-record-title { display:flex; align-items:center; gap:8px; color:#173f7a; font-weight:700; }
            #viena-ticket-macro-recording .viena-macro-record-title::before { content:''; width:8px; height:8px; border-radius:50%; background:#b42318; flex:none; }
            #viena-ticket-macro-recording .viena-macro-record-name { display:block; margin:6px 0; font-weight:700; overflow-wrap:anywhere; }
            #viena-ticket-macro-recording .viena-macro-record-count { display:block; min-height:18px; color:#64748b; font-size:12px; font-variant-numeric:tabular-nums; }
            #viena-ticket-macro-recording .viena-macro-record-actions { display:flex; gap:8px; margin-top:12px; flex-wrap:wrap; }
            #viena-ticket-macro-recording[hidden] { display:none !important; }
            #viena-ticket-macro-playback { position:fixed; z-index:2147483646; bottom:16px; right:16px; width:min(340px,calc(100vw - 32px)); box-sizing:border-box; padding:12px; border:1px solid #c7d5e4; border-left:4px solid #173f7a; border-radius:9px; background:#fff; color:#24324a; box-shadow:0 6px 22px rgba(15,35,60,.18); font:12px/1.4 Arial,sans-serif; }
            #viena-ticket-macro-playback[hidden] { display:none !important; }
            #viena-ticket-macro-playback button { margin-top:8px; border:1px solid #b8c7d9; border-radius:7px; padding:7px 10px; background:#fff; color:#173f7a; font:700 12px Arial,sans-serif; cursor:pointer; }
            #viena-ticket-macro-playback [data-state="error"] { color:#b42318; }
            #viena-ticket-macros-menu .viena-macro-choice { display:block; width:100%; margin:7px 0; text-align:left; white-space:normal; overflow-wrap:anywhere; }
        `;
        document.head.appendChild(style);

        const menu = markUi(document.createElement('section'));
        menu.id = 'viena-ticket-macros-menu';
        menu.hidden = true;
        menu.setAttribute('role', 'dialog');
        menu.setAttribute('aria-label', 'Crear y reproducir tareas');
        isolateInteractiveSurface(menu);
        document.body.appendChild(menu);
        state.menu = menu;

        const recordingBar = markUi(document.createElement('div'));
        recordingBar.id = 'viena-ticket-macro-recording';
        recordingBar.hidden = true;
        recordingBar.setAttribute('role', 'status');
        recordingBar.setAttribute('aria-live', 'polite');
        isolateInteractiveSurface(recordingBar);
        document.body.appendChild(recordingBar);

        return recordingBar;
    }

    const recordingBar = createUi();

    function row(name, buttons, description = '') {
        const item = markUi(document.createElement('div'));
        item.setAttribute('data-viena-macro-row', '1');
        const label = markUi(document.createElement('span'));
        label.textContent = name;
        if (description) {
            const detail = markUi(document.createElement('small'));
            detail.className = 'viena-macro-description';
            detail.textContent = description;
            label.appendChild(detail);
        }
        item.appendChild(label);
        for (const button of buttons) item.appendChild(button);
        return item;
    }

    function addHeading(container, text) {
        const header = markUi(document.createElement('div'));
        header.className = 'viena-macro-header';
        const titles = markUi(document.createElement('div'));
        const brand = markUi(document.createElement('span'));
        brand.className = 'viena-macro-brand';
        brand.textContent = 'VIENA NOC Tools';
        const heading = markUi(document.createElement('h3'));
        heading.textContent = text;
        titles.append(brand, heading);
        header.appendChild(titles);
        container.appendChild(header);
        return header;
    }

    function addStatus(container, bindState = true) {
        const status = markUi(document.createElement('div'));
        status.setAttribute('aria-live', 'polite');
        status.style.cssText = 'min-height:20px;margin-top:8px;font-weight:700;font-size:12px;';
        container.appendChild(status);
        if (bindState) state.status = status;
        return status;
    }

    function renderList() {
        state.menu.replaceChildren();
        const header = addHeading(state.menu, 'Macros Tareas');
        const close = makeButton('Cerrar');
        close.addEventListener('click', closeMenu);
        header.appendChild(close);

        if (!state.macros.length) {
            const empty = markUi(document.createElement('p'));
            empty.textContent = 'Todavía no guardaste tareas macro.';
            state.menu.appendChild(empty);
        }

        for (const macro of state.macros) {
            const play = makeButton('Reproducir', 'viena-macro-primary');
            play.addEventListener('click', () => {
                if (state.playing || state.recording?.active) return;
                void playMacro(macro);
            });
            const remove = makeButton(state.pendingDelete === macro.id ? 'Confirmar borrado' : 'Eliminar', 'viena-macro-danger');
            remove.addEventListener('click', () => {
                if (state.pendingDelete !== macro.id) {
                    state.pendingDelete = macro.id;
                    renderList();
                    setStatus(`¿Eliminar "${macro.name}" de este navegador?`, false);
                    return;
                }
                void deleteMacro(macro.id);
            });
            state.menu.appendChild(row(macro.name, [play, remove], `${macro.actions.length} acciones`));
            if (state.pendingDelete === macro.id) {
                const confirm = markUi(document.createElement('p'));
                confirm.textContent = `Esta acción elimina solo la macro "${macro.name}".`;
                state.menu.appendChild(confirm);
            }
        }

        const record = makeButton('Grabar nueva tarea', 'viena-macro-primary');
        record.addEventListener('click', renderNewMacroForm);
        state.menu.appendChild(record);
        addStatus(state.menu);
    }

    function renderNewMacroForm() {
        state.menu.replaceChildren();
        addHeading(state.menu, 'Grabar una tarea');
        const warning = markUi(document.createElement('p'));
        warning.textContent = 'La grabación guarda localmente los valores escritos y datos de los controles para reproducirlos. No grabes contraseñas ni información que no quieras conservar en este navegador.';
        warning.style.cssText = 'font-size:12px;color:#526176;';
        state.menu.appendChild(warning);
        const input = markUi(document.createElement('input'));
        input.type = 'text';
        input.maxLength = 60;
        input.autocomplete = 'off';
        input.placeholder = 'Nombre de la tarea macro';
        input.setAttribute('aria-label', 'Nombre de la tarea macro');
        state.menu.appendChild(input);
        state.nameInput = input;
        const begin = makeButton('Iniciar grabación', 'viena-macro-primary');
        begin.addEventListener('click', () => startRecording(input.value));
        const back = makeButton('Volver');
        back.addEventListener('click', renderList);
        state.menu.append(row('El operador decide cuándo detenerla.', [begin, back]));
        addStatus(state.menu);
        setTimeout(() => {
            if (state.menu.contains(input) && !state.menu.hidden) {
                try { input.focus({ preventScroll: true }); } catch (_) { input.focus(); }
            }
        }, 0);
    }

    function renderReview() {
        state.menu.replaceChildren();
        const recording = state.recording;
        addHeading(state.menu, 'Grabación detenida');
        const summary = markUi(document.createElement('p'));
        summary.textContent = `${recording.actions.length} acciones capturadas para "${recording.name}".`;
        state.menu.appendChild(summary);
        const save = makeButton('Guardar tarea', 'viena-macro-primary');
        save.disabled = Boolean(recording.failure) || recording.actions.length === 0;
        save.addEventListener('click', () => void saveRecording());
        const discard = makeButton('Descartar');
        discard.addEventListener('click', () => {
            state.recording = null;
            renderList();
        });
        state.menu.append(row('Revisá antes de guardar.', [save, discard]));
        addStatus(state.menu);
        if (recording.failure) setStatus(recording.failure, true);
        else if (recording.warnings.length) setStatus(recording.warnings[0], false);
    }

    function renderRecordingBar() {
        if (!state.recording?.active) {
            recordingBar.hidden = true;
            return;
        }
        recordingBar.hidden = false;
        // Keep the pressed control alive while textarea blur/change is captured.
        if (!recordingBar.firstElementChild) {
            const title = markUi(document.createElement('div'));
            title.className = 'viena-macro-record-title';
            title.textContent = 'Grabación en curso';
            const name = markUi(document.createElement('span'));
            name.className = 'viena-macro-record-name';
            const count = markUi(document.createElement('span'));
            count.className = 'viena-macro-record-count';
            const actions = markUi(document.createElement('div'));
            actions.className = 'viena-macro-record-actions';
            const stop = makeButton('Detener grabación', 'viena-macro-stop');
            stop.addEventListener('click', stopRecording);
            const cancel = makeButton('Cancelar');
            cancel.addEventListener('click', cancelRecording);
            actions.append(stop, cancel);
            recordingBar.append(title, name, count, actions);
        }
        recordingBar.querySelector('.viena-macro-record-name').textContent = state.recording.name;
        recordingBar.querySelector('.viena-macro-record-count').textContent = `${state.recording.actions.length} acciones capturadas · Detenela cuando termines`;
    }

    async function readMacros() {
        const result = await chrome.storage.local.get(STORAGE_KEY);
        const stored = result?.[STORAGE_KEY];
        if (stored === undefined) return [];
        if (!stored || stored.schema !== 1 || !Array.isArray(stored.macros)) {
            throw new Error('El almacenamiento de macros tiene un formato no compatible; no se modificó.');
        }
        if (stored.macros.some(macro => !macro || typeof macro.id !== 'string'
            || typeof macro.name !== 'string' || !Array.isArray(macro.actions)
            || macro.actions.length > MAX_ACTIONS)) {
            throw new Error('Hay una tarea macro dañada; no se modificó el almacenamiento.');
        }
        return stored.macros;
    }

    async function writeMacros(macros) {
        if (macros.length > MAX_MACROS) throw new Error(`Se alcanzó el límite de ${MAX_MACROS} tareas macro.`);
        const payload = { schema: 1, macros };
        const bytes = new TextEncoder().encode(JSON.stringify(payload)).length;
        if (bytes > MAX_STORAGE_BYTES) throw new Error('Las macros superarían el límite local de almacenamiento de 4 MB.');
        await chrome.storage.local.set({ [STORAGE_KEY]: payload });
        state.macros = macros;
    }

    async function openMenu() {
        state.hidden = false;
        state.menu.hidden = false;
        try {
            state.macros = await readMacros();
            state.pendingDelete = '';
            renderList();
            positionMenu();
        } catch (error) {
            state.hidden = false;
            state.menu.hidden = false;
            state.menu.replaceChildren();
            addHeading(state.menu, 'No se pudieron cargar las tareas');
            addStatus(state.menu);
            setStatus(error.message, true);
            positionMenu();
        }
    }

    function closeMenu() {
        if (state.recording?.active || state.playing) return;
        state.hidden = true;
        state.menu.hidden = true;
        state.button?.setAttribute('aria-expanded', 'false');
    }

    function positionMenu() {
        if (!state.button || state.menu.hidden) return;
        const rect = state.button.getBoundingClientRect();
        const menuRect = state.menu.getBoundingClientRect();
        const left = Math.max(10, Math.min(rect.left, window.innerWidth - menuRect.width - 10));
        const top = Math.max(10, Math.min(rect.bottom + 7, window.innerHeight - menuRect.height - 10));
        state.menu.style.left = `${Math.round(left)}px`;
        state.menu.style.top = `${Math.round(top)}px`;
    }

    function startRecording(rawName) {
        const name = normalizeText(rawName);
        if (!name) {
            setStatus('Escribí un nombre para la tarea macro antes de grabar.', true);
            state.nameInput?.focus();
            return;
        }
        if (state.recording?.active) return;
        state.recording = {
            id: `macro-${Date.now()}-${globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2, 10)}`,
            name,
            startedAt: Date.now(),
            lastActionAt: Date.now(),
            context: ticketContext(),
            actions: [],
            warnings: [],
            failure: '',
            active: true
        };
        renderRecordingBar();
        state.menu.hidden = true;
        state.hidden = true;
    }

    function stopRecording() {
        if (!state.recording?.active) return;
        state.recording.active = false;
        renderRecordingBar();
        state.menu.hidden = false;
        state.hidden = false;
        renderReview();
        positionMenu();
    }

    function cancelRecording() {
        if (!state.recording?.active) return;
        state.recording.active = false;
        state.recording = null;
        renderRecordingBar();
        state.menu.hidden = false;
        state.hidden = false;
        renderList();
        positionMenu();
    }

    function captureTarget(event) {
        if (!state.recording?.active || state.playing || !event.isTrusted) return null;
        const raw = event.target;
        if (!(raw instanceof Element) || raw.closest(`[${UI_ATTRIBUTE}]`)) return null;
        if (isSensitiveInput(raw)) {
            const warning = 'Se omitió un campo sensible o selector de archivo.';
            if (!state.recording.warnings.includes(warning)) state.recording.warnings.push(warning);
            renderRecordingBar();
            return null;
        }
        return raw;
    }

    function appendAction(action) {
        const recording = state.recording;
        if (!recording?.active) return;
        if (recording.actions.length >= MAX_ACTIONS) {
            recording.failure = `La grabación superó ${MAX_ACTIONS} acciones y no se puede guardar.`;
            stopRecording();
            return;
        }
        action.delayMs = Math.min(2500, Math.max(0, Date.now() - recording.lastActionAt));
        recording.lastActionAt = Date.now();
        const previous = recording.actions[recording.actions.length - 1];
        if (shouldCollapseInputAction(previous, action)) {
            action.eventTypes = [...new Set([...(previous.eventTypes || [previous.eventType]), ...(action.eventTypes || [action.eventType])])];
            recording.actions[recording.actions.length - 1] = action;
        } else {
            recording.actions.push(action);
        }
        renderRecordingBar();
    }

    function captureClick(event) {
        try {
            const raw = captureTarget(event);
            if (!raw) return;
            // VIENA binds some actions on the inner title, not the enclosing menu item.
            const target = raw;
            appendAction({
                type: 'click',
                targetKey: targetKeyFor(target),
                target: templateDescriptor(descriptorFor(target), state.recording.context),
                eventType: 'click'
            });
        } catch (error) {
            if (state.recording) {
                state.recording.failure = `No se pudo capturar una acción: ${String(error?.message || error)}.`;
                renderRecordingBar();
            }
        }
    }

    function captureValue(event) {
        try {
            const target = captureTarget(event);
            if (!target || !target.matches('input,textarea,select,[contenteditable="true"]')) return;
            const descriptor = descriptorFor(target);
            if (target.matches('input[type="checkbox"],input[type="radio"]')) {
                appendAction({
                    type: 'setChecked',
                    targetKey: targetKeyFor(target),
                    target: templateDescriptor(descriptor, state.recording.context),
                    checked: Boolean(target.checked),
                    eventType: event.type
                });
                return;
            }
            const value = target.isContentEditable ? target.textContent : target.value;
            const exactValue = String(value ?? '');
            appendAction({
                type: 'setValue',
                targetKey: targetKeyFor(target),
                target: templateDescriptor(descriptor, state.recording.context),
                value: exactValue,
                valueTemplate: tokenizeTicketValues(exactValue, state.recording.context),
                eventType: event.type
            });
        } catch (error) {
            if (state.recording) {
                state.recording.failure = `No se pudo capturar el contenido de un campo: ${String(error?.message || error)}.`;
                renderRecordingBar();
            }
        }
    }

    function captureKey(event) {
        if (!['Enter', 'Escape', 'Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
        try {
            const target = captureTarget(event);
            if (!target) return;
            appendAction({
                type: 'key',
                targetKey: targetKeyFor(target),
                target: templateDescriptor(descriptorFor(target), state.recording.context),
                key: event.key,
                code: event.code,
                altKey: Boolean(event.altKey),
                ctrlKey: Boolean(event.ctrlKey),
                metaKey: Boolean(event.metaKey),
                shiftKey: Boolean(event.shiftKey),
                eventType: 'keydown'
            });
        } catch (error) {
            if (state.recording) {
                state.recording.failure = `No se pudo capturar una tecla: ${String(error?.message || error)}.`;
                renderRecordingBar();
            }
        }
    }

    document.addEventListener('click', captureRepairTarget, true);
    document.addEventListener('click', captureClick, true);
    document.addEventListener('input', captureValue, true);
    document.addEventListener('change', captureValue, true);
    document.addEventListener('keydown', captureKey, true);
    let pointerOnMacroUi = false;
    document.addEventListener('pointerdown', event => {
        const target = event.target;
        pointerOnMacroUi = Boolean(target instanceof Element && target.closest(`[${UI_ATTRIBUTE}]`));
        if (pointerOnMacroUi) setTimeout(() => { pointerOnMacroUi = false; }, 0);
    }, true);
    document.addEventListener('focusin', event => captureFocus(event, 'focus'), true);
    document.addEventListener('focusout', event => captureFocus(event, 'blur'), true);

    function captureFocus(event, type) {
        try {
            if (pointerOnMacroUi || event.relatedTarget?.closest?.(`[${UI_ATTRIBUTE}]`)) return;
            const target = captureTarget(event);
            if (!target) return;
            appendAction({
                type,
                targetKey: targetKeyFor(target),
                target: templateDescriptor(descriptorFor(target), state.recording.context),
                eventType: event.type
            });
        } catch (error) {
            if (state.recording) {
                state.recording.failure = `No se pudo capturar el foco de un control: ${String(error?.message || error)}.`;
                renderRecordingBar();
            }
        }
    }

    async function saveRecording() {
        const recording = state.recording;
        if (!recording || recording.active || recording.failure || !recording.actions.length) return;
        try {
            const macros = await readMacros();
            if (macros.some(macro => macro.name.toLowerCase() === recording.name.toLowerCase())) {
                throw new Error('Ya existe una tarea con ese nombre; elegí otro nombre para evitar reemplazarla.');
            }
            await writeMacros([...macros, {
                id: recording.id,
                name: recording.name,
                createdAt: new Date(recording.startedAt).toISOString(),
                actions: recording.actions
            }]);
            state.recording = null;
            renderList();
            setStatus('Tarea macro guardada localmente en este navegador.', false);
        } catch (error) {
            setStatus(`No se pudo guardar la tarea macro: ${String(error?.message || error)}`, true);
        }
    }

    async function deleteMacro(id) {
        try {
            const macros = await readMacros();
            await writeMacros(macros.filter(macro => macro.id !== id));
            state.pendingDelete = '';
            renderList();
            setStatus('Tarea macro eliminada de este navegador.', false);
        } catch (error) {
            setStatus(`No se pudo eliminar la tarea macro: ${String(error?.message || error)}`, true);
        }
    }

    function findTarget(descriptor, dom = document) {
        const dialogs = Array.from(dom.querySelectorAll('.v-dialog__content--active')).filter(visible);
        const activeDialog = dialogs[dialogs.length - 1];
        const loadingOverlay = activeDialog?.querySelector?.('.v-overlay--active');
        if (loadingOverlay && visible(loadingOverlay)) return null;
        const eligible = element => {
            if (!element || !visible(element) || element.disabled || element.closest?.(`[${UI_ATTRIBUTE}]`)) return false;
            // Vuetify keeps old dialogs and forms mounted; portaled menus remain outside the dialog.
            const dialog = element.closest?.('.v-dialog__content');
            if (dialog) return dialog === activeDialog;
            // Selection gestures can record the exact application root. It is
            // an ancestor of the active modal, not a background form control.
            if (descriptor.id === 'app' && element.id === 'app' && activeDialog
                && element.contains(activeDialog)) return true;
            return !activeDialog || Boolean(element.closest?.('.v-menu__content'));
        };
        if (isRelatedEventDescriptor(descriptor)) {
            const menus = Array.from(dom.querySelectorAll('.v-menu__content')).filter(menu => visible(menu) && isRelatedEventMenu(menu));
            if (menus.length) {
                const events = menus.flatMap(menu => Array.from(menu.querySelectorAll('.v-list-item__title'))).filter(eligible);
                if (descriptor.currentEvent) {
                    const selected = events.filter(item => normalizeText(item.textContent) === descriptor.currentEvent);
                    return selected.length === 1 ? selected[0] : null;
                }
                // Event numbers belong to the current ticket. Never choose by
                // the old number or silently pick one when several are listed.
                return events.length === 1 ? events[0] : null;
            }
            if (descriptor.contextTarget === 'related-event') return null;
        }
        let direct = null;
        try {
            direct = descriptor.selector ? dom.querySelector(descriptor.selector) : null;
        } catch (_) {}
        const generatedId = /^(input|list-item|list)-\d+(?:-\d+)?$/.test(descriptor.id || '');
        if (!generatedId && eligible(direct) && scoreCandidate(direct, descriptor) >= 4) return direct;

        const tag = /^[a-z][a-z0-9-]*$/i.test(descriptor.tag) ? descriptor.tag : '*';
        const candidates = Array.from(dom.querySelectorAll(tag)).filter(eligible);
        return uniqueBestCandidate(candidates, descriptor);
    }

    async function waitForTarget(descriptor, timeoutMs = 8000) {
        const end = Date.now() + timeoutMs;
        while (Date.now() < end) {
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            const target = findTarget(descriptor);
            if (target && visible(target) && !target.disabled) return target;
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        return null;
    }

    function setNativeValue(target, value) {
        if (target.isContentEditable) {
            target.textContent = value;
            return;
        }
        const prototype = Object.getPrototypeOf(target);
        const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
        if (setter) setter.call(target, value);
        else target.value = value;
        if (target.localName === 'textarea') {
            target.setSelectionRange(0, 0);
            target.scrollTop = 0;
            target.scrollLeft = 0;
        }
    }

    function playbackDelayMs(recordedDelay) {
        const delay = Number(recordedDelay);
        return Number.isFinite(delay) ? Math.min(250, Math.max(0, delay / 10)) : 0;
    }

    async function clickTarget(target) {
        if (target.matches('select')) return;
        // Older recordings stored the menu-item wrapper. The supplied VIENA bundle
        // binds openTaskCreation on its title; clicking the title also bubbles to the wrapper.
        const hit = target.matches('[role="menuitem"],.v-list-item')
            ? target.querySelector('.v-list-item__title') || target
            : target;
        const rect = hit.getBoundingClientRect();
        const init = { bubbles: true, cancelable: true, composed: true, view: window,
            clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, button: 0 };
        hit.dispatchEvent(new MouseEvent('mouseover', init));
        // mouseenter does not bubble. Reproduce entry along the path so both a
        // hover activator and a portaled menu can cancel their pending close delay.
        const path = [];
        for (let element = hit; element; element = element.parentElement) path.unshift(element);
        for (const element of path) element.dispatchEvent(new MouseEvent('mouseenter', { ...init, bubbles: false }));
        hit.dispatchEvent(new MouseEvent('mousemove', init));
        await new Promise(resolve => setTimeout(resolve, 0));
        hit.dispatchEvent(new MouseEvent('mousedown', { ...init, buttons: 1 }));
        if (target.matches('button,a,input,textarea,[tabindex]')) target.focus({ preventScroll: true });
        hit.dispatchEvent(new MouseEvent('mouseup', { ...init, buttons: 0 }));
        hit.dispatchEvent(new MouseEvent('click', { ...init, buttons: 0, detail: 1 }));
    }

    async function executeAction(action, ticket) {
        const descriptor = renderDescriptor(action.target, ticket);
        if (Object.values({
            ariaLabel: descriptor.ariaLabel,
            title: descriptor.title,
            placeholder: descriptor.placeholder,
            label: descriptor.label,
            text: descriptor.text
        }).some(value => value === null)) {
            throw new Error('La macro requiere datos Nodo/Nodo CMTS que no están disponibles en este ticket.');
        }
        // A blur can be recorded after Vue has removed its control. It must not stop the next action.
        const target = action.type === 'blur' ? findTarget(descriptor) : await waitForTarget(descriptor);
        if (!target && action.type === 'blur') return;
        if (!target) {
            const error = new Error(`No se encontró de forma inequívoca el control ${descriptor.label || descriptor.text || descriptor.id || descriptor.selector}.`);
            error.macroTargetMissing = true;
            throw error;
        }
        if (action.type === 'click') {
            target.scrollIntoView?.({ block: 'nearest', inline: 'nearest' });
            await clickTarget(target);
        } else if (action.type === 'setValue') {
            const value = resolveTicketTemplate(action.valueTemplate ?? action.value, ticket);
            if (value === null) throw new Error('La macro requiere Nodo o Nodo CMTS y el ticket actual no tiene ese dato.');
            setNativeValue(target, value);
            for (const eventType of action.eventTypes || [action.eventType || 'input']) {
                target.dispatchEvent(new Event(eventType, { bubbles: true }));
            }
        } else if (action.type === 'setChecked') {
            target.checked = Boolean(action.checked);
            for (const eventType of action.eventTypes || [action.eventType || 'change']) {
                target.dispatchEvent(new Event(eventType, { bubbles: true }));
            }
        } else if (action.type === 'key') {
            target.dispatchEvent(new KeyboardEvent('keydown', {
                key: action.key,
                code: action.code || '',
                altKey: Boolean(action.altKey),
                ctrlKey: Boolean(action.ctrlKey),
                metaKey: Boolean(action.metaKey),
                shiftKey: Boolean(action.shiftKey),
                bubbles: true,
                cancelable: true
            }));
        } else if (action.type === 'focus') {
            target.focus({ preventScroll: true });
        } else if (action.type === 'blur') {
            target.blur();
        } else {
            throw new Error(`Tipo de acción no compatible: ${String(action.type)}`);
        }
    }

    function cancelPlayback() {
        state.cancelPlayback = true;
        const repair = state.repair;
        if (repair && !repair.saving) {
            state.repair = null;
            repair.reject(new Error('Reproducción detenida por el operador.'));
        }
    }

    function showStepCorrection(repair) {
        state.menu.replaceChildren();
        const action = repair.macro.actions[repair.index];
        const descriptor = renderDescriptor(action.target, repair.ticket);
        addHeading(state.menu, `Actualizar paso ${repair.index + 1}`);
        const info = markUi(document.createElement('p'));
        const previous = isRelatedEventDescriptor(descriptor) ? 'Evento asociado al ticket actual' : descriptor.text || descriptor.label
            || descriptor.ancestors?.find(item => item.text)?.text || 'Control grabado';
        info.textContent = `La macro "${repair.macro.name}" esperaba: ${previous}. VIENA no lo muestra como fue grabado.`;
        state.menu.appendChild(info);
        const help = markUi(document.createElement('p'));
        help.textContent = 'Elegí la opción actual para guardar la corrección y continuar desde este paso. Los pasos anteriores no se repiten.';
        state.menu.appendChild(help);
        if (isOptionDescriptor(descriptor)) {
            const options = Array.from(document.querySelectorAll('.v-menu__content [role="option"],.v-menu__content [role="menuitem"]'));
            for (const option of options) {
                const target = option.querySelector('.v-list-item__title,.v-list-item__content') || option;
                const current = descriptorFor(target);
                if (!visible(target) || option.getAttribute('aria-disabled') === 'true'
                    || findTarget({ ...current, contextTarget: 'exact' }) !== target) continue;
                const choice = makeButton(normalizeText(option.textContent), 'viena-macro-choice');
                choice.addEventListener('click', () => void saveStepCorrection(repair, target));
                state.menu.appendChild(choice);
            }
        }
        const capture = makeButton('Grabar corrección en VIENA', 'viena-macro-primary');
        capture.addEventListener('click', () => {
            if (repair.saving) return;
            repair.capture = true;
            state.menu.hidden = true;
            state.hidden = true;
            state.button?.setAttribute('aria-expanded', 'false');
            setStatus(`Paso ${repair.index + 1}: hacé clic en ${isOptionDescriptor(descriptor) ? 'la nueva opción' : 'el control correcto'} de VIENA.`, false);
        });
        const refresh = makeButton('Ver opciones actuales');
        refresh.addEventListener('click', () => { if (!repair.saving) showStepCorrection(repair); });
        const stop = makeButton('Detener reproducción');
        stop.addEventListener('click', cancelPlayback);
        state.menu.append(row('Corregí sólo este paso.', [capture, refresh, stop]));
        repair.status = addStatus(state.menu, false);
        state.menu.hidden = false;
        state.hidden = false;
        state.button?.setAttribute('aria-expanded', 'true');
        positionMenu();
    }

    function requestStepCorrection(macro, index, ticket) {
        return new Promise((resolve, reject) => {
            const repair = { macro, index, ticket, resolve, reject, saving: false, capture: false, status: null };
            state.repair = repair;
            setStatus(`Macro en pausa: el paso ${index + 1} requiere una corrección.`, false);
            showStepCorrection(repair);
        });
    }

    async function saveStepCorrection(repair, target) {
        if (state.repair !== repair || repair.saving || state.cancelPlayback) return;
        repair.saving = true;
        try {
            const descriptor = descriptorFor(target);
            if (isSensitiveInput(target) || findTarget({ ...descriptor, contextTarget: 'exact' }) !== target) {
                throw new Error('El control elegido ya no está disponible. Volvé a elegirlo en VIENA.');
            }
            const latest = [...await readMacros()];
            const position = latest.findIndex(item => item.id === repair.macro.id);
            if (position < 0 || JSON.stringify(latest[position].actions[repair.index])
                !== JSON.stringify(repair.macro.actions[repair.index])) {
                throw new Error('La macro cambió en otra ventana. Detené la reproducción y volvé a abrirla.');
            }
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            const corrected = replaceMacroStep(latest[position], repair.index, targetKeyFor(target),
                templateDescriptor(descriptor, repair.ticket));
            latest[position] = corrected;
            await writeMacros(latest);
            if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
            if (descriptor.contextTarget === 'related-event') {
                repair.ticket.relatedEvent = normalizeText(target.closest('.v-list-item,[role="menuitem"]')?.textContent || target.textContent);
            }
            state.repair = null;
            state.menu.hidden = true;
            state.hidden = true;
            state.button?.setAttribute('aria-expanded', 'false');
            repair.resolve(corrected);
        } catch (error) {
            if (state.cancelPlayback) {
                state.repair = null;
                repair.reject(error);
            } else {
                repair.capture = false;
                showStepCorrection(repair);
                repair.status.textContent = String(error?.message || error);
                repair.status.dataset.state = 'error';
            }
        } finally {
            repair.saving = false;
        }
    }

    function captureRepairTarget(event) {
        const repair = state.repair;
        if (!repair?.capture || repair.saving || !event.isTrusted || state.cancelPlayback) return;
        const target = event.target;
        if (!(target instanceof Element) || target.closest(`[${UI_ATTRIBUTE}]`) || isSensitiveInput(target)) return;
        if (isOptionDescriptor(repair.macro.actions[repair.index].target)
            && !target.closest('[role="option"],[role="menuitem"],.v-list-item')) return;
        // Capture the replacement click, then execute it once after the correction is saved.
        event.preventDefault();
        event.stopImmediatePropagation();
        void saveStepCorrection(repair, target);
    }

    async function playMacro(macro) {
        state.playing = true;
        state.cancelPlayback = false;
        state.menu.hidden = true;
        state.hidden = true;
        state.button?.setAttribute('aria-expanded', 'false');
        let playback = document.getElementById('viena-ticket-macro-playback');
        if (!playback) {
            playback = markUi(document.createElement('section'));
            playback.id = 'viena-ticket-macro-playback';
            playback.setAttribute('role', 'status');
            isolateInteractiveSurface(playback);
            document.body.appendChild(playback);
        }
        playback.replaceChildren();
        playback.hidden = false;
        const title = markUi(document.createElement('strong'));
        title.textContent = macro.name;
        playback.appendChild(title);
        addStatus(playback);
        const cancel = makeButton('Detener reproducción');
        cancel.addEventListener('click', cancelPlayback);
        playback.appendChild(cancel);
        const context = ticketContext();
        let currentMacro = macro;
        let currentStep = 0;
        let succeeded = false;
        try {
            for (let index = 0; index < currentMacro.actions.length; index += 1) {
                if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                currentStep = index + 1;
                const action = currentMacro.actions[index];
                setStatus(`Acción ${index + 1} de ${currentMacro.actions.length}…`, false);
                const delayMs = playbackDelayMs(action.delayMs);
                if (delayMs > 0) await new Promise(resolve => setTimeout(resolve, delayMs));
                if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                let completed = false;
                while (!completed) {
                    try {
                        await executeAction(currentMacro.actions[index], context);
                        completed = true;
                    } catch (error) {
                        if (!error.macroTargetMissing || state.cancelPlayback) throw error;
                        currentMacro = await requestStepCorrection(currentMacro, index, context);
                        if (state.cancelPlayback) throw new Error('Reproducción detenida por el operador.');
                    }
                }
                // Let Vue apply synchronous state changes before locating the next control.
                await new Promise(resolve => setTimeout(resolve, 0));
            }
            setStatus(`Se completaron ${currentMacro.actions.length} acciones. Revisá el resultado en VIENA.`, false);
            succeeded = true;
        } catch (error) {
            setStatus(`Reproducción detenida en la acción ${currentStep}: ${String(error?.message || error)}`, true);
        } finally {
            state.playing = false;
            state.cancelPlayback = false;
            state.repair = null;
            state.menu.hidden = true;
            state.hidden = true;
            state.button?.setAttribute('aria-expanded', 'false');
            cancel.remove();
            const dismiss = makeButton('Cerrar');
            dismiss.addEventListener('click', () => { playback.hidden = true; });
            const done = makeButton('Volver a las tareas');
            done.addEventListener('click', () => {
                playback.hidden = true;
                void openMenu();
            });
            playback.append(dismiss, done);
            if (succeeded) {
                const completedStatus = state.status;
                setTimeout(() => {
                    if (!state.playing && state.status === completedStatus) playback.hidden = true;
                }, 6000);
            }
        }
    }

    function mountButton() {
        const root = activeTicketDialog();
        const panel = root?.querySelector('#panel-plantillas-viena');
        const initiated = ticketIsInitiated(root);
        if (!initiated || !panel?.parentElement) {
            state.button?.parentElement?.remove();
            state.button = null;
            if (state.recording?.active) {
                state.recording.failure = 'El ticket dejó de estar INICIADA; se detuvo la grabación sin guardarla.';
                stopRecording();
            }
            closeMenu();
            return;
        }
        if (state.button?.isConnected) return;
        const button = markUi(document.createElement('button'));
        button.type = 'button';
        button.id = 'viena-ticket-macros-button';
        button.className = 'mx-3 v-btn v-btn--is-elevated v-btn--has-bg theme--dark v-size--default primary';
        button.setAttribute('aria-haspopup', 'dialog');
        button.setAttribute('aria-expanded', 'false');
        const content = markUi(document.createElement('span'));
        content.className = 'v-btn__content';
        content.textContent = 'Macros Tareas';
        button.appendChild(content);
        button.style.cssText = 'cursor:pointer;margin-left:8px;';
        button.addEventListener('click', () => {
            if (state.recording?.active || state.playing) return;
            if (state.menu.hidden) void openMenu();
            else closeMenu();
            button.setAttribute('aria-expanded', String(!state.menu.hidden));
        });
        const actions = panel.parentElement;
        actions.setAttribute('data-viena-macro-actions', '1');
        const anchor = markUi(document.createElement('div'));
        anchor.id = 'viena-ticket-macros-anchor';
        anchor.appendChild(button);
        actions.appendChild(anchor);
        state.button = button;
    }

    function observeTicketUi() {
        document.addEventListener('viena:ui-refresh', mountButton);
        let timer = 0;
        const observer = new MutationObserver(mutations => {
            const relevant = mutations.some(mutation => {
                const nodes = [...mutation.addedNodes, ...mutation.removedNodes];
                return nodes.some(node => {
                    const element = node.nodeType === 1 ? node : node.parentElement;
                    return element && (element.id === 'panel-plantillas-viena'
                        || (state.button && (element === state.button || element.contains?.(state.button))));
                });
            });
            if (!relevant) return;
            clearTimeout(timer);
            timer = setTimeout(mountButton, 40);
        });
        observer.observe(document.body, { childList: true, subtree: true });
        window.addEventListener('resize', positionMenu, { passive: true });
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape' && !state.recording?.active && !state.playing) closeMenu();
        });
        mountButton();
    }

    observeTicketUi();
})();
