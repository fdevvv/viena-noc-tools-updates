/* MIRA Estadísticas: lectura local de series, sin alterar gráficos o requests. */
(function () {
  'use strict';
  const number = value => typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : null;
  function date(value) {
    const label = String(value || '').replace(/\\\//g, '/').trim();
    const m = label.match(/^(\d{2})\/(\d{2})\/(\d{2}|\d{4}) (\d{2}):(\d{2})$/);
    if (!m) return null;
    const year = +m[3] < 100 ? 2000 + +m[3] : +m[3];
    const stamp = Date.UTC(year, +m[2]-1, +m[1], +m[4], +m[5]);
    const check = new Date(stamp);
    if (check.getUTCFullYear()!==year || check.getUTCMonth()!==+m[2]-1 || check.getUTCDate()!==+m[1] || +m[4]>23 || +m[5]>59) return null;
    return {label, stamp, day: `${year}-${m[2]}-${m[1]}`, hour: +m[4], time: `${m[4]}:${m[5]}`};
  }
  function identify(title) {
    const m = String(title || '').match(/^(.+?)\s+-\s+(Fec\s+(DS|US)\s+global|% de CMs c\/errores de (DS|US)|Cant\. de CMs c\/errores de (DS|US))\s+-\s+(QAM|OFDM|OFDMA)$/i);
    if (!m) return null;
    return {node:m[1].trim(), direction:(m[3]||m[4]||m[5]).toUpperCase(), tech:m[6].toUpperCase()==='OFDMA'?'OFDM':m[6].toUpperCase(), metric:m[3]?'fec':m[4]?'percent':'count'};
  }
  function analyze(charts) {
    const sources = new Map(), nodes = new Set();
    let ambiguous = false;
    for (const chart of charts) {
      const id = identify(chart.title);
      if (!id) continue;
      nodes.add(id.node);
      for (const series of chart.series || []) {
        if (!/^(Pre|Post)$/i.test(series.name)) continue;
        const name = /^pre$/i.test(series.name)?'Pre':'Post';
        const key = `${id.direction}/${id.tech}/${name}/${id.metric}`;
        if (sources.has(key)) ambiguous = true;
        const points = new Map();
        (chart.categories || []).forEach((label,i) => {
          const dt = date(label);
          if (!dt) return;
          if (points.has(dt.stamp)) ambiguous = true;
          const raw = (series.data || [])[i];
          points.set(dt.stamp,{...dt,value:number(raw && typeof raw==='object'?Array.isArray(raw)?raw[1]:raw.y:raw)});
        });
        sources.set(key,points);
      }
    }
    if (nodes.size>1) return {error:'mixed-nodes',groups:[]};
    if (ambiguous) return {error:'ambiguous-charts',groups:[]};
    const groups = [], allDates = new Map();
    for (const direction of ['DS','US']) for (const tech of ['QAM','OFDM']) for (const name of ['Pre','Post']) {
      const key = `${direction}/${tech}/${name}`, maps = {}, affectedThreshold=direction==='DS'?40:20;
      for (const metric of ['fec','percent','count']) maps[metric]=sources.get(`${key}/${metric}`) || new Map();
      const stamps = [...new Set([...maps.fec.keys(),...maps.percent.keys(),...maps.count.keys()])].sort((a,b)=>a-b);
      const samples = stamps.map(stamp => {
        const dt = maps.fec.get(stamp)||maps.percent.get(stamp)||maps.count.get(stamp);
        allDates.set(stamp,dt);
        const fec=maps.fec.get(stamp)?.value??null, percent=maps.percent.get(stamp)?.value??null, count=maps.count.get(stamp)?.value??null;
        const reasons=[];
        if (direction==='DS' && fec!==null && fec>1e-6) reasons.push('FEC > 1,0e-6');
        if (direction==='US' && name==='Post' && fec!==null && fec>=20) reasons.push('FEC Post US ≥ 20%');
        if (percent!==null && percent>=affectedThreshold) reasons.push(`CMs ≥ ${affectedThreshold}%`);
        return {...dt,fec,percent,count,reasons};
      });
      // Cadencia del origen; no unir huecos grandes, aunque cambie la fecha.
      const gaps=samples.slice(1).map((p,i)=>p.stamp-samples[i].stamp).filter(n=>n>0);
      gaps.sort((a,b)=>a-b);
      const cadence=gaps.length?gaps[Math.floor((gaps.length-1)/2)]:0;
      const events=[];let event=null;
      for (const p of samples) {
        if (!p.reasons.length) {event=null;continue;}
        if (!event || (cadence && p.stamp-event.end.stamp>Math.min(cadence*1.5,90*60000))) {
          event={start:p,end:p,peak:p,fecPeak:p,percentPeak:p,countPeak:p,reasons:[],points:0};events.push(event);
        }
        event.end=p;event.points++;
        event.reasons=[...new Set([...event.reasons,...p.reasons])];
        for (const [metric,field] of [['fec','fecPeak'],['percent','percentPeak'],['count','countPeak']]) {
          if (p[metric]!==null && (event[field][metric]===null || p[metric]>event[field][metric])) event[field]=p;
        }
        // La muestra representativa mantiene las tres métricas en la misma fecha.
        event.peak=event.reasons.includes(`CMs ≥ ${affectedThreshold}%`)?event.percentPeak:event.fecPeak;
      }
      const hours=new Map();
      for (const p of samples) {
        if (!hours.has(p.hour)) hours.set(p.hour,{days:new Set(),observedDays:new Set()});
        const h=hours.get(p.hour);
        if (((direction==='DS' || name==='Post') && p.fec!==null) || p.percent!==null) h.observedDays.add(p.day);
        if (p.reasons.length) h.days.add(p.day);
      }
      const patterns=[];
      for (const [hour,h] of [...hours.entries()].filter(([,h])=>h.days.size>=2).sort((a,b)=>a[0]-b[0])) {
        const next={hour,endHour:hour+1,days:[...h.days].sort(),observedDays:[...h.observedDays].sort()},last=patterns.at(-1);
        if(last && last.endHour===hour && JSON.stringify(last.days)===JSON.stringify(next.days) && JSON.stringify(last.observedDays)===JSON.stringify(next.observedDays))last.endHour=hour+1;
        else patterns.push(next);
      }
      groups.push({key,direction,tech,name,samples,events,patterns,cadence,days:[...new Set(samples.map(p=>p.day))].sort(),incomplete:!samples.length || samples.some(p=>p.fec===null||p.percent===null||p.count===null)});
    }
    const dates=[...allDates.values()].sort((a,b)=>a.stamp-b.stamp);
    return {node:[...nodes][0]||'',groups,start:dates[0],end:dates.at(-1),days:[...new Set(dates.map(p=>p.day))].sort(),chartCount:charts.length};
  }
  const extraMetrics={'Estado CMs':['cmStatus','cantCms','cmFrecNum'],'SNR US/DS':['cmSnr','cmIcmpPloss','cmIcmpPorcPloss'],'PWR US/DS':['cmPwrDs','cmPwrUs']};
  function extraGroup(sourceId){const metric=String(sourceId||'').match(/_chartGral_([A-Za-z]+)$/)?.[1];return Object.keys(extraMetrics).find(group=>extraMetrics[group].includes(metric))||null;}
  function chartSpec(source,groups){
    if(extraGroup(source.sourceId)){
      const options=JSON.parse(JSON.stringify(source.nativeOptions||{}));
      options.chart={...(options.chart||{}),height:source.chartHeight||options.chart?.height||260,animation:true};delete options.chart.renderTo;
      options.series=options.series||JSON.parse(JSON.stringify(source.series));
      const axes=Array.isArray(options.yAxis)?options.yAxis:[options.yAxis||{}];
      axes.forEach((axis,i)=>{const formatter=source.formatters?.axes?.[i]||(i===0?source.formatters?.axis:null);if(formatter)axis.labels={...(axis.labels||{}),formatter};});
      options.yAxis=Array.isArray(options.yAxis)?axes:axes[0];
      if(source.formatters?.tooltip)options.tooltip={...(options.tooltip||{}),formatter:source.formatters.tooltip};
      options.title={...(options.title||{}),text:source.title};
      options.plotOptions={...(options.plotOptions||{}),series:{...(options.plotOptions?.series||{}),animation:true}};
      return options;
    }
    const id=identify(source.title),options=JSON.parse(JSON.stringify(source.nativeOptions||{})),axis=Array.isArray(options.xAxis)?options.xAxis[0]:options.xAxis||{};
    const percent=id.metric==='percent'||id.metric==='fec'&&id.direction==='US',scientific=id.metric==='fec'&&id.direction==='DS';
    const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const value=n=>n===null||n===undefined?'Sin dato':scientific?Number(n).toExponential(1):String(n)+(percent?'%':'');
    function pointText(){const p=this.point||this,label=source.categories[p.x]??p.category??this.x,name=p.series?.name||this.series?.name||'';return escape(label)+'<br>'+escape(name)+': <b>'+escape(value(p.y))+'</b>';}
    const nativeAxis=source.formatters?.axis,nativeTooltip=source.formatters?.tooltip;
    const yAxis=Array.isArray(options.yAxis)?options.yAxis[0]:options.yAxis||{};
    yAxis.labels={...(yAxis.labels||{}),formatter:typeof nativeAxis==='function'?nativeAxis:function(){return scientific?Number(this.value).toExponential(2):String(this.value)+(percent?'%':'');}};
    options.yAxis=Array.isArray(options.yAxis)?[yAxis,...options.yAxis.slice(1)]:yAxis;
    options.tooltip={...(options.tooltip||{}),formatter:function(){if(!String(this.series?.name||this.point?.series?.name||'').startsWith('Picos ')&&typeof nativeTooltip==='function')return nativeTooltip.call(this);return pointText.call(this);}};
    const stamps=source.categories.map(label=>date(label)?.stamp),selected=groups.filter(g=>g.direction===id.direction&&g.tech===id.tech),bands=[];
    options.series=options.series||JSON.parse(JSON.stringify(source.series));
    for(const g of selected){const peaks=[];for(const event of g.events){const from=stamps.indexOf(event.start.stamp),to=stamps.indexOf(event.end.stamp);if(from>=0&&to>=0)bands.push({from:Math.max(-.5,from-.5),to:to+.5,color:g.name==='Post'?'rgba(250,70,97,.07)':'rgba(91,132,255,.07)'});const p=event[id.metric+'Peak'],x=stamps.indexOf(p.stamp),y=p[id.metric];if(x>=0&&y!==null&&!(id.metric==='fec'&&id.direction==='DS'&&y<=0))peaks.push({x,y});}
      if(peaks.length)options.series.push({name:'Picos '+g.name,type:'scatter',data:peaks,color:g.name==='Post'?'#fa4661':'#5b84ff',marker:{symbol:'diamond',radius:5},showInLegend:true,tooltip:{pointFormatter:pointText}});
    }
    options.xAxis={...axis,categories:source.categories.slice(),plotBands:[...(axis.plotBands||[]),...bands]};
    options.chart={...(options.chart||{}),height:source.chartHeight||options.chart?.height||260,animation:true};delete options.chart.renderTo;
    options.plotOptions={...(options.plotOptions||{}),series:{...(options.plotOptions?.series||{}),animation:true}};
    options.title={...(options.title||{}),text:source.title};
    return options;
  }
  function directionalSnr(source,direction){
    if(!source||!['US','DS'].includes(direction))return null;
    const options=JSON.parse(JSON.stringify(source.nativeOptions||{}));
    options.series=(options.series||source.series||[]).filter(series=>String(series.name).toUpperCase()===direction);
    return options.series.length?{...source,title:(source.title.split(' - ')[0]||'')+' - SNR '+direction,nativeOptions:options}:null;
  }
  function pngFilename(node,label,now=new Date()){const stamp=[String(now.getDate()).padStart(2,'0'),String(now.getMonth()+1).padStart(2,'0'),now.getFullYear()].join('-');return (String(node)+' '+label+' '+stamp).replace(/[<>:"/\\|?*\x00-\x1f]/g,'-').trim()+'.png';}
  function folderDestination(store,pick,changed=()=>{},timeoutMs=15000){
    let handle=null,loadError=null;
    const ready=store.read().then(value=>{handle=value||null;changed(handle);}).catch(error=>{loadError=error;});
    async function permit(value){
      if(await value.queryPermission({mode:'readwrite'})!=='granted'&&await (globalThis.VienaPermissionUI ? globalThis.VienaPermissionUI.request(value) : value.requestPermission({mode:'readwrite'}))!=='granted')throw new Error('Necesitás permitir el acceso a la carpeta.');
      return value;
    }
    async function change(){await ready;const next=await pick();await permit(next);await store.write(next);handle=next;loadError=null;changed(handle);return handle;}
    return {ready,change,async ensure(){await ready;if(loadError){handle=await store.read();loadError=null;changed(handle);}return handle?permit(handle):change();},async save(directory,blob,filename){
      const deadline=Date.now()+timeoutMs;
      function step(operation,late){return new Promise((resolve,reject)=>{
        let expired=false;const timer=setTimeout(()=>{expired=true;reject(new Error('La carpeta no respondió a tiempo.'));},Math.max(0,deadline-Date.now()));
        Promise.resolve(operation).then(value=>{clearTimeout(timer);if(expired){if(late)Promise.resolve(late(value)).catch(()=>{});}else resolve(value);},error=>{clearTimeout(timer);reject(error);});
      });}
      let name=filename,index=0;
      // Keep previous captures, including those created outside this page.
      for(;;){try{await step(directory.getFileHandle(name));}catch(error){if(error.name==='NotFoundError')break;throw error;}name=filename.replace(/\.png$/i,' ('+(++index)+').png');}
      const file=await step(directory.getFileHandle(name,{create:true})),writer=await step(file.createWritable(),late=>late.abort());
      try{await step(writer.write(blob));await step(writer.close());}catch(error){try{Promise.resolve(writer.abort()).catch(()=>{});}catch{}throw error;}
      return name;
    }};
  }
  if (typeof module==='object' && module.exports) {module.exports={analyze,date,identify,chartSpec,extraGroup,directionalSnr,pngFilename,folderDestination};return;}
  if (location.hostname!=='mira5-gdt.telecentro.net.ar' || location.pathname!=='/stats_frontend.php' || window.__VIENA_MIRA_FEC__) return;
  window.__VIENA_MIRA_FEC__=true;
  const ROOT='[id$="-dataChart-gral"]', PANEL='[data-viena-fec-summary]';
  // New, site-scoped preference; existing extension/operator storage is untouched.
  const VIEW_KEY='viena.mira.generalCharts.view';let view='tabs';
  try{if(localStorage.getItem(VIEW_KEY)==='original')view='original';}catch{}
  document.documentElement.toggleAttribute('data-viena-mira-original',view==='original');
  const states=new Map(), hooked=new WeakSet();let timer=0;
  let ticketDirection=null;
  window.addEventListener('viena-mira-ticket-direction',event=>{
    const {node,direction}=event.detail||{};
    ticketDirection=view==='tabs'&&typeof node==='string'&&/^[A-Z0-9_-]+$/.test(node)&&['US','DS'].includes(direction)
      ? {node,direction,expires:Date.now()+30000} : null;
    schedule();
  });
  const fmt=(v,scientific=false)=>v===null||v===undefined?'Sin dato':scientific?v.toExponential(2).replace('.',','):v.toLocaleString('es-AR',{maximumFractionDigits:2});
  const day=d=>d.split('-').reverse().join('/');
  function el(tag,text,className) {const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(className)node.className=className;return node;}
  // Dedicated MIRA database; existing extension/site stores remain untouched.
  function folderStorage(mode,value){return new Promise((resolve,reject)=>{
    let db,transaction,finished=false;
    const finish=(error,result)=>{if(finished)return;finished=true;clearTimeout(timeout);db?.close();error?reject(error):resolve(result);};
    const timeout=setTimeout(()=>{try{transaction?.abort();}catch{}finish(new Error('No se pudo acceder a la carpeta guardada. Volvé a intentarlo.'));},8000);
    let request;try{request=indexedDB.open('viena-mira-chart-downloads',1);}catch(error){finish(error);return;}
    request.onupgradeneeded=()=>{if(!finished)request.result.createObjectStore('destination');else request.transaction.abort();};
    request.onerror=()=>finish(request.error);request.onblocked=()=>finish(new Error('Cerrá las otras pestañas de Estadísticas y volvé a intentarlo.'));
    request.onsuccess=()=>{
      db=request.result;if(finished){db.close();return;}
      try{transaction=db.transaction('destination',mode);const store=transaction.objectStore('destination'),op=mode==='readonly'?store.get('folder'):store.put(value,'folder');let result;
        op.onsuccess=()=>{result=op.result;};transaction.oncomplete=()=>finish(null,result);transaction.onabort=transaction.onerror=()=>finish(transaction.error||new Error('No se pudo guardar la carpeta.'));
      }catch(error){finish(error);}
    };
  });}
  let folderName='',folderBusy=false;
  function syncFolderControls(){document.querySelectorAll('[data-viena-chart-folder]').forEach(control=>{
    control.querySelector('span').textContent=folderName?'Carpeta: '+folderName:'Carpeta de imágenes: elegir al descargar';
    control.querySelector('button').textContent=folderName?'Cambiar carpeta':'Elegir carpeta';
    control.querySelector('button').disabled=folderBusy;
  });}
  const destination=folderDestination({read:()=>folderStorage('readonly'),write:value=>folderStorage('readwrite',value)},()=>{
    if(typeof window.showDirectoryPicker!=='function')throw new Error('Este navegador no permite elegir una carpeta. Usá Chrome actualizado.');
    return globalThis.VienaPermissionUI.folder({id:'viena-mira-chart-images',mode:'readwrite'});
  },handle=>{folderName=handle?.name||'';syncFolderControls();});
  function folderControl(control){if(control.querySelector('[data-viena-chart-folder]'))return;
    const host=el('div',undefined,'vf-folder'),label=el('span'),button=el('button'),status=el('span');host.dataset.vienaChartFolder='';button.type='button';status.setAttribute('role','status');host.append(label,button,status);control.append(host);
    button.onclick=async()=>{if(folderBusy)return;folderBusy=true;syncFolderControls();status.textContent='';try{await destination.change();}catch(error){status.textContent=error.name==='AbortError'?'':'No se pudo cambiar la carpeta. Volvé a intentarlo.';}finally{folderBusy=false;syncFolderControls();}};syncFolderControls();
  }
  function snapshot(root) {
    const charts=[];
    for (const chart of window.Highcharts?.charts || []) {
      if (!chart?.renderTo?.isConnected || !root.contains(chart.renderTo)||chart.renderTo.closest(PANEL)) continue;
      if (!hooked.has(chart) && window.Highcharts.addEvent) {
        hooked.add(chart);window.Highcharts.addEvent(chart,'redraw',schedule);
      }
      charts.push({sourceId:chart.renderTo.id,chartHeight:chart.chartHeight,title:chart.options?.title?.text||'',categories:chart.xAxis?.[0]?.categories||chart.options?.xAxis?.categories||[],series:(chart.series||[]).map(s=>({name:s.name,data:s.options?.data||[]})),nativeOptions:JSON.parse(JSON.stringify({...chart.userOptions,yAxis:chart.yAxis.map(axis=>axis.options)},(key,value)=>key==='renderTo'||typeof value==='function'?undefined:value)),formatters:{axes:chart.yAxis.map(axis=>axis.options?.labels?.formatter),axis:chart.yAxis?.[0]?.options?.labels?.formatter,tooltip:chart.options?.tooltip?.formatter}});
    }
    return charts;
  }
  function destroyCharts(state){for(const node of state.hidden||[])node.classList.remove('vf-native-duplicate');state.hidden=[];for(const chart of state.charts||[])try{chart.destroy();}catch{}state.charts=[];}
  function reflowNative(root){for(const chart of window.Highcharts?.charts||[]){if(chart?.renderTo?.isConnected&&root.contains(chart.renderTo)&&!chart.renderTo.closest(PANEL)&&Math.abs(chart.chartWidth-chart.renderTo.clientWidth)>4)chart.reflow();}}
  function frequencyPeriodSync(){
    const $=window.jQuery;if(!$?.ajaxPrefilter)return;
    let applied=null;
    // Observe native general requests; rewrite only the period of native node-frequency requests.
    // jQuery 2.1.1 serializes data before prefilters. No extra requests or persistent state.
    $.ajaxPrefilter((options,original,jqXHR)=>{
      const url=new URL(options.url,location.href);
      if(url.origin!==location.origin||typeof options.data!=='string')return;
      const general=url.pathname==='/tabs/stats_tab_grafico_gral.php';
      if(!general&&url.pathname!=='/tabs/stats_tab_grafico_frec.php')return;
      const data=new URLSearchParams(options.data);
      if(data.get('tipoElemento')!=='nodoCmts'||!data.get('elemento'))return;
      const node=data.get('elemento');
      if(general){
        const period=['diasatras','fechadesde','fechahasta'].map(key=>data.get(key)||'');
        jqXHR.done(()=>{applied={node,period};});
      }else if(['DS','US'].includes(data.get('tipo'))&&data.get('frec')&&
        document.querySelector('#BOTON-NODOCMTS-CHART-GRAL')?.getAttribute('elemento')===node){
        // DS uses its own fixed history window; general/CM and US periods stay independent.
        if(data.get('tipo')==='DS'){
          data.set('diasatras','1.99');data.set('fechadesde','');data.set('fechahasta','');
        }else if(applied?.node===node){
          ['diasatras','fechadesde','fechahasta'].forEach((key,i)=>data.set(key,applied.period[i]));
        }
        options.data=data.toString();
      }
    });
  }
  frequencyPeriodSync();
  function quickDayControls(root){
    const input=root.querySelector('#nodoCmts-filtro-diasAtras');
    const filter=root.querySelector('[name="filtro-diasAtras"][tipoelemento="nodoCmts"]');
    let host=root.querySelector('[data-viena-quick-days]');
    if(!input||!filter){host?._dispose();return;}
    if(host&&(host._input!==input||host._filter!==filter)){host._dispose();host=null;}
    if(!host){
      host=el('div',undefined,'vf-quick-days');host.dataset.vienaQuickDays='';
      host.setAttribute('role','group');host.setAttribute('aria-label','Filtrar días atrás');
      host._input=input;host._filter=filter;
      for(const days of [2,3,4,5,6,7]){
        const button=el('button',String(days));button.type='button';
        button.title='Filtrar últimos '+days+' días';button.setAttribute('aria-label',button.title);
        button.onclick=()=>{
          if(!input.isConnected||!filter.isConnected||input.disabled||input.readOnly||filter.disabled)return;
          input.value=String(days);input.dispatchEvent(new Event('input',{bubbles:true}));
          input.dispatchEvent(new Event('change',{bubbles:true}));filter.click();
        };host.append(button);
      }
      // Empty Bootstrap column confirmed by UI_TRACE (8); never replace native controls.
      const slot=filter.parentElement?.nextElementSibling;
      if(slot?.matches('.col-sm-2')&&!slot.children.length&&!slot.textContent.trim())slot.append(host);
      else {host.classList.add('vf-quick-days-fallback');(filter.closest('div[style*="background"]')||root).append(host);}
      const sync=()=>{for(const button of host.children){button.disabled=input.disabled||input.readOnly||filter.disabled;button.setAttribute('aria-pressed',String(input.value===button.textContent));}};
      host._sync=sync;input.addEventListener('input',sync);input.addEventListener('change',sync);
      host._dispose=()=>{input.removeEventListener('input',sync);input.removeEventListener('change',sync);host.remove();};
    }
    host._sync();
  }
  function viewControl(root){
    let control=root.querySelector('[data-viena-chart-view]');
    if(!control){control=el('div',undefined,'vf-view-controls');control.dataset.vienaChartView='';const label=el('label','Vista de gr\u00e1ficos: '),select=el('select');select.setAttribute('aria-label','Vista de gr\u00e1ficos');for(const [value,text]of [['tabs','Por solapas'],['original','Gr\u00e1ficos originales']]){const option=el('option',text);option.value=value;select.append(option);}label.append(select);control.append(label);select.onchange=()=>{
      ticketDirection=null;view=select.value==='original'?'original':'tabs';try{localStorage.setItem(VIEW_KEY,view);}catch{}
      document.documentElement.toggleAttribute('data-viena-mira-original',view==='original');
      for(const [target,state]of states){destroyCharts(state);target.querySelector(PANEL)?.remove();target.querySelector('[data-viena-traffic-heading]')?.removeAttribute('data-viena-traffic-heading');state.signature='';if(view==='original')target.setAttribute('data-viena-fec-fallback','');else target.removeAttribute('data-viena-fec-fallback');reflowNative(target);}
      update();root.querySelector('[data-viena-chart-view] select')?.focus({preventScroll:true});
    };const filter=root.querySelector('[name="filtro-diasAtras"]')?.closest('div[style*="background"]');if(filter)filter.after(control);else root.prepend(control);}
    folderControl(control);control.querySelector('select').value=view;return control;
  }
  function metricSection(panel,title,items){const section=el('section',undefined,'vf-tech'),grid=el('div',undefined,'vf-graphs');section.append(el('h3',title));grid.style.gridTemplateColumns='repeat('+items.length+',minmax(0,1fr))';for(const [metric,source]of items){const graph=el('div',undefined,'vf-chart');graph.dataset.metric=metric;if(source)graph._source=source;else graph.textContent='Sin datos para esta medida.';grid.append(graph);}section.append(grid);panel.append(section);return section;}
  function svgImage(svg){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'})),image=new Image(),timeout=setTimeout(()=>finish(new Error('image timeout')),8000);function finish(error){clearTimeout(timeout);image.onload=image.onerror=null;URL.revokeObjectURL(url);if(error){image.src='';reject(error);}else resolve(image);}image.onload=()=>finish();image.onerror=()=>finish(new Error('image'));image.src=url;});}
  function canvasPng(canvas){return new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('PNG timeout')),8000);try{canvas.toBlob(blob=>{clearTimeout(timeout);blob?resolve(blob):reject(new Error('PNG'));},'image/png');}catch(error){clearTimeout(timeout);reject(error);}});}
  async function downloadPng(rows,filename,directory){
    if(!rows.length||rows.some(row=>!row.length||row.some(chart=>!chart?.renderTo?.isConnected)))throw new Error('missing chart');
    const gap=12,padding=16,cellWidth=600,width=padding*2+Math.max(...rows.map(row=>row.length))*(cellWidth+gap)-gap,cells=[],host=el('div');host.dataset.vienaExportWork='';host.style.cssText='position:fixed;left:-100000px;top:0;pointer-events:none';document.body.append(host);let y=48;
    try{
      for(const row of rows){const height=Math.max(...row.map(chart=>chart.chartHeight));
        for(let i=0;i<row.length;i++){const source=row[i],target=el('div');host.append(target);try{
          const options=window.Highcharts.merge({},source.userOptions);options.chart={...(options.chart||{}),width:cellWidth,height:source.chartHeight,animation:false,backgroundColor:'#fff'};delete options.chart.renderTo;
          options.series=source.series.map(series=>window.Highcharts.merge({},series.options,{visible:series.visible,color:series.color,animation:false}));
          for(const name of ['xAxis','yAxis'])options[name]=source[name].map(axis=>{const copy=window.Highcharts.merge({},axis.options),limits=axis.getExtremes();if(Number.isFinite(limits.userMin))copy.min=limits.userMin;if(Number.isFinite(limits.userMax))copy.max=limits.userMax;return copy;});
          options.plotOptions=window.Highcharts.merge({},options.plotOptions,{series:{animation:false}});options.exporting={...(options.exporting||{}),enabled:false};
          const chart=window.Highcharts.chart(target,options),svg=chart.renderer.box.cloneNode(true);svg.setAttribute('xmlns','http://www.w3.org/2000/svg');svg.querySelectorAll('.highcharts-tooltip,.highcharts-button,.highcharts-crosshair,.highcharts-halo').forEach(node=>node.remove());
          cells.push({svg:new XMLSerializer().serializeToString(svg),x:padding+i*(cellWidth+gap),y,width:cellWidth,height:source.chartHeight});
        }finally{for(const chart of window.Highcharts.charts)if(chart?.renderTo===target)try{chart.destroy();}catch{}target.remove();}}
        y+=height+gap;
      }
    }finally{host.remove();}
    const canvas=el('canvas');canvas.width=width;canvas.height=y-gap+padding;const context=canvas.getContext('2d');if(!context)throw new Error('canvas');context.fillStyle='#fff';context.fillRect(0,0,width,canvas.height);context.fillStyle='#18344e';context.font='bold 18px Arial';context.fillText(filename.slice(0,-4),padding,30,width-padding*2);
    for(const cell of cells){const image=await svgImage(cell.svg);context.drawImage(image,cell.x,cell.y,cell.width,cell.height);}
    const blob=await canvasPng(canvas);await destination.save(directory,blob,filename);
  }
  function downloadButton(section,state,node,label,text,rows){
    let actions=section.querySelector('.vf-download-actions');if(!actions){actions=el('div',undefined,'vf-download-actions');const heading=section.querySelector('h3');if(heading)heading.after(actions);else section.append(actions);}
    const button=el('button',undefined,'vf-download'),icon=el('span','\u2193'),status=el('span',undefined,'vf-download-status');icon.setAttribute('aria-hidden','true');button.append(icon,document.createTextNode(' Descargar '+text));button.title='Descargar imagen PNG: '+text;button.setAttribute('aria-label',button.title);button.type='button';button.dataset.downloadLabel=label;button.disabled=!!state.exporting;status.setAttribute('role','status');actions.append(button,status);
    button.onclick=async()=>{if(state.exporting||folderBusy)return;state.exporting=true;folderBusy=true;syncFolderControls();const root=section.closest(ROOT);root.querySelectorAll('.vf-download').forEach(b=>b.disabled=true);button.setAttribute('aria-busy','true');status.textContent='Preparando imagen\u2026';
      try{const directory=await destination.ensure(),charts=rows().map(row=>row.map(graph=>state.charts.find(chart=>chart.renderTo===graph)));await downloadPng(charts,pngFilename(node,label),directory);status.textContent='Guardada en '+directory.name;}
      catch(error){status.textContent=error.name==='AbortError'?'':'No se pudo guardar la imagen. Volvé a intentarlo o cambiá la carpeta.';}
      finally{state.exporting=false;folderBusy=false;syncFolderControls();button.removeAttribute('aria-busy');root.querySelectorAll('.vf-download').forEach(b=>b.disabled=false);}
    };
  }
  function singleChartDownload(section,metric,state,node,label,text,align='flex-start'){const graph=section.querySelector('[data-metric="'+metric+'"]'),card=el('div',undefined,'vf-chart-card');graph.before(card);card.append(graph);downloadButton(card,state,node,label,text,()=>[[graph]]);const actions=card.querySelector('.vf-download-actions');card.prepend(actions);actions.style.justifyContent=align;}
  function hideDuplicates(root,state){
    for(const node of state.hidden||[])node.classList.remove('vf-native-duplicate');state.hidden=[];
    if(!state.charts.length)return;const hidden=new Set();
    for(const chart of window.Highcharts?.charts||[]){if(!chart?.renderTo?.isConnected||!root.contains(chart.renderTo)||chart.renderTo.closest(PANEL)||!(identify(chart.options?.title?.text)||extraGroup(chart.renderTo.id)))continue;
      const column=chart.renderTo.closest('.col-lg-4');hidden.add(column&&column.parentElement===root?column:chart.renderTo);
    }
    for(const node of root.children){
      const leases=node.querySelector(':scope > [id$="_chartGral_cmLeasesCant"], :scope > [id$="_chartGral_cmLeasesPorc"]');
      if(node.classList.contains('col-lg-4')&&leases&&getComputedStyle(leases).visibility==='hidden')hidden.add(node);
      if(node.classList.contains('col-lg-4')&&/^cmTr\u00e1fico$/i.test(node.textContent.trim())&&!node.querySelector('[data-highcharts-chart]')){node.dataset.vienaTrafficHeading='';let next=node.nextElementSibling;for(let i=0;i<2&&next?.classList.contains('col-lg-4')&&!next.textContent.trim()&&!next.querySelector('[data-highcharts-chart]');i++,next=next.nextElementSibling)hidden.add(next);}
      if(node.classList.contains('col-lg-4')&&/^(?:cmFec(?:Us|Ds)(?:Ofdm)?|cmStatus|cmCant|cmfrecuencias|cmSnr|cmIcmp|cmPwrDs|cmPwrUs)$/i.test(node.textContent.trim())&&!node.querySelector('[data-highcharts-chart]')){hidden.add(node);let next=node.nextElementSibling;for(let i=0;i<2&&next?.classList.contains('col-lg-4')&&!next.textContent.trim()&&!next.querySelector('[data-highcharts-chart]');i++,next=next.nextElementSibling)hidden.add(next);}
    }
    for(const node of hidden)node.classList.add('vf-native-duplicate');state.hidden=[...hidden];
    for(const chart of window.Highcharts?.charts||[]){if(chart?.renderTo?.isConnected&&root.contains(chart.renderTo)&&/_chartGral_cmTrafico(?:Cant|Porc)$/.test(chart.renderTo.id)&&Math.abs(chart.chartWidth-chart.renderTo.clientWidth)>4)chart.reflow();}
  }
  function render(root,result,state) {
    destroyCharts(state);root.querySelector(PANEL)?.remove();
    const panel=el('section',undefined,'viena-fec-summary');panel.dataset.vienaFecSummary='';panel.setAttribute('aria-label','An\u00e1lisis FEC del nodo');
    const head=el('div',undefined,'vf-head');head.append(el('strong','An\u00e1lisis del nodo \u00b7 '+(result.node||'Sin datos')));panel.append(head);
    if(result.error)panel.append(el('p','No se puede analizar: hay gr\u00e1ficos duplicados o de distintos nodos.','vf-warning'));
    else{
      panel.append(el('p',result.start?result.start.label+' \u2192 '+result.end.label+' \u00b7 '+result.days.length+' d\u00edas con muestras':'Esperando datos.'));
      const selector=el('div',undefined,'vf-selector');selector.setAttribute('aria-label','Elegir secci\u00f3n del an\u00e1lisis');
      for(const direction of ['Estado CMs','US','DS']){const b=el('button',direction,'vf-choice');b.type='button';b.dataset.group=direction;b.setAttribute('aria-pressed',String(state.selection===direction));const count=result.groups.filter(g=>g.direction===direction).reduce((n,g)=>n+g.events.length,0);if(direction==='US'||direction==='DS')b.append(el('span',count+' episodios'));b.onclick=()=>{if(state.selection!==direction)state.expanded.clear();state.selection=direction;render(root,result,state);const selected=root.querySelector('[data-group="'+direction+'"]');selected.focus({preventScroll:true});requestAnimationFrame(()=>{if(!selected.isConnected)return;const graph=root.querySelector(PANEL+' .vf-chart');if(!graph)return;const rect=graph.getBoundingClientRect(),choice=selected.getBoundingClientRect();const offset=Math.min(rect.top+(rect.height-innerHeight)/2,choice.top-24);window.scrollTo({top:Math.max(0,scrollY+offset),left:scrollX,behavior:'instant'});});};selector.append(b);}panel.append(selector);
      const source=metric=>state.sources.find(c=>c.sourceId?.endsWith('_chartGral_'+metric));
      if(state.selection==='Estado CMs'){
        const section=metricSection(panel,state.selection,extraMetrics[state.selection].map(metric=>[metric,source(metric)]));
        downloadButton(section,state,result.node,'RESPUESTA DE LOS CMS','Respuesta de los CMs',()=>[[section.querySelector('[data-metric="cmStatus"]')]]);
        metricSection(panel,'P\u00e9rdida de paquetes',['cmIcmpPloss','cmIcmpPorcPloss'].map(metric=>[metric,source(metric)]));
      }else{
        const direction=state.selection,section=metricSection(panel,'SNR y PWR '+direction,[['cmSnr',directionalSnr(source('cmSnr'),direction)],[direction==='US'?'cmPwrUs':'cmPwrDs',source(direction==='US'?'cmPwrUs':'cmPwrDs')]]);
        if(direction==='DS')downloadButton(section,state,result.node,'SNR Y PWR DS','SNR DS y PWR DS',()=>[[...section.querySelectorAll('.vf-chart')]]);
        else {singleChartDownload(section,'cmSnr',state,result.node,'SNR US','SNR US');singleChartDownload(section,'cmPwrUs',state,result.node,'US POWER','US PWR','flex-end');}
      }
      for(const tech of extraMetrics[state.selection]?[]:['QAM','OFDM']){
        const section=el('section',undefined,'vf-tech');section.append(el('h3',state.selection+' '+tech));const graphGrid=el('div',undefined,'vf-graphs');
        for(const metric of ['fec','percent','count']){const source=state.sources.find(c=>{const id=identify(c.title);return id&&id.direction===state.selection&&id.tech===tech&&id.metric===metric;});const graph=el('div',undefined,'vf-chart');graph.dataset.metric=metric;graphGrid.append(graph);if(source)graph._source=source;else graph.textContent='Sin datos para esta medida.';}
        section.append(graphGrid);downloadButton(section,state,result.node,state.selection+' '+tech,state.selection+' '+tech,()=>[[...graphGrid.querySelectorAll('.vf-chart')]]);const grid=el('div',undefined,'vf-grid');
        for(const g of result.groups.filter(g=>g.direction===state.selection&&g.tech===tech)){
          const card=el('article',undefined,'vf-card');card.append(el('h3',g.direction+' '+g.tech+' \u00b7 '+g.name),el('p',!g.samples.length?'Sin datos disponibles':g.events.length?g.events.length+' episodios':'Sin muestras por encima de los umbrales'));
          if(g.incomplete)card.append(el('p','Informaci\u00f3n incompleta: faltan m\u00e9tricas o muestras coincidentes.','vf-warning'));
          const details=el('details');details.className='vf-detail';details.open=state.expanded.has(g.key);details.addEventListener('toggle',()=>{if(details.isConnected)details.open?state.expanded.add(g.key):state.expanded.delete(g.key);});details.append(el('summary','Ver detalle de episodios y picos'));
          if(!g.events.length)details.append(el('p','No se detectaron episodios con los criterios actuales.'));
          for(const pattern of g.patterns){const h=String(pattern.hour).padStart(2,'0'),end=String(pattern.endHour).padStart(2,'0');details.append(el('p',h+':00\u2013'+end+':00 aprox.: '+pattern.days.length+' de '+pattern.observedDays.length+' d\u00edas con datos en esa hora.','vf-pattern'),el('p',pattern.days.map(day).join(' \u00b7 ')));}
          if(g.events.length){
          const scroll=el('div',undefined,'vf-table'),table=el('table'),thead=el('thead'),tr=el('tr');
          for(const title of ['Día / franja','Motivo','Hora de referencia','FEC','CMs %','CMs cantidad'])tr.append(el('th',title));thead.append(tr);table.append(thead);
          const tbody=el('tbody');
          for (const event of g.events) {
            const p=event.peak,row=el('tr');
            const crossDay=event.start.day!==event.end.day;
            const moment=sample=>crossDay?`${day(sample.day)} ${sample.time}`:sample.time;
            const end=event.end.stamp===event.start.stamp?'':crossDay?` – ${day(event.end.day)} · ${event.end.time}`:'–'+event.end.time;
            for(const text of [`${day(event.start.day)} · ${event.start.time}${end}`,event.reasons.join(' + '),moment(p),fmt(p.fec,g.direction==='DS')+(g.direction==='US'&&p.fec!==null?'%':''),fmt(p.percent)+(p.percent!==null?'%':''),fmt(p.count)])row.append(el('td',text));
            tbody.append(row);
            const peaks=el('tr'),cell=el('td',`Picos del episodio: FEC ${fmt(event.fecPeak.fec,g.direction==='DS')}${g.direction==='US'&&event.fecPeak.fec!==null?'%':''} (${moment(event.fecPeak)}) · ${fmt(event.percentPeak.percent)}${event.percentPeak.percent!==null?'%':''} (${moment(event.percentPeak)}) · ${fmt(event.countPeak.count)} CMs (${moment(event.countPeak)})`,'vf-note');cell.colSpan=6;peaks.append(cell);tbody.append(peaks);
          }
          table.append(tbody);scroll.append(table);details.append(scroll);

          }
          card.append(details);grid.append(card);
        }
        section.append(grid);panel.append(section);
      }
      if(!extraMetrics[state.selection]){const criteria=el('details');criteria.append(el('summary','Criterios del an\u00e1lisis'),el('p','FEC DS > 1,0e-6; FEC Post US \u2265 20%; CMs con errores DS \u2265 40% y US \u2265 20%. Pre y Post se analizan por separado. Las franjas sombreadas muestran episodios; los rombos, picos de cada medida. Los datos faltantes no prueban normalidad. Las coincidencias no determinan la causa.','vf-note'));panel.append(criteria);}
    }
    viewControl(root).after(panel);
    for(const graph of panel.querySelectorAll('.vf-chart')){if(graph._source&&window.Highcharts?.chart){try{state.charts.push(window.Highcharts.chart(graph,chartSpec(graph._source,result.groups)));}catch{graph.textContent='No se pudo mostrar esta medida.';}delete graph._source;}}
    root.toggleAttribute('data-viena-fec-fallback',!state.charts.length);
    hideDuplicates(root,state);
  }
  function update() {
    timer=0;
    for (const [root,state] of states) if (!root.isConnected) {destroyCharts(state);state.observer.disconnect();states.delete(root);}
    for (const root of document.querySelectorAll(ROOT)) {
      let state=states.get(root);
      if (!state) {
        state={signature:'',node:'',selection:'Estado CMs',charts:[],sources:[],expanded:new Set(),observer:new MutationObserver(records=>{
          if(records.some(r=>[...r.addedNodes,...r.removedNodes].some(n=>n.nodeType===1&&!n.matches?.(PANEL+', [data-viena-chart-view]'))))schedule();
        })};state.observer.observe(root,{childList:true});states.set(root,state);
      }
      const charts=snapshot(root);
      // Native MIRA owns empty/loading containers; a view control would make them nonempty before loading.
      if (!charts.length) {destroyCharts(state);root.querySelector(PANEL)?.remove();root.querySelector('[data-viena-chart-view]')?.remove();root.querySelector('[data-viena-quick-days]')?._dispose();state.signature='';continue;}
      quickDayControls(root);
      if(ticketDirection&&Date.now()>ticketDirection.expires)ticketDirection=null;
      const requestedResult=ticketDirection?analyze(charts):null;
      const current=root.querySelector('[name="filtro-diasAtras"]')?.getAttribute('elemento');
      const requested=view==='tabs'&&ticketDirection&&requestedResult.node===ticketDirection.node&&(!current||current===requestedResult.node);
      viewControl(root);
      if(view==='original'){root.setAttribute('data-viena-fec-fallback','');continue;}
      const signature=JSON.stringify(charts);
      if(!requested&&signature===state.signature && root.querySelector(PANEL)){hideDuplicates(root,state);continue;}
      state.signature=signature;state.sources=charts;
      const result=requestedResult||analyze(charts);
      if(current && result.node && current!==result.node) {destroyCharts(state);root.querySelector(PANEL)?.remove();continue;}
      if(state.node!==result.node){state.node=result.node;state.selection='Estado CMs';state.expanded.clear();}
      if(requested){state.selection=ticketDirection.direction;state.expanded.clear();ticketDirection=null;}
      render(root,result,state);
    }
  }
  function schedule() {if(!timer)timer=setTimeout(()=>{try{update();}catch(_){timer=0;for(const [root,state] of states){destroyCharts(state);root.setAttribute('data-viena-fec-fallback','');root.querySelector(PANEL)?.remove();}}},100);}
  const style=el('style');style.textContent=`
    .vf-native-duplicate{display:none!important}
    .vf-quick-days{display:flex;flex-wrap:wrap;gap:4px;align-items:center;min-width:0;padding:0 4px;box-sizing:border-box}.vf-quick-days-fallback{clear:both;padding:6px 0 0}
    @media(min-width:768px){.vf-quick-days:not(.vf-quick-days-fallback){margin-left:calc(-50% + 52px)}}
    .vf-quick-days button{min-width:28px;height:34px;padding:4px 6px;border:1px solid #a4b8cb;border-radius:4px;background:#fff;color:#18344e;font:600 14px Arial,sans-serif;cursor:pointer;box-sizing:border-box}.vf-quick-days button:hover{background:#e3edf5}.vf-quick-days button[aria-pressed=true]{background:#183e60;color:#fff;border-color:#183e60}.vf-quick-days button:focus-visible{outline:2px solid #236aab;outline-offset:2px}.vf-quick-days button:disabled{opacity:.55;cursor:default}
    .vf-download-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:6px 0 10px}.vf-download{border:1px solid #b8c9d9;border-radius:4px;background:#fff;color:#18344e;padding:7px 10px;font:13px Arial;cursor:pointer}.vf-download:disabled{opacity:.6;cursor:wait}.vf-download-status{font:12px Arial;color:#9a431f}
    .vf-chart-card{min-width:0}.vf-chart-card>.vf-download-actions{justify-content:flex-end;margin:6px 0 10px}.vf-download-status:empty{display:none}
    .vf-folder{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px;overflow-wrap:anywhere}.vf-folder button{font:inherit;padding:6px 8px;border:1px solid #b8c9d9;border-radius:4px;background:#fff;color:#18344e;cursor:pointer}.vf-folder button:disabled{opacity:.6;cursor:wait}.vf-folder [role=status]{color:#9a431f}
    .vf-view-controls{clear:both;padding:8px 2px;font:13px Arial,sans-serif}.vf-view-controls label{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.vf-view-controls select{max-width:100%;padding:6px 8px;border:1px solid #b8c9d9;border-radius:4px;background:#fff;color:#18344e}.vf-view-controls select:focus-visible{outline:2px solid #236aab;outline-offset:2px}
    .viena-fec-summary{clear:both;margin:2px 2px 10px;padding:16px;border:1px solid #b9cadc;border-top:4px solid #f99c2e;border-radius:6px;background:#f6f9fc;color:#18344e;font:14px/1.5 Arial,sans-serif;box-sizing:border-box}
    .viena-fec-summary *{box-sizing:border-box}.viena-fec-summary p{margin:7px 0}.vf-head{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.vf-head strong{font-size:18px}.vf-head button{border:1px solid #a4b8cb;border-radius:4px;background:#fff;color:#18344e;padding:7px 12px;cursor:pointer}.vf-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,330px),1fr));align-items:start;gap:10px;margin-top:12px}.vf-card{background:#fff;border:1px solid #cfdae5;border-radius:5px;padding:12px;min-width:0;overflow-wrap:anywhere}.vf-card h3{font:700 15px/1.4 Arial;margin:0 0 8px}.vf-alert{border-left:4px solid #c14d25}.vf-warning{color:#9a431f}.vf-note{font-size:12px;color:#526577}.vf-pattern{font-weight:600}.viena-fec-summary summary{cursor:pointer;padding:7px 0;font-weight:600}.vf-table{overflow-x:auto;max-width:100%}.vf-table table{border-collapse:collapse;width:100%;min-width:650px;font-size:12px;overflow-wrap:normal}.vf-table th,.vf-table td{padding:7px;text-align:left;border-bottom:1px solid #dce4ec;vertical-align:top}.vf-table th{white-space:nowrap}.viena-fec-summary button:focus-visible,.viena-fec-summary summary:focus-visible{outline:2px solid #236aab;outline-offset:2px}
    .viena-fec-summary .vf-selector{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;padding-top:12px;border-top:1px solid #d9e3ed}
    .viena-fec-summary .vf-choice{display:flex;align-items:center;gap:12px;padding:10px 17px;border:1px solid #b8c9d9;border-radius:6px;background:#fff;color:#18344e;font:600 14px Arial;cursor:pointer}
    .viena-fec-summary .vf-choice[aria-pressed=true]{background:#183e60;color:#fff;border-color:#183e60;box-shadow:0 2px 4px #183e6020}
    .viena-fec-summary .vf-choice span{background:#fff0df;color:#994317;border-radius:20px;padding:3px 7px;font:600 12px Arial}
    .viena-fec-summary .vf-choice[aria-pressed=true] span{background:#f99c2e;color:#172d40}
    .viena-fec-summary .vf-selector-note{font-size:12px;color:#596d80;margin:8px 0}
    .viena-fec-summary .vf-placeholder{padding:16px;border:1px dashed #bccddc;border-radius:5px;background:#fff;text-align:center;color:#536a7e;margin-top:10px}
    .viena-fec-summary .vf-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
    .viena-fec-summary .vf-graphs{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.viena-fec-summary .vf-chart{min-width:0;background:white}.viena-fec-summary .vf-tech{margin-top:14px}.viena-fec-summary .vf-grid:empty{display:none}.viena-fec-summary .vf-card{padding:14px}.viena-fec-summary .vf-card h3{font-size:16px}.viena-fec-summary .vf-table{max-height:270px;overflow:auto}
    @media(max-width:700px){.viena-fec-summary .vf-graphs{grid-template-columns:1fr!important}.viena-fec-summary .vf-grid{grid-template-columns:1fr}.viena-fec-summary .vf-choice{flex:1 1 40%;justify-content:space-between;padding:10px 12px}}
    @media(max-width:480px){.viena-fec-summary{padding:10px}.vf-head strong{font-size:16px}}
  `;document.head.append(style);
  // El AJAX nativo reemplaza todo el contenedor al filtrar: no hay polling global,
  // ni interceptación de requests, ni lectura/evaluación de scripts HTML.
  if(window.jQuery)window.jQuery(document).on('ajaxComplete.vienaFec',schedule);
  schedule();
  window.addEventListener('pagehide',()=>{ticketDirection=null;clearTimeout(timer);timer=0;for(const [root,state] of states){destroyCharts(state);root.setAttribute('data-viena-fec-fallback','');state.observer.disconnect();}states.clear();if(window.jQuery)window.jQuery(document).off('ajaxComplete.vienaFec',schedule);});
  window.addEventListener('pageshow',event=>{if(event.persisted){if(view!=='original')for(const root of document.querySelectorAll(ROOT))root.removeAttribute('data-viena-fec-fallback');if(window.jQuery)window.jQuery(document).on('ajaxComplete.vienaFec',schedule);schedule();}});
})();
