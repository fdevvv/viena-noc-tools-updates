(() => {
    'use strict';
    const token=location.hash.slice(1),MOICA='https://moica2.telecentro.net.ar',ONMSI='http://onmsi.telecentro.net.ar';
    if(parent===window||!/^[a-f0-9]{32}$/.test(token))return;
    const nonce=Array.from(crypto.getRandomValues(new Uint8Array(16)),v=>v.toString(16).padStart(2,'0')).join('');let frame,stopped=false;
    const send=(type,data={})=>chrome.runtime.sendMessage({type:'ONMSI_103_NATIVE_'+type,token,...data});
    const report=(state,message)=>parent.postMessage({type:'ONMSI_103_NATIVE_VIEWER',token,state,message},ONMSI);
    window.addEventListener('message',async e=>{
        const d=e.data;if(stopped||e.origin!==MOICA||e.source!==frame?.contentWindow||d?.nonce!==nonce)return;
        if(d.type==='ONMSI_NATIVE_HELLO'){frame.contentWindow.postMessage({type:'ONMSI_NATIVE_ACK',nonce},MOICA);return;}
        if(d.type==='ONMSI_NATIVE_READY'){report('ready');return;}
        if(d.type==='ONMSI_NATIVE_CLOSED'){report('closed');return;}
        if(d.type==='ONMSI_NATIVE_ERROR'){report('error',d.message);return;}
        if(d.type==='ONMSI_NATIVE_ABORT'){void send('ABORT',{id:d.id}).catch(()=>{});return;}
        if(d.type!=='ONMSI_NATIVE_HTTP')return;
        let result;try{const r=await send('HTTP',{request:d.request});result=r?.ok?r.data:{ok:false,message:r?.message||'MOICA no respondió.'};}catch{result={ok:false,message:'Se interrumpió la conexión con el visor.'};}
        if(!stopped)frame.contentWindow.postMessage({type:'ONMSI_NATIVE_RESPONSE',nonce,id:d.request?.id,result},MOICA);
    });
    window.addEventListener('pagehide',()=>{stopped=true;void send('END').catch(()=>{});},{once:true});
    void(async()=>{try{
        const r=await send('REGISTER');if(!r?.ok||!/^\d{6}FO\d+$/i.test(r.data?.ticket||''))throw Error(r?.message||'No se confirmó el ticket.');
        frame=document.createElement('iframe');frame.title='Ticket MOICA '+r.data.ticket;const u=new URL('/buscarTicket.php',MOICA);
        u.searchParams.set('vienaOnmsiNative','1');u.searchParams.set('vienaOnmsiNativeTicket',r.data.ticket);u.searchParams.set('vienaOnmsiNativeNonce',nonce);u.searchParams.set('vienaOnmsiNativeExtension',chrome.runtime.id);frame.src=u.href;document.body.append(frame);
    }catch(e){report('error',e.message||'No se pudo abrir MOICA.');}})();
})();
