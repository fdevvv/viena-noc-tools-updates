(() => {
    'use strict';
    const origin='http://onmsi.telecentro.net.ar',text=v=>String(v??'').replace(/\s+/g,' ').trim();
    // Bounded migration candidate, never a prefix search or an invented node.
    // The current target must exist; an old name may be absent from the catalog.
    // MIRA verifies existence, not equivalence between the two names.
    function aliases(name,base){
        const s=text(name).toUpperCase(),tech=n=>String(base?.get(n)||'').toUpperCase();
        if(/^[A-Z]{2}\d{2}[A-Z]$/.test(s)&&(!tech(s)||tech(s)==='LEGACY')&&tech(s+'A')==='VCCAP')return [s+'A'];
        if(/^[A-Z]{2}\d{2}[A-Z]A$/.test(s)&&tech(s)==='VCCAP'&&tech(s.slice(0,-1))==='LEGACY')return [s.slice(0,-1)];
        return [];
    }
    function scope(raw,base){
        const s=text(raw).toUpperCase(),names=[...new Set([...s.matchAll(/\[([A-Z0-9]{1,32})\]/g)].map(m=>m[1]))];
        const ftth=/^FTTH(?:[_\s-]|\[)/.test(s),hfc=/^(?:HFC|LEGACY|VCCAP|RPHY)/.test(s);
        if(!ftth&&!hfc)return {kind:'manual',nodes:[],message:'Enlace core, corporativo u Origin no reconocido: verificar manualmente.'};
        const nodes=names.map(name=>({name,technology:String(base?.get(name)||''),registered:(ftth?['GPON','FTTH']:['LEGACY','RPHY','VCCAP']).includes(String(base?.get(name)||'').toUpperCase())}));
        return {kind:ftth?'ftth':'hfc',nodes:ftth?nodes.filter(n=>n.registered):nodes.filter(n=>n.registered||/^[A-Z]{2}\d{2}[A-Z]{1,2}$/.test(n.name)),message:ftth?'Verificar manualmente el estado de los nodos FTTH en GPON. Se buscan tickets FO en MOICA; no se consulta MIRA5.':''};
    }
    function link(raw){try{const u=new URL(raw,origin);return u.origin===origin&&u.pathname==='/app.jsp'&&/^#link_dashboard\?id=\d+(?:&p=\d+)?$/.test(u.hash)?u.href:null;}catch{return null;}}
    function coordinates(raw){
        const m=String(raw||'').match(/(\d{1,2})[°º]\s*(\d{1,2})['′]\s*(\d+(?:\.\d+)?)["″]\s*([NS])\s+(\d{1,3})[°º]\s*(\d{1,2})['′]\s*(\d+(?:\.\d+)?)["″]\s*([EW])/i);if(!m)return null;
        const lat=(+m[1]+m[2]/60+m[3]/3600)*(m[4].toUpperCase()==='S'?-1:1),lon=(+m[5]+m[6]/60+m[7]/3600)*(m[8].toUpperCase()==='W'?-1:1);
        if(+m[2]>=60||+m[3]>=60||+m[6]>=60||+m[7]>=60||Math.abs(lat)>90||Math.abs(lon)>180)return null;
        return 'https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(lat+','+lon);
    }
    const fields=[['ID','id'],['Creation','creation'],['Origin','origin'],['Specific problem','specificProblem'],['Severity','severity'],['Description','description'],['GPS Coordinates','gps'],['Link','link']];
    function detail(doc,id){
        // History/viewer headers also use gwt-Label. A label in a TH must
        // never climb into an outer TD and become a second field value.
        const cell=e=>{const td=e.closest('td,th');return td?.tagName==='TD'&&td.nextElementSibling?.tagName==='TD'?td:null;};
        const read=key=>{const values=[...new Set([...doc.querySelectorAll('.gwt-Label')].filter(e=>text(e.textContent)===key&&cell(e)).map(e=>text(cell(e).nextElementSibling.textContent)).filter(Boolean))];return values.length===1?values[0]:'';};
        if(read('ID')!==id)return null;const a=Object.fromEntries(fields.map(([label,key])=>[key,read(label)]));
        const label=[...doc.querySelectorAll('.gwt-Label')].find(e=>text(e.textContent)==='Link');a.link=link(label?.closest('td')?.nextElementSibling?.querySelector('a')?.getAttribute('href'))||'';
        return a.origin&&a.creation&&a.description?a:null;
    }
    function rows(doc){return [...doc.querySelectorAll('a[href*="#alarm_detail?id="]')].flatMap(a=>{try{const u=new URL(a.getAttribute('href'),origin),id=u.hash.match(/^#alarm_detail\?id=(\d+)$/)?.[1],row=a.closest('tr');return u.origin===origin&&id&&row?.querySelector('a[href*="#link_dashboard?id="]')?[{id,row}]:[];}catch{return [];}});}
    const nodeText=raw=>[...new Set([...String(raw||'').toUpperCase().matchAll(/\[([A-Z0-9]{1,32})\]/g)].map(m=>m[1]))].join(', ')||String(raw||'');
    function copy(a){return 'Información de alarma ONMSi\n'+fields.map(([label,key])=>(key==='origin'?'Nodos':label)+': '+(a[key]||(key==='gps'?'No se informan coordenadas':'No informado'))).join('\n')+(coordinates(a.gps)?'\nGoogle Maps: '+coordinates(a.gps):'');}
    function proposal(reads){return reads.length&&reads.every(r=>r.complete&&!r.relationPending&&r.branches?.length)?reads.some(r=>r.branches.some(b=>b.up<10))?'VXC':'VAO':'';}
    const task=(number,status)=>/^\d{6}(?:VAO|VXC|VXA)\d+$/i.test(number)&&['INICIADA','AGENDADA','EN CURSO','SUSPENDIDA','COMPLETADA','ABIERTO','ABIERTA'].includes(String(status).toUpperCase());
    const api={scope,aliases,link,coordinates,detail,rows,copy,proposal,task,fields,nodeText};if(typeof module==='object')module.exports=api;else globalThis.VienaOnmsi=api;
})();
