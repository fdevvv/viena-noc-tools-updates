(function () {
  'use strict';
  const KEY = 'viena_edificio_fallas_templates_v1';
  const motionAnimations = new WeakMap();
  function captureMotion(host, selector, attribute) {
    const before = new Map(), reduced = globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    for (const row of host.querySelectorAll(selector)) {
      if (!reduced) before.set(row.getAttribute(attribute), row.getBoundingClientRect());
      motionAnimations.get(row)?.cancel();motionAnimations.delete(row);
    }
    return () => {
      if (reduced || globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
      for (const row of host.querySelectorAll(selector)) {
        const old = before.get(row.getAttribute(attribute));if (!old || typeof row.animate !== 'function') continue;
        const next = row.getBoundingClientRect(), x = old.left - next.left, y = old.top - next.top;
        if (Math.abs(x) < .5 && Math.abs(y) < .5) continue;
        motionAnimations.set(row, row.animate([{ transform: `translate(${x}px,${y}px)` }, { transform: 'translate(0,0)' }], { duration: 180, easing: 'ease-out' }));
      }
    };
  }
  const clean = value => String(value ?? '').replace(/\s+/g, ' ').trim();
  function defaults() {
    return [
      { id: 'post-fec-ds', text: 'Se verifica conteo POST FEC DS', options: ['QAM', 'OFDM'] },
      { id: 'pwr-ds', text: 'Se verifican niveles de PWR DS', options: ['Bajos', 'Fuera de rango'] },
      { id: 'caida-cms', text: 'Se verifica caída parcial de CMs', options: [] }
    ];
  }
  function normalize(items) {
    if (!Array.isArray(items) || items.length > 100) throw Error('Biblioteca de templates inválida (máximo 100).');
    const seen = new Set();
    return items.map(item => {
      if (!item || typeof item.id !== 'string' || !item.id || seen.has(item.id)) throw Error('Identificador de template inválido o repetido.');
      seen.add(item.id);
      if (typeof item.text !== 'string') throw Error('Texto de template inválido.');
      const text = clean(item.text);
      if (!text || text.length > 240) throw Error('Completá el texto de la falla (máximo 240 caracteres).');
      if (!Array.isArray(item.options) || item.options.length > 80 || item.options.some(option => typeof option !== 'string')) throw Error('Opciones inválidas (máximo 80).');
      const options = [...new Set(item.options.map(clean).filter(Boolean))];
      if (options.some(option => option.length > 120)) throw Error('Cada opción admite hasta 120 caracteres.');
      return { id: item.id, text, options };
    });
  }
  function line(template, options = []) {
    const text = template.text.replace(/[.:;\s]+$/, '');
    return text + (options.length ? ' ' + options.join(', ') : '') + '.';
  }
  function message(datos, failure) {
    const lines = String(failure || '').trim().split('\n').map(text => text.trim() && !/^\s*-\s/.test(text) ? '- ' + text : text).join('\n');
    return `ID EDIFICIO: ${datos.idEdificio}\nNODO CMTS: ${datos.nodoCmts}\nDIRECCION: ${datos.direccion}\nFALLA DETECTADA:\n${lines}`;
  }
  // Only replace a line we own verbatim; a manually changed or ambiguous line stays intact.
  function updateFailure(value, previous, next) {
    if (!previous) return next ? (value ? value.replace(/\n?$/, '\n') : '') + next : value;
    const lines = value.split('\n'), indexes = lines.flatMap((text, i) => text === previous ? [i] : []);
    if (indexes.length !== 1) return null;
    if (next) lines[indexes[0]] = next; else lines.splice(indexes[0], 1);
    return lines.join('\n');
  }
  async function read() {
    const stored = await chrome.storage.local.get([KEY]);
    if (!Object.prototype.hasOwnProperty.call(stored, KEY)) return { templates: defaults(), revision: null };
    const payload = stored[KEY];
    if (payload?.schema !== 1) throw Error('No se pudo leer la biblioteca de edificio. Tus datos se conservan.');
    const templates = normalize(payload.templates);
    return { templates, revision: JSON.stringify({ schema: 1, templates }) };
  }
  function ensureStyle() {
    if (document.getElementById('viena-building-template-style')) return;
    const style = document.createElement('style');style.id = 'viena-building-template-style';
    style.textContent = `
      .viena-building{--building-accent:#ed9900;--building-ink:#333;--building-surface:#fff;--building-soft:#fff7e9;--building-border:#efc985;color:var(--building-ink);font:14px Arial,sans-serif;color-scheme:light}
      .viena-building *{box-sizing:border-box}.viena-building [hidden]{display:none!important}
      .viena-building-card{width:min(760px,100%);max-height:calc(100dvh - 24px);overflow:auto;background:var(--building-surface);border:1px solid var(--building-border);border-radius:8px;box-shadow:0 12px 38px #0004}
      .viena-building-header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 18px;background:var(--building-accent);color:#251900;font-size:19px;font-weight:700}
      .viena-building-header button{border:0;background:transparent;color:inherit;font-size:24px;cursor:pointer}
      .viena-building-body{padding:16px 18px}.viena-building-data{display:grid;grid-template-columns:1fr 1fr 1.5fr;gap:16px;margin-bottom:16px;overflow-wrap:anywhere}.viena-building-data b{display:block;margin-top:5px;font-size:16px}
      .viena-building-block{border:1px solid var(--building-border);border-radius:6px;overflow:hidden;margin:12px 0;background:var(--building-surface)}
      .viena-building-block>summary,.viena-building-label{display:block;padding:11px 14px;background:var(--building-soft);font-size:16px;font-weight:700;margin:0;color:var(--building-ink)}
      .viena-building-block>summary{cursor:pointer;list-style:revert}.viena-building-block-body{padding:12px 14px}
      .viena-building textarea,.viena-building input[type=text]{width:100%;min-width:0;max-width:100%;border:1px solid #bfc6ce;border-radius:5px;background:var(--building-surface);color:var(--building-ink);padding:9px;font:14px Arial,sans-serif;resize:vertical;line-height:1.5}
      .viena-building input[type=checkbox]{accent-color:#b66b00;width:18px;height:18px;flex-shrink:0;margin:0}
      .viena-building button:focus-visible,.viena-building input:focus-visible,.viena-building textarea:focus-visible,.viena-building summary:focus-visible{outline:2px solid #a85b00;outline-offset:3px}
      .viena-building-choice{display:grid;grid-template-columns:minmax(170px,1fr) minmax(0,1.1fr);gap:12px;padding:7px 0;align-items:start}.viena-building-choice label,.viena-building-options label{display:flex;gap:9px;align-items:center;margin:0;cursor:pointer;color:var(--building-ink);font-size:14px;overflow-wrap:anywhere}
      .viena-building-options{display:flex;gap:8px;flex-wrap:wrap}.viena-building-options label{padding:6px 9px;background:var(--building-soft);border-radius:5px}
      .viena-building-button{border:1px solid #bd7a00;border-radius:5px;padding:9px 13px;background:var(--building-accent);color:#251900;cursor:pointer;font:700 14px Arial,sans-serif}
      .viena-building-button.secondary{background:var(--building-surface);color:#a85b00}.viena-building-button.danger{background:var(--building-surface);color:#b92218;border-color:#dc827b}.viena-building button:disabled{opacity:.55;cursor:wait}
      .viena-building-actions{display:flex;gap:9px;flex-wrap:wrap;justify-content:flex-end;margin-top:12px}.viena-building-link{border:0;background:transparent;color:#a85b00;text-decoration:underline;cursor:pointer;font:14px Arial;padding:10px 0}
      .viena-building-preview{white-space:pre-wrap;overflow-wrap:anywhere;margin:0;background:var(--building-soft);border:1px solid var(--building-border);border-radius:5px;padding:12px;color:var(--building-ink);font:14px/1.6 Arial,sans-serif}
      .viena-building-note{font-size:13px;color:#666;margin:10px 0}.viena-building-status{min-height:20px;font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere}.viena-building-status.error{color:#b92218}
      .viena-building-editor{padding:16px;background:var(--building-surface);border:1px solid var(--building-border);border-radius:8px}.viena-building-editor label{display:block;color:var(--building-ink);font-size:14px;margin:10px 0}.viena-building-editor label input,.viena-building-editor label textarea{display:block;margin-top:7px}.viena-building-editor-row{border:1px solid var(--building-border);border-radius:6px;padding:14px;margin:12px 0}.viena-building-editor h2{color:var(--building-ink);margin:0;font-size:20px}
      .viena-building-card .viena-building-header{padding:7px 16px;font-size:17px}.viena-building-card .viena-building-body{padding:7px 16px}.viena-building-card .viena-building-data{margin-bottom:9px;gap:12px}.viena-building-card .viena-building-block{margin:8px 0}
      .viena-building-card .viena-building-block>summary,.viena-building-card .viena-building-label{padding:6px 11px;font-size:15px}.viena-building-card .viena-building-block-body{padding:6px 11px}.viena-building-card .viena-building-choice{padding:5px 0;gap:9px}.viena-building-card .viena-building-options label{padding:4px 8px}.viena-building-card textarea{padding:7px;font:13px/1.4 Arial,sans-serif}
      .viena-building-card .viena-building-link{padding:7px 0}.viena-building-card .viena-building-preview{padding:8px 10px;font:13px/1.4 Arial,sans-serif}.viena-building-card .viena-building-note{margin:6px 0;font-size:12px}.viena-building-card .viena-building-status:empty{display:none}.viena-building-card .viena-building-actions{margin-top:8px}
      .viena-building-editor-top{display:flex;justify-content:flex-end;margin:10px 0}
      .viena-building-editor-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,350px),400px));gap:12px;align-items:stretch}
      .viena-building-editor-grid .viena-building-editor-row{min-width:0;margin:0;display:flex;flex-direction:column}
      .viena-building-editor-grid .viena-building-actions{margin-top:auto;padding-top:8px}
      .viena-building-drag{align-self:flex-end;border:1px solid var(--building-border);border-radius:4px;background:var(--building-soft);color:var(--building-ink);padding:4px 8px;font:13px Arial;cursor:grab}
      .viena-building-drag:active{cursor:grabbing}.viena-building-drag:focus-visible{outline:2px solid #a85b00;outline-offset:3px}.viena-building-editor-row.dragging{opacity:.6}.viena-building-editor-row.drop-before{box-shadow:inset 4px 0 var(--building-accent)}.viena-building-editor-row.drop-after{box-shadow:inset -4px 0 var(--building-accent)}
      .viena-building-editor-preview{margin:4px 0 0;border:1px solid var(--building-border);border-radius:6px;padding:10px;background:var(--building-soft)}
      .viena-building-editor-preview-title{font:700 13px Arial,sans-serif;color:#a85b00;margin-bottom:7px}
      .viena-building-editor-preview pre{margin:0;white-space:pre-wrap;overflow-wrap:anywhere;font:13px/1.5 Arial,sans-serif;color:var(--building-ink)}
      html[data-viena-theme=dark] .viena-building-editor-preview-title{color:#ffc466}
      .viena-building-manage-actions{display:flex;justify-content:flex-end;margin-top:8px;padding-top:5px;border-top:1px solid var(--building-border)}
      .viena-building-manage-actions .viena-building-button{padding:4px 10px;font-size:13px;line-height:1.2;text-decoration:none}
      .viena-building-manage-actions .viena-building-button:hover{background:var(--building-soft)}
      .viena-building-preview-head{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}.viena-building-card .viena-building-preview-head{padding:3px 11px}.viena-building-preview-head .viena-building-button{padding:3px 10px;font-size:13px;line-height:1.2}
      [data-section=building-templates].active{box-shadow:inset 3px 0 #ed9900!important;background:#704800!important}
      html[data-viena-theme=dark] .viena-building{--building-ink:#f2ece1;--building-surface:#24282d;--building-soft:#393124;--building-border:#78603a;color-scheme:dark}
      html[data-viena-theme=dark] .viena-building-note{color:#c2bbb1}html[data-viena-theme=dark] .viena-building-link,html[data-viena-theme=dark] .viena-building-button.secondary{color:#ffc466}html[data-viena-theme=dark] .viena-building-status.error{color:#ffaaa0}
      .viena-building-editor{--building-accent:#f99c2e}
      html[data-viena-theme=dark] .viena-building-editor{--building-surface:#131619;--building-soft:#221b10;--building-border:#f99c2e}
      html[data-viena-theme=dark] .viena-building-editor .viena-building-button.secondary,html[data-viena-theme=dark] .viena-building-editor-preview-title{color:#f99c2e}
      [data-section=building-templates].active,[data-section=cuadras-templates].active{box-shadow:inset 3px 0 #f99c2e!important;background:#704800!important}
      .viena-building-editor-test{margin:8px 0}.viena-building-editor-test-title{font-weight:700;margin-bottom:8px}
      .viena-building-editor-test .viena-building-options{flex-direction:column;align-items:flex-start}
      .viena-building-editor-test .viena-building-options label{display:flex;margin:0;background:transparent;padding:4px 0}
      .viena-building-editor-test input[type=checkbox]{accent-color:var(--building-accent)}
      .viena-building-editor-grid .viena-building-editor-row{display:grid;grid-template-rows:subgrid;grid-row:span 7;row-gap:0}
      .viena-building-editor-grid .viena-building-actions{grid-row:7;align-self:end;margin-top:0}
      .viena-building-editor-grid .viena-building-drag{justify-self:end;align-self:start}
      .viena-building-editor-test .viena-building-options{max-height:216px;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;flex-wrap:nowrap}
      .viena-building-editor-test .viena-building-options label{flex-shrink:0;max-width:100%;justify-content:flex-start}
      .viena-building-editor-test input[type=checkbox]{flex:0 0 18px;width:18px;min-width:18px;max-width:18px;margin:0}
      @media(max-width:540px){.viena-building-body{padding:12px}.viena-building-data{grid-template-columns:1fr;gap:9px}.viena-building-choice{grid-template-columns:1fr}.viena-building-header{font-size:17px;padding:13px}.viena-building-editor{padding:12px}.viena-building-editor-row{padding:10px}}
    `;document.head.appendChild(style);
  }
  function create(tag, text, className) {
    const element = document.createElement(tag);
    if (text !== undefined) element.textContent = text;
    if (className) element.className = className;
    return element;
  }
  function button(text, action, className = '') {
    const element = create('button', text, 'viena-building-button ' + className);element.type = 'button';element.addEventListener('click', action);return element;
  }
  function attachModal(overlay, datos, { close, notify }) {
    ensureStyle();
    overlay.style.padding = '12px';
    const card = overlay.firstElementChild;card.className = 'viena-building viena-building-card';card.removeAttribute('style');
    const header = card.firstElementChild;header.className = 'viena-building-header';header.removeAttribute('style');
    header.append(button('×', close));header.lastElementChild.setAttribute('aria-label', 'Cerrar');
    card.setAttribute('role', 'dialog');card.setAttribute('aria-modal', 'true');card.setAttribute('aria-label', 'Copiar datos del edificio');
    const body = header.nextElementSibling;body.className = 'viena-building-body';body.removeAttribute('style');
    const info = body.firstElementChild;info.className = 'viena-building-data';info.removeAttribute('style');info.replaceChildren();
    for (const [label, value] of [['ID edificio:', datos.idEdificio], ['Nodo CMTS:', datos.nodoCmts], ['Dirección:', datos.direccion]]) {
      const field = create('div', label);field.append(create('b', value));info.append(field);
    }
    const failure = overlay.querySelector('#viena-falla-edificio');failure.className = '';failure.removeAttribute('style');failure.rows = 3;
    const label = overlay.querySelector('label[for=viena-falla-edificio]');label.removeAttribute('style');label.className = 'viena-building-label';
    const block = create('div', undefined, 'viena-building-block'), blockBody = create('div', undefined, 'viena-building-block-body');
    info.after(block);block.append(label, blockBody);blockBody.append(failure);
    const details = create('details', undefined, 'viena-building-block');details.open = true;
    details.append(create('summary', 'Seleccionar templates'));
    const choiceBody = create('div', undefined, 'viena-building-block-body'), choices = create('div'), status = create('div', '', 'viena-building-status');status.setAttribute('role', 'status');
    const manage = button('Administrar templates', () => chrome.runtime.sendMessage({ type: 'VIENA_BUILDING_TEMPLATES_OPEN' }).then(response => {
      if (!response?.ok) throw Error('No se pudo abrir el editor.');
    }).catch(error => { status.textContent = error.message;status.classList.add('error'); }), 'secondary');
    const manageActions = create('div', undefined, 'viena-building-manage-actions');manageActions.append(manage);
    choiceBody.append(choices, status, manageActions);details.append(choiceBody);block.before(details);
    const previewBlock = create('div', undefined, 'viena-building-block'), preview = create('pre', '', 'viena-building-preview');preview.dataset.vienaBuildingPreview = '';
    const previewBody = create('div', undefined, 'viena-building-block-body');previewBody.append(preview, create('p', 'Podés escribir o editar la falla antes de copiar.', 'viena-building-note'));
    previewBlock.append(create('div', 'Vista previa del mensaje', 'viena-building-label'), previewBody);block.after(previewBlock);
    const error = overlay.querySelector('#viena-edif-error');error.removeAttribute('style');error.className = 'viena-building-status error';error.setAttribute('role', 'alert');
    const copy = overlay.querySelector('[data-viena-copiar]'), cancel = overlay.querySelector('[data-viena-cancelar]');
    copy.className = 'viena-building-button';cancel.className = 'viena-building-button secondary';copy.parentElement.className = 'viena-building-actions';copy.parentElement.removeAttribute('style');
    const previewHead = previewBlock.firstElementChild;previewHead.classList.add('viena-building-preview-head');previewHead.append(copy);
    const updatePreview = () => {preview.textContent = message(datos, failure.value);};
    failure.addEventListener('input', updatePreview);updatePreview();
    let selected = new Map(), version = 0;
    function change(template, options, enabled) {
      const previous = selected.get(template.id)?.line || '', next = enabled ? line(template, options) : '';
      const value = updateFailure(failure.value, previous, next);
      if (value === null) {status.textContent = 'La falla fue editada. Conservamos tu texto; modificá esa línea directamente.';return false;}
      failure.value = value;failure.dispatchEvent(new Event('input', { bubbles: true }));
      if (enabled) selected.set(template.id, { line: next, options });else selected.delete(template.id);
      status.textContent = '';return true;
    }
    async function refresh() {
      const current = ++version;
      try {
        const { templates } = await read();if (!overlay.isConnected || current !== version) return;
        for (const [id, state] of selected) {
          const template = templates.find(t => t.id === id), options = state.options.filter(o => template?.options.includes(o)), next = template ? line(template, options) : '';
          const value = updateFailure(failure.value, state.line, next);
          if (value !== null) {failure.value = value;if (template) selected.set(id, { line: next, options });else selected.delete(id);}
        }
        updatePreview();choices.replaceChildren();
        if (!templates.length) choices.append(create('p', 'No hay templates guardados. Podés escribir la falla o crear uno.', 'viena-building-note'));
        for (const template of templates) {
          const row = create('div', undefined, 'viena-building-choice'), label = create('label'), check = create('input');check.type = 'checkbox';check.checked = selected.has(template.id);check.dataset.buildingTemplate = template.id;
          label.append(check, create('span', template.text));row.append(label);
          const opts = create('div', undefined, 'viena-building-options');row.append(opts);
          const optionInputs = template.options.map(option => {
            const label = create('label'), input = create('input');input.type = 'checkbox';input.checked = Boolean(selected.get(template.id)?.options.includes(option));input.dataset.buildingOption = option;
            label.append(input, create('span', option));opts.append(label);
            input.addEventListener('change', () => {
              const enabled = check.checked || input.checked;
              if (change(template, optionInputs.filter(i => i.checked).map(i => i.dataset.buildingOption), enabled)) check.checked = enabled;else input.checked = !input.checked;
            });return input;
          });
          check.addEventListener('change', () => {
            if (change(template, check.checked ? optionInputs.filter(i => i.checked).map(i => i.dataset.buildingOption) : [], check.checked)) {
              if (!check.checked) optionInputs.forEach(i => {i.checked = false;});
            } else check.checked = !check.checked;
          });choices.append(row);
        }
        status.classList.remove('error');
      } catch (_) {if (overlay.isConnected && current === version) {status.textContent = 'No se pudieron cargar los templates. Podés escribir y copiar la falla.';status.classList.add('error');choices.replaceChildren(button('Reintentar', refresh, 'secondary'));}}
    }
    const changed = (changes, area) => {if (area === 'local' && changes[KEY]) void refresh();};
    chrome.storage.onChanged.addListener(changed);
    overlay.vienaBuildingCleanup = () => {version++;chrome.storage.onChanged.removeListener(changed);};
    void refresh();
    // Keep keyboard focus inside the dialog, without global listeners or background polling.
    overlay.addEventListener('keydown', event => {
      if (event.key !== 'Tab') return;
      const focusable = [...overlay.querySelectorAll('button,input,textarea,summary')].filter(e => !e.disabled && e.getClientRects().length);
      const first = focusable[0], last = focusable.at(-1);
      if (event.shiftKey && document.activeElement === first) {event.preventDefault();last?.focus();}
      else if (!event.shiftKey && document.activeElement === last) {event.preventDefault();first?.focus();}
    });
  }
  function initHome({ confirm, notify }, config = {}) {
    const section = config.section || 'building-templates', title = config.title || 'Templates de edificio';
    const normalizeEntries = config.normalize || normalize, readLibrary = config.read || read, previewLine = config.line || line;
    if (document.querySelector('[data-view=' + section + ']')) return;
    ensureStyle();
    const nav = button(title, () => {});nav.className = 'nav-item';nav.dataset.section = section;nav.prepend(create('span', '▤'));nav.setAttribute('aria-label', title);
    document.querySelector('[data-section=' + (config.navAfter || 'personalization') + ']').after(nav);
    const view = create('section');view.className = 'view';view.dataset.view = section;
    const editor = create('div', undefined, 'viena-building viena-building-editor');view.append(editor);
    const heading = create('div', title, 'viena-building-header');editor.append(heading, create('p', config.description || 'Biblioteca independiente de Cuadras. Configurá el texto de la falla y sus opciones.', 'viena-building-note'));
    const list = create('div', undefined, 'viena-building-editor-grid'), status = create('div', '', 'viena-building-status');status.setAttribute('role', 'status');
    const actions = create('div', undefined, 'viena-building-actions');editor.append(list, status, actions);document.querySelector('main.content').append(view);
    let library = [], revision = null, ready = false, saving = false, loading = false, rows = [];
    let dragging = null;
    const clearDrag = () => {dragging = null;rows.forEach(r => r.box.classList.remove('dragging', 'drop-before', 'drop-after'));};
    const message = (text, error = false) => {status.textContent = text;status.classList.toggle('error', error);};
    function capture(row) {
      return normalizeEntries([{ id: row.id, text: row.text.value, options: row.options.value.split('\n').filter(o => o.trim()) }])[0];
    }
    function dirty() {
      if (!ready) return false;
      try {return JSON.stringify(rows.map(capture)) !== JSON.stringify(library);} catch (_) {return true;}
    }
    async function persist(next, after) {
      if (saving || loading || !ready) return;
      saving = true;const controls = [...editor.querySelectorAll('button,input,textarea')];controls.forEach(e => {e.disabled = true;});
      try {
        const actual = await readLibrary();if (actual.revision !== revision) throw Error('La biblioteca cambió en otra ventana. Conservamos tus borradores; recargá la biblioteca antes de guardar.');
        const payload = { schema: 1, templates: normalizeEntries(next) };
        const written = config.write ? await config.write(payload.templates) : await chrome.storage.local.set({ [KEY]: payload });
        library = payload.templates;revision = config.write ? written.revision : JSON.stringify(payload);after?.();message('Templates guardados.');notify(title + ' guardados.', 'success');
      } catch (error) {message(error.message || 'No se pudo guardar. Tus borradores se conservan.', true);}
      finally {saving = false;controls.forEach(e => {e.disabled = false;});}
    }
    function addRow(template) {
      const row = { id: template.id }, box = create('div', undefined, 'viena-building-editor-row');row.box = box;box.dataset.buildingRow = row.id;
      const drag = create('div', '⠿ Arrastrar', 'viena-building-drag');drag.tabIndex = 0;drag.setAttribute('role', 'button');drag.draggable = true;drag.dataset.buildingDrag = '';drag.setAttribute('aria-label', 'Mover template; usá flechas izquierda o derecha para ordenar');
      const move = (target, after) => {
        if (!ready || saving || loading || !dragging || dragging === target || !rows.includes(dragging) || !rows.includes(target)) return;
        const finishMotion = captureMotion(list, '[data-building-row]', 'data-building-row');
        const moved = dragging;rows = rows.filter(r => r !== moved);rows.splice(rows.indexOf(target) + (after ? 1 : 0), 0, moved);
        list.insertBefore(moved.box, after ? target.box.nextSibling : target.box);message('Orden modificado. Pulsá Guardar todo para conservarlo.');
        finishMotion();
      };
      drag.addEventListener('dragstart', event => {if (!ready || saving || loading) {event.preventDefault();return;}clearDrag();dragging = row;box.classList.add('dragging');event.dataTransfer.setData('text/plain', row.id);event.dataTransfer.effectAllowed = 'move';});
      drag.addEventListener('dragend', clearDrag);
      box.addEventListener('dragover', event => {if (!dragging || saving || loading || dragging === row) return;event.preventDefault();event.dataTransfer.dropEffect = 'move';const after = event.clientX >= box.getBoundingClientRect().left + box.clientWidth / 2;rows.forEach(r => r.box.classList.remove('drop-before', 'drop-after'));box.classList.add(after ? 'drop-after' : 'drop-before');});
      box.addEventListener('dragleave', event => {if (!box.contains(event.relatedTarget)) box.classList.remove('drop-before', 'drop-after');});
      box.addEventListener('drop', event => {if (!dragging) return;event.preventDefault();move(row, event.clientX >= box.getBoundingClientRect().left + box.clientWidth / 2);clearDrag();});
      drag.addEventListener('keydown', event => {if (!['ArrowLeft','ArrowRight'].includes(event.key) || saving || loading) return;const target = rows[rows.indexOf(row) + (event.key === 'ArrowLeft' ? -1 : 1)];if (!target) return;event.preventDefault();dragging = row;move(target, event.key === 'ArrowRight');clearDrag();drag.focus();});
      const nameLabel = create('label', 'Nombre / texto de la falla'), optionLabel = create('label', 'Opciones · una por línea');
      row.text = create('input');row.text.type = 'text';row.text.maxLength = 240;row.text.value = template.text;
      row.options = create('textarea');row.options.rows = 3;row.options.value = template.options.join('\n');nameLabel.append(row.text);optionLabel.append(row.options);
      const previewBox = create('div', undefined, 'viena-building-editor-preview'), preview = create('pre'), previewNote = create('p', '', 'viena-building-note');preview.dataset.buildingRowPreview = '';
      const testOptions = create('div', undefined, 'viena-building-editor-test'), optionChecks = create('div', undefined, 'viena-building-options');
      testOptions.append(create('div', 'Probar opciones', 'viena-building-editor-test-title'), optionChecks);
      const selected = new Set(template.options);
      previewBox.append(create('div', 'Vista previa', 'viena-building-editor-preview-title'), preview);
      const updatePreview = () => {
        try {const entry = capture(row), options = entry.options.filter(option => selected.has(option));preview.textContent = config.preview ? config.preview({ ...entry, options }) : 'FALLA DETECTADA:\n- ' + previewLine(entry, options);previewNote.textContent = entry.options.length ? 'Marcá opciones para probar la vista previa. Las selecciones de prueba no modifican el template.' : '';}
        catch (error) {preview.textContent = error.message;previewNote.textContent = '';}
      };
      const refreshChecks = () => {
        const options = [...new Set(row.options.value.split('\n').map(clean).filter(Boolean))];
        testOptions.firstElementChild.hidden = !options.length;
        for (const option of selected) if (!options.includes(option)) selected.delete(option);
        optionChecks.replaceChildren();
        for (const option of options) {
          const label = create('label'), input = create('input');input.type = 'checkbox';input.checked = selected.has(option);input.dataset.buildingPreviewOption = option;
          label.append(input, create('span', option));optionChecks.append(label);
          input.addEventListener('change', () => {if (input.checked) selected.add(option);else selected.delete(option);updatePreview();});
        }
        if (!options.length) optionChecks.append(create('p', 'Este template no tiene opciones adicionales.', 'viena-building-note'));
        updatePreview();
      };
      row.text.addEventListener('input', updatePreview);row.options.addEventListener('input', refreshChecks);refreshChecks();
      const buttons = create('div', undefined, 'viena-building-actions');
      buttons.append(button('Guardar', () => {
        if (saving || loading) return;
        try {const entry = capture(row), next = library.map(t => t.id === row.id ? entry : t);if (!library.some(t => t.id === row.id)) next.push(entry);void persist(next);} catch (error) {message(error.message, true);}
      }), button('Eliminar', async () => {
        if (saving || loading) return;
        const accepted = await confirm({ title: 'Eliminar template', message: config.deleteMessage || 'Se quitará este template de la biblioteca de edificio.', confirmLabel: 'Eliminar' });
        if (!accepted || saving || loading || !rows.includes(row)) return;
        const remove = () => {rows = rows.filter(r => r !== row);box.remove();};
        if (library.some(t => t.id === row.id)) await persist(library.filter(t => t.id !== row.id), remove);else remove();
      }, 'danger'));
      box.append(drag, nameLabel, optionLabel, testOptions, previewBox, previewNote, buttons);list.append(box);rows.push(row);return row;
    }
    async function load() {
      if (saving || loading) return;
      if (dirty() && !await confirm({ title: 'Recargar biblioteca', message: 'Se descartarán los cambios sin guardar de este editor.', confirmLabel: 'Recargar' })) return;
      if (saving || loading) return;
      loading = true;editor.querySelectorAll('button,input,textarea').forEach(e => {e.disabled = true;});
      message('Cargando templates…');
      try {const result = await readLibrary();library = result.templates;revision = result.revision;rows = [];list.replaceChildren();library.forEach(addRow);ready = true;message('');}
      catch (_) {if (!rows.length) ready = false;message('No se pudo leer la biblioteca. Reintentá; tus datos y borradores se conservan.', true);}
      finally {loading = false;editor.querySelectorAll('button,input,textarea').forEach(e => {e.disabled = false;});}
    }
    const topActions = create('div', undefined, 'viena-building-editor-top');list.before(topActions);
    topActions.append(button('Nuevo template', () => {
      if (!ready || saving || loading) return;
      if (rows.length >= (config.maxTemplates ?? 100)) {message('La biblioteca admite hasta 100 templates.', true);return;}
      addRow({ id: crypto.randomUUID(), text: '', options: [] }).text.focus();
    }, 'secondary'));
    actions.append(button('Guardar todo', () => {
      if (!ready || saving || loading) return;
      try {void persist(rows.map(capture));} catch (error) {message(error.message, true);}
    }), button('Recargar biblioteca', load, 'secondary'));
    window.addEventListener('beforeunload', event => {if (dirty() || saving) {event.preventDefault();event.returnValue = '';}});
    void load();
  }
  globalThis.VienaBuildingTemplates = Object.freeze({ defaults, normalize, line, message, updateFailure, read, attachModal, initHome, captureMotion });
})();
