(function(root){
  'use strict';
  const KEY='viena_cws_migration_v1';
  // Live bridge messages belong to the running installation, never to its preferences.
  const signals=new Set(['VIENA_NOC_BRIDGE_COMMAND','VIENA_NOC_BRIDGE_LAST_PROCESSED','VIENA_NOC_BRIDGE_RESPONSE','VIENA_NOC_BRIDGE_HEARTBEAT_STATS','VIENA_NOC_BRIDGE_HEARTBEAT_EDIFICIO','VIENA_NOC_BRIDGE_HEARTBEAT_GPON','VIENA_NOC_BRIDGE_PING','VIENA_NOC_BRIDGE_PONG','VIENA_FUENTES_HEARTBEAT','VIENA_FUENTES_PING','VIENA_FUENTES_PONG','VIENA_MOICA_PING','VIENA_MOICA_PONG','VIENA_MOICA_ORDEN']);
  const preferences=snapshot=>Object.fromEntries(['local','sync'].map(area=>[area,Object.fromEntries(Object.entries(snapshot[area]).filter(([key])=>!signals.has(key)))]));
  function create(chrome,transfer){
    let pending=null;
    const eligible=item=>item&&item.id!==chrome.runtime.id&&item.type==='extension'&&item.installType==='development'&&['VIENA NOC Tools','VIENA NOC Tools DEV'].includes(item.name);
    const bounded=async operation=>{let timer;try{return await Promise.race([operation,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('La instalación original no respondió. Reintentá sin desinstalarla.')),6000);})]);}finally{clearTimeout(timer);}};
    async function probe(item){
      if(!eligible(item)||!item.enabled)return null;
      try{const value=await bounded(chrome.runtime.sendMessage(item.id,{type:'VIENA_CWS_PROBE'}));return value?.protocol===1&&value.sourceId===item.id&&value.name===item.name&&value.version===item.version?item:null;}catch(_){return null;}
    }
    async function discover(){
      const items=await chrome.management.getAll();
      return (await Promise.all(items.filter(eligible).map(probe))).filter(Boolean);
    }
    async function finish(marker){
      if(marker.status==='complete')return marker;
      // Recheck the chosen origin. Never disable an unrelated installation or uninstall anything.
      const item=await chrome.management.get(marker.sourceId);
      if(!eligible(item))throw Error('La instalación original cambió. Conservá ambas instalaciones y revisá su estado.');
      if(item.enabled){if(!item.mayDisable)throw Error('La configuración ya fue importada. Desactivá manualmente la instalación original.');await chrome.management.setEnabled(item.id,false);}
      const complete={...marker,status:'complete'};await chrome.storage.local.set({[KEY]:complete});return complete;
    }
    async function recover(marker){
      if(marker.status!=='pending')return finish(marker);
      const backup={...transfer.validate(marker.backup),...preferences(marker.backup)};
      transfer.validate({format:'VIENA_NOC_INSTALLATION',schema:1,...marker.before});
      const before=preferences(marker.before);
      const matches=await Promise.all(['local','sync'].map(async area=>transfer.equal(await chrome.storage[area].get(Object.keys(backup[area])),backup[area])));
      const {backup:ignoredBackup,before:ignoredBefore,...metadata}=marker;
      if(matches.every(Boolean)){
        const imported={...metadata,status:'imported'};await chrome.storage.local.set({[KEY]:imported});return finish(imported);
      }
      for(const area of ['sync','local']){
        await chrome.storage[area].set(before[area]);
        const added=Object.keys(backup[area]).filter(key=>!Object.hasOwn(before[area],key));
        if(added.length)await chrome.storage[area].remove(added);
        if(!transfer.equal(await chrome.storage[area].get(Object.keys(backup[area])),before[area]))throw Error('No se pudo recuperar el traslado interrumpido. Conservá la instalación original.');
      }
      await chrome.storage.local.remove([KEY]);
      throw Error('Se recuperó una migración interrumpida. Volvé a buscar el origen para reintentar.');
    }
    async function importSource(sourceId){
      if(pending)throw Error('Ya hay una migración en curso.');
      pending=(async()=>{
        const previous=(await chrome.storage.local.get(KEY))[KEY];
        if(previous){if(previous.schema!==1||!['pending','imported','complete'].includes(previous.status))throw Error('Estado de migración incompatible. Conservá la instalación original.');return recover(previous);}
        const item=await chrome.management.get(sourceId);
        if(!await probe(item))throw Error('Actualizá la instalación original con la edición de transición antes de importar.');
        const reply=await bounded(chrome.runtime.sendMessage(sourceId,{type:'VIENA_CWS_EXPORT'}));
        if(reply?.protocol!==1||reply.sourceId!==sourceId||reply.backup?.sourceId!==sourceId||reply.backup?.version!==item.version)throw Error('No se pudo verificar la instalación original.');
        const backup={...transfer.validate(reply.backup),...preferences(reply.backup)},macros=transfer.summarizeMacros(backup);
        if(JSON.stringify(backup).length>20*1024*1024)throw Error('La configuración excede el tamaño permitido.');
        const marker={schema:1,status:'imported',sourceId,sourceVersion:item.version,macros,importedAt:new Date().toISOString()};
        const before={};for(const area of ['local','sync'])before[area]=await chrome.storage[area].get(Object.keys(backup[area]));
        const journal={...marker,status:'pending',backup,before};
        await chrome.storage.local.set({[KEY]:journal});
        if(!transfer.equal((await chrome.storage.local.get(KEY))[KEY],journal))throw Error('No se pudo preparar el traslado. No se modificó la configuración.');
        try{await transfer.restore(chrome.storage,backup);}
        catch(error){
          const restored=await Promise.all(['local','sync'].map(async area=>transfer.equal(await chrome.storage[area].get(Object.keys(backup[area])),before[area])));
          if(restored.every(Boolean))await chrome.storage.local.remove([KEY]);
          throw error;
        }
        await chrome.storage.local.set({[KEY]:marker});
        return finish(marker);
      })();
      try{return await pending;}finally{pending=null;}
    }
    async function restoreManual(backup){
      if(pending)throw Error('Ya hay una migración o restauración en curso.');
      pending=(async()=>{
        transfer.validate(backup);transfer.summarizeMacros(backup);
        if(['local','sync'].some(area=>Object.keys(backup[area]).some(key=>key.startsWith('viena_cws_'))))throw Error('El respaldo contiene estado interno del traslado. Exportá nuevamente desde la instalación original.');
        if((await chrome.storage.local.get(KEY))[KEY]?.status==='pending')throw Error('Primero recuperá el traslado interrumpido desde Traer configuración anterior.');
        return transfer.restore(chrome.storage,{...backup,...preferences(backup)});
      })();
      try{return await pending;}finally{pending=null;}
    }
    return {discover,importSource,restoreManual};
  }
  const api={KEY,create};if(typeof module==='object'&&module.exports)module.exports=api;else root.VienaCwsMigration=api;
  if(typeof module!=='object'&&typeof document==='undefined'&&root.chrome?.runtime?.onMessage){
    const migration=create(root.chrome,root.VienaInstallationTransfer);
    root.chrome.runtime.onMessage.addListener((message,sender,respond)=>{
      if(!['VIENA_CWS_MIGRATION_DISCOVER','VIENA_CWS_MIGRATION_IMPORT','VIENA_CWS_RESTORE_MANUAL'].includes(message?.type))return false;
      if(sender?.id!==root.chrome.runtime.id||!sender.url?.startsWith(root.chrome.runtime.getURL('')))return false;
      const task=message.type==='VIENA_CWS_MIGRATION_DISCOVER'?migration.discover():message.type==='VIENA_CWS_RESTORE_MANUAL'?migration.restoreManual(message.backup):migration.importSource(message.sourceId);
      task.then(value=>respond({ok:true,value}),error=>respond({ok:false,error:error.message||'No se pudo completar la migración.'}));return true;
    });
  }
})(globalThis);
