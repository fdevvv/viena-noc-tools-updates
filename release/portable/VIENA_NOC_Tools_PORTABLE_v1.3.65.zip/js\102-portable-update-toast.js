(() => {
  'use strict';
  const autoInstall = true;
  const key = 'viena_portable_update_offer';
  const automaticKey = 'viena_portable_auto_zip_version';
  const installed = chrome.runtime.getManifest().version;
  let available, automaticVersion, displayed, toast, timer;

  function show() {
    if (document.visibilityState !== 'visible' || displayed === available ||
        !/^\d+\.\d+\.\d+$/.test(available || '')) return;
    const installedParts = installed.split('.').map(Number);
    const difference = available.split('.').map((n, index) => Number(n) - installedParts[index]).find(n => n !== 0);
    if (!(difference > 0)) return;
    displayed = available;
    toast?.remove();
    clearTimeout(timer);
    const host = document.createElement('div');
    host.id = 'viena-portable-update-toast';
    host.style.cssText = 'all:initial;position:fixed;right:16px;bottom:16px;max-width:calc(100vw - 32px);z-index:2147483647';
    const shadow = host.attachShadow({ mode: 'open' });
    const card = document.createElement('div');
    card.setAttribute('role', 'status');
    card.style.cssText = 'display:flex;align-items:center;flex-wrap:wrap;gap:8px 12px;padding:12px 14px;border:1px solid #426080;border-radius:10px;background:#152c45;color:#fff;font:14px system-ui;box-shadow:0 6px 20px #152c4555';
    const text = document.createElement('strong');
    text.textContent = 'Nueva versión de VIENA · v' + available;
    const open = document.createElement('button');
    open.type = 'button';
    open.textContent = 'Ver actualización';
    open.style.cssText = 'font:inherit;border:0;border-radius:6px;padding:6px 10px;background:#fff;color:#173a5e;cursor:pointer';
    const close = document.createElement('button');
    close.type = 'button';
    const scheduled = autoInstall && available === automaticVersion;
    close.textContent = scheduled ? 'Posponer' : 'Cerrar';
    close.style.cssText = 'font:inherit;border:0;background:transparent;color:#fff;cursor:pointer';
    close.addEventListener('click', () => { clearTimeout(timer); host.remove(); });
    open.addEventListener('click', () => {
      void chrome.runtime.sendMessage({ type: 'VIENA_PORTABLE_OPEN_UPDATES' }).catch(() => {});
      close.click();
    });
    card.append(text, open, close);
    shadow.append(card);
    document.body.append(host);
    toast = host;
    if (scheduled) {
      const notice = document.createElement('span');
      notice.textContent = 'VIENA se actualizará en 20 segundos y recargará las páginas operativas.';
      card.append(notice);
      const version = available;
      timer = setTimeout(() => {
        if (document.visibilityState !== 'visible') {
          notice.textContent = 'Actualización pospuesta. Abrí Actualizaciones para continuar.';
          return;
        }
        chrome.runtime.sendMessage({ type: 'VIENA_PORTABLE_START_ZIP_UPDATE', version })
          .then(result => { if (result?.ok) host.remove(); })
          .catch(() => {});
      }, 20000);
    } else timer = setTimeout(() => host.remove(), 12000);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || (!changes[key] && !changes[automaticKey])) return;
    if(changes[key])available = changes[key].newValue;
    if(changes[automaticKey])automaticVersion = changes[automaticKey].newValue;
    show();
  });
  document.addEventListener('visibilitychange', show);
  chrome.storage.local.get([key,automaticKey]).then(value => {
    available = value[key]; automaticVersion=value[automaticKey]; show();
  }).catch(() => {});
})();
