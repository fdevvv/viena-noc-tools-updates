((root) => {
  'use strict';
  const maxBytes = 24 * 1024 * 1024;
  const feed = 'https://raw.githubusercontent.com/fdevvv/viena-noc-tools-updates/refs/heads/main/release/portable/';
  const title = /^VIENA_NOC_Tools_PORTABLE_v\d+\.\d+\.\d+\.zip$/;
  const decoder = new TextDecoder('utf-8', { fatal: true });
  const fail = () => { throw new Error('El ZIP portable tiene un formato inválido o no compatible.'); };
  function accepts(url) {
    return url.href.startsWith(feed) && title.test(url.href.slice(feed.length));
  }
  async function unpack(bytes, safePath, expectedKey) {
    if (bytes.length < 22 || bytes.length > maxBytes) fail();
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const u16 = at => view.getUint16(at, true);
    const u32 = at => view.getUint32(at, true);
    const end = bytes.length - 22;
    if (u32(end) !== 0x06054b50 || u16(end + 4) || u16(end + 6) || u16(end + 20)) fail();
    const count = u16(end + 10), start = u32(end + 16);
    if (!count || count > 256 || u16(end + 8) !== count || start + u32(end + 12) !== end) fail();
    const files = new Map(), names = new Set(), ranges = [];
    let offset = start, total = 0;
    for (let i = 0; i < count; i++) {
      if (offset + 46 > end || u32(offset) !== 0x02014b50) fail();
      const flags = u16(offset + 8), method = u16(offset + 10);
      const compressed = u32(offset + 20), size = u32(offset + 24);
      const nameLength = u16(offset + 28), extra = u16(offset + 30), comment = u16(offset + 32);
      const local = u32(offset + 42), next = offset + 46 + nameLength + extra + comment;
      if (next > end || flags & ~0x808 || ![0, 8].includes(method) || u16(offset + 34) ||
          local + 30 > start || u32(local) !== 0x04034b50 ||
          u16(local + 6) !== flags || u16(local + 8) !== method || u16(local + 26) !== nameLength) fail();
      const rawName = decoder.decode(bytes.subarray(offset + 46, offset + 46 + nameLength));
      const name = rawName.replaceAll('\\','/');
      if (!safePath(name) || names.has(name.toLowerCase()) ||
          decoder.decode(bytes.subarray(local + 30, local + 30 + nameLength)) !== rawName) fail();
      const begin = local + 30 + nameLength + u16(local + 28), finish = begin + compressed;
      if (finish > start || ranges.some(([a,b]) => local < b && a < finish) || (total += size) > maxBytes) fail();
      ranges.push([local,finish]);names.add(name.toLowerCase());
      let data = bytes.subarray(begin, finish);
      if (method === 8) {
        const reader = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw')).getReader();
        data = new Uint8Array(size);
        let written = 0;
        try {
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            if (written + value.length > size) fail();
            data.set(value, written);written += value.length;
          }
          if (written !== size) fail();
        } finally { await reader.cancel(); }
      }
      if (data.length !== size) fail();
      files.set(name,data);offset = next;
    }
    if (offset !== end) fail();
    const manifest = JSON.parse(decoder.decode(files.get('manifest.json')));
    const build = JSON.parse(decoder.decode(files.get('build.json')));
    if (!expectedKey || manifest.key !== expectedKey || manifest.name !== 'VIENA NOC Tools' ||
        build.distribution !== 'portable' || build.channel !== 'RELEASE') fail();
    const entries = [];
    for (const [path,data] of files) {
      const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
      const sha256 = [...hash].map(n=>n.toString(16).padStart(2,'0')).join('');
      let binary = '';
      for (let start = 0; start < data.length; start += 8192) binary += String.fromCharCode(...data.subarray(start,start+8192));
      entries.push({path,size:data.length,sha256,content_base64:btoa(binary)});
    }
    return {schema:1,app:'VIENA NOC Tools',version:build.version,build:build.build,channel:build.channel,mode:'full',files:entries};
  }
  const api = { accepts, unpack, maxBytes };
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.VienaPortableArchive=api;
})(globalThis);
