'use strict';
importScripts('js/102-portable-download.js');
try { importScripts('js/05-node-tech.js', 'js/103-onmsi-core.js', 'js/103-onmsi-prepare.js', 'js/103-onmsi-moica.js', 'js/103-onmsi-background.js'); } catch (error) { console.error('VIENA ONMSi load failed', error); }
try { importScripts('js/101-access-config.js', 'js/101-access-policy.js', 'js/101-access-bootstrap.js'); } catch (error) { console.error('VIENA installation policy load failed', error); }
try { importScripts('js/96-ui-assets.js'); } catch (_) {}
try { importScripts('js/76-grafana-api.js', 'js/76-node-background.js'); } catch (error) { console.error('VIENA background readers load failed', error); }
try { importScripts('js/99-gec-po-core.js', 'js/99-gec-po-background.js'); } catch (error) { console.error('VIENA GEC optical analysis load failed', error); }
try { importScripts('js/71-node-status.js'); } catch (error) { console.error('VIENA node status load failed', error); }
try { importScripts('js/94-infocall-access.js'); } catch (_) {}
try { importScripts('js/70-building-capture-access.js'); } catch (error) { console.error('VIENA building capture access failed', error); }
try { importScripts('js/82-installation-transfer.js', 'js/85-cws-migration.js'); } catch (_) {}
const VIENA_BUILD_ID = '1.3.65';
const VIENA_BUILD_FILE = 'build.json';
const STATUS_BADGES = {
  reload: { text: 'RLD', color: '#B42318', title: 'VIENA NOC Tools — recargá la extensión' },
  tabs: { text: 'TAB', color: '#AD6B00', title: 'VIENA NOC Tools — recargá la pestaña operativa' },
  update: { text: 'UPD', color: '#D97706', title: 'VIENA NOC Tools — actualización disponible' },
  on: { text: '•', color: '#23833B', title: 'VIENA NOC Tools — activa' }
};
const EXTENSION_ICON_VARIANT_KEY = 'viena_extension_icon_variant_v1';
const ICON_RING_COLORS = {
  on:'#23833B',
  update:'#D97706',
  reload:'#B42318',
  tabs:'#AD6B00'
};
let currentExtensionIconState='neutral';
const extensionIconBaseCache=new Map();
function normalizeExtensionIconVariant(value){const v=String(value||'1');return globalThis.VIENA_ICON_VARIANTS?.[v]?v:'1'}
async function iconDataUrlToImageData(dataUrl,size){
  const raw=String(dataUrl||'');
  const match=/^data:([^;,]+)?(;base64)?,(.*)$/s.exec(raw);
  if(!match) throw new Error('Icono embebido inválido');
  const mime=match[1]||'image/png';
  const payload=match[3]||'';
  let bytes;
  if(match[2]){
    const binary=atob(payload);
    bytes=new Uint8Array(binary.length);
    for(let i=0;i<binary.length;i++) bytes[i]=binary.charCodeAt(i);
  }else{
    const text=decodeURIComponent(payload);
    bytes=new TextEncoder().encode(text);
  }
  const bitmap=await createImageBitmap(new Blob([bytes],{type:mime}));
  const canvas=new OffscreenCanvas(size,size);
  const ctx=canvas.getContext('2d',{willReadFrequently:true});
  ctx.clearRect(0,0,size,size); ctx.drawImage(bitmap,0,0,size,size); try{bitmap.close()}catch(_){}
  return ctx.getImageData(0,0,size,size);
}
async function getBaseExtensionIconData(variant,size,dataUrl){
  const key=`${variant}:${size}`;
  if(extensionIconBaseCache.has(key)) return extensionIconBaseCache.get(key);
  const data=await iconDataUrlToImageData(dataUrl,size);
  extensionIconBaseCache.set(key,data);
  return data;
}
function renderExtensionIconState(base,size,state){
  const color=ICON_RING_COLORS[state]||'';
  if(!color)return base;
  const canvas=new OffscreenCanvas(size,size);
  const ctx=canvas.getContext('2d',{willReadFrequently:true});
  ctx.putImageData(base,0,0);
  const width=Math.max(1,Math.round(size*.09));
  const inset=Math.max(.5,width/2);
  ctx.save();
  ctx.strokeStyle=color;
  ctx.lineWidth=width;
  ctx.globalAlpha=.98;
  if(typeof ctx.roundRect==='function'){
    const radius=Math.max(2,Math.round(size*.18));
    ctx.beginPath();
    ctx.roundRect(inset,inset,size-width,size-width,radius);
    ctx.stroke();
  }else{
    ctx.strokeRect(inset,inset,size-width,size-width);
  }
  ctx.restore();
  return ctx.getImageData(0,0,size,size);
}
async function applyExtensionIconVariant(value,{persist=false,state=currentExtensionIconState}={}){
  const variant=normalizeExtensionIconVariant(value), assets=globalThis.VIENA_ICON_VARIANTS?.[variant];
  if(!assets) throw new Error('Icono no disponible');
  currentExtensionIconState=state||'neutral';
  const imageData={};
  for(const size of [16,32,48,128]){
    const base=await getBaseExtensionIconData(variant,size,assets[String(size)]);
    imageData[size]=renderExtensionIconState(base,size,currentExtensionIconState);
  }
  await chrome.action.setIcon({imageData});
  if(persist) await chrome.storage.local.set({[EXTENSION_ICON_VARIANT_KEY]:variant});
  return variant;
}
async function applyExtensionIconState(state){
  currentExtensionIconState=state||'neutral';
  const st=await chrome.storage.local.get([EXTENSION_ICON_VARIANT_KEY]);
  return applyExtensionIconVariant(st[EXTENSION_ICON_VARIANT_KEY]||'1',{state:currentExtensionIconState});
}
async function restoreExtensionIconVariant(){try{const st=await chrome.storage.local.get([EXTENSION_ICON_VARIANT_KEY]);return await applyExtensionIconVariant(st[EXTENSION_ICON_VARIANT_KEY]||'1',{state:currentExtensionIconState})}catch(_){return '1'}}
const WORK_HOSTS = new Set([
  'viena.telecentro.net.ar','mira5-gdt.telecentro.net.ar','mira5.telecentro.net.ar',
  'monitoreogpon.telecentro.net.ar','fuentes.telecentro.net.ar','moica2.telecentro.net.ar',
  'metricas-gdt.telecentro.net.ar','metricasnodos.telecentro.net.ar','grafana-telemetria.telecentro.net.ar'
]);
// Independent native zoom for operational tabs.
// Session state plus a tab-scoped local backup survives extension reloads.
{
  const zoomPrefix = 'viena_tab_zoom_v1_';
  const zoomKey = tabId => zoomPrefix + tabId;
  const zoomPagePrefix = 'viena_tab_zoom_page_v1_';
  const zoomPageKey = tabId => zoomPagePrefix + tabId;
  const pagePreferenceKey = page => 'viena_page_zoom_v1_' + encodeURIComponent(page);
  const zoomTasks = new Map();
  const automaticZoomTabs = new Set();
  const automaticZoomTargets = new Map();
  function zoomPage(tab) {
    const u = new URL(tab.url);
    if (u.hostname === 'viena.telecentro.net.ar') return u.origin;
    return u.origin + u.pathname + (u.hash.startsWith('#/') ? u.hash.split('?')[0] : '');
  }
  const isWorkTab = tab => {
    try { const u = new URL(tab?.url || ''); return /^https?:$/.test(u.protocol) && WORK_HOSTS.has(u.hostname); }
    catch (_) { return false; }
  };
  function queueZoomTask(tabId, task) {
    const previous = zoomTasks.get(tabId) || Promise.resolve();
    const next = previous.then(task).catch(() => {}).finally(() => {
      if (zoomTasks.get(tabId) === next) zoomTasks.delete(tabId);
    });
    zoomTasks.set(tabId, next);
    return next;
  }
  async function saveTabZoom(tab, factor, rememberPage = false) {
    const page = zoomPage(tab);
    const value = { [zoomKey(tab.id)]: factor, [zoomPageKey(tab.id)]: page };
    if (rememberPage) value[pagePreferenceKey(page)] = factor;
    await chrome.storage.local.set(value);
    await chrome.storage.session?.set(value);
  }
  async function removeTabZoom(tabId) {
    const keys = [zoomKey(tabId), zoomPageKey(tabId)];
    await chrome.storage.local.remove(keys);
    await chrome.storage.session?.remove(keys);
  }
  function configureTabZoom(tabId, reset = false) {
    if (typeof chrome.tabs.setZoomSettings !== 'function') return;
    return queueZoomTask(tabId, async () => {
      const tab = await chrome.tabs.get(tabId);
      const key = zoomKey(tabId);
      if (reset) await removeTabZoom(tabId);
      if (!isWorkTab(tab)) {
        await removeTabZoom(tabId);
        return;
      }
      const settings = await chrome.tabs.getZoomSettings(tabId);
      if (settings.mode !== 'automatic') return; // Respect disabled/manual zoom from other extensions.
      const page = zoomPage(tab), bindingKey = zoomPageKey(tabId);
      // Preserve the earlier tasks preference when VIENA starts sharing one site preference.
      const legacyKey = page === 'https://viena.telecentro.net.ar'
        ? pagePreferenceKey(page + '/tasks/intern') : pagePreferenceKey(page);
      const saved = await chrome.storage.session?.get([key, bindingKey]);
      const backup = await chrome.storage.local.get([key, bindingKey, pagePreferenceKey(page), legacyKey]);
      const storedBinding = saved?.[bindingKey] || backup[bindingKey];
      const binding = storedBinding ? zoomPage({ url: storedBinding }) : storedBinding;
      const ownFactor = !binding || binding === page ? saved?.[key] || backup[key] : null;
      if (settings.scope === 'per-tab' && saved?.[key] && (!binding || binding === page)) return;
      const factor = ownFactor || backup[pagePreferenceKey(page)] || backup[legacyKey] || 1;
      automaticZoomTabs.add(tabId);
      try {
        if (settings.scope !== 'per-tab') await chrome.tabs.setZoomSettings(tabId, { mode: 'automatic', scope: 'per-tab' });
        if (await chrome.tabs.getZoom(tabId) !== factor) {
          automaticZoomTargets.set(tabId, factor);
          await chrome.tabs.setZoom(tabId, factor);
        }
        await saveTabZoom(tab, factor);
      } finally { automaticZoomTabs.delete(tabId); }
    });
  }
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (change.url || change.status === 'loading' || change.status === 'complete') void configureTabZoom(tabId);
  });
  chrome.tabs.onActivated.addListener(info => { void configureTabZoom(info.tabId); });
  chrome.tabs.onZoomChange?.addListener(info => {
    if (info.zoomSettings?.scope !== 'per-tab' || info.zoomSettings.mode !== 'automatic') return;
    if (!Number.isFinite(info.newZoomFactor) || info.newZoomFactor <= 0) return;
    const automatic = automaticZoomTabs.has(info.tabId) || automaticZoomTargets.get(info.tabId) === info.newZoomFactor;
    automaticZoomTargets.delete(info.tabId);
    void queueZoomTask(info.tabId, async () => {
      const tab = await chrome.tabs.get(info.tabId);
      if (isWorkTab(tab)) {
        await saveTabZoom(tab, info.newZoomFactor, !automatic);
      }
    });
  });
  chrome.tabs.onRemoved.addListener(tabId => {
    automaticZoomTargets.delete(tabId);
    void queueZoomTask(tabId, () => removeTabZoom(tabId));
  });
  // Tab IDs belong to one browser session; a browser restart must not reuse old backups.
  chrome.runtime?.onStartup?.addListener(() => {
    void (async () => {
      try { for (const tab of await chrome.tabs.query({})) void configureTabZoom(tab.id, true); }
      catch (_) {}
    })();
  });
  // Also cover tabs already open when DEV is loaded or the worker wakes up.
  void (async () => {
    try {
      const tabs = await chrome.tabs.query({});
      const liveKeys = new Set(tabs.flatMap(tab => [zoomKey(tab.id), zoomPageKey(tab.id)]));
      const keys = typeof chrome.storage.local.getKeys === 'function'
        ? await chrome.storage.local.getKeys() : Object.keys(await chrome.storage.local.get(null));
      const stale = keys.filter(key => (key.startsWith(zoomPrefix) || key.startsWith(zoomPagePrefix)) && !liveKeys.has(key));
      if (stale.length) await chrome.storage.local.remove(stale);
      for (const tab of tabs) if (isWorkTab(tab)) void configureTabZoom(tab.id);
    }
    catch (_) {}
  })();
}
async function protect(tabId,url){
  try { const u=new URL(url||''); if(WORK_HOSTS.has(u.hostname)) await chrome.tabs.update(tabId,{autoDiscardable:false}); } catch(_){}
}
chrome.tabs.onUpdated.addListener((tabId,change,tab)=>protect(tabId,change.url||tab.url));
chrome.runtime.onInstalled.addListener(details=>{
  if(details?.reason==='update') runWorkerTask('installed_page_refresh',()=>refreshTabsOnRuntimeBuildTransition(true));
  runWorkerTask('onInstalled',async()=>{
    for(const tab of await chrome.tabs.query({})) protect(tab.id,tab.url);
    await ensureUpdateAlarm();
    await ensureInstallRegistryAlarm();

    await restoreExtensionIconVariant();
    runWorkerTask('installed_update_check',()=>checkUpdateInBackground());
    runWorkerTask('installed_registry',()=>sendInstallRegistryHeartbeat('installed'));
  });
});
chrome.runtime.onStartup.addListener(()=>{
  runWorkerTask('onStartup',async()=>{
    for(const tab of await chrome.tabs.query({})) protect(tab.id,tab.url);
    await ensureUpdateAlarm();
    await ensureInstallRegistryAlarm();

    await restoreExtensionIconVariant();
    runWorkerTask('startup_update_check',()=>checkUpdateInBackground());
    runWorkerTask('startup_registry',()=>sendInstallRegistryHeartbeat('startup'));
  });
});
chrome.tabs.onActivated.addListener(info=>{ void rememberPrimaryOperationalTab(info.tabId); void refreshActionBadge(info.tabId); });
chrome.tabs.onUpdated.addListener((tabId,change,tab)=>{ if(change.url && tab?.active) void rememberPrimaryOperationalTab(tabId); if(change.status==='complete'||change.url) void refreshActionBadge(tabId); });
chrome.tabs.onRemoved.addListener(tabId=>{ void forgetPrimaryOperationalTab(tabId); });
chrome.windows.onFocusChanged.addListener(()=>{ void refreshActionBadge(); });

// Comprobación periódica de actualizaciones y aviso al operador.


const IS_DEV_RUNTIME = /\bDEV\b/i.test(String(chrome.runtime.getManifest().name||''));
const UPDATE_ALARM = 'viena-update-check';
const UPDATE_CHECK_PERIOD_MINUTES = 5;
const LAST_NOTIFIED_VERSION_KEY = 'viena_last_notified_update_version';
const UPDATE_DOWNLOAD_URL_KEY = 'viena_last_update_download_url';
const UPDATE_STATE_KEY = 'viena_update_state';
const UPDATE_DISMISS_SESSION_KEY = 'viena_update_banner_dismissed';
const UPDATE_BADGE_TEXT = 'UPD';
// DEV 1.3.19 — registro técnico privado de instalaciones.
// Sólo envía metadatos técnicos; no tickets, nodos, búsquedas, URLs visitadas ni contenido operativo.
const INSTALL_REGISTRY_ENDPOINT = 'https://script.google.com/macros/s/AKfycbybjd7pdwq4QuqLwdZo1bYV-gkAWcP20dZmb3rsO2vcqRGY8UekSSnDHYPipjOUblY-/exec';
const INSTALL_REGISTRY_KEY = '474fe6b9-fd2d-42ea-a14d-23d2fcb53348-f476e7ba00fe4bb68a606dc770fa1fc1';
const INSTALL_REGISTRY_ALARM = 'viena-install-registry-heartbeat';
const INSTALL_REGISTRY_RETRY_ALARM = 'viena-install-registry-retry';
const INSTALL_REGISTRY_PERIOD_MINUTES = 5;
const INSTALLATION_ID_KEY = 'viena_installation_id_v1';
const INSTALL_REGISTRY_LAST_OK_KEY = 'viena_install_registry_last_ok';
const INSTALL_REGISTRY_LAST_ERROR_KEY = 'viena_install_registry_last_error';
const INSTALL_REGISTRY_LAST_USER_KEY = 'viena_install_registry_last_user';
const INSTALL_REGISTRY_LAST_VERSION_KEY = 'viena_install_registry_last_version';
const INSTALL_REGISTRY_LAST_BUILD_KEY = 'viena_install_registry_last_build';
const INSTALL_REGISTRY_LAST_REASON_KEY = 'viena_install_registry_last_reason';
const INSTALL_REGISTRY_RETRY_LEVEL_KEY = 'viena_install_registry_retry_level';
const INSTALL_REGISTRY_RETRY_DELAYS_MINUTES = [1,5,15];


function compareVersions(a,b){
  const pa=String(a||'').split('.').map(n=>Number.parseInt(n,10)||0);
  const pb=String(b||'').split('.').map(n=>Number.parseInt(n,10)||0);
  const max=Math.max(pa.length,pb.length);
  for(let i=0;i<max;i++){
    const x=pa[i]||0,y=pb[i]||0;
    if(x!==y)return x>y?1:-1;
  }
  return 0;
}
function validHttpsUrl(value){try{return new URL(String(value||'')).protocol==='https:'}catch(_){return false}}

function installRegistryConfigured(){
  return /^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec(?:[?#].*)?$/.test(String(INSTALL_REGISTRY_ENDPOINT||''));
}

function stableRegistryInstallationId(usuario,channel,deviceId=''){
  const user=String(usuario||'').trim().toLowerCase().replace(/[^a-z0-9._-]+/g,'-').replace(/^-+|-+$/g,'');
  const ch=String(channel||'RELEASE').trim().toUpperCase()==='DEV'?'dev':'release';
  const device=String(deviceId||'').trim().toLowerCase().replace(/[^a-z0-9._-]+/g,'-').replace(/^-+|-+$/g,'');
  return user && user!=='sin_detectar' && device ? `operator:${ch}:${user}:device:${device}` : '';
}

async function getRegistryIdentityFromViena(){
  try{
    const tabs=await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'});
    const ordered=[...tabs].filter(t=>t.id).sort((a,b)=>{
      if(Boolean(a.active)!==Boolean(b.active)) return a.active?-1:1;
      return Number(b.lastAccessed||0)-Number(a.lastAccessed||0);
    });
    for(const tab of ordered){
      try{
        const result=await Promise.race([
          chrome.tabs.sendMessage(tab.id,{type:'VIENA_GET_REGISTRY_IDENTITY'}),
          new Promise((_,reject)=>setTimeout(()=>reject(new Error('registry_identity_timeout')),1200))
        ]);
        const deviceId=String(result?.deviceId||'').trim();
        const installationId=String(result?.installationId||'').trim();
        if(deviceId) return {tabId:tab.id,deviceId,installationId};
      }catch(_){}
    }
  }catch(_){}
  return null;
}

async function persistRegistryInstallationIdInViena(identity,installationId){
  const tabId=Number(identity?.tabId||0);
  const id=String(installationId||'').trim();
  if(!tabId || !id) return false;
  try{
    const result=await chrome.tabs.sendMessage(tabId,{
      type:'VIENA_SET_REGISTRY_INSTALLATION_ID',
      installationId:id
    });
    return result?.ok===true;
  }catch(_){
    return false;
  }
}

async function ensureInstallationId(usuario='',channel='RELEASE'){
  const identity=await getRegistryIdentityFromViena();
  const saved=await chrome.storage.local.get([INSTALLATION_ID_KEY]);
  let id=String(saved[INSTALLATION_ID_KEY]||'').trim();

  // Migration path: if this extension instance already owns a registry ID,
  // anchor that exact ID in the VIENA origin before doing anything else.
  // Future manual reinstalls on this PC/profile will recover the same row.
  if(id){
    if(identity && identity.installationId!==id){
      await persistRegistryInstallationIdInViena(identity,id);
    }
    return id;
  }

  // Manual reinstall / different unpacked-extension ID on the same PC/profile:
  // recover the anchored installation ID instead of creating a new row.
  if(identity?.installationId){
    id=String(identity.installationId).trim();
    await chrome.storage.local.set({[INSTALLATION_ID_KEY]:id});
    return id;
  }

  // First real installation for this PC/profile. Do not fall back to a
  // user-only ID, because that would merge different PCs of the same operator.
  id=stableRegistryInstallationId(usuario,channel,identity?.deviceId||'');
  if(!id) return '';

  await chrome.storage.local.set({[INSTALLATION_ID_KEY]:id});
  if(identity) await persistRegistryInstallationIdInViena(identity,id);
  return id;
}

async function detectVienAUserFromOpenTab(){
  try{
    const tabs=await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'});
    const ordered=[...tabs].filter(t=>t.id).sort((a,b)=>{
      if(Boolean(a.active)!==Boolean(b.active)) return a.active?-1:1;
      return Number(b.lastAccessed||0)-Number(a.lastAccessed||0);
    });
    for(const tab of ordered){
      try{
        const result=await Promise.race([
          chrome.tabs.sendMessage(tab.id,{type:'VIENA_GET_DETECTED_USER'}),
          new Promise((_,reject)=>setTimeout(()=>reject(new Error('user_detect_timeout')),1200))
        ]);
        const usuario=String(result?.usuario||'').trim();
        if(usuario) return usuario;
      }catch(_){ }
    }
  }catch(_){ }
  return '';
}

let installRegistryHeartbeatInFlight = null;
let installRegistryLastStartedAt = 0;

async function sendInstallRegistryHeartbeat(reason='scheduled'){
  if(!installRegistryConfigured()) return {ok:false,disabled:true,reason:'endpoint_not_configured'};
  if(installRegistryHeartbeatInFlight) return installRegistryHeartbeatInFlight;
  const now=Date.now();
  if(now-installRegistryLastStartedAt<3000) return {ok:true,skipped:true,reason:'heartbeat_coalesced'};
  installRegistryLastStartedAt=now;
  installRegistryHeartbeatInFlight=(async()=>{
    try{
      const stored=await chrome.storage.local.get(['viena_usuario',INSTALL_REGISTRY_LAST_USER_KEY]);
      let usuario=String(stored.viena_usuario||'').trim();
      if(/^sin_detectar$/i.test(usuario)) usuario='';
      if(!usuario){
        usuario=await detectVienAUserFromOpenTab();
        if(/^sin_detectar$/i.test(usuario)) usuario='';
        if(usuario) await chrome.storage.local.set({viena_usuario:usuario,viena_usuario_origen:'auto'});
      }
      // A temporarily unavailable account DOM must not erase this installation's
      // last successfully reported operator. Do not copy history into user settings.
      if(!usuario){
        const lastUser=String(stored[INSTALL_REGISTRY_LAST_USER_KEY]||'').trim();
        if(lastUser && !/^sin_detectar$/i.test(lastUser)) usuario=lastUser;
      }
      if(!usuario) usuario='SIN_DETECTAR';

      const manifest=chrome.runtime.getManifest();
      const channel=/\bDEV\b/i.test(String(manifest.name||''))?'DEV':'RELEASE';
      const installationId=await ensureInstallationId(usuario,channel);
      if(!installationId) return {ok:false,pending:true,reason:'registry_identity_pending'};
      const runtimeId=String(chrome.runtime.id||'');
      const payload={
        registry_key:INSTALL_REGISTRY_KEY,
        installation_id:installationId,
        usuario_viena:usuario.slice(0,80),
        installed_version:String(manifest.version||''),
        build:`${VIENA_BUILD_ID} · ext:${runtimeId.slice(0,8)}`,
        runtime_id:runtimeId,
        channel,
        reason:String(reason||'scheduled').slice(0,32),
        reported_at:new Date().toISOString()
      };

      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),20000);
      let response;
      try{
        response=await fetch(INSTALL_REGISTRY_ENDPOINT,{
          method:'POST',
          cache:'no-store',
          redirect:'follow',
          headers:{'Content-Type':'text/plain;charset=UTF-8'},
          body:JSON.stringify(payload),
          signal:controller.signal
        });
      } finally { clearTimeout(timer); }

      if(!response.ok) throw new Error(`HTTP ${response.status}`);
      const finalUrl=String(response.url||'');
      try{
        const host=new URL(finalUrl).hostname.toLowerCase();
        if(host!=='script.google.com' && host!=='script.googleusercontent.com') throw new Error('registry_unexpected_redirect');
      }catch(error){
        if(String(error?.message||error)==='registry_unexpected_redirect') throw error;
        throw new Error('registry_invalid_response_url');
      }
      let result;
      try{ result=await response.json(); }
      catch(_){ throw new Error('registry_invalid_json'); }
      if(!result || result.ok!==true) throw new Error(String(result?.error||'registry_rejected'));

      await chrome.storage.local.set({
        [INSTALL_REGISTRY_LAST_OK_KEY]:Date.now(),
        [INSTALL_REGISTRY_LAST_USER_KEY]:usuario,
        [INSTALL_REGISTRY_LAST_VERSION_KEY]:String(manifest.version||''),
        [INSTALL_REGISTRY_LAST_BUILD_KEY]:VIENA_BUILD_ID,
        [INSTALL_REGISTRY_LAST_REASON_KEY]:String(reason||'scheduled').slice(0,32)
      });
      await chrome.storage.local.remove([INSTALL_REGISTRY_LAST_ERROR_KEY]);
      try{ await chrome.alarms.clear(INSTALL_REGISTRY_RETRY_ALARM); }catch(_){}
      await chrome.storage.local.remove([INSTALL_REGISTRY_RETRY_LEVEL_KEY]);
      return {ok:true};
    }catch(error){
      const raw=String(error?.message||error);
      const normalized=(error?.name==='AbortError'||/aborted|abort/i.test(raw))?'timeout_temporal':raw.slice(0,200);
      await chrome.storage.local.set({[INSTALL_REGISTRY_LAST_ERROR_KEY]:normalized});
      await scheduleInstallRegistryRetry();
      return {ok:false,error:normalized,retryScheduled:true};
    }
  })();
  try{ return await installRegistryHeartbeatInFlight; }
  finally{ installRegistryHeartbeatInFlight=null; }
}

async function ensureInstallRegistryAlarm(){
  const existing=await chrome.alarms.get(INSTALL_REGISTRY_ALARM);
  const period=Number(existing?.periodInMinutes||0);
  if(!existing || period!==INSTALL_REGISTRY_PERIOD_MINUTES){
    if(existing) await chrome.alarms.clear(INSTALL_REGISTRY_ALARM);
    chrome.alarms.create(INSTALL_REGISTRY_ALARM,{delayInMinutes:1,periodInMinutes:INSTALL_REGISTRY_PERIOD_MINUTES});
  }
}
async function scheduleInstallRegistryRetry(){
  try{
    const saved=await chrome.storage.local.get([INSTALL_REGISTRY_RETRY_LEVEL_KEY]);
    const level=Math.max(0,Math.min(Number(saved[INSTALL_REGISTRY_RETRY_LEVEL_KEY]||0),INSTALL_REGISTRY_RETRY_DELAYS_MINUTES.length-1));
    const delay=INSTALL_REGISTRY_RETRY_DELAYS_MINUTES[level];
    await chrome.storage.local.set({[INSTALL_REGISTRY_RETRY_LEVEL_KEY]:Math.min(level+1,INSTALL_REGISTRY_RETRY_DELAYS_MINUTES.length-1)});
    const existing=await chrome.alarms.get(INSTALL_REGISTRY_RETRY_ALARM);
    if(existing) await chrome.alarms.clear(INSTALL_REGISTRY_RETRY_ALARM);
    chrome.alarms.create(INSTALL_REGISTRY_RETRY_ALARM,{delayInMinutes:delay});
  }catch(_){}
}

// CyBOK hardening B2: los mensajes internos privilegiados sólo se aceptan
// desde páginas de la propia extensión o content scripts en hosts operativos esperados.
// No cambia ningún flujo funcional; sólo rechaza orígenes fuera del perímetro.
function senderUrl(sender){ return String(sender?.tab?.url || sender?.url || ''); }
function senderHost(sender){ try { return new URL(senderUrl(sender)).hostname; } catch(_) { return ''; } }
function senderIsExtensionPage(sender){
  if(sender?.id!==chrome.runtime.id) return false;
  const url=senderUrl(sender);
  return Boolean(url) && url.startsWith(chrome.runtime.getURL(''));
}
function senderIsOperational(sender, allowedHosts=null){
  if(sender?.id!==chrome.runtime.id) return false;
  const host=senderHost(sender);
  if(!host) return false;
  if(Array.isArray(allowedHosts)) return allowedHosts.includes(host);
  return WORK_HOSTS.has(host);
}
function rejectUnauthorized(sendResponse){
  sendResponse?.({ok:false,code:'unauthorized_sender',detail:'Origen de mensaje no autorizado'});
}
function localDayKey(){
  const d=new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}


async function readPackageBuild(){
  try{
    const url=`${chrome.runtime.getURL(VIENA_BUILD_FILE)}?_${Date.now()}`;
    const response=await fetch(url,{cache:'no-store'});
    if(!response.ok) throw new Error(`HTTP ${response.status}`);
    const data=await response.json();
    return String(data?.build||'').trim();
  }catch(_){ return ''; }
}


function waitMs(ms){ return new Promise(resolve=>setTimeout(resolve,ms)); }
function platformForUrl(raw){
  // MIRA5 tiene dos superficies operativas distintas para la extensión.
  // Cada una conserva su propia pestaña primaria para que una actualización
  // recargue Estadísticas y Listado de CMs de forma independiente.
  // MOICA2 sólo es operativa para la extensión en /buscarTicket.php.
  try{
    const u=new URL(raw||'');
    if(u.hostname==='viena.telecentro.net.ar') return 'viena';
    if(u.hostname==='mira5-gdt.telecentro.net.ar'||u.hostname==='mira5.telecentro.net.ar'){
      if(u.pathname.includes('stats_frontend.php')) return 'miraStats';
      if(u.pathname.includes('cablemodem_frontend.php')) return 'miraCm';
      return '';
    }
    if(u.hostname==='monitoreogpon.telecentro.net.ar') return 'gpon';
    if(u.hostname==='fuentes.telecentro.net.ar') return 'fuentes';
    if(u.hostname==='metricas-gdt.telecentro.net.ar'||u.hostname==='metricasnodos.telecentro.net.ar') return 'metricas';
    if(u.hostname==='moica2.telecentro.net.ar' && u.pathname==='/buscarTicket.php') return 'moica2';
    if(u.hostname==='grafana-telemetria.telecentro.net.ar') return 'grafana';
  }catch(_){}
  return '';
}


// Una sola pestaña primaria por plataforma. Si el operador activa otra pestaña
// de la misma plataforma, esa pasa a ser la primaria. Las duplicadas nunca se
// cierran ni se recargan en bloque.
const PRIMARY_TAB_BY_PLATFORM_KEY = 'viena_primary_tab_by_platform_v1';
const LAST_RUNTIME_BUILD_SEEN_KEY = 'viena_last_runtime_build_seen_v1';
const OPERATIONAL_PLATFORM_KEYS = ['viena','miraStats','miraCm','gpon','fuentes','moica2','grafana','metricas'];
const PLATFORM_DEFAULT_URLS = {
  viena: 'https://viena.telecentro.net.ar/',
  miraStats: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
  miraCm: 'https://mira5-gdt.telecentro.net.ar/cablemodem_frontend.php',
  gpon: 'https://monitoreogpon.telecentro.net.ar/#/listOnts',
  fuentes: 'https://fuentes.telecentro.net.ar/webs/home.php',
  moica2: 'https://moica2.telecentro.net.ar/buscarTicket.php',
  grafana: 'https://grafana-telemetria.telecentro.net.ar/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e?orgId=1',
  metricas: 'https://metricas-gdt.telecentro.net.ar/nodos/home.php'
};

async function getPrimaryTabMap(){
  const saved=await chrome.storage.local.get([PRIMARY_TAB_BY_PLATFORM_KEY]);
  const map=saved[PRIMARY_TAB_BY_PLATFORM_KEY];
  return map && typeof map==='object' ? {...map} : {};
}

async function setPrimaryOperationalTab(platform,tabId){
  if(!OPERATIONAL_PLATFORM_KEYS.includes(platform) || !Number.isInteger(Number(tabId))) return;
  const map=await getPrimaryTabMap();
  map[platform]=Number(tabId);
  await chrome.storage.local.set({[PRIMARY_TAB_BY_PLATFORM_KEY]:map});
}

async function rememberPrimaryOperationalTab(tabId){
  try{
    const tab=await chrome.tabs.get(tabId);
    const platform=platformForUrl(tab?.url);
    if(platform) await setPrimaryOperationalTab(platform,tabId);
  }catch(_){}
}

async function forgetPrimaryOperationalTab(tabId){
  try{
    const map=await getPrimaryTabMap();
    let changed=false;
    for(const key of Object.keys(map)){
      if(Number(map[key])===Number(tabId)){ delete map[key]; changed=true; }
    }
    if(changed) await chrome.storage.local.set({[PRIMARY_TAB_BY_PLATFORM_KEY]:map});
  }catch(_){}
}

async function selectPrimaryOperationalTab(platform,tabs=null){
  const all=Array.isArray(tabs)?tabs:await chrome.tabs.query({});
  const matches=all.filter(t=>t?.id && platformForUrl(t.url)===platform);
  if(!matches.length) return null;

  // El onActivated guarda cuál fue la última pestaña elegida por el operador.
  // Ese recuerdo tiene prioridad incluso si hay otras ventanas con una pestaña
  // técnicamente "active". Si no existe, usamos activa + lastAccessed.
  const map=await getPrimaryTabMap();
  const remembered=matches.find(t=>Number(t.id)===Number(map[platform]));
  if(remembered) return remembered;

  matches.sort((a,b)=>{
    if(Boolean(a.active)!==Boolean(b.active)) return a.active?-1:1;
    return Number(b.lastAccessed||0)-Number(a.lastAccessed||0) || Number(b.id||0)-Number(a.id||0);
  });
  const chosen=matches[0]||null;
  if(chosen?.id) await setPrimaryOperationalTab(platform,chosen.id);
  return chosen;
}

async function waitForTabComplete(tabId,timeout=18000,step=250){
  const start=Date.now();
  while(Date.now()-start<timeout){
    try{
      const tab=await chrome.tabs.get(tabId);
      if(tab?.status==='complete') return {ok:true,tab};
    }catch(_){ return {ok:false,code:'tab_unavailable'}; }
    await waitMs(step);
  }
  return {ok:false,code:'tab_load_timeout'};
}

async function ensureOperationalTabRuntimeCurrent(tabId){
  let tab;
  try{ tab=await chrome.tabs.get(tabId); }catch(_){ return {ok:false,code:'tab_unavailable'}; }
  const ping=await pingStatusTab(tab);
  if(ping.ok && !ping.stale) return {ok:true,reloaded:false};
  try{
    await chrome.tabs.reload(tabId);
    const loaded=await waitForTabComplete(tabId,18000,250);
    return loaded.ok ? {ok:true,reloaded:true} : loaded;
  }catch(_){ return {ok:false,code:'reload_failed'}; }
}

let reloadPrimaryOperationalTabsPromise = null;
let reloadPrimaryOperationalTabsStartedAt = 0;

async function reloadPrimaryOperationalTabs(reason='extension_reload'){
  if(reloadPrimaryOperationalTabsPromise) return reloadPrimaryOperationalTabsPromise;
  if(Date.now()-reloadPrimaryOperationalTabsStartedAt<3000) return {ok:true,reason,skipped:true,reloaded:[]};
  reloadPrimaryOperationalTabsStartedAt=Date.now();
  reloadPrimaryOperationalTabsPromise=(async()=>{
    const tabs=await runtimePageRefreshBounded(chrome.tabs.query({}));
    const reloaded=[];
    for(const platform of OPERATIONAL_PLATFORM_KEYS){
      const primary=await runtimePageRefreshBounded(selectPrimaryOperationalTab(platform,tabs));
      if(!primary?.id) continue;
      try{
        await runtimePageRefreshBounded(chrome.tabs.reload(primary.id));
        reloaded.push({platform,tabId:primary.id});
      }catch(_){}
    }
    return {ok:true,reason,reloaded};
  })();
  try{ return await reloadPrimaryOperationalTabsPromise; }
  finally{ reloadPrimaryOperationalTabsPromise=null; }
}

async function refreshTabsOnRuntimeBuildTransitionImpl(force=false){
  try{
    const saved=await runtimePageRefreshBounded(chrome.storage.local.get([LAST_RUNTIME_BUILD_SEEN_KEY]));
    const previous=String(saved[LAST_RUNTIME_BUILD_SEEN_KEY]||'').trim();
    if(!previous){
      await runtimePageRefreshBounded(chrome.storage.local.set({[LAST_RUNTIME_BUILD_SEEN_KEY]:VIENA_BUILD_ID}));
      // Primera ejecución de esta lógica: si las páginas ya estaban abiertas con
      // un content script viejo (por ejemplo DEV apagada mientras se copiaban
      // archivos), se recargan las primarias una sola vez.
      const tabs=await runtimePageRefreshBounded(chrome.tabs.query({}));
      let staleOpen=false;
      for(const platform of OPERATIONAL_PLATFORM_KEYS){
        const primary=await runtimePageRefreshBounded(selectPrimaryOperationalTab(platform,tabs));
        if(!primary?.id) continue;
        const ping=await runtimePageRefreshBounded(pingStatusTab(primary));
        if(!ping.ok || ping.stale){ staleOpen=true; break; }
      }
      return staleOpen ? reloadPrimaryOperationalTabs('first_runtime_reconcile') : {ok:true,firstRun:true};
    }
    if(previous===VIENA_BUILD_ID) return force ? reloadPrimaryOperationalTabs('runtime_extension_reload') : {ok:true,changed:false};
    await runtimePageRefreshBounded(chrome.storage.local.set({[LAST_RUNTIME_BUILD_SEEN_KEY]:VIENA_BUILD_ID}));
    return reloadPrimaryOperationalTabs('runtime_build_transition');
  }catch(_){ return {ok:false}; }
}


async function runtimePageRefreshBounded(operation){
  let timer;
  try{return await Promise.race([operation,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('runtime_refresh_timeout')),5000);})]);}
  finally{clearTimeout(timer);}
}
let runtimePageRefreshPromise=null;
let runtimePageRefreshForced=false;
async function refreshTabsOnRuntimeBuildTransition(force=false){
  if(runtimePageRefreshPromise){
    const pending=runtimePageRefreshPromise;
    if(force&&!runtimePageRefreshForced){await pending;return refreshTabsOnRuntimeBuildTransition(true);}
    return pending;
  }
  runtimePageRefreshForced=force;
  runtimePageRefreshPromise=refreshTabsOnRuntimeBuildTransitionImpl(force);
  try{return await runtimePageRefreshPromise;}
  finally{runtimePageRefreshPromise=null;}
}
async function reconcileCwsRuntimePages(){
  try{
    const key='viena_cws_runtime_session_v1';
    const session=await runtimePageRefreshBounded(chrome.storage.session.get(key));
    const fresh=session[key]!==VIENA_BUILD_ID;
    if(fresh)await runtimePageRefreshBounded(chrome.storage.session.set({[key]:VIENA_BUILD_ID}));
    return refreshTabsOnRuntimeBuildTransition(fresh);
  }catch(_){return {ok:false};}
}
async function focusOperationalTab(tabId){
  try{
    const tab=await chrome.tabs.update(tabId,{active:true});
    if(tab?.windowId!=null){ try{ await chrome.windows.update(tab.windowId,{focused:true}); }catch(_){} }
    return tab;
  }catch(_){ return null; }
}

async function openOperationalPlatform(platform,{background=false}={}){
  if(!OPERATIONAL_PLATFORM_KEYS.includes(platform)) return {ok:false,code:'invalid_platform'};

  const target = platform==='miraStats' ? 'mira-stats'
    : platform==='miraCm' ? 'mira-cm'
    : platform==='gpon' ? 'gpon'
    : platform==='fuentes' ? 'fuentes'
    : platform==='moica2' ? 'moica'
    : platform==='grafana' ? 'grafana-vccap' : '';

  if(target){
    const ensured=await ensureDestinationTab(target,{activate:!background});
    if(!ensured?.ok || !ensured.tabId) return {ok:false,code:ensured?.code||'open_failed'};
    await setPrimaryOperationalTab(platform,ensured.tabId);
    if(!background) await focusOperationalTab(ensured.tabId);
    return {ok:true,tabId:ensured.tabId,opened:Boolean(ensured.opened),navigated:Boolean(ensured.navigated),background:Boolean(background)};
  }

  const tabs=await chrome.tabs.query({});
  const existing=await selectPrimaryOperationalTab(platform,tabs);
  if(existing?.id){
    if(!background) await focusOperationalTab(existing.id);
    return {ok:true,tabId:existing.id,opened:false,background:Boolean(background)};
  }
  const url=PLATFORM_DEFAULT_URLS[platform];
  if(!url) return {ok:false,code:'no_default_url'};
  const created=await chrome.tabs.create({url,active:!background});
  if(!created?.id) return {ok:false,code:'open_failed'};
  await setPrimaryOperationalTab(platform,created.id);
  return {ok:true,tabId:created.id,opened:true,background:Boolean(background)};
}

async function reloadOperationalPlatform(platform){
  if(!OPERATIONAL_PLATFORM_KEYS.includes(platform)) return {ok:false,code:'invalid_platform'};
  const tabs=await chrome.tabs.query({});
  const primary=await selectPrimaryOperationalTab(platform,tabs);
  if(!primary?.id) return {ok:false,code:'closed'};
  try{
    await chrome.tabs.reload(primary.id);
    await setPrimaryOperationalTab(platform,primary.id);
    return {ok:true,tabId:primary.id};
  }catch(_){ return {ok:false,code:'reload_failed'}; }
}

const VIENA_STATUS_PING_TIMEOUT_MS = 1500;

async function sendTabStatusPing(tabId){
  let timer=0;
  try{
    return await Promise.race([
      chrome.tabs.sendMessage(tabId,{type:'VIENA_RUNTIME_STATUS_PING'}),
      new Promise((_,reject)=>{ timer=setTimeout(()=>reject(new Error('status_ping_timeout')),VIENA_STATUS_PING_TIMEOUT_MS); })
    ]);
  }finally{
    if(timer) clearTimeout(timer);
  }
}

async function pingStatusTab(tab){
  if(!tab?.id) return {ok:false,reason:'no_tab'};
  try{
    const result=await sendTabStatusPing(tab.id);
    if(!result?.ok) return {ok:false,reason:'no_receiver'};
    const runtimeVersion=chrome.runtime.getManifest().version;
    const stale=result.version!==runtimeVersion || result.build!==VIENA_BUILD_ID;
    return {ok:true,stale,version:result.version||'',build:result.build||'',href:result.href||tab.url||''};
  }catch(error){
    return {ok:false,reason:String(error?.message||error)==='status_ping_timeout'?'timeout':'no_receiver'};
  }
}

async function getOperationalStatus(){
  const runtimeVersion=chrome.runtime.getManifest().version;
  const diskBuild=await readPackageBuild();
  const extensionNeedsReload=Boolean(diskBuild && diskBuild!==VIENA_BUILD_ID);
  const tabs=await chrome.tabs.query({});
  const keys=['viena','miraStats','miraCm','gpon','fuentes','moica2','grafana','metricas'];
  const platforms={};
  await Promise.all(keys.map(async key=>{
    const matches=tabs.filter(t=>platformForUrl(t.url)===key && t.id);
    if(!matches.length){ platforms[key]={open:false,needsReload:false,tabs:0}; return; }
    const primary=await selectPrimaryOperationalTab(key,matches);
    const loading=Boolean(primary && primary.status!=='complete');
    const checked=loading ? {ok:true,stale:false,href:primary?.url||'',version:'',build:''} : (primary ? await pingStatusTab(primary) : {ok:false,reason:'no_tab'});
    platforms[key]={
      open:true,
      loading,
      needsReload:loading ? false : (!checked?.ok||Boolean(checked?.stale)),
      tabs:matches.length,
      tabId:primary?.id||matches[0].id,
      primaryTabId:primary?.id||matches[0].id,
      url:checked?.href||primary?.url||matches[0].url||'',
      version:checked?.version||'',
      build:checked?.build||'',
      statusReason:checked?.reason||''
    };
  }));
  return {ok:true,runtimeVersion,runtimeBuild:VIENA_BUILD_ID,diskBuild,extensionNeedsReload,platforms,checkedAt:Date.now()};
}

async function setActionStateVisual(state,badge,title){
  await Promise.all([
    chrome.action.setBadgeText({text:badge?.text||''}),
    badge?.color ? chrome.action.setBadgeBackgroundColor({color:badge.color}) : Promise.resolve(),
    chrome.action.setTitle({title:title||'VIENA NOC Tools'}),
    applyExtensionIconState(state)
  ]);
}
async function refreshActionBadge(tabId=null){
  try{
    const diskBuild=await readPackageBuild();
    if(diskBuild && diskBuild!==VIENA_BUILD_ID){
      const b=STATUS_BADGES.reload;
      await setActionStateVisual('reload',b,b.title); return;
    }
    let tab=null;
    if(tabId){ try{tab=await chrome.tabs.get(tabId);}catch(_){} }
    if(!tab){ const arr=await chrome.tabs.query({active:true,currentWindow:true}); tab=arr[0]||null; }
    if(tab && platformForUrl(tab.url)){
      const ping=await pingStatusTab(tab);
      if(!ping.ok||ping.stale){
        const b=STATUS_BADGES.tabs;
        await setActionStateVisual('tabs',b,b.title); return;
      }
    }
    const state=await getUpdateState();
    if(state?.available){
      const b=STATUS_BADGES.update;
      await setActionStateVisual('update',b,`${b.title}: v${state.latest}`); return;
    }
    if(tab && platformForUrl(tab.url)){
      const b=STATUS_BADGES.on;
      await setActionStateVisual('on',b,b.title); return;
    }
    await setActionStateVisual('neutral',null,'VIENA NOC Tools');
  }catch(_){ }
}


const portableUpdateClient = VienaPortableDownload.create(fetch, chrome.runtime.getManifest().version);
const portableNoticeKey = 'viena_portable_update_offer';
let portableUpdateCheck, zipNoticeOpening;
let portableUpdateState = { available: false };

async function getUpdateState() {
  const installed = chrome.runtime.getManifest().version;
  return { installed, latest: installed, runtimeBuild: VIENA_BUILD_ID, channel: 'RELEASE',
    distribution: 'portable', ...portableUpdateState };
}

function checkUpdateInBackground() {
  if (portableUpdateCheck) return portableUpdateCheck;
  portableUpdateCheck = (async () => {
    try {
      const found = await portableUpdateClient.check();
      portableUpdateState = found.available ? { available: true, latest: found.version } : { available: false };
      void refreshActionBadge();
      if (found.available) {
        const previous = await chrome.storage.local.get([portableNoticeKey,'viena_portable_auto_zip_version']);
        const automatic = found.automatic ? found.version : null;
        if (previous[portableNoticeKey] !== found.version || previous.viena_portable_auto_zip_version !== automatic) {
          await chrome.storage.local.set({ [portableNoticeKey]: found.version, viena_portable_auto_zip_version:automatic });
        }
      }
      return { ok: true, state: await getUpdateState() };
    } catch (error) {
      return { ok: false, message: String(error.message || error), state: await getUpdateState() };
    } finally {
      portableUpdateCheck = null;
    }
  })();
  return portableUpdateCheck;
}

async function ensureUpdateAlarm() {
  if (!await chrome.alarms.get(UPDATE_ALARM)) {
    await chrome.alarms.create(UPDATE_ALARM, { delayInMinutes: 1, periodInMinutes: 30 });
  }
}

function runWorkerTask(label,task){
  Promise.resolve().then(task).catch(error=>{
    const message=String(error?.message||error||'');
    if(message==='No SW' || /Extension context invalidated|context.*invalid/i.test(message)) return;
    try{ console.warn('[VIENA SW]',label,message); }catch(_){}
  });
}
chrome.alarms.onAlarm.addListener(alarm=>{
  if(alarm?.name===UPDATE_ALARM) runWorkerTask('update_alarm',()=>checkUpdateInBackground());
  if(alarm?.name===INSTALL_REGISTRY_ALARM) runWorkerTask('registry_alarm',()=>sendInstallRegistryHeartbeat('alarm'));
  if(alarm?.name===INSTALL_REGISTRY_RETRY_ALARM) runWorkerTask('registry_retry',()=>sendInstallRegistryHeartbeat('retry'));
});
runWorkerTask('ensure_update_alarm',()=>ensureUpdateAlarm());
runWorkerTask('ensure_registry_alarm',()=>ensureInstallRegistryAlarm());


runWorkerTask('registry_service_worker',()=>sendInstallRegistryHeartbeat('service_worker'));


runWorkerTask('runtime_page_refresh',()=>reconcileCwsRuntimePages());


chrome.storage.onChanged.addListener((changes,area)=>{
  if(area==='local' && changes?.viena_usuario?.newValue) void sendInstallRegistryHeartbeat('usuario_changed');
});



const DESTINATION_CONFIGS = {
  'mira-stats': {
    url: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
    matches: u => u.hostname === 'mira5-gdt.telecentro.net.ar' && u.pathname.includes('stats_frontend.php')
  },
  'mira-cm': {
    url: 'https://mira5-gdt.telecentro.net.ar/cablemodem_frontend.php',
    matches: u => u.hostname === 'mira5-gdt.telecentro.net.ar' && u.pathname.includes('cablemodem_frontend.php')
  },
  'gpon': {
    url: 'https://monitoreogpon.telecentro.net.ar/#/listOnts',
    matches: u => u.hostname === 'monitoreogpon.telecentro.net.ar'
  },
  'fuentes': {
    url: 'https://fuentes.telecentro.net.ar/webs/home.php',
    matches: u => u.hostname === 'fuentes.telecentro.net.ar' && u.pathname.includes('/webs/home.php')
  },
  'moica': {
    url: 'https://moica2.telecentro.net.ar/buscarTicket.php',
    // Reutilizar únicamente la pantalla limpia de Buscar Ticket.
    // Una URL con ?ticket=... representa un ticket ya abierto y NO debe ser
    // secuestrada por una nueva búsqueda iniciada desde VIENA.
    matches: u =>
      u.hostname === 'moica2.telecentro.net.ar' &&
      u.pathname === '/buscarTicket.php' &&
      !u.search &&
      !u.hash
  },
  'grafana-vccap': {
    url: 'https://grafana-telemetria.telecentro.net.ar/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e?orgId=1',
    matches: u => u.hostname === 'grafana-telemetria.telecentro.net.ar' && u.pathname.startsWith('/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e')
  }
};

function preferredMatchingTab(tabs,cfg){
  const matches=tabs.filter(t=>{
    if(!t?.id) return false;
    try{return cfg.matches(new URL(t.url||''));}catch(_){return false;}
  });
  matches.sort((a,b)=>{
    if(Boolean(a.active)!==Boolean(b.active)) return a.active?-1:1;
    return Number(b.lastAccessed||0)-Number(a.lastAccessed||0) || Number(b.id||0)-Number(a.id||0);
  });
  return matches[0]||null;
}

function targetForBridgeCommand(command){
  const tipo=String(command?.tipo||'').toLowerCase();
  const tecnologia=String(command?.tecnologia||'').toUpperCase();
  if(tecnologia==='FTTH') return 'gpon';
  if(tecnologia==='HFC' && tipo==='nodo') return 'mira-stats';
  if(tecnologia==='HFC' && ['edificio','cliente','nodocm','nodolist'].includes(tipo)) return 'mira-cm';
  return '';
}

async function waitTabMatches(tabId,matches,timeout=18000,step=250){
  const start=Date.now();
  while(Date.now()-start<timeout){
    try{
      const tab=await chrome.tabs.get(tabId);
      const url=new URL(tab.url||'');
      if(matches(url)) return {ok:true,tab};
    }catch(_){ return {ok:false,code:'tab_unavailable'}; }
    await new Promise(r=>setTimeout(r,step));
  }
  return {ok:false,code:'navigation_timeout'};
}

async function prepareOpenedDestination(target,tabId){
  if(!tabId) return {ok:false,code:'missing_tab'};
  if(target!=='mira-stats' && target!=='moica') return {ok:true};

  const message=target==='mira-stats'
    ? {type:'VIENA_MIRA5_NAVIGATE',target}
    : {type:'VIENA_MOICA_NAVIGATE'};
  const delivered=await sendMessageWithRetry(tabId,message,{timeout:18000,step:300});
  if(!delivered.ok) return {ok:false,code:'receiver_unavailable'};
  if(!delivered.result?.ok) return {ok:false,code:delivered.result?.code||'navigation_failed'};

  const cfg=DESTINATION_CONFIGS[target];
  const reached=cfg ? await waitTabMatches(tabId,cfg.matches,18000,250) : {ok:true};
  return reached.ok ? {ok:true,navigated:Boolean(delivered.result?.navigated)} : reached;
}

async function ensureDestinationTab(target,{activate=true}={}){
  const cfg=DESTINATION_CONFIGS[target];
  if(!cfg) return {ok:false,code:'invalid_target'};
  const tabs=await chrome.tabs.query({});
  const existing=preferredMatchingTab(tabs,cfg);
  if(existing?.id){
    const current=await ensureOperationalTabRuntimeCurrent(existing.id);
    if(!current?.ok) return {ok:false,opened:false,navigated:false,tabId:existing.id,url:existing.url||cfg.url,code:current?.code||'reload_failed'};
    await rememberPrimaryOperationalTab(existing.id);
    return {ok:true,opened:false,navigated:false,reloaded:Boolean(current.reloaded),tabId:existing.id,url:existing.url||cfg.url};
  }

  // Primer acceso a MIRA5 puede redirigir stats_frontend.php al home/index.php.
  // Si ya existe ese landing, lo reutilizamos y entramos por el botón nativo Estadísticas.
  if(target==='mira-stats'){
    const landing=[...tabs].filter(t=>{
      try{
        const u=new URL(t.url||'');
        return t?.id && u.hostname==='mira5-gdt.telecentro.net.ar' && (u.pathname==='/' || u.pathname.endsWith('/index.php'));
      }catch(_){return false;}
    }).sort((a,b)=>Boolean(b.active)-Boolean(a.active) || Number(b.lastAccessed||0)-Number(a.lastAccessed||0))[0];
    if(landing?.id){
      const current=await ensureOperationalTabRuntimeCurrent(landing.id);
      if(!current?.ok) return {ok:false,opened:false,navigated:false,tabId:landing.id,url:landing.url||cfg.url,code:current?.code||'reload_failed'};
      const prepared=await prepareOpenedDestination(target,landing.id);
      if(prepared?.ok){
        return {ok:true,opened:false,navigated:true,tabId:landing.id,url:landing.url||cfg.url};
      }
    }
  }

  // Primer acceso a MOICA2 puede aterrizar en /home.php. Si existe ese landing,
  // reutilizamos la pestaña y tocamos el enlace nativo "Buscar" hacia buscarTicket.php.
  if(target==='moica'){
    const landing=[...tabs].filter(t=>{
      try{
        const u=new URL(t.url||'');
        return t?.id && u.hostname==='moica2.telecentro.net.ar' && (u.pathname==='/' || u.pathname.endsWith('/home.php'));
      }catch(_){return false;}
    }).sort((a,b)=>Boolean(b.active)-Boolean(a.active) || Number(b.lastAccessed||0)-Number(a.lastAccessed||0))[0];
    if(landing?.id){
      const current=await ensureOperationalTabRuntimeCurrent(landing.id);
      if(!current?.ok) return {ok:false,opened:false,navigated:false,tabId:landing.id,url:landing.url||cfg.url,code:current?.code||'reload_failed'};
      const prepared=await prepareOpenedDestination(target,landing.id);
      if(prepared?.ok){
        return {ok:true,opened:false,navigated:true,tabId:landing.id,url:cfg.url};
      }
    }
  }

  const created=await chrome.tabs.create({url:cfg.url,active:Boolean(activate)});
  if(!created?.id) return {ok:false,opened:false,navigated:false,tabId:null,url:cfg.url};

  const prepared=await prepareOpenedDestination(target,created.id);
  if(!prepared?.ok && (target==='mira-stats' || target==='moica')){
    return {ok:false,opened:true,navigated:false,tabId:created.id,url:cfg.url,code:prepared?.code||'navigation_failed'};
  }

  await rememberPrimaryOperationalTab(created.id);
  return {ok:true,opened:true,navigated:Boolean(target==='mira-stats' || target==='moica'),reloaded:false,tabId:created.id,url:cfg.url};
}

async function sendMessageWithRetry(tabId,message,{timeout=20000,step=300}={}){
  const start=Date.now();
  let lastError=null;
  while(Date.now()-start<timeout){
    try{
      const result=await chrome.tabs.sendMessage(tabId,message);
      return {ok:true,result};
    }catch(error){
      lastError=error;
      await new Promise(r=>setTimeout(r,step));
    }
  }
  return {ok:false,error:lastError};
}


let moicaGeeInFlight = false;
async function runMoicaGee(value,sector='GEE',reuseAnalysis=false){
  if(!['GEE','GEC','GED'].includes(sector)) return {ok:false,code:'invalid_sector',mensaje:'El sector solicitado no es válido.'};
  const nodo=String(value||'').trim().toUpperCase();
  if(!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(nodo)) return {ok:false,code:'invalid_node',mensaje:'El ticket debe tener un único Nodo válido.'};
  if(moicaGeeInFlight) return {ok:false,code:'busy',mensaje:'Hay una consulta de nodo en curso. Esperá a que termine.'};
  moicaGeeInFlight=true;
  try{
    const cfg={url:'https://moica2.telecentro.net.ar/home.php#',matches:u=>u.hostname==='moica2.telecentro.net.ar'&&u.pathname==='/home.php'&&!u.search};
    const tabs=await chrome.tabs.query({});
    const existing=preferredMatchingTab(tabs,cfg);
    if(!existing) return {ok:true,viewer:true,nodo};
    const tab=existing;
    if(!tab?.id) return {ok:false,code:'open_failed',mensaje:'No se pudo abrir MOICA2.'};
    const deadline=Date.now()+60000;
    let refreshed=false;
    while(Date.now()<deadline){
      const current=await chrome.tabs.get(tab.id);
      let url;try{url=new URL(current.url||'');}catch(_){}
      if(url&&url.hostname==='moica2.telecentro.net.ar'&&/\/index\.php$/.test(url.pathname)) return {ok:false,code:'login_required',mensaje:'Iniciá sesión en MOICA2 y volvé a intentar.'};
      if(current.status!=='loading'&&url&&cfg.matches(url)){
        let state;
        try{state=await chrome.tabs.sendMessage(tab.id,{type:'VIENA_MOICA_GEE_RUN',nodo,sector,reuseAnalysis:reuseAnalysis===true});}catch(_){}
        if(state?.ok||state?.code) return {...state,tabId:tab.id};
        if(!state&&!refreshed){refreshed=true;await chrome.tabs.reload(tab.id);}
      }
      await new Promise(resolve=>setTimeout(resolve,250));
    }
    return {ok:false,code:'timeout',mensaje:'MOICA2 no quedó disponible a tiempo. Revisá la sesión y reintentá.'};
  }catch(error){console.warn('[VIENA GEE]',String(error?.message||error));return {ok:false,code:'unavailable',mensaje:'No se pudo completar la consulta ' + sector + '. Revisá MOICA2 y reintentá.'};}
  finally{moicaGeeInFlight=false;}
}

async function getFaviconBytes(pageUrl){
  try{
    const parsed=new URL(String(pageUrl||''));
    if(parsed.protocol!=='https:') return {ok:false,detail:'URL de favicon inválida'};
    const faviconUrl=chrome.runtime.getURL(`/_favicon/?pageUrl=${encodeURIComponent(parsed.href)}&size=32`);
    const response=await fetch(faviconUrl);
    if(!response.ok) return {ok:false,detail:`favicon HTTP ${response.status}`};
    const buffer=await response.arrayBuffer();
    if(!buffer.byteLength) return {ok:false,detail:'favicon vacío'};
    return {ok:true,mime:response.headers.get('content-type')||'image/png',bytes:Array.from(new Uint8Array(buffer))};
  }catch(error){
    return {ok:false,detail:String(error?.message||error)};
  }
}

// Self-Test Operativo (efoschi): enruta inspecciones de sólo lectura al destino abierto.
chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg?.type==='VIENA_RUNTIME_STATUS_HELLO'){
    if(!senderIsOperational(_sender)){ rejectUnauthorized(sendResponse); return; }
    void refreshActionBadge(_sender?.tab?.id||null);
    sendResponse({ok:true});
    return;
  }
  if(msg?.type==='VIENA_GET_OPERATIONAL_STATUS'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    getOperationalStatus().then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_INSTALL_REGISTRY_HEARTBEAT_NOW' || msg?.type==='VIENA_INSTALL_REGISTRY_SYNC_NOW'){
    if(!senderIsExtensionPage(_sender) && !senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    sendInstallRegistryHeartbeat(String(msg.reason||'manual')).then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_GET_INSTALL_REGISTRY_STATUS'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const keys=[INSTALL_REGISTRY_LAST_OK_KEY,INSTALL_REGISTRY_LAST_ERROR_KEY,INSTALL_REGISTRY_LAST_USER_KEY,INSTALL_REGISTRY_LAST_VERSION_KEY,INSTALL_REGISTRY_LAST_BUILD_KEY,INSTALL_REGISTRY_LAST_REASON_KEY,INSTALLATION_ID_KEY,'viena_usuario','viena_usuario_origen'];
      const st=await chrome.storage.local.get(keys);
      const alarm=await chrome.alarms.get(INSTALL_REGISTRY_ALARM);
      return {ok:true,lastOk:Number(st[INSTALL_REGISTRY_LAST_OK_KEY]||0),lastError:String(st[INSTALL_REGISTRY_LAST_ERROR_KEY]||''),lastUser:String(st[INSTALL_REGISTRY_LAST_USER_KEY]||''),lastVersion:String(st[INSTALL_REGISTRY_LAST_VERSION_KEY]||''),lastBuild:String(st[INSTALL_REGISTRY_LAST_BUILD_KEY]||''),lastReason:String(st[INSTALL_REGISTRY_LAST_REASON_KEY]||''),installationId:String(st[INSTALLATION_ID_KEY]||''),usuario:String(st.viena_usuario||''),origen:String(st.viena_usuario_origen||''),alarmNext:Number(alarm?.scheduledTime||0)};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_DETECT_USER_NOW'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const usuario=await detectVienAUserFromOpenTab();
      if(usuario) await chrome.storage.local.set({viena_usuario:usuario,viena_usuario_origen:'auto'});
      return {ok:true,usuario:usuario||''};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_PLATFORM_ACTION'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    const platform=String(msg.platform||'');
    const action=String(msg.action||'');
    const job=action==='open' ? openOperationalPlatform(platform,{background:Boolean(msg.background)})
      : action==='reload' ? reloadOperationalPlatform(platform)
      : Promise.resolve({ok:false,code:'invalid_action'});
    job.then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_REFRESH_ACTION_STATUS'){
    if(!senderIsExtensionPage(_sender) && !senderIsOperational(_sender)){ rejectUnauthorized(sendResponse); return; }
    refreshActionBadge(_sender?.tab?.id||null).then(()=>sendResponse({ok:true})).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_GET_FAVICON_BYTES'){
    if(!senderIsExtensionPage(_sender) && !senderIsOperational(_sender)){ rejectUnauthorized(sendResponse); return; }
    getFaviconBytes(msg.pageUrl).then(sendResponse).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_EXTENSION_ICON_GET'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    chrome.storage.local.get([EXTENSION_ICON_VARIANT_KEY]).then(st=>sendResponse({ok:true,variant:normalizeExtensionIconVariant(st[EXTENSION_ICON_VARIANT_KEY]||'1')})).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_EXTENSION_ICON_SET'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    applyExtensionIconVariant(msg.variant,{persist:true}).then(variant=>sendResponse({ok:true,variant})).catch(e=>sendResponse({ok:false,detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_BRIDGE_AVAILABLE'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const target=String(msg.target||'');
      const ensured=await ensureDestinationTab(target);
      if(!ensured?.ok||!ensured.tabId) return {ok:false,code:ensured?.code||'open_failed'};
      const ping=await sendMessageWithRetry(ensured.tabId,{type:'VIENA_BRIDGE_PING_DIRECT',target},{timeout:ensured.opened||ensured.navigated||ensured.reloaded?18000:2500,step:250});
      return ping.ok && ping.result?.ok ? {ok:true,tabId:ensured.tabId,opened:!!ensured.opened,navigated:!!ensured.navigated} : {ok:false,code:'receiver_unavailable',tabId:ensured.tabId};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_BRIDGE_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const command=msg.command&&typeof msg.command==='object'?msg.command:null;
      const target=targetForBridgeCommand(command);
      if(!target) return {ok:false,estado:'error',mensaje:'Destino inválido.'};
      const ensured=await ensureDestinationTab(target);
      if(!ensured?.ok||!ensured.tabId) return {ok:false,estado:'sin_respuesta',mensaje:'No se pudo abrir la página destino.'};
      const delivered=await sendMessageWithRetry(ensured.tabId,{type:'VIENA_BRIDGE_RUN',command,target},{timeout:22000,step:250});
      if(!delivered.ok) return {ok:false,estado:'sin_respuesta',mensaje:'La página destino no respondió. Recargá esa pestaña.'};
      return {...(delivered.result||{ok:false,estado:'error'}),tabId:ensured.tabId,opened:!!ensured.opened,navigated:!!ensured.navigated};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,estado:'error',mensaje:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_FUENTES_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const nodo=String(msg.nodo||'').trim().toUpperCase();
      const modo=String(msg.modo||'fuentes').toLowerCase();
      if(!nodo) return {ok:false,code:'invalid_node'};
      const ensured=await ensureDestinationTab('fuentes');
      if(!ensured?.ok||!ensured.tabId) return {ok:false,code:ensured?.code||'open_failed'};
      const delivered=await sendMessageWithRetry(ensured.tabId,{type:'VIENA_FUENTES_RUN',nodo,modo,...(msg.idFuente ? {idFuente:msg.idFuente} : {})},{timeout:22000,step:250});
      if(!delivered.ok) return {ok:false,code:'receiver_unavailable'};
      return {...(delivered.result||{ok:false}),tabId:ensured.tabId,opened:!!ensured.opened};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_ENSURE_DESTINATION'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    ensureDestinationTab(String(msg.target||'')).then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',detail:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_MOICA_GEE_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    runMoicaGee(msg.nodo,msg.sector,msg.reuseAnalysis===true).then(sendResponse).catch(()=>sendResponse({ok:false,code:'error',mensaje:'No se pudo consultar MOICA2.'}));
    return true;
  }
  if(msg?.type==='VIENA_MOICA_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const nodo=String(msg.nodo||'').trim().toUpperCase();
      if(!nodo)return {ok:false,code:'invalid_node',mensaje:'Nodo inválido para MOICA.'};
      const ensured=await ensureDestinationTab('moica');
      if(!ensured?.ok||!ensured.tabId){
        return {ok:false,code:ensured?.code||'open_failed',mensaje:'No se pudo abrir MOICA Buscar Ticket.'};
      }
      const delivered=await sendMessageWithRetry(ensured.tabId,{type:'VIENA_MOICA_SEARCH_RUN',nodo},{timeout:22000,step:250});
      if(!delivered.ok){
        return {ok:false,code:'receiver_unavailable',mensaje:'MOICA está abierto, pero el receptor de VIENA NOC Tools no respondió. Recargá esa pestaña.'};
      }
      return delivered.result?.ok ? {...delivered.result,opened:Boolean(ensured.opened),navigated:Boolean(ensured.navigated)} : {ok:false,code:delivered.result?.code||'search_failed',mensaje:delivered.result?.mensaje||'MOICA recibió la orden pero no pudo iniciar la búsqueda.'};
    })().then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',mensaje:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_GRAFANA_VCCAP_SEARCH'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    (async()=>{
      const nodo=String(msg.nodo||'').trim().toUpperCase();
      const cos=String(msg.cos||'').trim();
      if(!nodo||!cos)return {ok:false,code:'invalid',mensaje:'Nodo o COS inválido.'};

      const ensured=await ensureDestinationTab('grafana-vccap');
      if(!ensured?.ok||!ensured.tabId){
        return {ok:false,code:'open_failed',mensaje:'No se pudo abrir el dashboard VCCAP de Grafana.'};
      }

      const message={type:'VIENA_GRAFANA_VCCAP_RUN',nodo,cos};
      if(ensured.opened || ensured.reloaded){
        const delivered=await sendMessageWithRetry(ensured.tabId,message,{timeout:25000,step:300});
        if(!delivered.ok){
          return {ok:false,code:'receiver_unavailable',mensaje:'Grafana se abrió, pero el receptor de VIENA NOC Tools no quedó disponible a tiempo.'};
        }
        const result=delivered.result;
        return result?.ok ? result : {ok:false,code:'failed',mensaje:result?.mensaje||'Grafana recibió la orden pero no pudo completar el filtro.'};
      }

      try{
        const result=await chrome.tabs.sendMessage(ensured.tabId,message);
        return result?.ok ? result : {ok:false,code:'failed',mensaje:result?.mensaje||'Grafana recibió la orden pero no pudo completar el filtro.'};
      }catch(error){
        return {ok:false,code:'receiver_unavailable',mensaje:'Grafana ya está abierto, pero no respondió. Verificá la sesión o recargá esa pestaña.'};
      }
    })().then(sendResponse).catch(e=>sendResponse({ok:false,code:'error',mensaje:String(e?.message||e)}));
    return true;
  }

  if(msg?.type==='VIENA_PORTABLE_START_ZIP_UPDATE'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar']) || _sender.frameId!==0){
      rejectUnauthorized(sendResponse); return;
    }
    if(zipNoticeOpening){sendResponse({ok:false});return;}
    zipNoticeOpening=true;
    (async()=>{
      const state=await chrome.storage.local.get([portableNoticeKey,'viena_portable_auto_zip_version']);
      const version=state[portableNoticeKey];
      if(!version || msg.version!==version || state.viena_portable_auto_zip_version!==version)return {ok:false};
      const key='viena_portable_auto_zip_started';
      const session=await chrome.storage.session.get(key);
      if(session[key]===version)return {ok:true};
      await chrome.tabs.create({url:chrome.runtime.getURL('manual-update.html')+'?auto='+encodeURIComponent(version)});
      await chrome.storage.session.set({[key]:version});
      return {ok:true};
    })().then(sendResponse,()=>sendResponse({ok:false})).finally(()=>{zipNoticeOpening=false;});
    return true;
  }

  if(msg?.type==='VIENA_PORTABLE_OPEN_UPDATES'){
    if(!senderIsOperational(_sender,['viena.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    chrome.tabs.create({url:chrome.runtime.getURL('manual-update.html')+'?check=1'})
      .then(()=>sendResponse({ok:true}),()=>sendResponse({ok:false}));
    return true;
  }

  if(msg?.type==='VIENA_UPDATE_GET_CACHED_STATE'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    getUpdateState()
      .then(state=>sendResponse({ok:true,state:{...(state||{}),runtimeBuild:VIENA_BUILD_ID}}))
      .catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_UPDATE_CHECK_NOW'){
    if(!senderIsExtensionPage(_sender)){ rejectUnauthorized(sendResponse); return; }
    checkUpdateInBackground()
      .then(result=>sendResponse(result?.ok?{...result,state:{...(result.state||{}),runtimeBuild:VIENA_BUILD_ID}}:result))
      .catch(e=>sendResponse({ok:false,error:String(e?.message||e)}));
    return true;
  }
  if(msg?.type==='VIENA_BUILDING_TEMPLATES_OPEN'){
    if(!senderIsOperational(_sender,['mira5-gdt.telecentro.net.ar'])){ rejectUnauthorized(sendResponse); return; }
    let source;try{source=new URL(_sender.url||_sender.tab?.url||'')}catch(_){rejectUnauthorized(sendResponse);return;}
    if(source.pathname!=='/cablemodem_frontend.php'){rejectUnauthorized(sendResponse);return;}
    chrome.tabs.create({url:chrome.runtime.getURL('popup.html?full=1#building-templates'),active:true})
      .then(()=>sendResponse({ok:true})).catch(error=>sendResponse({ok:false,detail:String(error?.message||error)}));
    return true;
  }
});

chrome.runtime.onInstalled.addListener(details=>{if(details?.reason==='install')void chrome.tabs.create({url:chrome.runtime.getURL('cws-migration.html?detect=1')}).catch(()=>{});});
