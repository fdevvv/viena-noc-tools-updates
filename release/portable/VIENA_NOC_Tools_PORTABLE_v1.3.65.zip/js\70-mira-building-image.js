/* MIRA5: imagen completa del edificio filtrado. Sólo por acción del operador. */
(function () {
  'use strict';
  const value=(row,key)=>row[key]??key.split('.').reduce((v,k)=>v?.[k],row);
  const text=v=>String(v??'').replace(/\s+/g,' ').trim();
  function identity(rows,id){
    if(!rows.length||rows.some(r=>text(value(r,'infocliente.edificio.idedificio'))!==id))throw Error('Los resultados no corresponden al edificio filtrado. Aplicá el filtro nuevamente.');
    const nodes=new Map(),addresses=new Set();
    for(const row of rows){const node=text(value(row,'cmNodo.nodoCmts')).toUpperCase(),address=[text(value(row,'infocliente.calle')),text(value(row,'infocliente.nro'))].filter(Boolean).join(' ');if(!node||!address)throw Error('Faltan el nodo o la dirección del edificio.');nodes.set(node,(nodes.get(node)||0)+1);addresses.add(address);}
    const ranked=[...nodes].sort((a,b)=>b[1]-a[1]);
    if(addresses.size!==1||ranked[1]?.[1]===ranked[0][1])throw Error('El nodo o la dirección no son únicos. Revisá el edificio antes de capturar.');
    return {id,node:ranked[0][0],address:[...addresses][0]};
  }
  function filename(info,now=new Date()){
    const date=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-');
    const clean=v=>text(v).replace(/[<>:"/\\|?*\x00-\x1f]/g,'-').replace(/[. ]+$/g,'').slice(0,65);
    return [clean(info.node),clean(info.id),clean(info.address),date].join(' - ')+'.png';
  }
  async function allRows(config,read,current){
    const url=new URL(config.url,config.origin),size=Number(config.rowNum),count=Number(config.records);
    if(url.origin!==config.origin||url.pathname!=='/controller_grid_mira_cm.php'||!Number.isSafeInteger(size)||size<1||!Number.isSafeInteger(count)||count<1)throw Error('No se pudo verificar el listado. Aplicá el filtro de edificio nuevamente.');
    const rows=[],seen=new Set(),names=config.prmNames||{},total=Math.ceil(count/size);
    for(let page=1;page<=total;page++){
      if(!current())throw Error('Cambió el listado. Volvé a abrir la captura.');
      const params=new URLSearchParams();for(const [k,v]of Object.entries(config.postData||{})){if(typeof v==='function'||v&&typeof v==='object')throw Error('El filtro no es compatible con esta captura.');if(v!==undefined)params.set(k,String(v));}
      params.set(names.page||'page',page);params.set(names.rows||'rows',size);params.set(names.sort||'sidx',config.sortname||'');params.set(names.order||'sord',config.sortorder||'asc');
      // Keep MIRA's model/defaultFilter query bytes: reserializing the entire
      // URL expands its 80-column model and the server rejects it with HTTP414.
      const query=new URL(url),native=url.search?url.search.slice(1).split('&').filter(part=>!params.has(new URLSearchParams(part).keys().next().value)):[];
      query.search=[...native,params.toString()].join('&');
      const response=await read(query);
      if(!current())throw Error('Cambió el listado. Volvé a abrir la captura.');
      if(Number(response.page)!==page||Number(response.total)!==total||Number(response.records)!==count||!Array.isArray(response.rows)||response.rows.length!==Math.min(size,count-rows.length))throw Error('La respuesta está incompleta o cambió el total de CMs. Reintentá la captura.');
      for(const row of response.rows){const mac=text(value(row,'mac')).toLowerCase();if(!/^[a-f0-9]{12}$/.test(mac)||seen.has(mac)||text(value(row,'infocliente.edificio.idedificio'))!==config.id)throw Error('Hay CMs repetidos o de otro edificio. Reaplicá el filtro antes de capturar.');seen.add(mac);rows.push(row);}
    }
    identity(rows,config.id);return rows;
  }
  function deadline(operation,ms,message,late){return new Promise((resolve,reject)=>{
    let expired=false;const timer=setTimeout(()=>{expired=true;reject(Error(message));},ms);
    Promise.resolve(operation).then(result=>{clearTimeout(timer);if(expired){if(late)Promise.resolve(late(result)).catch(()=>{});}else resolve(result);},error=>{clearTimeout(timer);reject(error);});
  });}
  async function saveUnique(directory,blob,name,ms=15000){
    const end=Date.now()+ms,step=(p,late)=>deadline(p,Math.max(1,end-Date.now()),'La carpeta no respondió a tiempo. Revisá el archivo antes de reintentar.',late);let next=name,index=0;
    for(;;){try{await step(directory.getFileHandle(next));}catch(error){if(error.name==='NotFoundError')break;throw error;}next=name.replace(/\.png$/i,' ('+(++index)+').png');}
    const file=await step(directory.getFileHandle(next,{create:true})),writer=await step(file.createWritable(),late=>late.abort());
    try{await step(writer.write(blob));await step(writer.close());}catch(error){try{Promise.resolve(writer.abort()).catch(()=>{});}catch{}throw error;}return next;
  }
  if(typeof module==='object'&&module.exports){module.exports={identity,filename,allRows,saveUnique,partFilename,verifyCapture,frameGeometry,captureFailure,appliedBuildingId};return;}
  if(location.hostname!=='mira5-gdt.telecentro.net.ar'||location.pathname!=='/cablemodem_frontend.php'||window.__VIENA_BUILDING_IMAGE__)return;
  window.__VIENA_BUILDING_IMAGE__=true;
  const $=window.jQuery;let task=null,folder=null,folderLoaded=false;
  function captureAccess(op,signal){return new Promise((resolve,reject)=>{
    const id=Array.from(crypto.getRandomValues(new Uint8Array(16)),n=>n.toString(16).padStart(2,'0')).join('');
    let timer;const finish=(error,result)=>{clearTimeout(timer);window.removeEventListener('message',receive);signal?.removeEventListener('abort',cancel);error?reject(error):resolve(result);};
    const cancel=()=>finish(new DOMException('Captura cancelada.','AbortError'));
    const receive=e=>{if(e.source!==window||e.origin!==location.origin||e.data?.type!=='VIENA_BUILDING_CAPTURE_REPLY'||e.data.id!==id)return;
      if(!e.data.ok){const error=Error(e.data.code==='permission_required'?'Habilitá la captura de imágenes para continuar.':e.data.code==='inactive_tab'?'Mantené esta pestaña de MIRA activa mientras se captura.':'No se pudo capturar la pestaña. Volvé a intentar.');finish(error);}else if(op==='capture'&&(typeof e.data.image!=='string'||!e.data.image.startsWith('data:image/png;base64,')))finish(Error('No se pudo leer la imagen de Chrome.'));else finish(null,e.data);};
    window.addEventListener('message',receive);signal?.addEventListener('abort',cancel,{once:true});timer=setTimeout(()=>finish(Error('La captura no respondió a tiempo. Volvé a intentar.')),op==='authorize'?75000:10000);
    if(signal?.aborted){cancel();return;}window.postMessage({type:'VIENA_BUILDING_CAPTURE_REQUEST',id,op},location.origin);
  });}
  const el=(tag,label)=>{const n=document.createElement(tag);if(label!==undefined)n.textContent=label;return n;};
  function folderStore(mode,handle){return new Promise((resolve,reject)=>{
    let db,tx,done=false;const finish=(error,result)=>{if(done)return;done=true;clearTimeout(timer);db?.close();error?reject(error):resolve(result);};
    const timer=setTimeout(()=>{try{tx?.abort();}catch{}finish(Error('No se pudo acceder a la carpeta guardada.'));},8000);
    let request;try{request=indexedDB.open('viena-mira-building-images',1);}catch(error){finish(error);return;}
    request.onupgradeneeded=()=>{if(!done)request.result.createObjectStore('destination');else request.transaction.abort();};request.onerror=()=>finish(request.error);request.onblocked=()=>finish(Error('Cerrá otras capturas y volvé a elegir la carpeta.'));
    request.onsuccess=()=>{db=request.result;if(done){db.close();return;}try{tx=db.transaction('destination',mode);const op=mode==='readonly'?tx.objectStore('destination').get('folder'):tx.objectStore('destination').put(handle,'folder');let result;op.onsuccess=()=>{result=op.result;};tx.oncomplete=()=>finish(null,result);tx.onerror=tx.onabort=()=>finish(tx.error||Error('No se pudo guardar la carpeta.'));}catch(error){finish(error);}};
  });}
  function signature(grid,form){const p=grid.p;return JSON.stringify({url:p.url,post:p.postData,page:p.page,records:p.records,sort:p.sortname,order:p.sortorder,columns:p.colModel.map(c=>[c.name,c.hidden]),form:Array.from(new FormData(form))});}
  function snapshot(){
    const grid=document.getElementById('grid_cm_gral'),form=document.getElementById('CMS-FORM-FILTRO'),p=grid?.p,id=text(form?.querySelector('input[name="idedificio"]')?.value);
    if(!p||!form||!/^\d+$/.test(id)||!p.records||grid.grid?.hDiv?.loading)throw Error('Filtrá un edificio y esperá a que termine de cargar el listado.');
    if(p.search||p.postData?._search===true||p.postData?._search==='true')throw Error('Quitá los filtros de columnas para incluir todos los CMs del edificio.');
    const extra=Array.from(form.elements).some(c=>c.name&&c.name!=='idedificio'&&((['text','search','number'].includes(c.type)&&text(c.value))||(c.type==='checkbox'&&c.checked)));
    if(extra)throw Error('Dejá sólo el filtro por ID de edificio para incluir todos sus CMs.');
    const visible=Array.from(grid.querySelectorAll('tr.jqgrow'));
    if(!visible.length||visible.some(row=>{const cell=row.querySelector('td[aria-describedby="grid_cm_gral_infocliente.edificio.idedificio"]');return text(cell?.getAttribute('title')||cell?.textContent)!==id;}))throw Error('Aplicá el filtro del edificio antes de capturar.');
    if(p.mtype&&p.mtype.toUpperCase()!=='GET'||typeof p.serializeGridData==='function'||p.jsonReader?.repeatitems!==false)throw Error('El formato del listado cambió. No se generó una imagen parcial.');
    const stamp=signature(grid,form);
    return {grid,form,id,p,stamp,config:{url:p.url,origin:location.origin,postData:{...p.postData},prmNames:{...p.prmNames},records:p.records,rowNum:p.rowNum,sortname:p.sortname,sortorder:p.sortorder,id},current:()=>grid.isConnected&&grid.p===p&&!grid.grid?.hDiv?.loading&&signature(grid,form)===stamp};
  }
  function styles(){if(document.getElementById('viena-building-image-style'))return;const s=el('style');s.id='viena-building-image-style';s.textContent=`
    [data-viena-building-image-modal]{position:fixed;inset:0;z-index:2147483600;display:grid;place-items:center;padding:16px;background:#091b31b8;overflow:auto;overscroll-behavior:contain;font:14px Arial,sans-serif;color:#19334c;box-sizing:border-box}
    [data-viena-building-image-card]{width:min(1120px,100%);min-width:0;box-sizing:border-box;height:auto;margin:0;padding:0;max-height:94vh;display:flex;flex-direction:column;background:#f5f8fc;border:1px solid #d5deea;border-radius:12px;box-shadow:0 15px 60px #0006;overflow:hidden}
    [data-viena-building-image-card] header{padding:14px 18px;background:#ed8a2e;color:#152b42;font-size:18px;font-weight:bold;display:flex;justify-content:space-between;align-items:center;gap:12px}
    [data-viena-building-image-actions]{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:12px 16px}
    [data-viena-building-image-card] button{font:inherit;padding:8px 12px;border:1px solid #a8b9cb;border-radius:6px;color:#19334c;background:#fff;cursor:pointer}
    [data-viena-building-image-card] button:disabled{opacity:.55;cursor:default}
    [data-viena-building-image-card] button:focus-visible{outline:3px solid #1683c9;outline-offset:2px}
    [data-viena-building-image-preview]{margin:0 16px;overflow:auto;min-height:80px;background:white;border:1px solid #c8d8e9;overscroll-behavior:contain;flex:1}
    [data-viena-building-image-preview] img{max-width:none;display:block}
    [data-viena-building-image-status]{padding:10px 16px;white-space:pre-wrap;overflow-wrap:anywhere}
    html[data-viena-theme=dark] [data-viena-building-image-card]{background:#24282d;color:#f2ece1;border-color:#78603a}
    html[data-viena-theme=dark] [data-viena-building-image-card] button{background:#393124;color:#f2ece1;border-color:#78603a}
    @media(max-width:540px){[data-viena-building-image-modal]{padding:8px}[data-viena-building-image-card] header{font-size:16px;padding:12px}}
  `;document.head.append(s);}
  function partFilename(info,index,total,now){
    if(!Number.isSafeInteger(total)||total<1||!Number.isSafeInteger(index)||index<1||index>total)throw Error('No se pudo numerar la captura completa.');
    const base=filename(info,now);return total===1?base:base.replace(/\.png$/i,' - Parte '+String(index).padStart(2,'0')+' de '+total+'.png');
  }
  function verifyCapture(track,origin,nonce){
    const handle=track?.getCaptureHandle?.();
    if(track?.readyState!=='live'||track.getSettings().displaySurface!=='browser'||handle?.origin!==origin||handle?.handle!==nonce)throw Error('Seleccioná esta misma pestaña de MIRA en el selector de Chrome.');
  }
  function frameGeometry(frame,viewport,reference){
    if(reference&&['width','height','dpr'].some(key=>viewport[key]!==reference[key]))throw Error('Cambió el tamaño de la ventana. Volvé a capturar.');
    if(![frame.width,frame.height,viewport.width,viewport.height].every(n=>Number.isFinite(n)&&n>0)||Math.abs(frame.height-frame.width*viewport.height/viewport.width)>2)throw Error('La imagen de Chrome no coincide con la pestaña. Volvé a capturar.');
    return {x:frame.width/viewport.width,y:frame.height/viewport.height};
  }
  function captureFailure(error,state){
    const dimensions=(value,keys)=>Object.fromEntries(keys.map(key=>[key,Number.isFinite(value?.[key])?value[key]:null]));
    const view=v=>dimensions(v,['width','height','dpr']),image=v=>dimensions(v,['width','height']);
    const message=String(error?.message||''),reason=message.startsWith('Cambió el tamaño')?'viewport':message.startsWith('Cambió el listado')?'context':message.startsWith('La imagen de Chrome')?'aspect':message.startsWith('No se pudo estabilizar')?'calibration':'other';
    return {diagnostic:'VIENA_BUILDING_CAPTURE_GEOMETRY_V1',reason,phase:['source','first-frame','calibration','page','photograph','finish'].includes(state.phase)?state.phase:'unknown',reference:view(state.reference),actual:view(state.actual),frame:image(state.frame),changed:(state.changed||[]).filter(k=>['url','post','records','size','sort','order','columns','form'].includes(k)),samples:(state.samples||[]).slice(-8).map(sample=>({viewport:view(sample.viewport),frame:image(sample.frame)}))};
  }
  function contextSignature(view,includeWidths=true){
    const p=view.p,post={...p.postData},names=p.prmNames||{};
    for(const k of [names.page||'page',names.rows||'rows',names.sort||'sidx',names.order||'sord',names.nd||'nd'])delete post[k];
    return JSON.stringify({url:p.url,post,records:p.records,size:p.rowNum,sort:p.sortname,order:p.sortorder,columns:p.colModel.map(c=>includeWidths?[c.name,c.hidden,c.width]:[c.name,c.hidden]),form:Array.from(new FormData(view.form))});
  }
  function nativePage(view,page){return new Promise((resolve,reject)=>{
    const grid=$(view.grid),ns='.vienaBuildingPhoto';let settled=false;
    const finish=error=>{if(settled)return;settled=true;clearTimeout(timer);grid.off(ns);error?reject(error):resolve();};
    const timer=setTimeout(()=>finish(Error('El listado no terminó de cargar. Volvé a intentar.')),20000);
    grid.on('jqGridLoadError'+ns,()=>finish(Error('No se pudo cargar una página del edificio.')));
    grid.on('jqGridGridComplete'+ns,()=>{if(Number(view.p.page)===page)finish();});
    try{grid.jqGrid('setGridParam',{page}).trigger('reloadGrid');}catch(error){finish(error);}
  });}
  async function render(view,operation){
    const original={page:Number(view.p.page),post:{...view.p.postData},selection:[...(view.p.selarrrow||[])],selected:view.p.selrow,focus:document.activeElement,x:scrollX,y:scrollY};
    const body=view.grid.grid?.bDiv,header=view.grid.grid?.hDiv,box=view.grid.closest('.ui-jqgrid');
    if(!body||!header||!box)throw Error('No se pudo verificar el encuadre de MIRA.');
    original.left=body.scrollLeft;original.top=body.scrollTop;
    let context=contextSignature(view),calibrating=true;const logicalContext=contextSignature(view,false);
    const sameData=()=>view.grid.isConnected&&view.grid.p===view.p&&contextSignature(view,false)===logicalContext;
    const same=()=>sameData()&&(calibrating||contextSignature(view)===context);
    const parts=[],rows=[],seen=new Set();let grabber,bitmap,viewport,mapping,expectedPage=original.page,canvas,used=0,scale,outputWidth,interrupted=false,active=false,complete=false,traversed=false;
    const readViewport=()=>({width:innerWidth,height:innerHeight,dpr:devicePixelRatio});
    const requestedViewport=readViewport();
    let phase='source';const samples=[];
    const sample=()=>{samples.push({viewport:readViewport(),frame:{width:bitmap?.width,height:bitmap?.height}});if(samples.length>8)samples.shift();};
    const rootStyle=document.documentElement.style,oldBehavior=rootStyle.getPropertyValue('scroll-behavior'),oldPriority=rootStyle.getPropertyPriority('scroll-behavior');
    const check=()=>{if(operation.cancelled||operation.controller.signal.aborted||interrupted||!same()||Number(view.p.page)!==expectedPage)throw Error('Cambió el listado o se canceló la foto. Volvé a capturar.');};
    const interrupt=event=>{if(event.type==='keydown'&&event.key==='Escape')event.preventDefault();interrupted=true;};
    const flush=async()=>{if(!used)return;const result=el('canvas');result.width=canvas.width;result.height=used;result.getContext('2d').drawImage(canvas,0,0);const blob=await deadline(new Promise((resolve,reject)=>result.toBlob(b=>b?resolve(b):reject(Error('No se pudo guardar la foto.')),'image/png')),8000,'No se pudo guardar la foto a tiempo.');parts.push({blob,width:result.width,height:result.height});result.width=result.height=1;used=0;canvas.getContext('2d').fillStyle='#fff';canvas.getContext('2d').fillRect(0,0,canvas.width,canvas.height);};
    const frame=async()=>{
      await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
      await new Promise(resolve=>setTimeout(resolve,160));check();
      bitmap?.close();bitmap=await deadline(grabber.grabFrame(),5000,'La foto dejó de recibir imágenes. Volvé a intentar.',late=>late.close());sample();check();
      mapping=frameGeometry(bitmap,readViewport(),viewport);
    };
    const append=async band=>{
      const maxHeight=canvas.height;let y=0;
      while(y<band.height){if(used===maxHeight)await flush();const height=Math.min(band.height-y,maxHeight-used);canvas.getContext('2d').drawImage(band,0,y,band.width,height,0,used,band.width,height);used+=height;y+=height;}
      band.width=band.height=1;
    };
    const photograph=async(rectangle,scroller)=>{
      phase='photograph';
      const initial=rectangle(),width=Math.round(initial.width),height=Math.round(initial.height);
      if(!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1)throw Error('No se pudo medir el listado completo.');
      // Native pagination may widen the table after the first page was photographed.
      // Grow the output without scaling or clipping the photographs already stored.
      if(width>outputWidth){
        const nextWidth=Math.round(width*scale),nextHeight=Math.min(canvas.height,Math.floor(40000000/nextWidth));
        if(nextWidth>30000||nextHeight<1)throw Error('El listado es demasiado ancho para guardarlo.');
        if(used>nextHeight)await flush();
        const expanded=el('canvas');expanded.width=nextWidth;expanded.height=nextHeight;
        const context=expanded.getContext('2d');context.fillStyle='#fff';context.fillRect(0,0,nextWidth,nextHeight);
        if(used)context.drawImage(canvas,0,0,canvas.width,used,0,0,canvas.width,used);
        canvas.width=canvas.height=1;canvas=expanded;outputWidth=width;
      }
      const band=el('canvas');band.width=Math.round(width*scale);band.height=Math.round(height*scale);
      if(band.height>30000||band.width*band.height>50000000)throw Error('El listado de esta página es demasiado grande. Elegí menos filas por página y reintentá.');
      const ctx=band.getContext('2d');let y=0;
      while(y<height){let x=0,stepY=Infinity;
        while(x<width){check();if(scroller){body.scrollLeft=x;body.scrollTop=scroller===body?y:0;header.scrollLeft=body.scrollLeft;}
          let r=rectangle();window.scrollTo({left:scrollX+r.left+x,top:scrollY+r.top+y,behavior:'instant'});
          await frame();r=rectangle();
          let right=document.documentElement.clientWidth,bottom=document.documentElement.clientHeight,left=0,top=0;
          if(scroller){const clip=scroller.getBoundingClientRect();left=Math.max(0,clip.left+scroller.clientLeft);top=Math.max(0,clip.top+scroller.clientTop);right=Math.min(right,clip.left+scroller.clientLeft+scroller.clientWidth);bottom=Math.min(bottom,clip.top+scroller.clientTop+scroller.clientHeight);}
          const sx=r.left+x,sy=r.top+y,w=Math.min(width-x,right-sx),h=Math.min(height-y,bottom-sy);
          if(sx<left-.6||sy<top-.6||w<1||h<1)throw Error('No se pudo fotografiar todo el listado. Revisá el zoom y el tamaño de la ventana.');
          const dx=Math.round(x*scale),dy=Math.round(y*scale),dw=Math.round((x+w)*scale)-dx,dh=Math.round((y+h)*scale)-dy;
          const sourceX=Math.round(sx*mapping.x),sourceY=Math.round(sy*mapping.y),sourceWidth=Math.round((sx+w)*mapping.x)-sourceX,sourceHeight=Math.round((sy+h)*mapping.y)-sourceY;
          ctx.drawImage(bitmap,sourceX,sourceY,sourceWidth,sourceHeight,dx,dy,dw,dh);x+=w;stepY=Math.min(stepY,h);
        }y+=stepY;
      }await append(band);
    };
    try{
      await captureAccess('authorize',operation.controller.signal);check();
      phase='first-frame';
      grabber={grabFrame:async()=>{const result=await captureAccess('capture',operation.controller.signal);check();return createImageBitmap(await(await fetch(result.image)).blob());}};
      operation.overlay.style.visibility='hidden';view.form.querySelector('[data-viena-building-image-button]').style.visibility='hidden';
      rootStyle.setProperty('scroll-behavior','auto','important');
      for(const name of ['pointerdown','wheel','keydown'])document.addEventListener(name,interrupt,{capture:true,passive:name==='wheel'});active=true;
      // Freeze each native layout only after it has settled; pagination can
      // legitimately resize widths without changing the data or visible columns.
      phase='calibration';let previous=null;
      for(let attempt=0;attempt<8;attempt++){
        await new Promise(resolve=>setTimeout(resolve,160));check();bitmap?.close();bitmap=await deadline(grabber.grabFrame(),8000,'No se pudo leer la foto de la pestaña.',late=>late.close());sample();check();
        const next=readViewport();let geometry;try{geometry=frameGeometry(bitmap,next);}catch(error){previous=null;if(attempt===7)throw error;continue;}
        const layout=contextSignature(view);
        if(previous&&['width','height','dpr'].every(key=>next[key]===previous[key])&&layout===previous.layout){viewport=next;mapping=geometry;context=layout;calibrating=false;break;}previous={...next,layout};
      }
      if(!viewport)throw Error('No se pudo estabilizar la ventana. Volvé a capturar.');scale=mapping.x;
      const tableHeader=header.querySelector('table');if(!tableHeader)throw Error('No se pudieron leer las columnas.');
      outputWidth=Math.round(Math.max(box.getBoundingClientRect().width,view.grid.getBoundingClientRect().width,tableHeader.getBoundingClientRect().width));
      const estimatedHeight=Math.ceil((box.getBoundingClientRect().top-view.form.getBoundingClientRect().top+100+Number(view.p.records)*Math.max(48,view.grid.querySelector('tr.jqgrow').getBoundingClientRect().height))*scale);
      const widthPx=Math.round(outputWidth*scale),maxHeight=Math.min(28000,Math.floor(40000000/widthPx),estimatedHeight);if(widthPx>30000||maxHeight<1)throw Error('El listado es demasiado ancho para guardarlo.');
      canvas=el('canvas');canvas.width=widthPx;canvas.height=maxHeight;canvas.getContext('2d').fillStyle='#fff';canvas.getContext('2d').fillRect(0,0,canvas.width,canvas.height);
      const total=Math.ceil(Number(view.p.records)/Number(view.p.rowNum));
      for(let page=1;page<=total;page++){
        phase='page';
        check();let resized=false;if(Number(view.p.page)!==page){expectedPage=page;calibrating=true;traversed=true;await nativePage(view,page);check();let previousLayout=null,stable=false;
          for(let attempt=0;attempt<8;attempt++){await new Promise(r=>setTimeout(r,160));check();frameGeometry(bitmap,readViewport(),viewport);const next=contextSignature(view);if(next===previousLayout){resized=next!==context;context=next;stable=true;break;}previousLayout=next;}
          if(!stable)throw Error('No se pudo estabilizar el listado. Volvé a capturar.');calibrating=false;check();}
        body.scrollTop=body.scrollLeft=header.scrollLeft=0;
        const visible=[...view.grid.querySelectorAll('tr.jqgrow')];
        if(visible.length!==Math.min(Number(view.p.rowNum),Number(view.p.records)-rows.length))throw Error('La respuesta está incompleta. No se guardó una foto parcial.');
        for(const tr of visible){const row={};for(const key of ['mac','infocliente.edificio.idedificio','cmNodo.nodoCmts','infocliente.calle','infocliente.nro']){const cell=tr.querySelector('td[aria-describedby="grid_cm_gral_'+CSS.escape(key)+'"]');row[key]=text(cell?.getAttribute('title')||cell?.textContent);}
          const mac=row.mac.toLowerCase();if(!/^[a-f0-9]{12}$/.test(mac)||seen.has(mac)||row['infocliente.edificio.idedificio']!==view.id)throw Error('Hay CMs repetidos o de otro edificio. Reaplicá el filtro.');seen.add(mac);rows.push(row);
        }
        if(page===1){await photograph(()=>{const a=view.form.getBoundingClientRect(),b=box.getBoundingClientRect();return {left:b.left,top:a.top,width:b.width,height:b.top-a.top};});await photograph(()=>tableHeader.getBoundingClientRect(),header);}
        else if(resized)await photograph(()=>tableHeader.getBoundingClientRect(),header);
        await photograph(()=>{const a=visible[0].getBoundingClientRect(),b=visible.at(-1).getBoundingClientRect();return {left:a.left,top:a.top,width:a.width,height:b.bottom-a.top};},body);
      }
      const pager=typeof view.p.pager==='string'?document.querySelector(view.p.pager):view.p.pager?.[0];if(pager)await photograph(()=>pager.getBoundingClientRect());
      phase='finish';check();const info=identity(rows,view.id);await flush();complete=true;return {parts,info,count:rows.length,scale};
    }catch(error){
      // Only structural measurements: no URLs, filter values, customers or handles.
      try{const before=JSON.parse(context),after=JSON.parse(contextSignature(view)),changed=Object.keys(before).filter(k=>JSON.stringify(before[k])!==JSON.stringify(after[k]));console.log('VIENA_BUILDING_CAPTURE_DIAGNOSTIC '+JSON.stringify(captureFailure(error,{phase,reference:viewport||requestedViewport,actual:readViewport(),frame:bitmap,changed,samples})));}catch{}
      throw error;
    }finally{
      bitmap?.close();
      try{if(sameData()&&Number(view.p.page)===expectedPage){if(Number(view.p.page)!==original.page||(!complete&&traversed))await nativePage(view,original.page);if(sameData()){view.p.postData={...original.post};$(view.grid).jqGrid('resetSelection');for(const id of original.selection.length?original.selection:original.selected?[original.selected]:[])$(view.grid).jqGrid('setSelection',id,false);body.scrollLeft=original.left;body.scrollTop=original.top;header.scrollLeft=original.left;window.scrollTo({left:original.x,top:original.y,behavior:'instant'});}}}finally{
        if(oldBehavior)rootStyle.setProperty('scroll-behavior',oldBehavior,oldPriority);else rootStyle.removeProperty('scroll-behavior');
        if(active)for(const name of ['pointerdown','wheel','keydown'])document.removeEventListener(name,interrupt,true);
        operation.overlay.style.visibility='';view.form.querySelector('[data-viena-building-image-button]')?.style.removeProperty('visibility');canvas&&(canvas.width=canvas.height=1);
      }
    }
  }
  async function open(){
    if(task)return;let view;try{view=snapshot();}catch(error){showNotice(error.message);return;}
    styles();const previous=document.activeElement,operation={cancelled:false,controller:new AbortController(),busy:true};task=operation;
    const overlay=el('div');overlay.dataset.vienaBuildingImageModal='';const card=el('section');card.dataset.vienaBuildingImageCard='';card.setAttribute('role','dialog');card.setAttribute('aria-modal','true');card.setAttribute('aria-label','Imagen del edificio');
    const heading=el('header','Imagen del edificio '+view.id),close=el('button','Cerrar'),actions=el('div');actions.dataset.vienaBuildingImageActions='';close.type='button';heading.append(close);
    const copy=el('button','Copiar imagen'),save=el('button','Guardar PNG'),choose=el('button','Elegir carpeta'),folderLabel=el('span','Carpeta sin elegir'),preview=el('div'),status=el('div','Preparando todos los CMs del edificio…');preview.dataset.vienaBuildingImagePreview='';status.dataset.vienaBuildingImageStatus='';status.setAttribute('role','status');for(const b of [copy,save,choose])b.type='button';copy.disabled=save.disabled=true;actions.append(copy,save,choose,folderLabel);card.append(heading,actions,preview,status);overlay.append(card);document.body.append(overlay);close.focus({preventScroll:true});
    let imageUrls=[],prepared=null,writing=false;const start=el('button','Capturar pantalla');start.type='button';start.dataset.vienaBuildingPhotoStart='';actions.prepend(start);operation.overlay=overlay;operation.busy=false;status.textContent='La foto incluirá todos los CMs del edificio. Mantené esta pestaña activa mientras se captura; Escape cancela.';
    const current=()=>!operation.cancelled&&view.current();
    const valid=()=>{if(!prepared||!current())throw Error('Cambió el filtro o el listado. Cerrá esta vista y volvé a capturar el edificio.');};
    const syncFolder=()=>{folderLabel.textContent=folder?'Carpeta: '+folder.name:'Carpeta sin elegir';choose.textContent=folder?'Cambiar carpeta':'Elegir carpeta';};
    const ready=(async()=>{if(!folderLoaded){folder=await folderStore('readonly');folderLoaded=true;}syncFolder();})().catch(()=>{status.textContent='No se pudo leer la carpeta guardada. Podés elegirla nuevamente.';});
    close.onclick=()=>{if(writing){status.textContent='Esperá a que termine de guardar el archivo.';return;}operation.cancelled=true;operation.controller.abort();overlay.remove();imageUrls.forEach(url=>URL.revokeObjectURL(url));operation.stream?.getTracks().forEach(t=>t.stop());operation.work?.remove();operation.frame?.remove();if(!operation.busy&&task===operation)task=null;previous?.focus?.({preventScroll:true});};
    overlay.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();close.click();}if(event.key==='Tab'){const buttons=[...card.querySelectorAll('button:not(:disabled)')];if(event.shiftKey&&document.activeElement===buttons[0]){event.preventDefault();buttons.at(-1).focus();}else if(!event.shiftKey&&document.activeElement===buttons.at(-1)){event.preventDefault();buttons[0].focus();}}});
    choose.onclick=async()=>{if(writing)return;choose.disabled=true;try{if(typeof window.showDirectoryPicker!=='function')throw Error('Este navegador no permite elegir una carpeta. Usá Chrome actualizado.');const next=await (globalThis.VienaPermissionUI ? globalThis.VienaPermissionUI.folder({id:'viena-mira-building-images',mode:'readwrite'}) : window.showDirectoryPicker({id:'viena-mira-building-images',mode:'readwrite'}));await ready;if(operation.cancelled)return;await folderStore('readwrite',next);folder=next;folderLoaded=true;syncFolder();status.textContent='Carpeta guardada para las próximas imágenes.';}catch(error){if(error.name!=='AbortError')status.textContent='No se pudo guardar la carpeta. Volvé a elegirla.';}finally{choose.disabled=false;}};
    copy.onclick=async()=>{copy.disabled=true;try{valid();if(typeof ClipboardItem!=='function'||!navigator.clipboard?.write)throw Error('Chrome no permite copiar la imagen en esta página. Podés guardar el PNG.');if(prepared.parts.length!==1)throw Error('El edificio tiene varias imágenes. Guardá los PNG para conservar todos los CMs.');await deadline(navigator.clipboard.write([new ClipboardItem({'image/png':prepared.parts[0].blob})]),10000,'La copia no respondió a tiempo.');status.textContent='Imagen copiada. Ya podés pegarla.';}catch(error){status.textContent=error.message?.startsWith('Cambió')?error.message:'No se pudo copiar la imagen. Podés reintentar o guardar el PNG.';}finally{copy.disabled=!prepared||operation.cancelled;}};
    save.onclick=async()=>{if(writing)return;writing=true;save.disabled=choose.disabled=true;try{valid();await ready;if(!folder){status.textContent='Elegí primero la carpeta donde querés guardar las imágenes.';return;}const permission=await folder.queryPermission({mode:'readwrite'});if(permission!=='granted'&&await (globalThis.VienaPermissionUI ? globalThis.VienaPermissionUI.request(folder) : folder.requestPermission({mode:'readwrite'}))!=='granted')throw Error('Permití el acceso a la carpeta o elegí otra.');valid();const name=await navigator.locks.request('viena-building-image-save',{ifAvailable:true},lock=>{if(!lock)throw Error('Hay otra imagen guardándose. Reintentá cuando termine.');valid();return (async()=>{const saved=[];for(let i=0;i<prepared.parts.length;i++){valid();const name=partFilename(prepared.info,i+1,prepared.parts.length);saved.push(await saveUnique(folder,prepared.parts[i].blob,name));}return saved.join(', ');})();});status.textContent='Guardado en '+folder.name+': '+name;}catch(error){status.textContent=error.name==='NotAllowedError'?'Permití el acceso a la carpeta o elegí otra.':/^(Cambió|La carpeta|Permití|Hay otra imagen)/.test(error.message)?error.message:'No se pudo guardar el PNG. Revisá la carpeta y volvé a intentarlo.';}finally{writing=false;save.disabled=!prepared;choose.disabled=false;}};
    start.onclick=async()=>{
      if(operation.busy||writing||choose.disabled)return;operation.busy=true;start.disabled=choose.disabled=true;prepared=null;copy.disabled=save.disabled=true;imageUrls.forEach(url=>URL.revokeObjectURL(url));imageUrls=[];preview.replaceChildren();
      const timeout=setTimeout(()=>operation.controller.abort(),300000);
      try{
        if(!view.current())throw Error('Cambió el listado. Cerrá y volvé a abrir la captura.');
        const result=await render(view,operation);if(operation.cancelled)return;
        if(!view.current())throw Error('Cambió el listado. Volvé a capturar.');prepared=result;
        for(const part of result.parts){const url=URL.createObjectURL(part.blob);imageUrls.push(url);const image=el('img');image.src=url;image.alt='Edificio '+view.id+' · captura real';image.style.width=part.width/result.scale+'px';preview.append(image);}
        status.textContent=result.count+' CMs incluidos en '+result.parts.length+' imagen'+(result.parts.length===1?'':'es')+'. Captura de la pantalla real.';copy.disabled=result.parts.length!==1;save.disabled=false;
      }catch(error){if(!operation.cancelled)status.textContent=error.name==='NotAllowedError'?'No se habilitó la captura. Podés volver a intentar.':error.name==='AbortError'?'Captura cancelada. Podés volver a intentar.':error.message||'No se pudo capturar la pantalla.';}
      finally{clearTimeout(timeout);operation.busy=false;operation.controller=new AbortController();start.disabled=choose.disabled=false;if(operation.cancelled&&task===operation)task=null;}
    };
  }

  function showNotice(message){styles();let notice=document.querySelector('[data-viena-building-image-notice]');if(notice){clearTimeout(notice._timer);notice.remove();}notice=el('div',message);notice.dataset.vienaBuildingImageNotice='';notice.setAttribute('role','status');notice.style.cssText='position:fixed;bottom:20px;left:20px;right:20px;max-width:650px;background:#19334c;color:white;padding:14px;border-radius:8px;z-index:2147483601;font:14px Arial';document.body.append(notice);notice._timer=setTimeout(()=>notice.remove(),6000);}
  function appliedBuildingId(config,origin){
    try{const url=new URL(config.url,origin);if(url.origin!==origin||url.pathname!=='/controller_grid_mira_cm.php')return null;
      const raw=Object.prototype.hasOwnProperty.call(config.postData||{},'defaultFilter')?config.postData.defaultFilter:url.searchParams.get('defaultFilter');
      const filter=typeof raw==='string'?JSON.parse(raw):raw,id=filter?.['infocliente.edificio.idedificio'];return ['string','number'].includes(typeof id)&&/^\d+$/.test(text(id))?text(id):null;
    }catch{return null;}
  }
  function mount(){const form=document.getElementById('CMS-FORM-FILTRO'),submit=form?.querySelector('[type="submit"]'),grid=document.getElementById('grid_cm_gral');if(!submit||!grid||!$?.fn?.jqGrid)return;let button=form.querySelector('[data-viena-building-image-button]');if(!button){button=el('button','Imagen del edificio');button.type='button';button.className='btn btn-default';button.dataset.vienaBuildingImageButton='';button.addEventListener('click',open);submit.parentElement.append(button);}
    const id=text(form.querySelector('input[name="idedificio"]')?.value),rows=[...grid.querySelectorAll('tr.jqgrow')];
    const visible=/^\d+$/.test(id)&&grid.p?.records>0&&!grid.grid?.hDiv?.loading&&appliedBuildingId(grid.p,location.origin)===id&&rows.length>0&&rows.every(row=>{const cell=row.querySelector('td[aria-describedby="grid_cm_gral_infocliente.edificio.idedificio"]');return text(cell?.getAttribute('title')||cell?.textContent)===id;});
    button.hidden=!visible;if(visible)button.style.removeProperty('display');else button.style.setProperty('display','none','important');
  }
  // Existing native ajax lifecycle; no global MutationObserver or polling.
  if($)$(document).on('ajaxComplete.vienaBuildingImage',mount);mount();
  document.getElementById('CMS-FORM-FILTRO')?.addEventListener('input',mount);
  document.getElementById('CMS-FORM-FILTRO')?.addEventListener('reset',()=>queueMicrotask(mount));
})();
