(() => {
  'use strict';
  // Isolated world: only width preferences cross the page boundary.
  const prefix = 'viena_table_widths_v1:' + location.origin + location.pathname + ':';
  const nameValid = key => typeof key === 'string' && key.length > 0 && key.length <= 300 &&
    !['__proto__', 'constructor', 'prototype'].includes(key);
  const valid = value => value && typeof value === 'object' && !Array.isArray(value) &&
    Object.keys(value).length <= 200 && Object.entries(value).every(([key, width]) =>
      nameValid(key) &&
      Number.isFinite(width) && width >= 16 && width <= 4000);
  document.addEventListener('VIENA_TABLE_WIDTHS_REQUEST', async event => {
    let request;
    try {
      if (typeof event.detail !== 'string' || event.detail.length > 24000) return;
      request = JSON.parse(event.detail);
      if (!request || typeof request.id !== 'string' || request.id.length > 100 ||
          typeof request.table !== 'string' || !request.table.length || request.table.length > 6000) return;
      const key = prefix + request.table;
      let columns;
      if (request.op === 'load') {
        if (!Array.isArray(request.columns) || request.columns.length > 200 || !request.columns.every(nameValid)) return;
        const keys = request.columns.map(name => key + ':' + JSON.stringify(name));
        const data = await chrome.storage.local.get(keys);
        columns = {};
        request.columns.forEach((name, i) => {
          const width = data[keys[i]];
          if (Number.isFinite(width) && width >= 16 && width <= 4000) columns[name] = width;
        });
      } else if (request.op === 'save' && valid(request.columns)) {
        // Separate keys avoid lost preferences when two tabs resize different columns.
        const values = Object.fromEntries(Object.entries(request.columns).map(([name, width]) =>
          [key + ':' + JSON.stringify(name), width]));
        await chrome.storage.local.set(values);
      } else return;
      document.dispatchEvent(new CustomEvent('VIENA_TABLE_WIDTHS_RESPONSE', {
        detail: JSON.stringify({id: request.id, ok: true, columns})
      }));
    } catch (_) {
      if (request?.id) document.dispatchEvent(new CustomEvent('VIENA_TABLE_WIDTHS_RESPONSE', {
        detail: JSON.stringify({id: request.id, ok: false})
      }));
    }
  });
})();
