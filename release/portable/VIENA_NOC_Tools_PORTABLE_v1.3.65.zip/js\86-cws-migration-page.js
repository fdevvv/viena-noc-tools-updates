(() => {
  'use strict';
  const $=id=>document.getElementById(id);
  const request=async(type,sourceId)=>{const result=await chrome.runtime.sendMessage({type,sourceId});if(!result?.ok)throw Error(result?.error||'No se pudo completar la migración.');return result.value;};
  const migration={discover:()=>request('VIENA_CWS_MIGRATION_DISCOVER'),importSource:sourceId=>request('VIENA_CWS_MIGRATION_IMPORT',sourceId)};
  let busy=false;
  const status=text=>{$('status').textContent=text;};
  const update=()=>{$('import').disabled=busy||!$('approve').checked||!$('source').value;};
  $('approve').addEventListener('change',update);$('source').addEventListener('change',()=>{$('approve').checked=false;update();});
  async function detect(askPermission){
    if(busy)return;busy=true;$('detect').disabled=true;$('choice').hidden=true;
    try{
      if(askPermission&&!await chrome.permissions.request({permissions:['management']})){status('No se concedió el permiso. Tus datos permanecen en la instalación original.');return;}
      if(!askPermission&&!await chrome.permissions.contains({permissions:['management']})){
        status('Para buscar otra instalación, pulsá Buscar mi instalación anterior. Si tenés un archivo JSON, podés importar el respaldo.');
        return;
      }
      const previous=(await chrome.storage.local.get(VienaCwsMigration.KEY))[VienaCwsMigration.KEY];
      if(previous&&!askPermission){status('Ya hay un traslado registrado. Pulsá Buscar mi instalación anterior para revisarlo.');return;}
      if(previous){const done=await migration.importSource(previous.sourceId);status(`Configuración ya trasladada. Macros VIENA: ${done.macros.viena}; MOICA: ${done.macros.moica}. No se volvieron a copiar tus preferencias.`);return;}
      status('Buscando instalaciones compatibles…');const sources=await migration.discover();$('source').replaceChildren();
      if(!sources.length){status('No se encontró otra instalación compatible. Si tus datos no aparecen, importá un respaldo de la instalación anterior.');return;}
      if(sources.length>1)$('source').append(new Option('Elegí la instalación que tiene tus datos',''));
      for(const item of sources)$('source').append(new Option(`${item.name} · ${item.version} · ${item.id}`,item.id));
      $('approve').checked=false;$('choice').hidden=false;status('Seleccioná el origen y confirmá el traslado. No se mezclarán instalaciones.');
    }catch(error){status(error.message||'No se pudo buscar la instalación anterior.');}
    finally{busy=false;$('detect').disabled=false;update();}
  }
  $('detect').addEventListener('click',()=>void detect(true));
  if(new URLSearchParams(location.search).has('detect'))void detect(false);
  $('import').addEventListener('click',async()=>{
    if(busy||!$('approve').checked||!$('source').value)return;busy=true;$('detect').disabled=true;update();status('Trasladando y verificando tu configuración…');
    try{const done=await migration.importSource($('source').value);$('choice').hidden=true;status(`Configuración trasladada y verificada. Macros VIENA: ${done.macros.viena}; MOICA: ${done.macros.moica}. La instalación original quedó desactivada y conserva sus datos. Abrí nuevamente el panel para ver tus preferencias.`);}
    catch(error){status(error.message||'No se pudo completar el traslado. Conservá la instalación original.');}
    finally{busy=false;$('detect').disabled=false;update();}
  });
})();
