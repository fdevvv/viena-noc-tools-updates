(() => {
    'use strict';
    const frames=new Map(),queues=new Map(),running=new Map(),depth=new Map();let sequence=0;
    const origin=chrome.runtime.getURL('').replace(/\/$/,'');
    window.addEventListener('message',event=>{
        if(event.data?.type!=='VIENA_NODE_HIDDEN_READY'||event.ports.length!==1)return;
        for(const frame of frames.values()){
            if(event.source!==frame.element.contentWindow||event.origin!==frame.origin)continue;
            frame.port?.close();
            const port=event.ports[0];
            frame.port=port;
            port.onmessage=({data})=>{if(frame.port===port)frame.receive?.(data);};
            frame.send?.();
            break;
        }
    });
    function destination(msg){
        const url=new URL(msg.url);
        const key=msg.kind==='mira'?'mira':msg.kind==='grafana'?'grafana':'fuentes';
        const allowed=key==='mira'?url.hostname==='mira5-gdt.telecentro.net.ar'&&url.pathname==='/stats_frontend.php':key==='fuentes'?url.hostname==='fuentes.telecentro.net.ar'&&url.pathname==='/webs/home.php':url.hostname==='grafana-telemetria.telecentro.net.ar'&&url.pathname.startsWith('/d/');
        if(url.protocol!=='https:'||url.username||url.password||url.port||!allowed)throw Error('Destino inválido.');
        return {key,url};
    }
    async function read(msg,deadline){
        if(Date.now()>=deadline)return {ok:false,message:'La consulta venció. Reintentá con Actualizar.'};
        const {key,url}=destination(msg);
        let frame=frames.get(key);
        if(!frame){
            const element=document.createElement('iframe');
            element.width='1280';element.height='900';element.src=url.href;
            frame={element,origin:url.origin};
            frames.set(key,frame);document.body.append(element);
        }
        const id=String(++sequence)+'-'+crypto.randomUUID();
        const result=await new Promise(resolve=>{
            let poll,timer;
            const done=data=>{clearInterval(poll);clearTimeout(timer);frame.receive=null;frame.send=null;resolve(data);};
            running.set(key,{node:msg.node,cos:msg.cos,cancel:()=>frame.port?.postMessage({type:'VIENA_NODE_HIDDEN_CANCEL',id,parentOrigin:origin})});
            frame.receive=data=>{
                if(data?.type!=='VIENA_NODE_HIDDEN_RESULT'||data.id!==id)return;
                done(data.result);
            };
            frame.send=()=>frame.port?.postMessage({type:'VIENA_NODE_HIDDEN_QUERY',id,kind:msg.kind,node:msg.node,cos:msg.cos,parentOrigin:origin});
            poll=setInterval(frame.send,300);frame.send();
            timer=setTimeout(()=>done({ok:false,message:'La plataforma no respondió en segundo plano. Abrila para revisar el acceso y volvé a Actualizar.'}),Math.max(1,deadline-Date.now()));
        });
        // A failed frame must not retain an unfinished query or stale login.
        running.delete(key);
        if(!result?.ok||result.data?.needsSession||result.data?.pending||result.data?.unsupported){frame.port?.close();frame.element.remove();frames.delete(key);}
        return result;
    }
    chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
        if(msg?.type!=='VIENA_NODE_HIDDEN_READ'||sender.id!==chrome.runtime.id||sender.tab||sender.url!==chrome.runtime.getURL('background.js'))return;
        if(!['mira','fuente','optico','rphy','grafana'].includes(msg.kind)||!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(msg.node)||typeof msg.cos!=='string'||msg.cos.length>100||/[\r\n]/.test(msg.cos))return;
        let key;try{key=destination(msg).key;}catch(_){reply({ok:false,message:'Destino inválido.'});return;}
        if((depth.get(key)||0)>=2){reply({ok:false,message:'Hay una consulta en curso. Reintentá con Actualizar.'});return;}
        const current=running.get(key);
        if(current&&current.node===msg.node&&current.cos===msg.cos&&key==='grafana'){reply({ok:false,message:'Hay una consulta en curso. Reintentá con Actualizar.'});return;}
        if(key==='grafana'&&current&&(current.node!==msg.node||current.cos!==msg.cos))current.cancel();
        depth.set(key,(depth.get(key)||0)+1);
        const deadline=Date.now()+(msg.kind==='grafana'?75000:40000);
        const next=(queues.get(key)||Promise.resolve()).then(()=>read(msg,deadline));queues.set(key,next.catch(()=>{}));
        next.then(reply).catch(()=>reply({ok:false,message:'No se pudo consultar la plataforma en segundo plano.'})).finally(()=>depth.set(key,depth.get(key)-1));return true;
    });
})();
