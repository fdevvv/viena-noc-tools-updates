(function () {
    'use strict';
    const unique = values => [...new Set(values)];
    function clients(text) {
        const tokens = String(text).replace(/(^|[\s,;/|])(?:ID[ \t]+CLIENTE|CLIENTES?|ID)(?:[ \t]*[:#=][ \t]*|\s+)/gi, '$1').split(/[\s,;/|]+/).filter(Boolean);
        return { ids: unique(tokens.filter(value => /^\d+$/.test(value))), invalid: unique(tokens.filter(value => !/^\d+$/.test(value))) };
    }
    function clientRefreshOnly(callback) {
        if (typeof callback !== 'function') return false;
        const source = Function.prototype.toString.call(callback);
        if (!/^function\s*\(\s*data\s*\)\s*\{/.test(source)) return false;
        // Ignore formatting between tokens, never spaces inside selectors/strings.
        const normalize = value => (value.match(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'|[^\s]/g) || [])
            .map(token => /^["']/.test(token) && !token.includes('\\') ? JSON.stringify(token.slice(1, -1)) : token).join('');
        // Exact success callback freshly supplied by MOICA's operator (trace44).
        // A changed callback keeps all native behavior; no guessed side effects.
        const body = `{if (data != null) {if (("noses" in data)) window.location.replace("index.php?msg=LogIn")};
            if (data.error == "") {fillModalVerTicket($('#TKT-VER-ID').val());changeTab("TAB-CLI");$('#grid_CliRel').trigger('reloadGrid');}
            else {$('#DIV-MSG-TKT-VER').html(data.error);$('#DIV-MSG-TKT-VER').css("display", "block");}}`;
        return normalize(source.slice(source.indexOf('{'))) === normalize(body);
    }
    function nodeOptions(values) {
        const result = values.filter(Boolean).map(value => {
            const parts = value.split('%%');
            if (parts.length !== 4 || !parts[1] || !parts[2] || !['HFC', 'FTTH'].includes(parts[3])) throw new Error('El selector de nodos cambió. No se cargó ninguna zona.');
            return { value, crm: parts[1], side: parts[2], technology: parts[3] };
        });
        if (!result.length || unique(result.map(item => item.crm)).length !== 1 || unique(result.map(item => item.technology)).length !== 1 || unique(result.map(item => item.side)).length !== result.length) throw new Error('Las opciones del nodo son ambiguas.');
        return result;
    }
    function selections(wanted, options, whole = false) {
        const sides = options.filter(item => item.side !== 'COMPLETO');
        if (whole) {
            if (options.length !== 1 || options[0].side !== 'COMPLETO' || options[0].technology !== 'FTTH' || wanted.length !== 1 || options[0].crm !== wanted[0]) throw new Error('No se pudo verificar el nodo FTTH exacto.');
            return [options[0].value];
        }
        if (!wanted.length || wanted.some(value => !sides.some(item => item.side === value))) throw new Error('No se encontraron todos los lados solicitados.');
        const complete = options.find(item => item.side === 'COMPLETO');
        return unique(wanted).length === sides.length && complete ? [complete.value] : unique(wanted).map(value => sides.find(item => item.side === value).value);
    }
    function covered(zone, zones) {
        return zones.some(item => item.nodo_crm === zone.nodo_crm && (item.nodo_cmts === zone.nodo_cmts || item.nodo_cmts === 'COMPLETO'));
    }
    if (typeof module === 'object' && module.exports) { module.exports = { clients, clientRefreshOnly, nodeOptions, selections, covered }; return; }
    if (location.hostname !== 'moica2.telecentro.net.ar' || !['/buscarTicket.php', '/home.php'].includes(location.pathname) || globalThis.__VIENA_MOICA_TICKET_LISTS__) return;
    const $ = globalThis.jQuery, parser = globalThis.VienaMoicaZoneParsing, base = globalThis.VienaNodeTech;
    if (typeof $ !== 'function' || !parser || !base) return;
    const byId = id => document.getElementById(id);
    const anchors = [byId('BT-ZONA-TKT'), byId('BT-CLI-CLI-TKT')];
    if (anchors.some(element => !element)) return;
    globalThis.__VIENA_MOICA_TICKET_LISTS__ = true;
    const visible = element => element && element.isConnected && !element.hidden && getComputedStyle(element).display !== 'none' && element.getClientRects().length > 0;
    let session = null;
    const uncertainTickets = new Map();
    const blockedClientReads = new Set();
    let clearFeedback = () => {};
    function feedback(message) {
        clearFeedback();
        const element = byId('DIV-MSG-TKT-VER-SUCCESS');
        if (!element) return;
        const owner = $(byId('TKT-VER-ID').closest('.modal-content'));
        const parent = owner.closest('.modal');
        element.textContent = message; element.style.display = 'block';
        const clear = () => {
            clearTimeout(timer); owner.off('hide.bs.modal.vienaTicketList', clear);
            parent.off('hide.bs.modal.vienaTicketList', clear);
            if (element.textContent === message) { element.textContent = ''; element.style.display = 'none'; }
        };
        // Bootstrap hide bubbles from the parent modal; a short lifetime also
        // covers native flows which reuse the ticket DOM without that event.
        owner.on('hide.bs.modal.vienaTicketList', clear);
        parent.on('hide.bs.modal.vienaTicketList', clear);
        const timer = setTimeout(() => { clear(); parent.off('hide.bs.modal.vienaTicketList', clear); }, 5000);
        clearFeedback = () => { clear(); parent.off('hide.bs.modal.vienaTicketList', clear); };
    }
    const buttons = anchors.map((anchor, index) => {
        const button = document.createElement('button');
        button.type = 'button'; button.className = 'jsTabButton btn btn-primary btn-sm viena-ticket-list-button';
        button.id = index ? 'viena-ticket-list-clients' : 'viena-ticket-list-nodes';
        button.textContent = index ? 'Cargar listado clientes' : 'Cargar listado nodos';
        button.style.marginRight = '4px';
        anchor.before(button);
        const mirror = () => { button.style.display = anchor.style.display || ''; button.hidden = anchor.hidden; button.disabled = anchor.disabled || Boolean(session?.active); };
        // Only native permission/tab buttons are observed, never the document tree.
        new MutationObserver(mirror).observe(anchor, { attributes: true, attributeFilter: ['style', 'hidden', 'disabled'] });
        mirror(); button.addEventListener('click', () => open(index ? 'clients' : 'nodes', button));
        return button;
    });
    const style = document.createElement('style');
    style.textContent = `.viena-ticket-list-button{white-space:normal!important}#viena-ticket-list-review{box-sizing:border-box;width:min(620px,calc(100vw - 24px));max-height:85vh;overflow:auto;border:1px solid #a6bdd3;border-radius:10px;padding:18px;background:#fff;color:#24324a;font:14px/1.5 Arial,sans-serif}#viena-ticket-list-review::backdrop{background:rgba(15,35,60,.45)}#viena-ticket-list-review h4{margin:0 0 10px}#viena-ticket-list-review textarea{box-sizing:border-box;width:100%;min-height:140px;resize:vertical;margin:8px 0}#viena-ticket-list-review .list-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}#viena-ticket-list-review button{white-space:normal}#viena-ticket-list-review pre{white-space:pre-wrap;overflow-wrap:anywhere;background:inherit;color:inherit;max-height:25vh;overflow:auto}#viena-ticket-list-review .list-warning{border:2px solid #a65300;border-radius:6px;padding:10px;background:#fff3df;color:#653000;overflow-wrap:anywhere}#viena-ticket-list-review [hidden]{display:none!important}#viena-ticket-list-review :focus-visible{outline:2px solid #1769aa;outline-offset:2px}@media(prefers-color-scheme:dark){#viena-ticket-list-review{background:#16243a;color:#e5edf7;border-color:#526780}#viena-ticket-list-review textarea{background:#20324c;color:#e5edf7}#viena-ticket-list-review .list-warning{background:#382913;color:#ffe0a3;border-color:#e5a343}}`;
    document.head.append(style);
    function ticket() { return byId('TKT-VER-ID')?.value || ''; }
    function check(s, allowCancel = false) {
        if (session !== s || !s.dialog.isConnected || ticket() !== s.ticket || !visible(byId('TKT-VER-ID')?.closest('.modal-content'))) throw new Error('El ticket cambió o se cerró. Abrí nuevamente el listado.');
        if (!allowCancel && s.cancelled) throw new Error('Carga detenida. Revisá el resultado y los pendientes.');
        if (s.text.value !== s.snapshot) throw new Error('El listado cambió. Revisalo antes de continuar.');
    }
    async function wait(s, predicate, label, allowCancel = false) {
        const start = performance.now();
        while (true) {
            check(s, allowCancel);
            if (predicate()) return;
            if (performance.now() - start > 8000) throw new Error(`Tiempo agotado al ${label}. Esperá que termine MOICA antes de reintentar.`);
            await new Promise(resolve => setTimeout(resolve, 30));
        }
    }
    async function idle(s, allowCancel = false) { await wait(s, () => $.active === 0, 'esperar a MOICA', allowCancel); }
    function native(name, ...args) {
        if (typeof globalThis[name] !== 'function') throw new Error('La operación nativa no está disponible en este ticket.');
        return globalThis[name](...args);
    }
    // Observe only requests initiated synchronously by this native call; restore
    // jQuery immediately, before any asynchronous callback or other UI action.
    function capture(call, s) {
        const original = $.ajax, requests = [];
        $.ajax = function (...args) {
            const options = args[0];
            if (s?.mode === 'clients' && args.length === 1 && options?.data?.accion === 'REL-CLI-TKT' && options.data.idTicket === s.ticket && options.data.idCliente === s.current &&
                String(options.method || options.type).toUpperCase() === 'POST' && typeof options.url === 'string' && new URL(options.url, location.href).origin === location.origin &&
                new URL(options.url, location.href).pathname === '/scripts/ajaxTickets2.php' && clientRefreshOnly(options.success)) {
                const callback = options.success;
                args[0] = { ...options, success: function (data, ...rest) {
                    if (data && !('noses' in data) && data.error === '') s.needsClientRefresh = true;
                    else return callback.call(this, data, ...rest);
                } };
            }
            const request = original.apply(this, args); requests.push(request); return request;
        };
        try { call(); } finally { $.ajax = original; }
        if (requests.length !== 1) throw new Error('No se pudo identificar una consulta nativa única.');
        return requests[0];
    }
    async function request(s, call, writing = false) {
        check(s); await idle(s);
        const anchor = anchors[s.mode === 'clients' ? 1 : 0];
        // A native ticket refresh can return to Notes after changeTab('TAB-CLI').
        // Restore the native tab, then recheck its permission; never force CSS.
        if (writing && s.mode === 'clients' && !visible(anchor)) {
            native('changeTab', 'TAB-CLI'); await idle(s); check(s);
        }
        // cambiarVista('ZONA') hides the general toolbar intentionally. During
        // that view, validate the active native form rather than its hidden entry.
        const available = s.mode === 'nodes' && s.nativeView ? visible(byId('BUSCAR-NODO-DIV')) : visible(anchor);
        if (writing && (!available || anchor.disabled)) {
            s.permissionDenied = true;
            throw new Error('El botón nativo de MOICA no está disponible para cargar en este ticket. Revisá sus permisos y estado.');
        }
        let xhr;
        try { xhr = capture(call, writing ? s : null); }
        catch (error) { if (writing) s.uncertain = true; throw error; }
        let settled = false, data, failed;
        xhr.done(value => { data = value; settled = true; }).fail(() => { failed = true; settled = true; });
        try {
            // Once dispatched, a write must settle even if Stop was pressed.
            await wait(s, () => settled, 'confirmar la respuesta', writing);
        } catch (error) {
            xhr.abort();
            if (writing) { s.uncertain = true; error.message = 'No se pudo confirmar el guardado. Revisá el ticket antes de volver a cargar estos IDs.'; }
            throw error;
        }
        if (failed) { if (writing) s.uncertain = true; throw new Error(writing ? 'Respuesta no confirmada. Revisá el ticket antes de repetir la carga.' : 'MOICA no pudo completar la consulta.'); }
        if (!data || typeof data.error !== 'string' || data.noses) { if (writing) s.uncertain = true; throw new Error('MOICA no devolvió una confirmación válida. Revisá el ticket.'); }
        if (data.error) {
            if (writing && s.mode === 'nodes') s.uncertain = true;
            throw new Error(data.error);
        }
        return data;
    }
    async function suggestions(s, element, term) {
        check(s); await idle(s);
        const widget = $(element).data('ui-autocomplete') || $(element).data('autocomplete');
        if (!widget || typeof widget.options?.source !== 'function') throw new Error('La búsqueda nativa no está lista.');
        let done = false, items;
        const original = $.ajax, requests = [];
        $.ajax = function (...args) { const xhr = original.apply(this, args); requests.push(xhr); return xhr; };
        try { widget.options.source.call(element, { term }, values => { if (!done) { items = values; done = true; } }); }
        finally { $.ajax = original; }
        try { await wait(s, () => done, `buscar ${term}`); await idle(s); }
        catch (error) { requests.forEach(xhr => xhr.abort()); throw error; }
        finally { done = true; }
        if (!Array.isArray(items)) throw new Error('La búsqueda no devolvió una lista válida.');
        return { widget, items };
    }
    async function choose(s, element, widget, item) {
        check(s); element.value = item.value || item.label;
        widget._trigger('select', new Event('autocompleteselect'), { item }); await idle(s);
    }
    function staged() {
        const list = byId('TKT-ZONA-LISTA');
        if (!list) throw new Error('La lista nativa de zonas no está disponible.');
        return [...list.querySelectorAll('.jsDatosZonas')].map(input => JSON.parse(input.value));
    }
    async function zones(s) {
        const data = await request(s, () => native('showZonasTab'));
        const result = data.data?.dataZona;
        if (!Array.isArray(result)) throw new Error('No se pudo verificar la lista de zonas del ticket.');
        return result;
    }
    async function nodes(s, ids) {
        const previous = await zones(s);
        // Never replace a different native zone type or discard a manual draft.
        const type = byId('TKT-VER-TIPO-ZONA-INI')?.value;
        if (type !== 'NODO') throw new Error('Este ticket no tiene zonas de tipo Nodo. La carga no cambia su tipo.');
        if (staged().length) throw new Error('Hay zonas preparadas manualmente. Guardalas o descartalas antes de usar el listado.');
        const nodeInput = byId('TKT-NODO-autocom-ADD'), select = byId('TKT-NODO-CMTS-ADD');
        if (!nodeInput || !select || select.getAttribute('onchange')?.replace(/\s/g, '') !== 'selectNodoParaDiv(this.value)') throw new Error('El selector nativo de nodos no está disponible.');
        native('cambiarVista', 'ZONA'); await idle(s);
        if (!visible(byId('BUSCAR-NODO-DIV'))) throw new Error('MOICA no permite agregar nodos en este ticket.');
        s.nativeView = true; s.ownedStage = byId('TKT-ZONA-LISTA').innerHTML;
        const remaining = new Set(ids), groups = [], notFound = [];
        while (remaining.size) {
            const node = remaining.values().next().value; let found;
            for (let length = node.length; length >= 4 && !found; length--) {
                s.status.textContent = `Buscando ${node}…`;
                const result = await suggestions(s, nodeInput, node.slice(0, length));
                const matches = result.items.filter(item => Array.isArray(item.nodoCmts) && (item.nodoCmts.includes(node) || item.label === node && item.tipoAcceso === 'FTTH' && item.nodoCmts.length === 0));
                if (matches.length > 1) throw new Error(`El nodo ${node} tiene más de una coincidencia. No se cargó ninguna zona.`);
                if (matches.length === 1) found = { ...result, item: matches[0] };
            }
            if (!found) { notFound.push(node); remaining.delete(node); continue; }
            const whole = found.item.label === node && found.item.tipoAcceso === 'FTTH' && !found.item.nodoCmts.length;
            const wanted = whole ? [node] : [...remaining].filter(value => found.item.nodoCmts.includes(value));
            await choose(s, nodeInput, found.widget, found.item);
            const options = nodeOptions([...select.options].map(option => option.value));
            const sides = options.filter(item => item.side !== 'COMPLETO').map(item => item.side);
            if (unique(found.item.nodoCmts).length !== sides.length || found.item.nodoCmts.some(value => !sides.includes(value))) throw new Error(`La búsqueda y el selector de ${node} no coinciden.`);
            groups.push({ ...found, wanted, whole, values: selections(wanted, options, whole) });
            wanted.forEach(value => remaining.delete(value));
        }
        if (notFound.length) throw new Error(`MOICA no encontró: ${notFound.join(', ')}. No se guardó ninguna zona.`);
        const expected = [];
        for (const group of groups) for (const value of group.values) {
            const parts = value.split('%%'), zone = { nodo_crm: parts[1], nodo_cmts: parts[2] };
            expected.push(zone);
            if (covered(zone, previous)) continue;
            await choose(s, nodeInput, group.widget, group.item);
            if (!selections(group.wanted, nodeOptions([...select.options].map(option => option.value)), group.whole).includes(value)) throw new Error('Las opciones del nodo cambiaron.');
            if (byId('TKT-ZONA-LISTA').innerHTML !== s.ownedStage) throw new Error('La selección nativa cambió durante la carga.');
            select.value = value; select.dispatchEvent(new Event('change', { bubbles: true }));
            s.ownedStage = byId('TKT-ZONA-LISTA').innerHTML;
            if (!covered(zone, staged())) throw new Error(`MOICA no agregó ${zone.nodo_cmts}.`);
        }
        if (!staged().length) { s.status.textContent = 'Todos los nodos ya estaban asociados. No se guardaron duplicados.'; return true; }
        const current = await zones(s);
        if (JSON.stringify(current) !== JSON.stringify(previous)) throw new Error('Las zonas cambiaron. Revisá el ticket antes de cargar.');
        s.status.textContent = 'Guardando los nodos…';
        await request(s, () => native('addZonasTicket'), true); s.committed = true;
        await idle(s, true);
        // Readback may continue after Stop, because the native write already ran.
        const wasCancelled = s.cancelled; s.cancelled = false;
        let after;
        try { after = await zones(s); } finally { s.cancelled = wasCancelled; }
        if (!expected.every(zone => covered(zone, after)) || !previous.every(zone => covered(zone, after))) { s.uncertain = true; throw new Error('El guardado respondió, pero no se verificaron todos los nodos o las zonas anteriores. Revisá el ticket antes de repetir.'); }
        s.status.textContent = `Nodos asociados y verificados: ${ids.join(', ')}.`; return true;
    }
    async function clientRows(s, id) {
        if (!/^\d+$/.test(id)) throw new Error('No se pudo identificar el cliente a verificar.');
        if (blockedClientReads.has(s.ticket)) {
            s.clientReadUnavailable = true;
            throw new Error('La consulta anterior no terminó a tiempo. Esperá que MOICA responda y recargá la página antes de volver a consultar.');
        }
        await idle(s, true);
        const grid = byId('grid_CliRel');
        if (!grid || typeof $(grid).jqGrid !== 'function') throw new Error('La lista de clientes relacionados no está disponible.');
        const p = $(grid).jqGrid('getGridParam');
        // Initial datatype=local does not imply that later native AJAX reloads
        // populate p.data. Remote pages and toolbar filters are not full lists.
        if (!p?.url) {
            const rows = $(grid).jqGrid('getGridParam', 'data');
            if (!Array.isArray(rows) || rows.some(row => row.idCliente == null)) throw new Error('No se pudo verificar la lista completa de clientes.');
            return rows.filter(row => String(row.idCliente) === id);
        }
        const names = p.prmNames, reader = p.jsonReader;
        if (!reader || reader.repeatitems !== false || !names?.page || !names.rows || !names.search || !names.filter || new URL(p.url, location.href).origin !== location.origin) throw new Error('No se pudo verificar el contrato de búsqueda de clientes.');
        // Current native toolbar contract supplied by the operator (trace42):
        // AND/idCliente/cn, page 1, 10 rows, original street sort. Never scan
        // all associations or sort by _id; that request blocked MOICA in trace41.
        const query = { ...p.postData };
        delete query.searchField; delete query.searchOper; delete query.searchString;
        query[names.page] = 1; query[names.rows] = 10; query[names.search] = true;
        query[names.filter] = JSON.stringify({ groupOp: 'AND', rules: [{ field: 'idCliente', op: 'cn', data: id }] });
        if (names.sort) query[names.sort] = p.sortname;
        if (names.order) query[names.order] = p.sortorder;
        if (names.nd) query[names.nd] = Date.now();
        const xhr = $.ajax({ url: p.url, type: p.mtype || 'GET', dataType: 'json', data: typeof p.serializeGridData === 'function' ? p.serializeGridData.call(grid, query) : query });
        let settled = false, data, failed;
        xhr.done(value => { data = value; settled = true; }).fail(() => { failed = true; settled = true; });
        try { await wait(s, () => settled, `verificar el cliente ${id}`, true); }
        catch (error) {
            xhr.abort();
            blockedClientReads.add(s.ticket); s.clientReadUnavailable = true;
            throw error;
        }
        if (failed || !data || data.error || data.noses) throw new Error('MOICA no pudo consultar el cliente. No se confirma la asociación.');
        const read = field => typeof field === 'function' ? field(data) : String(field).split('.').reduce((value, key) => value?.[key], data);
        const rawRows = read(reader.root), rawRecords = read(reader.records), rawTotal = read(reader.total);
        const records = Number(rawRecords), page = Number(read(reader.page)), total = Number(rawTotal);
        // Native empty response observed in trace43: rows:null, records:0,
        // total:0, page:"1". Missing/contradictory metadata is not absence.
        const rows = rawRows === null && (rawRecords === 0 || rawRecords === '0') && (rawTotal === 0 || rawTotal === '0') && page === 1 ? [] : rawRows;
        if (!Array.isArray(rows) || rows.length > 10 || rows.some(row => row.idCliente == null) || !Number.isInteger(records) || records < rows.length || !Number.isInteger(total) || total < 0 || records && page !== 1) throw new Error('MOICA no devolvió un resultado válido para el cliente.');
        const exact = rows.filter(row => String(row.idCliente) === id);
        if (exact.length) return exact;
        // cn may match a different ID containing the digits. Absence is proven
        // only when all matches fit this one native-sized page; never paginate.
        if (records !== rows.length || total > 1) throw new Error(`Hay más coincidencias para ${id}. Revisá el ID completo antes de cargarlo.`);
        return [];
    }
    async function loadClients(s, ids) {
        renderResults(s, ids);
        const input = byId('TKT-CLI-ID-CLIENTE');
        if (!input) throw new Error('El ingreso nativo de cliente no está disponible.');
        const saved = input.value;
        try {
            for (const id of ids) {
                // Keep Stop and painting responsive even for already-associated IDs.
                await new Promise(resolve => setTimeout(resolve, 0));
                check(s);
                let accepted = false;
                let checked = false;
                s.timing.currentStarted = performance.now();
                try {
                    s.status.textContent = `Verificando cliente ${id}…`;
                    s.results.set(id, 'Verificando'); renderResults(s, ids, id);
                    if ((await clientRows(s, id)).length) { s.results.set(id, 'Ya relacionado'); renderResults(s, ids, id); continue; }
                    checked = true;
                    s.current = id; s.status.textContent = `Cargando cliente ${id}…`;
                    s.results.set(id, 'Cargando'); renderResults(s, ids, id);
                    input.value = id; input.dispatchEvent(new Event('input', { bubbles: true }));
                    s.pendingVerification = { id };
                    await request(s, () => native('relacionarClienteTicket'), true);
                    accepted = true;
                    await idle(s, true);
                    let rows;
                    try { rows = (await clientRows(s, id)).map(row => String(row.idCliente)); }
                    catch (error) { s.uncertain = true; throw error; }
                    if (!rows.includes(id)) { s.uncertain = true; throw new Error(`MOICA respondió, pero no se pudo confirmar la asociación del cliente ${id}.`); }
                    s.pendingVerification = null;
                    s.results.set(id, 'Cargado y verificado');
                } catch (error) {
                    if (accepted) s.uncertain = true;
                    if (!s.uncertain) s.pendingVerification = null;
                    s.results.set(id, s.uncertain ? 'Sin confirmar: revisar ticket' : `No cargado: ${error.message}`);
                    renderResults(s, ids, id);
                    if (!checked || s.permissionDenied || s.uncertain || s.cancelled || ticket() !== s.ticket) throw error;
                } finally {
                    const elapsed = performance.now() - s.timing.currentStarted;
                    s.timing.average = s.timing.done ? s.timing.average * 0.7 + elapsed * 0.3 : elapsed;
                    s.timing.done++;
                    s.timing.currentStarted = performance.now();
                    updateProgress(s);
                }
                renderResults(s, ids, id);
            }
        } finally { if (ticket() === s.ticket && input.value === s.current) input.value = saved; }
        s.current = ''; const failures = [...s.results.values()].filter(value => value.startsWith('No cargado')).length;
        const existing = [...s.results].filter(([, value]) => value === 'Ya relacionado').map(([id]) => id);
        s.status.textContent = failures ? `${failures} cliente(s) no cargados. Revisá el detalle; los éxitos se conservan.` : `Clientes relacionados y verificados.${existing.length ? ` Ya estaban asociados: ${existing.join(', ')}.` : ''}`;
        return failures === 0;
    }
    function renderResults(s, ids, changed) {
        if (!s.resultRows) {
            s.resultRows = new Map(); const fragment = document.createDocumentFragment();
            for (const id of ids) {
                const row = document.createTextNode(`${id}: ${s.results.get(id) || 'Pendiente'}\n`);
                s.resultRows.set(id, row); fragment.append(row);
            }
            s.list.replaceChildren(fragment);
        }
        const update = id => { const row = s.resultRows.get(id); if (row) row.data = `${id}: ${s.results.get(id) || 'Pendiente'}\n`; };
        if (changed) update(changed); else ids.forEach(update);
    }
    async function refreshClients(s) {
        if (!s.needsClientRefresh || s.clientReadUnavailable || ticket() !== s.ticket || !s.dialog.isConnected) return;
        await idle(s, true); check(s, true);
        // Preserve the three observed native refresh actions, once per batch.
        native('fillModalVerTicket', s.ticket);
        native('changeTab', 'TAB-CLI');
        $(byId('grid_CliRel')).trigger('reloadGrid');
        await idle(s, true);
        if (!visible(anchors[1])) { native('changeTab', 'TAB-CLI'); await idle(s, true); }
        s.needsClientRefresh = false;
    }
    function parsed(s) {
        if (s.mode === 'clients') return clients(s.text.value);
        const result = parser.recognize(s.text.value, base);
        return { ids: result.nodes, invalid: result.unknownNodes };
    }
    function review(s) {
        if (s.clientReadUnavailable) { s.confirm.disabled = true; return; }
        if (s.uncertain) { s.confirm.disabled = true; return; }
        const data = parsed(s); s.resultRows = null; s.list.textContent = data.ids.join('\n');
        s.warning.hidden = !data.invalid.length;
        s.warning.textContent = data.invalid.length ? `No reconocidos (${data.invalid.length}): ${data.invalid.join(', ')}. No se cargarán. Corregí el listado antes de confirmar.` : '';
        s.status.textContent = `${data.ids.length} ${s.mode === 'clients' ? 'clientes' : 'nodos'} únicos para revisar.`;
        const tooManyNodes = s.mode === 'nodes' && (data.ids.length > 100 || s.text.value.length > 100000);
        s.confirm.disabled = !data.ids.length || data.invalid.length > 0 || tooManyNodes;
        if (tooManyNodes) s.status.textContent = 'Dividí el listado: máximo 100 IDs y 100.000 caracteres por carga.';
    }
    function close(s) {
        if (s.active) { s.cancelled = true; s.status.textContent = 'Deteniendo después de confirmar la operación en curso…'; return; }
        s.dialog.close(); s.dialog.remove(); session = null;
        if (s.origin.isConnected) s.origin.focus();
    }
    function updateProgress(s) {
        const timing = s.timing;
        if (!timing || session !== s || !s.dialog.isConnected) return;
        const count = `Procesados ${timing.done} de ${timing.total}`;
        if (!s.active) { s.progress.textContent = count; return; }
        if (s.cancelled) { s.progress.textContent = `${count} · Deteniendo…`; return; }
        if (timing.done === timing.total) { s.progress.textContent = `${count} · Actualizando ticket…`; return; }
        if (!timing.done) { s.progress.textContent = `${count} · Calculando tiempo restante…`; return; }
        const seconds = Math.max(1, Math.ceil((timing.average * (timing.total - timing.done) - (performance.now() - timing.currentStarted)) / 1000));
        const duration = seconds < 60 ? `${seconds} s` : `${Math.floor(seconds / 60)} min ${seconds % 60} s`;
        s.progress.textContent = `${count} · Tiempo restante aproximado: ${duration}`;
    }
    async function run(s) {
        if (s.active || s.uncertain || s.confirm.disabled) return;
        const data = parsed(s); s.snapshot = s.text.value; s.cancelled = false; s.active = true;
        s.results.clear(); s.resultRows = null; s.permissionDenied = false; s.warning.hidden = true;
        s.text.readOnly = true; s.confirm.disabled = true; buttons.forEach(button => { button.disabled = true; });
        s.cancel.textContent = 'Detener';
        if (s.mode === 'clients') {
            s.timing = { done: 0, total: data.ids.length, average: 0, currentStarted: performance.now() };
            s.progress.hidden = false; updateProgress(s);
            s.progressTimer = setInterval(() => updateProgress(s), 1000);
        }
        let success = false;
        try { check(s); success = s.mode === 'nodes' ? await nodes(s, data.ids) : await loadClients(s, data.ids); }
        catch (error) { s.warning.hidden = false; s.warning.textContent = error.message; s.status.textContent = 'Carga incompleta. Revisá el detalle antes de continuar.'; if (s.mode === 'clients') renderResults(s, data.ids); }
        finally {
            try { await refreshClients(s); }
            catch (error) { s.warning.hidden = false; s.warning.textContent = `Los resultados se conservan, pero no se pudo actualizar la vista del ticket: ${error.message}`; success = false; }
            s.active = false;
            clearInterval(s.progressTimer); updateProgress(s);
            if (s.uncertain) uncertainTickets.set(s.ticket, s.pendingVerification || null);
            if (s.mode === 'nodes' && !s.uncertain && ticket() === s.ticket && s.ownedStage !== undefined && byId('TKT-ZONA-LISTA')?.innerHTML === s.ownedStage) byId('TKT-ZONA-LISTA').replaceChildren();
            if (s.nativeView && ticket() === s.ticket && !s.uncertain && $.active === 0) {
                try { native('cambiarVista', 'GENERAL'); native('changeTab', 'TAB-ZONA'); }
                catch (error) { s.warning.hidden = false; s.warning.textContent = error.message; success = false; }
            }
            buttons.forEach((button, index) => { button.disabled = anchors[index].disabled; });
            s.cancel.textContent = 'Cerrar';
            // After remote effects, retain the result and original list. Never offer
            // blind retry for successful, failed or uncertain per-client writes.
            s.text.readOnly = s.mode === 'nodes' && (s.committed || s.uncertain);
            s.confirm.disabled = s.text.readOnly || s.uncertain || s.clientReadUnavailable || ticket() !== s.ticket || $.active !== 0;
            if (!s.confirm.disabled) reviewRetry(s, data);
            if (s.mode === 'clients' && s.results.size && !s.uncertain) s.confirm.textContent = 'Cargar listado actualizado';
            s.verify.hidden = !s.uncertain || !s.pendingVerification;
        }
        if (success && !s.cancelled) {
            const message = s.status.textContent;
            if (s.mode === 'nodes') { close(s); feedback(message); }
            else { s.warning.hidden = true; renderResults(s, data.ids); }
        }
    }
    function reviewRetry(s, data) { s.confirm.disabled = !data.ids.length || data.invalid.length > 0; s.confirm.textContent = 'Volver a intentar'; }
    function open(mode, origin) {
        if (session || !visible(origin) || origin.disabled || !ticket()) return;
        const dialog = document.createElement('dialog'); dialog.id = 'viena-ticket-list-review';
        const title = document.createElement('h4'); title.id = 'viena-ticket-list-title'; title.textContent = mode === 'nodes' ? 'Cargar listado nodos' : 'Cargar listado clientes';
        dialog.setAttribute('aria-labelledby', title.id);
        const help = document.createElement('p'); help.textContent = mode === 'nodes' ? 'Pegá los nodos separados por espacios, renglones, coma, /, | o ;. Se conservan las zonas existentes y no se agregan duplicados.' : 'Pegá los IDs de clientes separados por espacios, renglones, coma, /, | o ;. Se conservan los clientes relacionados. Cada cliente se guarda por separado.';
        const text = document.createElement('textarea'); text.setAttribute('aria-label', mode === 'nodes' ? 'Listado de nodos' : 'Listado de clientes'); text.spellcheck = false;
        const warning = document.createElement('div'); warning.className = 'list-warning'; warning.setAttribute('role', 'alert'); warning.hidden = true;
        const list = document.createElement('pre'), status = document.createElement('p'); status.setAttribute('role', 'status');
        const progress = document.createElement('p'); progress.className = 'list-progress'; progress.hidden = true;
        const actions = document.createElement('div'); actions.className = 'list-actions';
        const confirm = document.createElement('button'); confirm.type = 'button'; confirm.className = 'btn btn-primary'; confirm.textContent = 'Confirmar carga';
        const cancel = document.createElement('button'); cancel.type = 'button'; cancel.className = 'btn btn-default'; cancel.textContent = 'Cancelar';
        const verify = document.createElement('button'); verify.type = 'button'; verify.className = 'btn btn-default'; verify.textContent = 'Verificar resultado'; verify.hidden = true;
        actions.append(confirm, verify, cancel); dialog.append(title, help, text, warning, list, progress, status, actions);
        // Remain within the native ticket modal so Bootstrap's focus guard accepts
        // the textarea while dialog provides its own top-layer focus containment.
        byId('TKT-VER-ID').closest('.modal-content').append(dialog);
        const s = { dialog, mode, origin, ticket: ticket(), text, warning, list, progress, status, confirm, cancel, verify, results: new Map(), active: false, cancelled: false, uncertain: uncertainTickets.has(ticket()), pendingVerification: uncertainTickets.get(ticket()) };
        session = s; text.addEventListener('input', () => review(s)); confirm.addEventListener('click', () => { void run(s); }); cancel.addEventListener('click', () => close(s));
        if (mode === 'clients') text.addEventListener('paste', () => {
            setTimeout(() => {
                if (session !== s || s.active || s.uncertain || !dialog.isConnected) return;
                const data = clients(text.value);
                // Keep invalid tokens for correction, rather than silently dropping them.
                text.value = data.invalid.length ? text.value.split(/\r?\n/).map(line => line.trim()).filter(Boolean).join('\n') : data.ids.join('\n');
                review(s);
            }, 0);
        });
        verify.addEventListener('click', async () => {
            if (s.active || !s.pendingVerification) return;
            s.active = true; s.snapshot = s.text.value; verify.disabled = true; s.text.readOnly = true;
            try {
                const pending = s.pendingVerification, rows = (await clientRows(s, pending.id)).map(row => String(row.idCliente));
                if (!rows.includes(pending.id)) throw new Error('La asociación sigue sin confirmar. Revisá el ticket antes de repetir ese cliente.');
                s.results.set(pending.id, 'Cargado y verificado'); s.pendingVerification = null; s.uncertain = false; uncertainTickets.delete(s.ticket); verify.hidden = true; s.warning.hidden = true; review(s);
                s.status.textContent = 'Resultado verificado. Podés cargar los pendientes o un nuevo listado.';
            } catch (error) { s.warning.hidden = false; s.warning.textContent = error.message; }
            finally { s.active = false; verify.disabled = false; s.text.readOnly = false; }
        });
        dialog.addEventListener('keydown', event => { if (event.key === 'Escape') event.stopPropagation(); });
        dialog.addEventListener('cancel', event => { event.preventDefault(); close(s); });
        dialog.showModal(); review(s); text.focus();
        if (s.uncertain) { s.text.readOnly = mode === 'nodes'; s.confirm.disabled = true; verify.hidden = !s.pendingVerification; s.warning.hidden = false; s.warning.textContent = 'Hay un guardado anterior sin confirmar en este ticket. Usá Verificar resultado o revisá sus zonas/clientes antes de repetir la carga.'; }
        if (mode === 'clients' && blockedClientReads.has(s.ticket)) { s.clientReadUnavailable = true; s.confirm.disabled = true; verify.disabled = true; s.warning.hidden = false; s.warning.textContent = 'Una consulta no terminó a tiempo. Esperá que MOICA responda y recargá la página antes de volver a consultar.'; }
    }
})();
