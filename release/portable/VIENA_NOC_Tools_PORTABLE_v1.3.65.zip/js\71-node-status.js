(() => {
    'use strict';
    if (globalThis.VienaNodeStatus) return;
    const fields = (row, key) => row?.[key] ?? key.split('.').reduce((v,k) => v?.[k],row);
    const matches = (value,node) => (Array.isArray(value) ? value : String(value ?? '').split(/[\s,;|]+/)).some(v => String(v).trim().toUpperCase() === node);
    function value(v) {
        if (v == null || /^(?:\s*|S\/D|N\/A|null|undefined|sin (?:datos|monitoreo|monitoria))$/i.test(String(v).trim())) return 'Sin monitoreo';
        return String(v).slice(0,150);
    }
    function opticalNumber(v) {
        if((typeof v!=='number'&&typeof v!=='string')||value(v)==='Sin monitoreo')return 'Sin monitoreo';
        const n=Number(String(v).trim().replace(',','.'));
        return Number.isFinite(n)?n.toLocaleString('es-AR',{minimumFractionDigits:2,maximumFractionDigits:2,useGrouping:false}).replace(/^-0,00$/,'0,00'):'Sin monitoreo';
    }
    function sourceNodes(row) {
        const raw=fields(row,'nodosAlimenta'),nodes=Array.isArray(raw)?raw:typeof raw==='string'?raw.split(/[\s,;|]+/):[];
        return [...new Set(nodes.filter(n=>typeof n==='string'||typeof n==='number').map(n=>String(n).trim().toUpperCase()).filter(n=>n&&value(n)!=='Sin monitoreo'))];
    }
    function miraMetrics(row) {
        const cell=(key,percent=false)=>{
            const raw=fields(row,key),text=typeof raw==='number'||typeof raw==='string'?String(raw).trim().replace(',','.'):'';
            const n=Number(text),valid=text!==''&&Number.isFinite(n)&&(!percent||(n>=0&&n<=100));
            return {text:valid?opticalNumber(n)+(percent?' %':''):'Sin monitoreo',red:valid&&percent&&n>5};
        };
        return {
            partial:cell('cmPartialService.ofdmaPercent',true).text,
            levels:[['Power',cell('cmPwr.pwrDs').text,cell('cmPwr.pwrUs').text],['SNR',cell('cmSnr.snrDs').text,cell('cmSnr.snrUs').text]],
            fec:[['QAM',cell('cmFecDs.porcCmFecPost',true),cell('cmFecUs.porcCmFecPost',true)],['OFDM',cell('cmFecDsOfdm.porcCmFecPost',true),cell('cmFecUsOfdm.porcCmFecPost',true)]]
        };
    }
    function rphyColors(row) {
        // Fuentes grid-nodos-rphy: formatRPDPowerRx / formatLeafPower.
        // RPHY boundaries are exclusive; Leaf RX has only a lower threshold.
        const distance=fields(row,'distanciaSFP');
        const range=(typeof distance==='number'||typeof distance==='string')&&['20','40','80'].includes(String(distance))?({'20':[-14,-1],'40':[-16,-7],'80':[-20,-7]})[String(distance)]:null;
        const number=raw=>(typeof raw==='number'||typeof raw==='string')&&String(raw).trim()!==''&&Number.isFinite(Number(raw))?Number(raw):null;
        const rx=number(fields(row,'poleo.RPDPower.rx')),leaf=number(fields(row,'leaf.byLabelActivePorts.RxLanePower.bandwidthLabel'));
        return {
            rphyRx:range&&rx!==null?(rx>range[0]&&rx<range[1]?'green':rx<range[0]||rx>range[1]?'red':''):'',
            leafRx:range&&leaf!==null?(leaf>range[0]?'green':'red'):''
        };
    }
    function plan(c) {
        if (c.ftth) return [];
        return ['mira',...(c.source ? ['fuente'] : []),...(c.technology === 'LEGACY' ? ['optico'] : c.technology === 'RPHY' ? ['rphy'] : c.technology === 'VCCAP' ? ['grafana'] : [])];
    }
    function battery(row) {
        const voltage = v => {
            if (typeof v !== 'number' && typeof v !== 'string') return 'Sin monitoreo';
            const text=String(v).trim().replace(',','.');
            return /^[+-]?\d+(?:\.\d+)?$/.test(text)&&Number.isFinite(Number(text)) ? text+' V' : 'Sin monitoreo';
        };
        return {total:voltage(fields(row,'info_poleo.tp_psTotalStringVoltage')),
            rows:[1,2].flatMap(s=>[1,2,3].map(b=>['String '+s,'Batería '+b,voltage(fields(row,'info_poleo.tp_psBatteryVoltage_String_'+s+'_Battery_'+b))]))};
    }
    function monitored(row,kind) {
        const present=v=>value(v)!=='Sin monitoreo';
        const state=fields(row,'info_poleo.status'),status=present(state)?value(state):null;
        if(kind==='fuente'){
            const b=battery(row);b.total=present(b.total)?b.total:null;b.rows=b.rows.filter(r=>present(r[2]));
            const rawInverter=fields(row,'info_poleo.tp_psInverterStatus_description'),inverter=present(rawInverter)?value(rawInverter):null;
            return {status,inverter,battery:b,visible:status!==null||inverter!==null||b.total!==null||b.rows.length>0};
        }
        const channels=[1,2,3,4].map(i=>[i,...['info_poleo.tp_fnOpticalReceiverPower_','info_poleo.tp_fnReturnLaserOpticalPower_'].map(k=>{
            const v=fields(row,k+i);return present(v)?v:null;
        })]).filter(r=>r[1]!==null||r[2]!==null);
        return {status,channels,visible:status!==null||channels.length>0};
    }
    function grafana(text, href, node) {
        const url = new URL(href);
        if (url.hostname !== 'grafana-telemetria.telecentro.net.ar' || url.searchParams.get('var-nodo') !== node || url.searchParams.get('var-rpd') !== node) throw Error('Abrí Grafana para este nodo.');
        const equipment = url.searchParams.get('var-equipo'), port = url.searchParams.get('var-interface');
        const heading = 'Potencia óptica ' + equipment + ' Interfaz ' + port + ' hacia ' + node;
        const start = text.indexOf(heading), next = text.indexOf('Potencia óptica Rx / Tx RPD',start);
        if (!equipment || !port || start < 0 || next < 0) throw Error('Los paneles ópticos todavía no están disponibles.');
        const hub = text.slice(start + heading.length,next), rpd = text.slice(next).split(/Tráfico|Datos del nodo/)[0];
        const read = (section,label) => {
            const at = section.indexOf(label); if (at < 0) return null;
            const following = section.slice(at + label.length).trimStart();
            return following.match(/^([+−-]?\d+(?:[.,]\d+)?)\s*dBm\b/)?.[1]?.replace('−','-').replace(',','.') ?? null;
        };
        const ports = [...new Set([...rpd.matchAll(/\b(sfp\d+)\s*-\s*(?:Rx|Tx)\b/g)].map(m => m[1]))].slice(0,16).map(name => ({name,rx:read(rpd,name+' - Rx'),tx:read(rpd,name+' - Tx')}));
        const statusAt=text.indexOf('Estado CMs',next),cmPartialRows=[];
        const cmText=statusAt>=0?text.slice(statusAt+'Estado CMs'.length).split(/Vendor|RPD MAC|RPD Uptime/)[0]:'';
        const mds=[...new Set([...cmText.matchAll(/^(Md[A-Z0-9:.\/_-]+)\s*-\s*(?:online|offline|partial|active(?:\s*\(ranging\))?)(?=\s|$)/gim)].map(match=>match[1]))];
        for(const match of cmText.matchAll(/^([^\r\n\t]+?\s-\s*partial)\s*[\r\n\t ]+(\d+)(?=\s|$)/gim)){
            const count=Number(match[2]),name=match[1].trim();
            if(Number.isSafeInteger(count)&&!cmPartialRows.some(row=>row.name===name&&row.count===count))cmPartialRows.push({name,count});
        }
        return {equipment,interface:port,hubTx:read(hub,'TX - '+port+' ENLACE HACIA NODO '+node),hubRx:read(hub,'RX - '+port+' ENLACE HACIA NODO '+node),ports,mds,cmPartialRows,cmPartialStatus:cmPartialRows.length?'available':'missing'};
    }
    // Serialized into the selected operational tab by chrome.scripting. No
    // captured module variables, UI actions, visible-grid writes or imports.
    async function readSource(kind, node) {
        const get = (r,k) => r?.[k] ?? k.split('.').reduce((v,p) => v?.[p],r);
        const same = v => (Array.isArray(v) ? v : String(v ?? '').split(/[\s,;|]+/)).some(v => String(v).trim().toUpperCase() === node);
        const pick = (row,keys) => Object.fromEntries(keys.map(k => [k,get(row,k) ?? null]));
        if (!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(node)) throw Error('Nodo inválido.');
        if (kind === 'grafana') {
            if (location.hostname !== 'grafana-telemetria.telecentro.net.ar') throw Error('Destino inválido.');
            return {href:location.href,text:(document.body?.innerText || '').slice(0,100000)};
        }
        const mira = kind === 'mira', host = mira ? 'mira5-gdt.telecentro.net.ar' : 'fuentes.telecentro.net.ar';
        if (location.hostname !== host) throw Error('Destino inválido.');
        const $ = window.jQuery;
        const ids = {mira:'gridStatsNodosCmts',fuente:'grid-fuentes',optico:'grid-opticos',rphy:'grid-nodos-rphy'};
        const element = document.getElementById(ids[kind]);
        if (!$ || !element?.grid) return {pending:true};
        const param = key => $(element).jqGrid('getGridParam',key);
        const identity = {mira:'nodoCmts',fuente:'nodosAlimenta',optico:'nodoAlimenta',rphy:'nodoRPHY'}[kind];
        const keys = kind === 'mira' ? ['nodoCmts','cmStatus.cmUpPercent','cmStatus.cmTot','cmPartialService.ofdmaPercent','cmPwr.pwrDs','cmPwr.pwrUs','cmSnr.snrDs','cmSnr.snrUs','cmFecDs.porcCmFecPost','cmFecUs.porcCmFecPost','cmFecDsOfdm.porcCmFecPost','cmFecUsOfdm.porcCmFecPost'] : kind === 'fuente' ? ['idFuente','nodosAlimenta','direccion.nodoUbic','info_poleo.status','info_poleo.timestamp_inicio_status','info_poleo.tp_psInverterStatus_description','info_poleo.tp_psTotalStringVoltage',...[1,2].flatMap(s=>[1,2,3].map(b=>'info_poleo.tp_psBatteryVoltage_String_'+s+'_Battery_'+b))] : kind === 'optico' ? ['idOptico','nodoAlimenta','info_poleo.status','info_poleo.timestamp_inicio_status',...[1,2,3,4].flatMap(i => ['info_poleo.tp_fnOpticalReceiverPower_'+i,'info_poleo.tp_fnReturnLaserOpticalPower_'+i])] : ['idNodoRPHY','nodoRPHY','poleo.RPDStatus.1.descripcion','distanciaSFP','poleo.RPDPower.tx','poleo.RPDPower.rx','leaf.byLabelActivePorts.TxLanePower.bandwidthLabel','leaf.byLabelActivePorts.RxLanePower.bandwidthLabel'];
        if (mira) keys.unshift('nodo');
        // The native local grid exists before its separate AJAX inventory read.
        // An empty array alone cannot confirm that loading has finished.
        if (kind === 'rphy') {
            if (param('datatype') !== 'local' || !Array.isArray(param('data')) || !param('data').length) return {pending:true};
            const rows = param('data').filter(row => same(get(row,identity)));
            return {rows:rows.slice(0,100).map(r => pick(r,keys)),partial:rows.length > 100,loaded:true};
        }
        const url = new URL(param('url'),location.href), names = param('prmNames');
        if (url.origin !== location.origin || (mira ? url.pathname !== '/controller_grid_mira_gral.php' || url.searchParams.get('coll') !== 'statsNodosCmts' : url.pathname !== '/scripts/grid_controller.php' || url.searchParams.get('grid') !== (kind === 'fuente' ? 'fuentes' : 'opticos')) || String(param('mtype')).toUpperCase() !== 'GET' || !names?.page || !names.rows || !names.search || !names.filter) throw Error('La consulta de esta plataforma no está disponible.');
        // Construct an independent native grid read, keeping only the native
        // operation. Never inherit a visible filter, selection or page.
        for (const key of ['filters','defaultFilter','searchField','searchOper','searchString','page','rows','sidx','sord',names.page,names.rows,names.search,names.filter,names.sort,names.order].filter(Boolean)) url.searchParams.delete(key);
        url.searchParams.set('oper','grid');
        url.searchParams.set(names.page,'1'); url.searchParams.set(names.rows,'100'); url.searchParams.set(names.search,'true');
        url.searchParams.set(names.filter,JSON.stringify({groupOp:'AND',rules:[{field:identity,op:kind === 'fuente' ? 'cn' : 'eq',data:node}]}));
        if (names.sort && param('sortname')) url.searchParams.set(names.sort,param('sortname'));
        if (names.order) url.searchParams.set(names.order,'asc');
        const abort = new AbortController(), timeout = setTimeout(() => abort.abort(),10000);
        const leave = () => abort.abort(); window.addEventListener('pagehide',leave,{once:true});
        try {
            const response = await fetch(url.href,{credentials:'same-origin',signal:abort.signal,cache:'no-store',redirect:'manual'});
            if (response.status===401 || response.status===403 || response.redirected || response.type==='opaqueredirect') return {needsSession:true};
            if (!response.ok) throw Error('No se pudo consultar la plataforma.');
            // PHP may serve valid JSON with its default text/html header.
            // Inspect an actual HTML body only after JSON decoding fails.
            const copy=response.clone?.();let data;
            try{data=await response.json();}
            catch(_){
                const prefix=copy?(await copy.text()).trimStart().slice(0,500):'';
                if(/^(?:<!doctype\s+html\b|<html\b|<head\b|<body\b|<form\b)/i.test(prefix))return {needsSession:true};
                throw Error('La respuesta no pudo verificarse.');
            }finally{if(copy?.body&&!copy.bodyUsed)void copy.body.cancel().catch(()=>{});}
            const records = Number(data.records), page = Number(data.page), total = Number(data.total);
            if (!Array.isArray(data.rows) || !Number.isSafeInteger(records) || records < 0 || page !== 1 || data.rows.length > 100 || data.rows.length !== Math.min(records,100) || !(total === Math.ceil(records/100) || records === 0 && total === 1)) throw Error('La respuesta no pudo verificarse.');
            const rows = data.rows.filter(row => same(get(row,identity)));
            return {rows:rows.map(r => pick(r,keys)),partial:records > 100,loaded:false};
        } finally { clearTimeout(timeout); window.removeEventListener('pagehide',leave); }
    }
    // Grafana 10.2.2 exposes these native contracts in the supplied build dump.
    // Private query runners work while its panel rendering is deferred in a hidden tab.
    async function readGrafanaBackground(node,cos,token) {
        let stage='runtime',diagnostic=()=>({});
        const abort=token?new AbortController():null;
        if(token){window.__vienaNodeOpticalCancel?.();window.__vienaNodeOpticalToken=token;window.__vienaNodeOpticalCancel=()=>abort.abort();}
        const live=()=>{if(abort?.signal.aborted||token&&window.__vienaNodeOpticalToken!==token)throw Error('Consulta reemplazada por otro nodo.');};
        try{
        if(!window.System?.import)return {unsupported:true};
        let runtime,data;
        try{[runtime,data]=await Promise.all([window.System.import('@grafana/runtime'),window.System.import('@grafana/data')]);}
        catch(_){return {unsupported:true};}
        if(!runtime?.createQueryRunner||!runtime?.locationService?.partial||!data?.getFieldDisplayName)return {unsupported:true};
        const deadline=Date.now()+30000,sleep=()=>new Promise(r=>setTimeout(r,250));
        const wait=async predicate=>{while(Date.now()<deadline){live();const v=predicate();if(v)return v;await sleep();}throw Error('Grafana no terminó de preparar el nodo.');};
        const uid='e1239f9e-a168-4843-963c-15681c84fe47';
        stage='dashboard';const templates=await wait(()=>{try{return runtime.getTemplateSrv?.();}catch(_){return null;}});
        let model,dashboard,variables,timeRange,timezone;
        const backend=runtime.getBackendSrv?await wait(()=>{try{return runtime.getBackendSrv();}catch(_){return null;}}):null;
        if(backend?.getDashboardByUid&&templates?.getVariables&&data.rangeUtil?.convertRawToRange){
            // These are public Grafana contracts from the supplied native build.
            // DashboardSrv/TimeSrv are not public runtime services and need not
            // be registered in its legacy Angular injector.
            model=(await backend.getDashboardByUid(uid))?.dashboard;
            if(!model)throw Error('Grafana no devolvió el dashboard.');
            dashboard=()=>model;variables=()=>templates.getVariables();
            timezone=()=>model.timezone||'browser';
            timeRange=()=>{const u=new URL(location.href),raw={...model.time};for(const key of ['from','to'])if(u.searchParams.has(key))raw[key]=u.searchParams.get(key);if(!raw.from||!raw.to)throw Error('El período de Grafana no está disponible.');return data.rangeUtil.convertRawToRange(raw,timezone(),model.fiscalYearStartMonth);};
        }else{
            if(!runtime.getLegacyAngularInjector)return {unsupported:true};
            const injector=await wait(()=>{try{return runtime.getLegacyAngularInjector();}catch(_){return null;}});
            dashboard=()=>injector.get('dashboardSrv').getCurrent();model=await wait(()=>dashboard());
            variables=()=>model.getVariables();timezone=()=>model.getTimezone();timeRange=()=>injector.get('timeSrv').timeRange();
        }
        live();if(model.uid!==uid)throw Error('Dashboard de Grafana incorrecto.');
        const flatten=panels=>(panels||[]).flatMap(p=>[p,...flatten(p.panels)]);
        const allPanels=flatten(model.panels),needed=new Set(['cluster','rpd','nodo','equipo','interface']);
        const references=(text,names=needed)=>{for(const match of text.matchAll(/\$(?:\{(\w+)(?:[^}]*)\}|(\w+))|\[\[(\w+)(?::[^\]]*)?\]\]/g))names.add(match[1]||match[2]||match[3]);};
        for(const panel of allPanels.filter(p=>p.title?.startsWith('Potencia óptica ')))references(JSON.stringify({title:panel.title,targets:panel.targets,datasource:panel.datasource}));
        let size;do{size=needed.size;for(const v of variables())if(needed.has(v.name))references(JSON.stringify(v.query||''));}while(needed.size!==size);
        const idle=(names=needed)=>variables().filter(v=>names.has(v.name)).every(v=>v.state!=='Loading'&&v.state!=='Error'&&
            (v.state!=='NotStarted'||v.type==='constant'&&v.current?.value!=null&&String(v.current.value)!==''));
        const currentValue=key=>{const v=variables().find(v=>v.name===key)?.current?.value;return Array.isArray(v)?v.length===1?String(v[0]):null:v==null?null:String(v);};
        diagnostic=()=>{
            const url=new URL(location.href),selected={};
            for(const name of ['cluster','rpd','nodo','equipo','interface']){
                const v=variables().find(v=>v.name===name);
                selected[name]={current:currentValue(name),raw:templates.replace('$'+name,undefined,'raw'),url:url.searchParams.get('var-'+name),skipUrlSync:v?.skipUrlSync===true,state:v?.state??null};
            }
            return {selected,pending:variables().filter(v=>needed.has(v.name)&&['NotStarted','Loading','Error'].includes(v.state)).map(v=>({name:v.name,type:v.type,state:v.state})),rpdOptionAvailable:!!variables().find(v=>v.name==='rpd')?.options?.some(o=>o.value===node)};
        };
        const same=(key,v)=>{
            const variable=variables().find(x=>x.name===key),url=new URL(location.href),param='var-'+key;
            return currentValue(key)===v&&templates.replace('$'+key,undefined,'raw')===v&&
                (variable?.skipUrlSync===true||!url.searchParams.has(param)||url.searchParams.get(param)===v);
        };
        const select=async(key,v)=>{
            if(same(key,v))return;
            const param='var-'+key,current=currentValue(key);
            // A stale template can disagree with an already-correct URL.
            // Replacing that same URL is a router no-op. First let Grafana
            // consume its actual selection, then request the desired value.
            if(current&&current!==v&&new URL(location.href).searchParams.get(param)===v){
                runtime.locationService.partial({[param]:current},true);
                await sleep();live();
            }
            runtime.locationService.partial({[param]:v},true);
        };
        stage='variables';await wait(()=>idle(new Set(['cluster'])));
        stage='cluster';
        await select('cluster',cos);
        await wait(()=>idle(new Set(['cluster','rpd']))&&same('cluster',cos));
        const rpd=variables().find(v=>v.name==='rpd');
        if(!rpd?.options?.some(o=>o.value===node))throw Error('El nodo no está disponible en este COS.');
        stage='nodo';await select('rpd',node);
        const ready=()=>{live();return dashboard()===model&&idle()&&same('cluster',cos)&&same('rpd',node)&&same('nodo',node);};
        await wait(ready);
        stage='enlace';const href=location.href,url=new URL(href),equipment=currentValue('equipo'),iface=currentValue('interface');
        if(!equipment||!iface||!same('equipo',equipment)||!same('interface',iface))throw Error('El enlace óptico no está disponible.');
        const titles=['Potencia óptica '+equipment+' Interfaz '+iface+' hacia '+node,'Potencia óptica Rx / Tx RPD'];
        const panels=allPanels.filter(p=>titles.includes(templates.replace(p.title,p.scopedVars)));
        if(panels.length!==2||new Set(panels.map(p=>templates.replace(p.title,p.scopedVars))).size!==2)throw Error('No se encontraron los paneles ópticos del nodo.');
        stage='potencias';const lines=[];
        async function queryPanel(panel,title,unit='dBm',timeout=15000,signal=abort?.signal){
            const runner=runtime.createQueryRunner(),panelLines=[title];
            let subscription,timer,onAbort;
            try{
                const result=await new Promise((resolve,reject)=>{
                    timer=setTimeout(()=>reject(Error('La consulta óptica de Grafana venció.')),timeout);
                    onAbort=()=>reject(Error('Consulta reemplazada por otro nodo.'));signal?.addEventListener('abort',onAbort,{once:true});live();if(signal?.aborted)throw Error('Consulta reemplazada por otro nodo.');
                    subscription=runner.get().subscribe({next:r=>{if(r.state==='Error'||r.error||r.errors?.length)reject(Error('Grafana no pudo consultar las potencias.'));else if(r.state==='Done')resolve(r);},error:reject});
                    try{runner.run({datasource:panel.datasource,queries:panel.targets,panelId:panel.id,dashboardUID:model.uid,timezone:timezone(),timeRange:timeRange(),maxDataPoints:panel.maxDataPoints||Math.max(1,Math.floor(window.innerWidth)),minInterval:panel.interval,scopedVars:panel.scopedVars,cacheTimeout:panel.cacheTimeout,queryCachingTTL:panel.queryCachingTTL});}catch(error){reject(error);}
                });
                if(!ready()||location.href!==href)throw Error('El nodo de Grafana cambió durante la consulta.');
                for(const frame of result.series||[])for(const field of frame.fields||[]){
                    if(field.type!=='number')continue;
                    const label=data.getFieldDisplayName(field,frame,result.series);
                    if(!unit)panelLines.push(label);
                    const values=field.values;
                    for(let i=(values?.length||0)-1;i>=0;i--){
                        const v=typeof values.get==='function'?values.get(i):values[i];
                        if(typeof v==='number'&&Number.isFinite(v)){if(unit)panelLines.push(label);panelLines.push(String(v)+(unit?' '+unit:''));break;}
                    }
                }
                return panelLines;
            }finally{clearTimeout(timer);if(onAbort)signal?.removeEventListener('abort',onAbort);subscription?.unsubscribe();runner.destroy();}
        }
        const cmPanels=allPanels.filter(p=>templates.replace(p.title||'',p.scopedVars).trim()==='Estado CMs');
        let cmPartialStatus='missing',cmAbort,cmRead;
        const cancelCms=()=>cmAbort?.abort();
        if(cmPanels.length===1){
            cmAbort=new AbortController();abort?.signal.addEventListener('abort',cancelCms,{once:true});
            cmRead=(async()=>{
                const names=new Set(needed);references(JSON.stringify({targets:cmPanels[0].targets,datasource:cmPanels[0].datasource}),names);
                let count;do{count=names.size;for(const v of variables())if(names.has(v.name))references(JSON.stringify(v.query||''),names);}while(names.size!==count);
                const deadline=Date.now()+4000;
                while(!idle(names)){live();if(cmAbort.signal.aborted||Date.now()>=deadline)throw Error('CMs no disponibles.');await sleep();}
                const signature=()=>JSON.stringify(variables().filter(v=>names.has(v.name)).map(v=>[v.name,v.current?.value]));
                const before=signature(),rows=await queryPanel(cmPanels[0],'Estado CMs','',Math.max(1,deadline-Date.now()),cmAbort.signal);
                if(!idle(names)||signature()!==before)throw Error('CMs no disponibles.');return rows;
            })().then(rows=>{cmPartialStatus='available';return rows;},()=>{cmPartialStatus='unavailable';return [];});
        }
        try{
            for(const title of titles)lines.push(...await queryPanel(panels.find(p=>templates.replace(p.title,p.scopedVars)===title),title));
            if(cmRead)lines.push(...await cmRead);
            if(!ready()||location.href!==href)throw Error('El nodo de Grafana cambió durante la consulta.');
        }finally{cancelCms();if(cmRead)await cmRead;abort?.signal.removeEventListener('abort',cancelCms);}
        // The parser receives a proof of the validated live variables. Hidden
        // skipUrlSync variables need not exist in the operator's address bar.
        for(const [key,v] of Object.entries({cluster:cos,rpd:node,nodo:node,equipo:equipment,interface:iface}))url.searchParams.set('var-'+key,v);
        return {href:url.href,text:lines.join('\n'),cmPartialStatus};
        }catch(error){
            const known=/^(?:Grafana no |Dashboard de Grafana |El nodo |El enlace |No se encontraron |La consulta óptica |El período )/.test(String(error?.message||''));
            let details={};try{details=diagnostic();}catch(_){}
            return {failure:{stage,details,cancelled:!!abort?.signal.aborted||!!token&&window.__vienaNodeOpticalToken!==token,message:known?error.message:'Grafana no pudo completar '+({runtime:'la carga',dashboard:'el dashboard',variables:'las variables',cluster:'el COS',nodo:'el nodo',enlace:'el enlace',potencias:'la consulta de potencias'}[stage]||'la consulta')+'.'}};
        }finally{if(token&&window.__vienaNodeOpticalToken===token)delete window.__vienaNodeOpticalCancel;}
    }
    // Separate evidence model: the established Post-FEC analyzer is unchanged.
    globalThis.VienaNodeStatus = {value,opticalNumber,sourceNodes,miraMetrics,rphyColors,fields,matches,plan,grafana,battery,monitored,readSource,readGrafanaBackground};
    if (typeof document === 'undefined') {
        if (!globalThis.chrome?.runtime?.onMessage) return;
        const busy=new Set(),graphRuns=new Map(),sourceBusy=new Set(),accessWaiters=new Map();let graphSequence=0;
        // Destination preparation writes a shared primary-tab map. Serialize
        // that short phase, then let independent platform reads progress.
        let preparing=Promise.resolve();
        const prepareDestination=target=>{
            const next=preparing.then(()=>ensureDestinationTab(target,{activate:false}));
            preparing=next.catch(()=>{});return next;
        };
        const nativeDestination=async target=>{
            // Summary API reads are independent of the operator's dashboard
            // state and must use the same transport with or without open tabs.
            if(target==='grafana-vccap'&&globalThis.VienaNodeBackground)return {ok:true,hidden:true,target};
            const cfg=typeof DESTINATION_CONFIGS==='undefined'?null:DESTINATION_CONFIGS[target];
            if(typeof preferredMatchingTab==='function'&&cfg?.matches){
                const ready=preferredMatchingTab((await chrome.tabs.query({})).filter(t=>t.status==='complete'&&!t.discarded),cfg);
                if(ready)return {ok:true,tabId:ready.id,opened:false,nativeReady:true};
            }
            if(globalThis.VienaNodeBackground)return {ok:true,hidden:true,target};
            return prepareDestination(target);
        };
        const sourceTarget=kind=>kind==='mira'?'mira-stats':'fuentes';
        function accessRequired(target,tabId,clientId,session=true) {
            let record=accessWaiters.get(target);
            if(!record){record={tabId,session,clients:new Set()};accessWaiters.set(target,record);}
            if(Number.isInteger(clientId))record.clients.add(clientId);
            const name=target==='mira-stats'?'MIRA5':'Fuentes';
            return {ok:false,needsAccess:true,needsSession:record.session,platform:target,loginUrl:DESTINATION_CONFIGS[target].url,message:(record.session?'Iniciá sesión en ':'Completá el acceso a ')+name+' para continuar. El resumen se actualizará al recuperar el acceso.'};
        }
        chrome.tabs.onUpdated?.addListener((_id,change,tab)=>{
            if(change.status!=='complete')return;
            for(const target of ['mira-stats','fuentes']){
                let sameHost=false;try{sameHost=new URL(tab.url||'').origin===new URL(DESTINATION_CONFIGS[target].url).origin;}catch(_){}
                if(!sameHost||sourceBusy.has(target))continue;
                const record=accessWaiters.get(target);
                accessWaiters.delete(target);
                // The worker may have slept while the operator signed in. The
                // live VIENA card decides whether it is still awaiting access.
                void(async()=>{
                    const clients=record?.clients||new Set((await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'})).map(t=>t.id));
                    for(const id of clients)chrome.tabs.sendMessage(id,{type:'VIENA_NODE_STATUS_SOURCE_READY',platform:target}).catch(()=>{});
                })().catch(()=>{});
            }
        });
        chrome.tabs.onRemoved?.addListener(id=>{
            for(const [target,record] of accessWaiters){record.clients.delete(id);if(!record.clients.size)accessWaiters.delete(target);}
        });
        async function automaticSource(kind,node,clientId,force) {
            const target=sourceTarget(kind);
            if(force)accessWaiters.delete(target);
            const waiting=accessWaiters.get(target);
            if(waiting)return accessRequired(target,waiting.tabId,clientId,waiting.session);
            if(sourceBusy.has(target))return {ok:false,busy:true,message:'Hay una consulta en curso.'};
            sourceBusy.add(target);let timer,stopped=false;
            const check=()=>{if(stopped)throw Error('La consulta venció.');};
            const outside=loaded=>loaded?.tab?.url&&new URL(loaded.tab.url).origin!==new URL(DESTINATION_CONFIGS[target].url).origin;
            const read=async tabId=>{
                const deadline=Date.now()+(kind==='rphy'?30000:8000);
                while(Date.now()<deadline){
                    check();
                    const results=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},world:'MAIN',func:readSource,args:[kind,node]});check();
                    const result=results?.[0]?.result;
                    if(!result)throw Error('La plataforma no respondió.');
                    if(!result.pending)return result;
                    await new Promise(r=>setTimeout(r,300));
                }
                return {pending:true};
            };
            const work=async()=>{
                const destination=await nativeDestination(target);check();
                if(destination.hidden){
                    const result=await VienaNodeBackground.read(kind,node);check();
                    if(result.needsSession)return accessRequired(target,null,clientId,true);
                    if(result.pending)return kind==='rphy'?{ok:false,message:'El inventario RPHY no terminó de cargar. Reintentá con Actualizar.'}:accessRequired(target,null,clientId,false);
                    return {ok:true,data:result,loaded:true,readAt:Date.now()};
                }
                if(!destination?.tabId)throw Error('No se pudo abrir la plataforma en segundo plano.');
                if(!destination.ok)return accessRequired(target,destination.tabId,clientId,false);
                let tabId=destination.tabId;
                const initialLoad=await waitForTabComplete(tabId,18000,250);check();
                if(!initialLoad?.ok)throw Error('La plataforma no terminó de cargar.');
                if(outside(initialLoad))return accessRequired(target,tabId,clientId,true);
                let result=await read(tabId);check();
                if(kind==='rphy'&&result.pending)return {ok:false,message:'El inventario RPHY no terminó de cargar. Reintentá con Actualizar.'};
                if(result.needsSession||result.pending){
                    // Recover once in a background destination owned by this read.
                    // An existing operator tab keeps its visible grid and filters.
                    if(globalThis.VienaNodeBackground){
                        result=await VienaNodeBackground.read(kind,node);check();
                        if(result.needsSession)return accessRequired(target,null,clientId,true);
                        if(result.pending)return kind==='rphy'?{ok:false,message:'El inventario RPHY no terminó de cargar. Reintentá con Actualizar.'}:accessRequired(target,null,clientId,false);
                        return {ok:true,data:result,loaded:true,readAt:Date.now()};
                    }
                    if(destination.opened)await chrome.tabs.reload(tabId);
                    else{const recovery=await chrome.tabs.create({url:DESTINATION_CONFIGS[target].url,active:false});tabId=recovery?.id;}
                    check();if(!tabId)throw Error('No se pudo recuperar el acceso.');
                    const loaded=await waitForTabComplete(tabId,18000,250);check();
                    if(!loaded?.ok)throw Error('La plataforma no terminó de cargar.');
                    if(outside(loaded))return accessRequired(target,tabId,clientId,true);
                    if(target==='mira-stats'){
                        const prepared=await prepareOpenedDestination(target,tabId);check();
                        if(!prepared?.ok)return accessRequired(target,tabId,clientId,result.needsSession===true);
                        if(!(await waitForTabComplete(tabId,18000,250))?.ok)throw Error('MIRA5 no terminó de cargar.');check();
                    }
                    result=await read(tabId);check();
                    if(result.needsSession||result.pending)return accessRequired(target,tabId,clientId,result.needsSession===true);
                }
                accessWaiters.delete(target);
                return {ok:true,data:result,loaded:!!result.loaded,readAt:Date.now()};
            };
            try{return await Promise.race([work(),new Promise((_,reject)=>{timer=setTimeout(()=>{stopped=true;reject(Error('La consulta venció.'));},90000)})]);}
            finally{stopped=true;clearTimeout(timer);sourceBusy.delete(target);}
        }
        async function automaticGrafana(node,cos) {
            if(!cos)return {ok:false,message:'No se encontró el COS de este nodo en la base.'};
            let timer,tabId=null,locked=false,stopped=false,cancelRead;
            const token=String(Date.now())+'-'+(++graphSequence);
            const cancelled=new Promise((_,reject)=>{cancelRead=()=>{stopped=true;reject(Error('Consulta reemplazada por otro nodo.'));};});
            const check=()=>{if(stopped)throw Error('Consulta vencida.');};
            const work=async()=>{
                const target=await nativeDestination('grafana-vccap');check();
                if(target.hidden){
                    const snapshot=await VienaNodeBackground.read('grafana',node,cos);check();
                    if(snapshot?.failure)return {ok:false,message:snapshot.failure.message,diagnostic:{stage:snapshot.failure.stage,...snapshot.failure.details}};
                    if(snapshot?.unsupported||snapshot?.pending||snapshot?.needsSession)return {ok:false,message:'Grafana no terminó de cargar. Abrila para revisar el acceso y volvé a Actualizar.'};
                    if(!snapshot?.href||new URL(snapshot.href).searchParams.get('var-cluster')!==cos)throw Error('El COS de Grafana cambió durante la consulta.');
                    const data=grafana(snapshot.text,snapshot.href,node);
                    if(snapshot.cmPartialStatus==='unavailable'&&!data.cmPartialRows.length)data.cmPartialStatus='unavailable';
                    if(![data.hubTx,data.hubRx,...data.ports.flatMap(p=>[p.rx,p.tx])].some(v=>v!==null))throw Error('Grafana no tiene potencias disponibles.');
                    return {ok:true,data,loaded:true,readAt:Date.now()};
                }
                if(!target?.ok||!target.tabId)throw Error('Grafana no está disponible.');
                tabId=target.tabId;
                if(busy.has(tabId)){const previous=graphRuns.get(tabId);if(previous?.native&&(previous.node!==node||previous.cos!==cos))previous.cancel();return {ok:false,busy:true,message:'Hay una consulta en curso.'};}
                busy.add(tabId);locked=true;graphRuns.set(tabId,{node,cos,token,cancel:cancelRead,native:true});
                const loaded=await waitForTabComplete(tabId,18000,250);check();
                if(!loaded?.ok)throw Error('Grafana no terminó de abrirse.');
                const native=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},world:'MAIN',func:readGrafanaBackground,args:[node,cos,token]});check();
                const snapshot=native?.[0]?.result;
                if(snapshot?.failure)return {ok:false,message:snapshot.failure.message,diagnostic:{stage:snapshot.failure.stage,...snapshot.failure.details}};
                if(snapshot&&!snapshot.unsupported){
                    if(new URL(snapshot.href).searchParams.get('var-cluster')!==cos)throw Error('El COS de Grafana cambió durante la consulta.');
                    const data=grafana(snapshot.text,snapshot.href,node);
                    if(snapshot.cmPartialStatus==='unavailable'&&!data.cmPartialRows.length)data.cmPartialStatus='unavailable';
                    if(![data.hubTx,data.hubRx,...data.ports.flatMap(p=>[p.rx,p.tx])].some(v=>v!==null))throw Error('Grafana no tiene potencias disponibles.');
                    return {ok:true,data,loaded:true,readAt:Date.now()};
                }
                graphRuns.get(tabId).native=false;
                if(target.nativeReady){
                    const current=await ensureOperationalTabRuntimeCurrent(tabId);check();
                    if(!current?.ok)throw Error('Grafana no está disponible.');
                }
                const delivered=await sendMessageWithRetry(tabId,{type:'VIENA_GRAFANA_VCCAP_RUN',nodo:node,cos,backgroundRead:true},{timeout:22000,step:300});check();
                if(!delivered?.ok||!delivered.result?.ok)throw Error('No se pudo filtrar Grafana.');
                const deadline=Date.now()+15000;
                while(Date.now()<deadline){
                    check();
                    const results=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},world:'MAIN',func:readSource,args:['grafana',node]});check();
                    const result=results?.[0]?.result;
                    if(result){
                        try{
                            if(new URL(result.href).searchParams.get('var-cluster')!==cos)throw Error('COS pendiente.');
                            const data=grafana(result.text,result.href,node);
                            if([data.hubTx,data.hubRx,...data.ports.flatMap(p=>[p.rx,p.tx])].some(v=>v!==null))return {ok:true,data,loaded:true,readAt:Date.now()};
                        }catch(_){}
                    }
                    await new Promise(resolve=>setTimeout(resolve,250));
                }
                throw Error('Grafana no terminó de cargar las potencias del nodo.');
            };
            try{return await Promise.race([work(),cancelled,new Promise((_,reject)=>{timer=setTimeout(()=>{stopped=true;reject(Error('La consulta de Grafana venció.'));},85000)})]);}
            finally{stopped=true;clearTimeout(timer);if(locked&&graphRuns.get(tabId)?.token===token){busy.delete(tabId);graphRuns.delete(tabId);}}
        }
        chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
            if(msg?.type!=='VIENA_NODE_STATUS_READ')return;
            let allowed=false;
            try{allowed=sender.id===chrome.runtime.id&&new URL(sender.tab?.url||'').origin==='https://viena.telecentro.net.ar'&&sender.frameId===0;}catch(_){}
            if(!allowed){reply({ok:false,message:'Consulta no autorizada.'});return;}
            const kind=String(msg.kind||''),node=String(msg.node||'').trim().toUpperCase();
            if(!['mira','fuente','optico','rphy','grafana'].includes(kind)||!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(node)){reply({ok:false,message:'Nodo o plataforma inválidos.'});return;}
            if(kind==='grafana'){
                const cos=String(msg.cos||'').trim();
                if(cos.length>100||/[\r\n]/.test(cos)){reply({ok:false,message:'COS inválido.'});return;}
                automaticGrafana(node,cos).then(reply).catch(()=>reply({ok:false,message:'No se pudo completar la consulta de Grafana. Reintentá con Actualizar.',diagnostic:{stage:'destino-o-consulta'}}));return true;
            }
            automaticSource(kind,node,sender.tab.id,msg.forceAccessCheck===true).then(reply).catch(()=>reply({ok:false,message:'No se pudo consultar la plataforma en segundo plano. Reintent\u00e1 con Actualizar.'}));
            return true;
        });
        return;
    }
    if (location.hostname !== 'viena.telecentro.net.ar') return;
    const titles = {mira:'MIRA5 · CM Status',fuente:'Fuente · Status TP',optico:'Óptico',rphy:'RPHY · Potencia óptica',grafana:'Grafana · Potencia óptica'};
    let current = null, generation = 0, active = false, pending = false, selected = null, resumeTimer = 0;
    const nodeValid = n => /^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(n);
    function element(tag, text, className) { const el = document.createElement(tag); if (text != null) el.textContent = text; if (className) el.className = className; return el; }
    function style() {
        if (document.getElementById('viena-node-status-css')) return;
        const el = element('style'); el.id = 'viena-node-status-css'; el.textContent = `
        .viena-node-status{flex:0 0 100%;width:100%;min-width:0;box-sizing:border-box;border-top:1px solid #d7e3ef;padding-top:12px;margin-top:10px;color:#20344b;font:13px/1.5 Arial,sans-serif;overflow-wrap:anywhere}
        .viena-node-status header{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}.viena-node-status header strong{font-size:15px}.viena-node-status button{font:600 12px Arial,sans-serif;border:1px solid #b5c9de;border-radius:4px;background:#fff;color:#175e9b;padding:7px 10px;cursor:pointer}.viena-node-status button:disabled{opacity:.6;cursor:default}
        .viena-node-status-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,195px),1fr));gap:9px;margin-top:10px}.viena-node-status article{border:1px solid #d5e1ed;border-radius:6px;padding:11px;min-width:0;background:#fff}.viena-node-status h3{font-size:12px;color:#52677e;margin:0 0 9px}.viena-node-status p{margin:5px 0}.viena-node-status .vns-number{font-size:18px;font-weight:bold}.viena-node-status .vns-mira-green{color:#3c763d}.viena-node-status .vns-mira-orange{color:#8a6d3b}.viena-node-status .vns-mira-red{color:#a94442}.viena-node-status .vns-partial{font-size:12px}.viena-node-status .vns-post-red{color:#a94442;font-weight:bold}.viena-node-status .vns-mira-detail table+table{margin-top:9px}.viena-node-status .vns-muted{font-size:11px;color:#66778a}.viena-node-status a{color:#1764ac}.viena-node-status summary{cursor:pointer;color:#1764ac;padding:7px 0}.viena-node-status table{width:100%;border-collapse:collapse;font-size:12px}.viena-node-status td,.viena-node-status th{padding:5px 3px;text-align:left;border-bottom:1px solid #e1e8ef}.viena-node-status .vns-state{display:inline-block;padding:3px 8px;border-radius:12px;background:#edf0f4;color:#566577}.viena-node-status .vns-up{background:#e3f4e9;color:#21683f}.viena-node-status .vns-down{background:#fde8e8;color:#a32525}.viena-node-status .vns-error{color:#855600}.viena-node-status :focus-visible{outline:2px solid #1976d2;outline-offset:2px}
        .viena-node-status article[hidden]{display:none!important}
        .viena-node-status .vns-rphy-green{color:green}.viena-node-status .vns-rphy-red{color:red}
        html[data-viena-theme="dark"] .viena-node-status .vns-rphy-green,.theme--dark .viena-node-status .vns-rphy-green{color:#75db8a}html[data-viena-theme="dark"] .viena-node-status .vns-rphy-red,.theme--dark .viena-node-status .vns-rphy-red{color:#ff8f8f}
        html[data-viena-theme="dark"] .viena-node-status,.theme--dark .viena-node-status{color:#e2e8f0}.theme--dark .viena-node-status article,html[data-viena-theme="dark"] .viena-node-status article{background:#202d3d;border-color:#455568}.theme--dark .viena-node-status h3,.theme--dark .viena-node-status .vns-muted,html[data-viena-theme="dark"] .viena-node-status h3,html[data-viena-theme="dark"] .viena-node-status .vns-muted{color:#bccbdb}.theme--dark .viena-node-status summary,html[data-viena-theme="dark"] .viena-node-status summary,.theme--dark .viena-node-status a,html[data-viena-theme="dark"] .viena-node-status a{color:#8bc5ff}
        .theme--dark .viena-node-status .vns-post-red,html[data-viena-theme="dark"] .viena-node-status .vns-post-red{color:#ffaaa8}
        `; document.head.append(el);
    }
    // Draw the already loaded report, including closed details, without touching
    // the live DOM or consulting the source platforms again.
    function summaryImage(root,title,ticketId) {
        const cards=[...root.querySelectorAll('article')].filter(card=>!card.hidden&&getComputedStyle(card).display!=='none');
        if(!cards.length)throw Error('No hay información visible para descargar.');
        const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
        if(!ctx)throw Error('No se pudo preparar la imagen.');
        const width=360,gap=16,pad=18,columns=Math.min(cards.length,3),commands=[];
        const text=(value,x,y,max,bold=false,size=13,color='#20344b')=>{
            ctx.font=(bold?'bold ':'')+size+'px Arial';
            const lines=[];let line='';
            for(const word of String(value).trim().split(/\s+/)){
                if(!word)continue;
                if(line&&ctx.measureText(line+' '+word).width>max){lines.push(line);line='';}
                for(const char of word){
                    if(line&&ctx.measureText(line+char).width>max){lines.push(line);line='';}
                    line+=char;
                }
                line+=' ';
            }
            if(line.trim())lines.push(line.trim());
            for(const line of lines){commands.push({text:line.trimEnd(),x,y,size,bold,color});y+=size+7;}
            return y;
        };
        const totalWidth=columns*width+(columns+1)*gap;
        let y=text(title,gap,30,totalWidth-gap*2,true,19);
        y=text('Ticket · '+ticketId+' · Captura '+new Date().toLocaleString('es-AR'),gap,y+7,totalWidth-gap*2,false,12,'#52677e')+12;
        const boxes=[];
        for(let i=0;i<cards.length;i+=columns){
            let bottom=y;
            for(let j=0;j<columns&&i+j<cards.length;j++){
                const x=gap+j*(width+gap),top=y;let cy=y+pad+13;
                const visit=node=>{
                    if(node.hidden||['BUTTON','SCRIPT','STYLE'].includes(node.tagName))return;
                    if(node.tagName==='TABLE'){
                        for(const row of node.querySelectorAll('tr')){
                            const cells=[...row.children],cw=(width-pad*2)/cells.length;let next=cy;
                            cells.forEach((cell,k)=>{next=Math.max(next,text(cell.textContent,x+pad+k*cw,cy,cw-8,cell.tagName==='TH',12,cell.classList.contains('vns-rphy-green')?'green':cell.classList.contains('vns-rphy-red')?'red':cell.classList.contains('vns-post-red')?'#a94442':'#20344b'));});
                            cy=next+6;commands.push({line:true,x:x+pad,y:cy-10,width:width-pad*2});
                        }
                        cy+=4;return;
                    }
                    if(['H3','P','SUMMARY','PRE','A','SPAN'].includes(node.tagName)){
                        const heading=node.tagName==='H3',number=node.classList.contains('vns-number');
                        const color=node.classList.contains('vns-rphy-green')?'green':node.classList.contains('vns-rphy-red')?'red':node.classList.contains('vns-mira-red')?'#a94442':node.classList.contains('vns-mira-orange')?'#8a6d3b':node.classList.contains('vns-mira-green')?'#3c763d':'#20344b';
                        cy=text(node.textContent,x+pad,cy,width-pad*2,heading||number||node.tagName==='SUMMARY',number?18:13,color)+7;return;
                    }
                    for(const child of node.children)visit(child);
                    if(node.tagName==='DETAILS')cy+=5;
                };
                visit(cards[i+j]);bottom=Math.max(bottom,cy+pad-6);boxes.push({x,y:top,width,height:cy+pad-6-top});
            }
            y=bottom+gap;
        }
        // Chrome has finite canvas dimensions. Never download a clipped report.
        if(y>16000||totalWidth*y>16000000)throw Error('El resumen es demasiado grande para una sola imagen.');
        canvas.width=totalWidth*2;canvas.height=Math.ceil(y)*2;ctx.scale(2,2);
        ctx.fillStyle='#f4f7fb';ctx.fillRect(0,0,totalWidth,y);
        for(const b of boxes){ctx.fillStyle='#fff';ctx.fillRect(b.x,b.y,b.width,b.height);ctx.strokeStyle='#d5e1ed';ctx.strokeRect(b.x,b.y,b.width,b.height);}
        for(const c of commands){
            if(c.line){ctx.strokeStyle='#e1e8ef';ctx.beginPath();ctx.moveTo(c.x,c.y);ctx.lineTo(c.x+c.width,c.y);ctx.stroke();continue;}
            ctx.font=(c.bold?'bold ':'')+c.size+'px Arial';ctx.fillStyle=c.color;ctx.fillText(c.text,c.x,c.y);
        }
        return canvas;
    }
    async function downloadImage(c) {
        if(c.exporting||c.running||current!==c)return;
        c.exporting=true;c.imageButton.disabled=true;c.imageButton.textContent='Preparando imagen…';c.imageMessage.hidden=true;
        const version=generation;let timer,url;
        try{
            const canvas=summaryImage(c.root,c.root.querySelector('header strong').textContent,c.ticketId);
            const blob=await new Promise((resolve,reject)=>{
                timer=setTimeout(()=>reject(Error('La imagen demoró demasiado. Reintentá.')),12000);
                canvas.toBlob(b=>b?resolve(b):reject(Error('No se pudo generar la imagen. Reintentá.')),'image/png');
            });
            if(!alive(c,version))return;
            url=URL.createObjectURL(blob);const link=element('a');link.href=url;
            link.download='Resumen-'+c.node+'-'+String(c.ticketId).replace(/[^A-Za-z0-9_-]/g,'_')+'-'+new Date().toISOString().replace(/[:.]/g,'-')+'.png';
            c.root.append(link);try{link.click();}finally{link.remove();}
        }catch(error){if(alive(c,version)){c.imageMessage.textContent=error.message||'No se pudo descargar. Reintentá.';c.imageMessage.hidden=false;}}
        finally{clearTimeout(timer);if(url)setTimeout(()=>URL.revokeObjectURL(url),30000);c.exporting=false;c.imageButton.disabled=!!c.running;c.imageButton.textContent='Descargar imagen';}
    }
    function cancel() { generation++; pending = false; clearTimeout(resumeTimer);resumeTimer=0;current?.root.remove(); current = null; }
    function alive(c,version) { return current === c && version === generation && c.root.isConnected && c.ticket?.isConnected && c.ticket.classList.contains('v-dialog__content--active') && (!c.isCurrent || c.isCurrent()); }
    function time(card,result) {
        const date = new Date(result.readAt); card.append(element('p','Consulta '+date.toLocaleTimeString('es-AR')+(result.loaded ? ' · datos cargados en plataforma' : ''),'vns-muted'));
        card.append(element('p','Hora de muestra no confirmada.','vns-muted'));
    }
    function status(parent,v) { const text=value(v), el=element('span',text,'vns-state'); if (/^up$/i.test(text)) el.classList.add('vns-up'); if (/^down$/i.test(text)) el.classList.add('vns-down'); parent.append(el); }
    function table(parent,head,rows,hideMissing=false) {
        const t=element('table'), tr=element('tr'); head.forEach(h=>tr.append(element('th',h))); t.append(tr);
        rows.forEach(row=>{const tr=element('tr');row.forEach(v=>tr.append(element('td',hideMissing&&v==null?'':value(v))));t.append(tr)});parent.append(t);return t;
    }
    function detail(parent,label) { const d=element('details');d.append(element('summary',label));parent.append(d);return d; }
    function paint(card,kind,result,node) {
        card.hidden=false;
        card.dataset.accessPlatform=result?.needsAccess?result.platform:'';
        card.dataset.retryPlatform=result?.ok?'':kind==='grafana'?'grafana':kind==='mira'?'mira-stats':'fuentes';
        const title=card.querySelector('h3');card.replaceChildren(title);
        if(kind==='mira'&&result?.branches){
            card.dataset.retryPlatform=result.branches.some(b=>!b.result?.ok)?'mira-stats':'';
            for(const branch of result.branches){
                const section=element('section');section.append(element('h3','Nodo CMTS · '+branch.node));
                paint(section,kind,branch.result,node);card.append(section);
            }
            return;
        }
        if(result?.needsAccess){
            card.append(element('p','Acceso requerido'),element('p',result.message,'vns-muted'));
            const link=element('a','Iniciar sesión en '+(kind==='mira'?'MIRA5':'Fuentes'));link.href=result.loginUrl;link.target='_blank';link.rel='noopener';card.append(link);return;
        }
        if (!result?.ok) {
            card.append(element('p',result?.message || 'No se pudo consultar.','vns-error'));
            if(kind==='grafana'&&result?.diagnostic){
                const d=detail(card,'Ver diagnóstico de Grafana'),text=JSON.stringify(result.diagnostic,null,2),pre=element('pre',text),copy=element('button','Copiar diagnóstico');
                pre.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;max-height:240px;overflow:auto;font-size:11px';copy.type='button';
                copy.addEventListener('click',async()=>{copy.disabled=true;try{await navigator.clipboard.writeText(text);copy.textContent='Copiado';}catch(_){copy.textContent='Seleccioná el diagnóstico para copiarlo';}finally{copy.disabled=false;}});
                d.append(copy,pre);
            }
            return;
        }
        if (kind === 'grafana') {
            const g=result.data;table(card,['Extremo','Rx dBm','Tx dBm'],[['Hub',g.hubRx,g.hubTx],...g.ports.map(p=>['RPD · '+p.name,p.rx,p.tx])].map(([name,rx,tx])=>[name,opticalNumber(rx),opticalNumber(tx)]));
            card.append(element('p','MD · '+(g.mds?.length?g.mds.join(' · '):'Sin datos')));
            const cm=g.cmPartialRows||[];
            if(cm.length===1)card.append(element('p','CMs en partial · '+cm[0].count));
            else if(cm.length>1)table(detail(card,'CMs en partial · '+cm.length+' series'),['Serie','CMs'],cm.map(row=>[row.name,row.count]));
            else card.append(element('p','CMs en partial · '+(g.cmPartialStatus==='unavailable'?'No disponible':'Sin datos'),'vns-muted'));
            const d=detail(card,'Ver enlace');d.append(element('p',g.equipment+' · '+g.interface));card.append(element('p','Últimos valores disponibles de Grafana.','vns-muted'));
        } else {
            const scoped=kind==='fuente'||kind==='optico';
            let rows=scoped?result.data.rows.filter(row=>monitored(row,kind).visible):result.data.rows;
            if(kind==='mira'&&rows.length>1&&node&& !result.data.partial){
                // Only disambiguate complete identities; never choose by UP/CM count or order.
                const identity=row=>String(fields(row,'nodo')??'').trim().toUpperCase();
                const exact=rows.filter(row=>identity(row)===node);
                if(rows.every(row=>identity(row))&&exact.length===1)rows=exact;
            }
            if(scoped&&!rows.length&&!result.data.partial){card.append(element('p','Sin monitoría','vns-muted'));time(card,result);return;}
            if (!rows.length) {card.append(element('p','Sin coincidencias confirmadas para este nodo.'));if(result.data.partial)card.append(element('p','Información parcial: hay más resultados en la plataforma.','vns-error'));time(card,result);return;}
            if (kind === 'mira') {
                card.append(element('p','Nodo CMTS · '+value(fields(rows[0],'nodoCmts')),'vns-muted'));
                if(rows.length!==1){card.append(element('p','Hay más de un resultado. Revisá MIRA5.','vns-error'));return;}
                const row=rows[0],up=fields(row,'cmStatus.cmUpPercent'),total=fields(row,'cmStatus.cmTot');
                const validNumber=v=>v!==null&&v!==undefined&&String(v).trim()!==''&&Number.isFinite(Number(v));
                const hasUp=validNumber(up)&&Number(up)>=0&&Number(up)<=100;
                card.append(element('p',hasUp ? value(up)+' % UP' : 'UP \u00b7 Sin monitoreo','vns-number'+(hasUp?' vns-mira-'+(Number(up)<10?'red':Number(up)<90?'orange':'green'):'')));
                card.append(element('p',validNumber(total)&&Number.isSafeInteger(Number(total))&&Number(total)>=0 ? value(total)+' CMs totales' : 'Total CMs · Sin monitoreo'));
                const metrics=miraMetrics(row);
                card.append(element('p','Partial OFDMA · '+metrics.partial,'vns-partial'));
                const d=detail(card,'Ver niveles y FEC');d.className='vns-mira-detail';
                table(d,['Niveles','DS','US'],metrics.levels);
                const fec=element('table'),head=element('tr');
                ['CMs con Post FEC','DS','US'].forEach(label=>head.append(element('th',label)));fec.append(head);
                for(const [label,ds,us] of metrics.fec){
                    const tr=element('tr');tr.append(element('td',label));
                    for(const cell of [ds,us])tr.append(element('td',cell.text,cell.red?'vns-post-red':''));
                    fec.append(tr);
                }
                d.append(fec);
            } else for (const row of rows) {
                const label=kind==='fuente'?'Fuente '+value(fields(row,'idFuente')):kind==='optico'?'Óptico '+value(fields(row,'idOptico')):'RPHY '+value(fields(row,'nodoRPHY'));
                const target=rows.length>1?detail(card,label):card;
                if(rows.length===1&&kind!=='rphy')target.append(element('p',label,'vns-muted'));
                const data=scoped?monitored(row,kind):null;
                if(kind==='fuente'){
                    const location=value(fields(row,'direccion.nodoUbic'));target.append(element('p','Nodo ubic \u00b7 '+(location==='Sin monitoreo'?'No informado':location),'vns-muted'));
                    const nodes=sourceNodes(row);target.append(element('p','Nodos alimenta · '+(nodes.length?nodes.join(' · '):'No informados'),'vns-muted'));
                }
                if(data?.status!==null&&scoped)status(target,data.status);
                if(kind==='fuente'){
                    if(data.inverter!==null)target.append(element('p','Inverter status · '+data.inverter));
                    const b=data.battery;if(b.total!==null)target.append(element('p','Baterías · '+b.total));
                    if(b.rows.length){
                        const d=detail(target,'Ver voltajes por batería');table(d,['Banco','Batería','Voltaje'],b.rows);
                    }
                }
                if(kind==='optico'){
                    const channels=data.channels,columns=[0,...[1,2].filter(i=>channels.some(r=>r[i]!==null))];
                    if(channels.length){table(target,columns.map(i=>['Canal','Rx','Tx'][i]),channels.map(r=>columns.map(i=>r[i])),true);target.append(element('p','Potencias según plataforma.','vns-muted'));}
                }
                if(kind==='rphy'){
                    const state=value(fields(row,'poleo.RPDStatus.1.descripcion'));
                    target.append(element('p','Estado RPD · '+state,state==='Sin monitoreo'||state==='S/D'||state==='NO PRODUCTIVO'?'vns-muted':state==='UP'?'vns-rphy-green':'vns-rphy-red'));
                    const t=table(target,['Extremo','Po Tx','Po Rx'],[['RPHY',fields(row,'poleo.RPDPower.tx'),fields(row,'poleo.RPDPower.rx')],['Leaf',fields(row,'leaf.byLabelActivePorts.TxLanePower.bandwidthLabel'),fields(row,'leaf.byLabelActivePorts.RxLanePower.bandwidthLabel')]]),colors=rphyColors(row);
                    [colors.rphyRx,colors.leafRx].forEach((color,index)=>{if(color)t.children[index+1].children[2].classList.add('vns-rphy-'+color)});
                    target.append(element('p','Valores según plataforma.','vns-muted'));
                }
            }
            if(result.data.partial)card.append(element('p','Información parcial: hay más resultados en la plataforma.','vns-error'));
        }
        time(card,result);
    }
    function request(kind,node,cos='',force=false) {
        return new Promise(resolve=>{
            let done=false,retryTimer;const owner=current,version=generation,started=Date.now();const finish=r=>{if(done)return;done=true;clearTimeout(timer);clearTimeout(retryTimer);console.info('[VIENA resumen]',{platform:kind,node,elapsedMs:Date.now()-started,ok:!!r?.ok,stage:r?.diagnostic?.stage||'',accessRequired:!!r?.needsAccess});resolve(r)};
            const timer=setTimeout(()=>finish({ok:false,message:'La consulta no respondió a tiempo. Reintentá.'}),kind==='grafana'?90000:95000);
            const send=()=>{
                if(done)return;
                if(!alive(owner,version)){finish({ok:false,cancelled:true});return;}
                try{chrome.runtime.sendMessage({type:'VIENA_NODE_STATUS_READ',kind,node,cos,forceAccessCheck:force},r=>{
                    const error=chrome.runtime.lastError;
                    if(!error&&r?.busy){retryTimer=setTimeout(send,300);return;}
                    finish(error?{ok:false,message:'No se pudo consultar. Recargá la extensión si el problema persiste.'}:r);
                });}catch(_){finish({ok:false,message:'No se pudo consultar.'})}
            };send();
        });
    }
    async function run(c,force=false,only=null) {
        if (c.running) {c.rerun=true;return;}
        c.running=true;active=true;const version=generation;c.button.disabled=true;c.button.textContent='Consultando…';c.imageButton.disabled=true;
        try {
            const checkedAccess=new Set();
            const groups=new Map();
            for(const [kind,card] of c.cards){
                const platform=kind==='grafana'?'grafana':kind==='mira'?'mira-stats':'fuentes';
                if(only&&!only.has(platform))continue;
                if(!groups.has(platform))groups.set(platform,[]);
                groups.get(platform).push([kind,card]);
            }
            c.queryingPlatforms=new Set();
            await Promise.allSettled([...groups].map(async([platform,items])=>{
                c.queryingPlatforms.add(platform);
                try{for(const [kind,card] of items){
                if(!alive(c,version))break;
                const forceAccess=force&&!checkedAccess.has(platform);checkedAccess.add(platform);
                const initial=card.querySelector('.vns-pending');if(initial)initial.textContent='Consultando…';
                let result;
                if(kind==='mira'){
                    const nodes=[...new Set(String(c.miraNode||(nodeValid(c.miraFallbackNode)?c.miraFallbackNode:nodeValid(c.node)?c.node:'')).split('|').map(n=>n.trim()))];
                    if(!nodes.length||!nodes.every(nodeValid))result={ok:false,message:'Nodo CMTS no disponible o ambiguo. Revisá el campo del ticket.'};
                    else if(nodes.length===1)result=await request(kind,nodes[0],c.grafanaCos,forceAccess);
                    else{
                        const branches=[];
                        for(const node of nodes){
                            if(!alive(c,version))break;
                            branches.push({node,result:await request(kind,node,c.grafanaCos,forceAccess&&branches.length===0)});
                        }
                        result={branches};
                    }
                    // Empty CMTS: try the explicit ticket message (or Nodo) as an exact CMTS key,
                    // accepting only a complete, unique match of both identities.
                    if(!c.miraNode&&result?.ok){
                        const rows=result.data?.rows,identity=(row,key)=>String(fields(row,key)??'').trim().toUpperCase();
                        const exact=Array.isArray(rows)?rows.filter(row=>identity(row,'nodo')===c.node&&identity(row,'nodoCmts')===nodes[0]):[];
                        if(!result.data?.partial&&rows?.every(row=>identity(row,'nodo')&&identity(row,'nodoCmts'))&&exact.length===1)result={...result,data:{...result.data,rows:exact}};
                        else result={ok:false,message:'No se pudo confirmar un Nodo CMTS único para este nodo. Revisá MIRA5.'};
                    }
                }else result=await request(kind,c.node,c.grafanaCos,forceAccess);
                if(!alive(c,version))break;
                (c.evidence||=new Map()).set(kind,result);paint(card,kind,result,c.node);
                }}finally{c.queryingPlatforms.delete(platform);}
            }));
        } finally {
            c.running=false;if(current===c)active=false;
            c.queryingPlatforms?.clear();
            if(current===c&&!alive(c,version))cancel();
            if(alive(c,version)){c.button.disabled=false;c.button.textContent='Actualizar';c.imageButton.disabled=!!c.exporting;}
            if(alive(c,version)&&c.rerun){c.rerun=false;void run(c);}
            else if(alive(c,version)&&c.retryPlatforms?.size){const retry=c.retryPlatforms;c.retryPlatforms=null;retryFailed(retry);}
        }
    }
    function retryFailed(only=null) {
        const c=current;if(!c?.cards||!alive(c,generation))return;
        const platforms=new Set([...c.cards.values()].map(card=>card.dataset.retryPlatform).filter(p=>p&&(!only||only.has(p))));
        if(!platforms.size)return;
        if(c.running){c.retryPlatforms||=new Set();for(const p of platforms)c.retryPlatforms.add(p);return;}
        void run(c,true,platforms);
    }
    function resumeAfterAccess() {
        clearTimeout(resumeTimer);const c=current;
        resumeTimer=setTimeout(()=>{
            resumeTimer=0;if(current!==c||document.visibilityState==='hidden')return;
            if(c?.running&&c.queryingPlatforms?.size){c.retryPlatforms||=new Set();for(const p of c.queryingPlatforms)c.retryPlatforms.add(p);}
            retryFailed();
        },150);
    }
    function refresh(config) {
        if(!config){if(current&&!current.ticket?.classList.contains('v-dialog__content--active'))cancel();return;}
        if(!config.ftth&&!nodeValid(String(config.node||''))&&config.nodes?.length>1&&config.resolve){
            const choiceKey=config.ticketId+'|'+config.nodes.join('|');
            if(selected?.key===choiceKey&&config.nodes.includes(selected.node))config=config.resolve(selected.node);
            else {
                if(current?.signature===choiceKey&&current.root.isConnected)return;
                cancel();style();const root=element('section',null,'viena-node-status');root.append(element('p','Elegí el nodo para consultar su resumen.'));
                for(const node of config.nodes.filter(nodeValid)){
                    const button=element('button',node);button.type='button';button.addEventListener('click',()=>{selected={key:choiceKey,node};refresh(config.resolve(node))});root.append(button);
                }
                config.host.append(root);current={root,ticket:config.ticket,signature:choiceKey};return;
            }
        }
        const {host,ticket}=config;
        const node=String(config.node||'').trim().toUpperCase(),technology=String(config.technology||'').toUpperCase();
        const kinds=plan({...config,technology});
        if(!host||!ticket||!nodeValid(node)||!kinds.length){cancel();return;}
        const miraNode=String(config.miraNode||'').trim().toUpperCase();
        const miraFallbackNode=String(config.miraFallbackNode||'').trim().toUpperCase();
        const grafanaCos=String(config.grafanaCos||'').trim();
        const signature=[config.ticketId,node,miraNode,miraFallbackNode,technology,grafanaCos,kinds.join(',')].join('|');
        if(current?.signature===signature&&current.root.isConnected){return;}
        cancel();style();
        const root=element('section',null,'viena-node-status');root.setAttribute('aria-label','Resumen del nodo');
        const header=element('header'),button=element('button','Actualizar');button.type='button';header.append(element('strong','Resumen · '+node+(technology?' · '+technology:'')),button);root.append(header);
        const imageButton=element('button','Descargar imagen');imageButton.type='button';imageButton.title='Descargar el resumen con todos sus detalles desplegados';header.append(imageButton);
        const imageMessage=element('p',null,'vns-error');imageMessage.setAttribute('role','status');imageMessage.hidden=true;root.append(imageMessage);
        if(config.chooseAgain){const change=element('button','Cambiar nodo');change.type='button';change.addEventListener('click',()=>{selected=null;cancel();refresh(config.chooseAgain)});header.append(change)}
        const grid=element('div',null,'viena-node-status-grid'),cards=new Map();root.append(grid);
        for(const kind of kinds){const card=element('article');card.append(element('h3',titles[kind]),element('p','Pendiente de consulta.','vns-muted vns-pending'));grid.append(card);cards.set(kind,card)}
        host.append(root);const c={root,host,ticket,node,ticketId:config.ticketId,miraNode,miraFallbackNode,grafanaCos,signature,cards,technology,evidence:new Map(),button,imageButton,imageMessage,isCurrent:config.isCurrent};current=c;imageButton.addEventListener('click',()=>void downloadImage(c));button.addEventListener('click',()=>{if(current===c&&!c.running)void run(c,true)});void run(c);
    }
    chrome.runtime.onMessage.addListener((msg,sender)=>{
        if(msg?.type!=='VIENA_NODE_STATUS_SOURCE_READY'||sender.id!==chrome.runtime.id||sender.tab)return;
        if(!['mira-stats','fuentes'].includes(msg.platform))return;
        retryFailed(new Set([msg.platform]));
    });
    window.addEventListener('focus',resumeAfterAccess);
    document.addEventListener('visibilitychange',resumeAfterAccess);
    document.addEventListener('viena:ui-refresh',()=>refresh());
    window.addEventListener('pagehide',cancel);
    Object.assign(globalThis.VienaNodeStatus,{refresh,cancel});
})();
