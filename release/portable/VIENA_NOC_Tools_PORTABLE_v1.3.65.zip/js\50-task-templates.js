(() => {
    'use strict';
    const PREFIX = 'viena_create_task_templates_v1:';
    const clean = value => String(value ?? '').replace(/\s+/g, ' ').trim();
    const userKey = user => PREFIX + encodeURIComponent(clean(user).toLowerCase());
    const empty = () => ({ schema: 1, revision: '', templates: [] });
    const STARTER_ID = 'ingress-ldi-example-20261009';
    const INGRESS_RESTORE_REQUEST = 'emanuel-ingress-restore-message-options-20261009';
    function ingressStarter() {
        return {id:STARTER_ID,name:'INGRESS LDI',associations:['LDI - Limpieza de Ingress'],body:
            'NODO CMTS: {{NODO_CMTS}}\nTIPO DE INGRESS: {{CAMPO_1}}\nRANGO HORARIO: {{CAMPO_2}}\nMODULACION AFECTACION  : {{CAMPO_3}}\nSaturación por ruido (Si/No): {{CAMPO_4}}\nHAY FIRMAS PNM?: {{CAMPO_5}}\nSE IDENTIFICO PUERTO?: {{CAMPO_6}}',fields:[
                {label:'Tipo de ingress',type:'single',options:['tipo 1','2 parcial','tipo 3'],defaults:['2 parcial']},
                {label:'Rango horario',type:'single',options:['Constante','Intermitente','Otro'],defaults:['Constante'],otherOption:'Otro',otherPlaceholder:'Escribí la franja horaria'},
                {label:'Modulación afectada',type:'multi',options:['QAM','OFDM'],defaults:['QAM']},
                {label:'Saturación por ruido',type:'single',options:['Sí','No'],defaults:[]},
                {label:'Firmas PNM',type:'single',options:['Sin firmas PNM','Con firmas PNM'],defaults:[]},
                {label:'Puerto identificado',type:'text',options:[],defaults:[]}
            ]};
    }
    function withIngressStarter(library) {
        const next = validate(library);
        if (next.installedDefaults?.includes(STARTER_ID)) return next;
        if (!next.templates.some(t => t.id === STARTER_ID || clean(t.name).toUpperCase() === 'INGRESS LDI')) next.templates.push(ingressStarter());
        next.installedDefaults = [...(next.installedDefaults || []),STARTER_ID];
        return validate(next);
    }
    function restoreIngressExample(library) {
        const next = validate(library);
        if (next.ingressRestore?.request === INGRESS_RESTORE_REQUEST) return next;
        const index = next.templates.findIndex(t => clean(t.name).toUpperCase() === 'INGRESS LDI');
        const target = index >= 0 ? index : next.templates.findIndex(t => t.id === STARTER_ID);
        const original = target >= 0 ? next.templates[target] : null;
        const restored = {...ingressStarter(),id:original?.id || STARTER_ID};
        next.ingressRestore = {request:INGRESS_RESTORE_REQUEST,restoredId:restored.id};
        if(original && !sameLibrary(original,restored)) next.ingressRestore.previous = structuredClone(original);
        if(target >= 0) next.templates[target] = restored; else next.templates.push(restored);
        return validate(next);
    }
    function sameLibrary(a, b) {
        const ordered = value => Array.isArray(value) ? value.map(ordered) : value && typeof value === 'object'
            ? Object.fromEntries(Object.keys(value).sort().map(key => [key, ordered(value[key])])) : value;
        return JSON.stringify(ordered(a)) === JSON.stringify(ordered(b));
    }
    function compatibleTypification(associations, selected) {
        const normalized = clean(selected).toUpperCase();
        const code = value => clean(value).toUpperCase().match(/^([A-Z][A-Z0-9]*)(?:\s*[-–—:]\s*.+|$)/)?.[1];
        return !associations.length || associations.some(value => clean(value).toUpperCase() === normalized || Boolean(code(value) && code(value) === code(normalized)));
    }
    function parseAssociations(value) {
        return [...new Set(value.split('\n').flatMap(line => {
            const parts = line.split(/[,;]+/).map(clean).filter(Boolean);
            return parts.length > 1 && parts.every(part => /^[a-z][a-z0-9]*$/i.test(part)) ? parts : [clean(line)];
        }).filter(Boolean))];
    }
    function messageParts(template) {
        const parts = []; let cursor = 0;
        for (const match of template.body.matchAll(/\{\{(NODO_CMTS|CAMPO_(\d+))\}\}/g)) {
            if (match.index > cursor) parts.push({text:template.body.slice(cursor,match.index)});
            parts.push(match[1] === 'NODO_CMTS' ? {node:true,label:'Nodo CMTS'} : {field:Number(match[2])-1,label:template.fields[Number(match[2])-1]?.label || 'Pregunta eliminada'});
            cursor = match.index + match[0].length;
        }
        if (cursor < template.body.length) parts.push({text:template.body.slice(cursor)});
        return parts;
    }
    function optionsFromMessage(template) {
        const next = structuredClone(template);
        for(let index = next.fields.length-1;index >= 0;index--) {
            const f = next.fields[index];
            if(!clean(f.label) && !f.options.length && !f.defaults?.length) {
                const token = '{{CAMPO_' + (index+1) + '}}';
                next.body = removeQuestionBody(next.body.split('\n').filter(line => line.trim() !== token).join('\n'),index); next.fields.splice(index,1);
            }
        }
        const normalized = value => clean(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase();
        next.body = next.body.split('\n').map(line => {
            if(/^\s*NODO(?: CMTS)?\s*$/i.test(line)) return line.trim() + ': {{NODO_CMTS}}';
            const match = line.match(/^([ \t]*([^:\n{}]{1,150}?):[ \t]*)(.*)$/);
            if(!match) return line;
            const label = clean(match[2]), value = match[3], prefix = match[1] + (/\s$/.test(match[1]) ? '' : ' ');
            if(/^NODO(?: CMTS)?$/i.test(label)) return prefix + '{{NODO_CMTS}}';
            const tokens = [...value.matchAll(/\{\{CAMPO_(\d+)\}\}/g)];
            if(tokens.length) return line; // Existing configured answers keep their identity and payload.
            if(value.includes('{{')) return line;
            let index = next.fields.findIndex(f => normalized(f.label) === normalized(label));
            if(index < 0) {
                index = next.fields.length; next.fields.push({label,type:'text',options:[],defaults:value ? [value] : []});
            } else {
                const f = next.fields[index];
                if(value) { if(f.type !== 'text' && !f.options.includes(value)) f.options.push(value); f.defaults = [value]; }
                if(f.includeLabel) f.includeLabel = false;
            }
            return prefix + '{{CAMPO_' + (index+1) + '}}';
        }).join('\n');
        return next;
    }
    function removeQuestionBody(body, index) {
        return body.replace(/\{\{CAMPO_(\d+)\}\}/g,(token,number) => Number(number)-1 === index ? '' : Number(number)-1 > index ? '{{CAMPO_' + (Number(number)-1) + '}}' : token);
    }
    function validate(value) {
        if (value === undefined) return empty();
        if (!value || value.schema !== 1 || !Array.isArray(value.templates) || value.templates.length > 50) throw Error('Biblioteca inválida. Se conservó la configuración guardada.');
        if (value.installedDefaults !== undefined && (!Array.isArray(value.installedDefaults) || value.installedDefaults.length > 100 || value.installedDefaults.some(v => typeof v !== 'string'))) throw Error('Biblioteca inválida. Se conservó la configuración guardada.');
        if(value.ingressRestore !== undefined) {
            if(!value.ingressRestore || typeof value.ingressRestore.request !== 'string' || typeof value.ingressRestore.restoredId !== 'string') throw Error('La copia de restauración no es válida. Se conservó la biblioteca.');
            if(value.ingressRestore.previous) validate({schema:1,templates:[value.ingressRestore.previous]});
        }
        const ids = new Set();
        for (const t of value.templates) {
            if (!t || typeof t.id !== 'string' || !t.id || ids.has(t.id) || typeof t.name !== 'string' || !clean(t.name) || t.name.length > 150 || typeof t.body !== 'string' || t.body.length > 20000
                || !Array.isArray(t.associations) || t.associations.length > 100 || t.associations.some(a => typeof a !== 'string') || !Array.isArray(t.fields) || t.fields.length > 30) throw Error('Template inválido. Se conservó la configuración guardada.');
            ids.add(t.id);
            for (const f of t.fields) {
                if (typeof f.label !== 'string' || !clean(f.label) || f.label.length > 150 || !['single', 'multi', 'text'].includes(f.type) || !Array.isArray(f.options) || f.options.length > 100 || f.options.some(o => typeof o !== 'string' || !clean(o) || o.length > 500)) throw Error('Revisá los campos y opciones del template.');
                if (f.type !== 'text' && !f.options.length) throw Error('Un campo de selección necesita opciones.');
                if (f.defaults !== undefined && (!Array.isArray(f.defaults) || f.defaults.some(o => typeof o !== 'string' || (f.type !== 'text' && !f.options.includes(o))) || (f.type !== 'multi' && f.defaults.length > 1))) throw Error('Revisá la respuesta predeterminada del campo.');
                if (f.otherOption && (f.type !== 'single' || typeof f.otherOption !== 'string' || !f.options.includes(f.otherOption))) throw Error('La opción con texto libre debe existir en un campo de selección única.');
                if (f.otherPlaceholder !== undefined && (typeof f.otherPlaceholder !== 'string' || f.otherPlaceholder.length > 150)) throw Error('Revisá la ayuda del texto libre.');
                if (f.includeLabel !== undefined && typeof f.includeLabel !== 'boolean') throw Error('Revisá la pregunta del template.');
            }
        }
        if (JSON.stringify(value).length > 500000) throw Error('La biblioteca supera el tamaño permitido.');
        return structuredClone(value);
    }
    function compose(template, answers, node) {
        if (template.body.includes('{{NODO_CMTS}}') && !node) throw Error('Elegí o ingresá el Nodo CMTS antes de aplicar.');
        const replaceAnswer = (body,token,value) => body.replaceAll(token,(_,offset) => (body[offset-1] === ':' && !/^\s/.test(value) ? ' ' : '') + value);
        let text = replaceAnswer(template.body,'{{NODO_CMTS}}',node || '');
        const appended = [];
        template.fields.forEach((field, index) => {
            const response = answers[index] ?? field.defaults ?? [];
            let value = (Array.isArray(response) ? response : [response]).map(String).join(', ');
            if (field.otherOption && value === field.otherOption) {
                value = clean(answers[index + '_other']);
                if (!value) throw Error(field.otherPlaceholder || 'Completá el texto de ' + field.label + '.');
            }
            const token = '{{CAMPO_' + (index + 1) + '}}';
            if (text.includes(token)) text = replaceAnswer(text,token,field.includeLabel ? field.label + ': ' + value : value);
            else if (value) appended.push(field.label + ': ' + value);
        });
        if (/\{\{(?:CAMPO_\d+|NODO_CMTS)\}\}/.test(text)) throw Error('El texto referencia un campo que no existe. Revisá el template.');
        return [text, ...appended].filter(Boolean).join('\n');
    }
    function nodeCandidates(ticket, message) {
        const values = [];
        const add = value => String(value || '').split(/[|,;\/\s]+/).filter(v => /^[a-z0-9][a-z0-9_-]*$/i.test(v)).forEach(v => values.push(v.toUpperCase()));
        add(ticket);
        const cmts = [...String(message || '').matchAll(/\bNODO[ \t]+CMTS[ \t]*:[ \t]*([^\r\n]*)/gi)].filter(match => match[1].trim());
        const matches = cmts.length ? cmts : String(message || '').matchAll(/\bNODO[ \t]*:[ \t]*([^\r\n]*)/gi);
        for (const match of matches) add(match[1]);
        return [...new Set(values)];
    }
    const api = { validate, compose, nodeCandidates, userKey, sameLibrary, ingressStarter, withIngressStarter, restoreIngressExample, optionsFromMessage, compatibleTypification, parseAssociations, messageParts, removeQuestionBody };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    if (typeof document === 'undefined' || !document.body || !globalThis.chrome?.storage?.local || globalThis.VienaTaskTemplates) return;
    globalThis.VienaTaskTemplates = api;
    let session = null, opening = 0;
    const pendingWrites = new Map();
    const user = () => {
        const name = clean(globalThis.VienaUserConfig?.detectar?.() || globalThis.VienaUserConfig?.current).toLowerCase();
        return /^[a-z][a-z0-9._-]{2,30}$/.test(name) ? name : '';
    };
    const visible = el => Boolean(el?.isConnected && el.getClientRects().length && !el.closest('[hidden]'));
    function field(root, name) {
        const label = [...root.querySelectorAll('label')].find(el => !el.closest('.viena-task-templates,.viena-ticket-fields-bar') && clean(el.textContent).toLowerCase() === name.toLowerCase());
        return label?.closest('.v-input') || null;
    }
    function selectedText(root, name) {
        const group = field(root, name);
        const select = group?.querySelector('select');
        return clean(select ? select.selectedOptions[0]?.textContent : group?.querySelector('.v-select__selection,.v-select__selections')?.textContent || group?.querySelector('input')?.value);
    }
    function nativeMessage(root) { return field(root, 'Mensaje')?.querySelector('textarea:not([readonly])') || null; }
    const creationIdentity = root => clean(root.querySelector('.v-toolbar__title')?.textContent);
    function rootNow() {
        return [...document.querySelectorAll('.v-dialog__content--active')].filter(visible).reverse()
            .find(el => /^Creando tarea\s*:/i.test(clean(el.querySelector('.v-toolbar__title')?.textContent))) || null;
    }
    function ticketNode() {
        const roots = [...document.querySelectorAll('.v-dialog__content--active')].filter(visible)
            .filter(el => /^TICKET\s*:/i.test(clean(el.querySelector('.v-toolbar__title')?.textContent)));
        if (roots.length !== 1) return '';
        const read = name => {
            const group = field(roots[0], name);
            const selections = group?.querySelectorAll('option:checked,.v-select__selection');
            if (selections?.length) return [...selections].map(el => clean(el.textContent)).filter(Boolean).join(' | ');
            return selectedText(roots[0], name) || group?.querySelector('textarea')?.value?.trim() || '';
        };
        return read('Nodo CMTS') || read('Nodo');
    }
    function bounded(promise) {
        let timer;
        return Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(Error('La operación demoró demasiado. Conservamos tus cambios para reintentar.')), 3000); })]).finally(() => clearTimeout(timer));
    }
    function el(tag, text, attribute) {
        const node = document.createElement(tag);
        if (text !== undefined) node.textContent = text;
        if (attribute) node.setAttribute('data-task-' + attribute, '');
        return node;
    }
    function button(text, attribute, action) {
        const node = el('button', text, attribute); node.type = 'button';
        node.addEventListener('click', action); return node;
    }
    function input(labelText, tag, attribute, container) {
        const label = el('label', labelText), node = el(tag, undefined, attribute);
        label.append(node); container.append(label); return node;
    }
    function styles() {
        if (document.getElementById('viena-task-templates-style')) return;
        const style = el('style'); style.id = 'viena-task-templates-style';
        style.textContent = `
        .viena-task-template-dialog {width:min(960px,calc(100vw - 24px))!important;max-width:calc(100vw - 24px)!important;max-height:calc(100vh - 32px)!important;overflow:auto!important;}
        .viena-task-templates {font:13px/1.4 Arial,sans-serif;color:#172b4d;min-width:0;margin:10px 0;}
        .viena-task-templates [hidden] {display:none!important;}
        .viena-task-templates button {border:1px solid #b7c9df;border-radius:5px;background:#fff;color:#174b83;padding:6px 10px;cursor:pointer;min-height:34px;white-space:normal;}
        .viena-task-templates button[aria-pressed=true],.viena-task-templates [data-task-save],.viena-task-templates [data-task-replace-confirm] {background:#173f7a;color:white;border-color:#173f7a;}
        .viena-task-templates button:disabled {opacity:.6;cursor:wait;}
        .viena-task-templates label {display:block;margin:7px 0;}
        .viena-task-templates input:not([type=checkbox]):not([type=radio]),.viena-task-templates select,.viena-task-templates textarea {box-sizing:border-box;width:100%;max-width:100%;border:1px solid #aebfd4;border-radius:5px;padding:8px;background:white;color:#172b4d;font:inherit;}
        .viena-task-templates textarea {min-height:110px;resize:vertical;}
        .viena-task-template-bar {display:flex;gap:8px;flex-wrap:wrap;align-items:center;}
        .viena-task-template-modes {display:inline-flex;flex-wrap:nowrap;gap:0;border:1px solid #b7c9df;padding:3px;border-radius:5px;}
        .viena-task-template-modes button {border:0;}
        .viena-task-template-bar [data-task-all],.viena-task-template-bar [data-task-new],.viena-task-template-bar [data-task-edit],.viena-task-templates [data-task-edit-fields] {border:0;background:transparent;color:#007bff;padding:4px;}
        .viena-task-template-editor {position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:min(740px,calc(100vw - 32px));max-height:calc(100vh - 48px);overflow:auto;z-index:2147483000;background:white;box-shadow:0 0 0 100vmax rgba(0,0,0,.4);box-sizing:border-box;}
        [data-task-editor-shade] {display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:2147482999;}
        [data-task-editor]:not([hidden]) + [data-task-editor-shade] {display:block;}
        .viena-task-template-help {font-size:12px;color:#536c8d;margin:6px 0;}
        .viena-task-template-bar select {flex:1 1 230px;min-width:0;width:auto;}
        .viena-task-template-grid {display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px;margin-top:12px;}
        .viena-task-template-panel {border:1px solid #d1dbe7;border-radius:7px;padding:12px;min-width:0;}
        .viena-task-template-panel h3 {font:700 15px Arial;margin:0 0 10px;}
        .viena-task-template-choice {display:flex!important;align-items:center;gap:7px;}
        .viena-task-template-answer-row {display:grid;grid-template-columns:minmax(100px,.8fr) minmax(0,1.5fr);align-items:center;gap:10px;margin:10px 0;}
        .viena-task-template-answer-row > strong {font-weight:400;}
        .viena-task-template-choices {display:flex;gap:8px 14px;flex-wrap:wrap;}
        .viena-task-template-status {margin:8px 0;overflow-wrap:anywhere;}
        .viena-task-template-native-grid {display:grid!important;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px;align-items:start;}
        .viena-task-template-native-grid > .col {width:auto!important;max-width:100%!important;min-width:0;flex:none!important;}
        .viena-task-template-native-grid > .viena-task-template-panel {margin:12px;}
        .viena-task-template-message-panel {border:1px solid #d1dbe7;border-radius:7px;padding:12px!important;margin:12px;}
        .viena-task-template-message-panel .v-input {margin-top:0!important;}
        .viena-task-template-message-panel textarea {min-height:220px;}
        .viena-task-template-message-panel .viena-task-templates {margin-bottom:0;}
        .viena-task-templates [data-task-node-detected] {background:#eef3f9;}
        [data-viena-theme=dark] .viena-task-template-message-panel,.theme--dark .viena-task-template-message-panel {border-color:#64748b;}
        [data-viena-theme=dark] .viena-task-templates,.theme--dark .viena-task-templates {color:#e3ebf6;background:#1e293b;border-color:#64748b;}
        [data-viena-theme=dark] .viena-task-templates button,.theme--dark .viena-task-templates button {background:#223650;color:#e3ebf6;}
        [data-viena-theme=dark] .viena-task-templates button[aria-pressed=true],.theme--dark .viena-task-templates button[aria-pressed=true] {background:#315f99;color:#fff;}
        [data-viena-theme=dark] .viena-task-templates input:not([type=radio]):not([type=checkbox]),[data-viena-theme=dark] .viena-task-templates textarea,[data-viena-theme=dark] .viena-task-templates select,.theme--dark .viena-task-templates input:not([type=radio]):not([type=checkbox]),.theme--dark .viena-task-templates textarea,.theme--dark .viena-task-templates select {background:#17283e;color:#eef4ff;}
        /* Geometry/colors from the approved 1649x954 reference. Native controls
           keep their parents and listeners; only the first-step scope changes. */
        .viena-task-template-dialog {--task-bg:#fff;--task-fg:#101b52;--task-label:#506d94;--task-border:#dce5f1;--task-muted:#e7edf5;width:min(988px,calc(100vw - 32px))!important;border-radius:6px!important;font:14px Arial,sans-serif;color:var(--task-fg);margin-top:40px!important;margin-bottom:0!important;max-height:calc(100vh - 72px)!important;}
        .viena-task-template-creation-root,.viena-task-template-dialog {transform:none!important;scale:1!important;zoom:1!important;animation:none!important;transition:none!important;}
        .viena-task-template-dialog.viena-task-template-expanded {width:calc(100vw - 32px)!important;max-width:calc(100vw - 32px)!important;max-height:calc(100vh - 32px)!important;margin-top:0!important;}
        [data-viena-theme=dark] .viena-task-template-dialog,.theme--dark .viena-task-template-dialog {--task-bg:#18263b;--task-fg:#eef4ff;--task-label:#b8c9df;--task-border:#526780;--task-muted:#253b56;}
        .viena-task-template-dialog .v-card {background:var(--task-bg);color:var(--task-fg);}
        .viena-task-template-dialog > .v-card > .v-card__text {padding:0!important;}
        .viena-task-template-dialog header.v-toolbar,.viena-task-template-dialog header.v-toolbar .v-toolbar__content {height:52px!important;min-height:52px!important;background:#0085ff!important;color:white!important;}
        .viena-task-template-dialog header.v-toolbar .v-toolbar__content {padding:0 28px!important;}
        .viena-task-template-dialog header.v-toolbar .v-toolbar__title {font:700 24px Arial!important;color:white!important;}
        .viena-task-template-dialog header.v-toolbar .v-toolbar__title {min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
        .viena-task-template-dialog header.v-toolbar .viena-task-template-size-host {display:inline-flex;align-items:center;flex:0 0 auto;margin:0;background:transparent!important;}
        .viena-task-template-dialog header.v-toolbar .viena-task-template-size {font:600 14px Arial!important;color:#101b52!important;background:#fff!important;border:1px solid #dce5f1;border-radius:5px;width:auto!important;height:34px!important;min-width:86px!important;padding:0 14px!important;margin-right:8px;}
        .viena-task-template-dialog header.v-toolbar button {border:0;background:transparent;color:white;font-size:32px;min-width:40px;width:40px;height:40px;padding:0;}
        .viena-task-template-dialog .v-card__text:has(> .viena-task-template-form) {padding:18px 22px 20px!important;}
        .viena-task-template-form {display:grid;grid-template-columns:1.28fr 1fr 1fr;column-gap:20px;row-gap:18px;}
        .viena-task-template-form > * {grid-column:1/-1;min-width:0;}
        .viena-task-template-form > .viena-task-template-header-0 {grid-column:1;grid-row:1;}
        .viena-task-template-form > .viena-task-template-header-1 {grid-column:2;grid-row:1;}
        .viena-task-template-form > .viena-task-template-header-2 {grid-column:3;grid-row:1;}
        .viena-task-template-form > .row {margin:0!important;}
        .viena-task-template-form > .row > .col {padding:0!important;min-width:0;}
        .viena-task-template-form > .row:has(> .col:empty) {display:none;}
        .viena-task-template-native-header-field {margin:22px 0 0!important;min-width:0;}
        .viena-task-template-native-header-field .v-input__slot {position:relative;min-height:36px!important;height:36px!important;padding:0 12px!important;border:1px solid var(--task-border);border-radius:5px;background:var(--task-bg);margin:0!important;}
        .viena-task-template-native-header-field .v-input__slot label {position:absolute!important;left:0!important;top:-22px!important;transform:none!important;font:14px Arial!important;color:var(--task-label)!important;}
        .viena-task-template-native-header-field fieldset {display:none;}
        .viena-task-template-native-header-field input,.viena-task-template-native-header-field select,.viena-task-template-native-header-field .v-select__selection {font:14px Arial!important;color:var(--task-fg)!important;max-width:100%;min-height:0;}
        .viena-task-template-native-header-field .v-select__selections {padding:0!important;min-height:0!important;}
        .viena-task-template-native-header-field.v-select .v-input__slot {height:auto!important;}
        .viena-task-template-native-header-field .v-select__slot {position:static!important;height:auto!important;min-height:34px;}
        .viena-task-template-native-header-field .v-select__selections {flex-wrap:nowrap!important;}
        .viena-task-template-native-header-field .v-select__selection--comma {white-space:normal!important;text-overflow:clip!important;overflow:visible!important;overflow-wrap:anywhere;line-height:16px!important;margin:0!important;}
        .viena-task-template-native-header-field .v-select__selections > input {flex:0 0 0!important;width:0!important;min-width:0!important;padding:0!important;margin:0!important;}
        .viena-task-template-native-header-field .v-input__append-inner {align-self:center!important;margin-top:0!important;flex-shrink:0;}
        .viena-task-template-native-header-field:has(input[readonly]) .v-input__slot {background:var(--task-muted);}
        .viena-task-templates {font:14px/1.4 Arial;color:var(--task-fg,#101b52);margin:0;}
        [data-task-root] > label {margin:0 0 4px;color:var(--task-label,#506d94);}
        .viena-task-template-form > [data-task-root] {margin-top:-4px;}
        .viena-task-template-modes {display:grid;grid-template-columns:1fr 1fr;width:min(500px,100%);height:44px;padding:3px;gap:0;border-color:#afbfdb;}
        .viena-task-template-modes button {font:14px Arial;min-height:36px;padding:0 12px;color:var(--task-fg,#101b52);}
        .viena-task-template-modes button[aria-pressed=true] {background:#0085ff!important;color:white!important;}
        .viena-task-note-toolbar {display:flex;align-items:center;justify-content:space-between;gap:12px 16px;flex-wrap:wrap;margin-bottom:16px;}
        .viena-task-note-toolbar > .viena-task-template-modes {flex:0 1 440px;width:min(440px,100%);min-width:0;box-sizing:border-box;height:36px;}
        .viena-task-note-toolbar > .viena-task-template-modes button {min-width:0;min-height:28px;padding:0 8px;font-size:13px;line-height:14px;}
        .viena-task-note-toolbar > [data-task-note-toggle] {display:inline-flex;align-items:center;justify-content:center;gap:8px;box-sizing:border-box;height:36px;min-height:36px;margin-left:auto;padding:0 12px;font:14px Arial;border-color:#0085ff;color:#006edb;background:var(--task-bg,#fff);white-space:nowrap;}
        .viena-task-note-panel {border:1px solid var(--task-border,#afbfdb);border-radius:5px;padding:12px;margin-top:10px;min-width:0;background:var(--task-bg,#fff);color:var(--task-fg,#101b52);}
        .viena-task-note-panel[hidden] {display:none!important;}
        .viena-task-note-panel p {font-size:12px;margin:6px 0;}
        .viena-task-note-panel label {display:block;margin:8px 0;}
        .viena-task-note-panel input:not([type=checkbox]),.viena-task-note-panel textarea {box-sizing:border-box;width:100%;max-width:100%;}
        .viena-task-note-panel .viena-task-note-auto {display:flex;align-items:center;gap:8px;}
        .viena-task-note-panel button {margin:4px 8px 4px 0;}
        .viena-task-note-panel [data-task-note-status] {font-size:13px;overflow-wrap:anywhere;}
        .viena-task-note-result {position:fixed;right:16px;bottom:16px;z-index:2147483000;box-sizing:border-box;width:min(430px,calc(100vw - 32px));max-height:60vh;overflow:auto;background:#fff;color:#101b52;box-shadow:0 4px 20px #0003;}
        .viena-task-note-result:not(.viena-task-note-inspect) > :not([data-task-note-status]):not([data-task-note-dismiss]):not([data-task-note-retry]):not([data-task-note-inspect]) {display:none;}
        .viena-task-template-custom > label {margin:18px 0 5px;color:var(--task-label,#506d94);}
        .viena-task-template-custom > .viena-task-template-bar {gap:8px;}
        .viena-task-template-custom > .viena-task-template-bar select {flex:1 1 240px;height:36px;padding:0 14px;border-color:var(--task-border,#dce5f1);font:14px Arial;}
        .viena-task-template-custom > .viena-task-template-bar button {min-height:36px;padding:6px 12px;border:1px solid var(--task-border,#b7c9df);border-radius:5px;background:var(--task-bg,#fff)!important;font:600 14px Arial;color:var(--task-fg,#101b52)!important;}
        .viena-task-template-custom > .viena-task-template-bar [data-task-new] {background:var(--task-muted,#e7edf5)!important;border-color:#83baff;}
        .viena-task-template-status:empty {display:none;}
        .viena-task-template-status[data-kind=info] {position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);margin:0;}
        .viena-task-template-native-grid {grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:8px;align-items:stretch;}
        .viena-task-template-native-grid > .viena-task-template-panel,.viena-task-template-message-panel {margin:0!important;padding:16px 18px!important;border:1px solid var(--task-border,#dce5f1);border-radius:5px;min-height:386px;box-sizing:border-box;}
        .viena-task-template-native-grid > .col.viena-task-template-message-panel {padding:16px 18px!important;}
        .viena-task-template-panel h3,.viena-task-template-message-heading {font:700 18px/22px Arial;color:var(--task-fg,#101b52);margin:0 0 16px;}
        .viena-task-template-node-row {display:grid;grid-template-columns:minmax(0,1fr) 82px;gap:8px;align-items:center;margin-bottom:6px;min-height:36px;}
        .viena-task-template-node-row > label {display:grid;grid-template-columns:minmax(0,1fr);gap:4px;align-items:center;margin:0;color:var(--task-label,#506d94);}
        .viena-task-templates [data-task-node-detected] {height:36px;padding:0 12px;font:14px Arial;background:var(--task-muted,#e7edf5)!important;color:var(--task-label,#506d94)!important;border-color:var(--task-border,#dce5f1);}
        .viena-task-templates [data-task-node-edit] {border:0;border-radius:18px;min-height:30px;padding:0 8px;background:#d6ebff!important;color:#0085ff!important;font:14px Arial;}
        .viena-task-template-answer-row {grid-template-columns:132px minmax(0,1fr);gap:8px;min-height:40px;margin:0;}
        .viena-task-template-answer-row > strong {font:14px Arial;color:var(--task-label,#506d94);}
        .viena-task-template-choices {gap:10px 16px;}
        .viena-task-template-choices .viena-task-template-choice {margin:0;font:14px Arial;gap:8px;}
        .viena-task-template-choice input {width:18px;height:18px;margin:0;accent-color:#0085ff;flex-shrink:0;}
        .viena-task-template-answer-row > label {margin:0;}
        .viena-task-template-answer-row:has(textarea[data-task-answer]) {grid-template-columns:minmax(0,1fr);gap:6px;margin:12px 0;}
        .viena-task-template-answer-row > label textarea[data-task-answer] {width:100%;max-width:100%;min-height:72px;height:80px;padding:8px 12px;resize:vertical;font:14px/1.45 Arial;border-color:var(--task-border,#dce5f1);}
        .viena-task-template-answer-row > label textarea[data-task-answer]:focus-visible {outline:2px solid #83baff;outline-offset:1px;border-color:#0085ff;}
        .viena-task-templates [data-task-other-answer] {height:36px;padding:0 12px;width:100%;}
        .viena-task-templates [data-task-edit-fields] {display:block;width:100%;padding:8px 12px;margin-top:12px;min-height:36px;border:1px solid var(--task-border,#b7c9df);border-radius:5px;background:var(--task-muted,#e7edf5)!important;color:var(--task-fg,#101b52)!important;font:600 14px Arial;text-decoration:none;}
        .viena-task-template-custom > .viena-task-template-bar button:hover,.viena-task-templates [data-task-edit-fields]:hover {border-color:#0085ff;}
        .viena-task-template-custom > .viena-task-template-bar button:focus-visible,.viena-task-templates [data-task-edit-fields]:focus-visible,.viena-task-template-size:focus-visible {outline:2px solid #83baff;outline-offset:2px;}
        .viena-task-template-message-panel .viena-task-template-native-message {margin:0!important;}
        .viena-task-template-message-panel .viena-task-template-native-message label {display:none!important;}
        .viena-task-template-native-message .v-input__slot {padding:12px!important;border:1px solid #afbfdb;border-radius:5px;background:var(--task-bg)!important;margin:0!important;}
        .viena-task-template-native-message fieldset {display:none;}
        .viena-task-template-native-message textarea {min-height:222px;height:222px;padding:0!important;font:14px/1.55 Arial!important;color:var(--task-fg)!important;resize:vertical;}
        .viena-task-template-native-message > textarea {height:248px;min-height:248px;border:1px solid #afbfdb;border-radius:5px;padding:12px!important;}
        .viena-task-template-message-panel [data-task-message-tools] {margin:12px 0 0;}
        .viena-task-templates [data-task-apply] {border:0;padding:0;min-height:18px;background:transparent!important;color:#0085ff!important;font:14px Arial;text-decoration:underline;}
        .viena-task-templates [data-task-replace] {display:flex;flex-wrap:wrap;gap:10px;margin-top:12px;}
        .viena-task-templates [data-task-replace] > p {flex-basis:100%;margin:0;}
        .viena-task-template-bar [data-task-all],.viena-task-template-bar [data-task-new],.viena-task-template-bar [data-task-edit] {border:1px solid var(--task-border,#b7c9df);border-radius:5px;padding:6px 10px;min-height:34px;background:var(--task-bg,#fff);font:14px Arial;}
        .viena-task-template-bar [data-task-all][aria-pressed=true] {background:#173f7a!important;color:white!important;}
        .viena-task-templates [data-task-apply] {border:1px solid #007bff;border-radius:5px;padding:8px 14px;min-height:36px;background:#007bff!important;color:white!important;text-decoration:none;}
        .viena-task-template-help {font:12px/1.4 Arial;color:var(--task-label,#506d94);margin:6px 0 0;}
        .viena-task-template-dialog hr {display:none;}
        .viena-task-template-actions {min-height:68px;padding:12px 18px!important;border-top:1px solid var(--task-border,#dce5f1);display:flex;justify-content:flex-end;align-items:center;gap:16px;}
        .viena-task-template-actions {position:sticky;bottom:0;z-index:2;background:var(--task-bg,#fff);}
        .viena-task-template-create {min-width:104px;min-height:38px;border:0;border-radius:5px;background:#0085ff!important;color:white!important;font:700 14px Arial;text-transform:uppercase;}
        .viena-task-template-dialog .viena-task-template-actions .viena-task-template-create,.viena-task-template-dialog .viena-task-template-create .v-btn__content {color:white!important;opacity:1!important;}
        .viena-task-template-dialog .viena-task-template-actions .viena-task-template-create {background:#006edb!important;}
        .viena-task-template-dialog .viena-task-template-actions .viena-task-template-create:disabled,.viena-task-template-dialog .viena-task-template-actions .viena-task-template-create.v-btn--disabled {background:#53657b!important;color:white!important;opacity:1!important;cursor:not-allowed;}
        .viena-task-template-cancel {min-width:92px;min-height:38px;border:0;background:transparent!important;color:#0085ff!important;font:14px Arial;text-transform:uppercase;}
        @media(max-width:700px) {.viena-task-template-form {grid-template-columns:1fr;gap:16px;}.viena-task-template-form > [class*=viena-task-template-header-] {grid-column:1;grid-row:auto;}.viena-task-template-custom > .viena-task-template-bar {gap:8px 14px;}.viena-task-template-custom > .viena-task-template-bar select {flex:1 1 100%;}.viena-task-template-native-grid {grid-template-columns:1fr;}.viena-task-template-node-row > label,.viena-task-template-answer-row {grid-template-columns:105px minmax(0,1fr);}.viena-task-template-dialog header.v-toolbar .v-toolbar__title {font-size:18px!important;}.viena-task-template-dialog header.v-toolbar .v-toolbar__content {padding:0 16px!important;}.viena-task-template-node-row {grid-template-columns:minmax(0,1fr) 68px;}.viena-task-templates [data-task-node-edit] {font-size:12px;}.viena-task-template-native-grid > .viena-task-template-panel,.viena-task-template-message-panel {padding:14px!important;}}
        @media(max-width:700px) {.viena-task-template-grid,.viena-task-template-native-grid{grid-template-columns:minmax(0,1fr);}.viena-task-template-dialog{width:calc(100vw - 16px)!important;max-width:calc(100vw - 16px)!important;margin-top:0!important;max-height:calc(100vh - 32px)!important;}.viena-task-templates button{flex:0 1 auto;}}
        .viena-task-template-dialog .viena-task-templates button:not([data-task-editor-close]),
        .viena-task-template-dialog .viena-task-template-create,.viena-task-template-dialog .viena-task-template-cancel,
        .viena-task-template-dialog header.v-toolbar .viena-task-template-size {font:600 15px/20px Arial,sans-serif!important;min-height:36px;white-space:normal;overflow-wrap:anywhere;}
        .viena-task-note-toolbar > .viena-task-template-modes {height:auto;min-height:44px;}
        .viena-task-template-dialog .viena-task-note-toolbar > button[data-task-note-toggle] {height:auto;min-height:44px;white-space:nowrap;}
        .viena-task-template-node-row {grid-template-columns:minmax(0,1fr) auto;align-items:end;}
        .viena-task-template-node-row > label {grid-template-columns:minmax(0,1fr);}
        .viena-task-templates [data-task-node-edit] {align-self:end;box-sizing:border-box;height:auto;min-height:36px;min-width:0;}
        @media(max-width:300px) {.viena-task-template-node-row {grid-template-columns:minmax(0,1fr);}.viena-task-templates [data-task-node-edit] {justify-self:end;}}
        .viena-task-templates .viena-task-template-editor {display:flex;flex-direction:column;width:min(1040px,calc(100vw - 32px));max-height:calc(100vh - 32px);padding:0;border:0;border-radius:6px;background:var(--task-bg,#fff);color:var(--task-fg,#101b52);font:14px/1.4 Arial;overflow:hidden;}
        .viena-task-template-editor-portal {position:fixed;inset:0;z-index:2147482999;pointer-events:none;margin:0!important;}
        .viena-task-template-editor-portal [data-task-editor],.viena-task-template-editor-portal [data-task-editor-shade] {pointer-events:auto;}
        .viena-task-template-editor-portal:has([data-task-editor][hidden]) {display:none!important;}
        .viena-task-template-editor-header {display:flex;align-items:center;justify-content:space-between;gap:12px;background:#0085ff;color:white;padding:12px 20px;flex-shrink:0;}
        .viena-task-template-editor-header h3 {font:700 20px Arial!important;color:white!important;margin:0!important;}
        .viena-task-templates .viena-task-template-editor-header button {border:0;background:transparent!important;color:white;font-size:24px;padding:0;min-width:32px;}
        .viena-task-template-editor-content {padding:18px 20px;overflow:auto;min-height:0;}
        .viena-task-template-editor-settings,.viena-task-template-editor-workspace {display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px;}
        .viena-task-template-editor-workspace {align-items:start;margin-top:18px;}
        .viena-task-template-editor-content h4 {font:700 16px Arial;margin:0 0 10px;}
        .viena-task-template-editor label {color:var(--task-label,#506d94);margin:0 0 12px;}
        .viena-task-template-editor input:not([type=checkbox]):not([type=radio]),.viena-task-template-editor select,.viena-task-template-editor textarea {font:14px Arial;min-height:36px;padding:8px 10px;color:var(--task-fg,#101b52);background:var(--task-bg,#fff);border-color:var(--task-border,#dce5f1);margin-top:4px;}
        .viena-task-template-editor [data-task-associations] {min-height:56px;height:56px;}
        .viena-task-template-question {border:1px solid var(--task-border,#dce5f1);border-radius:5px;margin-bottom:8px;background:var(--task-bg,#fff);}
        .viena-task-template-question > summary {padding:12px;cursor:pointer;color:var(--task-fg,#101b52);font-weight:700;}
        .viena-task-template-question > summary small {display:block;font-weight:400;margin-left:16px;color:var(--task-label,#506d94);}
        .viena-task-template-question-content {padding:0 12px 12px;}
        .viena-task-template-editor textarea[data-task-field-options] {min-height:76px;height:76px;}
        .viena-task-template-editor .viena-task-template-defaults {display:flex;gap:8px 14px;flex-wrap:wrap;}
        .viena-task-template-editor .viena-task-template-defaults label {display:flex;align-items:center;gap:8px;}
        .viena-task-template-editor .viena-task-template-defaults input {width:16px;height:16px;accent-color:#0085ff;}
        .viena-task-template-editor [data-task-message-builder] {white-space:pre-wrap;overflow-wrap:anywhere;border:1px solid #afbfdb;border-radius:5px;padding:12px;min-height:150px;background:var(--task-bg,#fff);color:var(--task-fg,#101b52);line-height:1.9;outline-color:#0085ff;}
        .viena-task-template-message-chip {display:inline-block;border:1px solid #afbfdb;border-radius:4px;padding:0 6px;background:var(--task-muted,#e7edf5);color:var(--task-fg,#101b52);font-size:13px;line-height:1.7;vertical-align:baseline;user-select:all;}
        .viena-task-template-editor-preview {white-space:pre-wrap;overflow-wrap:anywhere;padding:12px;background:var(--task-muted,#e7edf5);border-radius:5px;font:14px/1.6 Arial;margin:10px 0 0;}
        .viena-task-template-editor-tools {display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:10px 0;}
        .viena-task-template-editor-tools select {flex:1 1 150px;width:auto;margin:0;}
        .viena-task-template-editor-footer {display:flex;justify-content:flex-end;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 20px;border-top:1px solid var(--task-border,#dce5f1);background:var(--task-bg,#fff);flex-shrink:0;}
        .viena-task-template-editor-footer [data-task-delete] {margin-right:auto;}
        .viena-task-templates .viena-task-template-editor-footer [data-task-save] {background:#0085ff!important;border-color:#0085ff!important;color:white;}
        .viena-task-template-editor [data-task-editor-status]:empty {display:none;}
        .viena-task-template-editor [data-task-editor-status] {color:#b42318;margin:10px 0 0;}
        .viena-task-template-editor [data-task-editor-status][data-kind=info] {color:var(--task-label,#506d94);}
        @media(max-width:700px) {.viena-task-template-editor-settings,.viena-task-template-editor-workspace {grid-template-columns:minmax(0,1fr);gap:12px;}.viena-task-template-editor-content {padding:14px;}.viena-task-template-editor-header,.viena-task-template-editor-footer {padding:10px 14px;}.viena-task-templates .viena-task-template-editor {width:calc(100vw - 16px);}.viena-task-template-editor-footer {gap:6px;}}
        `;
        document.head.append(style);
    }
    function tell(s, text, isError = false) { if (session === s && s.host?.isConnected) { s.status.textContent = text; s.status.dataset.kind = isError ? 'error' : 'info'; if(s.editorStatus) { s.editorStatus.textContent = isError ? text : ''; s.editorStatus.dataset.kind = s.status.dataset.kind; } } }
    function libraryMessage(s) { return s.library.templates.length ? '' : 'Todavía no tenés templates guardados. Usá Nuevo para configurar uno.'; }
    function checkUser(s) {
        if (!s.user || user() !== s.user) throw Error('No pudimos confirmar tu usuario VIENA. Reabrí Crear tarea con tu sesión actual.');
    }
    function editorFields(s) {
        return [...s.fields.children].map(row => {
            const f = {...row.originalField,
                label:row.querySelector('[data-task-field-label]').value.trim(),type:row.querySelector('[data-task-field-type]').value,
                options:[...new Set(row.querySelector('[data-task-field-options]').value.split('\n').map(clean).filter(Boolean))]
            };
            const defaults = row.querySelector('[data-task-field-default]').value.split('\n').map(v => v.trim()).filter(Boolean);
            if (defaults.length || f.defaults !== undefined) f.defaults = defaults;
            for (const [key,attr] of [['otherOption','other'],['otherPlaceholder','other-help']]) {
                const value = row.querySelector('[data-task-field-' + attr + ']').value.trim();
                if (value || f[key] !== undefined) f[key] = value;
            }
            return f;
        });
    }
    function captureEditor(s) {
        if (!s.editor || s.editor.hidden || !s.editId) return;
        const draft = {
            id: s.editId, name: s.name.value.trim(), body: s.body.value,
            associations: parseAssociations(s.associations.value),
            fields: editorFields(s)
        };
        s.drafts.set(s.editId, draft);
    }
    function addField(s, f = { label: '', type: 'single', options: [], defaults: [], includeLabel:true }, appendMessage = false) {
        const row = el('details'); row.className = 'viena-task-template-question'; row.originalField = structuredClone(f);
        const summary = el('summary'), title = el('span'), hint = el('small'); summary.append(title,hint); row.append(summary);
        const content = el('div'); content.className = 'viena-task-template-question-content'; row.append(content);
        const label = input('Nombre de la opción', 'input', 'field-label', content); label.value = f.label; label.placeholder = 'Ej.: Tipo de ingress';
        const type = input('Cómo se responde', 'select', 'field-type', content);
        for (const [value, text] of [['single','Elegir una opción'],['multi','Marcar varias opciones'],['text','Escribir una respuesta']]) { const o = el('option', text); o.value = value; type.append(o); }
        type.value = f.type;
        const options = input('Opciones (una en cada línea)', 'textarea', 'field-options', content); options.value = f.options.join('\n'); options.rows = 3;
        const defaults = el('textarea',undefined,'field-default'); defaults.hidden = true; defaults.value = (f.defaults || []).join('\n'); content.append(defaults);
        const defaultLabel = el('label','Valor inicial (opcional)'), defaultChoices = el('div'); defaultChoices.className = 'viena-task-template-defaults'; defaultLabel.append(defaultChoices); content.append(defaultLabel);
        const other = el('input',undefined,'field-other'); other.hidden = true; other.value = f.otherOption || ''; content.append(other);
        const otherChoice = input('Opción con texto adicional','select','other-choice',content);
        const otherHelp = input('Ayuda para escribir el detalle','input','field-other-help',content); otherHelp.value = f.otherPlaceholder || ''; otherHelp.placeholder = 'Ej.: Escribí la franja horaria';
        const overview = () => { title.textContent = label.value.trim() || 'Nueva opción'; hint.textContent = (type.selectedOptions[0]?.textContent || '') + (defaults.value ? ' · Inicial: ' + defaults.value.split('\n').join(', ') : ' · Sin valor inicial'); };
        const choices = () => {
            const values = [...new Set(options.value.split('\n').map(clean).filter(Boolean))], selected = defaults.value.split('\n').filter(Boolean);
            options.parentElement.hidden = type.value === 'text'; otherChoice.parentElement.hidden = type.value !== 'single' || !(other.value || values.some(v => /^otro$/i.test(v)));
            defaultChoices.replaceChildren();
            if (type.value === 'multi') {
                for (const value of [...new Set([...values,...selected])]) { const option = el('label'), control = el('input'); control.type = 'checkbox'; control.value = value; control.checked = selected.includes(value); control.addEventListener('change',() => { defaults.value = [...defaultChoices.querySelectorAll('input:checked')].map(c => c.value).join('\n'); overview(); editorPreview(s); }); option.append(control,document.createTextNode(value + (values.includes(value) ? '' : ' (revisar opción)'))); defaultChoices.append(option); }
            } else {
                const control = el(type.value === 'text' ? 'input' : 'select',undefined,'default-choice');
                if (type.value !== 'text') { const blank = el('option','Sin valor inicial'); blank.value = ''; control.append(blank); for(const value of [...new Set([...values,...selected])]) { const option = el('option',value + (values.includes(value) ? '' : ' (revisar opción)')); option.value = value; control.append(option); } }
                control.value = selected[0] || ''; control.placeholder = 'Dejar vacío para que responda el operador';
                control.addEventListener(type.value === 'text' ? 'input' : 'change',() => { defaults.value = control.value; overview(); editorPreview(s); }); defaultChoices.append(control);
            }
            otherChoice.replaceChildren(); const none = el('option','Nunca'); none.value = ''; otherChoice.append(none);
            for(const value of [...new Set([...values,...(other.value ? [other.value] : [])])]) { const option = el('option',value + (values.includes(value) ? '' : ' (revisar opción)')); option.value = value; otherChoice.append(option); }
            otherChoice.value = other.value; otherHelp.parentElement.hidden = !otherChoice.value || type.value !== 'single'; overview();
        };
        options.addEventListener('input',choices);
        type.addEventListener('change',() => { if(type.value !== 'single') other.value = ''; if(type.value !== 'multi') defaults.value = defaults.value.split('\n')[0] || ''; choices(); });
        otherChoice.addEventListener('change',() => { other.value = otherChoice.value; otherHelp.parentElement.hidden = !other.value; });
        label.addEventListener('input',() => { overview(); renderMessageBuilder(s); });
        content.append(button('Quitar opción', 'remove-field', () => { const index = [...s.fields.children].indexOf(row); s.body.value = removeQuestionBody(s.body.value,index); row.remove(); renderMessageBuilder(s); editorPreview(s); })); s.fields.append(row); choices();
        row.open = appendMessage || s.fields.children.length === 1;
        row.addEventListener('toggle',() => { if(row.open && row.isConnected && s.fields.contains(row)) for(const sibling of s.fields.children) if(sibling !== row) sibling.open = false; });
        if (appendMessage) { s.body.value += (s.body.value && !s.body.value.endsWith('\n') ? '\n' : '') + '{{CAMPO_' + s.fields.children.length + '}}'; renderMessageBuilder(s); editorPreview(s); label.focus(); }
    }
    function renderMessageBuilder(s) {
        const template = {body:s.body.value,fields:editorFields(s)}; s.messageBuilder.replaceChildren(); s.messageRange = null;
        for(const part of messageParts(template)) {
            if (part.text !== undefined) s.messageBuilder.append(document.createTextNode(part.text));
            else { const chip = el('span',part.label); chip.className = 'viena-task-template-message-chip'; chip.contentEditable = 'false'; if(part.node) chip.setAttribute('data-message-node',''); else chip.setAttribute('data-message-field',part.field); s.messageBuilder.append(chip); }
        }
        s.insertAnswer.replaceChildren(); const blank = el('option','Insertar una respuesta…'); blank.value = ''; s.insertAnswer.append(blank);
        template.fields.forEach((f,index) => { const option = el('option',f.label || 'Nueva pregunta'); option.value = index; s.insertAnswer.append(option); });
    }
    function builderText(node) {
        if(node.nodeType === Node.TEXT_NODE) return node.textContent;
        if(node.hasAttribute('data-message-node')) return '{{NODO_CMTS}}';
        if(node.hasAttribute('data-message-field')) return '{{CAMPO_' + (Number(node.getAttribute('data-message-field'))+1) + '}}';
        if(node.hasAttribute('data-message-caret')) return node.textContent.startsWith('\u200B') ? node.textContent.slice(1) : node.textContent;
        if(node.tagName === 'BR') return '\n';
        let text = ''; for(const child of node.childNodes) { if(child.nodeType === Node.ELEMENT_NODE && ['DIV','P'].includes(child.tagName) && text && !text.endsWith('\n')) text += '\n'; text += builderText(child); } return text;
    }
    function insertMessagePart(s, node) {
        const selection = getSelection(); let range = selection?.rangeCount ? selection.getRangeAt(0) : null;
        if(!range || !s.messageBuilder.contains(range.commonAncestorContainer)) range = s.messageRange;
        if(!range || !s.messageBuilder.contains(range.commonAncestorContainer)) { range = document.createRange(); range.selectNodeContents(s.messageBuilder); range.collapse(false); }
        range.deleteContents();
        if(node.nodeType === Node.ELEMENT_NODE && (node.hasAttribute('data-message-field') || node.hasAttribute('data-message-node'))) {
            const prefix = document.createRange(); prefix.selectNodeContents(s.messageBuilder); prefix.setEnd(range.startContainer,range.startOffset);
            const before = el('div'); before.append(prefix.cloneContents());
            if(builderText(before).endsWith(':')) { const space = document.createTextNode(' '); range.insertNode(space); range.setStartAfter(space); range.collapse(true); }
        }
        range.insertNode(node);
        if(node.nodeType === Node.TEXT_NODE && node.textContent.endsWith('\n')) {
            // Chrome needs a rendered caret after a terminal newline. This owned
            // marker never enters the saved template or the operator's message.
            const caret = el('span','\u200B'); caret.setAttribute('data-message-caret',''); node.after(caret); range.setStart(caret.firstChild,1);
        } else range.setStartAfter(node);
        range.collapse(true); s.messageBuilder.focus(); selection.removeAllRanges(); selection.addRange(range); s.messageRange = range.cloneRange();
        s.body.value = builderText(s.messageBuilder); editorPreview(s);
    }
    function editorPreview(s) {
        if(!s.editor || s.editor.hidden || !s.editId) return;
        const draft = {body:s.body.value,fields:editorFields(s)}, answers = {};
        draft.fields.forEach((f,index) => { answers[index] = f.defaults?.length ? f.defaults : ['[' + (f.label || 'Respuesta') + ']']; if(f.otherOption && answers[index].includes(f.otherOption)) answers[index + '_other'] = '[Detalle]'; });
        try { s.editorPreview.textContent = compose(draft,answers,'[Nodo CMTS del ticket]'); }
        catch { s.editorPreview.textContent = 'Revisá las preguntas del mensaje.'; }
    }
    function detectMessageOptions(s) {
        captureEditor(s);
        const draft = optionsFromMessage(s.drafts.get(s.editId));
        s.body.value = draft.body; s.fields.replaceChildren(); draft.fields.forEach(f => addField(s,f)); renderMessageBuilder(s); editorPreview(s);
        captureEditor(s); s.editorStatus.textContent = draft.fields.length ? 'Opciones del mensaje listas para configurar. Guardá el template para conservarlas.' : 'Escribí títulos en el mensaje, por ejemplo: Tipo de ingress:';
        s.editorStatus.dataset.kind = 'info';
    }
    function openEditor(s, id) {
        if (s.busy) return;
        s.editorReturn = document.activeElement;
        captureEditor(s); s.editId = id || crypto.randomUUID();
        let draft = s.drafts.get(s.editId) || s.library.templates.find(t => t.id === s.editId) || { id:s.editId, name:'', body:'', associations:[], fields:[] };
        if(draft.body && !draft.fields.length) draft = optionsFromMessage(draft);
        s.editor.hidden = false; s.name.value = draft.name; s.body.value = draft.body;
        const colors = getComputedStyle(s.dialog || s.root);
        for(const variable of ['--task-bg','--task-fg','--task-label','--task-border','--task-muted']) s.editorPortal.style.setProperty(variable,colors.getPropertyValue(variable));
        s.previousIngress.hidden = !s.library.ingressRestore?.previous || s.editId !== s.library.ingressRestore.restoredId;
        s.associations.value = draft.associations.join('\n'); s.fields.replaceChildren(); draft.fields.forEach(f => addField(s, f));
        renderMessageBuilder(s); editorPreview(s); s.editorStatus.textContent = '';
        s.manage.replaceChildren();
        const ids = [...new Set([...s.library.templates.map(t => t.id),...s.drafts.keys(),s.editId])];
        for (const entryId of ids) {
            const entry = entryId === s.editId ? draft : s.drafts.get(entryId) || s.library.templates.find(t => t.id === entryId);
            const option = el('option',(entry?.name || 'Nuevo template') + (s.drafts.has(entryId) ? ' · borrador' : '')); option.value = entryId; s.manage.append(option);
        }
        s.manage.value = s.editId;
        s.name.focus({ preventScroll:true }); s.editor.scrollIntoView({ block:'nearest' });
    }
    function closeEditor(s) { captureEditor(s); s.editor.hidden = true; s.editorReturn?.focus({ preventScroll:true }); }
    async function persistLibrary(s, next) {
        checkUser(s);
        const storageKey = userKey(s.user);
        if (pendingWrites.has(storageKey)) throw Error('El guardado anterior todavía está pendiente. Conservamos tu borrador; volvé a intentar cuando termine.');
        validate(next);
        const live = validate((await bounded(chrome.storage.local.get(storageKey)))[storageKey]);
        checkUser(s);
        if (!sameLibrary(live, s.library)) {
            s.library = live; if (s.select) refreshSelect(s);
            throw Error('La biblioteca cambió en otra ventana. Conservamos tu borrador; revisá y volvé a guardar.');
        }
        const write = Promise.resolve(chrome.storage.local.set({[storageKey]:next}));
        pendingWrites.set(storageKey,write);
        await bounded(write.finally(() => { if (pendingWrites.get(storageKey) === write) pendingWrites.delete(storageKey); }));
        const readback = validate((await bounded(chrome.storage.local.get(storageKey)))[storageKey]);
        checkUser(s);
        if (!sameLibrary(readback,next)) throw Error('No pudimos verificar el guardado. Conservamos tu borrador.');
        return readback;
    }
    async function save(s, remove = false) {
        if (s.busy || s.loading || s.readError) return;
        captureEditor(s);
        s.busy = true; s.save.disabled = true;
        try {
            checkUser(s);
            if (pendingWrites.has(userKey(s.user))) throw Error('El guardado anterior todavía está pendiente. Conservamos tu borrador; volvé a intentar cuando termine.');
            const draft = s.drafts.get(s.editId);
            if (!remove && !draft) throw Error('No hay cambios para guardar.');
            const next = structuredClone(s.library);
            next.templates = next.templates.filter(t => t.id !== s.editId);
            if (!remove) {
                if (next.templates.some(t => clean(t.name).toLowerCase() === clean(draft.name).toLowerCase())) throw Error('Ya existe un template con ese nombre.');
                next.templates.push(draft);
            }
            next.revision = crypto.randomUUID(); validate(next);
            const readback = await persistLibrary(s,next);
            captureEditor(s);
            const laterEdits = !remove && JSON.stringify(s.drafts.get(s.editId)) !== JSON.stringify(draft);
            s.library = readback; if (!laterEdits) s.drafts.delete(s.editId); s.answers.delete(s.editId); s.selected = remove ? '' : s.editId;
            s.editor.hidden = !laterEdits; if (!laterEdits) s.editorReturn?.focus({ preventScroll:true }); refreshSelect(s); renderAnswers(s); tell(s, laterEdits ? 'Configuración guardada. Conservamos los cambios que escribiste durante el guardado; aún están sin guardar.' : 'Configuración guardada.');
        } catch (error) { tell(s, error.message || 'No se pudo guardar. Volvé a intentar.',true); }
        finally { s.busy = false; s.save.disabled = false; }
    }
    function refreshSelect(s) {
        const typification = selectedText(s.root, 'Tipificación');
        s.templateLabel.textContent = typification ? 'Templates para ' + typification : 'Elegí una tipificación para ver sus templates';
        const compatible = t => compatibleTypification(t.associations,typification);
        const ordered = [...s.library.templates].sort((a,b) => Number(compatible(b)) - Number(compatible(a)));
        const current = s.select.value || s.selected;
        const placeholder = el('option', 'Elegí un template'); placeholder.value = '';
        s.select.replaceChildren(placeholder);
        for (const t of ordered.filter(t => s.showAll || compatible(t) || t.id === current)) {
            const option = el('option', t.name + (compatible(t) ? '' : ' · otra tipificación')); option.value = t.id; s.select.append(option);
        }
        s.select.value = s.selected || current || ''; s.all.textContent = s.showAll ? 'Sólo compatibles' : 'Mostrar todos'; s.all.setAttribute('aria-pressed',String(s.showAll));
    }
    function resolveNode(s) {
        const ticket = ticketNode(), message = nativeMessage(s.root)?.value || '';
        const ticketValues = nodeCandidates(ticket,''), messageValues = nodeCandidates('',message);
        // A legacy template may render the node without its heading. Applying it
        // must not erase the source detected earlier in this same creation session.
        const retained = !ticketValues.length && !messageValues.length && message === s.lastApplied ? s.nodeAutomatic || '' : '';
        const candidates = nodeCandidates(ticket || retained,message);
        const conflict = ticketValues.length && messageValues.some(v => !ticketValues.includes(v));
        const automatic = !conflict && candidates.length ? (ticketValues.length ? ticketValues : messageValues.length ? messageValues : candidates).join(' | ') : '';
        if(automatic) s.nodeAutomatic = automatic;
        const signature = JSON.stringify([candidates,automatic]);
        if (signature !== s.nodeSignature) {
            s.nodeSignature = signature;
            const placeholder = el('option', candidates.length > 1 ? 'Elegí el Nodo CMTS actual' : 'Ingresar otro nodo'); placeholder.value = '';
            s.nodeSelect.replaceChildren(placeholder);
            for (const value of candidates) { const option = el('option', value); option.value = value; s.nodeSelect.append(option); }
            if (!s.nodeSelected) s.nodeChoice = automatic;
            if (candidates.length === 1 && automatic) s.nodeSelect.value = automatic;
        }
        s.nodeInfo.hidden = false;
        s.nodeInfo.textContent = conflict ? 'Ticket y mensaje muestran nodos distintos. Elegí el que corresponde o corregí NODO CMTS.' : automatic
            ? (ticketValues.length ? 'Nodo tomado del ticket.' : retained ? 'Nodo conservado del mensaje original.' : 'Nodo tomado del mensaje.') + ' Usá Corregir para cambiarlo.'
            : 'No se detectó Nodo CMTS. Ingresalo en NODO CMTS para aplicar.';
        s.nodeDetected.value = candidates.join(' | '); s.nodeDetected.parentElement.hidden = !candidates.length;
        s.nodeSelect.parentElement.hidden = !conflict;
        s.nodeInput.parentElement.hidden = Boolean(automatic && !s.editNode);
        s.nodeEdit.hidden = !automatic;
        s.nodeEdit.textContent = s.editNode ? 'Usar detectado' : 'Corregir';
        s.nodeDetected.title = ticketValues.length ? 'Detectado desde el ticket' : retained ? 'Detectado al abrir este mensaje' : 'Detectado desde el mensaje';
        return clean(s.nodeInput.value).toUpperCase() || s.nodeChoice;
    }
    function preview(s) {
        const node = resolveNode(s);
        const t = s.library.templates.find(t => t.id === s.selected);
        if (!t) { s.generated = ''; s.apply.disabled = true; return ''; }
        try { const result = compose(t, s.answers.get(t.id) || {}, node); s.generated = result; s.apply.disabled = !result; if(s.previewError) tell(s,''); s.previewError = false; return result; }
        catch (error) { s.generated = ''; s.apply.disabled = true; s.previewError = true; tell(s, error.message,true); return ''; }
    }
    function renderAnswers(s) {
        const t = s.library.templates.find(t => t.id === s.selected); s.answersHost.replaceChildren();
        s.edit.disabled = !t;
        if (!t) { preview(s); return; }
        const answers = s.answers.get(t.id) || {}; s.answers.set(t.id, answers);
        t.fields.forEach((f, index) => {
            const section = el('div'); section.className = 'viena-task-template-answer-row'; section.append(el('strong', f.label));
            if (f.type === 'text') {
                const control = input('', 'textarea', 'answer', section); control.rows = 3; control.setAttribute('aria-label',f.label); control.value = (answers[index] ?? f.defaults ?? []).join(', ');
                control.addEventListener('input', () => { answers[index] = [control.value]; s.replace.hidden = true; preview(s); });
            } else {
                const choices = el('div'); choices.className = 'viena-task-template-choices';
                let otherControl;
                f.options.forEach(value => {
                    const label = el('label'); label.className = 'viena-task-template-choice';
                    const control = el('input', undefined, 'answer'); control.type = f.type === 'single' ? 'radio' : 'checkbox';
                    control.name = 'viena-task-' + t.id + '-' + index; control.checked = (answers[index] ?? f.defaults ?? []).includes(value);
                    control.addEventListener('change', () => {
                        answers[index] = f.type === 'single' ? [value] : [...choices.querySelectorAll('input:checked')].map(c => c.value);
                        if (otherControl) { otherControl.hidden = value !== f.otherOption; if (!otherControl.hidden) otherControl.focus(); }
                        s.replace.hidden = true; preview(s);
                    });
                    control.value = value; label.append(control, document.createTextNode(value)); choices.append(label);
                }); section.append(choices);
                if (f.otherOption) {
                    otherControl = el('input',undefined,'other-answer'); otherControl.placeholder = f.otherPlaceholder || 'Escribí el detalle'; otherControl.setAttribute('aria-label',otherControl.placeholder);
                    otherControl.value = answers[index + '_other'] || ''; otherControl.hidden = !(answers[index] ?? f.defaults ?? []).includes(f.otherOption);
                    otherControl.addEventListener('input',() => { answers[index + '_other'] = otherControl.value; s.replace.hidden = true; preview(s); }); choices.append(otherControl);
                }
            }
            s.answersHost.append(section);
        }); preview(s);
    }
    function writeMessage(s, text) {
        const message = nativeMessage(s.root);
        if (!message || !visible(message)) throw Error('El formulario cambió. Revisá el mensaje antes de aplicar.');
        s.writing = true;
        try {
            Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(message, text);
            message.dispatchEvent(new Event('input', { bubbles:true })); message.dispatchEvent(new Event('change', { bubbles:true }));
            s.text = text; s.lastApplied = text; s.dirty = true; s.replace.hidden = true; tell(s, 'Template aplicado. El mensaje sigue editable.');
        } finally { s.writing = false; }
    }
    function apply(s, confirmed = false) {
        if (session !== s || s.readError || s.loading) return;
        try {
            checkUser(s);
            const result = preview(s); if (!result) return;
            const message = nativeMessage(s.root);
            if (confirmed && (s.replaceText !== message.value || s.replacePreview !== result)) { s.replace.hidden = true; throw Error('El mensaje o las opciones cambiaron. Revisá y volvé a aplicar.'); }
            if (s.dirty && message.value !== s.lastApplied && message.value !== result && !confirmed) {
                s.replaceText = message.value; s.replacePreview = result; s.replace.hidden = false; return;
            }
            writeMessage(s, result);
            tell(s,'Mensaje generado. Revisalo y editá lo que necesites antes de Crear.');
        } catch (error) { tell(s, error.message,true); }
    }
    function mode(s, custom) {
        if(s.custom !== custom) {
            const message = nativeMessage(s.root);
            if(message) {
                s.modeMessages ||= new Map();
                s.modeMessages.set(s.custom,{text:message.value,dirty:s.dirty,lastApplied:s.lastApplied});
                const saved = s.modeMessages.get(custom);
                if(saved) {
                    writeMessage(s,saved.text);
                    s.dirty = saved.dirty; s.lastApplied = saved.lastApplied;
                    tell(s,custom ? 'Recuperamos tu mensaje personalizado.' : 'Recuperamos tu mensaje predeterminado.');
                }
            }
        }
        s.custom = custom; s.customHost.hidden = !custom; s.defaultMode.setAttribute('aria-pressed', String(!custom)); s.customMode.setAttribute('aria-pressed', String(custom));
        if (s.messageRow) s.messageRow.classList.toggle('viena-task-template-native-grid', custom);
        if (s.side) s.side.hidden = !custom;
        if (s.messageTools) s.messageTools.hidden = !custom;
        if (s.messageHeading) s.messageHeading.hidden = !custom;
        s.messageCol?.classList.toggle('viena-task-template-message-panel', custom);
        if (!custom && s.editor && !s.editor.hidden) closeEditor(s);
        s.replace.hidden = true;
        if (custom) { refreshSelect(s); preview(s); }
    }
    function mount(s, message) {
        const nativeGroup = field(s.root, 'Mensaje'), row = nativeGroup?.closest('.row'), col = nativeGroup?.closest('.col');
        const messageRow = row && col && col.parentElement === row && Array.from(row.children).filter(child => child !== s.side).length === 1 ? row : null;
        if (s.host) {
            if (s.messageRow !== messageRow || !s.host.isConnected || !s.side.isConnected) {
                s.messageRow?.classList.remove('viena-task-template-native-grid'); s.messageRow = messageRow;
                if (messageRow) { messageRow.before(s.host); messageRow.prepend(s.side); messageRow.classList.toggle('viena-task-template-native-grid', s.custom); }
                else { nativeGroup.before(s.host); s.customHost.append(s.side); }
            }
            if (s.messageCol !== col) s.messageCol?.classList.remove('viena-task-template-message-panel');
            s.messageCol = col; col?.classList.toggle('viena-task-template-message-panel', s.custom);
            if (s.messageHeading.parentElement !== nativeGroup.parentElement) nativeGroup.before(s.messageHeading);
            if (s.messageTools.parentElement !== nativeGroup.parentElement) nativeGroup.after(s.messageTools);
            return;
        }
        styles(); s.message = message; s.text = message.value; s.dirty = false;
        s.host = el('section',undefined,'root'); s.host.className = 'viena-task-templates'; s.host.setAttribute('data-viena-macro-ui', '1');
        s.messageRow = messageRow;
        if (s.messageRow) s.messageRow.before(s.host); else nativeGroup.before(s.host);
        s.dialog = s.root.querySelector('.v-dialog'); s.dialog?.classList.add('viena-task-template-dialog');
        const nativeHeader = s.dialog?.querySelector('header.v-toolbar .v-toolbar__content');
        if(nativeHeader) {
            s.sizeHost = el('span'); s.sizeHost.className = 'viena-task-templates viena-task-template-size-host'; s.sizeHost.setAttribute('data-viena-macro-ui','1');
            s.sizeButton = button('Ampliar','expand-modal',() => { s.expanded = !s.expanded; s.dialog.classList.toggle('viena-task-template-expanded',s.expanded); s.sizeButton.textContent = s.expanded ? 'Tamaño normal' : 'Ampliar'; }); s.sizeButton.className = 'viena-task-template-size'; s.sizeHost.append(s.sizeButton); nativeHeader.insertBefore(s.sizeHost,nativeHeader.querySelector('button'));
        }
        const modes = el('div'); modes.className = 'viena-task-template-bar viena-task-template-modes';
        s.defaultMode = button('Predeterminado', undefined, () => mode(s, false)); s.defaultMode.setAttribute('data-task-mode','default');
        s.customMode = button('Templates personalizados', undefined, () => mode(s, true)); s.customMode.setAttribute('data-task-mode','custom'); modes.append(s.defaultMode, s.customMode); s.host.append(el('label','Modo de mensaje'), modes);
        mountNote(s,modes);
        s.status = el('p'); s.status.className = 'viena-task-template-status'; s.status.setAttribute('role','status'); s.host.append(s.status);
        s.retryRead = button('Reintentar lectura','retry-read',() => void readLibrary(s)); s.retryRead.hidden = !s.readError; s.host.append(s.retryRead);
        s.customHost = el('div'); s.customHost.className = 'viena-task-template-custom'; s.host.append(s.customHost);
        s.templateLabel = el('label','Templates para la tipificación elegida'); s.customHost.append(s.templateLabel);
        const bar = el('div'); bar.className = 'viena-task-template-bar'; s.select = el('select',undefined,'select'); s.select.setAttribute('aria-label','Templates por tipificación');
        s.select.addEventListener('change', () => { s.selected = s.select.value; s.replace.hidden = true; renderAnswers(s); });
        s.all = button('Ver todos', 'all', () => { s.showAll = !s.showAll; refreshSelect(s); });
        s.edit = button('Editar template', 'edit', () => openEditor(s, s.selected));
        bar.append(s.select, s.all, button('Nuevo template','new',() => openEditor(s)), s.edit); s.customHost.append(bar);
        s.side = el('section'); s.side.className = 'viena-task-templates viena-task-template-panel'; s.side.setAttribute('data-viena-macro-ui','1');
        s.side.append(el('h3','Opciones del template')); s.nodeInfo = el('p'); s.side.append(s.nodeInfo);
        const nodeRow = el('div'); nodeRow.className = 'viena-task-template-node-row'; s.side.append(nodeRow);
        s.nodeDetected = input('Nodo CMTS','input','node-detected',nodeRow); s.nodeDetected.readOnly = true;
        s.nodeSelect = input('Elegí el nodo que corresponde','select','node',s.side); s.nodeInput = input('NODO CMTS:','input','node-manual',s.side); s.nodeInput.placeholder = 'Ingresá el Nodo CMTS correcto';
        s.nodeEdit = button('Corregir','node-edit',() => { s.editNode = !s.editNode; if(!s.editNode) { s.nodeInput.value = ''; s.nodeSelected = false; s.nodeSignature = ''; } preview(s); if (s.editNode) s.nodeInput.focus(); }); s.nodeEdit.title = 'Corregir Nodo CMTS'; nodeRow.append(s.nodeEdit);
        s.nodeSelect.addEventListener('change', () => { s.nodeChoice = s.nodeSelect.value; s.nodeSelected = Boolean(s.nodeChoice); s.nodeInput.value = ''; s.replace.hidden = true; preview(s); });
        s.nodeInput.addEventListener('input', () => { s.replace.hidden = true; preview(s); });
        s.answersHost = el('div'); s.side.append(s.answersHost);
        if (s.messageRow) s.messageRow.prepend(s.side); else s.customHost.append(s.side);
        s.side.append(button('Editar campos y opciones','edit-fields',() => openEditor(s,s.selected)));
        s.messageTools = el('section',undefined,'message-tools'); s.messageTools.className = 'viena-task-templates'; s.messageTools.setAttribute('data-viena-macro-ui','1');
        s.messageHeading = el('h3','Mensaje editable'); s.messageHeading.className = 'viena-task-template-message-heading'; s.messageHeading.setAttribute('data-viena-macro-ui','1'); nativeGroup.before(s.messageHeading);
        s.messageCol = col;
        s.apply = button('Aplicar template','apply',() => apply(s)); s.messageTools.append(s.apply);
        const help = el('p','Aplicar reemplaza este mensaje. Cada modo conserva su propio texto.'); help.className = 'viena-task-template-help'; s.messageTools.append(help);
        s.replace = el('div',undefined,'replace'); s.replace.hidden = true; s.replace.append(el('p','El mensaje fue editado. ¿Querés reemplazarlo por el texto generado?'),button('Conservar mensaje','keep',() => { s.replace.hidden = true; }),button('Reemplazar mensaje','replace-confirm',() => apply(s,true))); s.messageTools.append(s.replace); nativeGroup.after(s.messageTools);
        s.editorPortal = el('div'); s.editorPortal.className = 'viena-task-templates viena-task-template-editor-portal'; s.editorPortal.setAttribute('data-viena-macro-ui','1'); document.body.append(s.editorPortal);
        s.editor = el('section',undefined,'editor'); s.editor.className = 'viena-task-template-panel viena-task-template-editor'; s.editor.setAttribute('role','dialog'); s.editor.setAttribute('aria-modal','true'); s.editor.setAttribute('aria-label','Configurar template'); s.editor.hidden = true; s.editorPortal.append(s.editor);
        const shade = el('div',undefined,'editor-shade'); shade.addEventListener('click',() => closeEditor(s)); s.editorPortal.append(shade);
        const editorHeader = el('header'); editorHeader.className = 'viena-task-template-editor-header'; const editorX = button('×','editor-x',() => closeEditor(s)); editorX.setAttribute('aria-label','Cerrar editor'); editorHeader.append(el('h3','Configurar template'),editorX); s.editor.append(editorHeader);
        const editorContent = el('div'); editorContent.className = 'viena-task-template-editor-content'; s.editor.append(editorContent);
        s.manage = input('Template que estás configurando','select','manage-select',editorContent); s.manage.addEventListener('change',() => openEditor(s,s.manage.value));
        const settings = el('div'); settings.className = 'viena-task-template-editor-settings'; editorContent.append(settings);
        s.name = input('Nombre del template','input','name',settings); s.name.placeholder = 'Ej.: INGRESS LDI';
        const compatibility = el('div'); settings.append(compatibility);
        s.associations = input('Se usa en estas tipificaciones','textarea','associations',compatibility); s.associations.rows = 2; s.associations.placeholder = 'Ej.: LDI, FMR, LII';
        const associationHelp = el('p','Siglas: LDI, FMR, LII. Nombres completos: uno por línea. Vacío: todas.'); associationHelp.className = 'viena-task-template-help'; compatibility.append(associationHelp);
        const workspace = el('div'); workspace.className = 'viena-task-template-editor-workspace'; editorContent.append(workspace);
        const questions = el('section'); questions.append(el('h4','Opciones del template')); s.fields = el('div'); questions.append(s.fields,button('Agregar opción','add-field',() => addField(s,undefined,true))); workspace.append(questions);
        const messageEditor = el('section'); messageEditor.append(el('h4','Mensaje del template')); workspace.append(messageEditor);
        s.body = el('textarea',undefined,'body'); s.body.hidden = true; messageEditor.append(s.body);
        s.messageBuilder = el('div',undefined,'message-builder'); s.messageBuilder.contentEditable = 'true'; s.messageBuilder.setAttribute('role','textbox'); s.messageBuilder.setAttribute('aria-multiline','true'); s.messageBuilder.setAttribute('aria-label','Mensaje del template'); messageEditor.append(s.messageBuilder);
        s.messageBuilder.addEventListener('input',() => { s.body.value = builderText(s.messageBuilder); });
        const rememberSelection = () => { const selection = getSelection(); if(selection?.rangeCount && s.messageBuilder.contains(selection.getRangeAt(0).commonAncestorContainer)) s.messageRange = selection.getRangeAt(0).cloneRange(); };
        s.messageBuilder.addEventListener('keyup',rememberSelection); s.messageBuilder.addEventListener('pointerup',rememberSelection);
        s.messageBuilder.addEventListener('keydown',event => { if(event.key === 'Enter') { event.preventDefault(); insertMessagePart(s,document.createTextNode('\n')); } });
        s.messageBuilder.addEventListener('paste',event => { event.preventDefault(); insertMessagePart(s,document.createTextNode(event.clipboardData.getData('text/plain'))); });
        const editorTools = el('div'); editorTools.className = 'viena-task-template-editor-tools'; messageEditor.append(editorTools);
        const chip = (label,attribute,value) => { const node = el('span',label); node.className = 'viena-task-template-message-chip'; node.contentEditable = 'false'; node.setAttribute(attribute,value); return node; };
        editorTools.append(button('Tomar opciones del mensaje','detect-options',() => detectMessageOptions(s)),button('Agregar Nodo CMTS','insert-node',() => {
            const selection = getSelection(), current = selection?.rangeCount ? selection.getRangeAt(0) : null;
            const range = current && s.messageBuilder.contains(current.commonAncestorContainer) ? current : s.messageRange;
            const prefix = document.createRange(); prefix.selectNodeContents(s.messageBuilder);
            if(range && s.messageBuilder.contains(range.startContainer)) prefix.setEnd(range.startContainer,range.startOffset);
            const before = el('div'); before.append(prefix.cloneContents());
            const line = builderText(before).split('\n').pop();
            if(!/\bNODO[ \t]+CMTS[ \t]*:[ \t]*$/i.test(line)) insertMessagePart(s,document.createTextNode((line ? '\n' : '') + 'NODO CMTS: '));
            insertMessagePart(s,chip('Nodo CMTS','data-message-node',''));
        }));
        s.insertAnswer = el('select',undefined,'insert-answer'); s.insertAnswer.setAttribute('aria-label','Insertar respuesta en el mensaje'); editorTools.append(s.insertAnswer);
        s.insertAnswer.addEventListener('change',() => { if(s.insertAnswer.value !== '') { const index = Number(s.insertAnswer.value), f = editorFields(s)[index]; insertMessagePart(s,chip(f.label || 'Nueva pregunta','data-message-field',index)); s.insertAnswer.value = ''; } });
        const messageHelp = el('p','Escribí o pegá tu mensaje y usá Tomar opciones del mensaje. Cada título seguido de dos puntos se convierte en una opción configurable.'); messageHelp.className = 'viena-task-template-help'; messageEditor.append(messageHelp,el('h4','Así va a quedar el mensaje'));
        s.editorPreview = el('pre',undefined,'editor-preview'); s.editorPreview.className = 'viena-task-template-editor-preview'; messageEditor.append(s.editorPreview);
        s.editorStatus = el('p',undefined,'editor-status'); s.editorStatus.setAttribute('role','status'); editorContent.append(s.editorStatus);
        s.editor.addEventListener('input',() => editorPreview(s)); s.editor.addEventListener('change',() => editorPreview(s));
        s.save = button('Guardar template','save',() => void save(s));
        s.previousIngress = button('Ver versión anterior','previous-ingress',() => {
            const previous = s.library.ingressRestore?.previous; if(!previous) return;
            s.recoveryId ||= crypto.randomUUID();
            if(!s.drafts.has(s.recoveryId)) s.drafts.set(s.recoveryId,{...structuredClone(previous),id:s.recoveryId,name:previous.name + ' — anterior'});
            openEditor(s,s.recoveryId);
        }); s.previousIngress.hidden = true;
        const remove = button('Eliminar template','delete',() => { deleteConfirm.hidden = false; });
        const deleteConfirm = el('div'); deleteConfirm.hidden = true; deleteConfirm.append(el('p','¿Eliminar este template guardado?'),button('Cancelar',undefined,() => { deleteConfirm.hidden = true; }),button('Confirmar eliminación',undefined,() => void save(s,true)));
        editorContent.append(deleteConfirm);
        const editorFooter = el('footer'); editorFooter.className = 'viena-task-template-editor-footer'; editorFooter.append(remove,s.previousIngress,button('Cerrar editor','editor-close',() => closeEditor(s)),s.save); s.editor.append(editorFooter);
        s.editor.addEventListener('keydown', event => {
            if (event.key !== 'Tab') return;
            const controls = [...s.editor.querySelectorAll('button,input,select,textarea')].filter(node => !node.disabled && visible(node));
            const first = controls[0], last = controls.at(-1);
            if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
            else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
        });
        for (const container of [s.host,s.side,s.messageTools,s.editorPortal,s.sizeHost].filter(Boolean)) {
            for (const name of ['pointerdown','mousedown','click','input','change','focusin']) container.addEventListener(name,event => event.stopPropagation());
            container.addEventListener('keydown', event => {
                if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); if (!s.replace.hidden) s.replace.hidden = true; else if (!s.editor.hidden) closeEditor(s); else mode(s,false); }
            });
        }
        mode(s,false); refreshSelect(s); renderAnswers(s); s.save.disabled = Boolean(s.readError || s.loading);
        if (!s.user) tell(s,'Detectá tu usuario VIENA para administrar templates. El mensaje predeterminado sigue disponible.',true);
    }
    let noteFolder = null, noteFolderReady = null;
    function noteFolderStore(mode, handle) {
        return new Promise((resolve,reject) => {
            let db, tx, done = false;
            const finish = (error,value) => { if(done) return; done = true; clearTimeout(timer); db?.close(); error ? reject(error) : resolve(value); };
            const timer = setTimeout(() => { try { tx?.abort(); } catch {} finish(Error('folder-storage')); },3000);
            let request;
            try { request = indexedDB.open('viena-task-note-folder',1); } catch(error) { finish(error); return; }
            request.onupgradeneeded = () => { if(done) request.transaction.abort(); else request.result.createObjectStore('directory'); };
            request.onerror = () => finish(request.error);
            request.onblocked = () => finish(Error('folder-storage'));
            request.onsuccess = () => {
                db = request.result; if(done) { db.close(); return; }
                try {
                    tx = db.transaction('directory',mode);
                    const op = mode === 'readonly' ? tx.objectStore('directory').get('folder') : tx.objectStore('directory').put(handle,'folder');
                    let value; op.onsuccess = () => { value = op.result; };
                    tx.oncomplete = () => finish(null,value);
                    tx.onerror = tx.onabort = () => finish(tx.error || Error('folder-storage'));
                } catch(error) { finish(error); }
            };
        });
    }
    function loadNoteFolder() {
        return noteFolderReady ||= noteFolderStore('readonly').then(handle => { noteFolder = handle || null; }).catch(() => { noteFolderReady = null; });
    }
    async function noteDirectory(change, current) {
        await loadNoteFolder();
        if(!current()) throw new DOMException('Cancelado','AbortError');
        if(change || !noteFolder) {
            const options = {id:'viena-task-notes',mode:'read',startIn:noteFolder || 'downloads'};
            const handle = await (globalThis.VienaPermissionUI ? globalThis.VienaPermissionUI.folder(options) : window.showDirectoryPicker(options));
            if(!current()) throw new DOMException('Cancelado','AbortError');
            // Commit only after durable storage succeeds; cancellation preserves the prior folder.
            await noteFolderStore('readwrite',handle);
            noteFolder = handle;
        } else if(await noteFolder.queryPermission({mode:'read'}) !== 'granted') {
            // The operator already clicked Search for this saved folder. Chrome
            // owns the permission decision; no second VIENA confirmation.
            if(!current()) throw new DOMException('Cancelado','AbortError');
            const permission = await noteFolder.requestPermission({mode:'read'});
            if(permission !== 'granted') throw new DOMException('Acceso no habilitado','NotAllowedError');
        }
        return noteFolder;
    }
    function scheduleNoteDismiss(n) {
        if (!n?.detached || n.state !== 'saved' || n.dismissTimer) return;
        n.dismissTimer = setTimeout(() => {
            n.dismissTimer = null;
            // A synthetic outside click would close the operator's native selector.
            if (n.detached && n.state === 'saved') n.dismiss();
        },1500);
    }
    function noteRequest(s, action, now = false) {
        const n = s.note;
        if (!n) return false;
        if (action === 'arm') n.ack = false;
        document.dispatchEvent(new CustomEvent('VIENA_TASK_NOTE_REQUEST',{detail:{action,id:n.id,source:n.source,filesId:n.files.id,title:n.title.value,message:n.message.value,now}}));
        return n.ack;
    }
    function mountNote(s, modes) {
        if (location.pathname !== '/tasks/intern') return;
        const source = s.identity.replace(/^Creando tarea\s*:\s*/i,'').trim();
        const n = s.note = {id:crypto.randomUUID(),source,state:'draft'};
        void loadNoteFolder(); // Restore the handle only; no permission prompt or directory scan.
        const row = el('div'); row.className = 'viena-task-note-toolbar'; modes.before(row); row.append(modes);
        n.panel = el('section'); n.panel.className = 'viena-task-templates viena-task-note-panel'; n.panel.hidden = true;
        n.toggle = button('Nota y adjuntos','note-toggle',() => { n.panel.hidden = !n.panel.hidden; n.toggle.setAttribute('aria-expanded',String(!n.panel.hidden)); });
        const clip = document.createElementNS('http://www.w3.org/2000/svg','svg'); clip.setAttribute('viewBox','0 0 24 24'); clip.setAttribute('width','18'); clip.setAttribute('height','18'); clip.setAttribute('aria-hidden','true');
        const clipPath = document.createElementNS('http://www.w3.org/2000/svg','path'); clipPath.setAttribute('d','M21 11.5l-8.5 8.5a6 6 0 0 1-8.5-8.5l9-9a4 4 0 0 1 5.7 5.7l-9 9a2 2 0 0 1-2.8-2.8l8.5-8.5'); clipPath.setAttribute('fill','none'); clipPath.setAttribute('stroke','currentColor'); clipPath.setAttribute('stroke-width','2'); clipPath.setAttribute('stroke-linecap','round'); clipPath.setAttribute('stroke-linejoin','round'); clip.append(clipPath); n.toggle.prepend(clip);
        n.toggle.setAttribute('aria-expanded','false'); row.append(n.toggle); row.after(n.panel);
        n.panel.append(el('strong','Nota para la tarea interna ' + source));
        n.panel.append(el('p','Se guarda en este ticket de origen, sin abrir Notas. Al terminar queda en Eventos relacionados.'));
        n.title = input('Título','input','note-title',n.panel); n.title.value = 'Archivos';
        n.message = input('Mensaje de la nota','textarea','note-message',n.panel); n.message.value = 'Archivos imágenes afectación'; n.message.rows = 2;
        const filesLabel = el('label','Elegir archivos (hasta 20 MB cada uno)');
        n.files = el('input',undefined,'note-files'); n.files.type = 'file'; n.files.multiple = true; n.files.id = 'viena-note-files-' + n.id; filesLabel.append(n.files); n.panel.append(filesLabel);
        const list = el('p'); list.style.overflowWrap = 'anywhere'; n.panel.append(list);
        const selected = () => { list.textContent = [...n.files.files].map(file => file.name).join(' · ') || 'Sin archivos seleccionados.'; n.toggle.textContent = n.files.files.length ? 'Nota y adjuntos (' + n.files.files.length + ')' : 'Nota y adjuntos'; n.toggle.prepend(clip); };
        n.files.addEventListener('change',() => { n.selectionRevision = (n.selectionRevision || 0) + 1; selected(); }); selected();
        const normalizeFileNode = value => String(value || '').normalize('NFKC').replace(/[\u200B-\u200D\u2060\uFEFF]/g,'').trim().toUpperCase();
        const searchFolder = async (change = false) => {
            if (n.folderBusy || ['sending','saved','uncertain'].includes(n.state)) return;
            const node = normalizeFileNode(ticketNode());
            if (!node || /[,;\s]/.test(node)) { n.status.textContent = 'No hay un único nodo confirmado. Elegí los archivos manualmente.'; return; }
            if (typeof window.showDirectoryPicker !== 'function') { n.status.textContent = 'Este navegador no permite leer carpetas desde aquí. Usá Elegir archivos.'; return; }
            const revision = n.selectionRevision || 0;
            const current = () => session === s && visible(s.root) && revision === (n.selectionRevision || 0) && !['sending','saved','uncertain'].includes(n.state);
            n.folderBusy = true; n.folderButton.disabled = true;
            let active = true, timer;
            try {
                // Read names first; obtain File content only for matching nodes.
                // No directory input/FileList importing all of Downloads.
                const directory = await noteDirectory(change,current);
                if (!current()) return;
                n.status.textContent = 'Buscando archivos de ' + node + ' en ' + directory.name + '…';
                const read = async () => {
                    const queue = [directory], matches = []; let scanned = 0;
                    while (queue.length && active && current()) {
                        for await (const entry of queue.shift().values()) {
                            if (!active || !current()) return null;
                            if (entry.kind === 'directory') { queue.push(entry); continue; }
                            if (entry.kind !== 'file') continue;
                            scanned++;
                            const name = normalizeFileNode(entry.name);
                            if (name.startsWith(node) && (!name[node.length] || !/[A-Z0-9]/.test(name[node.length]))) matches.push(entry);
                        }
                    }
                    const files = [];
                    for (const entry of matches) {
                        if (!active || !current()) return null;
                        const file = await entry.getFile();
                        if (file.size > 20000000) throw Error('oversize');
                        files.push(file);
                    }
                    return {scanned,files};
                };
                const result = await Promise.race([read(),new Promise((resolve,reject) => { timer = setTimeout(() => reject(Error('folder-timeout')),20000); })]);
                if (!result || !current()) return;
                if (!result.files.length) { n.status.textContent = directory.name + ': ' + result.scanned + ' archivo(s) revisados, sin coincidencias para ' + node + '. Se conserva tu selección anterior.'; return; }
                const transfer = new DataTransfer(); for (const file of result.files) transfer.items.add(file);
                n.files.files = transfer.files; selected();
                n.status.textContent = directory.name + ': ' + result.files.length + ' archivo(s) de ' + node + ' preparados entre ' + result.scanned + ' revisados. Revisá la selección antes de crear.';
            } catch (error) {
                if (!current()) return;
                n.status.textContent = error.name === 'AbortError' ? 'Selección de carpeta cancelada. Se conserva tu selección anterior.'
                    : error.message === 'oversize' ? 'Un archivo coincidente supera los 20 MB. Se conserva tu selección anterior; podés elegir archivos manualmente.'
                    : error.message === 'folder-timeout' ? 'La lectura de la carpeta demoró demasiado. Se conserva tu selección anterior.'
                    : 'No pudimos guardar o leer la carpeta o alguno de los archivos coincidentes. Se conserva tu selección anterior; revisá el acceso, cambiá la carpeta o elegí archivos manualmente.';
            } finally { active = false; clearTimeout(timer); n.folderBusy = false; n.folderButton.disabled = ['sending','saved','uncertain'].includes(n.state); }
        };
        n.folderButton = button('Buscar por nodo en una carpeta','note-folder',() => searchFolder());
        n.changeFolder = button('Cambiar carpeta','note-change-folder',() => searchFolder(true));
        n.panel.append(n.folderButton,n.changeFolder);
        const autoLabel = el('label'); autoLabel.className = 'viena-task-note-auto'; n.auto = el('input',undefined,'note-auto'); n.auto.type = 'checkbox'; n.auto.checked = true;
        autoLabel.append(n.auto,document.createTextNode('Guardar automáticamente al confirmarse la creación de la tarea')); n.panel.append(autoLabel);
        n.panel.append(el('p','La creación y el agendamiento siguen su flujo habitual. La nota se envía después de crear, sin esperar el agendamiento. Sin archivos, se crea la tarea normalmente.'));
        n.manual = button('Guardar nota ahora','note-now',() => {
            if (n.folderBusy) { n.status.textContent = 'Esperá a que termine la búsqueda de archivos o cancelá la selección de carpeta.'; return; }
            if (['sending','saved','uncertain'].includes(n.state)) return;
            if (!noteRequest(s,'arm',true)) { n.panel.hidden = false; n.status.textContent ||= 'No pudimos preparar la nota. Reabrí el formulario con VIENA actualizado.'; }
        }); n.manual.hidden = true; n.panel.append(n.manual);
        n.auto.addEventListener('change',() => { n.manual.hidden = n.auto.checked; });
        n.panel.append(button('Listo','note-ready',() => { n.panel.hidden = true; n.toggle.setAttribute('aria-expanded','false'); }));
        n.retry = button('Reintentar nota','note-retry',() => noteRequest(s,'retry')); n.retry.hidden = true; n.panel.append(n.retry);
        n.status = el('p',undefined,'note-status'); n.status.setAttribute('role','status'); n.panel.append(n.status);
        const inspect = button('Ver preparación','note-inspect',() => n.panel.classList.toggle('viena-task-note-inspect')); inspect.hidden = true; n.panel.append(inspect); n.inspect = inspect;
        n.dismiss = () => { if (['sending','armed'].includes(n.state)) return; clearTimeout(n.dismissTimer); n.dismissTimer = null; noteRequest(s,'discard'); n.panel.remove(); document.removeEventListener('VIENA_TASK_NOTE_RESULT',n.onResult); };
        const close = button('Cerrar aviso','note-dismiss',n.dismiss); close.hidden = true; n.panel.append(close); n.close = close;
        n.onResult = event => {
            const result = event.detail; if (result?.id !== n.id) return;
            clearTimeout(n.dismissTimer); n.dismissTimer = null;
            n.state = result.state; n.ack = result.state === 'armed'; n.status.textContent = result.message;
            if (result.state === 'armed') n.wasArmed = true;
            n.retry.hidden = result.retryable !== true;
            const locked = ['sending','saved','uncertain'].includes(n.state);
            for (const control of [n.title,n.message,n.files,n.folderButton,n.changeFolder,n.auto,n.manual]) control.disabled = locked;
            if (result.state === 'saved') { n.files.value = ''; selected(); }
            if (session === s && !visible(s.root) && !['armed','draft'].includes(n.state)) stop(s);
            if (!['armed','sending'].includes(n.state) && n.detached) close.hidden = false;
            scheduleNoteDismiss(n);
        };
        document.addEventListener('VIENA_TASK_NOTE_RESULT',n.onResult);
        s.onNoteCreate = event => {
            const target = event.target instanceof Element ? event.target.closest('button') : null;
            if (!target || !target.closest('.v-card__actions') || clean(target.textContent).toLowerCase() !== 'crear' || !n.auto.checked) return;
            if (n.folderBusy) { event.preventDefault(); event.stopImmediatePropagation(); n.panel.hidden = false; n.status.textContent = 'Esperá a que termine la búsqueda de archivos o cancelá la selección de carpeta.'; return; }
            if (!n.files.files.length) return;
            if (['sending','saved','uncertain'].includes(n.state)) return;
            if (!noteRequest(s,'arm')) { event.preventDefault(); event.stopImmediatePropagation(); n.panel.hidden = false; n.status.textContent ||= 'No pudimos preparar la nota. Reabrí el formulario con VIENA actualizado.'; }
        };
        s.root.addEventListener('click',s.onNoteCreate,true);
    }
    function stop(s) {
        if (s.note) {
            const n = s.note; s.root.removeEventListener('click',s.onNoteCreate,true);
            if (n.state === 'armed') noteRequest(s,'cancel');
            if (['sending','saved','failed','uncertain','expired'].includes(n.state)) {
                n.detached = true; n.panel.hidden = false; n.panel.classList.add('viena-task-note-result'); document.body.append(n.panel); n.close.hidden = n.state === 'sending'; n.inspect.hidden = false;
                scheduleNoteDismiss(n);
            } else { document.removeEventListener('VIENA_TASK_NOTE_RESULT',n.onResult); }
        }
        clearTimeout(s.nativeTimer);
        document.removeEventListener('wheel',s.onZoomWheel,true);
        s.observer.disconnect(); s.host?.remove(); s.editorPortal?.remove(); s.sizeHost?.remove(); s.side?.remove(); s.messageTools?.remove(); s.messageHeading?.remove(); s.messageCol?.classList.remove('viena-task-template-message-panel'); s.messageRow?.classList.remove('viena-task-template-native-grid'); s.dialog?.classList.remove('viena-task-template-dialog','viena-task-template-expanded');
        for (const [element,classes] of s.decorations || []) for (const name of classes) element.classList.remove(name);
        s.root.removeEventListener('input',s.onInput,true);
        if (session === s) session = null;
    }
    function referenceLayout(s, message) {
        const add = (element,name) => {
            if (!element || element.classList.contains(name)) return;
            element.classList.add(name); if (!s.decorations) s.decorations = new Map();
            if (!s.decorations.has(element)) s.decorations.set(element,new Set()); s.decorations.get(element).add(name);
        };
        // Persistent Vuetify dialogs replace their class list after an outside click.
        // Restore our scoped decoration through the existing observer, only when lost.
        add(s.dialog,'viena-task-template-dialog');
        if(s.expanded) add(s.dialog,'viena-task-template-expanded');
        const form = message.closest('form.v-form') || s.messageRow?.parentElement;
        add(form,'viena-task-template-form');
        add(s.root,'viena-task-template-creation-root');
        ['Problema','Tipificación','Tipo de tarea'].forEach((name,index) => {
            const group = field(s.root,name), item = group?.parentElement === form ? group : group?.closest('.row');
            if (item?.parentElement === form) add(item,'viena-task-template-header-' + index);
            add(group,'viena-task-template-native-header-field');
        });
        add(field(s.root,'Mensaje'),'viena-task-template-native-message');
        const actions = s.root.querySelector('.v-card__actions'); add(actions,'viena-task-template-actions');
        for (const control of actions?.querySelectorAll('button') || []) {
            const text = clean(control.textContent).toLowerCase();
            if (text === 'crear') add(control,'viena-task-template-create');
            else if (text === 'cancelar') add(control,'viena-task-template-cancel');
        }
    }
    function watchNativeContext(s) {
        clearTimeout(s.nativeTimer); s.nativeDeadline = Date.now()+3000;
        const tick = () => {
            if(session !== s || !s.root.isConnected) return;
            const message = nativeMessage(s.root);
            if(message && message.value !== s.nativeWatchValue) refresh(s);
            if(Date.now() < s.nativeDeadline) s.nativeTimer = setTimeout(tick,60);
            else s.nativeContextPending = false;
        };
        s.nativeTimer = setTimeout(tick,60);
    }
    function refresh(s) {
        if (session !== s) return;
        if (!visible(s.root)) { stop(s); return; }
        // Vuetify can reuse the dialog without an observable hidden frame.
        // Never protect a previous ticket's draft over the new native message.
        if (s.identity !== creationIdentity(s.root)) { void attach(s.root); return; }
        const message = nativeMessage(s.root);
        if (!message) {
            // Native first step may disappear after submission. Never enhance its result.
            if (s.message && !s.message.isConnected && !field(s.root,'Problema')) stop(s);
            return;
        }
        mount(s,message);
        referenceLayout(s,message);
        const signature = selectedText(s.root,'Problema') + '\n' + selectedText(s.root,'Tipificación');
        const changed = s.signature !== undefined && signature !== s.signature;
        if(changed) {
            s.nativeContextPending = true;
            if(!s.custom) { s.dirty = false; s.lastApplied = undefined; }
            watchNativeContext(s);
        }
        if(s.nativeContextPending && message.value !== s.text) {
            s.modeMessages ||= new Map();
            s.modeMessages.set(false,{text:message.value,dirty:false,lastApplied:undefined});
        }
        if (s.dirty && s.text !== message.value) {
            // Only real operator edits / explicit Apply are protected; macro writes
            // are allowed to replace message through the native input handler.
            s.writing = true;
            try { Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(message,s.text); message.dispatchEvent(new Event('input',{bubbles:true})); }
            finally { s.writing = false; }
            tell(s,'Conservamos tu mensaje al actualizar las opciones nativas.');
        } else if (!s.dirty) s.text = message.value;
        s.nativeWatchValue = message.value;
        s.message = message;
        if (signature !== s.signature) { s.signature = signature; s.replace.hidden = true; refreshSelect(s); if (s.custom) preview(s); }
    }
    async function readLibrary(s) {
        if (s.loading) return;
        s.loading = true; if (s.save) s.save.disabled = true;
        try {
            if (s.user) {
                checkUser(s);
                const library = validate((await bounded(chrome.storage.local.get(userKey(s.user))))[userKey(s.user)]);
                if (session !== s) return;
                s.library = library;
                const seeded = restoreIngressExample(withIngressStarter(library));
                if (!sameLibrary(seeded,library)) { seeded.revision = crypto.randomUUID(); s.library = await persistLibrary(s,seeded); }
            }
            s.readError = false;
            if (session === s && s.host) { refreshSelect(s); renderAnswers(s); tell(s,libraryMessage(s)); }
        } catch(error) {
            if (session === s) { s.readError = true; tell(s,'No se pudo leer o preparar la biblioteca. Reintentá la lectura; tus datos guardados y borradores se conservan.',true); }
        } finally {
            s.loading = false;
            if (s.save) s.save.disabled = Boolean(s.readError);
            if (s.retryRead) s.retryRead.hidden = !s.readError;
        }
    }
    async function attach(root) {
        if (!/^Creando tarea\s*:/i.test(creationIdentity(root))) { if (session?.root === root) stop(session); return; }
        if (session?.root === root && session.identity === creationIdentity(root)) { refresh(session); return; }
        if (session) stop(session);
        const s = { root,identity:creationIdentity(root),user:user(),library:empty(),loading:false,busy:false,selected:'',showAll:false,custom:false,drafts:new Map(),answers:new Map(),text:'',dirty:false,writing:false,nodeSignature:'',nodeChoice:'' };
        session = s;
        // Let Chrome own Ctrl+wheel over the modal and its background while open.
        // Ordinary scrolling remains untouched; stop() removes this listener.
        s.onZoomWheel = event => { if(event.ctrlKey && session === s && visible(s.root)) event.stopImmediatePropagation(); };
        document.addEventListener('wheel',s.onZoomWheel,{capture:true,passive:true});
        s.onInput = event => {
            if (event.target !== nativeMessage(root) || s.writing) return;
            if (s.identity !== creationIdentity(root)) { void attach(root); return; }
            if(!event.isTrusted && s.nativeContextPending) {
                s.modeMessages ||= new Map();
                s.modeMessages.set(false,{text:event.target.value,dirty:false,lastApplied:undefined});
                if(s.custom && s.dirty) { refresh(s); return; }
            }
            s.text = event.target.value; s.dirty = event.isTrusted; if (s.replace) s.replace.hidden = true;
            if (s.custom && s.apply) preview(s);
        };
        root.addEventListener('input',s.onInput,true);
        s.observer = new MutationObserver(mutations => {
            if (mutations.every(m => (m.target.nodeType === 1 ? m.target : m.target.parentElement)?.closest('.viena-task-templates'))) return;
            refresh(s);
        });
        s.observer.observe(root,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class','style']});
        refresh(s);
        await readLibrary(s);
    }
    function lookForCreation() {
        clearTimeout(opening);
        // Each native Crear tarea action starts a fresh task, including a fast
        // close/reopen of the same ticket using the same persistent dialog.
        if (session) stop(session);
        const deadline = Date.now() + 10000;
        const scan = () => {
            const root = rootNow(); if (root) { void attach(root); return; }
            if (Date.now() < deadline) opening = setTimeout(scan,60);
        }; opening = setTimeout(scan,0);
    }
    document.addEventListener('click', event => {
        const target = event.target instanceof Element ? event.target.closest('button') : null;
        if (target && !target.closest('.viena-task-templates') && clean(target.textContent).toLowerCase() === 'crear tarea') lookForCreation();
        else if (session && target && session.root.contains(target) && (['cerrar','cancelar'].includes(clean(target.textContent).toLowerCase()) || clean(target.title).toLowerCase() === 'cerrar')) setTimeout(() => { if (session && !visible(session.root)) stop(session); },100);
    },true);
    document.addEventListener('viena:ui-refresh',() => { const root = rootNow(); if (root) void attach(root); else if (session && !visible(session.root)) stop(session); });
    const initial = rootNow(); if (initial) void attach(initial);
})();
