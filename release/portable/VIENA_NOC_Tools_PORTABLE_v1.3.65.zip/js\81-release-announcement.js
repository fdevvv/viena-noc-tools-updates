(() => {
  'use strict';
  if(location.hostname!=='viena.telecentro.net.ar'||window.top!==window)return;
  const release=globalThis.VienaReleaseNotes,announcement=release?.announcement;
  const manifest=chrome.runtime.getManifest(),channel=/\bDEV\b/i.test(manifest.name)?'dev':'release';
  // A version bump never selects content. Each release needs Emanuel's selection.
  if(!announcement?.approved||announcement.version!==release.version||
     (channel==='release'&&manifest.version!==release.version)||!announcement.items?.length)return;
  const HOST='viena-noc-release-announcement',key=`viena_release_news_seen_${channel}_v1`;
  if(document.getElementById(HOST))return;
  let reading=false,finished=false,hide=null,recheck=false;
  const visible=()=>document.visibilityState==='visible'&&document.hasFocus();
  async function bounded(operation){let timer;try{return await Promise.race([operation,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('timeout')),3000);})]);}finally{clearTimeout(timer);}}
  function stop(){finished=true;document.removeEventListener('visibilitychange',activate);window.removeEventListener('focus',activate);window.removeEventListener('blur',onLeave);window.removeEventListener('pagehide',onLeave);}
  function onLeave(){if(!visible())hide?.();}
  function activate(){
    if(!visible()){hide?.();return;}
    if(finished||document.getElementById(HOST)||!document.body)return;
    if(reading){recheck=true;return;}
    reading=true;
    const start=async()=>{
      const stored=await bounded(chrome.storage.local.get([key,'viena_ui_theme_v1']));
      if(stored[key]===release.version){stop();return;}
      if(!visible()||finished||document.getElementById(HOST))return;
      await show(stored.viena_ui_theme_v1==='dark');
    };
    // Hold the origin lock only while a visible tab presents the notice.
    const run=navigator.locks?.request
      ?navigator.locks.request(`viena-news-${channel}`,{ifAvailable:true},lock=>lock?start():undefined)
      :start();
    void Promise.resolve(run).catch(()=>{}).finally(()=>{reading=false;if(recheck){recheck=false;activate();}});
  }
  function show(dark){return new Promise(resolve=>{
    const previous=document.activeElement,host=document.createElement('div');host.id=HOST;
    const shadow=host.attachShadow({mode:'open'}),style=document.createElement('style');
    style.textContent=`:host{all:initial}*{box-sizing:border-box}dialog{--surface:#fff;--ink:#254b6e;--muted:#5d7082;--line:#e3ebf2;--soft:#f7fbff;padding:0;border:1px solid var(--line);border-radius:14px;width:min(610px,calc(100vw - 28px));max-height:calc(100dvh - 28px);overflow:auto;background:var(--surface);color:var(--ink);box-shadow:0 22px 80px #102c4850;font:14px/1.5 'Segoe UI',Arial,sans-serif}dialog.dark{--surface:#152131;--ink:#e1eaf4;--muted:#b1c2d4;--line:#33465b;--soft:#1a2c40;color-scheme:dark}dialog::backdrop{background:#10233670}header{padding:25px 30px 22px;border-bottom:1px solid var(--line);background:var(--soft)}.kicker{font-size:11px;font-weight:700;letter-spacing:1px}h1{margin:9px 0 0;font-size:25px;line-height:1.25;font-weight:650}main{padding:23px 30px 26px}.intro{margin:0 0 22px;color:var(--muted)}ul{list-style:none;margin:0;padding:0}li{position:relative;margin-bottom:19px;padding-left:19px}li:last-child{margin-bottom:0}li::before{content:'•';position:absolute;left:0;color:#2375bc;font-size:21px;top:-4px}li b{display:block;font-size:15px;margin-bottom:4px}li p{margin:0;color:var(--muted)}footer{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:18px 30px;border-top:1px solid var(--line);background:var(--soft)}button{font:600 14px 'Segoe UI',Arial,sans-serif;cursor:pointer;border-radius:7px;min-height:44px;padding:11px 16px;border:1px solid var(--line);background:var(--soft);color:var(--ink)}button:focus-visible,summary:focus-visible{outline:3px solid #4c9be8;outline-offset:3px}.history{border:0;background:transparent;padding-left:0;color:var(--ink);text-align:left}.primary{background:#126bbb;color:#fff;border-color:#126bbb;padding-inline:25px}button:disabled{opacity:.55;cursor:default}.error{color:var(--muted);margin:0;padding:0 30px 15px}details{border-bottom:1px solid var(--line);padding:12px 0}details summary{cursor:pointer;font-weight:650}details ul{margin-top:12px}details li{margin-bottom:10px}details li::before{font-size:16px;top:0}@media(max-width:440px){header,main,footer{padding:18px}h1{font-size:21px}footer{flex-wrap:wrap}.error{padding-inline:18px}}`;
    const dialog=document.createElement('dialog');if(dark)dialog.className='dark';
    dialog.setAttribute('aria-labelledby','news-title');
    const header=document.createElement('header'),kicker=document.createElement('div'),title=document.createElement('h1');
    kicker.className='kicker';kicker.textContent='VIENA NOC TOOLS · NOVEDADES';title.id='news-title';title.textContent=`Lo nuevo en la versión ${release.version}`;header.append(kicker,title);
    const main=document.createElement('main'),footer=document.createElement('footer');
    const history=document.createElement('button'),done=document.createElement('button'),later=document.createElement('button');history.type=done.type=later.type='button';
    history.className='history';history.textContent='Ver historial completo →';done.className='primary';done.textContent='Entendido';later.textContent='Cerrar por ahora';later.hidden=true;footer.append(history,later,done);
    const error=document.createElement('p');error.className='error';error.hidden=true;error.setAttribute('role','status');
    dialog.append(header,main,footer,error);shadow.append(style,dialog);document.body.append(host);
    let closed=false,saving=false,showingHistory=false;
    function render(){
      main.replaceChildren();
      if(!showingHistory){
        const intro=document.createElement('p');intro.className='intro';intro.textContent='Estas mejoras ya están disponibles para tu trabajo diario.';
        const list=document.createElement('ul');for(const item of announcement.items){const li=document.createElement('li'),b=document.createElement('b'),p=document.createElement('p');b.textContent=item.title;p.textContent=item.text;li.append(b,p);list.append(li);}main.append(intro,list);
      }else{
        for(const entry of globalThis.VienaReleaseHistory||[release]){const detail=document.createElement('details'),summary=document.createElement('summary'),list=document.createElement('ul');summary.textContent=`v${entry.version} · ${entry.title}`;detail.open=entry.version===release.version;for(const note of entry.notes){const li=document.createElement('li');li.textContent=note;list.append(li);}detail.append(summary,list);main.append(detail);}
      }
      title.textContent=showingHistory?'Historial de versiones':`Lo nuevo en la versión ${release.version}`;
      history.textContent=showingHistory?'← Volver a novedades':'Ver historial completo →';dialog.scrollTop=0;
    }
    function close(restore){if(closed)return;closed=true;hide=null;if(dialog.open)dialog.close();host.remove();if(restore&&visible()&&previous?.isConnected){try{previous.focus({preventScroll:true});}catch(_){}}resolve();}
    hide=()=>close(false);
    async function dismiss(){
      if(saving||closed)return;saving=true;done.disabled=true;error.hidden=true;
      try{await bounded(chrome.storage.local.set({[key]:release.version}));stop();close(true);}
      catch(_){if(!closed){error.textContent='No se pudo guardar la confirmación. Volvé a pulsar Entendido.';error.hidden=false;done.disabled=false;later.hidden=false;}}
      finally{saving=false;}
    }
    done.addEventListener('click',()=>{void dismiss();});
    later.addEventListener('click',()=>{stop();close(true);});
    history.addEventListener('click',()=>{showingHistory=!showingHistory;render();});
    dialog.addEventListener('cancel',event=>{event.preventDefault();void dismiss();});
    dialog.addEventListener('keydown',event=>{event.stopPropagation();if(event.key==='Escape'){event.preventDefault();void dismiss();}});
    try{render();dialog.showModal();done.focus({preventScroll:true});}catch(_){close(false);}
  });}
  document.addEventListener('visibilitychange',activate);window.addEventListener('focus',activate);window.addEventListener('blur',onLeave);window.addEventListener('pagehide',onLeave);
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',activate,{once:true});else activate();
})();
