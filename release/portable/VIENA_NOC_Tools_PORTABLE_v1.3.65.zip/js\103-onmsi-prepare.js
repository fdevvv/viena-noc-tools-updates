(() => {
    'use strict';
    function recipe(kind){
        const types={VAO:{category:'661935750da17976dd05af2a',categoryName:'ONMSI',problem:'6602d48a035859f38958aaa3',problemName:'Alarma ONMSI',template:'Servicio Afectado: ONMSI',priority:'Menor'},VXC:{category:'5f7c86a31d2eef063a2d25cc',categoryName:'Incidentes',problem:'633d7b4d1d2eef2910299df1',problemName:'FO - Corte',template:'Se detecta corte de FO',priority:'Critica',affectation:'SI'},VXA:{category:'5f7c86a31d2eef063a2d25cc',categoryName:'Incidentes',problem:'633d7c081d2eef2bf94b21eb',problemName:'Atenuacion FO',template:'Se detecta una atenuacion',affectation:'SI'}};
        if(!Object.hasOwn(types,kind))throw Error('Elegí VAO, VXC o VXA.');return {kind,...types[kind],sector:'5ad8a34351b99792552078e0',subject:'5bec69d81d2eef30d6740903',queue:'5ad8a36251b99792eb60418a'};
    }
    async function prepare(r,a,token){
        if(location.origin!=='https://moica2.telecentro.net.ar'||location.pathname!=='/viewCrearTktManual.php')return {ok:false,message:'Revisá la sesión de Crear ticket de MOICA.'};
        if(window.__vienaOnmsiPrepare)return {ok:false,message:'Ya hay una preparación en curso.'};
        const state={token,cancelled:false},deadline=Date.now()+45000;window.__vienaOnmsiPrepare=state;
        const normalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toUpperCase();
        const banner=document.createElement('section');banner.id='viena-onmsi-prepare-status';banner.setAttribute('role','status');banner.style.cssText='position:fixed;top:20px;right:20px;max-width:min(520px,calc(100vw - 40px));z-index:2147483646;background:#f4f9fc;border:1px solid #c7dce8;border-left:4px solid #006b9d;padding:16px 18px;border-radius:10px;box-shadow:0 8px 28px #16324730;font:14px/1.5 Arial;color:#173247;transition:opacity .25s,transform .25s';
        const status=document.createElement('div'),stop=document.createElement('button');stop.type='button';stop.textContent='Detener';stop.style.cssText='margin-top:10px;border:1px solid #b6cbd8;border-radius:6px;background:#fff;color:#173247;padding:6px 12px;font:13px Arial;cursor:pointer';stop.onclick=()=>{state.cancelled=true;};banner.append(status,stop);document.getElementById(banner.id)?.remove();document.body.append(banner);
        const changed=e=>{if(e.isTrusted&&(document.getElementById('FO-TICKET-ADD')?.contains(e.target)||e.target.id==='MO-PROBLEMA-CATEGORIA-ID'))state.cancelled=true;};
        const leave=()=>{state.cancelled=true;};window.addEventListener('pagehide',leave,{once:true});document.addEventListener('input',changed,true);document.addEventListener('change',changed,true);
        const check=()=>{if(state.cancelled)throw Error('Preparación detenida.');if(Date.now()>deadline)throw Error('La preparación superó el tiempo de espera.');};
        const busy=()=>Number(window.jQuery?.active)>0;
        async function wait(test,label){status.textContent=label;const end=Math.min(deadline,Date.now()+10000);for(;;){check();if(Date.now()>end)throw Error('MOICA no completó: '+label);const result=!busy()&&test();if(result)return result;await new Promise(r=>setTimeout(r,100));}}
        async function choose(selector,id,label,json=false){
            const selected=await wait(()=>{const el=document.querySelector(selector);if(!el||el.disabled||!el.getClientRects().length)return null;const matches=[...el.options].filter(o=>{let value=o.value;if(json){try{const d=JSON.parse(value);value=d._id?.$oid??d._id;}catch{}}return value===id&&(Array.isArray(label)?label:[label]).some(l=>normalize(l)===normalize(o.textContent));});if(matches.length>1&&matches.some(o=>o.value!==matches[0].value||normalize(o.textContent)!==normalize(matches[0].textContent)))throw Error('Opciones ambiguas en '+selector);return matches[0];},'Esperando '+(Array.isArray(label)?label[0]:label));
            const el=selected.closest('select');el.value=selected.value;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));if(window.jQuery?.fn?.selectpicker)window.jQuery(el).selectpicker('refresh');
        }
        async function click(selector){const label=selector==='#BT-ADD-PROBLEMA'?'Agregar problema':selector==='#BTN-ADD-PROBLEMA-TKT'?'Agregar problema al ticket':'Control del formulario';const el=await wait(()=>{const e=document.querySelector(selector);return e&&!e.disabled&&e.getClientRects().length&&e;},'Esperando '+label);el.click();}
        try{
            await wait(()=>document.getElementById('FO-TICKET-ADD'),'Crear ticket');
            for(let i=0;document.querySelector('#TKT-PROBLEMAS-DIV .jsProblema');i++){
                if(i>=100)throw Error('Demasiados problemas anteriores para reemplazar.');
                const count=document.querySelectorAll('#TKT-PROBLEMAS-DIV .jsProblema').length;
                const remove=await wait(()=>{const first=document.querySelector('#TKT-PROBLEMAS-DIV .jsProblema'),button=first?.querySelector('button[onclick*="delProblema"]')||first?.querySelector('.panel-heading button.btn-warning');return button&&!button.disabled&&button;},'Quitar el problema anterior');
                // UI_TRACE (5): remove first, clear message, then Sector inicial.
                // Native removal also works when the problems panel is collapsed.
                remove.click();
                await wait(()=>document.querySelectorAll('#TKT-PROBLEMAS-DIV .jsProblema').length<count,'Quitar problema anterior');
            }
            const previousMessage=document.getElementById('TKT-MSG-ADD');if(!previousMessage)throw Error('El mensaje no está disponible.');previousMessage.value='';previousMessage.dispatchEvent(new Event('input',{bubbles:true}));previousMessage.dispatchEvent(new Event('change',{bubbles:true}));
            await choose('#TKT-ORIGEN-ADD',r.sector,['DARS - CGS - NOC DE CORE ACCESO','DARS - NOC - RED']);
            await choose('#TKT-ASUNTO-ADD',r.subject,'Tareas Fibra Óptica');
            await choose('#TKT-CATEGORIA-ADD-NEW',r.category,r.categoryName,true);
            await choose('#PANEL-COLA-DESTINO > .row > .col-xs-4:nth-of-type(1) select',r.sector,'DARS - NOC - RED');
            await choose('#PANEL-COLA-DESTINO > .row > .col-xs-4:nth-of-type(2) select',r.queue,'GEC');
            await click('#BT-ADD-PROBLEMA');await choose('#MO-PROBLEMA-CATEGORIA-ID',r.problem,r.problemName);await click('#BTN-ADD-PROBLEMA-TKT');
            await wait(()=>document.querySelectorAll('#TKT-PROBLEMAS-DIV .jsProblema').length===1&&normalize(document.getElementById('TKT-MSG-ADD')?.value).startsWith(normalize(r.template)),'Plantilla de '+r.problemName);
            await choose('#TKT-ACCION-ADD','Correctiva','Correctiva');if(r.priority)await choose('#TKT-PRIORIDAD-ADD',r.priority,r.priority);if(r.affectation)await choose('#TKT-AFECTACION-ADD',r.affectation,r.affectation);
            await wait(()=>true,'Opciones finales');check();const msg=document.getElementById('TKT-MSG-ADD');msg.value=a.message;msg.dispatchEvent(new Event('input',{bubbles:true}));msg.dispatchEvent(new Event('change',{bubbles:true}));
            status.textContent='Formulario '+r.kind+' preparado con alarma '+a.id+'. Revisá los datos antes de enviar.';banner.style.borderLeftColor='#16713e';banner.style.background='#f0f9f3';state.success=true;return {ok:true,submitted:false};
        }catch(e){status.textContent=e.message+' Revisá los campos completados antes de reintentar.';return {ok:false,message:status.textContent,submitted:false};}
        finally{stop.textContent='Cerrar';stop.onclick=()=>banner.remove();if(state.success)setTimeout(()=>{banner.style.opacity='0';banner.style.transform='translateY(-6px)';setTimeout(()=>banner.remove(),250);},3500);document.removeEventListener('input',changed,true);document.removeEventListener('change',changed,true);window.removeEventListener('pagehide',leave);if(window.__vienaOnmsiPrepare===state)delete window.__vienaOnmsiPrepare;}
    }
    // Serialized into the already prepared native creation page. Observe only
    // native creation success; never submit, replace or wrap native handlers.
    function tracking(a,mode='install'){
        const valid=n=>/^\d{6}[A-Z]{2,3}\d+$/i.test(n||'');
        const cell=v=>{const s=String(v??'').replace(/[\u0000-\u001f\u007f]+/g,' ').trim();return /^[=+@-]/.test(s)?"'"+s:s;};
        function row(ticket,state,date=new Date()){
            if(!valid(ticket)||!String(state||'').trim())throw Error('El número y estado del ticket deben estar confirmados.');
            if(!Number.isFinite(date.getTime()))throw Error('Fecha no válida.');
            const day=[date.getDate(),date.getMonth()+1].map(v=>String(v).padStart(2,'0')).join('/')+'/'+date.getFullYear();
            const raw=String(a.specificProblem||'').trim(),key=raw.replace(/[ _-]+/g,'').toUpperCase(),cause={FIBERCUT:'FIBER_CUT',ATTENUATION:'Attenuation',INJECTION:'INJECTION'}[key]||raw;
            return [day,a.operator,'',a.origin,'',cause,ticket,'',a.severity,state,'',''].map(cell).join('\t');
        }
        if(mode==='row')return row(a.ticket,a.state,a.date?new Date(a.date):new Date());
        if(location.origin!=='https://moica2.telecentro.net.ar'||location.pathname!=='/viewCrearTktManual.php')return {ok:false};
        const result=document.getElementById('TKT-RESULTADO-ADD'),jq=window.jQuery;
        if(!result||typeof jq!=='function'||typeof jq.ajax!=='function')return {ok:false,message:'El resultado nativo de creación no está disponible.'};
        window.__vienaOnmsiTracking103?.close();
        let ticket='',busy=false,closed=false,request,generation=0;
        const section=document.createElement('section'),button=document.createElement('button'),status=document.createElement('p'),manual=document.createElement('textarea');
        section.id='viena-onmsi-tracking-copy';section.style.cssText='padding:12px 16px;border-top:1px solid #cbdce7';
        button.type='button';button.className='btn btn-primary';button.textContent='Copiar seguimiento ONMSi';button.disabled=true;
        status.setAttribute('role','status');status.textContent='Disponible cuando MOICA confirme el ticket creado desde esta alarma.';
        manual.readOnly=true;manual.hidden=true;manual.setAttribute('aria-label','Fila de seguimiento para copiar');manual.style.cssText='width:100%;min-height:70px';section.append(button,status,manual);result.append(section);
        const dataOf=settings=>{try{const u=new URL(settings.url,location.href);if(u.origin!==location.origin||u.pathname!=='/scripts/ajaxTickets2.php'||String(settings.type||settings.method||'').toUpperCase()!=='POST')return null;const d=typeof settings.data==='string'?Object.fromEntries(new URLSearchParams(settings.data)):settings.data;return d?.accion==='ADD-TICKET-MANUAL'?d:null;}catch{return null;}};
        const reset=()=>{generation++;ticket='';request?.abort();button.disabled=true;manual.hidden=true;status.textContent='Esperando confirmación de MOICA.';};
        const sending=(_e,_xhr,settings)=>{if(dataOf(settings))reset();};
        const success=(_e,_xhr,settings,response)=>{
            const d=dataOf(settings);if(!d||closed)return;
            if(typeof d.mensaje!=='string'||!d.mensaje.includes(a.message)||!response||Object.hasOwn(response,'noses')||response.error!==''||!valid(response.data))return;
            const n=String(response.data).toUpperCase(),nativeNumber=document.getElementById('NEW-TKT-NRO')?.value;
            if(nativeNumber!==n||!result.querySelector('.modal-body')?.textContent.includes(n))return;
            ticket=n;button.disabled=false;status.textContent='Ticket '+ticket+'. Copia 12 columnas; las no solicitadas quedan vacías.'+(a.operator?'':' Operador VIENA no disponible: esa celda quedará vacía.');
        };
        jq(document).on('ajaxSend.vienaOnmsiTracking103',sending).on('ajaxSuccess.vienaOnmsiTracking103',success);
        const post=data=>new Promise((resolve,reject)=>{
            request=jq.ajax({url:'scripts/ajaxTickets2.php',method:'POST',type:'POST',dataType:'json',timeout:10000,data,success:r=>{if(!r||Object.hasOwn(r,'noses')||r.error!=='')reject(Error('MOICA no confirmó el estado. Revisá la sesión.'));else resolve(r.data);},error:()=>reject(Error('No se pudo consultar el estado actual. Reintentá.'))});
        });
        const close=()=>{closed=true;generation++;request?.abort();jq(document).off('.vienaOnmsiTracking103');window.removeEventListener('pagehide',close);section.remove();if(window.__vienaOnmsiTracking103?.close===close)delete window.__vienaOnmsiTracking103;};
        window.__vienaOnmsiTracking103={close};window.addEventListener('pagehide',close,{once:true});
        button.onclick=async()=>{
            if(busy||closed||!ticket)return;busy=true;button.disabled=true;manual.hidden=true;const current=generation,n=ticket;
            const live=()=>!closed&&current===generation&&ticket===n;
            try{
                status.textContent='Consultando estado actual…';
                const id=await post({accion:'GET-ID-TKT',nroTicket:n});if(!live())return;
                if(typeof id!=='string'||!/^[a-f0-9]{24}$/i.test(id))throw Error('MOICA no confirmó la identidad del ticket.');
                const record=await post({accion:'GET-TKT',idTicket:id});if(!live())return;
                const recordId=record?._id?.$oid??record?._id,state=record?.estado_actual?.estado;
                if(recordId!==id||record?.nroTkt!==n||typeof state!=='string'||!state.trim()||state.length>100)throw Error('El estado recibido no corresponde al ticket creado.');
                const text=row(n,state);let copied=false;
                try{await navigator.clipboard.writeText(text);copied=true;}catch{
                    const copy=e=>{e.preventDefault();e.clipboardData.setData('text/plain',text);};
                    document.addEventListener('copy',copy);try{copied=document.execCommand('copy');}finally{document.removeEventListener('copy',copy);}
                }
                if(!live())return;
                status.textContent=copied?'Fila copiada. Pegala desde la columna FECHA de la planilla.':'No se pudo copiar automáticamente. Copiá el texto seleccionado y pegalo desde FECHA.';
                if(!copied){manual.hidden=false;manual.value=text;manual.focus();manual.select();}
            }catch(e){if(live())status.textContent=e.message;}
            finally{busy=false;if(!closed)button.disabled=!ticket;}
        };
        return {ok:true};
    }
    const api={recipe,prepare,tracking};if(typeof module==='object')module.exports=api;else globalThis.VienaOnmsiPrepare=api;
})();
