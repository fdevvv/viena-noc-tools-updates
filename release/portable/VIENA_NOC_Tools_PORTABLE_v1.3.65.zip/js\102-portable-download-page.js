(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const engine = VienaLocalUpdater;
  const installed = chrome.runtime.getManifest().version;
  const client = VienaPortableDownload.create(fetch, installed);
  const scheduled = new URLSearchParams(location.search).get('auto');
  let selected, busy;
  $('identity').textContent = 'Versión instalada v' + installed;

  function status(text, error = false) {
    $('status').textContent = text;
    $('status').dataset.error = String(error);
  }
  function progress(update) {
    status(update.label + (update.totalWrites ? ' (' + update.writtenCount + '/' + update.totalWrites + ')' : ''));
  }
  function controls() {
    for (const id of ['check', 'link', 'authorize', 'install', 'resume']) {
      $(id).disabled = busy || (id === 'install' && !selected);
    }
  }
  async function run(action) {
    if (busy) return;
    busy = true;
    controls();
    try { await action(); }
    catch (error) { status(error.message || 'No se pudo completar la actualización.', true); }
    finally { busy = false; controls(); }
  }
  function finish(result) {
    if (!result?.ok) throw Error('La actualización quedó pendiente.');
    status('Archivos verificados. Reiniciando VIENA…');
    chrome.runtime.reload();
  }
  async function apply() {
    const link = await engine.getLinkStatus();
    if (!link.valid || link.permission !== 'granted') {
      status('Disponible v' + selected.version + '. Vinculá o autorizá la carpeta instalada.');
      return;
    }
    finish(await engine.installPackage({
      packageUrl: selected.url,
      packageSha256: selected.sha256,
      expectedVersion: selected.version,
      expectedBuild: selected.version,
      expectedChannel: 'RELEASE',
      onProgress: progress,
    }));
  }
  async function check() {
    status('Consultando GitHub…');
    const result = await client.check();
    selected = result.available ? result : null;
    if (!selected) {
      status('No hay una versión posterior a v' + installed + ' en GitHub.');
      return;
    }
    status('Disponible v' + selected.version + '.');
    if (selected.automatic && scheduled === selected.version) await apply();
  }
  $('check').addEventListener('click', () => void run(check));
  $('install').addEventListener('click', () => void run(apply));
  $('link').addEventListener('click', () => void run(async () => {
    const link = await engine.pickAndLink();
    status('Carpeta vinculada: ' + link.name + '.');
    if (selected?.automatic && scheduled === selected.version) await apply();
  }));
  $('authorize').addEventListener('click', () => void run(async () => {
    const handle = await engine.getStoredHandleForUi();
    if (!handle) { status('Primero vinculá la carpeta de VIENA.'); return; }
    await engine.authorizeStoredHandleFromGesture(handle);
    status('Carpeta autorizada.');
    if (selected?.automatic && scheduled === selected.version) await apply();
  }));
  $('resume').addEventListener('click', () => void run(async () => {
    const result = await engine.resumePendingUpdate({ onProgress: progress });
    if (result.skipped) status('No hay una actualización interrumpida.');
    else finish(result);
  }));
  controls();
  if (scheduled || new URLSearchParams(location.search).has('check')) void run(check);
})();
