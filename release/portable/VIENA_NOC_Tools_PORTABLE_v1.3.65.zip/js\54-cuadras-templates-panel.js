(function(root){
  'use strict';
  const KEY='viena_cuadras_fallas_templates_v1', OPTIONS=KEY+'_opciones';
  const defaults=[
    'Se verifica caida parcial de CMs sin patron de red.',
    'Se verifica conteo POST FEC DS QAM/ OFDM en cuadras',
    'Se verifica conteo POST FEC US QAM / OFDM en cuadras.',
    'Se verifica niveles de PWR DS bajos / fuera de rango.',
    'Se verifica niveles de SNR DS bajos / fuera de rango.',
    'Se verifica niveles de PWR US bajos / fuera de rango.',
    'ESTADO DE FUENTE:'
  ];
  const clean=value=>String(value||'').replace(/\s+/g,' ').trim();
  const orderedOptions=options=>JSON.stringify(Object.keys(options||{}).sort().map(key=>[key,options[key]]));
  function normalize(entries){
    if(!Array.isArray(entries))throw Error('No se pudo leer la biblioteca de cuadras. Tus datos se conservan.');
    const ids=new Set(),names=new Set();
    return entries.map(entry=>{
      if(!entry||typeof entry.id!=='string'||!entry.id||ids.has(entry.id)||typeof entry.text!=='string'||!Array.isArray(entry.options))throw Error('Template de cuadras inválido. Tus datos se conservan.');
      const text=clean(entry.text),name=text.toLocaleLowerCase('es-AR');
      if(!text||text.length>240)throw Error('Completá el texto de la falla (máximo 240 caracteres).');
      if(names.has(name))throw Error('Ya existe un template con ese texto.');ids.add(entry.id);names.add(name);
      const seen=new Set(),options=[];
      for(const raw of entry.options){
        if(typeof raw!=='string')throw Error('Revisá las opciones del template.');
        const option=clean(raw),key=option.toLocaleLowerCase('es-AR');
        if(option.length>240)throw Error('Cada opción admite hasta 240 caracteres.');
        if(option&&!seen.has(key)){seen.add(key);options.push(option);}
      }
      return {id:entry.id,text,options};
    });
  }
  function decode(stored){
    const texts=Object.hasOwn(stored,KEY)?stored[KEY]:defaults;
    const options=stored[OPTIONS]??(Object.hasOwn(stored,KEY)?{}:{'ESTADO DE FUENTE:':['DOWN','UP']});
    if(!Array.isArray(texts)||!options||typeof options!=='object'||Array.isArray(options)||texts.some(text=>typeof text!=='string'))throw Error('No se pudo leer la biblioteca de cuadras. Tus datos se conservan.');
    return {templates:normalize(texts.map(text=>({id:text,text,options:Object.hasOwn(options,text)?options[text]:[]}))),revision:JSON.stringify([stored[KEY],stored[OPTIONS]===undefined?null:orderedOptions(stored[OPTIONS])])};
  }
  function encode(entries){
    const templates=normalize(entries);
    return {[KEY]:templates.map(t=>t.text),[OPTIONS]:Object.fromEntries(templates.filter(t=>t.options.length).map(t=>[t.text,t.options]))};
  }
  function line(template,selected){if(/^ESTADO DE FUENTE:$/i.test(template.text))return selected.length?template.text+' '+selected.join(', '):template.text;return selected.length?template.text.replace(/[.:;]+$/,'')+' '+selected.join(', ')+'.':template.text;}
  function preview(template){const text=line(template,template.options);return /^ESTADO DE FUENTE:/i.test(template.text)?text:'FALLA DETECTADA:\n- '+text;}
  const bounded=promise=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('La operación tardó demasiado. Tus borradores se conservan.')),8000);Promise.resolve(promise).then(value=>{clearTimeout(timer);resolve(value);},error=>{clearTimeout(timer);reject(error);});});
  const read=async()=>decode(await bounded(chrome.storage.local.get([KEY,OPTIONS])));
  let pendingWrite=null;
  async function write(entries){
    if(pendingWrite)throw Error('El guardado anterior sigue pendiente. Volvé a intentarlo cuando termine.');
    const payload=encode(entries),operation=Promise.resolve(chrome.storage.local.set(payload));pendingWrite=operation;
    await bounded(operation.finally(()=>{if(pendingWrite===operation)pendingWrite=null;}));
    const actual=await bounded(chrome.storage.local.get([KEY,OPTIONS]));
    if(JSON.stringify(actual[KEY])!==JSON.stringify(payload[KEY])||orderedOptions(actual[OPTIONS])!==orderedOptions(payload[OPTIONS]))throw Error('No se pudo verificar el guardado. Tus borradores se conservan.');
    return decode(actual);
  }
  function initHome(options){root.VienaBuildingTemplates.initHome(options,{section:'cuadras-templates',title:'Templates de cuadras',navAfter:'building-templates',description:'Editá los mismos templates y opciones que usás en Seleccionar cuadras.',deleteMessage:'Se quitará este template de la biblioteca de cuadras.',normalize,read,write,line,preview,maxTemplates:Infinity});}
  const api={normalize,decode,encode,line,preview,initHome};if(typeof module==='object'&&module.exports)module.exports=api;else root.VienaCuadrasPanel=api;
})(globalThis);
