/* Comparación DS por cuadra. Sólo datos declarativos; no ejecuta respuestas HTML. */
(function(){
  'use strict';
  const native=typeof module==='object'&&module.exports?require('./58-mira-native-chart.js'):window.__VIENA_MIRA_NATIVE__;
  const valid=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0;
  const WINDOW=1.99*86400000,THRESHOLD=1e-9;
  function date(label){const m=String(label).match(/^(\d{2})\/(\d{2})\/(\d{2}|\d{4}) (\d{2}):(\d{2})$/);if(!m)return null;const y=+m[3]<100?2000+ +m[3]:+m[3],t=Date.UTC(y,+m[2]-1,+m[1],+m[4],+m[5]),d=new Date(t);return d.getUTCFullYear()===y&&d.getUTCMonth()===+m[2]-1&&d.getUTCDate()===+m[1]&&+m[4]<24&&+m[5]<60?t:null;}
  function label(t){const s=new Date(t).toISOString();return s.slice(0,10).split('-').reverse().join('/')+': '+s.slice(11,16);}
  function cadence(points){const gaps=points.slice(1).map((p,i)=>p.stamp-points[i].stamp).filter(v=>v>0).sort((a,b)=>a-b);return gaps.length?gaps[Math.floor((gaps.length-1)/2)]:0;}
  function parse(html,node,frequency){
    const matches=[...String(html).matchAll(/Highcharts\.chart\(\s*['"]nodoCmts_chartFrec_dsFec['"]\s*,\s*/g)];
    if(matches.length!==1)throw Error('frequency-chart');
    const options=native.history(html,'nodoCmts_chartFrec_dsFec');
    if(options.title?.text!==node+' DS'+frequency+' - Fec DS')throw Error('frequency-identity');
    const axis=Array.isArray(options.xAxis)?options.xAxis[0]:options.xAxis,categories=axis?.categories,posts=options.series?.filter(s=>s.name==='Post');
    if(!Array.isArray(categories)||!categories.length||categories.length>100000||posts?.length!==1||!Array.isArray(posts[0].data)||posts[0].data.length!==categories.length)throw Error('frequency-data');
    const seen=new Set(),points=categories.map((c,i)=>{const stamp=date(c),value=posts[0].data[i];if(stamp===null||seen.has(stamp)||value!==null&&!valid(value))throw Error('frequency-sample');seen.add(stamp);return {stamp,value};}).sort((a,b)=>a.stamp-b.stamp);
    if(!points.some(p=>valid(p.value)))throw Error('frequency-no-post');
    return {frequency:String(frequency),points,nativeOptions:options};
  }
  function nearest(points,stamp,tolerance){let lo=0,hi=points.length;while(lo<hi){const m=(lo+hi)>>1;if(points[m].stamp<stamp)lo=m+1;else hi=m;}const candidates=[points[lo-1],points[lo]].filter(Boolean).sort((a,b)=>Math.abs(a.stamp-stamp)-Math.abs(b.stamp-stamp));const p=candidates[0];return p&&Math.abs(p.stamp-stamp)<=tolerance?p:null;}
  function compare(task,frequencies){
    const end=Math.max(-Infinity,...frequencies.flatMap(f=>f.points.length?[f.points.at(-1).stamp]:[])),from=end-WINDOW;
    const groups=new Map();for(const row of task.results){const cm=row.cm;if(!Number.isSafeInteger(cm.block)||cm.block<0)continue;const key=JSON.stringify([cm.street.toUpperCase(),cm.block]);if(!groups.has(key))groups.set(key,{street:cm.street,block:cm.block,rows:[]});groups.get(key).rows.push(row);}
    const clipped=frequencies.map(f=>({...f,points:f.points.filter(p=>p.stamp>=from&&p.stamp<=end)})),steps=new Map(task.results.map(row=>[row,cadence(row.points)]));
    const blocks=[];
    for(const group of groups.values()){
      const found=[];let covered=false;
      for(const f of clipped){
        const pairs=[],observed=new Set(),frequencyStep=cadence(f.points);
        for(const row of group.rows){const tol=Math.min(steps.get(row)/2,frequencyStep/2,5*60000);for(const hit of row.match.hits){if(hit.stamp<from||hit.stamp>end)continue;const point=nearest(f.points,hit.stamp,tol);if(!point||!valid(point.value))continue;covered=true;observed.add(row.cm.mac);if(point.value>=THRESHOLD)pairs.push({stamp:hit.stamp,frequencyStamp:point.stamp,cm:row.cm.mac,value:point.value,cmValue:hit.value});}}
        if(!pairs.length)continue;
        pairs.sort((a,b)=>a.stamp-b.stamp);const episodes=[],step=Math.min(frequencyStep||0, ...group.rows.map(r=>steps.get(r)||0));let current;
        for(const pair of pairs){if(!current||pair.stamp-current.last>step*1.5){current={start:Math.min(pair.stamp,pair.frequencyStamp),end:Math.max(pair.stamp,pair.frequencyStamp),last:pair.stamp,cms:new Set(),peak:0,offset:0};episodes.push(current);}current.last=pair.stamp;current.end=Math.max(current.end,pair.stamp,pair.frequencyStamp);current.cms.add(pair.cm);current.peak=Math.max(current.peak,pair.value);current.offset=Math.max(current.offset,Math.abs(pair.stamp-pair.frequencyStamp));}
        found.push({frequency:f.frequency,cms:[...new Set(pairs.map(p=>p.cm))],observed:observed.size,episodes:episodes.map(p=>({...p,cms:[...p.cms]})),points:f.points,nativeOptions:f.nativeOptions});
      }
      found.sort((a,b)=>+a.frequency- +b.frequency);blocks.push({street:group.street,block:group.block,frequencies:found,status:found.length?'matched':covered?'no-match':'no-coverage'});
    }
    blocks.sort((a,b)=>a.street.localeCompare(b.street,'es')||a.block-b.block);
    return {node:task.source.node,from,end,total:frequencies.length,affected:clipped.filter(f=>f.points.some(p=>valid(p.value)&&p.value>=THRESHOLD)).length,blocks};
  }
  function powerSummary(task,selected){
    if(!Array.isArray(task.inventoryCms))return;
    const reference=task.powerReference||{min:-10,max:12},cms=[...new Map(task.inventoryCms.map(cm=>[cm.mac,cm])).values()],stats=rows=>{
      const values=rows.map(cm=>cm.pwrDs).filter(v=>typeof v==='number'&&Number.isFinite(v)&&v!==-99);
      const summarize=values=>{const min=values.length?Math.min(...values):null,max=values.length?Math.max(...values):null;return {total:rows.length,count:values.length,mean:values.length?Math.max(min,Math.min(max,values.reduce((a,b)=>a+b,0)/values.length)):null,min,max};};
      return {...summarize(values),within:summarize(values.filter(v=>v>=reference.min&&v<=reference.max))};
    },matches=(cm,s)=>cm.street.toUpperCase()===s.calle.toUpperCase()&&cm.block===s.inicioCuadra;
    return {node:stats(cms),selected:stats(cms.filter(cm=>selected.some(s=>matches(cm,s)))),blocks:selected.map(s=>({...s,stats:stats(cms.filter(cm=>matches(cm,s)))})),reference};
  }
  function compact(report,selected){
    if(!selected.length)return {frecuenciasDS:'',alcancesDS:[]};
    const levels=[['ALTO','Alto','Post ≥ 1e-5'],['MEDIO','Medio','1e-7 ≤ Post < 1e-5'],['BAJO','Bajo','1e-9 ≤ Post < 1e-7']],level=p=>p>=1e-5?0:p>=1e-7?1:2;
    const blocks=selected.map(s=>report.blocks.find(b=>b.street.toUpperCase()===s.calle.toUpperCase()&&b.block===s.inicioCuadra)||{street:s.calle,block:s.inicioCuadra,status:'no-coverage',frequencies:[]});
    const peak=f=>Math.max(0,...f.episodes.map(e=>e.peak)),all=new Map();
    for(const b of blocks)for(const f of b.frequencies)all.set(f.frequency,Math.max(all.get(f.frequency)||0,peak(f)));
    const groups=levels.map((_,i)=>[...all].filter(([,p])=>level(p)===i).map(([f])=>f).sort((a,b)=>+a- +b));
    const alcancesDS=blocks.map(b=>{
      let alcance;
      if(!b.frequencies.length)alcance=b.status==='no-match'?'Sin coincidencias observadas':'Sin cobertura temporal suficiente';
      else {const local=levels.filter((_,i)=>b.frequencies.some(f=>level(peak(f))===i)).map(entry=>entry[0]);alcance=local.length>1?local.slice(0,-1).join(', ')+' y '+local.at(-1):local[0];}
      return {calle:b.street,inicioCuadra:b.block,alcance};
    });
    const lines=['FRECUENCIA/S CON FEC DS:',all.size+' de '+(report.total+(report.failed||0))+' frecuencias analizadas con coincidencias DS FEC Post.'];
    if(all.size){lines.push('','Máximo nivel coincidente — frecuencias en MHz:');for(let i=0;i<levels.length;i++)if(groups[i].length){lines.push('',levels[i][0]+' — '+levels[i][2]+':');for(let n=0;n<groups[i].length;n+=9)lines.push(groups[i].slice(n,n+9).join(', ')+(n+9>=groups[i].length?'.':','));}
    }
    if(report.failed)lines.push('','Análisis parcial: '+report.failed+' frecuencias sin datos verificables.');
    lines.push('','Cada cuadra indica sus niveles detectados.','Las frecuencias se agrupan por su máximo nivel entre las cuadras seleccionadas.','No implica afectación continua ni simultánea.');
    return {frecuenciasDS:lines.join('\n'),alcancesDS};
  }
  function template(report,selected){return compact(report,selected).frecuenciasDS;}
  function clientRelations(task,row,frequencies){return compare({...task,results:[row]},frequencies).blocks.flatMap(b=>b.frequencies).sort((a,b)=>b.episodes.length-a.episodes.length||+a.frequency- +b.frequency);}
  const api={parse,compare,template,compact,date,cadence,clientRelations,powerSummary};
  if(typeof module==='object'&&module.exports){module.exports=api;return;}
  if(location.hostname!=='mira5-gdt.telecentro.net.ar'||window.__VIENA_FREQUENCY_DS__)return;
  const states=new WeakMap();let active=null;const charts=new Set(),pendingOpens=new Map();
  const el=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
  function inventory(node){
    const expected=document.querySelector('#TAB-NODOCMTS-DESC .mira-element-selected')?.textContent.trim();if(expected!==node)return [];
    const links=[...document.querySelectorAll('#TAB-NODOCMTS-DESC .mira-getChartFrec')].filter(a=>a.getAttribute('tipo')==='DS'&&a.getAttribute('tipoelemento')==='nodoCmts'&&a.getAttribute('elemento')===node);
    if(!links.length||links.some(a=>!/^\d+(?:\.\d+)?$/.test(a.getAttribute('frec')||'')))return [];
    return [...new Set(links.map(a=>a.getAttribute('frec')))].sort((a,b)=>+a- +b);
  }
  function clear(task){if(viewer?.task===task)closeViewer(false);const state=task&&states.get(task);if(state?.controller)state.controller.abort();if(task)states.delete(task);if(active===task)active=null;for(const chart of charts)try{chart.destroy();}catch{}charts.clear();for(const close of pendingOpens.values())close();}
  function stateFor(task){let state=states.get(task);const signature=JSON.stringify([task.source.node,task.source.samples,task.source.frequencies]);if(state&&state.signature!==signature){clear(task);state=null;}if(!state){state={signature,running:false,done:false,failed:0,results:[],message:'',controller:null};states.set(task,state);}return state;}
  function report(task){const state=stateFor(task);if(!state.done)return null;const revision=task.filterRevision||0;if(!state.report||state.reportRevision!==revision){state.report={...compare(task,state.results),failed:state.failed};state.reportRevision=revision;}return state.report;}
  function bindUi(state,node,update){if(!state.ui)state.ui=new Map();for(const old of state.ui.keys())if(!old.isConnected)state.ui.delete(old);state.ui.set(node,update);update();}
  function refreshUi(state,refresh){const updates=[];for(const [node,update]of state.ui||[]){if(node.isConnected)updates.push({node,update,height:node.getBoundingClientRect().height});else state.ui.delete(node);}for(const {node,update,height}of updates){node.style.boxSizing='border-box';node.style.minHeight=height+'px';update();}if(!updates.length)refresh();}
  async function scan(task,refresh){
    const state=stateFor(task);if(state.running)return;const frequencies=task.source.frequencies;if(!Array.isArray(frequencies)||!frequencies.length||frequencies.length>512||new Set(frequencies).size!==frequencies.length){state.message='Abrí Frecuencias en Estadísticas del mismo nodo para obtener su listado DS.';refreshUi(state,refresh);return;}
    active=task;state.running=true;state.done=false;state.failed=0;state.results=[];state.report=null;state.relations=null;state.controller=new AbortController();
    try{
      for(const frequency of frequencies){
        if(state.controller.signal.aborted)throw Error('cancelled');state.message='Analizando frecuencias DS: '+(state.results.length+state.failed)+' / '+frequencies.length+'…';refreshUi(state,refresh);
        const timeout=new AbortController(),abort=()=>timeout.abort(),timer=setTimeout(abort,20000);state.controller.signal.addEventListener('abort',abort,{once:true});
        try{
          if(!/^\d+(?:\.\d+)?$/.test(frequency))throw Error('frequency-id');
          const url=new URL(task.source.frequencyEndpoint,location.href);if(url.origin!==location.origin||url.pathname!=='/tabs/stats_tab_grafico_frec.php')throw Error('frequency-url');
          for(const [key,value]of Object.entries({tipo:'DS',tipoElemento:'nodoCmts',elemento:task.source.node,frec:frequency,diasatras:1.99,fechadesde:'',fechahasta:''}))url.searchParams.set(key,value);
          const response=await fetch(url,{credentials:'same-origin',signal:timeout.signal});if(!response.ok||response.redirected)throw Error('frequency-response');const html=await response.text();if(state.controller.signal.aborted)throw Error('cancelled');state.results.push(parse(html,task.source.node,frequency));
        }catch(error){if(state.controller.signal.aborted)throw error;state.failed++;}
        finally{clearTimeout(timer);state.controller.signal.removeEventListener('abort',abort);}
      }
      state.done=true;state.message='';
    }catch(error){state.message='Análisis detenido. Volvé a analizar para obtener un resultado completo.';}
    finally{state.running=false;if(states.get(task)===state){if(active===task)active=null;refreshUi(state,refresh);}}
  }
  function autoStart(task,refresh){
    if(!task.done||task.cancelled)return;const state=stateFor(task);if(state.running||state.done||state.autoStarted)return;state.autoStarted=true;return scan(task,refresh);
  }
  function toolbar(parent,task,refresh){
    const state=stateFor(task),box=el('div'),button=el('button'),text=el('span');button.type='button';button.onclick=()=>state.running?state.controller.abort():scan(task,refresh);box.className='vcm-frequency-toolbar';box.append(button,text);parent.append(box);
    bindUi(state,box,()=>{button.textContent=state.running?'Detener análisis DS':state.done?'Volver a analizar frecuencias DS':'Analizar frecuencias DS';
      if(state.message)text.textContent=state.message;else if(state.done){const r=report(task),matched=new Set(r.blocks.flatMap(b=>b.frequencies.map(f=>f.frequency)));text.textContent=r.total+' frecuencias con historial · '+r.affected+' con errores · '+matched.size+' con coincidencias'+(state.failed?' · '+state.failed+' sin datos verificables':'');}
      else text.textContent='Compara todas las frecuencias DS disponibles · máximo 1,99 días.';});
  }
  function destroyWithin(parent){if(viewer&&parent.contains(viewer.opener))closeViewer(false);for(const chart of charts)if(parent.contains(chart.renderTo)){try{chart.destroy();}catch{}charts.delete(chart);}for(const [button,close]of pendingOpens)if(parent.contains(button))close();}
  function openNative(button,task,frequency){
    if(pendingOpens.has(button))return;if(!task.source.frequencyPublisher){button.textContent='Abrí Estadísticas del nodo para ver el gráfico nativo.';return;}
    let channel;try{channel=new BroadcastChannel('viena-mira-post-ds-qam-v1');}catch{return;}
    const client=crypto.randomUUID(),requestId=crypto.randomUUID();let timer;
    const close=()=>{clearTimeout(timer);channel.close();pendingOpens.delete(button);button.disabled=false;};pendingOpens.set(button,close);button.disabled=true;
    timer=setTimeout(()=>{button.textContent='Estadísticas no respondió. Reintentar gráfico nativo';close();},5000);
    channel.onmessage=event=>{const m=event.data;if(m?.type!=='frequency-open-result'||m.target!==client||m.requestId!==requestId)return;button.textContent=m.ok?'Gráfico abierto en la pestaña Estadísticas':'Cambió el nodo. Actualizá el período de Estadísticas.';close();};
    channel.postMessage({type:'frequency-open',publisher:task.source.frequencyPublisher,node:task.source.node,frequency,client,requestId});
  }
  let viewer=null;
  function relationsFor(task,row){
    const state=stateFor(task);if(!state.done)return null;
    const revision=task.filterRevision||0;if(!state.relations||state.relationsRevision!==revision){state.relations=new WeakMap();state.relationsRevision=revision;}
    let cached=state.relations.get(row);if(!cached||cached.match!==row.match){cached={match:row.match,items:clientRelations(task,row,state.results)};state.relations.set(row,cached);}return cached.items;
  }
  function installViewerStyle(){
    if(document.querySelector('[data-viena-frequency-viewer-style]'))return;const style=el('style');style.dataset.vienaFrequencyViewerStyle='';style.textContent=`
      .vcm-frequency-viewer .vcm-building-id{overflow-wrap:anywhere}
      .vcm-frequency-summary{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:8px;padding-top:8px;border-top:1px solid #e4ebf2}.vcm-frequency-summary p{margin:3px 0;font-size:12px}.vcm-frequency-summary button{flex:none}
      .vcm-frequency-viewer{position:fixed;inset:0;z-index:2147483645;display:flex;align-items:center;justify-content:center;padding:12px;background:rgba(15,23,42,.55);font:14px/1.4 Arial,sans-serif;color:#18344e;box-sizing:border-box}
      .vcm-frequency-viewer *{box-sizing:border-box}.vcm-frequency-dialog{display:flex;flex-direction:column;width:min(1600px,96vw);max-height:94vh;min-height:0;background:#fff;border:1px solid #b5c9df;border-top:4px solid #f99c2e;border-radius:6px;box-shadow:0 12px 38px #0005;overflow:hidden}
      .vcm-frequency-viewer button{font:inherit;cursor:pointer;border:1px solid #b5c9df;border-radius:4px;background:#fff;color:#245b88;padding:7px 11px}.vcm-frequency-viewer button:disabled{opacity:.5;cursor:default}.vcm-frequency-viewer button:focus-visible{outline:2px solid #236aab;outline-offset:2px}
      .vcm-frequency-head{display:flex;align-items:flex-start;gap:12px;justify-content:space-between;padding:12px 16px;border-bottom:1px solid #dbe5ef}.vcm-frequency-head h2{font:700 20px/1.3 Arial;margin:0 0 5px}.vcm-frequency-head p{margin:0;color:#526579;font-size:12px}.vcm-frequency-close{font-size:22px!important;line-height:1!important}
      .vcm-frequency-scroll{overflow:auto;overscroll-behavior:contain;padding:12px 16px;min-height:0}.vcm-frequency-chart-card{border:1px solid #cad9e6;border-radius:5px;padding:10px;min-width:0;background:#fff}.vcm-frequency-chart-card h3{font:700 15px Arial;margin:0 0 4px}.vcm-frequency-chart-card p{font-size:12px;color:#526579;margin:3px 0 7px}.vcm-frequency-viewer [data-frequency-cm]{width:calc((100% - 10px)/2);margin-inline:auto}.vcm-frequency-native-chart{width:100%;min-width:0}.vcm-frequency-native-chart .highcharts-title{font-family:'Times New Roman',serif;font-size:18px;font-weight:normal}
      .vcm-frequency-viewer-tools{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin:10px 0}.vcm-frequency-viewer-tools p{margin:0;font-size:12px;color:#526579}.vcm-frequency-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.vcm-frequency-bottom{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;padding:9px 16px;border-top:1px solid #dbe5ef;background:#f8fafc}.vcm-frequency-pager{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:10px}.vcm-frequency-viewer-note{font-size:12px;color:#526579;margin:8px 0 0}
      html[data-viena-theme="dark"] .vcm-frequency-dialog,html[data-viena-theme="dark"] .vcm-frequency-chart-card{background:#24282d;color:#f2ece1;border-color:#526579}html[data-viena-theme="dark"] .vcm-frequency-bottom{background:#30363d}html[data-viena-theme="dark"] .vcm-frequency-viewer p{color:#c3ccd6}html[data-viena-theme="dark"] .vcm-frequency-viewer button{background:#30363d;color:#dae7f6;border-color:#66778b}
      @media(max-width:700px){.vcm-frequency-viewer{padding:5px}.vcm-frequency-dialog{width:100%;max-height:98vh}.vcm-frequency-head,.vcm-frequency-scroll{padding:9px}.vcm-frequency-head h2{font-size:17px}.vcm-frequency-grid{grid-template-columns:1fr}.vcm-frequency-viewer [data-frequency-cm]{width:100%}.vcm-frequency-bottom{padding:8px}.vcm-frequency-chart-card{padding:7px}.vcm-frequency-summary{flex-wrap:wrap}}
    `;document.head.append(style);
  }
  function cardSummary(parent,task,row){
    installViewerStyle();const box=el('div'),text=el('div'),button=el('button','Comparar');let previous;box.className='vcm-frequency-summary';button.type='button';button.dataset.frequencyCompare=row.cm.mac;
    button.onclick=()=>openViewer(task,row,button);box.append(text,button);parent.append(box);
    bindUi(stateFor(task),box,()=>{const items=relationsFor(task,row);if(items===previous)return;previous=items;
      text.replaceChildren(el('strong',items?items.length+(items.length===1?' frecuencia con coincidencias':' frecuencias con coincidencias'):'Frecuencias DS pendientes de análisis'));
      const episodes=items?.flatMap(f=>f.episodes)||[],last=episodes.reduce((a,b)=>!a||b.end>a.end?b:a,null);if(last)text.append(el('p','Último episodio: '+label(last.start)+(last.end!==last.start?' → '+label(last.end):'')));
      button.disabled=!items?.length||!row.nativeOptions;button.title=!row.nativeOptions?'Gráfico nativo del CM no disponible':!items?'Primero analizá las frecuencias DS':!items.length?'No hay coincidencias verificadas para este CM':'Comparar este CM con sus frecuencias';});
  }
  function closeViewer(restore=true){
    const current=viewer;if(!current)return;viewer=null;document.removeEventListener('keydown',current.keydown,true);window.removeEventListener('resize',current.resize);if(current.resizeFrame)cancelAnimationFrame(current.resizeFrame);destroyWithin(current.overlay);current.overlay.remove();document.body.style.overflow=current.overflow;
    if(restore&&current.opener?.isConnected){current.opener.focus({preventScroll:true});window.scrollTo({left:current.x,top:current.y,behavior:'instant'});}
  }
  function indexAt(stamps,stamp){
    if(!stamps.length)return 0;let lo=0,hi=stamps.length;while(lo<hi){const mid=(lo+hi)>>1;if(stamps[mid]<stamp)lo=mid+1;else hi=mid;}if(lo===0)return 0;if(lo===stamps.length)return lo-1;return lo-1+(stamp-stamps[lo-1])/(stamps[lo]-stamps[lo-1]);
  }
  function stampAt(stamps,index){const p=Math.max(0,Math.min(stamps.length-1,index)),lo=Math.floor(p),hi=Math.ceil(p);return stamps[lo]+(stamps[hi]-stamps[lo])*(p-lo);}
  function openViewer(task,row,opener){
    const items=relationsFor(task,row);if(!items?.length||!row.nativeOptions)return;if(viewer?.task===task&&viewer.row===row){viewer.close.focus();return;}closeViewer(false);installViewerStyle();
    const r=report(task),from=Math.max(r.from,row.points[0]?.stamp??Infinity,task.source.samples[0].stamp),to=Math.min(r.end,row.points.at(-1)?.stamp??-Infinity,task.source.samples.at(-1).stamp);if(!Number.isFinite(from)||from>to)return;
    const overlay=el('div'),dialog=el('section'),head=el('header'),heading=el('div'),title=el('h2','Comparar · '+row.cm.street+' '+(row.cm.height??row.cm.block)),subtitle=el('p','CM: período elegido · Frecuencias DS: 1,99 días'),close=el('button','×');
    overlay.className='vcm-frequency-viewer';overlay.dataset.vienaFrequencyViewer='';dialog.className='vcm-frequency-dialog';dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');title.id='viena-frequency-viewer-title';dialog.setAttribute('aria-labelledby',title.id);head.className='vcm-frequency-head';close.className='vcm-frequency-close';close.type='button';close.setAttribute('aria-label','Cerrar comparación');close.onclick=()=>closeViewer();heading.append(title);if(row.cm.buildingId!=null){const building=el('p','ID EDIFICIO: '+row.cm.buildingId);building.className='vcm-building-id';heading.append(building);}heading.append(subtitle);head.append(heading,close);dialog.append(head);
    const scroll=el('div'),tools=el('div'),mode=el('button','Ver período completo del CM'),cursorLabel=el('p','Vista: tramo común · señalá un horario para compararlo'),root=el('div');scroll.className='vcm-frequency-scroll';tools.className='vcm-frequency-viewer-tools';mode.type='button';mode.dataset.frequencyFull='';tools.append(cursorLabel,mode);scroll.append(tools,root);dialog.append(scroll);
    const bottom=el('footer'),pager=el('div'),previous=el('button','← Anterior'),pageText=el('span'),next=el('button','Siguiente →'),done=el('button','Cerrar');bottom.className='vcm-frequency-bottom';pager.className='vcm-frequency-pager';pageText.setAttribute('aria-live','polite');pageText.dataset.frequencyPage='';for(const b of [previous,next,done])b.type='button';previous.setAttribute('aria-label','Frecuencias anteriores');next.setAttribute('aria-label','Frecuencias siguientes');done.onclick=()=>closeViewer();pager.append(previous,pageText,next);bottom.append(pager,done);dialog.append(bottom);overlay.append(dialog);
    const current={task,row,opener,overlay,close,overflow:document.body.style.overflow,x:scrollX,y:scrollY,page:0,size:innerWidth<=700?2:4,full:false,range:[from,to],entries:[],resizeFrame:0};viewer=current;
    function draw(){
      if(viewer!==current)return;const oldScroll=scroll.scrollTop;destroyWithin(root);current.entries=[];root.replaceChildren();current.page=Math.max(0,Math.min(current.page,Math.ceil(items.length/current.size)-1));
      const cmCard=el('section'),cmTitle=el('h3','CM seleccionado · '+row.cm.street+' '+(row.cm.height??row.cm.block));cmCard.className='vcm-frequency-chart-card';cmCard.dataset.frequencyCm='';cmCard.append(cmTitle);if(row.cm.buildingId!=null){const building=el('p','ID EDIFICIO: '+row.cm.buildingId);building.className='vcm-building-id';cmCard.append(building);}root.append(cmCard);
      const caption=el('div'),count=el('strong','Frecuencias con coincidencias · '+items.length);caption.className='vcm-frequency-viewer-tools';caption.append(count,el('p','Ordenadas por episodios coincidentes'));root.append(caption);const grid=el('div');grid.className='vcm-frequency-grid';root.append(grid);
      function pointCursor(stamp){
        if(viewer!==current)return;cursorLabel.textContent='Horario señalado: '+label(stamp);for(const entry of current.entries){const axis=entry.chart.xAxis[0];axis.removePlotLine('frequency-cursor');const p=nearest(entry.stamps.map(stamp=>({stamp})),stamp,Math.min(cadence(entry.stamps.map(stamp=>({stamp})))/2,5*60000));if(p&&stamp>=entry.stamps[0]&&stamp<=entry.stamps.at(-1))axis.addPlotLine({id:'frequency-cursor',value:indexAt(entry.stamps,p.stamp),color:'#667085',width:1,zIndex:5});}
      }
      function makeChart(parent,source,isCm,episodes){
        const canvas=el('div');canvas.className='vcm-frequency-native-chart';parent.append(canvas);if(!source||!window.Highcharts?.chart){canvas.textContent='Gráfico nativo no disponible. Volvé a analizar.';return;}
        try{
          const options=JSON.parse(JSON.stringify(source)),axis=Array.isArray(options.xAxis)?options.xAxis[0]:options.xAxis,stamps=(axis?.categories||[]).map(date);if(!axis||!stamps.length||stamps.some(t=>t===null))throw Error('native-dates');
          const selected=isCm&&current.full?[stamps[0],stamps.at(-1)]:current.range;axis.min=indexAt(stamps,selected[0]);axis.max=indexAt(stamps,selected[1]);if(axis.min===axis.max)axis.max=axis.min+1;
          axis.plotBands=[...(axis.plotBands||[]),...episodes.filter(ep=>ep.end>ep.start).map(ep=>({from:indexAt(stamps,ep.start),to:indexAt(stamps,ep.end),color:'#fff0d533'}))];
          axis.plotLines=[...(axis.plotLines||[]),...episodes.filter(ep=>ep.end===ep.start&&ep.start>=stamps[0]&&ep.start<=stamps.at(-1)).map(ep=>({value:indexAt(stamps,ep.start),color:'#f99c2e55',width:1,zIndex:1}))];
          const original=axis.events?.setExtremes;axis.events={...axis.events,setExtremes:function(e){if(typeof original==='function')original.call(this,e);if(e.trigger==='viena-frequency-viewer'||viewer!==current)return;const range=Number.isFinite(e.min)&&Number.isFinite(e.max)?[stampAt(stamps,e.min),stampAt(stamps,e.max)]:[from,to];if(isCm&&current.full)return;current.range=range;for(const entry of current.entries)if(entry.chart.xAxis[0]!==this&&!(current.full&&entry.isCm)){entry.chart.xAxis[0].setExtremes(indexAt(entry.stamps,range[0]),indexAt(entry.stamps,range[1]),true,false,{trigger:'viena-frequency-viewer'});}}};
          options.chart={...options.chart,height:isCm?275:240,animation:false,zoomType:'x'};delete options.chart.renderTo;const over=options.plotOptions?.series?.point?.events?.mouseOver;options.plotOptions={...options.plotOptions,series:{...options.plotOptions?.series,animation:false,point:{...options.plotOptions?.series?.point,events:{...options.plotOptions?.series?.point?.events,mouseOver:function(e){if(typeof over==='function')over.call(this,e);const stamp=stamps[this.x];if(Number.isFinite(stamp))pointCursor(stamp);}}}}};native.hydrate(options);
          const chart=window.Highcharts.chart(canvas,options);charts.add(chart);current.entries.push({chart,stamps,isCm});
        }catch{canvas.textContent='No se pudo mostrar el gráfico nativo. Cerrá y reintentá.';}
      }
      const allEpisodes=items.flatMap(f=>f.episodes);makeChart(cmCard,row.nativeOptions,true,allEpisodes);
      for(const f of items.slice(current.page*current.size,(current.page+1)*current.size)){const card=el('section'),last=f.episodes.reduce((a,b)=>!a||b.end>a.end?b:a,null);card.className='vcm-frequency-chart-card';card.dataset.frequency=f.frequency;card.append(el('h3',f.frequency+' MHz'),el('p',f.episodes.length+' episodios · último: '+label(last.start)+(last.end!==last.start?' → '+label(last.end):'')));grid.append(card);makeChart(card,f.nativeOptions,false,f.episodes);const action=el('button','Abrir gráfico nativo en Estadísticas');action.type='button';action.dataset.frequencyNative=f.frequency;action.onclick=()=>openNative(action,task,f.frequency);card.append(action);const times=el('details'),summary=el('summary','Ver horarios coincidentes'),list=el('ul');times.append(summary,list);for(const ep of f.episodes)list.append(el('li',label(ep.start)+(ep.end!==ep.start?' - '+label(ep.end):'')));card.append(times);}
      const note=el('p','Coincidencias temporales de Post FEC DS; no confirman por sí solas la causa ni el canal asignado a cada CM.');note.className='vcm-frequency-viewer-note';root.append(note);previous.disabled=current.page===0;next.disabled=(current.page+1)*current.size>=items.length;pageText.textContent=(current.page+1)+' de '+Math.ceil(items.length/current.size)+' · '+Math.min(current.size,items.length-current.page*current.size)+' de '+items.length+' frecuencias';scroll.scrollTop=oldScroll;
    }
    previous.onclick=()=>{current.page--;draw();};next.onclick=()=>{current.page++;draw();};mode.onclick=()=>{current.full=!current.full;mode.textContent=current.full?'Volver al tramo común':'Ver período completo del CM';cursorLabel.textContent=current.full?'CM: período completo · DS: tramo disponible':'Vista: tramo común';if(!current.full)current.range=[from,to];draw();};
    current.keydown=e=>{if(viewer!==current)return;if(e.key==='Escape'&&!e.target.closest?.('.highcharts-contextmenu')){e.preventDefault();e.stopPropagation();closeViewer();}else if(e.key==='Tab'){const focusable=[...dialog.querySelectorAll('button:not(:disabled),[tabindex="0"]')].filter(n=>n.getClientRects().length);const first=focusable[0],last=focusable.at(-1);if(e.shiftKey&&(document.activeElement===first||!dialog.contains(document.activeElement))){e.preventDefault();last?.focus();}else if(!e.shiftKey&&(document.activeElement===last||!dialog.contains(document.activeElement))){e.preventDefault();first?.focus();}}};
    current.resize=()=>{if(current.resizeFrame)return;current.resizeFrame=requestAnimationFrame(()=>{current.resizeFrame=0;if(viewer!==current)return;const size=innerWidth<=700?2:4;if(size!==current.size){current.page=Math.floor(current.page*current.size/size);current.size=size;draw();}});};document.body.append(overlay);document.body.style.overflow='hidden';document.addEventListener('keydown',current.keydown,true);window.addEventListener('resize',current.resize);draw();close.focus({preventScroll:true});
  }
  window.__VIENA_FREQUENCY_DS__= {...api,inventory,clear,toolbar,autoStart,cardSummary,openViewer,closeViewer,report,destroyWithin,selectionFor(task,selected,rows){const state=stateFor(task),r=rows&&state.done?{...compare({...task,results:rows},state.results),failed:state.failed}:report(task);return {...(r?compact(r,selected):{}),pwrDS:powerSummary(task,selected)};},templateFor(task,selected,rows){const state=stateFor(task),r=rows&&state.done?{...compare({...task,results:rows},state.results),failed:state.failed}:report(task);return r?template(r,selected):'';}};
  window.addEventListener('pagehide',()=>{closeViewer(false);if(active)clear(active);for(const chart of charts)try{chart.destroy();}catch{}charts.clear();for(const close of pendingOpens.values())close();});
})();
