(() => {
    'use strict';
    const origin='https://grafana-telemetria.telecentro.net.ar',uid='e1239f9e-a168-4843-963c-15681c84fe47';
    const dashboardPath='/d/'+uid+'/966718b3-44f9-56c1-9412-ccaf6599ff9e';
    let active=null;
    const duration=text=>{const m=String(text||'').match(/^(\d+(?:\.\d+)?)(ms|s|m|h|d|w)$/);return m?Number(m[1])*({ms:.001,s:1,m:60,h:3600,d:86400,w:604800}[m[2]]):null;};
    const regex=text=>{
        text=String(text||'');if(text.length>2000)throw Error('regex');
        const end=text.startsWith('/')?text.lastIndexOf('/'):0;
        return end>0?new RegExp(text.slice(1,end),text.slice(end+1).replace(/[gy]/g,'')):new RegExp(text);
    };
    function bootSources(html){
        const boot=html.search(/(?:window\.)?grafanaBootData\s*=/);
        const match=boot>=0?/\bsettings\s*:\s*\{/.exec(html.slice(boot)):null;
        if(!match)throw Error('boot');
        const start=boot+match.index+match[0].lastIndexOf('{');let depth=0,quoted=false,escaped=false;
        for(let i=start;i<html.length;i++){
            const ch=html[i];
            if(quoted){if(escaped)escaped=false;else if(ch==='\\')escaped=true;else if(ch==='"')quoted=false;}
            else if(ch==='"')quoted=true;
            else if(ch==='{')depth++;
            else if(ch==='}'&&!--depth){const settings=JSON.parse(html.slice(start,i+1));return Object.values(settings.datasources||{});}
        }
        throw Error('boot');
    }
    async function perform(node,cos,controller){
        let stage='identity',lastStatus=null,endpoint=null,pointDetail=null;const signal=controller.signal;
        const live=()=>{if(signal.aborted)throw Error('cancelled');};
        const request=async(path,params={},json=true,budget=12000)=>{
            live();const url=new URL(path,origin);if(url.origin!==origin||url.username||url.password)throw Error('origin');
            endpoint=path.startsWith('/api/dashboards/')?'dashboard':path.startsWith('/d/')?'boot':path.endsWith('/query_range')?'query-range':path.endsWith('/query')?'query':path.includes('/label/')?'label-values':'other';
            for(const [key,value] of Object.entries(params))url.searchParams.set(key,String(value));
            const local=new AbortController(),cancel=()=>local.abort();signal.addEventListener('abort',cancel,{once:true});
            const timer=setTimeout(cancel,budget);
            try{
                const response=await fetch(url.href,{method:'GET',credentials:'include',redirect:'manual',cache:'no-store',signal:local.signal});live();lastStatus=response.status;
                if([401,403].includes(response.status)||response.redirected||response.type==='opaqueredirect'||response.status>=300&&response.status<400){stage='session';throw Error('access');}
                if(!response.ok)throw Error('http');
                const text=await response.text();live();if(text.length>16000000)throw Error('size');
                return json?JSON.parse(text):text;
            }finally{clearTimeout(timer);signal.removeEventListener('abort',cancel);}
        };
        try{
            if(!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(node)||!cos||cos.length>100||/[\r\n"\\]/.test(cos))throw Error('identity');
            stage='dashboard';const model=(await request('/api/dashboards/uid/'+uid))?.dashboard;
            if(model?.uid!==uid||!Array.isArray(model.templating?.list)||!Array.isArray(model.panels))throw Error('dashboard');
            if(model.time?.to!=='now'||!String(model.time?.from||'').startsWith('now-'))throw Error('time');
            const seconds=duration(model.time.from.slice(4));if(!seconds||seconds>604800)throw Error('time');
            const end=Math.floor(Date.now()/1000),start=end-seconds,values={__range:seconds+'s',__range_s:String(seconds),__from:String(start*1000),__to:String(end*1000)};
            stage='datasource';const sources=bootSources(await request(dashboardPath+'?orgId=1',{},false));
            const variables=new Map(model.templating.list.map(v=>[v.name,v])),resolving=new Set(),cache=new Map();
            const interpolate=(text,query=false)=>String(text||'').replace(/\$(?:\{(\w+)(?::([^}]+))?\}|(\w+))|\[\[(\w+)(?::[^\]]*)?\]\]/g,(token,a,format,b,c,offset,whole)=>{
                const key=a||b||c;if(!Object.hasOwn(values,key))throw Error('unresolved');
                let value=String(values[key]);if(/[\r\n]/.test(value)||value.length>250)throw Error('value');
                if(query){
                    // Match native single-value interpolation while escaping
                    // selector regex metacharacters and PromQL string literals.
                    const before=whole.slice(0,offset),quoted=before.match(/(=~|!~|=|!=)"([^"\\]|\\.)*$/);
                    if(quoted&&['=~','!~'].includes(quoted[1])&&format!=='raw')value=value.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
                    if(quoted)value=JSON.stringify(value).slice(1,-1);
                }
                return value;
            });
            const sourceFor=ref=>{
                const id=interpolate(typeof ref==='string'?ref:ref?.uid),matches=sources.filter(s=>s.uid===id&&['prometheus','victoriametrics-metrics-datasource'].includes(s.type));
                if(matches.length!==1)throw Error('datasource');const source=matches[0],url=new URL(source.url,origin);
                if(url.origin!==origin||url.pathname!=='/api/datasources/proxy/uid/'+encodeURIComponent(source.uid)||url.search||url.hash)throw Error('proxy');
                return url.pathname;
            };
            const api=async(source,path,params,budget)=>{
                const result=await request(source+path,params,true,budget);
                if(result?.status!=='success'||result.warnings?.length||result.isPartial===true)throw Error('response');return result.data;
            };
            const resolve=async name=>{
                if(Object.hasOwn(values,name))return values[name];
                if(resolving.has(name))throw Error('cycle');const v=variables.get(name);if(!v||v.multi||v.includeAll)throw Error('variable');
                resolving.add(name);
                try{
                    if(v.type==='datasource'){
                        const candidates=sources.filter(s=>s.type===v.query&&regex(v.regex||'.*').test(s.name));
                        if(candidates.length!==1)throw Error('datasource');values[name]=candidates[0].uid;return values[name];
                    }
                    if(v.type==='constant'){const val=v.query;if(typeof val!=='string'||!val)throw Error('constant');values[name]=val;return val;}
                    if(v.type!=='query')throw Error('variable');
                    const raw=typeof v.query==='string'?v.query:v.query?.query;if(typeof raw!=='string'||raw.length>30000)throw Error('query');
                    const deps=[...JSON.stringify({query:raw,source:v.datasource}).matchAll(/\$(?:\{(\w+)(?::[^}]+)?\}|(\w+))/g)].map(m=>m[1]||m[2]);
                    for(const dep of new Set(deps))await resolve(dep);
                    const query=interpolate(raw,true),source=sourceFor(v.datasource);let options;
                    if(query.startsWith('query_result(')&&query.endsWith(')')){
                        const result=await api(source,'/api/v1/query',{query:query.slice(13,-1),time:end});
                        if(result?.resultType!=='vector'||!Array.isArray(result.result)||result.result.length>10000)throw Error('vector');
                        options=result.result.map(row=>{
                            if(!row.metric||!Array.isArray(row.value))throw Error('vector');
                            const labels=Object.entries(row.metric).filter(([key])=>key!=='__name__').map(([key,val])=>key+'='+JSON.stringify(String(val))).join(',');
                            return (row.metric.__name__||'')+'{'+labels+'} '+row.value[1]+' '+Number(row.value[0])*1000;
                        });
                    }else{
                        const match=/^label_values\((.+),\s*([a-zA-Z_][a-zA-Z0-9_]*)\)$/.exec(query);if(!match)throw Error('variable-query');
                        // Native label-values API returns unique label strings.
                        // /series enumerates every metric of a node and can be
                        // huge even when this variable has exactly one value.
                        const key=source+'|'+query;options=cache.get(key);
                        if(!options){options=await api(source,'/api/v1/label/'+match[2]+'/values',{'match[]':match[1],start,end});if(!Array.isArray(options)||options.length>10000||options.some(v=>typeof v!=='string'))throw Error('label-values');cache.set(key,options);}
                    }
                    options=options.flatMap(option=>{if(!v.regex)return [option];const found=regex(v.regex).exec(option);return found?[found.groups?.value??found[1]??found[0]]:[];});
                    options=[...new Set(options)];const desired=name==='cluster'?cos:['rpd','nodo'].includes(name)?node:null;
                    if(desired!==null){if(!options.includes(desired))throw Error('identity');values[name]=desired;}
                    else{if(options.length!==1)throw Error('ambiguous');values[name]=options[0];}
                    return values[name];
                }finally{resolving.delete(name);}
            };
            for(const name of ['cluster','rpd','nodo','interface','equipo','optics']){stage=name;await resolve(name);}
            if(values.cluster!==cos||values.rpd!==node||values.nodo!==node)throw Error('identity');
            const flatten=panels=>panels.flatMap(p=>[p,...flatten(p.panels||[])]),all=flatten(model.panels);
            const titles=['Potencia óptica '+values.equipo+' Interfaz '+values.interface+' hacia '+node,'Potencia óptica Rx / Tx RPD'];
            const lines=[];
            const panelLines=async(panel,title,budget=12000,cm=false)=>{
                if(!Array.isArray(panel.targets)||panel.targets.length>30||panel.transformations?.length)throw Error('panel');
                const out=[title],seen=new Set();
                const targets=panel.targets.filter(t=>!t.hide&&(!cm||/ - (?:partial|online)$/.test(t.legendFormat||''))).sort((a,b)=>cm?Number(!/partial$/.test(a.legendFormat))-Number(!/partial$/.test(b.legendFormat)):0);
                if(!targets.length)throw Error('targets');const deadline=Date.now()+budget;
                for(const target of targets){
                    live();if(Date.now()>=deadline)throw Error('timeout');
                    const step=Math.max(duration(panel.interval)||1,Math.ceil(seconds/(panel.maxDataPoints||1000)));values.__interval=step+'s';values.__interval_ms=String(step*1000);
                    // Native datasource createQuery aligns BOTH bounds with
                    // floor((time + utcOffset) / step) * step - utcOffset.
                    const offset=model.timezone==='utc'?0:-new Date(end*1000).getTimezoneOffset()*60;
                    const queryStart=Math.floor((start+offset)/step)*step-offset,queryEnd=Math.floor((end+offset)/step)*step-offset;
                    const expr=interpolate(target.expr,true),legend=interpolate(target.legendFormat||'');if(!expr||!legend||expr.includes('$'))throw Error('target');
                    const data=await api(sourceFor(target.datasource||panel.datasource),'/api/v1/query_range',{query:expr,start:queryStart,end:queryEnd,step},Math.min(12000,deadline-Date.now()));
                    if(data?.resultType!=='matrix'||!Array.isArray(data.result)||data.result.length>100)throw Error('matrix');
                    for(const series of data.result){
                        if(!series.metric||!Array.isArray(series.values)||series.values.length>20000||series.metric.rpdName&&series.metric.rpdName!==node||series.metric.cluster&&series.metric.cluster!==cos)throw Error('series');
                        const label=legend.replace(/\{\{\s*([^}]+?)\s*\}\}/g,(_m,key)=>{const val=series.metric[key];if(typeof val!=='string'||/[\r\n]/.test(val)||val.length>150)throw Error('label');return val;});
                        if(seen.has(label))throw Error('ambiguous');seen.add(label);
                        let last=null;
                        for(const point of series.values){
                            if(!Array.isArray(point)||point.length!==2){pointDetail={pointIssue:'shape'};throw Error('point');}
                            const time=Number(point[0]);if(point[0]===null||String(point[0]).trim()===''||!Number.isFinite(time)){pointDetail={pointIssue:'timestamp'};throw Error('point');}
                            if(time<queryStart||time>queryEnd){pointDetail={pointIssue:'range',pointBoundary:time<queryStart?'before-start':'after-end',pointOffsetSeconds:Math.max(-1000000,Math.min(1000000,Math.round(time-(time<queryStart?queryStart:queryEnd))))};throw Error('point');}
                            const n=point[1]===null||String(point[1]).trim()===''?NaN:Number(point[1]);if(Number.isFinite(n)&&(!last||time>=last.time))last={time,value:n};
                        }
                        if(last)out.push(label,String(last.value)+(cm?'':' dBm'));
                    }
                }
                return out;
            };
            stage='potencias';
            for(const title of titles){
                const panels=all.filter(p=>{
                    if(typeof p.title!=='string'||!p.title.startsWith('Potencia óptica '))return false;
                    try{return interpolate(p.title)===title;}catch(_){return false;}
                });
                if(panels.length!==1)throw Error('panel');lines.push(...await panelLines(panels[0],title));
            }
            if(!lines.some(line=>/ dBm$/.test(line)))throw Error('empty');
            const cm=all.filter(p=>p.title==='Estado CMs');let cmPartialStatus='unavailable';
            if(cm.length===1){try{lines.push(...await panelLines(cm[0],'Estado CMs',4000,true));cmPartialStatus='available';}catch(_){live();}}
            live();const href=new URL(dashboardPath,origin);for(const [key,value] of Object.entries({cluster:cos,rpd:node,nodo:node,equipo:values.equipo,interface:values.interface}))href.searchParams.set('var-'+key,value);
            return {href:href.href,text:lines.join('\n'),cmPartialStatus};
        }catch(error){
            const cancelled=signal.aborted;
            const reason=/^(?:identity|origin|access|http|size|time|boot|datasource|proxy|cycle|variable|constant|query|vector|variable-query|label-values|ambiguous|unresolved|value|panel|targets|timeout|target|matrix|series|label|point|empty|cancelled)$/.test(error?.message)?error.message:'network-or-format';
            return {failure:{stage,cancelled,needsSession:stage==='session',details:{transport:'native-api',httpStatus:lastStatus,endpoint,reason,...(pointDetail||{})},message:cancelled?'La consulta de Grafana fue reemplazada o venció.':stage==='session'?'Revisá el acceso a Grafana, iniciá sesión y volvé a Actualizar.':'Grafana no pudo completar '+({dashboard:'la lectura del dashboard',datasource:'la selección de origen',cluster:'el COS',rpd:'el nodo',nodo:'el nodo',interface:'la interfaz',equipo:'el equipo',optics:'el puerto óptico',potencias:'la consulta de potencias'}[stage]||'la consulta')+'.'}};
        }
    }
    globalThis.VienaGrafanaApi={read(node,cos){
        if(active?.node===node&&active.cos===cos)return active.promise;
        active?.controller.abort();const controller=new AbortController(),record={node,cos,controller};
        const timer=setTimeout(()=>controller.abort(),70000);active=record;
        record.promise=perform(node,cos,controller).finally(()=>{clearTimeout(timer);if(active===record)active=null;});return record.promise;
    }};
})();
