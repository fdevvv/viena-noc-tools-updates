// Worker-only wiring. It never alters registry identity or user configuration.
try{
  globalThis.VienaAccessClient=globalThis.VienaAccessPolicy.install(chrome,globalThis.VienaAccessConfig,async()=>{
    const saved=await chrome.storage.local.get([INSTALLATION_ID_KEY]);
    const user=await detectVienAUserFromOpenTab();
    return{installationId:String(saved[INSTALLATION_ID_KEY]||'').trim(),user:String(user||'').trim()};
  });
  chrome.runtime.onInstalled.addListener(async details=>{
    if(details?.reason!=='update'||!globalThis.VienaAccessConfig.enabled)return;
    const bounded=(promise,ms)=>{let timer;return Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('identity_recovery_timeout')),ms);})]).finally(()=>clearTimeout(timer));};
    try{
      const tabs=(await chrome.tabs.query({url:'https://viena.telecentro.net.ar/*'})).filter(tab=>tab.id&&/^https:\/\/viena\.telecentro\.net\.ar\//.test(tab.url||'')).sort((a,b)=>Number(!!b.active)-Number(!!a.active)||Number(b.lastAccessed||0)-Number(a.lastAccessed||0));
      let restored=false;
      // Bound startup work; never reload/navigate the operator's page or use history.
      for(const tab of tabs.slice(0,3)){
        try{await bounded(chrome.tabs.sendMessage(tab.id,{type:'VIENA_GET_DETECTED_USER'}),1200);}
        catch(error){
          if(!/Receiving end does not exist|Extension context invalidated/i.test(String(error?.message||error)))continue;
          try{await bounded(chrome.scripting.executeScript({target:{tabId:tab.id},files:['js/06-user-config.js']}),4000);restored=true;}catch(_){}
        }
      }
      if(restored)await globalThis.VienaAccessClient.check();
    }catch(_){/* An unavailable tab must not block startup or the popup. */}
  });
}catch(error){console.error('VIENA installation policy initialization failed',error);}
