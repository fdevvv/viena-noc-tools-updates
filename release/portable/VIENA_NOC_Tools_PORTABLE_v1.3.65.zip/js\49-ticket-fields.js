(() => {
    'use strict';
    if (globalThis.VienaTicketFields) return;
    const PREFIX = 'viena_ticket_field_visible_v1:';
    const BUTTON_PREFIX = 'viena_ticket_button_visible_v1:';
    const ORDER_PREFIX = 'viena_ticket_field_order_v1:';
    const BUTTON_ORDER_PREFIX = 'viena_ticket_button_order_v1:';
    const LAYOUT_PREFIX = 'viena_ticket_layout_v1:';
    const PANEL_PREFIX = 'viena_ticket_panel_position_v1:';
    const panelSlots = ['@panel:moica','@panel:ged','@panel:gec','@panel:gee'];
    // Explicit opt-in; absent or malformed values preserve the native dialog.
    const INTERNAL_VIEWER_KEY = 'viena_internal_ticket_viewer_enabled_v1';
    const internalViewerStorage = globalThis.chrome?.storage?.local;
    let internalViewerEnabled = false, internalViewerRevision = 0, internalViewerSaving = false;
    const buttonAttributes = new WeakMap();
    const states = new Map();
    let current = null;
    let watchedRoot = null;
    // Vue can replace fields or overwrite their classes between UI refreshes.
    // Reapply inside this ticket's mutation microtask, before the next paint.
    const ticketObserver = new MutationObserver(mutations => {
        if (!current) {
            // The ticket shell can be visible before Vue mounts its fields.
            if (mutations.some(mutation => mutation.target === watchedRoot || mutation.type !== 'attributes')) refresh();
            return;
        }
        const toolbar = current.bar.parentElement;
        const relevant = mutations.some(mutation => {
            const target = mutation.target.nodeType === 1 ? mutation.target : mutation.target.parentElement;
            if (mutation.type === 'attributes') return target === current.root || target === current.area
                || target.parentElement === current.area
                || target.parentElement?.parentElement === current.area
                || current.area.contains(target)
                || current.buttons?.some(item => item.button === target);
            if (target.closest?.('.viena-ticket-fields-bar,[data-viena-macro-ui],.viena-ticket-tools-host')) return false;
            return current.area.contains(target) || toolbar?.contains(target) || current.statusHeader?.contains(target)
                || [...mutation.removedNodes].some(node => node === current.area || node.contains?.(current.area));
        });
        if (relevant) refresh();
    });
    const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
    const key = (user, name) => name === '@layout' ? LAYOUT_PREFIX + encodeURIComponent(user)
        : panelSlots.includes(name) ? PANEL_PREFIX + encodeURIComponent(user) + ':' + name.slice(7)
        : name === '@order' ? ORDER_PREFIX + encodeURIComponent(user)
        : name === '@button-order' ? BUTTON_ORDER_PREFIX + encodeURIComponent(user)
        : (name.startsWith('@button:') ? BUTTON_PREFIX : PREFIX) + encodeURIComponent(user) + ':' + encodeURIComponent(name.startsWith('@button:') ? name.slice(8) : name);
    const bounded = promise => {
        let timer;
        return Promise.race([promise, new Promise((_, reject) => {
            timer = setTimeout(() => reject(new Error('storage timeout')), 2500);
        })]).finally(() => clearTimeout(timer));
    };
    function syncViewerOptions() {
        for (const input of document.querySelectorAll('[data-viena-internal-viewer-option]')) {
            input.checked = internalViewerEnabled;
            input.disabled = internalViewerSaving;
        }
    }
    function mountViewerOption(host) {
        if (host.querySelector('[data-viena-internal-viewer-option]')) return;
        ensureStyle();
        const label = document.createElement('label'), input = document.createElement('input'), status = document.createElement('span');
        label.className = 'viena-internal-viewer-toggle';
        label.style.cssText = host.querySelector('button')?.style.cssText || 'background:#1976d2;color:#fff;border:0;border-radius:6px;padding:11px 16px;font:700 13px Arial,sans-serif;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.25);';
        Object.assign(label.style, { display:'inline-flex', alignItems:'center', gap:'6px', flexWrap:'wrap', maxWidth:'100%' });
        input.type = 'checkbox'; input.setAttribute('data-viena-internal-viewer-option','');
        // The action bar is mounted while detached; document queries cannot see it yet.
        input.checked = internalViewerEnabled; input.disabled = internalViewerSaving;
        input.style.cssText = 'width:14px;height:14px;margin:0;accent-color:#1976d2;cursor:pointer;';
        status.setAttribute('data-viena-internal-viewer-status',''); status.setAttribute('role','status');
        label.append(input,document.createTextNode('Abrir tickets en visor ampliado'),status); host.append(label);
        syncViewerOptions();
        input.onchange = async () => {
            if (internalViewerSaving) return;
            const previous = internalViewerEnabled;
            internalViewerRevision++; internalViewerSaving = true;
            internalViewerEnabled = input.checked; status.textContent = ''; syncViewerOptions();
            try { await bounded(internalViewerStorage.set({ [INTERNAL_VIEWER_KEY]: internalViewerEnabled })); }
            catch (_) { internalViewerEnabled = previous; status.textContent = 'No se pudo guardar. Volvé a intentar.'; }
            finally { internalViewerSaving = false; syncViewerOptions(); refresh(); }
        };
    }
    const initialViewerRevision = internalViewerRevision;
    if (internalViewerStorage) void bounded(internalViewerStorage.get(INTERNAL_VIEWER_KEY)).then(values => {
        if (internalViewerRevision !== initialViewerRevision) return;
        internalViewerEnabled = values[INTERNAL_VIEWER_KEY] === true; syncViewerOptions(); refresh();
    }).catch(() => {});
    globalThis.chrome?.storage?.onChanged?.addListener((changes, area) => {
        if (area !== 'local' || !Object.hasOwn(changes, INTERNAL_VIEWER_KEY)) return;
        internalViewerRevision++;
        internalViewerEnabled = changes[INTERNAL_VIEWER_KEY].newValue === true; syncViewerOptions(); refresh();
    });
    function userName() {
        const value = clean(globalThis.VienaUserConfig?.detectar?.() || globalThis.VienaUserConfig?.current).toLowerCase();
        return /^[a-z][a-z0-9._-]{2,30}$/.test(value) ? value : '';
    }
    function visible(state, name) {
        const value = current?.state === state && Object.hasOwn(current.draft || {},name) ? current.draft[name] : state.values[name];
        return typeof value === 'boolean' ? value : true;
    }
    function read(state, names) {
        if (!state.user) return;
        const missing = names.filter(name => !state.loaded.has(name));
        if (!missing.length) return;
        missing.forEach(name => {
            state.loaded.add(name);
            try {
                const mirror = localStorage.getItem(key(state.user, name));
                if (mirror === 'true' || mirror === 'false') state.values[name] = mirror === 'true';
                else if ((name === '@order' || name === '@button-order') && mirror) { const order = JSON.parse(mirror); if (Array.isArray(order)) state.values[name] = order.filter(item => typeof item === 'string'); }
                else if (name === '@layout' && mirror) { const layout = JSON.parse(mirror); if (layout === 'cards' || layout === 'current') state.values[name] = layout; }
                else if (panelSlots.includes(name) && mirror) { const position = JSON.parse(mirror); if (position === 'left' || position === 'right') state.values[name] = position; }
            } catch (_) {}
        });
        void bounded(chrome.storage.local.get(missing.map(name => key(state.user, name))))
            .then(values => {
                for (const name of missing) {
                    if (state.changed.has(name)) continue;
                    const value = values[key(state.user, name)];
                    if (typeof value === 'boolean') state.values[name] = value;
                    else if ((name === '@order' || name === '@button-order') && Array.isArray(value)) state.values[name] = value.filter(item => typeof item === 'string');
                    else if (name === '@layout' && value !== undefined) state.values[name] = value === 'cards' ? 'cards' : 'current';
                    else if (panelSlots.includes(name) && value !== undefined) state.values[name] = value === 'right' ? 'right' : 'left';
                }
                refresh();
            }).catch(() => {
                if (current?.state === state) current.status.textContent = 'No se pudo leer la configuración guardada. Podés volver a intentar al reabrir VIENA.';
            });
    }
    function ordered(state, names, slot = '@order') {
        const value = current?.state === state && Object.hasOwn(current.draft || {},slot) ? current.draft[slot] : state.values[slot];
        const saved = Array.isArray(value) ? value : [];
        return [...new Set([...saved.filter(name => names.includes(name)), ...names])];
    }
    async function save(state, updates) {
        const view = current;
        if (!state.user || view.busy) return;
        const focus = view.menu.contains(document.activeElement) ? document.activeElement : null;
        const previous = Object.fromEntries(Object.keys(updates).map(name => [name, state.values[name]]));
        view.busy = true;
        for (const [name, value] of Object.entries(updates)) { state.changed.add(name); state.values[name] = value; }
        refresh();
        try {
            await bounded(chrome.storage.local.set(Object.fromEntries(Object.entries(updates).map(([name, value]) => [key(state.user, name), value]))));
            for (const [name, value] of Object.entries(updates)) { try { localStorage.setItem(key(state.user, name), JSON.stringify(value)); } catch (_) {} }
            view.status.textContent = 'Configuración guardada.';
            return true;
        } catch (_) {
            Object.assign(state.values, previous);
            view.status.textContent = 'No se pudo guardar. Volvé a intentar.';
            return false;
        } finally { view.busy = false; refresh(); if (focus?.isConnected && !focus.disabled) focus.focus({preventScroll:true}); }
    }
    function edit(state, updates) {
        if (!state.user || current.busy || current.state !== state) return;
        current.draft = { ...current.draft, ...updates };
        refresh();
        current.status.textContent = 'Vista previa · Cambios sin guardar.';
    }
    function toolbarData(root) {
        const native = [...root.querySelectorAll('button')].find(button => ['crear tarea','cambiar estado'].includes(clean(button.textContent).toLowerCase()));
        const toolbar = root.querySelector('#panel-plantillas-viena')?.parentElement || native?.closest('.row');
        if (!toolbar) return { toolbar:null, buttons:[] };
        const buttons = [...toolbar.querySelectorAll('button')].filter(button => !button.closest('.viena-ticket-fields-bar,.v-menu__content') && button.closest('.row') === toolbar)
            .map(button => ({ button, name:clean(button.textContent).replace(/^[✓✔✎]\s*/, ''), id:button.id }));
        return { toolbar, buttons:buttons.filter(item => item.name) };
    }
    function applyButton(button, hidden) {
        if (hidden && !buttonAttributes.has(button)) buttonAttributes.set(button, { aria:button.getAttribute('aria-hidden'), tab:button.getAttribute('tabindex') });
        button.classList.toggle('viena-ticket-button-hidden', hidden);
        if (hidden) { button.setAttribute('aria-hidden','true'); button.setAttribute('tabindex','-1'); }
        else if (buttonAttributes.has(button)) {
            const attributes = buttonAttributes.get(button);
            for (const [name, value] of [['aria-hidden',attributes.aria],['tabindex',attributes.tab]]) { if (value === null) button.removeAttribute(name); else button.setAttribute(name,value); }
            buttonAttributes.delete(button);
        }
    }
    function moveField(name, target, before = true) {
        if (!current?.state.user || current.busy || name === target) return;
        const order = ordered(current.state, current.names);
        if (!order.includes(name) || !order.includes(target)) return;
        order.splice(order.indexOf(name),1); order.splice(order.indexOf(target)+(before?0:1),0,name);
        const other = (current.state.values['@order'] || []).filter(item => !order.includes(item));
        edit(current.state, { '@order':[...order,...other] });
    }
    function moveButton(name, target, before = true) {
        if (!current?.state.user || current.busy || name === target) return;
        const order = ordered(current.state, current.buttons.map(item => item.name), '@button-order');
        if (!order.includes(name) || !order.includes(target)) return;
        order.splice(order.indexOf(name),1); order.splice(order.indexOf(target)+(before?0:1),0,name);
        const other = (current.state.values['@button-order'] || []).filter(item => !order.includes(item));
        edit(current.state, { '@button-order':[...order,...other] });
    }
    function discover(root) {
        for (const area of root.querySelectorAll('.ma-5')) {
            const fields = [];
            for (const row of area.querySelectorAll(':scope > .row')) {
                for (const column of row.querySelectorAll(':scope > .col')) {
                    if (column.classList.contains('viena-ticket-tools-host') || column.classList.contains('viena-completed-person-hidden')) continue;
                    const label = column.querySelector('.v-text-field__slot > label');
                    const control = label?.parentElement.querySelector('input[readonly],textarea[readonly]');
                    const name = clean(label?.textContent);
                    if (!name || !control) continue;
                    fields.push({ name, column, row, wide: control.tagName === 'TEXTAREA' });
                }
            }
            if (fields.some(field => field.name === 'Estado') && fields.some(field => field.name === 'Nodo CMTS' || field.name === 'Nodo')) return { area, fields };
        }
        return null;
    }
    function clearStatus() {
        current?.statusBadge?.remove();
        current?.statusHeader?.classList.remove('viena-ticket-status-header');
        if (current) { current.statusBadge = null; current.statusHeader = null; }
    }
    function clearFieldTask() {
        current?.fieldTask?.remove();
        current?.root.querySelector('.viena-ticket-field-task-header')?.classList.remove('viena-ticket-field-task-header');
        if (current) { current.fieldTask = null; current.fieldTaskId = ''; current.fieldTaskSource = ''; }
        document.dispatchEvent(new CustomEvent('VIENA_FIELD_TASK_REQUEST',{detail:{action:'clear'}}));
    }
    function syncFieldTask(root) {
        const source = clean(root.querySelector('.v-toolbar__title')?.textContent).replace(/^TICKET\s*:\s*/i,'');
        if (!source || source.length > 100) { clearFieldTask(); return; }
        if (current.fieldTaskSource !== source) {
            clearFieldTask(); current.fieldTaskSource = source; current.fieldTaskId = crypto.randomUUID();
        }
        document.dispatchEvent(new CustomEvent('VIENA_FIELD_TASK_REQUEST',{detail:{id:current.fieldTaskId,source}}));
    }
    document.addEventListener('VIENA_FIELD_TASK_RESULT', event => {
        const result = event.detail, view = current;
        if (!view || result?.id !== view.fieldTaskId || result.source !== view.fieldTaskSource
            || !view.root.classList.contains('v-dialog__content--active')
            || clean(view.root.querySelector('.v-toolbar__title')?.textContent).replace(/^TICKET\s*:\s*/i,'') !== result.source) return;
        const header = view.root.querySelector('.v-toolbar__title')?.parentElement;
        if (!header?.matches('.v-toolbar__content')) return;
        const tasks = result.available && Array.isArray(result.tasks) ? result.tasks.filter(task => typeof task.number === 'string' && ['AGENDADA','ASIGNADA','EN CURSO','INICIADA'].includes(task.status)) : [];
        view.fieldTask?.remove(); view.fieldTask = null;
        header.classList.toggle('viena-ticket-field-task-header',tasks.length > 0);
        if (!tasks.length) return;
        const multiple = tasks.length > 1, node = document.createElement(multiple ? 'details' : 'span');
        node.className = 'viena-ticket-field-task';
        const label = document.createElement(multiple ? 'summary' : 'span');
        label.textContent = multiple ? 'TAREA DE CAMPO: ' + tasks.length + ' tareas ▾' : 'TAREA DE CAMPO: ' + tasks[0].number + ' · ' + tasks[0].status;
        node.append(label);
        if (multiple) {
            const list = document.createElement('div'); list.className = 'viena-ticket-field-task-list'; list.setAttribute('role','list');
            for (const task of tasks) { const row = document.createElement('div'); row.setAttribute('role','listitem'); row.textContent = task.number + ' · ' + task.status; list.append(row); }
            node.append(list);
            node.addEventListener('keydown',event => { if (event.key === 'Escape') { node.open = false; label.focus(); event.stopPropagation(); } });
        }
        const anchor = view.statusBadge?.isConnected ? view.statusBadge : header.querySelector('.v-toolbar__title');
        anchor.after(node); view.fieldTask = node;
    });
    function nodeInputVisible(input) {
        return !!input?.isConnected && !!input.getClientRects().length
            && getComputedStyle(input).visibility === 'visible'
            && (!input.checkVisibility || input.checkVisibility({ checkOpacity:true, checkVisibilityCSS:true }));
    }
    function clearNodeCopies(root) {
        root?.querySelectorAll('.viena-ticket-node-copy').forEach(button => {
            clearTimeout(button.__vienaTimer);
            button.remove();
        });
    }
    async function copyNodeText(text) {
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await bounded(navigator.clipboard.writeText(text));
                return true;
            }
        } catch (_) {}
        const focus = document.activeElement;
        const selection = window.getSelection();
        const ranges = selection ? Array.from({ length:selection.rangeCount }, (_, i) => selection.getRangeAt(i).cloneRange()) : [];
        const textarea = document.createElement('textarea');
        textarea.value = text; textarea.readOnly = true;
        textarea.style.cssText = 'position:fixed;left:-9999px;top:-9999px;opacity:0';
        document.body.append(textarea);
        try { textarea.select(); return document.execCommand('copy'); }
        catch (_) { return false; }
        finally {
            textarea.remove(); focus?.focus?.({ preventScroll:true });
            if (selection) { selection.removeAllRanges(); ranges.forEach(range => selection.addRange(range)); }
        }
    }
    function renderNodeCopies(root, data) {
        const targets = data.fields.filter(field => field.name === 'Nodo' || field.name === 'Nodo CMTS')
            .map(field => ({ name:field.name, input:field.column.querySelector('.v-text-field__slot > input[readonly]') }))
            .filter(item => nodeInputVisible(item.input));
        root.querySelectorAll('.viena-ticket-node-copy').forEach(button => {
            if (!targets.some(item => item.input === button.__vienaInput && item.input.parentElement === button.parentElement)) {
                clearTimeout(button.__vienaTimer); button.remove();
            }
        });
        const measure = document.createElement('canvas').getContext('2d');
        for (const { name, input } of targets) {
            const style = getComputedStyle(input);
            measure.font = style.font;
            const spacing = parseFloat(style.letterSpacing) || 0;
            const left = input.offsetLeft + (parseFloat(style.borderLeftWidth) || 0) + (parseFloat(style.paddingLeft) || 0)
                + measure.measureText(input.value).width + spacing * input.value.length + 6;
            input.parentElement.style.setProperty('--viena-node-copy-left', left + 'px');
            if ([...input.parentElement.querySelectorAll('.viena-ticket-node-copy')].some(button => button.__vienaInput === input)) continue;
            const button = document.createElement('button');
            button.type = 'button'; button.className = 'viena-ticket-node-copy'; button.__vienaInput = input;
            const reset = () => {
                button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg>'; button.title = 'Copiar ' + name;
                button.setAttribute('aria-label', button.title);
                button.classList.remove('viena-copy-ok', 'viena-copy-error');
            };
            reset();
            let pending = false;
            button.addEventListener('click', async event => {
                event.preventDefault(); event.stopPropagation();
                if (pending || !nodeInputVisible(input) || !root.classList.contains('v-dialog__content--active')) return;
                const text = input.value.trim().replace(/\s*\|\s*/g, '|');
                pending = true;
                let ok = false;
                try { if (text) ok = await copyNodeText(text); }
                catch (_) {}
                finally { pending = false; }
                if (!button.isConnected) return;
                clearTimeout(button.__vienaTimer);
                button.textContent = ok ? '✓' : '!';
                button.title = ok ? 'Copiado' : text ? 'No se pudo copiar' : 'El campo está vacío';
                button.setAttribute('aria-label', button.title);
                button.classList.toggle('viena-copy-ok', ok); button.classList.toggle('viena-copy-error', !ok);
                button.__vienaTimer = setTimeout(reset, 1200);
            });
            input.parentElement.append(button);
        }
    }
    function renderStatus(root, data) {
        const title = root.querySelector('.v-toolbar__title');
        const header = title?.parentElement;
        const field = data.fields.find(field => field.name === 'Estado');
        const value = clean(field?.column.querySelector('.v-text-field__slot > input[readonly]')?.value);
        // Read only this ticket's native field; never the change-state dialog or
        // related-task rows. Preserve the title text used by ticket identity.
        if (!value || !header?.matches('.v-toolbar__content')) { clearStatus(); return; }
        if (current.statusHeader !== header) clearStatus();
        const states = {
            INICIADA:['Iniciado','▶','started'], SUSPENDIDA:['Suspendido','Ⅱ','suspended'],
            'NO ASIGNADA':['Pendiente de asignación','◷','pending'],
            COMPLETADA:['Completado','✓','completed'], ASIGNADA:['Asignada','●','neutral']
        };
        const [text, icon, kind] = Object.hasOwn(states, value.toUpperCase()) ? states[value.toUpperCase()] : [value,'●','neutral'];
        let badge = current.statusBadge;
        if (!badge?.isConnected) {
            badge = document.createElement('span'); badge.className = 'viena-ticket-status-badge';
            const symbol = document.createElement('span'); symbol.setAttribute('aria-hidden','true');
            badge.append(symbol, document.createElement('span')); title.after(badge);
            current.statusBadge = badge;
        }
        current.statusHeader = header; header.classList.add('viena-ticket-status-header');
        if (badge.dataset.kind !== kind) badge.dataset.kind = kind;
        if (badge.firstChild.textContent !== icon) badge.firstChild.textContent = icon;
        if (badge.lastChild.textContent !== text) badge.lastChild.textContent = text;
        if (badge.title !== 'Estado: ' + value) badge.title = 'Estado: ' + value;
    }
    function applyLayout(data, state, order) {
        const value = Object.hasOwn(current.draft || {}, '@layout') ? current.draft['@layout'] : state.values['@layout'];
        const cards = value === 'cards';
        current.root.setAttribute('data-viena-ticket-layout', cards ? 'cards' : 'current');
        for (const input of current.layoutChoice.querySelectorAll('input')) { input.checked = input.value === (cards ? 'cards' : 'current'); input.disabled = !state.user || current.busy; }
        if (!cards) return;
        const fields = data.fields.filter(field => visible(state, field.name));
        const message = fields.find(field => field.name === 'Mensaje');
        const info = fields.filter(field => field !== message).sort((a,b) => order.indexOf(a.name) - order.indexOf(b.name));
        const tools = [...data.area.querySelectorAll('.viena-ticket-tools-host')];
        const split = !!message && !!info.length;
        const rows = Math.max(1, Math.ceil(info.length / 2));
        const headerRow = message ? (tools.length ? 3 : 2) : 1;
        const set = (element, values) => { for (const [name, value] of Object.entries(values)) element.style.setProperty('--viena-card-' + name, String(value)); };
        data.area.classList.toggle('viena-ticket-cards-split', split);
        data.area.classList.toggle('viena-ticket-cards-message', !!message);
        data.area.classList.toggle('viena-ticket-cards-info', !!info.length);
        set(data.area, { 'info-col':split ? '3 / -1' : '1 / -1', 'info-end':rows + 2,
            'info-height':(56 + rows * 72) + 'px',
            'mobile-info-start':headerRow, 'mobile-info-end':headerRow + rows + 1,
            'small-info-end':headerRow + info.length + 1, 'left-end':info.length ? rows + 2 + tools.length : 2 + tools.length,
            'rows':info.length ? '56px' : 'auto', 'mobile-rows':(message ? 'auto ' + (tools.length ? 'auto ' : '') : '') + (info.length ? '56px' : 'auto') });
        if (message) set(message.column, { col:split ? '1 / 3' : '1 / -1', row:1,
            'mobile-col':'1 / -1', 'mobile-row':1, 'small-row':1 });
        info.forEach((field, index) => set(field.column, { col:(split ? 3 : 1) + index % 2, row:2 + Math.floor(index / 2),
            'info-top':(56 + Math.floor(index / 2) * 72) + 'px',
            'info-left':(50 + index % 2 * 25) + '%',
            'mobile-col':1 + index % 2, 'mobile-row':headerRow + 1 + Math.floor(index / 2), 'small-row':headerRow + 1 + index }));
        tools.forEach((host, index) => set(host, { col:split ? '1 / 3' : '1 / -1', row:split ? 2 + index : info.length ? rows + 2 + index : (message ? 2 : 1) + index,
            'mobile-col':'1 / -1', 'mobile-row':message ? 2 + index : info.length ? rows + 2 + index : 1 + index,
            'small-row':message ? 2 + index : info.length ? info.length + 2 + index : 1 + index }));
    }
    function panelHost(kind, fallback) {
        if (!current?.state || !current.root.contains(fallback)) return fallback;
        const name = '@panel:' + kind;
        const value = Object.hasOwn(current.draft || {}, name) ? current.draft[name] : current.state.values[name];
        if (value !== 'right') return fallback;
        let host = current.area.querySelector(':scope > .viena-ticket-panels-right');
        if (!host) {
            host = document.createElement('div'); host.className = 'viena-ticket-panels-right';
            current.area.append(host);
        }
        return host;
    }
    function placePanels() {
        if (!current?.state) return;
        const fallback = current.root.querySelector('.viena-ticket-tools-host .viena-mira5-action-wrap') || current.root.querySelector('.viena-ticket-tools-host');
        if (!fallback) return;
        for (const [kind, selector] of [['moica','.viena-node-progress'],['ged','.viena-moica-gee-status[data-ged-context],.viena-moica-gee-status:has(.viena-ged-report)'],['gec','.viena-gec-report[data-gec-context]'],['gee','.viena-gec-report[data-gee-context]']]) {
            for (const panel of current.root.querySelectorAll(selector)) {
                const host = panelHost(kind, fallback);
                if (panel.parentElement !== host) host.append(panel);
            }
        }
        const host = current.area.querySelector(':scope > .viena-ticket-panels-right');
        if (host && !host.childElementCount) host.remove();
        for (const input of current.panelChoice.querySelectorAll('select')) {
            const name = '@panel:' + input.dataset.vienaPanelPosition;
            input.value = (Object.hasOwn(current.draft || {}, name) ? current.draft[name] : current.state.values[name]) === 'right' ? 'right' : 'left';
            input.disabled = !current.state.user || current.busy;
        }
    }
    function ensureStyle() {
        if (document.getElementById('viena-ticket-fields-style')) return;
        const style = document.createElement('style');
        style.id = 'viena-ticket-fields-style';
        style.textContent = `
            .viena-internal-viewer-toggle:has(> input:checked) { background:#166534 !important; }
            .viena-internal-ticket-viewer.v-dialog__content--active > .v-dialog {
                position:relative !important; inset:auto !important;
                width:94vw !important; max-width:94vw !important; height:92vh !important;
                max-height:92vh !important; margin:0 !important; overflow-y:auto;
            }
            .v-text-field__slot:has(> .viena-ticket-node-copy) { position:relative; }
            .v-text-field__slot:has(> .viena-ticket-node-copy) > input { min-width:0; padding-right:30px; }
            .viena-ticket-node-copy { position:absolute; left:clamp(0px,var(--viena-node-copy-left),calc(100% - 30px)); top:50%; transform:translateY(-50%); display:inline-flex; align-items:center; justify-content:center; width:30px; height:30px; padding:0; border:0; border-radius:5px; background:transparent; color:#526579; font:18px Arial; line-height:1; cursor:pointer; }
            .viena-ticket-node-copy > svg { display:block; flex:none; pointer-events:none; }
            .viena-ticket-node-copy:focus-visible { outline:2px solid #1976d2; outline-offset:2px; }
            .viena-ticket-node-copy:hover { background:#e3f0fc; }
            .viena-ticket-node-copy.viena-copy-ok { color:#059669; }
            .viena-ticket-node-copy.viena-copy-error { color:#dc2626; }
            .theme--dark .viena-ticket-node-copy, html[data-viena-theme="dark"] .viena-ticket-node-copy { background:#1e293b; color:#e2e8f0; border-color:#64748b; }
            .viena-ticket-status-badge { display:inline-flex; align-items:center; gap:6px; flex:0 1 auto; min-width:0; max-width:45%; margin-left:10px; padding:4px 9px; border:1px solid #bec9d4; border-radius:20px; background:#edf1f5; color:#455569; font:600 12px/16px Arial; white-space:nowrap; }
            .viena-ticket-status-badge > span:last-child { overflow:hidden; text-overflow:ellipsis; }
            .viena-ticket-status-badge[data-kind="started"] { background:#e3f2fd; color:#125894; border-color:#a3cef1; }
            .viena-ticket-status-badge[data-kind="suspended"] { background:#fff0e0; color:#934700; border-color:#eeb774; }
            .viena-ticket-status-badge[data-kind="pending"] { background:#fff7dc; color:#795900; border-color:#e6cc75; }
            .viena-ticket-status-badge[data-kind="completed"] { background:#e4f5e9; color:#216b38; border-color:#9accaa; }
            .viena-ticket-field-task { position:relative; flex:0 1 auto; min-width:0; max-width:60%; margin-left:24px; color:inherit; font:600 16px/22px Arial; }
            .viena-ticket-field-task > span { display:block; overflow:auto; white-space:nowrap; }
            .viena-ticket-field-task > summary { cursor:pointer; white-space:nowrap; list-style:none; border:1px solid #ffffff80; border-radius:5px; padding:2px 8px; }
            .viena-ticket-field-task > summary:focus-visible { outline:2px solid currentColor; outline-offset:2px; }
            .v-toolbar:has(> .v-toolbar__content > .viena-ticket-field-task[open]),
            .v-toolbar__content:has(> .viena-ticket-field-task[open]) { position:relative; z-index:2; overflow:visible; }
            .viena-ticket-field-task-list { position:absolute; top:100%; left:0; z-index:100; width:max-content; max-width:min(420px,calc(100vw - 48px)); max-height:240px; overflow:auto; margin-top:6px; padding:6px 0; border:1px solid #b8cce0; border-radius:6px; background:#fff; color:#183a61; box-shadow:0 6px 20px #0b376840; }
            .viena-ticket-field-task-list > div { padding:6px 12px; overflow-wrap:anywhere; }
            .viena-ticket-field-task-list > div + div { border-top:1px solid #e1e9f2; }
            .theme--dark .viena-ticket-field-task-list { background:#1e293b; color:#e2e8f0; border-color:#64748b; }
            @media(max-width:600px) {
                .viena-ticket-status-header { display:grid !important; grid-template-columns:minmax(0,1fr) auto; grid-template-rows:20px 20px; gap:0 8px; }
                .viena-ticket-status-header > .v-toolbar__title { grid-column:1; grid-row:1; min-width:0; font-size:13px; line-height:20px; }
                .viena-ticket-status-header > .spacer { display:none; }
                .viena-ticket-status-header > button { grid-column:2; grid-row:1 / 3; }
                .viena-ticket-status-header > .viena-ticket-status-badge { grid-column:1; grid-row:2; justify-self:start; max-width:100%; margin-left:0; padding:0 7px; font-size:11px; line-height:18px; }
            }
            @media(max-width:1000px) {
                .viena-ticket-field-task-header { display:grid !important; height:auto !important; min-height:70px; grid-template-columns:minmax(0,1fr) auto; grid-template-rows:20px 20px auto; gap:0 8px; }
                .viena-ticket-field-task-header > .v-toolbar__title { grid-column:1; grid-row:1; min-width:0; }
                .viena-ticket-field-task-header > .spacer { display:none; }
                .viena-ticket-field-task-header > .viena-ticket-status-badge { grid-column:1; grid-row:2; justify-self:start; max-width:100%; margin-left:0; padding:0 7px; font-size:11px; line-height:18px; }
                .viena-ticket-field-task-header > button { grid-column:2; grid-row:1 / 4; }
                .viena-ticket-field-task-header > .viena-ticket-field-task { grid-column:1; grid-row:3; max-width:100%; margin-left:0; justify-self:start; }
                .viena-ticket-field-task-header .viena-ticket-field-task > span, .viena-ticket-field-task-header .viena-ticket-field-task > summary { white-space:normal; overflow-wrap:anywhere; }
            }
            .viena-ticket-fields-grid { display:grid !important; grid-template-columns:repeat(4,minmax(0,1fr)); gap:0 0; }
            .viena-ticket-fields-grid > .viena-ticket-fields-row { display:contents !important; }
            .viena-ticket-fields-grid > .viena-ticket-fields-row > .viena-ticket-field { width:auto !important; max-width:100% !important; min-width:0 !important; }
            .viena-ticket-fields-grid > .viena-ticket-fields-row > .viena-ticket-field-hidden { display:none !important; }
            .viena-ticket-field-wide,.viena-ticket-fields-grid > .row > .viena-ticket-tools-host { grid-column:1 / -1; }
            .viena-ticket-fields-bar { grid-column:1 / -1; display:flex; justify-content:flex-end; position:relative; padding:0 12px 8px; }
            .viena-ticket-fields-toggle { min-height:36px; padding:6px 12px; border:1px solid #b8c9dc; border-radius:6px; color:#174f80; background:#f1f6fb; font:600 14px Arial; cursor:pointer; }
            .viena-ticket-fields-menu { position:absolute; right:12px; top:100%; width:min(340px,calc(100vw - 64px)); max-height:min(65vh,600px); overflow:auto; padding:14px; border:1px solid #b8c9dc; border-radius:10px; background:#fff; color:#24324a; box-shadow:0 8px 24px #10233b33; z-index:1000001; font:14px/1.5 Arial; }
            .viena-ticket-fields-menu[hidden] { display:none !important; }
            .viena-ticket-fields-menu label { display:flex; align-items:center; gap:10px; padding:7px 0; cursor:pointer; }
            .viena-ticket-fields-menu input[type=checkbox] { width:18px !important; height:18px !important; flex:0 0 18px; margin:0; accent-color:#1976d2; }
            .viena-ticket-fields-status { margin:8px 0; font-size:13px; }
            .viena-ticket-fields-menu button { min-height:34px; cursor:pointer; }
            .viena-ticket-fields-toolbar { position:relative !important; display:flex !important; flex-wrap:wrap; align-items:center; gap:8px; padding-right:0 !important; }
            .v-banner:has(.viena-ticket-fields-toolbar), .v-banner__wrapper:has(.viena-ticket-fields-toolbar), .v-banner__content:has(.viena-ticket-fields-toolbar), .v-banner__text:has(.viena-ticket-fields-toolbar) { overflow:visible !important; }
            .viena-ticket-fields-toolbar > #panel-plantillas-viena, .viena-ticket-fields-toolbar #viena-custom-template-groups, .viena-ticket-fields-toolbar #viena-ticket-macros-anchor { display:contents !important; }
            .viena-ticket-fields-toolbar > .viena-ticket-resync-btn { position:static !important; margin-left:auto !important; margin-right:0 !important; }
            .viena-ticket-fields-toolbar.viena-ticket-buttons-ordered > .viena-ticket-resync-btn { margin-left:0 !important; }
            .viena-ticket-fields-toolbar button:not(.viena-ticket-button-hidden) { margin:0 !important; }
            .viena-ticket-fields-toolbar #viena-custom-template-manager-btn { color:#1976d2 !important; background:white !important; border:1px solid #b8c9dc; box-shadow:none !important; }
            .viena-ticket-fields-toolbar > .viena-ticket-fields-bar { position:static; padding:0; margin-left:auto; }
            .viena-ticket-button-hidden { position:absolute !important; width:1px !important; height:1px !important; min-width:0 !important; min-height:0 !important; padding:0 !important; margin:0 !important; overflow:hidden !important; clip-path:inset(50%) !important; opacity:0 !important; pointer-events:none !important; }
            .viena-ticket-fields-menu { width:min(420px,calc(100vw - 32px)); padding:0; display:flex; flex-direction:column; max-height:min(76vh,820px); }
            .viena-ticket-fields-header,.viena-ticket-fields-footer { padding:14px 16px; flex:0 0 auto; background:inherit; }
            .viena-ticket-fields-header { display:flex; align-items:center; justify-content:space-between; border-bottom:1px solid #d7e4f0; }
            .viena-ticket-fields-header strong { font-size:18px; }
            .viena-ticket-fields-body { overflow:auto; min-height:0; padding:0 16px; }
            .viena-ticket-fields-body section { padding:12px 0; border-bottom:1px solid #d7e4f0; }
            .viena-ticket-fields-body h3 { margin:0 0 4px; font-size:15px; color:#1976d2; }
            .viena-ticket-fields-help { margin:0 0 8px; color:#64748b; font-size:13px; }
            .viena-ticket-field-option,.viena-ticket-button-option { display:flex; align-items:center; border:1px solid #d7e4f0; border-radius:5px; margin:4px 0; padding:0 6px; gap:6px; }
            .viena-ticket-field-option label,.viena-ticket-button-option label { flex:1; min-width:0; }
            .viena-ticket-field-drag { cursor:grab; padding:5px; user-select:none; }
            .viena-ticket-field-option button,.viena-ticket-button-option button { border:0; background:transparent; color:#174f80; padding:0 5px; }
            .viena-ticket-field-option.viena-ticket-field-drop,.viena-ticket-button-option.viena-ticket-field-drop { outline:2px solid #1976d2; }
            .viena-ticket-fields-footer { border-top:1px solid #d7e4f0; display:flex; flex-wrap:wrap; gap:8px; }
            .viena-ticket-fields-footer button,.viena-ticket-fields-show-buttons { border:1px solid #b8c9dc; border-radius:5px; background:#fff; color:#174f80; padding:6px 10px; }
            .viena-ticket-fields-footer .viena-ticket-fields-done { background:#1976d2; color:#fff; margin-left:auto; }
            .viena-ticket-fields-preview-bar { position:fixed; bottom:16px; left:50%; transform:translateX(-50%); z-index:1000002; display:flex; flex-wrap:wrap; align-items:center; justify-content:center; gap:8px; width:max-content; max-width:calc(100vw - 32px); padding:12px; border:1px solid #b8c9dc; border-radius:8px; background:#fff; color:#174f80; box-shadow:0 4px 20px #10233b33; font:14px Arial; }
            .viena-ticket-fields-preview-bar[hidden] { display:none !important; }
            .viena-ticket-fields-preview-bar button { min-height:34px; border:1px solid #b8c9dc; border-radius:5px; padding:6px 10px; background:#fff; color:#174f80; cursor:pointer; }
            .viena-ticket-fields-preview-bar .viena-ticket-fields-preview-apply { background:#1976d2; color:#fff; }
            @media(max-width:960px) { .viena-ticket-fields-grid { grid-template-columns:repeat(2,minmax(0,1fr)); } }
            @media(max-width:520px) { .viena-ticket-fields-grid { grid-template-columns:minmax(0,1fr); } }
            html[data-viena-theme="dark"] .viena-ticket-fields-menu, .theme--dark .viena-ticket-fields-menu { background:#1e293b; color:#e2e8f0; border-color:#64748b; }
            .viena-ticket-layout-choice { border:0; border-bottom:1px solid #d7e4f0; padding:0 0 12px; margin:0 0 16px; }
            .viena-ticket-layout-choice legend { font-weight:700; padding:0; }
            .viena-ticket-layout-choice input[type=radio] { width:18px; height:18px; flex:0 0 18px; margin:0; accent-color:#1976d2; }
            .viena-ticket-panel-choice select { min-width:0; max-width:100%; padding:6px; border:1px solid #b8c9dc; border-radius:5px; background:inherit; color:inherit; font:inherit; }
            .viena-ticket-fields-menu { white-space:normal; }
            .viena-ticket-panel-choice label { flex-direction:column; align-items:stretch; gap:6px; }
            .viena-ticket-panels-right { display:flex; flex-direction:column; gap:12px; grid-column:1 / -1; order:10000; min-width:0; width:50%; margin-left:auto; padding:12px 16px; }
            .viena-ticket-panels-right > * { max-width:100%; min-width:0; overflow-wrap:anywhere; }
            [data-viena-ticket-layout="cards"] .viena-ticket-panels-right { width:auto; margin-left:0; }
            @media(min-width:1101px) {
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split:has(> .viena-ticket-panels-right) { grid-template-rows:max-content max-content minmax(0,1fr); }
                [data-viena-ticket-layout="cards"] .viena-ticket-cards-split > .viena-ticket-panels-right { grid-column:3 / -1; grid-row:1 / span 3; padding-top:calc(var(--viena-card-info-height) + 12px); align-self:start; }
            }
            @media(max-width:1100px) { .viena-ticket-panels-right { width:auto; margin-left:0; } }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid { grid-template-columns:repeat(2,minmax(0,1fr)); grid-template-rows:var(--viena-card-rows); position:relative; isolation:isolate; z-index:1; gap:0; }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row:has(> .viena-ticket-tools-host) { display:contents !important; }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split { grid-template-columns:repeat(4,minmax(0,1fr)); }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::before { content:'Información del ticket'; grid-column:var(--viena-card-info-col); grid-row:1 / var(--viena-card-info-end); background:#fff; color:#174f80; border:1px solid #d7e4f0; border-radius:10px; box-shadow:0 3px 12px #10233b0d; font:700 18px/24px Arial; padding:18px 16px; min-width:0; pointer-events:none; z-index:-1; }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid:not(.viena-ticket-cards-info)::before { display:none; }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::after { content:''; grid-column:1 / -1; grid-row:1 / var(--viena-card-left-end); background:#fff; border:1px solid #d7e4f0; border-radius:10px; box-shadow:0 3px 12px #10233b0d; pointer-events:none; z-index:-1; }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split::after { grid-column:1 / 3; margin-right:16px; }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid:not(.viena-ticket-cards-message)::after { display:none; }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row > .viena-ticket-field,
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row > .viena-ticket-tools-host { grid-column:var(--viena-card-col); grid-row:var(--viena-card-row); align-self:start; padding:12px 16px; min-width:0; max-width:100% !important; width:auto !important; }
            [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row > .viena-ticket-field-wide { padding-top:54px; }
            [data-viena-ticket-layout="cards"] .viena-ticket-cards-split > .row > .viena-ticket-field-wide,
            [data-viena-ticket-layout="cards"] .viena-ticket-cards-split > .row > .viena-ticket-tools-host { margin-right:16px; }
            [data-viena-ticket-layout="cards"] .viena-ticket-field-wide .v-text-field__slot > label { transform:none !important; top:-36px !important; left:0 !important; font-size:18px; font-weight:700; color:#174f80; background:transparent; }
            [data-viena-ticket-layout="cards"] .viena-ticket-field .v-input { min-width:0; max-width:100%; }
            @media(min-width:1101px) {
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split { grid-template-rows:auto; align-content:start; min-height:var(--viena-card-info-height); }
                [data-viena-ticket-layout="cards"] .viena-ticket-cards-split > .row > .viena-ticket-field:not(.viena-ticket-field-wide) { position:absolute; grid-area:auto; top:var(--viena-card-info-top); left:var(--viena-card-info-left); width:25% !important; }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split::before { position:absolute; grid-area:auto; top:0; right:0; width:50%; height:var(--viena-card-info-height); box-sizing:border-box; }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split::after { grid-row:1 / span 2; }
            }
            [data-viena-ticket-layout="cards"] .ma-5:has(> .v-tabs) { border:1px solid #d7e4f0; border-radius:10px; box-shadow:0 3px 12px #10233b0d; }
            @media(max-width:1100px) {
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid { grid-template-rows:var(--viena-card-mobile-rows); }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split { grid-template-columns:repeat(2,minmax(0,1fr)); }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::before { grid-column:1 / -1; grid-row:var(--viena-card-mobile-info-start) / var(--viena-card-mobile-info-end); }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::after,
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split::after { grid-column:1 / -1; grid-row:1 / var(--viena-card-mobile-info-start); margin:0 0 16px; }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row > .viena-ticket-field,
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row > .viena-ticket-tools-host { grid-column:var(--viena-card-mobile-col); grid-row:var(--viena-card-mobile-row); margin-right:0; }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row > .viena-ticket-tools-host { padding-bottom:28px; }
            }
            @media(max-width:520px) {
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid,
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid.viena-ticket-cards-split { grid-template-columns:minmax(0,1fr); }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::before { grid-row-end:var(--viena-card-small-info-end); }
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row > .viena-ticket-field,
                [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid > .row > .viena-ticket-tools-host { grid-column:1 / -1; grid-row:var(--viena-card-small-row); }
            }
            html[data-viena-theme="dark"] [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::before,
            html[data-viena-theme="dark"] [data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::after,
            .theme--dark[data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::before,
            .theme--dark[data-viena-ticket-layout="cards"] .viena-ticket-fields-grid::after { background:#1e293b; color:#e2e8f0; border-color:#64748b; }
            html[data-viena-theme="dark"] [data-viena-ticket-layout="cards"] .viena-ticket-field-wide .v-text-field__slot > label,
            .theme--dark[data-viena-ticket-layout="cards"] .viena-ticket-field-wide .v-text-field__slot > label { color:#e2e8f0; }
        `;
        document.head.appendChild(style);
    }
    function mount(root, area) {
        const bar = document.createElement('div');
        bar.className = 'viena-ticket-fields-bar';
        bar.setAttribute('data-viena-macro-ui', '1');
        const button = document.createElement('button');
        button.type = 'button'; button.className = 'viena-ticket-fields-toggle';
        button.textContent = '⚙ Personalizar vista'; button.setAttribute('aria-expanded', 'false'); button.setAttribute('aria-controls', 'viena-ticket-fields-menu');
        const menu = document.createElement('div');
        menu.id = 'viena-ticket-fields-menu'; menu.className = 'viena-ticket-fields-menu'; menu.hidden = true;
        menu.setAttribute('role', 'dialog'); menu.setAttribute('aria-label', 'Personalizar vista');
        const title = document.createElement('strong'); title.textContent = 'Personalizar vista';
        const header = document.createElement('div'); header.className='viena-ticket-fields-header';
        const body = document.createElement('div'); body.className='viena-ticket-fields-body';
        const layoutChoice = document.createElement('fieldset'); layoutChoice.className='viena-ticket-layout-choice';
        const layoutTitle = document.createElement('legend'); layoutTitle.textContent='Vista del ticket'; layoutChoice.append(layoutTitle);
        for (const [value, text] of [['current','Vista actual (predeterminada)'],['cards','Vista en tarjetas']]) {
            const label=document.createElement('label'),input=document.createElement('input'); input.type='radio';input.name='viena-ticket-layout';input.value=value;
            input.addEventListener('change',()=>{if(input.checked)edit(current.state,{'@layout':value});}); label.append(input,document.createTextNode(text));layoutChoice.append(label);
        }
        const panelChoice = document.createElement('section'); panelChoice.className = 'viena-ticket-panel-choice';
        const panelTitle = document.createElement('h3'); panelTitle.textContent = 'Ubicación de los paneles';
        const panelHelp = document.createElement('p'); panelHelp.className = 'viena-ticket-fields-help'; panelHelp.textContent = 'A la derecha se muestran debajo de los campos de información. En ventanas angostas se apilan.';
        panelChoice.append(panelTitle,panelHelp);
        for (const [kind, text] of [['moica','Tickets MOICA'],['ged','Análisis GED'],['gec','Tareas de campo GEC'],['gee','Tareas de campo GEE']]) {
            const label = document.createElement('label'), input = document.createElement('select');
            input.dataset.vienaPanelPosition = kind; input.setAttribute('aria-label','Ubicación de ' + text);
            for (const [value, title] of [['left','Izquierda (predeterminada)'],['right','Derecha · debajo de Información del ticket']]) {
                const option = document.createElement('option'); option.value = value; option.textContent = title; input.append(option);
            }
            input.onchange = () => edit(current.state,{['@panel:' + kind]:input.value});
            label.append(document.createTextNode(text),input); panelChoice.append(label);
        }
        const buttonsSection = document.createElement('section');
        const buttonsTitle = document.createElement('h3'); buttonsTitle.textContent='Botones superiores';
        const buttonsHelp = document.createElement('p'); buttonsHelp.className='viena-ticket-fields-help'; buttonsHelp.textContent='Arrastrá para ordenar · Destildá para ocultar';
        const buttonOptions = document.createElement('div'); buttonOptions.className='viena-ticket-button-options';
        const showButtons = document.createElement('button'); showButtons.type='button'; showButtons.className='viena-ticket-fields-show-buttons'; showButtons.textContent='Mostrar todos';
        showButtons.onclick=()=>edit(current.state,Object.fromEntries(current.buttons.map(item=>['@button:'+item.name,true])));
        buttonsSection.append(buttonsTitle,buttonsHelp,buttonOptions,showButtons);
        const viewerOptions = ['GEC','GEE','GED'].map(sector => {
            const section = document.createElement('section'), label = document.createElement('label'), input = document.createElement('input');
            const name = '@button:Ver ' + sector;
            input.type = 'checkbox'; input.setAttribute('data-viena-' + sector.toLowerCase() + '-button-option','');
            label.append(input,document.createTextNode('Mostrar botón Ver ' + sector)); section.append(label); section.hidden = true;
            if (sector === 'GED') {
                const help = document.createElement('p'); help.className = 'viena-ticket-fields-help'; help.textContent = 'El análisis automático y su resultado siguen activos aunque ocultes el botón.'; section.append(help);
            }
            input.onchange = () => edit(current.state,{[name]:input.checked});
            return { section, input, name, selector:'.viena-moica-' + sector.toLowerCase() + '-button' };
        });
        const fieldsSection = document.createElement('section');
        const fieldsTitle = document.createElement('h3'); fieldsTitle.textContent='Campos del ticket';
        const help = document.createElement('p'); help.className='viena-ticket-fields-help'; help.textContent='Arrastrá para ordenar · Destildá para ocultar';
        const options = document.createElement('div'); options.className='viena-ticket-field-options';
        fieldsSection.append(fieldsTitle,help,options);
        const status = document.createElement('p'); status.className = 'viena-ticket-fields-status'; status.setAttribute('role', 'status');
        const close = document.createElement('button'); close.type = 'button'; close.textContent = '×'; close.setAttribute('aria-label','Cerrar personalización');
        const footer = document.createElement('div'); footer.className='viena-ticket-fields-footer';
        const reset = document.createElement('button'); reset.type='button'; reset.className='viena-ticket-fields-reset'; reset.textContent='Restaurar vista predeterminada';
        reset.onclick=()=>edit(current.state,{...Object.fromEntries([...current.names,...current.buttons.map(item=>'@button:'+item.name),...current.viewerOptions.filter(item=>!item.section.hidden).map(item=>item.name)].map(name=>[name,true])),'@order':[],'@button-order':[],'@layout':'current','@panel:moica':'left','@panel:ged':'left','@panel:gec':'left','@panel:gee':'left'});
        const done = document.createElement('button'); done.type='button'; done.className='viena-ticket-fields-done'; done.textContent='Aplicar';
        const cancel=document.createElement('button');cancel.type='button';cancel.textContent='Cancelar';cancel.className='viena-ticket-fields-cancel';
        const result=document.createElement('button');result.type='button';result.textContent='Ver resultado';result.className='viena-ticket-fields-preview-result';
        const preview=document.createElement('div');preview.className='viena-ticket-fields-preview-bar';preview.hidden=true;
        const previewText=document.createElement('span');previewText.textContent='Vista previa · Cambios sin guardar';previewText.setAttribute('role','status');
        const previewEdit=document.createElement('button');previewEdit.type='button';previewEdit.textContent='Editar';
        const previewApply=document.createElement('button');previewApply.type='button';previewApply.textContent='Aplicar';previewApply.className='viena-ticket-fields-preview-apply';
        const previewCancel=document.createElement('button');previewCancel.type='button';previewCancel.textContent='Cancelar';previewCancel.className='viena-ticket-fields-preview-cancel';
        preview.append(previewText,previewEdit,previewApply,previewCancel);
        header.append(title,close); body.append(status,layoutChoice,panelChoice,buttonsSection,...viewerOptions.map(item=>item.section),fieldsSection); footer.append(reset,result,cancel,done); menu.append(header,body,footer); bar.append(button,menu,preview); area.prepend(bar);
        const hideMenu = () => { menu.hidden=true;area.classList.remove('viena-ticket-fields-open');button.setAttribute('aria-expanded','false');button.focus({preventScroll:true}); };
        const closeMenu = () => { if(current.busy)return;current.draft=null;refresh();hideMenu(); };
        const openMenu = () => { menu.hidden=false;area.classList.add('viena-ticket-fields-open');button.setAttribute('aria-expanded','true');(menu.querySelector('input:not(:disabled)')||close).focus({preventScroll:true}); };
        button.onclick = () => { if(menu.hidden)openMenu();else closeMenu(); };
        close.onclick = closeMenu;
        cancel.onclick=previewCancel.onclick=closeMenu;
        result.onclick=hideMenu;
        previewEdit.onclick=openMenu;
        done.onclick=previewApply.onclick=async()=>{if(current.busy||!current.draft)return;const view=current,updates=view.draft;view.draft=null;const saved=await save(view.state,updates);if(current===view&&saved)hideMenu();};
        bar.addEventListener('keydown', event => { if (event.key === 'Escape') { event.preventDefault(); closeMenu(); } });
        for (const type of ['pointerdown','pointerup','mousedown','mouseup','click','dblclick','keydown','keypress','keyup','input','change','focusin','focusout']) bar.addEventListener(type, event => event.stopPropagation());
        return { root, area, bar, button, menu, options, buttonOptions, buttonsSection, viewerOptions, layoutChoice, panelChoice, status, preview, done, previewApply, result, signature:'', busy:false, dragName:'', draft:null };
    }
    function refresh() {
        // Do not observe our own class/order/menu updates or create feedback loops.
        ticketObserver.disconnect();
        try { refreshView(); globalThis.VienaMoicaViewer?.refresh(); placePanels(); globalThis.VienaInfocallViewer?.refresh(); }
        finally {
            if (current?.root.isConnected) watchedRoot = current.root;
            if (watchedRoot?.isConnected) ticketObserver.observe(watchedRoot, {
                childList:true, subtree:true, characterData:true, attributes:true, attributeFilter:['class','style','hidden','data-viena-ticket-layout','value','type']
            });
        }
    }
    function refreshView() {
        const root = [...document.querySelectorAll('.v-dialog__content--active')].reverse().find(dialog => dialog.getClientRects().length && /^TICKET\s*:/i.test(clean(dialog.querySelector('.v-toolbar__title')?.textContent)));
        const expanded = internalViewerEnabled && /^\/tasks\/intern(?:\/|$)/i.test(location.pathname);
        for (const previous of document.querySelectorAll('.viena-internal-ticket-viewer')) {
            if (previous !== root || !expanded) previous.classList.remove('viena-internal-ticket-viewer');
        }
        if (root && expanded) { ensureStyle(); root.classList.add('viena-internal-ticket-viewer'); }
        if (!root) {
            clearNodeCopies(current?.root || watchedRoot);
            clearFieldTask();
            clearStatus();
            current?.bar.remove(); current = null;
            watchedRoot = [...document.querySelectorAll('.v-dialog__content')].reverse().find(dialog => /^TICKET\s*:/i.test(clean(dialog.querySelector('.v-toolbar__title')?.textContent))) || watchedRoot;
            return;
        }
        const data = discover(root);
        if (!data) {
            clearNodeCopies(root); clearFieldTask(); clearStatus();
            current?.bar.remove(); current = null;
            // Observe this incomplete ticket, rather than the previous dialog.
            watchedRoot = root;
            return;
        }
        ensureStyle();
        if (current?.root !== root) clearNodeCopies(current?.root);
        if (current?.area !== data.area || !current.bar.isConnected) { clearFieldTask(); clearStatus(); current?.bar.remove(); current = mount(root, data.area); }
        renderStatus(root, data);
        syncFieldTask(root);
        const user = userName();
        if (!states.has(user)) states.set(user, { user, values:Object.create(null), loaded:new Set(), changed:new Set() });
        const state = states.get(user);
        if(current.state!==state)current.draft=null;
        current.state = state;
        const toolbar = toolbarData(root);
        const names = [...new Set(data.fields.map(field => field.name))];
        const signature = JSON.stringify([user, names, toolbar.buttons.map(item=>item.name)]);
        if(signature!==current.signature)current.draft=null;
        current.buttons = toolbar.buttons;
        read(state, [...names,...toolbar.buttons.map(item=>'@button:'+item.name),'@order','@button-order','@layout',...panelSlots]);
        if (toolbar.toolbar) { toolbar.toolbar.classList.add('viena-ticket-fields-toolbar'); if(current.bar.parentElement!==toolbar.toolbar) toolbar.toolbar.append(current.bar); }
        const buttonOrder = ordered(state, toolbar.buttons.map(item=>item.name), '@button-order');
        toolbar.toolbar?.classList.toggle('viena-ticket-buttons-ordered',!!(current.draft?.['@button-order']||state.values['@button-order'])?.length);
        current.bar.style.order=String(buttonOrder.length+1);
        for (const item of toolbar.buttons) { applyButton(item.button,!visible(state,'@button:'+item.name)); item.button.style.order=String(buttonOrder.indexOf(item.name)); }
        data.area.classList.add('viena-ticket-fields-grid');
        current.names=names;
        const order=ordered(state,names);
        for (const field of data.fields) {
            field.row.classList.add('viena-ticket-fields-row');
            field.column.classList.add('viena-ticket-field');
            field.column.classList.toggle('viena-ticket-field-wide', field.wide);
            field.column.classList.toggle('viena-ticket-field-hidden', !visible(state, field.name));
            field.column.style.order=String(order.indexOf(field.name)*2);
        }
        const messageIndex=order.indexOf('Mensaje');
        for(const host of data.area.querySelectorAll('.viena-ticket-tools-host')) host.style.order=String((messageIndex<0?order.length:messageIndex)*2-1);
        applyLayout(data, state, order);
        renderNodeCopies(root, data);
        if (signature !== current.signature) {
            current.signature = signature; current.menu.hidden = true; data.area.classList.remove('viena-ticket-fields-open'); current.button.setAttribute('aria-expanded','false'); current.options.replaceChildren(); current.buttonOptions.replaceChildren();
            current.status.textContent = user ? 'Los cambios se guardan para tu usuario.' : 'Esperando identificar tu usuario VIENA para guardar tus preferencias.';
            for (const name of names) {
                const row=document.createElement('div'); row.className='viena-ticket-field-option'; row.dataset.name=name;
                const handle=document.createElement('span'); handle.className='viena-ticket-field-drag'; handle.textContent='⠿'; handle.draggable=true; handle.title='Arrastrar '+name;
                handle.addEventListener('dragstart',event=>{if(current.busy||!state.user){event.preventDefault();return;}current.dragKind='fields';current.dragName=name;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',name);});
                handle.addEventListener('dragend',()=>{current.dragName='';current.options.querySelectorAll('.viena-ticket-field-drop').forEach(item=>item.classList.remove('viena-ticket-field-drop'));});
                row.addEventListener('dragover',event=>{if(current.dragKind!=='fields'||!current.dragName||current.busy)return;event.preventDefault();row.classList.add('viena-ticket-field-drop');});
                row.addEventListener('dragleave',()=>row.classList.remove('viena-ticket-field-drop'));
                row.addEventListener('drop',event=>{if(current.dragKind!=='fields')return;event.preventDefault();row.classList.remove('viena-ticket-field-drop');const source=current.dragName;current.dragName='';if(source)moveField(source,name);});
                const label = document.createElement('label');
                const input = document.createElement('input'); input.type = 'checkbox'; input.dataset.field = name;
                label.append(input, document.createTextNode(name)); row.append(handle,label);
                for(const direction of [-1,1]){const arrow=document.createElement('button');arrow.type='button';arrow.dataset.direction=String(direction);arrow.textContent=direction<0?'↑':'↓';arrow.setAttribute('aria-label',(direction<0?'Subir ':'Bajar ')+name);arrow.onclick=()=>{const order=ordered(state,current.names),index=order.indexOf(name);if(order[index+direction])moveField(name,order[index+direction],direction<0);};row.append(arrow);}
                current.options.append(row);
                input.addEventListener('change', async () => {
                    edit(state,{[name]:input.checked});
                });
            }
            for(const item of toolbar.buttons){
                const name=item.name,row=document.createElement('div');row.className='viena-ticket-button-option';row.dataset.name=name;
                const handle=document.createElement('span');handle.className='viena-ticket-field-drag';handle.textContent='⠿';handle.draggable=true;handle.title='Arrastrar '+name;
                handle.addEventListener('dragstart',event=>{if(current.busy||!state.user){event.preventDefault();return;}current.dragKind='buttons';current.dragName=name;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',name);});
                handle.addEventListener('dragend',()=>{current.dragName='';current.buttonOptions.querySelectorAll('.viena-ticket-field-drop').forEach(item=>item.classList.remove('viena-ticket-field-drop'));});
                row.addEventListener('dragover',event=>{if(current.dragKind!=='buttons'||!current.dragName||current.busy)return;event.preventDefault();row.classList.add('viena-ticket-field-drop');});
                row.addEventListener('dragleave',()=>row.classList.remove('viena-ticket-field-drop'));
                row.addEventListener('drop',event=>{if(current.dragKind!=='buttons')return;event.preventDefault();row.classList.remove('viena-ticket-field-drop');const source=current.dragName;current.dragName='';if(source)moveButton(source,name);});
                const label=document.createElement('label'),input=document.createElement('input');input.type='checkbox';input.dataset.button=name;label.append(input,document.createTextNode(name));row.append(handle,label);
                for(const direction of [-1,1]){const arrow=document.createElement('button');arrow.type='button';arrow.dataset.direction=String(direction);arrow.textContent=direction<0?'↑':'↓';arrow.setAttribute('aria-label',(direction<0?'Subir ':'Bajar ')+name);arrow.onclick=()=>{const order=ordered(state,current.buttons.map(item=>item.name),'@button-order'),index=order.indexOf(name);if(order[index+direction])moveButton(name,order[index+direction],direction<0);};row.append(arrow);}
                current.buttonOptions.append(row);input.onchange=()=>edit(state,{['@button:'+name]:input.checked});
            }
        }
        const rows=[...current.options.children];
        for(const name of order){const row=rows.find(item=>item.dataset.name===name);if(row&&current.options.children[order.indexOf(name)]!==row)current.options.insertBefore(row,current.options.children[order.indexOf(name)]||null);}
        for (const input of current.options.querySelectorAll('input')) { input.checked = visible(state, input.dataset.field); input.disabled = !user || current.busy; }
        for (const input of current.buttonOptions.querySelectorAll('input')) { input.checked=visible(state,'@button:'+input.dataset.button);input.disabled=!user||current.busy; }
        for (const option of current.viewerOptions) {
            const viewerButton = root.querySelector(option.selector);
            option.section.hidden = !viewerButton;
            if (viewerButton) {
                read(state,[option.name]);
                applyButton(viewerButton,!visible(state,option.name));
            }
            option.input.checked = visible(state,option.name); option.input.disabled = !user || current.busy;
        }
        const buttonRows=[...current.buttonOptions.children];
        for(const name of buttonOrder){const row=buttonRows.find(item=>item.dataset.name===name),index=buttonOrder.indexOf(name);if(row&&current.buttonOptions.children[index]!==row)current.buttonOptions.insertBefore(row,current.buttonOptions.children[index]||null);}
        for(const row of current.buttonOptions.children){const index=buttonOrder.indexOf(row.dataset.name);for(const button of row.querySelectorAll('button'))button.disabled=!user||current.busy||(Number(button.dataset.direction)<0?index===0:index===buttonOrder.length-1);}
        current.buttonsSection.hidden=!toolbar.buttons.length;
        for(const row of current.options.children){const index=order.indexOf(row.dataset.name);for(const button of row.querySelectorAll('button'))button.disabled=!user||current.busy||(Number(button.dataset.direction)<0?index===0:index===order.length-1);}
        for(const button of current.menu.querySelectorAll('.viena-ticket-fields-reset,.viena-ticket-fields-show-buttons'))button.disabled=!user||current.busy;
        const pending=!!current.draft&&Object.keys(current.draft).some(name=>JSON.stringify(current.draft[name])!==JSON.stringify(state.values[name]));
        current.preview.hidden=!pending;
        current.done.disabled=current.previewApply.disabled=!user||current.busy||!pending;
        current.result.disabled=!pending||current.busy;
        for(const button of current.bar.querySelectorAll('.viena-ticket-fields-cancel,.viena-ticket-fields-preview-cancel,.viena-ticket-fields-header > button'))button.disabled=current.busy;
    }
    // List-only presentation preferences. Native controls, values and handlers stay mounted.
    const filterPrefix = 'viena_internal_filter_hidden_v1:';
    const filterNames = ['Nro Ticket','Estado','Motivo','Tipificación de tarea','Tipo de negocio','Afectación','Fecha creación','Fecha completada','Nro Ticket Evento','Seleccione Jerarquía','Tipo de evento','Prioridades','Nodos','Hubs','Region','Olts','Usuario creador','ownerGroup','Seleccione Reincidencia','Proveedor','Asignado a','Id Cliente','Id Edificio'];
    const filterStates = new Map();
    let filterView = null;
    function refreshInternalFilters() {
        const scope = /^\/tasks\/(intern|field)\/?$/i.exec(location.pathname)?.[1].toLowerCase();
        if (!scope) {
            filterView?.header?.classList.remove('viena-filter-header-wrap');filterView?.panel?.classList.remove('viena-filter-panel');
            filterView?.bar.remove(); filterView = null;
            document.querySelectorAll('.viena-internal-filter-hidden').forEach(column => column.classList.remove('viena-internal-filter-hidden'));
            document.querySelectorAll('.viena-filter-ordered').forEach(column=>{column.classList.remove('viena-filter-ordered');column.style.removeProperty('--viena-filter-order');});
            return;
        }
        const panels = [...document.querySelectorAll('main .v-expansion-panel')].filter(panel =>
            /^Filtros de tabla(?:\s|$)/.test(clean(panel.querySelector(':scope > .v-expansion-panel-header')?.textContent)));
        if (panels.length !== 1) { filterView?.header?.classList.remove('viena-filter-header-wrap');filterView?.panel?.classList.remove('viena-filter-panel');filterView?.bar.remove(); filterView = null; return; }
        const panel = panels[0], user = userName();
        const storageKey = (scope === 'field' ? 'viena_field_filter_hidden_v1:' : filterPrefix) + encodeURIComponent(user);
        const orderKey = 'viena_'+(scope==='field'?'field':'internal')+'_filter_order_v1:'+encodeURIComponent(user);
        const allowedNames = scope === 'field' ? [...filterNames.slice(0,6),'SubZonas','Contratista','Aplicación de Campo',...filterNames.slice(6).filter(name=>!['ownerGroup','Asignado a','Id Cliente','Id Edificio'].includes(name))] : filterNames;
        const grid = panel.querySelector(':scope > .v-expansion-panel-content .container > .row');
        const fields = grid ? [...grid.children].filter(column => column.classList.contains('col')).map(column => ({column,
            name:clean(column.querySelector(':scope > .v-expansion-panels > .v-expansion-panel > .v-expansion-panel-header > span')?.textContent || column.querySelector('label')?.textContent || column.querySelector('.v-expansion-panel-header > span')?.textContent)
        })).filter(field => field.name) : allowedNames.map(name=>({name,column:null}));
        if (!fields.length || new Set(fields.map(field => field.name)).size !== fields.length) return;
        if (!document.getElementById('viena-internal-filter-style')) {
            const style = document.createElement('style'); style.id = 'viena-internal-filter-style';
            style.textContent = `.viena-internal-filter-hidden{display:none!important}
.viena-filter-ordered{order:var(--viena-filter-order)!important}
.viena-internal-filter-option{display:flex;align-items:center;gap:4px;min-width:0}
.viena-internal-filter-option label{flex:1;overflow-wrap:anywhere}
.viena-filter-drag{cursor:grab;padding:4px;user-select:none}
.viena-filter-drop{outline:2px dashed #1976d2;outline-offset:2px}
.viena-filter-panel{position:relative}
.viena-internal-filter-bar{margin:0 24px;font:14px Arial,sans-serif;color:inherit}
.viena-internal-filter-bar > button{position:absolute;z-index:1}
.viena-filter-header-wrap{padding-bottom:56px!important}
.viena-internal-filter-bar button{font:600 13px Arial,sans-serif;border:1px solid #1976d2;border-radius:6px;background:transparent;color:#1976d2;padding:8px 12px;cursor:pointer;margin:4px 8px 4px 0}
.viena-internal-filter-bar button:disabled{opacity:.55;cursor:default}
.viena-internal-filter-menu{border:1px solid #9e9e9e;border-radius:8px;padding:12px;margin:8px 0 12px;background:inherit}
.viena-internal-filter-options{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr));gap:10px;margin:14px 0}
.viena-internal-filter-options label{display:flex;align-items:center;gap:8px;min-width:0;cursor:pointer}
.viena-internal-filter-options input{width:16px;height:16px;accent-color:#1976d2}
.viena-internal-filter-bar p{margin:8px 0;line-height:1.4}
.theme--dark .viena-internal-filter-bar button{color:#90caf9;border-color:#90caf9}`;
            document.head.append(style);
        }
        if (!filterStates.has(storageKey)) {
            const state = { hidden:[], order:[], loaded:!user, loading:false, error:false };
            filterStates.set(storageKey,state);
        }
        const state = filterStates.get(storageKey);
        if (filterView?.panel !== panel || filterView.user !== user || filterView.scope !== scope || !filterView.bar.isConnected) {
            filterView?.header?.classList.remove('viena-filter-header-wrap');
            filterView?.bar.remove();
            const bar=document.createElement('div'); bar.className='viena-internal-filter-bar';
            const toggle=document.createElement('button'); toggle.type='button'; toggle.textContent='⚙ Personalizar vista';
            toggle.setAttribute('aria-expanded','false'); toggle.setAttribute('aria-controls','viena-internal-filter-menu');
            const menu=document.createElement('div'); menu.id='viena-internal-filter-menu'; menu.className='viena-internal-filter-menu'; menu.hidden=true;
            menu.setAttribute('role','region'); menu.setAttribute('aria-label','Personalizar filtros visibles');
            const hint=document.createElement('p'); hint.textContent='Elegí qué filtros mostrar. Arrastrá desde ⠿ para reubicarlos. Vista previa en tiempo real; Aplicar guarda los cambios. Ocultarlos no borra sus valores: los filtros aplicados siguen activos.';
            const options=document.createElement('div'); options.className='viena-internal-filter-options';
            const status=document.createElement('p'); status.setAttribute('role','status');
            const show=document.createElement('button'); show.type='button'; show.textContent='Mostrar todos';
            const apply=document.createElement('button'); apply.type='button'; apply.textContent='Aplicar';
            const cancel=document.createElement('button'); cancel.type='button'; cancel.textContent='Cancelar';
            menu.append(hint,options,show,apply,cancel,status); bar.append(toggle,menu);
            panel.insertBefore(bar,panel.querySelector(':scope > .v-expansion-panel-content'));
            const view=filterView={panel,user,scope,bar,toggle,menu,options,status,show,apply,cancel,fields,signature:'',busy:false,draft:null,orderDraft:null};
            const close=()=>{if(view.busy)return;view.draft=null;view.orderDraft=null;view.dragName='';menu.hidden=true;toggle.setAttribute('aria-expanded','false');refreshInternalFilters();toggle.focus();};
            toggle.onclick=event=>{event.stopPropagation();if(view.busy)return;if(!menu.hidden){close();return;}if(state.error){state.error=false;state.loaded=false;}view.signature='';refreshInternalFilters();menu.hidden=false;toggle.setAttribute('aria-expanded','true');};
            cancel.onclick=close;
            options.onchange=()=>{
                if(view.busy||!user||!state.loaded||state.error)return;
                view.draft=[...state.hidden.filter(name=>!view.fields.some(field=>field.name===name)),
                    ...[...options.querySelectorAll('input')].filter(input=>!input.checked).map(input=>input.dataset.filter)];
                status.textContent='Vista previa. Aplicá para guardar los cambios.';
                refreshInternalFilters();
            };
            show.onclick=()=>{options.querySelectorAll('input').forEach(input=>{input.checked=true;});options.onchange();};
            bar.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();close();}});
            apply.onclick=async()=>{
                if(view.busy || !user || !state.loaded || state.error)return;
                const hidden=[...options.querySelectorAll('input')].filter(input=>!input.checked).map(input=>input.dataset.filter);
                // Preserve preferences for temporarily absent native filters.
                const next=[...state.hidden.filter(name=>!view.fields.some(field=>field.name===name)),...hidden];
                const nextOrder=view.orderDraft||state.order;
                view.busy=true; refreshInternalFilters(); status.textContent='Guardando…';
                try {
                    await bounded(chrome.storage.local.set({[storageKey]:next,[orderKey]:nextOrder}));
                    state.hidden=next;state.order=nextOrder;
                    status.textContent='Vista guardada para tu usuario.';
                    view.busy=false; close();
                } catch (_) { status.textContent='No se pudo guardar. Volvé a intentar.'; }
                finally { view.busy=false; refreshInternalFilters(); }
            };
        }
        const view=filterView; view.fields=fields;
        const header=panel.querySelector(':scope > .v-expansion-panel-header');
        const positionSignature=JSON.stringify([panel.clientWidth,header?.textContent,header?.getAttribute('aria-expanded'),view.toggle.offsetWidth]);
        if(header&&(view.positionSignature!==positionSignature||view.header!==header)){
            view.positionSignature=positionSignature;view.header=header;
            panel.classList.add('viena-filter-panel');header.classList.remove('viena-filter-header-wrap');
            const title=header.querySelector(':scope > span'),range=document.createRange();
            if(title)range.selectNodeContents(title);
            const panelRect=panel.getBoundingClientRect(),headerRect=header.getBoundingClientRect();
            const titleRight=title?range.getBoundingClientRect().right:headerRect.left+160;
            const left=Math.max(24,titleRight-panelRect.left+12),width=view.toggle.offsetWidth;
            if(left+width<=panelRect.width-56){
                view.toggle.style.left=left+'px';view.toggle.style.top=(headerRect.top-panelRect.top+Math.max(0,(headerRect.height-view.toggle.offsetHeight)/2))+'px';
            }else{
                header.classList.add('viena-filter-header-wrap');view.toggle.style.left='24px';view.toggle.style.top=(headerRect.bottom-panelRect.top+4)+'px';
            }
        }
        const signature=JSON.stringify(fields.map(field=>field.name));
        if (view.signature!==signature) {
            view.signature=signature; view.options.replaceChildren();
            for (const {name} of fields) {
                const label=document.createElement('label'),input=document.createElement('input');
                input.type='checkbox';input.dataset.filter=name;input.checked=!(view.draft||state.hidden).includes(name);
                const row=document.createElement('div');row.className='viena-internal-filter-option';row.dataset.filter=name;
                const handle=document.createElement('span');handle.className='viena-filter-drag';handle.textContent='⠿';handle.draggable=true;handle.title='Arrastrar '+name;
                handle.ondragstart=event=>{if(view.busy||!user||!state.loaded||state.error){event.preventDefault();return;}view.dragName=name;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',name);};
                const clearDrag=()=>{view.dragName='';view.options.querySelectorAll('.viena-filter-drop').forEach(item=>item.classList.remove('viena-filter-drop'));};
                handle.ondragend=clearDrag;
                row.ondragover=event=>{if(!view.dragName||view.dragName===name||view.busy)return;event.preventDefault();event.dataTransfer.dropEffect='move';row.classList.add('viena-filter-drop');};
                row.ondragleave=()=>row.classList.remove('viena-filter-drop');
                row.ondrop=event=>{
                    if(!view.dragName||view.dragName===name||view.busy)return;
                    event.preventDefault();const source=view.dragName;clearDrag();
                    const order=[...view.options.querySelectorAll('input')].map(item=>item.dataset.filter).filter(item=>item!==source);
                    order.splice(order.indexOf(name),0,source);
                    view.orderDraft=[...order,...(view.orderDraft||state.order).filter(item=>!order.includes(item))];
                    view.status.textContent='Vista previa. Aplicá para guardar los cambios.';refreshInternalFilters();
                };
                label.append(input,document.createTextNode(name));row.append(handle,label);
                view.options.append(row);
            }
        }
        const preferred=view.orderDraft||state.order;
        const order=[...preferred.filter(name=>fields.some(field=>field.name===name)),...fields.map(field=>field.name).filter(name=>!preferred.includes(name))];
        for (const {column,name} of fields) {
            if(!column)continue;
            column.classList.toggle('viena-internal-filter-hidden',!!user && state.loaded && (view.draft||state.hidden).includes(name));
            column.classList.add('viena-filter-ordered');column.style.setProperty('--viena-filter-order',String(order.indexOf(name)-order.length));
        }
        const rows=[...view.options.children];
        order.forEach((name,index)=>{
            const row=rows.find(item=>item.dataset.filter===name);
            if(row&&view.options.children[index]!==row)view.options.insertBefore(row,view.options.children[index]||null);
        });
        for (const input of view.options.querySelectorAll('input')) input.disabled=!user||!state.loaded||state.error||view.busy;
        view.apply.disabled=view.show.disabled=!user||!state.loaded||state.error||view.busy;
        view.cancel.disabled=view.toggle.disabled=view.busy;
        if (!user) view.status.textContent='Esperando identificar tu usuario VIENA para guardar tu vista.';
        else if (!state.loaded && !state.error) view.status.textContent='Cargando tu vista…';
        if (user && !state.loaded && !state.loading && !state.error) {
            state.loading=true;
            void bounded(chrome.storage.local.get([storageKey,orderKey])).then(values=>{
                const value=values[storageKey];
                // New and temporarily absent filters keep their preferences across reloads.
                const validName=name=>typeof name==='string'&&!!name&&clean(name)===name;
                state.hidden=Array.isArray(value)?value.filter(validName):[];
                state.order=Array.isArray(values[orderKey])?[...new Set(values[orderKey].filter(validName))]:[];
                state.loaded=true;state.error=false;
                if(filterView?.user===user&&filterView.scope===scope){filterView.signature='';filterView.status.textContent='Los cambios se guardan para tu usuario.';}
            }).catch(()=>{
                state.error=true;
                if(filterView?.user===user&&filterView.scope===scope)filterView.status.textContent='No se pudo cargar tu vista. Cerrá y volvé a abrir Personalizar vista para reintentar.';
            }).finally(()=>{state.loading=false;if(!state.error)refreshInternalFilters();});
        }
    }
    globalThis.VienaTicketFields = { refresh, mountViewerOption, panelHost, refreshInternalFilters };
    document.addEventListener('viena:ui-refresh', refresh);
    refresh();
})();
