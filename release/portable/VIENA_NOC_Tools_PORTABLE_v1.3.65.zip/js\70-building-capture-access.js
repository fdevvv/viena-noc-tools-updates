/* Optional native screenshots: worker, isolated MIRA bridge, consent page. */
(() => {
  'use strict';
  const TYPE='VIENA_BUILDING_CAPTURE', ORIGIN='https://mira5-gdt.telecentro.net.ar';
  const mira=url=>{try{const u=new URL(url);return u.origin===ORIGIN&&u.pathname==='/cablemodem_frontend.php';}catch{return false;}};
  const bounded=async promise=>{let timer;try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('timeout')),8000);})]);}finally{clearTimeout(timer);}};
  if(typeof document==='undefined'){
    let busy=false,last=0;
    chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
      if(msg?.type!==TYPE)return;
      if(sender.id!==chrome.runtime.id||sender.frameId!==0||!sender.tab?.id||!mira(sender.url)){respond({ok:false,code:'unauthorized'});return;}
      if(!['status','capture'].includes(msg.op)){respond({ok:false,code:'unauthorized'});return;}
      if(busy){respond({ok:false,code:'busy'});return;}
      busy=true;
      bounded((async()=>{
        if(!await chrome.permissions.contains({origins:['<all_urls>']}))return {ok:false,code:'permission_required'};
        const current=async()=>{const tab=await chrome.tabs.get(sender.tab.id),win=await chrome.windows.getLastFocused();return tab.active&&tab.windowId===win.id&&mira(tab.url)&&tab.url===sender.url?tab:null;};
        const tab=await current();if(!tab)return {ok:false,code:'inactive_tab'};
        if(msg.op==='status')return {ok:true};
        const wait=550-(Date.now()-last);if(wait>0)await new Promise(r=>setTimeout(r,wait));
        if(!await current())return {ok:false,code:'inactive_tab'};
        last=Date.now();const image=await chrome.tabs.captureVisibleTab(tab.windowId,{format:'png'});
        if(!await current())return {ok:false,code:'inactive_tab'};
        if(!await chrome.permissions.contains({origins:['<all_urls>']}))return {ok:false,code:'permission_required'};
        if(typeof image!=='string'||!image.startsWith('data:image/png;base64,'))return {ok:false,code:'capture_unavailable'};
        return {ok:true,image};
      })()).then(result=>{busy=false;respond(result);},()=>{busy=false;respond({ok:false,code:'capture_unavailable'});});
      return true;
    });
    return;
  }
  if(location.protocol==='chrome-extension:'){
    if(location.pathname!=='/building-capture-permission.html'||parent===window)return;
    const token=new URLSearchParams(location.search).get('token');if(!/^[a-f0-9]{32}$/.test(token||''))return;
    const report=state=>parent.postMessage({type:TYPE,token,state},ORIGIN);
    globalThis.VienaPermissionUI.run({title:'Habilitar captura de imágenes',message:'Habilitá la captura de imágenes para poder guardar la imagen del edificio. Chrome te pedirá autorización al continuar.',success:'',operation:async()=>{
      if(!await chrome.permissions.request({origins:['<all_urls>']}))throw new DOMException('Permiso no habilitado.','NotAllowedError');
    }}).then(()=>report('granted'),()=>report('denied'));
    return;
  }
  if(!mira(location.href)||window!==top)return;
  let busy=false,expires=0;
  document.addEventListener('click',event=>{
    if(event.isTrusted&&event.target.closest?.('[data-viena-building-image-modal] [data-viena-building-photo-start]'))expires=Date.now()+300000;
  },true);
  async function authorize(){
    const state=await bounded(chrome.runtime.sendMessage({type:TYPE,op:'status'}));
    if(state?.ok||state?.code!=='permission_required')return state||{ok:false,code:'capture_unavailable'};
    return new Promise(resolve=>{
      const token=Array.from(crypto.getRandomValues(new Uint8Array(16)),n=>n.toString(16).padStart(2,'0')).join('');
      const frame=document.createElement('iframe');frame.title='Habilitar captura de imágenes';frame.src=chrome.runtime.getURL('building-capture-permission.html?token='+token);
      frame.style.cssText='position:fixed;inset:0;width:100%;height:100%;border:0;z-index:2147483647;background:transparent';
      let timer;const finish=ok=>{clearTimeout(timer);removeEventListener('message',receive);removeEventListener('pagehide',cancel);frame.remove();resolve({ok,code:ok?undefined:'permission_required'});};
      const cancel=()=>finish(false),receive=e=>{if(e.source===frame.contentWindow&&e.origin===new URL(frame.src).origin&&e.data?.type===TYPE&&e.data.token===token)finish(e.data.state==='granted');};
      addEventListener('message',receive);addEventListener('pagehide',cancel,{once:true});timer=setTimeout(cancel,70000);document.documentElement.append(frame);
    });
  }
  addEventListener('message',event=>{
    const msg=event.data;if(event.source!==window||event.origin!==ORIGIN||msg?.type!==TYPE+'_REQUEST'||!/^[a-f0-9]{32}$/.test(msg.id||'')||!['authorize','capture'].includes(msg.op))return;
    const reply=result=>window.postMessage({type:TYPE+'_REPLY',id:msg.id,...result},ORIGIN);
    if(Date.now()>expires){reply({ok:false,code:'unauthorized'});return;}
    if(busy){reply({ok:false,code:'busy'});return;}busy=true;
    const work=msg.op==='authorize'?authorize():bounded(chrome.runtime.sendMessage({type:TYPE,op:'capture'}));
    work.then(reply,()=>reply({ok:false,code:'capture_unavailable'})).finally(()=>{busy=false;});
  });
})();
