(function(root){
  'use strict';
  const STATE_KEY='viena_access_policy_v1',ALARM='viena-access-policy-v1';
  const protocol=1,enc=new TextEncoder();
  function create(env,config){
    let inFlight=null;
    const bytes=s=>Uint8Array.from(env.atob(s),c=>c.charCodeAt(0));
    const base64=b=>env.btoa(String.fromCharCode(...new Uint8Array(b)));
    const random=()=>base64(env.crypto.getRandomValues(new Uint8Array(32)));
    const channel=/\bDEV\b/i.test(env.manifest.name)?'DEV':'RELEASE';
    const endpointValid=()=>/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(config.endpoint||'');
    async function run(signal){
      if(!config.enabled)return{status:'disabled'};
      if(!endpointValid()||!config.publicKey||!['observe','enforce'].includes(config.mode))return{status:'configuration_required'};
      let state=(await env.storage.get(STATE_KEY))[STATE_KEY]||{};
      const save=async patch=>{if(signal.aborted)throw Error('access_timeout');state={...state,...patch};await env.storage.set({[STATE_KEY]:state});};
      try{
        const identity=await env.getIdentity();
        const match=/^operator:(dev|release):([a-z0-9._-]+):device:(pc-[a-z0-9-]+)$/.exec(identity?.installationId||'');
        const user=String(identity?.user||'').trim().toLowerCase();
        if(!match||match[1]!==channel.toLowerCase()||!user||user==='sin_detectar'||match[2]!==user)return{status:'identity_pending'};
        // Never silently rebind a credential to another operator, device or channel.
        if(state.installationId&&state.installationId!==identity.installationId)return{status:'identity_changed'};
        if(!state.secret){
          const secret=random(),digest=await env.crypto.subtle.digest('SHA-256',bytes(secret));
          await save({secret,credentialId:base64(digest),installationId:identity.installationId,revision:0});
        }
        const request={protocol,op:state.enrolled?'check':'enroll',installationId:identity.installationId,user,channel,runtimeId:env.runtimeId,version:env.manifest.version,credentialId:state.credentialId,nonce:random(),sentAt:env.now()};
        const key=await env.crypto.subtle.importKey('raw',bytes(state.secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
        const proof=base64(await env.crypto.subtle.sign('HMAC',key,enc.encode(JSON.stringify(request))));
        const response=await env.fetch(config.endpoint,{method:'POST',cache:'no-store',redirect:'follow',headers:{'Content-Type':'text/plain;charset=UTF-8'},body:JSON.stringify({...request,proof,...(request.op==='enroll'?{secret:state.secret}:{})}),signal});
        if(!response.ok)throw Error('access_http_'+response.status);
        const url=new URL(response.url);
        if(url.protocol!=='https:'||!['script.google.com','script.googleusercontent.com'].includes(url.hostname))throw Error('access_redirect');
        const raw=await response.text();if(raw.length>16000)throw Error('access_response_size');
        const envelope=JSON.parse(raw);
        if(typeof envelope.body!=='string'||envelope.body.length>8000||typeof envelope.signature!=='string'||envelope.signature.length>1000)throw Error('access_unsigned_response');
        const signingKey=await env.crypto.subtle.importKey('spki',bytes(config.publicKey),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
        if(!await env.crypto.subtle.verify('RSASSA-PKCS1-v1_5',signingKey,bytes(envelope.signature),enc.encode(envelope.body)))throw Error('access_signature');
        const policy=JSON.parse(envelope.body),now=env.now();
        for(const k of ['protocol','nonce','installationId','user','channel','runtimeId','credentialId'])if(policy[k]!==request[k])throw Error('access_binding_'+k);
        if(!Number.isSafeInteger(policy.issuedAt)||!Number.isSafeInteger(policy.expiresAt)||policy.issuedAt>now+120000||policy.issuedAt<now-120000||policy.expiresAt<=now||policy.expiresAt-policy.issuedAt>120000||policy.expiresAt<=policy.issuedAt)throw Error('access_expired');
        if(!Number.isSafeInteger(policy.revision)||policy.revision<1||policy.revision<(state.revision||0)||!['observe','allow','remove'].includes(policy.action))throw Error('access_policy');
        if(signal.aborted)throw Error('access_timeout');
        await save({enrolled:true,revision:policy.revision,lastCheck:now,lastError:'',lastAction:policy.action});
        if(policy.action!=='remove')return{status:policy.action};
        if(policy.verified!==true||policy.armed!==true)throw Error('access_retirement_not_authorized');
        // DEV has no code path that invokes the injected uninstall capability.
        if(channel==='DEV'||config.mode!=='enforce'){
          await save({lastResult:'would_remove',lastResultAt:now});return{status:'would_remove'};
        }
        if(state.attemptRevision===policy.revision&&now-(state.attemptAt||0)<300000)return{status:'retry_deferred'};
        // Re-read current identity after network and before the destructive action.
        const current=await env.getIdentity();
        if(current?.installationId!==request.installationId||String(current?.user||'').trim().toLowerCase()!==request.user)throw Error('access_identity_changed');
        await save({attemptRevision:policy.revision,attemptAt:now,lastResult:'remove_started',lastResultAt:now});
        if(signal.aborted)throw Error('access_timeout');
        await env.uninstall();
        return{status:'remove_started'};
      }catch(error){
        if(!signal.aborted)try{await save({lastError:String(error?.message||error).slice(0,180),lastFailureAt:env.now()});}catch(_){}
        return{status:'error',error:String(error?.message||error).slice(0,180)};
      }
    }
    function check(){
      if(!config.enabled)return Promise.resolve({status:'disabled'});
      if(inFlight)return inFlight;
      const controller=new AbortController();let timer;
      const timeout=new Promise(resolve=>{timer=env.setTimeout(()=>{controller.abort();resolve({status:'error',error:'access_timeout'});},15000);});
      inFlight=Promise.race([Promise.resolve().then(()=>run(controller.signal)),timeout]).catch(e=>({status:'error',error:String(e?.message||e)})).finally(()=>{env.clearTimeout(timer);inFlight=null;});
      return inFlight;
    }
    return Object.freeze({check});
  }
  function install(chrome,config,getIdentity){
    const manifest=chrome.runtime.getManifest();
    const client=create({manifest,runtimeId:chrome.runtime.id,crypto:root.crypto,atob:root.atob.bind(root),btoa:root.btoa.bind(root),now:Date.now,setTimeout:root.setTimeout.bind(root),clearTimeout:root.clearTimeout.bind(root),storage:chrome.storage.local,getIdentity,fetch:root.fetch.bind(root),uninstall:()=>chrome.management.uninstallSelf({showConfirmDialog:false})},config);
    const check=()=>{void client.check();};
    chrome.runtime.onInstalled.addListener(check);chrome.runtime.onStartup.addListener(check);
    chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name===ALARM)check();});
    // No extra alarm, request, credential or storage write while unprovisioned.
    if(config.enabled){void chrome.alarms.create(ALARM,{periodInMinutes:5});check();}
    return client;
  }
  const api=Object.freeze({create,install,STATE_KEY,ALARM});
  root.VienaAccessPolicy=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(globalThis);
