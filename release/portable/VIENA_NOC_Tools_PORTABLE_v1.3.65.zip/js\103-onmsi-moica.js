(() => {
    'use strict';
    // Serialized into the already signed-in top-level HTTPS MOICA tab. The
    // private native child has the same site/scheme as its parent, as in VIENA.
    async function query(name,token,view=false,owner=0,viewportWidth=1000){
        if(location.origin!=='https://moica2.telecentro.net.ar'||location.pathname!=='/buscarTicket.php')return {complete:false,message:'Abrí Buscar Ticket de MOICA e iniciá sesión.'};
        if(window.__vienaOnmsiMoica)return {complete:false,message:'MOICA está finalizando otra consulta ONMSi.'};
        let taskCache;
        if(!view){
            taskCache=window.__vienaOnmsiTaskCache103;
            if(!taskCache||taskCache.owner!==owner||taskCache.token!==token||Date.now()-taskCache.at>=120000){
                taskCache={owner,token,at:Date.now(),items:new Map()};window.__vienaOnmsiTaskCache103=taskCache;
            }
        }
        if(view&&window.__vienaOnmsiViewer){if(window.__vienaOnmsiViewer.token!==token&&window.__vienaOnmsiViewer.owner!==owner)return {complete:false,message:'Hay otro visor ONMSi abierto en MOICA.'};window.__vienaOnmsiViewer.cancel();}
        return new Promise(resolve=>{
            const frame=document.createElement('iframe');frame.title='Consulta privada FO '+name;frame.referrerPolicy='origin';frame.style.cssText='position:absolute;left:-12000px;top:0;width:1000px;height:700px;visibility:hidden';
            if(view){frame.style.width=viewportWidth+'px';frame.style.border='0';}
            const url=new URL('/buscarTicket.php',location.origin);url.searchParams.set(view?'vienaViewerTicket':'vienaNodeSearch',name);url.searchParams.set('vienaViewerSession',token);url.searchParams.set('vienaOnmsi','1');url.searchParams.set('vienaOnmsiRelay','1');
            let settled=false,parents=null,viewerTimer,stopReadiness=()=>{};const tasks=new Map(),actions=new Map();
            const styleKeys=['display','color','background-color','font-family','font-size','font-weight','line-height','text-align','vertical-align','white-space','padding-top','padding-right','padding-bottom','padding-left','margin-top','margin-right','margin-bottom','margin-left','border-top','border-right','border-bottom','border-left','border-radius','float','clear','width','min-width','max-height','overflow','box-sizing','list-style-type','list-style-position','text-decoration','border-collapse','border-spacing','box-shadow'];
            function snapshot(){
                const doc=frame.contentDocument,modal=doc?.getElementById('MO-TKT-VER');if(!modal)throw Error('No se encontró el detalle nativo.');let count=0;actions.clear();
                const walk=node=>{
                    if(++count>15000)throw Error('El detalle excede el límite de lectura.');
                    if(node.nodeType===3)return {text:node.textContent};if(node.nodeType!==1||['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','NOSCRIPT'].includes(node.tagName))return null;
                    const computed=frame.contentWindow.getComputedStyle(node);if(computed.display==='none'||computed.visibility==='hidden')return null;
                    const nav=node.tagName==='A'&&/^#[A-Za-z][\w:.-]*$/.test(node.getAttribute('href')||'')&&doc.getElementById(node.getAttribute('href').slice(1))&&(node.getAttribute('data-toggle')==='tab'||node.getAttribute('data-toggle')==='collapse'||node.closest('ul.nav'));
                    if(node.tagName==='BUTTON'&&!nav)return null;
                    const styles=styleKeys.map(k=>[k,computed.getPropertyValue(k)]).filter(([,v])=>v&&!/url\(|expression|javascript/i.test(v));
                    if(node.classList?.contains('modal-dialog'))for(const pair of styles)if(pair[0]==='margin-left'||pair[0]==='margin-right')pair[1]='auto';
                    if(node.tagName==='INPUT')return !['hidden','password','submit','button'].includes(node.type)&&node.value?{tag:'span',styles,children:[{text:node.value}]}:null;
                    if(node.tagName==='TEXTAREA')return {tag:'pre',styles,children:[{text:node.value}]};
                    if(node.tagName==='SELECT')return {tag:'span',styles,children:[{text:[...node.selectedOptions].map(o=>o.textContent).join(', ')}]};
                    let href;try{if(node.tagName==='A'&&!nav){const u=new URL(node.getAttribute('href'),frame.contentWindow.location.href);if(['https:','http:'].includes(u.protocol)&&!u.username&&!u.password&&u.href.length<4000)href=u.href;}}catch{}
                    const tag=nav?'button':href?'a':['TABLE','THEAD','TBODY','TR','TD','TH','P','PRE','H1','H2','H3','H4','UL','OL','LI','BR','STRONG','B','SPAN','DIV','LABEL'].includes(node.tagName)?node.tagName.toLowerCase():'div';
                    const result={tag,styles,children:[...node.childNodes].map(walk).filter(Boolean)};
                    if(href)result.href=href;if(nav){result.action=String(actions.size+1);actions.set(result.action,node);}if(['TD','TH'].includes(node.tagName)){result.colSpan=node.colSpan;result.rowSpan=node.rowSpan;}return result;
                };
                const tree=walk(modal);if(!tree||JSON.stringify(tree).length>2000000)throw Error('El detalle excede el límite de lectura.');return {complete:true,tree,ticket:name};
            }
            const finish=(message)=>{if(settled)return;settled=true;stopReadiness();clearTimeout(timer);clearTimeout(boot);window.removeEventListener('message',receive);frame.remove();if(window.__vienaOnmsiMoica?.token===token)delete window.__vienaOnmsiMoica;
                if(!parents){resolve({complete:false,message:message||'MOICA no confirmó el listado de tickets FO.'});return;}
                const items=parents.map(parent=>{
                    const details=tasks.get(parent.number);
                    const tasksComplete=details?.ok===true&&Array.isArray(details.tasks);
                    return {ticket:parent.number,ticketState:parent.state,problem:parent.problem,tasks:tasksComplete?details.tasks:[],tasksComplete};
                });
                const incomplete=message||(items.some(item=>!item.tasksComplete)?'No se completó la lectura de tareas de todos los FO.':'');
                resolve(incomplete?{complete:false,message:incomplete,items}:{complete:true,items});
            };
            function viewerReady(){
                if(settled)return;
                    try{
                        const data=snapshot();let navigating=false;
                        const cancel=()=>{clearTimeout(viewerTimer);frame.remove();window.removeEventListener('pagehide',cancel);if(window.__vienaOnmsiViewer?.token===token)delete window.__vienaOnmsiViewer;};
                        const keep=()=>{clearTimeout(viewerTimer);viewerTimer=setTimeout(cancel,180000);};
                        window.__vienaOnmsiViewer={token,owner,cancel,navigate:async action=>{
                            if(navigating)return {complete:false,message:'Esperá a que termine de cargar la pestaña.'};const target=actions.get(action);if(!target?.isConnected)return {complete:false,message:'La pestaña del visor cambió; volvé a abrir el ticket.'};navigating=true;
                            try{target.click();await new Promise(r=>setTimeout(r,200));const deadline=Date.now()+10000;while(Number(frame.contentWindow.jQuery?.active)>0){if(Date.now()>deadline)throw Error('MOICA no completó la pestaña del ticket.');await new Promise(r=>setTimeout(r,100));}keep();return snapshot();}
                            catch(e){return {complete:false,message:e.message||'No se pudo leer la pestaña.'};}finally{navigating=false;}
                        }};keep();window.addEventListener('pagehide',cancel,{once:true});
                        settled=true;stopReadiness();clearTimeout(timer);clearTimeout(boot);window.removeEventListener('message',receive);if(window.__vienaOnmsiMoica?.token===token)delete window.__vienaOnmsiMoica;resolve(data);
                    }catch(error){finish(error.message||'No se pudo leer el detalle.');}
            }
            function watchReady(){
                // Only this private modal, until ready/cancel/timeout. Native
                // lookup still belongs to65; no extra open/read-marking call.
                try{
                    const doc=frame.contentDocument,jq=frame.contentWindow.jQuery,modal=doc?.getElementById('MO-TKT-VER');
                    if(settled||frame.contentWindow.location.origin!==location.origin||frame.contentWindow.location.pathname!=='/buscarTicket.php'||!modal||typeof jq!=='function')return;
                    const checkReady=()=>{
                        if(settled||Number(jq.active)!==0)return;
                        const number=String(doc.getElementById('TKT-VER-VISTA-NRO')?.textContent||'').toUpperCase();
                        if(modal.getClientRects().length&&(number.match(/\b\d{6}[A-Z]{2}\d+\b/g)||[]).includes(name.toUpperCase())&&doc.getElementById('TKT-VER-ID')?.value)viewerReady();
                    };
                    const observer=new MutationObserver(checkReady),event='ajaxStop.vienaOnmsi103'+token;
                    stopReadiness=()=>{observer.disconnect();try{jq(doc).off(event,checkReady);}catch{}frame.removeEventListener('load',watchReady);};
                    observer.observe(modal,{attributes:true,childList:true,characterData:true,subtree:true});jq(doc).on(event,checkReady);checkReady();
                }catch{/* The authenticated native message remains the fallback. */}
            }
            const receive=e=>{const d=e.data;if(e.origin!==location.origin||e.source!==frame.contentWindow||d?.token!==token)return;
                if(view&&d.type==='VIENA_MOICA_VIEWER'){
                    if(d.state!=='ready')finish('MOICA no confirmó la apertura del ticket. Revisá permisos y sesión.');else viewerReady();return;
                }
                if(d.type==='VIENA_MOICA_NODE_RESULT'){if(!d.ok||!Array.isArray(d.rows)||d.rows.some(r=>!/^\d{6}FO\d+$/i.test(r.number)))finish(d.message||'La búsqueda FO no llegó completa.');else parents=d.rows;}
                if(d.type==='VIENA_MOICA_NODE_TASKS'){if(d.done)finish();else if(parents?.some(p=>p.number===d.ticket))tasks.set(d.ticket,d);}
            };
            const timer=setTimeout(()=>finish('MOICA no completó la búsqueda nativa dentro del tiempo de espera.'),65000);
            const boot=setTimeout(()=>{try{if(frame.contentWindow.location.pathname!=='/buscarTicket.php'||!frame.contentDocument?.getElementById('grid_TktsBuscar')?.grid)finish('El marco de MOICA no cargó Buscar Ticket. Revisá la sesión y los permisos de la plataforma.');}catch{finish('MOICA redirigió la búsqueda; revisá la sesión.');}},12000);
            window.__vienaOnmsiMoica={token,readTasks:async(ticket,read)=>{
                const live=()=>!settled&&taskCache&&window.__vienaOnmsiTaskCache103===taskCache&&Date.now()-taskCache.at<120000;
                if(live()&&taskCache.items.has(ticket))return taskCache.items.get(ticket).map(t=>({...t}));
                const value=await read();
                if(live()){
                    if(taskCache.items.size>=100)taskCache.items.delete(taskCache.items.keys().next().value);
                    taskCache.items.set(ticket,value.map(t=>({...t})));
                }
                return value;
            },cancel:()=>{if(window.__vienaOnmsiTaskCache103===taskCache)delete window.__vienaOnmsiTaskCache103;finish('Consulta detenida.');}};window.addEventListener('message',receive);if(view)frame.addEventListener('load',watchReady,{once:true});frame.src=url.href;document.body.append(frame);
        });
    }
    globalThis.VienaOnmsiMoica={query};
})();
