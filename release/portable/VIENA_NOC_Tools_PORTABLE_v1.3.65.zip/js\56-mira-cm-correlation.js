/* Cruce Post DS QAM: ventanas del nodo y Fec DS individual. Sin ejecutar HTML remoto. */
(function () {
  'use strict';
  const finite=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0;
  function date(label) {
    const m=String(label).replace(/\\\//g,'/').match(/^(\d{2})\/(\d{2})\/(\d{2}|\d{4}) (\d{2}):(\d{2})$/);
    if(!m)return null;
    const year=+m[3]<100?2000+ +m[3]:+m[3],stamp=Date.UTC(year,+m[2]-1,+m[1],+m[4],+m[5]),d=new Date(stamp);
    return d.getUTCFullYear()===year&&d.getUTCMonth()===+m[2]-1&&d.getUTCDate()===+m[1]&&+m[4]<24&&+m[5]<60?stamp:null;
  }
  function cadence(points) {
    const gaps=points.slice(1).map((p,i)=>p.stamp-points[i].stamp).filter(n=>n>0).sort((a,b)=>a-b);
    return gaps.length?gaps[Math.floor((gaps.length-1)/2)]:0;
  }
  function bands(source,threshold=40) {
    if(threshold!==null&&(!finite(threshold)||threshold>100))throw Error('invalid-threshold');
    const points=(source.samples||[]).slice().sort((a,b)=>a.stamp-b.stamp),step=cadence(points),result=[];
    if(threshold===null){if(!points.length)return [];const known=points.filter(p=>finite(p.percent)),peak=known.length?known.reduce((a,b)=>a.percent>b.percent?a:b):{stamp:points[0].stamp,percent:null,count:null};return [{start:points[0].stamp,end:points.at(-1).stamp,from:points[0].stamp,to:points.at(-1).stamp,peak,samples:points}];}
    let current=null;
    for(let i=0;i<points.length;i++) {
      const p=points[i];
      if(!finite(p.percent)||p.percent<threshold){current=null;continue;}
      if(!current||(step&&p.stamp-current.end>Math.min(step*1.5,90*60000))) {
        current={start:p.stamp,end:p.stamp,from:p.stamp-Math.min(step/2,45*60000),to:p.stamp,peak:p,samples:[]};result.push(current);
      }
      current.end=p.stamp;current.to=p.stamp+Math.min(step/2,45*60000);current.samples.push(p);
      if(p.percent>current.peak.percent)current.peak=p;
    }
    return result;
  }
  function correlate(points,windows) {
    const hits=[],seen=new Set(),observedDays=new Set(),events=new Map();let observed=0;
    for(const p of points) {
      const index=windows.findIndex(w=>p.stamp>=w.from&&p.stamp<=w.to);
      if(index<0||!finite(p.value))continue;
      observed++;seen.add(index);observedDays.add(new Date(p.stamp).toISOString().slice(0,10));
      if(p.value>=1e-9){const hit={...p,event:index};hits.push(hit);if(!events.has(index))events.set(index,[]);events.get(index).push(hit);}
    }
    const hours=new Map();for(const p of hits){const d=new Date(p.stamp),hour=d.getUTCHours();if(!hours.has(hour))hours.set(hour,new Set());hours.get(hour).add(d.toISOString().slice(0,10));}
    return {hits,observed,observedDays:[...observedDays].sort(),observedEvents:[...seen],events:[...events.keys()],days:[...new Set(hits.map(p=>new Date(p.stamp).toISOString().slice(0,10)))].sort(),repeatedHours:[...hours].filter(([,days])=>days.size>=2).map(([hour,days])=>({hour,days:[...days].sort()}))};
  }
  function reproject(task,threshold) {
    const windows=bands(task.source,threshold);
    task.threshold=threshold;task.windows=windows;task.filterRevision=(task.filterRevision||0)+1;
    for(const row of task.results)row.match=correlate(row.points,windows);
    return task;
  }
  // Lee solamente literales JSON de arrays. No eval, Function ni inserción de scripts.
  function array(text,index) {
    const start=text.indexOf('[',index);if(start<0)throw Error('missing-array');
    let depth=0,quote='',escape=false;
    for(let i=start;i<text.length;i++) {
      const c=text[i];if(quote){if(escape)escape=false;else if(c==='\\')escape=true;else if(c===quote)quote='';continue;}
      if(c==='"'||c==="'"){quote=c;continue;}if(c==='[')depth++;if(c===']'&&!--depth)return {raw:text.slice(start,i+1),end:i+1};
    }
    throw Error('incomplete-array');
  }
  function parseHistory(html,mac) {
    const starts=[...String(html).matchAll(/Highcharts\.chart\(\s*['"]chart-gral-erroresDs['"]\s*,/g)];
    if(starts.length!==1)throw Error(starts.length?'ambiguous-history':'missing-history');
    const rest=String(html).slice(starts[0].index),next=rest.slice(1).search(/Highcharts\.chart\(/),text=next<0?rest:rest.slice(0,next+1);
    const title=text.match(/title\s*:\s*\{\s*text\s*:\s*['"]([^'"]+)['"]/);
    if(!title||title[1].trim().toLowerCase()!==mac.toLowerCase()+' - fec ds')throw Error('history-identity');
    const ci=text.search(/categories\s*:/),si=text.search(/series\s*:/);if(ci<0||si<0)throw Error('missing-history');
    const categories=JSON.parse(array(text,ci).raw),series=array(text,si).raw;
    const names=[...series.matchAll(/["']?name["']?\s*:\s*['"](Pre|Post)['"]/g)],posts=names.filter(m=>m[1]==='Post');if(posts.length!==1)throw Error('ambiguous-post');
    const post=posts[0],following=names.find(m=>m.index>post.index),part=series.slice(post.index,following?.index||series.length),di=part.search(/["']?data["']?\s*:/);if(di<0)throw Error('missing-post');
    const values=JSON.parse(array(part,di).raw);if(values.length!==categories.length)throw Error('incomplete-history');
    const pres=names.filter(m=>m[1]==='Pre');if(pres.length>1)throw Error('ambiguous-pre');let preValues=categories.map(()=>null);
    if(pres.length){const first=pres[0],last=names.find(m=>m.index>first.index),prePart=series.slice(first.index,last?.index||series.length),data=prePart.search(/["']?data["']?\s*:/);if(data<0)throw Error('missing-pre');preValues=JSON.parse(array(prePart,data).raw);if(preValues.length!==categories.length||preValues.some(v=>v!==null&&!finite(v)))throw Error('invalid-pre');}
    const native=typeof module==='object'&&module.exports?require('./58-mira-native-chart.js'):window.__VIENA_MIRA_NATIVE__;const nativeOptions=native.history(text);
    const seen=new Set();const points=categories.map((label,i)=>{const stamp=date(label);if(stamp===null)throw Error('invalid-date');if(seen.has(stamp))throw Error('duplicate-date');seen.add(stamp);const value=values[i];if(value!==null&&!finite(value))throw Error('invalid-value');return {stamp,value,pre:preValues[i]};}).sort((a,b)=>a.stamp-b.stamp);Object.defineProperty(points,'nativeOptions',{value:nativeOptions});return points;
  }
  const field=(row,key)=>row[key]??key.split('.').reduce((v,k)=>v?.[k],row);
  function exclusion(cm) {
    if([cm.name,cm.surname].some(v=>/^AP\b/i.test(String(v||'').trim())))return 'AP';
    if(/\s+y\s+/i.test(cm.street))return 'Cruce de calles';
    return '';
  }
  function parsePowerDs(value){
    if(typeof value!=='number'&&typeof value!=='string')return null;
    const text=String(value).replace(/<[^>]*>/g,'').trim().replace(',','.');
    if(!/^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(text))return null;
    const number=Number(text);return Number.isFinite(number)&&number!==-99?number:null;
  }
  function inventory(rows,node) {
    const result=new Map();
    for(const row of rows) {
      if(String(field(row,'cmNodo.nodoCmts')||'')!==node)throw Error('inventory-node');
      const mac=String(field(row,'mac')||'').trim().slice(0,12).toLowerCase(),equipment=String(field(row,'idequipo')??'');
      if(!/^[a-f0-9]{12}$/.test(mac)||!/^\d+$/.test(equipment))throw Error('inventory-identity');
      const rawBuilding=field(row,'infocliente.edificio.idedificio'),buildingText=typeof rawBuilding==='string'?rawBuilding.trim():typeof rawBuilding==='number'&&Number.isSafeInteger(rawBuilding)&&rawBuilding>=0?String(rawBuilding):'',buildingId=/^\d+$/.test(buildingText)?buildingText:null;
      if(result.has(mac)){if(result.get(mac).equipment!==equipment)throw Error('inventory-identity');if(result.get(mac).buildingId!==buildingId)result.get(mac).buildingId=null;continue;}
      const street=String(field(row,'infocliente.calle')||'Sin calle').trim(),locality=String(field(row,'infocliente.localidad')||'Sin localidad').trim(),height=String(field(row,'infocliente.nro')||'').trim();
      result.set(mac,{mac,equipment,street,locality,height,block:/^\d+$/.test(height)?Math.floor(+height/100)*100:null,client:String(field(row,'infocliente.idcliente')||'Sin cliente'),name:String(field(row,'infocliente.nombre')||''),surname:String(field(row,'infocliente.apellido')||''),pwrDs:parsePowerDs(field(row,'cmPwr.pwrDsTotal')),buildingId});
    }
    return [...result.values()];
  }
  if(typeof module==='object'&&module.exports){module.exports={bands,correlate,reproject,parseHistory,inventory,exclusion,date,parsePowerDs};return;}
  if(location.hostname!=='mira5-gdt.telecentro.net.ar'||!['/stats_frontend.php','/cablemodem_frontend.php'].includes(location.pathname)||window.__VIENA_CM_CORRELATION__)return;
  window.__VIENA_CM_CORRELATION__=true;
  const CHANNEL='viena-mira-post-ds-qam-v1';let channel;
  try{channel=new BroadcastChannel(CHANNEL);}catch{return;}
  if(location.pathname==='/stats_frontend.php') {
    const publisher=crypto.randomUUID(),hooked=new WeakSet();let revision=0,signature='',focusedAt=Date.now(),publishTimer=0;
    function snapshots() {
      const output=[];
      for(const root of document.querySelectorAll('[id$="-dataChart-gral"]')) {
        const charts=(window.Highcharts?.charts||[]).filter(c=>c?.renderTo?.isConnected&&root.contains(c.renderTo)&&!c.renderTo.closest('[data-viena-fec-summary]'));
        for(const chart of charts)if(!hooked.has(chart)&&window.Highcharts.addEvent){hooked.add(chart);window.Highcharts.addEvent(chart,'redraw',schedulePublish);}
        const percent=charts.filter(c=>/^.+?\s+-\s+% de CMs c\/errores de DS\s+-\s+QAM$/i.test(c.options?.title?.text||''));
        if(percent.length!==1)continue;
        const chart=percent[0],node=chart.options.title.text.split(/\s+-\s+/)[0].trim(),expected=root.querySelector('[name="filtro-diasAtras"]')?.getAttribute('elemento');
        if(expected&&expected!==node)continue;
        const count=charts.filter(c=>c.options?.title?.text===node+' - Cant. de CMs c/errores de Ds - QAM'||c.options?.title?.text===node+' - Cant. de CMs c/errores de DS - QAM');
        if(count.length!==1)continue;
        const post=chart.series.filter(s=>s.name==='Post'),counts=count[0].series.filter(s=>s.name==='Post');if(post.length!==1||counts.length!==1)continue;
        const pre=chart.series.filter(s=>s.name==='Pre'),preValues=pre.length===1?pre[0].options.data:[];
        const categories=chart.xAxis[0].categories,values=post[0].options.data,countValues=counts[0].options.data,map=new Map();
        count[0].xAxis[0].categories.forEach((v,i)=>{const t=date(v);if(t!==null)map.set(t,countValues[i]);});
        const samples=categories.map((label,i)=>({stamp:date(label),percent:finite(values[i])?values[i]:null,prePercent:finite(preValues[i])?preValues[i]:null,count:finite(map.get(date(label)))?map.get(date(label)):null})).filter(p=>p.stamp!==null).sort((a,b)=>a.stamp-b.stamp);
        if(!samples.length||new Set(samples.map(p=>p.stamp)).size!==samples.length)continue;
        const nativeCharts=charts.filter(c=>/^.+?\s+-\s+(?:Fec DS global|% de CMs c\/errores de DS|Cant. de CMs c\/errores de D[sS])\s+-\s+QAM$/i.test(c.options?.title?.text||'')).map(c=>JSON.parse(JSON.stringify({chart:c.options.chart,title:c.options.title,credits:c.options.credits,legend:c.options.legend,xAxis:c.options.xAxis,yAxis:c.options.yAxis,tooltip:c.options.tooltip,plotOptions:c.options.plotOptions,series:c.options.series,exporting:c.options.exporting},(key,value)=>typeof value==='function'?undefined:key==='renderTo'?undefined:value)));
        const frequencies=window.__VIENA_FREQUENCY_DS__?.inventory(node)||[];
        const frequencyEndpoint=typeof window.urlChartData==='string'?window.urlChartData:'';
        output.push({node,samples,nativeCharts,frequencies,frequencyEndpoint,frequencyPublisher:publisher});
      }
      return output;
    }
    function publish(target){const sources=snapshots(),next=JSON.stringify(sources);if(next!==signature){signature=next;revision++;}channel.postMessage({type:'sources',publisher,revision,focusedAt,target,sources});}
    function schedulePublish(){clearTimeout(publishTimer);publishTimer=setTimeout(()=>publish(),150);}
    function focus(){if(document.visibilityState==='visible'){focusedAt=Date.now();schedulePublish();}}
    channel.onmessage=event=>{
      const message=event.data;
      if(message?.type==='request')publish(message.client);
      if(message?.type!=='frequency-open'||message.publisher!==publisher||typeof message.client!=='string'||typeof message.requestId!=='string')return;
      const allowed=window.__VIENA_FREQUENCY_DS__?.inventory(message.node)||[];
      const link=allowed.includes(message.frequency)?[...document.querySelectorAll('#TAB-NODOCMTS-DESC .mira-getChartFrec')].find(a=>a.getAttribute('tipo')==='DS'&&a.getAttribute('elemento')===message.node&&a.getAttribute('frec')===message.frequency):null;
      if(link){document.querySelector('a[href="#TAB-NODOCMTS-FREC"]')?.click();link.click();}
      channel.postMessage({type:'frequency-open-result',requestId:message.requestId,target:message.client,ok:!!link});
    };
    if(window.jQuery)window.jQuery(document).on('ajaxComplete.vienaCmSource',schedulePublish);
    window.addEventListener('focus',focus);document.addEventListener('visibilitychange',focus);schedulePublish();
    window.addEventListener('pagehide',()=>{clearTimeout(publishTimer);channel.postMessage({type:'closed',publisher});channel.close();if(window.jQuery)window.jQuery(document).off('ajaxComplete.vienaCmSource',schedulePublish);});
    window.addEventListener('pageshow',event=>{if(event.persisted){const handler=channel.onmessage;channel=new BroadcastChannel(CHANNEL);channel.onmessage=handler;if(window.jQuery)window.jQuery(document).on('ajaxComplete.vienaCmSource',schedulePublish);focus();schedulePublish();}});
    return;
  }
  const $=window.jQuery;let panel=null,selected=null,run=null,refreshTimer=0,selectedSignature='',lastTask=null,threshold=null;
  const client=crypto.randomUUID(),providers=new Map(),sources=new Map(),e=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
  const label=stamp=>{const iso=new Date(stamp).toISOString();return iso.slice(0,10).split('-').reverse().join('/')+' '+iso.slice(11,16);};
  // Guard liviano durante la cola; inventory verifica el nodo de todas las filas antes de consultar historiales.
  function node(){const grid=document.getElementById('grid_cm_gral');if(!grid||!$?.fn?.jqGrid)return '';const ids=$(grid).jqGrid('getDataIDs');const nodes=new Set([ids[0],ids.at(-1)].filter(id=>id!==undefined).map(id=>$(grid).jqGrid('getRowData',id)['cmNodo.nodoCmts']).filter(Boolean));return nodes.size===1?[...nodes][0]:'';}
  function status(text){const target=panel?.querySelector('[data-status]');if(target)target.textContent=text;}
  function stop(message='Análisis detenido. Los CMs pendientes no se consideran normales.') {if(run){const task=run;task.cancelled=true;task.controller?.abort();run=null;renderResults(task);}if(panel){panel.querySelector('[data-start]').disabled=!selected;panel.querySelector('[data-stop]').disabled=true;status(message);}}
  function setSource(source){const custom=panel.querySelector('[aria-label="Porcentaje personalizado del nodo"]'),invalid=custom&&!custom.hidden&&(!finite(custom.valueAsNumber)||custom.valueAsNumber>100),signature=source?JSON.stringify([source.node,source.samples[0].stamp,source.samples.at(-1).stamp]):'';if(signature!==selectedSignature){if(run)stop('Cambió el nodo o el período. Análisis detenido.');window.__VIENA_CM_VIEW__?.clear();lastTask=null;panel.querySelector('[data-results]').replaceChildren();selectedSignature=signature;selected=source;panel.querySelector('[data-start]').textContent='Analizar CMs';status(source?`${threshold===null?'Todo el período, sin mínimo del nodo.':`${bands(source,threshold).length} franjas del nodo con Post DS QAM ≥ ${threshold}%.`} Individual: Post FEC DS ≥ 1,00e-9.`:'Abrí Estadísticas de este mismo nodo y filtrá los días que quieras comparar. El período se sincroniza automáticamente.');}else if(source&&JSON.stringify(source)!==JSON.stringify(selected)){selected=source;if(lastTask){lastTask.source=source;reproject(lastTask,threshold);renderResults(lastTask);}else status(`${threshold===null?'Todo el período, sin mínimo del nodo.':`${bands(source,threshold).length} franjas del nodo con Post DS QAM ≥ ${threshold}%.`} Individual: Post FEC DS ≥ 1,00e-9.`);}panel.querySelector('[data-start]').disabled=!!run||!source||!!invalid;}
  function filterThreshold(){if(lastTask&&selected&&lastTask.node===selected.node){reproject(lastTask,threshold);renderResults(lastTask);status(run?`Analizando CMs: ${lastTask.results.length+lastTask.failed} / ${lastTask.total}…`:`${lastTask.done?'Análisis terminado.':'Análisis detenido; resultado parcial.'} Filtro actualizado sin consultar CMs.`);}else if(selected)status(`${threshold===null?'Todo el período, sin mínimo del nodo.':`${bands(selected,threshold).length} franjas del nodo con Post DS QAM ≥ ${threshold}%.`} La lectura conservará todo el período.`);}
  function choices() {
    if(!panel)return;const select=panel.querySelector('select'),old=select.value;sources.clear();const candidates=[];
    for(const [publisher,provider]of providers)for(const source of provider.sources)if(source.node===node()){const id=publisher+'/'+source.node;sources.set(id,source);candidates.push({id,source,focusedAt:provider.focusedAt});}
    select.replaceChildren(e('option','Período de Estadísticas'));select.firstChild.value='';
    for(const item of candidates){const option=e('option',`${label(item.source.samples[0].stamp)} → ${label(item.source.samples.at(-1).stamp)}`);option.value=item.id;select.append(option);}
    const newest=Math.max(...candidates.map(c=>c.focusedAt)),latest=candidates.filter(c=>c.focusedAt===newest),distinct=new Set(latest.map(c=>JSON.stringify(c.source)));
    const chosen=distinct.size===1?latest.find(c=>c.id===old)||latest[0]:candidates.find(c=>c.id===old);
    if(chosen)select.value=chosen.id;setSource(chosen?.source||null);
    if(!chosen&&candidates.length>1)status('Hay varios períodos abiertos para este nodo. Elegí uno o activá la pestaña de Estadísticas que querés usar.');
  }
  channel.onmessage=event=>{
    const message=event.data;if(message?.type==='closed'&&typeof message.publisher==='string'){providers.delete(message.publisher);choices();return;}
    if(message?.type!=='sources'||message.target&&message.target!==client||typeof message.publisher!=='string'||!Number.isSafeInteger(message.revision)||!Number.isFinite(message.focusedAt)||!Array.isArray(message.sources))return;
    const prior=providers.get(message.publisher);if(prior&&prior.revision>message.revision)return;
    const valid=message.sources.filter(source=>source&&typeof source.node==='string'&&Array.isArray(source.samples)&&source.samples.length&&source.samples.length<=100000&&!source.samples.some((p,i)=>!p||!Number.isSafeInteger(p.stamp)||Math.abs(p.stamp)>8640000000000000||i&&p.stamp<=source.samples[i-1].stamp||p.percent!==null&&(!finite(p.percent)||p.percent>100)||p.count!==null&&!finite(p.count)));
    providers.set(message.publisher,{sources:valid,revision:message.revision,focusedAt:message.focusedAt});choices();
  };
  function request(){channel.postMessage({type:'request',client});}
  async function read(url,signal,type) {
    const timeout=new AbortController(),abort=()=>timeout.abort();signal.addEventListener('abort',abort,{once:true});const timer=setTimeout(abort,20000);
    try {if(signal.aborted)throw Error('cancelled');const response=await fetch(url,{signal:timeout.signal,credentials:'same-origin'});if(!response.ok||response.redirected)throw Error('request-failed');return type==='json'?await response.json():await response.text();}
    finally {clearTimeout(timer);signal.removeEventListener('abort',abort);}
  }
  async function allRows(task) {
    const grid=document.getElementById('grid_cm_gral'),p=grid.p;
    if(!p||p.search||p.postData?._search===true||p.postData?._search==='true')throw Error('filtered-inventory');
    const ids=$(grid).jqGrid('getDataIDs'),records=Number(p.records);
    if(!Number.isSafeInteger(records)||records<0)throw Error('unknown-inventory');
    if(ids.length===records)return inventory(ids.map(id=>$(grid).jqGrid('getRowData',id)),task.node);
    const url=new URL(p.url,location.href);if(url.origin!==location.origin||url.pathname!=='/controller_grid_mira_cm.php')throw Error('inventory-url');
    const rows=[],names=p.prmNames||{},size=Number(p.rowNum);if(!Number.isSafeInteger(size)||size<1)throw Error('inventory-pages');
    let page=1,total=1;
    do {
      if(task.cancelled||node()!==task.node)throw Error('cancelled');
      const query=new URL(url);for(const [k,v]of Object.entries(p.postData||{}))if(typeof v!=='function')query.searchParams.set(k,String(v));
      query.searchParams.set(names.page||'page',page);query.searchParams.set(names.rows||'rows',size);query.searchParams.set(names.sort||'sidx',p.sortname||'');query.searchParams.set(names.order||'sord',p.sortorder||'asc');
      const response=await read(query,task.controller.signal,'json');total=Number(response.total);
      if(Number(response.page)!==page||Number(response.records)!==records||!Number.isSafeInteger(total)||total<page||!Array.isArray(response.rows)||response.rows.length!==Math.min(size,records-rows.length))throw Error('incomplete-inventory');
      rows.push(...response.rows);page++;
    }while(page<=total);
    if(rows.length!==records)throw Error('incomplete-inventory');const normalized=inventory(rows,task.node);if(normalized.length!==records)throw Error('unstable-inventory');return normalized;
  }
  function renderResults(task) {
    lastTask=task;if(window.__VIENA_CM_VIEW__){window.__VIENA_CM_VIEW__.render(panel.querySelector('[data-results]'),task);document.dispatchEvent(new Event('viena-cm-view-updated'));return;}
    const output=panel.querySelector('[data-results]');output.replaceChildren();const completed=task.results.length,matched=task.results.filter(r=>r.match.hits.length),valid=task.results.filter(r=>r.match.observed),failed=task.failed;
    output.append(e('p',`${completed + failed} / ${task.total} CMs procesados · ${matched.length} coinciden · ${matched.filter(r=>r.match.days.length>=2).length} se repiten en distintos días · ${valid.length} con datos en las franjas · ${failed} sin historial verificable. Resultado ${task.done?'final':'parcial'}.`));
    const zones=new Map();for(const row of task.results){const cm=row.cm,key=JSON.stringify([cm.street,cm.block]);if(!zones.has(key))zones.set(key,[]);zones.get(key).push(row);}
    const container=e('div');container.className='vcm-zones';
    for(const rows of [...zones.values()].sort((a,b)=>b.filter(r=>r.match.hits.length).length-a.filter(r=>r.match.hits.length).length)) {
      const affected=rows.filter(r=>r.match.hits.length);if(!affected.length)continue;
      const cm=rows[0].cm,covered=rows.filter(r=>r.match.observed).length,details=e('details'),title=e('summary',`${cm.street} ${cm.block===null?'Sin altura':cm.block+'–'+(cm.block+99)} · ${affected.length} CMs coinciden`);details.append(title,e('p',`${affected.length} / ${covered} CMs con muestras en alguna franja (${covered?Math.round(affected.length/covered*100):0}%). Este porcentaje resume el período; no es el porcentaje simultáneo del nodo.`));
      for(const row of affected){const item=e('details');item.append(e('summary',`${row.cm.mac} · Cliente ${row.cm.client} · ${row.cm.street} ${row.cm.height} · ${row.match.days.length} días · ${row.match.events.length} eventos`));
        item.append(e('p',`Coincide en ${row.match.days.length} de ${row.match.observedDays.length} días con datos durante las franjas del nodo.`));
        if(row.match.days.length>=2)item.append(e('p',row.match.repeatedHours.length?`Horas que se repiten: ${row.match.repeatedHours.map(h=>`${String(h.hour).padStart(2,'0')}:00–${String(h.hour+1).padStart(2,'0')}:00 (${h.days.length} días)`).join(' · ')}.`:'El mismo CM coincide en varios días, sin una hora compartida entre días.'));
        for(const index of row.match.events){const w=task.windows[index],hits=row.match.hits.filter(p=>p.event===index),peak=hits.reduce((a,b)=>a.value>b.value?a:b);item.append(e('p',`Nodo: ${label(w.start)} → ${label(w.end)} · pico ${w.peak.percent}% / ${w.peak.count??'Sin dato'} CMs (${label(w.peak.stamp)}). CM: ${label(hits[0].stamp)} → ${label(hits.at(-1).stamp)} · Post máximo ${peak.value.toExponential(2)} (${label(peak.stamp)}).`));}
        details.append(item);
      }container.append(details);
    }
    output.append(container);
    const missing=[...task.failures,...task.results.filter(r=>!r.match.observed).map(r=>r.cm)];if(missing.length){const details=e('details');details.append(e('summary',`Ver CMs sin cobertura verificable (${missing.length})`));for(const cm of missing)details.append(e('p',`${cm.mac} · ${cm.street} ${cm.height}`));output.append(details);}
    const events=e('details');events.append(e('summary','Ver cobertura por franja del nodo'));
    task.windows.forEach((w,i)=>{const observed=task.results.filter(r=>r.match.observedEvents.includes(i)).length,hit=task.results.filter(r=>r.match.events.includes(i)).length;events.append(e('p',`${label(w.start)} → ${label(w.end)} · ${hit} CMs coinciden / ${observed} con datos · ${task.total-observed} pendientes o sin cobertura.`));});output.append(events);
    output.append(e('p','Franjas aproximadas según el muestreo del nodo; faltantes no prueban normalidad. Coincidencias por dirección no determinan la causa ni la topología de red. El inventario es el actual. DS OFDM no se cruza en este análisis.'));
  }
  async function start() {
    if(run||!selected)return;if(selected.node!==node()){request();return;}const task={node:node(),source:selected,threshold,windows:bands(selected,threshold),controller:new AbortController(),cancelled:false,results:[],failures:[],failed:0,total:0,done:false};
    run=task;window.__VIENA_CM_VIEW__?.clear();lastTask=task;panel.querySelector('[data-start]').disabled=true;panel.querySelector('[data-stop]').disabled=false;panel.querySelector('[data-results]').replaceChildren();
    try {
      status('Leyendo el inventario completo del nodo…');const inventoryCms=await allRows(task),cms=inventoryCms.filter(cm=>!exclusion(cm));task.excluded=inventoryCms.length-cms.length;task.total=cms.length;
      task.inventoryCms=inventoryCms;
      const powerReference=window.UMBRALES?.ds?.pwr;task.powerReference=powerReference&&Number.isFinite(powerReference.min)&&Number.isFinite(powerReference.max)&&powerReference.min<=powerReference.max?{min:powerReference.min,max:powerReference.max}:null;
      const endpoint=new URL(window.URL_cm_graf||'',location.href);if(endpoint.origin!==location.origin||endpoint.pathname!=='/tabs/cablemodem_tab_cms_graficos.php')throw Error('history-url');
      const from=new Date(task.source.samples[0].stamp).toISOString().slice(0,10),to=new Date(task.source.samples.at(-1).stamp).toISOString().slice(0,10);
      for(const cm of cms) {
        if(task.cancelled||node()!==task.node)throw Error('cancelled');status(`Analizando CMs: ${task.results.length+task.failed} / ${cms.length}…`);
        const url=new URL(endpoint);for(const [key,value]of Object.entries({flag:'gral',mac:cm.mac,idequipo:cm.equipment,diasatras:'',fechadesde:from,fechahasta:to}))url.searchParams.set(key,value);
        try {const html=await read(url,task.controller.signal,'text');if(task.cancelled||node()!==task.node)throw Error('cancelled');const points=parseHistory(html,cm.mac);task.results.push({cm,points,nativeOptions:points.nativeOptions,match:correlate(points,task.windows)});}
        catch(error){if(task.cancelled||node()!==task.node)throw error;task.failed++;task.failures.push(cm);}
        if(!task.cancelled)renderResults(task);
      }
      task.done=true;renderResults(task);panel.querySelector('[data-start]').textContent='Volver a analizar';status('Análisis terminado. Elegí una cuadra para ver los gráficos de sus CMs.');
    }catch(error){if(!task.cancelled)status(error.message==='filtered-inventory'?'Quitá los filtros de columnas de la grilla general para analizar todos los CMs del nodo.':'No se pudo completar el análisis. Verificá el nodo, el listado y la sesión; los datos faltantes no se consideran normales.');}
    finally {if(run===task){run=null;panel.querySelector('[data-start]').disabled=false;panel.querySelector('[data-stop]').disabled=true;}}
    if(task.done&&!task.cancelled&&lastTask===task&&selected===task.source&&node()===task.node)window.__VIENA_FREQUENCY_DS__?.autoStart(task,()=>renderResults(task));
  }
  function mount() {
    if(!document.getElementById('grid_cm_gral')||!$?.fn?.jqGrid)return;
    if(panel?.isConnected){if(node()!==panel.dataset.node){stop('Cambió el nodo. Análisis detenido.');panel.dataset.node=node();choices();request();}return;}
    stop();panel=e('section');panel.className='viena-cm-correlation';panel.dataset.vienaCmCorrelation='';panel.append(e('strong','Cruce Post DS QAM · nodo / CMs'));
    const actions=e('div');actions.className='vcm-toolbar';const select=e('select');select.setAttribute('aria-label','Período de Estadísticas');select.addEventListener('change',()=>setSource(sources.get(select.value)||null));actions.append(select);
    const thresholdLabel=e('label','Afectación del nodo: '),thresholdSelect=e('select');thresholdSelect.dataset.threshold='';thresholdSelect.setAttribute('aria-label','Umbral de afectación del nodo');
    for(const [value,text]of [['none','Sin mínimo · todo el período'],['10','Desde 10%'],['20','Desde 20%'],['40','Desde 40%'],['custom','Personalizado']]){const option=e('option',text);option.value=value;thresholdSelect.append(option);}thresholdSelect.value=threshold===null?'none':['10','20','40'].includes(String(threshold))?String(threshold):'custom';
    const custom=e('input');custom.type='number';custom.min='0';custom.max='100';custom.step='any';custom.value=String(threshold??40);custom.hidden=thresholdSelect.value!=='custom';custom.style.width='85px';custom.setAttribute('aria-label','Porcentaje personalizado del nodo');
    function changeThreshold(){custom.hidden=thresholdSelect.value!=='custom';const next=thresholdSelect.value==='none'?null:thresholdSelect.value==='custom'?custom.valueAsNumber:Number(thresholdSelect.value);if(next!==null&&(!finite(next)||next>100)){panel.querySelector('[data-start]').disabled=true;status('Ingresá un porcentaje entre 0 y 100. Se conserva el último filtro válido.');return;}threshold=next;setSource(sources.get(select.value)||null);filterThreshold();}
    thresholdSelect.addEventListener('change',changeThreshold);custom.addEventListener('input',changeThreshold);thresholdLabel.append(thresholdSelect);actions.append(thresholdLabel,custom);
    const refresh=e('button','Actualizar períodos');refresh.type='button';refresh.addEventListener('click',request);actions.append(refresh);
    const startButton=e('button','Analizar CMs');startButton.type='button';startButton.dataset.start='';startButton.disabled=true;startButton.addEventListener('click',start);actions.append(startButton);
    const stopButton=e('button','Detener');stopButton.type='button';stopButton.dataset.stop='';stopButton.disabled=true;stopButton.addEventListener('click',()=>stop());actions.append(stopButton);panel.append(actions);
    const statusLine=e('p');statusLine.dataset.status='';statusLine.setAttribute('role','status');panel.append(statusLine);const output=e('div');output.dataset.results='';panel.append(output);
    panel.dataset.node=node();const anchor=document.getElementById('gbox_grid_cm_gral')||document.getElementById('grid_cm_gral');anchor.before(panel);request();
  }
  function schedule(){clearTimeout(refreshTimer);refreshTimer=setTimeout(mount,100);}
  if($)$(document).on('ajaxComplete.vienaCmCorrelation',schedule);mount();
  function focus(){if(document.visibilityState==='visible')request();}
  window.addEventListener('focus',focus);document.addEventListener('visibilitychange',focus);
  window.addEventListener('pagehide',()=>{stop();window.__VIENA_CM_VIEW__?.clear();clearTimeout(refreshTimer);channel.close();if($)$(document).off('ajaxComplete.vienaCmCorrelation',schedule);});
  window.addEventListener('pageshow',event=>{if(event.persisted){const handler=channel.onmessage;channel=new BroadcastChannel(CHANNEL);channel.onmessage=handler;if($)$(document).on('ajaxComplete.vienaCmCorrelation',schedule);request();schedule();if(lastTask&&!run)renderResults(lastTask);}});
})();
