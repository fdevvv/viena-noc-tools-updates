(() => {
    'use strict';
    if(location.origin!=='http://onmsi.telecentro.net.ar'||window!==top||globalThis.__vienaOnmsi103)return;
    globalThis.__vienaOnmsi103=true;const api=VienaOnmsi;let active;
    const nonce=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),v=>v.toString(16).padStart(2,'0')).join('');
    const el=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
    function send(type,data,token,timeout=70000){return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('La operación superó el tiempo de espera.')),timeout);try{chrome.runtime.sendMessage({type:'ONMSI_103_'+type,token,...data},r=>{clearTimeout(timer);if(chrome.runtime.lastError||!r?.ok)reject(Error(r?.message||'Recargá ONMSi después de recargar DEV.'));else resolve(r.data);});}catch(e){clearTimeout(timer);reject(e);}});}
    const anchor=(label,url)=>{const a=el('a',label);a.href=url;a.target='_blank';a.rel='noopener noreferrer';return a;};
    function close(){if(!active)return;const c=active;active=null;c.stopped=true;c.stopQueue?.();c.stopQuery?.();c.stopViewer?.();void send('CANCEL',{},c.token,3000).catch(()=>{});c.host.remove();c.focus?.focus();}
    function modal(id){
        if(active)return;const host=el('div');host.id='viena-onmsi-modal';host.style.cssText='position:fixed;inset:0;z-index:2147483646';const shadow=host.attachShadow({mode:'open'}),css=el('style');
        css.textContent=`:host{font:14px Arial;color:#173247}*{box-sizing:border-box}.shade{position:absolute;inset:0;background:#09223399;display:flex;align-items:center;justify-content:center;padding:16px}.panel{width:920px;max-width:100%;max-height:92vh;overflow:auto;background:white;padding:20px;border-radius:12px;box-shadow:0 12px 40px #0004}.head,.actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.head{justify-content:space-between;position:sticky;top:-20px;background:white;padding:10px 0;z-index:1}h2{font-size:20px;margin:0}button,select{font:inherit;border:1px solid #b5ccda;padding:8px 12px;border-radius:6px;background:#eff6fb;color:#173247;cursor:pointer}button:disabled{opacity:.5;cursor:default}.primary{background:#006b9d;color:white}.fields{display:grid;grid-template-columns:145px 1fr;gap:8px;margin:16px 0}.label{font-weight:bold}.value{white-space:pre-wrap;overflow-wrap:anywhere}a{color:#006b9d;overflow-wrap:anywhere}.notice{padding:12px;background:#edf6fc;border-radius:8px}.node{padding:12px;border:1px solid #cbdce7;border-radius:8px;margin:12px 0}h3{font-size:16px}.error,.down{color:#b11924}.up{color:#16713e}.partial{color:#a05a00}.muted{color:#526b7d}.chooser{margin:18px 0;padding:16px;border:1px solid #d6e2ea;border-radius:8px;background:#f6f9fb;gap:16px;align-items:flex-end}.chooser label{display:flex;flex-direction:column;gap:10px}.chooser select{min-width:180px}.fo-results .node p{margin:7px 0}.fo-results .node h3{margin:0 0 10px}.nodes-scroll{overflow:auto;border:1px solid #cbdce7;border-radius:8px}.nodes-table{border-collapse:collapse;width:100%;min-width:650px;font-size:13px}.nodes-table td,.nodes-table th{padding:10px;border-bottom:1px solid #dde7ee;text-align:left;vertical-align:top}.nodes-table th{background:#edf6fc}.nodes-table p{margin:0 0 6px}.polling{min-width:110px}.ticket-view{margin-top:16px;overflow:auto;line-height:1.6}.ticket-view table{border-collapse:collapse;width:100%}.ticket-view td,.ticket-view th{padding:8px;border:1px solid #d6e2ea;text-align:left}.ticket-view pre{white-space:pre-wrap;overflow-wrap:anywhere}.ticket{border-top:1px solid #dde7ee;padding:8px 0}iframe.viewer{width:100%;height:65vh;border:1px solid #cbdce7}[hidden]{display:none!important}button:focus-visible,a:focus-visible,select:focus-visible{outline:3px solid #009bd5}@media(max-width:520px){.shade{padding:8px}.panel{padding:12px}.head{top:-12px}.fields{grid-template-columns:1fr}.value{margin-bottom:6px}.actions button{flex:1}}`;
        css.textContent+='.panel.ticket-open{position:relative;width:88vw;height:82vh;max-height:82vh;overflow:hidden;padding:10px}.ticket-overlay{position:absolute;inset:76px 20px 20px;z-index:2;display:flex;flex-direction:column;min-height:0;background:white;border:1px solid #b5ccda;border-radius:8px;padding:0}.ticket-overlay>header{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;flex:none}.panel.ticket-open .head h2{flex:1}.ticket-overlay>header h3{margin:0}.ticket-overlay>.ticket-view{flex:1;min-height:0;margin-top:0;overflow:hidden}.ticket-view>.native-viewer{display:block;width:100%;height:100%;border:0}@media(max-width:600px){.panel.ticket-open{width:94vw;height:86vh;max-height:86vh}.ticket-overlay{left:12px;right:12px;bottom:12px;padding:0}}';
        const shade=el('div');shade.className='shade';const panel=el('section');panel.className='panel';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.tabIndex=-1;
        const head=el('div');head.className='head';const title=el('h2','Alarma ONMSi · '+id);title.id='onmsi103-title';panel.setAttribute('aria-labelledby',title.id);const exit=el('button','Cerrar');exit.onclick=close;head.append(title,exit);
        const status=el('p','Leyendo detalle…');status.setAttribute('role','status');const fields=el('div');fields.className='fields';const actions=el('div');actions.className='actions';
        const copy=el('button','Copiar información'),refresh=el('button','Actualizar consulta'),create=el('button','Crear ticket en MOICA');create.className='primary';copy.disabled=refresh.disabled=create.disabled=true;actions.append(copy,refresh,create);
        const chooser=el('div');chooser.className='actions chooser';chooser.hidden=true;const label=el('label','Tipificación (reemplaza el borrador existente): '),select=el('select');select.setAttribute('aria-label','Tipificación de tarea');for(const kind of ['','VAO','VXC','VXA']){const o=el('option',kind||'Elegir tarea');o.value=kind;select.append(o);}label.append(select);const prepare=el('button','Crear ticket');prepare.disabled=true;select.onchange=()=>{prepare.disabled=!select.value;};chooser.append(label,prepare);
        const notice=el('p','Verificando estado y tickets…');notice.className='notice';const results=el('div'),foArea=el('div');foArea.className='fo-results';panel.append(head,status,fields,actions,chooser,results,foArea);shade.append(panel);shadow.append(css,shade);document.body.append(host);
        const c={host,token:nonce(),stopped:false,focus:document.activeElement};active=c;panel.focus();const valid=()=>active===c&&!c.stopped;
        panel.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();if(c.stopViewer)c.stopViewer();else close();}if(e.key==='Tab'){const items=[...(c.viewerSection||panel).querySelectorAll('button:not(:disabled),select:not(:disabled),a[href]')].filter(x=>x.getClientRects().length),first=items[0],last=items.at(-1);if(e.shiftKey&&(shadow.activeElement===first||shadow.activeElement===panel)){e.preventDefault();last?.focus();}else if(!e.shiftKey&&shadow.activeElement===last){e.preventDefault();first?.focus();}}});
        let alarm,scope;
        copy.onclick=()=>{const handler=e=>{e.preventDefault();e.clipboardData.setData('text/plain',api.copy(alarm));};document.addEventListener('copy',handler);try{status.textContent=document.execCommand('copy')?'Información copiada con URLs completas.':'No se pudo copiar; reintentá.';}finally{document.removeEventListener('copy',handler);}};
        create.onclick=()=>{chooser.hidden=!chooser.hidden;select.focus();};
        prepare.onclick=async()=>{prepare.disabled=true;select.disabled=true;create.disabled=true;try{status.textContent='Preparando '+select.value+' en MOICA…';await send('CREATE',{kind:select.value,alarm},c.token);if(valid()){status.textContent='Formulario '+select.value+' preparado en MOICA. Revisá antes de enviar.';chooser.hidden=true;}}catch(e){if(valid())status.textContent=e.message;}finally{if(valid()){select.disabled=false;prepare.disabled=!select.value;create.disabled=false;}}};
        function renderFos(){
            foArea.replaceChildren();if(!c.foGroups?.size)return;foArea.append(el('h3','Tickets FO encontrados'));
            for(const [ticket,g] of c.foGroups){
                const card=el('section');card.className='node';card.dataset.foTicket=ticket;card.append(el('h3','Ticket FO: '+ticket),el('p','Estado: '+[...g.states].join(' / ')),el('p','Problema: '+([...g.problems].join(' / ')||'No informado en la búsqueda')));
                if(g.nodes.size)card.append(el('p','Nodos: '+[...g.nodes].join(', ')));
                if(g.candidates.size){const warning=el('p','Coincidencia por nombre alternativo: '+[...g.candidates].join('; ')+'. Relación con el nodo de la alarma no confirmada.');warning.className='partial';card.append(warning);}
                for(const t of g.tasks.values()){const kind=t.number.match(/^[0-9]{6}(VAO|VXC|VXA)/i)?.[1]||'';card.append(el('p','Tarea '+kind+': '+t.number+' · '+t.state));}
                if(!g.tasksComplete)card.append(el('p','Tareas de campo sin verificar.'));
                else if(!g.tasks.size)card.append(el('p','Sin tareas VAO, VXC o VXA coincidentes.'));
                const actions=el('div');actions.className='actions';actions.style.marginTop='16px';const button=el('button','Ver ticket');button.dataset.onmsiTicket=ticket;button.onclick=()=>void showTicket(ticket);actions.append(button);
                const tracking=el('button','Copiar seguimiento ONMSi'),copyStatus=el('p','Preparando fila de seguimiento…');tracking.dataset.onmsiTrackingTicket=ticket;tracking.disabled=true;copyStatus.setAttribute('role','status');actions.append(tracking);card.append(actions,copyStatus);foArea.append(card);
                const token=c.token,current=()=>valid()&&c.token===token&&card.isConnected;
                if(g.states.size!==1){copyStatus.textContent='Hay estados distintos para este FO. Actualizá la consulta antes de copiar.';continue;}
                const state=[...g.states][0],key=ticket+':'+state;c.trackingRows??=new Map();
                if(!c.trackingRows.has(key))c.trackingRows.set(key,send('TRACKING_ROW',{alarm,ticket,state},token,8000));
                const load=()=>c.trackingRows.get(key).then(data=>{
                    if(!current())return;tracking.disabled=false;copyStatus.textContent='Copia el estado mostrado en esta consulta.'+(data.operatorAvailable?'':' Operador VIENA no disponible: esa celda quedará vacía.');
                    tracking.onclick=()=>{
                        if(!current())return;const columns=data.text.split('\t'),date=new Date();columns[0]=[date.getDate(),date.getMonth()+1].map(v=>String(v).padStart(2,'0')).join('/')+'/'+date.getFullYear();const text=columns.join('\t');
                        const handler=e=>{e.preventDefault();e.clipboardData.setData('text/plain',text);};let copied=false;
                        document.addEventListener('copy',handler);try{copied=document.execCommand('copy');}catch{/* Manual selection below preserves plain text on clipboard denial. */}finally{document.removeEventListener('copy',handler);}
                        copyStatus.textContent=copied?'Fila copiada. Pegala desde FECHA; para refrescar el estado usá Actualizar consulta.':'No se pudo copiar automáticamente. Copiá el texto seleccionado y pegalo desde FECHA.';
                        if(!copied){let manual=card.querySelector('textarea');if(!manual){manual=el('textarea');manual.readOnly=true;manual.style.cssText='width:100%;min-height:70px';manual.setAttribute('aria-label','Fila de seguimiento para copiar');card.append(manual);}manual.value=text;manual.focus();manual.select();}
                    };
                }).catch(e=>{if(current()){c.trackingRows.delete(key);tracking.disabled=false;copyStatus.textContent=e.message;tracking.onclick=()=>{tracking.disabled=true;c.trackingRows.set(key,send('TRACKING_ROW',{alarm,ticket,state},token,8000));void load();};}});
                void load();
            }
        }
        async function showTicket(number){
            c.stopViewer?.();const previous=c.viewerPending,scroll=panel.scrollTop;c.viewing=true;const viewerToken=nonce();let closed=false,pending,cancelLoad;
            const section=el('section'),back=el('button','Cerrar visor'),message=el('p','Abriendo el ticket en MOICA…'),body=el('div'),viewerHead=el('header');body.className='ticket-view';section.className='ticket-overlay';section.setAttribute('role','region');section.setAttribute('aria-label','Visor del ticket '+number);message.setAttribute('role','status');
            back.dataset.nativeClose='1';head.insertBefore(back,exit);section.append(message,body);c.viewerSection=section;c.viewRequest=section;panel.classList.add('ticket-open');panel.append(section);panel.scrollTop=0;section.style.top=(head.getBoundingClientRect().bottom-panel.getBoundingClientRect().top+6)+'px';const covered=[status,fields,actions,chooser,results,foArea];for(const e of covered)e.inert=true;
            const cleanup=()=>{if(closed)return;closed=true;cancelLoad?.();void send('NATIVE_END',{},viewerToken,5000).catch(()=>{});section.remove();back.remove();if(c.viewerSection===section){c.viewerSection=null;for(const e of covered)e.inert=false;panel.classList.remove('ticket-open');panel.scrollTop=scroll;c.stopViewer=null;if(valid())[...foArea.querySelectorAll('[data-onmsi-ticket]')].find(b=>b.dataset.onmsiTicket===number)?.focus({preventScroll:true});}};c.stopViewer=cleanup;back.onclick=cleanup;back.focus();
            pending=(async()=>{
                if(previous){message.textContent='Esperando el cierre del visor anterior…';await previous.catch(()=>{});}if(!valid()||closed)return;
                if(c.moicaInFlight)message.textContent='Esperando que termine la consulta en curso de MOICA…';
                while(c.moicaInFlight&&valid())await new Promise(r=>setTimeout(r,100));if(!valid()||closed)return;
                message.textContent='Abriendo el ticket en MOICA…';const data=await send('NATIVE_BEGIN',{ticket:number},viewerToken,30000);if(!valid()||closed)return;
                const u=new URL(data.url);if(u.protocol!=='chrome-extension:'||u.hostname!==chrome.runtime.id||u.pathname!=='/onmsi-viewer.html'||u.hash!=='#'+viewerToken)throw Error('Marco del visor no confirmado.');
                const frame=el('iframe');frame.className='native-viewer';frame.title='Visor nativo del ticket '+number;
                const ready=await new Promise((resolve,reject)=>{
                    let settled=false;const finish=(ok,error)=>{if(settled)return;settled=true;clearTimeout(timer);error?reject(Error(error)):resolve(ok);};
                    const receive=e=>{const d=e.data;if(e.origin!=='chrome-extension://'+chrome.runtime.id||e.source!==frame.contentWindow||d?.type!=='ONMSI_103_NATIVE_VIEWER'||d.token!==viewerToken)return;
                        if(d.state==='ready')finish(true);else if(d.state==='closed'){cleanup();}else if(d.state==='error'){message.hidden=false;message.textContent=d.message||'MOICA no pudo completar el visor.';message.className='error';finish(false,message.textContent);}
                    };
                    const timer=setTimeout(()=>finish(false,'MOICA no confirmó el visor dentro del tiempo de espera.'),35000);cancelLoad=()=>{window.removeEventListener('message',receive);clearTimeout(timer);finish(false);};window.addEventListener('message',receive);frame.src=u.href;body.append(frame);
                });
                if(valid()&&!closed&&ready){message.textContent='Ticket abierto en MOICA.';message.hidden=true;}
            })();c.viewerPending=pending;
            try{await pending;}catch(e){if(valid()&&!closed){message.hidden=false;message.textContent=e.message;message.className='error';}}
            finally{if(c.viewerPending===pending)c.viewerPending=null;if(c.viewRequest===section)c.viewing=false;}
        }

        async function nativeLookup(name,parent){while(c.viewing&&valid())await new Promise(r=>setTimeout(r,100));if(!valid())throw Error('Consulta detenida.');c.moicaInFlight=true;try{return await send('MOICA',{node:name,parent,origin:alarm.origin},c.token,70000);}finally{c.moicaInFlight=false;}}
        async function run(){
            refresh.disabled=true;c.stopViewer?.();results.replaceChildren();foArea.replaceChildren();c.foGroups=new Map();c.trackingRows=new Map();c.token=nonce();
            const states=new Map(),miraResults=new Map(),miraPromises=new Map();let miraDone=0,moicaDone=0;
            const progress=()=>{if(valid())status.textContent='MIRA5 '+miraDone+'/'+scope.nodes.length+' · MOICA '+moicaDone+'/'+scope.nodes.length+' nodos.';};
            const sideKey=(node,b)=>{const cmts=String(b.cmts).trim(),physical=String(b.node||node.name).trim();return cmts.startsWith(physical)&&cmts.length>physical.length?cmts.slice(physical.length):cmts;};
            const hasSides=data=>data?.complete&&new Set(data.branches.map(b=>b.cmts)).size>1;
            function renderNodes(){
                const sides=[...new Set(scope.nodes.flatMap(n=>hasSides(states.get(n.name).mira)?states.get(n.name).mira.branches.map(b=>sideKey(n,b)):[]))];
                const poleo=scope.nodes.some(n=>!hasSides(states.get(n.name).mira)),compactSides=sides.length>8;
                const table=el('table');table.className='nodes-table';const head=el('tr');head.append(el('th','Nodo'));
                if(poleo)head.append(el('th',scope.kind==='ftth'?'Estado':'Poleo'));if(compactSides)head.append(el('th','Lados'));else for(const side of sides)head.append(el('th','Lado '+side));head.append(el('th','Consulta FO'));
                const thead=el('thead'),tbody=el('tbody');thead.append(head);table.append(thead,tbody);
                const polling=(cell,branches)=>{for(const b of branches){const p=el('p',b.cmts+': '+b.up.toLocaleString('es-AR')+' % UP · '+b.total+' CMs');p.className=b.up<10?'down':b.up>=90?'up':'partial';cell.append(p);}};
                for(const node of scope.nodes){
                    const state=states.get(node.name),data=state.mira,row=el('tr'),name=el('td',node.name);name.title=node.technology;name.style.fontWeight='bold';row.append(name);
                    if(data?.verified){const current=data.physical.map(n=>n+(VienaNodeTech.get(n)?' · '+VienaNodeTech.get(n):''));if(data.physical.some(n=>n!==node.name))name.append(el('p',(data.relationPending?'Candidato MIRA5: ':'MIRA5: ')+current.join(', ')+(data.relationPending?' · relación sin confirmar':'')));}
                    if(poleo){const cell=el('td');if(data?.complete&&!hasSides(data))polling(cell,data.branches);else if(!data?.complete){cell.textContent=data?.message||state.miraText;cell.className=data&&!data.manual?'error':'muted';}else cell.textContent='—';row.append(cell);}
                    if(compactSides){const cell=el('td');if(hasSides(data))polling(cell,data.branches);else cell.textContent='—';row.append(cell);}else for(const side of sides){const cell=el('td');const branches=hasSides(data)?data.branches.filter(b=>sideKey(node,b)===side):[];if(branches.length)polling(cell,branches);else cell.textContent='—';row.append(cell);}
                    const fo=el('td',state.moicaText);fo.className=state.moicaError?'error':'muted';row.append(fo);tbody.append(row);
                }
                const wrap=el('div');wrap.className='nodes-scroll';wrap.append(table);const tech=[...new Set(scope.nodes.flatMap(n=>states.get(n.name).mira?.relationPending?[]:states.get(n.name).mira?.verified?states.get(n.name).mira.physical.map(p=>VienaNodeTech.get(p)):[n.technology]).filter(Boolean))];results.replaceChildren(el('h3',scope.nodes.length+' nodos'+(tech.length===1?' · '+tech[0]:'')),wrap);
            }
            const foStatus=(node,text,error=false)=>{const state=states.get(node.name);state.moicaText=text;state.moicaError=error;renderNodes();};
            try{
                if(!alarm){
                    alarm=api.detail(document,id)||await send('DETAIL',{id},c.token,35000);if(!valid())return;
                    for(const [label,key] of api.fields){const k=el('div',(key==='origin'?'Nodos':label)+':');k.className='label';const v=el('div');v.className='value';if(key==='gps'&&api.coordinates(alarm.gps))v.append(anchor(alarm.gps,api.coordinates(alarm.gps)));else if(key==='link'&&api.link(alarm.link))v.append(anchor('Ver enlace y gráfico OTDR',api.link(alarm.link)));else v.textContent=alarm[key]||(key==='gps'?'No se informan coordenadas':'No informado');fields.append(k,v);}copy.disabled=create.disabled=false;
                }
                scope=api.scope(alarm.origin,VienaNodeTech);if(scope.kind==='manual'||!scope.nodes.length){status.textContent=scope.message||'No se identificaron nodos registrados. Verificá manualmente.';return;}
                for(const node of scope.nodes){states.set(node.name,{mira:null,miraText:'Pendiente',moicaText:'Pendiente'});let done;const promise=new Promise(r=>{done=r;});miraPromises.set(node.name,{promise,done});}
                c.stopQueue=()=>{for(const deferred of miraPromises.values())deferred.done({complete:false,verified:false,message:'Consulta detenida.'});};renderNodes();
                const miraQueue=async()=>{
                    for(const node of scope.nodes){
                        if(!valid())return;const state=states.get(node.name);state.miraText='Consultando MIRA5…';renderNodes();let data;
                        if(scope.kind==='ftth')data={complete:false,manual:true,message:'Verificar manualmente en GPON.'};else try{data=await send('MIRA',{node:node.name,origin:alarm.origin},c.token,30000);}catch(e){data={complete:false,message:e.message};}
                        if(!valid())return;state.mira=data;miraResults.set(node.name,data);miraPromises.get(node.name).done(data);miraDone++;renderNodes();progress();
                    }
                };
                const moicaQueue=async()=>{
                    for(const node of scope.nodes){
                        if(!valid())return;
                        try{
                            let names=[node.name],identityIncomplete=false,relationPending=false;
                            if(scope.kind==='hfc'){
                                foStatus(node,'Esperando validar identidad en MIRA5…');const m=await miraPromises.get(node.name).promise;if(!valid())return;
                                if(!m.verified&&!node.registered)throw Error('Nombre exacto no confirmado en MIRA5: verificar manualmente.');
                                identityIncomplete=!m.verified;if(m.verified){const candidates=m.physical.includes(node.name)&&node.technology.toUpperCase()==='VCCAP'?api.aliases(node.name,VienaNodeTech):[];names=[...new Set([node.name,...m.physical,...candidates])];relationPending=Boolean(m.relationPending||candidates.length);}
                            }
                            foStatus(node,'Buscando FO: '+names.join(', ')+'…');
                            const all=[],errors=[],coverage=[];
                            for(const name of names){
                                if(!valid())return;
                                try{
                                    const data=await nativeLookup(name,node.name);
                                    if(!Array.isArray(data.items))throw Error(data.message||'MOICA no confirmó el listado.');
                                    coverage.push(name+' ('+data.items.length+' FO)');
                                    for(const item of data.items)all.push({...item,matchedName:data.matchedName,candidateSearch:data.candidateSearch});
                                    if(!data.complete)errors.push(name+': '+(data.message||'No se pudo completar la verificación de tareas.'));
                                }catch(e){coverage.push(name+' (sin verificar)');errors.push(name+': '+e.message);}
                            }
                            if(!valid())return;
                            for(const t of all){
                                let g=c.foGroups.get(t.ticket);
                                if(!g){g={states:new Set(),problems:new Set(),nodes:new Set(),candidates:new Set(),tasks:new Map(),tasksComplete:false};c.foGroups.set(t.ticket,g);}
                                g.states.add(t.ticketState);if(t.problem)g.problems.add(t.problem);
                                if(t.candidateSearch)g.candidates.add(t.matchedName+' (alarma '+node.name+')');else g.nodes.add(node.name);
                                g.tasksComplete||=t.tasksComplete;
                                for(const task of t.tasks)g.tasks.set(task.number+':'+task.state,task);
                            }
                            renderFos();
                            const incomplete=identityIncomplete||errors.length>0;
                            const label=all.length?(all.some(t=>!t.candidateSearch)?'FO encontrado.':'FO encontrado por nombre candidato.'):incomplete?'No se pudo confirmar si hay tickets FO.':'Sin tickets FO en los nombres consultados.';
                            const details=incomplete?' · Consulta incompleta: '+(identityIncomplete?'identidad actual sin confirmar en MIRA5. ':'')+errors.join(' · '):'';
                            foStatus(node,'Buscado: '+coverage.join(', ')+'. '+label+details+(relationPending?' · Relación entre nombres sin confirmar.':''),incomplete);
                        }catch(e){if(!valid())return;foStatus(node,e.message,true);}
                        moicaDone++;progress();
                    }
                };
                await Promise.all([miraQueue(),moicaQueue()]);if(valid())status.textContent='Consulta finalizada. Los errores no equivalen a ausencia de tickets ni a nodos operativos.';
            }catch(e){if(valid())status.textContent=e.message;}finally{c.stopQueue=null;if(valid())refresh.disabled=false;}
        }

        refresh.onclick=()=>void run();void run();
    }
    function scan(){for(const {id,row} of api.rows(document)){const old=row.querySelector('[data-onmsi-fo]');if(old?.dataset.onmsiFo===id)continue;old?.remove();const button=el('button','Consultar FO');button.type='button';button.dataset.onmsiFo=id;button.style.cssText='margin-left:8px;font:11px Arial;padding:2px 7px;border:1px solid #8aa;border-radius:4px;background:#edf6fc;color:#17405a';button.onclick=e=>{e.preventDefault();e.stopPropagation();modal(id);};row.querySelector('a[href*="#link_dashboard?id="]').parentElement.append(button);}}
    scan();const timer=setInterval(scan,2000);window.addEventListener('pagehide',()=>{clearInterval(timer);close();},{once:true});
})();
