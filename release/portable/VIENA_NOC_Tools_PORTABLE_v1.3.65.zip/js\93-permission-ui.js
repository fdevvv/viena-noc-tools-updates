/* Permission explanations only: Chrome retains its native consent UI. */
(() => {
  'use strict';
  if (globalThis.VienaPermissionUI || typeof document === 'undefined') return;
  let active = null, toastTimer = 0, toastHost = null;
  const cancelled = () => new DOMException('Operación cancelada.', 'AbortError');
  const css = `:host{all:initial;color-scheme:light;font:14px/1.5 Inter,system-ui,"Segoe UI",Arial,sans-serif;color:#183a61}*{box-sizing:border-box}dialog{position:fixed;inset:0;margin:auto;width:min(460px,calc(100vw - 32px));max-height:calc(100dvh - 32px);padding:0;overflow:auto;border:1px solid #cbd9e7;border-radius:13px;background:#fff;color:#183a61;box-shadow:0 18px 45px #0b376847;font:inherit}dialog::backdrop{background:#0a1c3070}header{display:flex;gap:13px;align-items:center;padding:20px 24px;background:#f5f9fd;border-bottom:1px solid #dbe5ef}.icon{display:grid;place-items:center;width:48px;height:48px;flex:none;border-radius:11px;background:#e4f0ff;color:#0b72e7;font-size:24px}h2{font-size:18px;line-height:1.3;margin:0;color:#073f7e}.brand{font-size:12px;color:#66809d;margin-top:4px}.body{padding:18px 24px;overflow-wrap:anywhere}.note{background:#edf6ff;border:1px solid #d7e3f0;padding:11px 13px;border-radius:9px;margin-top:14px;font-size:12px;color:#40556e}.actions{display:flex;justify-content:flex-end;gap:10px;padding:0 24px 21px}button{font:600 14px system-ui;cursor:pointer;padding:10px 18px;border:1px solid #d7e3f0;border-radius:8px;background:white;color:#183a61}button:focus-visible{outline:3px solid #0b72e7;outline-offset:3px}.primary{background:#0b72e7;border-color:#0b72e7;color:white}button:disabled{opacity:.6;cursor:wait}.toast{display:flex;align-items:center;gap:12px;width:min(460px,calc(100vw - 32px));padding:16px 18px;border:1px solid #d7e3f0;border-left:4px solid #16823b;border-radius:10px;background:#fff;box-shadow:0 10px 30px #0e3a6933}.toast.warning{border-left-color:#a76500}.toast.error{border-left-color:#b42318}.toast span{flex:1;overflow-wrap:anywhere}.toast button{padding:0 4px;border:0;font-size:20px;color:#66809d}@media(max-width:360px){header,.body{padding:16px}.actions{padding:0 16px 16px;flex-wrap:wrap}}@media(prefers-color-scheme:dark){dialog,.toast{background:#152538;color:#e7eff8;border-color:#405975}header{background:#1a3049;border-color:#405975}h2{color:#e7eff8}.brand{color:#afc5dd}.note{background:#1a3049;color:#d3e3f5;border-color:#405975}button{background:#203b58;color:#e7eff8;border-color:#536c87}.primary{background:#0b72e7}}`;
  function host(id) {
    const node = document.createElement('div'); node.id = id;
    node.style.cssText = 'all:initial;font:14px/1.5 Inter,system-ui,"Segoe UI",Arial,sans-serif;color:#183a61;position:fixed;inset:0;z-index:2147483647;pointer-events:none;';
    const shadow = node.attachShadow({mode:'open'}), style = document.createElement('style'); style.textContent = css; shadow.append(style);
    (document.body || document.documentElement).append(node); return {node,shadow};
  }
  function toast(message, type = 'success') {
    clearTimeout(toastTimer); toastHost?.remove();
    const {node,shadow} = host('viena-permission-toast'); toastHost = node;
    node.style.cssText += 'display:grid;place-items:center;';
    const box = document.createElement('div'), text = document.createElement('span'), close = document.createElement('button');
    box.className = 'toast '+type; box.style.pointerEvents = 'auto'; box.setAttribute('role','status'); text.textContent = message;
    close.type = 'button'; close.textContent = '×'; close.setAttribute('aria-label','Cerrar aviso'); close.onclick = () => {node.remove();clearTimeout(toastTimer);};
    box.append(text,close); shadow.append(box); toastTimer = setTimeout(() => node.remove(),4500);
  }
  function run({title,message,operation,success = 'Permiso habilitado.',timeoutMs = 60000}) {
    if (active) return Promise.reject(cancelled());
    return new Promise((resolve,reject) => {
      const focus = document.activeElement, {node,shadow} = host('viena-permission-modal');
      const dialog = document.createElement('dialog'); dialog.style.pointerEvents = 'auto';
      dialog.innerHTML = '<header><span class="icon" aria-hidden="true">▣</span><div><h2 id="permission-title"></h2><div class="brand">VIENA NOC Tools</div></div></header><div class="body"><div class="message"></div><div class="note">Al continuar, Chrome mostrará su solicitud si necesita tu autorización. Confirmá allí para completar el permiso.</div></div><div class="actions"><button type="button" class="cancel">Ahora no</button><button type="button" class="primary">Continuar</button></div>';
      dialog.setAttribute('aria-labelledby','permission-title'); dialog.querySelector('h2').textContent = title; dialog.querySelector('.message').textContent = message;
      shadow.append(dialog);
      let done = false, timer;
      function finish(error,value) {
        if (done) return; done = true; clearTimeout(timer); active = null; dialog.close(); node.remove();
        if (focus?.isConnected) focus.focus({preventScroll:true});
        if (error) { if (error.name !== 'AbortError') toast(error.name === 'NotAllowedError' ? 'No se habilitó el permiso. Podés volver a intentarlo.' : 'No se pudo completar el permiso. Volvé a intentarlo.','warning'); reject(error); }
        else { if(success) toast(success); resolve(value); }
      }
      active = {cancel:() => finish(cancelled())};
      dialog.oncancel = event => {event.preventDefault();finish(cancelled());};
      dialog.addEventListener('keydown',event => {if(event.key === 'Escape'){event.preventDefault();event.stopPropagation();finish(cancelled());}});
      dialog.querySelector('.cancel').onclick = () => finish(cancelled());
      const button = dialog.querySelector('.primary');
      button.onclick = () => {
        if (button.disabled || done) return; button.disabled = true; button.textContent = 'Esperando a Chrome…';
        timer = setTimeout(() => finish(new DOMException('El permiso no respondió a tiempo.','TimeoutError')),timeoutMs);
        // Invoke synchronously from the real click, before any await.
        try { Promise.resolve(operation()).then(value => finish(null,value),error => finish(error)); } catch(error) { finish(error); }
      };
      try { dialog.showModal(); dialog.querySelector('.cancel').focus(); } catch(error) {finish(error);}
    });
  }
  const folder = (options) => run({title:'Elegir carpeta',message:'Elegí la carpeta que VIENA podrá usar. Chrome te pedirá autorización para acceder a ella.',operation:() => window.showDirectoryPicker(options),success:'Carpeta autorizada.'});
  const request = handle => run({title:'Permitir acceso a la carpeta',message:'Para continuar, VIENA necesita tu autorización para acceder a la carpeta que elegiste.',operation:async() => {
    const state = await handle.requestPermission({mode:'readwrite'});
    if (state !== 'granted') throw new DOMException('Permiso no habilitado.','NotAllowedError'); return state;
  },success:'Acceso a la carpeta habilitado.'});
  globalThis.VienaPermissionUI = {run,toast,folder,request,cancel:() => active?.cancel()};
})();
