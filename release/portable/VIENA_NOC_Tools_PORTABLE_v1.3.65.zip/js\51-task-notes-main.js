(() => {
    'use strict';
    if (location.hostname !== 'viena.telecentro.net.ar' || window.__VIENA_TASK_NOTES__) return;
    window.__VIENA_TASK_NOTES__ = true;
    const jobs = new Map();
    const notify = (job, state, message) => {
        job.state = state;
        document.dispatchEvent(new CustomEvent('VIENA_TASK_NOTE_RESULT', {detail:{id:job.id,state,message,source:job.source,retryable:state === 'failed' && job.readyToSend === true}}));
    };
    function components() {
        const seen = new Set(), queue = [];
        for (const root of document.querySelectorAll('.v-dialog__content--active')) {
            if (!root.isConnected || !root.getClientRects().length) continue;
            for (const node of [root,...root.querySelectorAll('*')]) if (node.__vue__) queue.push(node.__vue__);
        }
        while (queue.length && seen.size < 4000) {
            const item = queue.shift(); if (!item || seen.has(item)) continue;
            seen.add(item); queue.push(item.$parent,...(item.$children || []));
        }
        return [...seen];
    }
    function sourceComponent(source) {
        return components().find(item => item.$options?.name === 'DialogTaskDetail' && item.ticketDetail?.ticketNumber === source && typeof item.tab === 'string' && item.currentUser && Array.isArray(item.taskPermissions));
    }
    // Read-only header companion. Native RelatedTask.getSiblings uses this same
    // service and receives the complete array; Vuetify paginates it client-side.
    let fieldJob = null, fieldService;
    function stopFieldJob() {
        const job = fieldJob; fieldJob = null;
        if (!job) return;
        clearTimeout(job.timer);
        for (const dispose of job.disposers) dispose();
    }
    function fieldApi() {
        if (!fieldService) {
            const id = 'viena-field-header-' + crypto.randomUUID();
            window.webpackJsonp?.push([[id],{[id]:(module,exports,require) => { fieldService = require('8692')?.a; }},[[id]]]);
        }
        if (typeof fieldService?.getSiblings !== 'function') throw Error('field-contract');
        return fieldService;
    }
    function publishField(job, tasks, available = true) {
        if (fieldJob !== job || job.component.ticketDetail?.ticketNumber !== job.source) return;
        document.dispatchEvent(new CustomEvent('VIENA_FIELD_TASK_RESULT',{detail:{id:job.id,source:job.source,tasks,available}}));
    }
    async function readFieldTasks(job) {
        if (fieldJob !== job) return;
        if (job.inFlight) { job.dirty = true; return; }
        job.inFlight = true; job.dirty = false;
        // Timeout clears the display, but the native request retains its lock
        // until it settles: never pile up reads behind a stalled native service.
        job.timer = setTimeout(() => { job.expired = true; publishField(job,[],false); },15000);
        job.expired = false;
        try {
            const response = await fieldApi().getSiblings(job.source);
            if (job.expired || fieldJob !== job) return;
            if (response?.status !== 200 || !Array.isArray(response.data?.data)) throw Error('field-response');
            const tasks = [], seen = new Set();
            for (const row of response.data.data) {
                if (!row || typeof row.ticketNumber !== 'string' || typeof row.status !== 'string') throw Error('field-row');
                if (row.taskTypification?.taskType?.code !== 'TC') continue;
                const status = row.status.trim().toUpperCase();
                if (!['AGENDADA','ASIGNADA','EN CURSO','INICIADA'].includes(status)) continue;
                const number = row.ticketNumber.trim();
                if (!number || seen.has(number)) throw Error('field-identity');
                seen.add(number); tasks.push({number,status});
            }
            publishField(job,tasks);
        } catch (_) { publishField(job,[],false); }
        finally {
            clearTimeout(job.timer); job.inFlight = false;
            if (fieldJob === job && job.dirty) void readFieldTasks(job);
        }
    }
    function watchFieldChildren(job) {
        const queue = [...(job.component.$children || [])], seen = new Set();
        while (queue.length && seen.size < 400) {
            const child = queue.shift(); if (!child || seen.has(child)) continue;
            seen.add(child); queue.push(...(child.$children || []));
            if (job.children.has(child)) continue;
            const name = child.$options?.name;
            if (!['TaskTicketCreate','FormScheduleTask','RelatedTask'].includes(name)) continue;
            if (name === 'TaskTicketCreate' && child.taskConfig?.ticketNumber !== job.source) continue;
            job.children.add(child);
            const changed = () => { void readFieldTasks(job); };
            if (name === 'RelatedTask' && typeof child.$watch === 'function') {
                job.disposers.push(child.$watch('loadingTable',(loading,wasLoading) => { if (!loading && wasLoading) changed(); }));
            } else if (typeof child.$on === 'function') {
                const event = name === 'TaskTicketCreate' ? 'update_tareas' : 'closeDialog';
                child.$on(event,changed); job.disposers.push(() => child.$off(event,changed));
                if (name === 'TaskTicketCreate') {
                    const updated = () => watchFieldChildren(job);
                    child.$on('hook:updated',updated); job.disposers.push(() => child.$off('hook:updated',updated));
                }
            }
        }
    }
    document.addEventListener('VIENA_FIELD_TASK_REQUEST', event => {
        const msg = event.detail;
        if (msg?.action === 'clear') { stopFieldJob(); return; }
        if (typeof msg?.id !== 'string' || typeof msg.source !== 'string' || !msg.source || msg.source.length > 100) return;
        if (fieldJob?.id === msg.id && fieldJob.source === msg.source) { watchFieldChildren(fieldJob); return; }
        stopFieldJob();
        const component = sourceComponent(msg.source);
        const permission = component?.ticketDetail.taskTypification?.taskType?.code === 'TC' ? 'viewRelatedTask.taskticket' : 'viewRelatedTask.taskinternal';
        if (!component?.taskPermissions.includes(permission)) return;
        const job = fieldJob = {id:msg.id,source:msg.source,component,children:new Set(),disposers:[],inFlight:false};
        if (typeof component.$watch === 'function') job.disposers.push(component.$watch(() => component.ticketDetail,() => { void readFieldTasks(job); }));
        if (typeof component.$on === 'function') {
            const updated = () => watchFieldChildren(job);
            component.$on('hook:updated',updated); job.disposers.push(() => component.$off('hook:updated',updated));
        }
        watchFieldChildren(job);
        void readFieldTasks(job);
    });
    window.addEventListener?.('pagehide',stopFieldJob);
    let service;
    function nativeService() {
        if (service) return service;
        // Public VIENA app.a7e38b4f.js, module 4e7a; keep its own authentication.
        // If the application contract changes, fail closed before any upload.
        if (!Array.isArray(window.webpackJsonp)) throw Error('No pudimos acceder al guardado nativo de VIENA.');
        const id = 'viena-note-' + crypto.randomUUID();
        window.webpackJsonp.push([[id],{[id]:(module,exports,require) => { module.exports = require('4e7a'); service = module.exports?.a; }},[[id]]]);
        if (typeof service?.addNote !== 'function') { service = null; throw Error('El guardado nativo de VIENA cambió. Conservamos tus archivos.'); }
        return service;
    }
    function checkSource(source) {
        const item = sourceComponent(source);
        if (!item || item.ticketDetail.taskTypification?.taskType?.code !== 'TI' || !item.taskPermissions.includes('addNotes.taskinternal')) throw Error('Abrí la tarea interna de origen con permiso para agregar notas.');
        // Native loadToken stores the session user, which can have id/name and
        // no ldap_id. DialogAddNote forwards that field without requiring it.
        if (typeof item.currentUser.name !== 'string' || !item.currentUser.name.trim()) throw Error('No pudimos confirmar el usuario de la sesión de VIENA.');
        return item;
    }
    function unwatch(job) {
        clearTimeout(job.waitTimer);
        job.creator?.$off('update_tareas',job.confirmed);
        job.creator = null;
    }
    async function send(job) {
        if (!['armed','failed'].includes(job.state)) return;
        let timer, invoked = false;
        try {
            const source = checkSource(job.source), api = nativeService(), data = new FormData();
            for (const file of job.files) data.append('files[]',file);
            data.append('nroTkt',job.source); data.append('title',job.title); data.append('message',job.message);
            data.append('user_name',source.currentUser.name); data.append('user_id',source.currentUser.ldap_id);
            notify(job,'sending','Guardando nota y adjuntos en ' + job.source + '…');
            invoked = true;
            const response = await Promise.race([api.addNote(data),new Promise((resolve,reject) => {timer = setTimeout(() => reject(Error('timeout')),30000);})]);
            if (response?.status >= 200 && response.status < 300 && response.data?.status === 'success') {
                job.files = [];
                // Never change another ticket or open the Notes dialog/tab.
                const current = sourceComponent(job.source);
                if (current) {
                    current.tab = 'tab-2';
                    // Match the native post-save refresh, without delaying the result.
                    try { Promise.resolve(current.$refs?.NotesTable?.recargarTrasAgregarNota?.()).catch(() => {}); } catch (_) {}
                }
                notify(job,'saved','Nota y adjuntos guardados en ' + job.source + '.');
            } else notify(job,'uncertain','VIENA no confirmó el guardado. Revisá Notas antes de volver a enviar para evitar duplicados.');
        } catch (error) {
            const rejected = invoked && error?.response?.status >= 400 && error.response.status < 500;
            notify(job,invoked && !rejected ? 'uncertain' : 'failed',invoked && !rejected
                ? 'No pudimos confirmar el guardado. Conservamos los archivos; revisá Notas antes de volver a enviar.'
                : 'No se guardó la nota. Conservamos tus archivos. ' + (invoked ? 'VIENA rechazó el envío.' : error.message));
        } finally { clearTimeout(timer); }
    }
    document.addEventListener('VIENA_TASK_NOTE_REQUEST',event => {
        if (location.pathname !== '/tasks/intern') return;
        const msg = event.detail || {}; if (typeof msg.id !== 'string') return;
        let job = jobs.get(msg.id);
        if (msg.action === 'discard') { if (job && !['armed','sending'].includes(job.state)) { job.files = []; } return; }
        if (msg.action === 'retry') { if (job?.state === 'failed' && job.readyToSend) void send(job); return; }
        if (msg.action === 'cancel') {
            if (job?.state === 'armed') { unwatch(job); jobs.delete(job.id); }
            return;
        }
        if (msg.action !== 'arm') return;
        if (job && job.state !== 'armed') { notify(job,job.state,'La nota ya fue procesada. Revisá su resultado antes de repetir.'); return; }
        try {
            if (job) unwatch(job);
            if (jobs.size >= 20 && !job) {
                for (const [key,item] of jobs) if (item.state === 'saved' || item.state === 'expired') { item.files = []; jobs.delete(key); }
                if (jobs.size >= 20) throw Error('Hay varias notas pendientes. Revisá sus resultados antes de preparar otra.');
            }
            checkSource(msg.source); nativeService();
            const creator = components().find(item => item.$options?.name === 'TaskTicketCreate' && item.taskConfig?.ticketNumber === msg.source);
            if (!creator || typeof creator.$once !== 'function') throw Error('No pudimos vincular la nota con el formulario de creación actual.');
            const files = Array.from(document.getElementById(msg.filesId)?.files || []);
            if (!files.length || files.some(file => file.size > 20000000)) throw Error('Elegí archivos de hasta 20 MB cada uno.');
            if (typeof msg.title !== 'string' || !msg.title.trim() || typeof msg.message !== 'string' || !msg.message.trim()) throw Error('Completá el título y el mensaje de la nota.');
            job = {id:msg.id,source:msg.source,title:msg.title,message:msg.message,files,creator}; jobs.set(job.id,job);
            if (msg.now === true) { job.readyToSend = true; notify(job,'armed','Nota preparada.'); void send(job); return; }
            job.confirmed = number => {
                unwatch(job);
                if (typeof number !== 'string' || !number.trim() || number === job.source) { notify(job,'failed','No se confirmó la nueva tarea. La nota no fue enviada.'); return; }
                job.readyToSend = true; void send(job);
            };
            creator.$once('update_tareas',job.confirmed);
            job.waitTimer = setTimeout(() => { unwatch(job); notify(job,'expired','No se confirmó la creación. La nota no fue enviada; los archivos siguen preparados.'); },300000);
            notify(job,'armed','Nota preparada para la tarea interna ' + job.source + '.');
        } catch (error) { notify({id:msg.id,source:msg.source},'failed',error.message); }
    });
})();
