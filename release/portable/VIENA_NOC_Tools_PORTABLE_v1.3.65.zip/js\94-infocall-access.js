'use strict';
(() => {
  const ORIGIN = 'https://i3.telecentro.net.ar/*';
  const ID = 'viena-infocall-optional';
  const TYPE = 'VIENA_INFOCALL_ACCESS';
  const optional = chrome.runtime.getManifest().optional_host_permissions?.includes(ORIGIN);
  if (!optional) return;
  if (typeof document === 'undefined') {
    const bounded = async operation => {
      let timer;
      try { return await Promise.race([operation, new Promise((_, reject) => { timer = setTimeout(() => reject(Error('access_timeout')), 5000); })]); }
      finally { clearTimeout(timer); }
    };
    let queue = Promise.resolve();
    function sync() {
      const operation = queue.catch(() => {}).then(async () => {
        const allowed = await bounded(chrome.permissions.contains({ origins: [ORIGIN] }));
        const registered = await bounded(chrome.scripting.getRegisteredContentScripts({ ids: [ID] }));
        if (allowed && !registered.length) await bounded(chrome.scripting.registerContentScripts([{
          id: ID, matches: ['https://i3.telecentro.net.ar/info.php*'], js: ['js/68-infocall-viewer.js'], allFrames: true, runAt: 'document_idle', persistAcrossSessions: true
        }]));
        if (!allowed && registered.length) await bounded(chrome.scripting.unregisterContentScripts({ ids: [ID] }));
        return allowed;
      });
      queue = operation;
      return operation;
    }
    chrome.permissions.onAdded.addListener(() => { void sync().catch(() => {}); });
    chrome.permissions.onRemoved.addListener(() => { void sync().catch(() => {}); });
    chrome.runtime.onMessage.addListener((msg, sender, respond) => {
      if (msg?.type !== TYPE) return;
      const ownPage = sender.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL(''));
      let viena = false;
      try { viena = sender.id === chrome.runtime.id && new URL(sender.url).origin === 'https://viena.telecentro.net.ar'; } catch (_) {}
      if (!ownPage && !viena) { respond({ ok: false, code: 'unauthorized' }); return; }
      (async () => {
        if (await sync()) return { ok: true };
        return { ok: false, code: 'permission_required' };
      })().then(respond).catch(() => respond({ ok: false, code: 'access_unavailable' }));
      return true;
    });
    void sync().catch(() => {});
    return;
  }
  if (location.pathname === '/permission.html') {
    if (window.parent === window) return;
    const token = new URLSearchParams(location.search).get('token');
    if (!/^[a-f0-9]{32}$/.test(token || '')) return;
    const report = (state) => window.parent.postMessage({type:'VIENA_INFOCALL_PERMISSION',token,state},'https://viena.telecentro.net.ar');
    report('ready');
    globalThis.VienaPermissionUI.run({title:'Habilitar Infocall3',message:'VIENA necesita tu autorización para mostrar los diagnósticos de Infocall3 dentro de este ticket.',success:'',operation:async() => {
      if (!await chrome.permissions.request({origins:[ORIGIN]})) throw new DOMException('Permiso no habilitado.','NotAllowedError');
      const result = await chrome.runtime.sendMessage({type:TYPE});
      if (!result?.ok) throw Error('registration_failed');
    }}).then(() => report('granted'),error => report(error.name === 'AbortError' ? 'cancelled' : 'denied'));
    return;
  }
  if (!new URLSearchParams(location.search).has('infocallAccess')) return;
  const panel = document.createElement('section');
  panel.className = 'card';
  panel.style.cssText = 'margin:16px;padding:20px;max-width:560px';
  const title = document.createElement('h2'); title.textContent = 'Conectar Infocall3';
  const text = document.createElement('p'); text.textContent = 'Permití el acceso a Infocall3 para usar el visor de diagnósticos. El resto de las herramientas sigue disponible si no lo habilitás.';
  const button = document.createElement('button'); button.type = 'button'; button.className = 'btn primary'; button.textContent = 'Habilitar Infocall3';
  const state = document.createElement('p'); state.setAttribute('role', 'status');
  button.onclick = async () => {
    button.disabled = true;
    try {
      // Must remain the first asynchronous operation inside the user gesture.
      const granted = await chrome.permissions.request({ origins: [ORIGIN] });
      if (!granted) { state.textContent = 'No se habilitó Infocall3. Podés reintentarlo cuando lo necesites.'; return; }
      const result = await chrome.runtime.sendMessage({ type: TYPE });
      if (!result?.ok) throw Error('registration_failed');
      state.textContent = 'Infocall3 habilitado. Volvé al ticket y abrí el visor.';
      button.textContent = 'Infocall3 habilitado';
      const source = Number(new URLSearchParams(location.search).get('sourceTab'));
      if (Number.isInteger(source) && source > 0) {
        try { await chrome.tabs.update(source, { active: true }); } catch (_) {}
      }
    } catch (_) { state.textContent = 'No se pudo habilitar Infocall3. Volvé a intentarlo.'; }
    finally { button.disabled = false; }
  };
  panel.append(title, text, button, state);
  document.body.prepend(panel);
})();
