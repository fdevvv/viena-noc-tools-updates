(() => {
    'use strict';
    if(typeof importScripts==='function')try{importScripts('js/103-onmsi-native-background.js');}catch(e){console.error('ONMSi native viewer unavailable',e);}
    const jobs=new Map(),identities=new Map(),viewers=new Map(),pause=ms=>new Promise(r=>setTimeout(r,ms));let creating=false;
    async function viewerFor(owner,token){
        const known=viewers.get(owner);if(known?.token===token)return known;
        // MV3 may restart between opening the viewer and clicking a tab. The
        // authenticated page owns this short-lived state; no storage is needed.
        const tabs=await chrome.tabs.query({url:'https://moica2.telecentro.net.ar/*'}).catch(()=>[]);
        for(const tab of tabs.filter(t=>!t.discarded&&new URL(t.url).pathname==='/buscarTicket.php')){
            try{const r=await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:(t,o)=>window.__vienaOnmsiViewer?.token===t&&window.__vienaOnmsiViewer?.owner===o,args:[token,owner]});if(r[0]?.result){const v={tab:tab.id,token};viewers.set(owner,v);return v;}}catch{}
        }return null;
    }
    async function closeViewer(owner,token){const v=await viewerFor(owner,token);if(v){if(viewers.get(owner)?.token===token)viewers.delete(owner);await chrome.scripting.executeScript({target:{tabId:v.tab},world:'MAIN',func:t=>{if(window.__vienaOnmsiViewer?.token===t)window.__vienaOnmsiViewer.cancel();},args:[token]}).catch(()=>{});}}
    const allowed=s=>{try{return s.id===chrome.runtime.id&&s.frameId===0&&new URL(s.tab.url).origin==='http://onmsi.telecentro.net.ar';}catch{return false;}};
    async function mira(name,token,alternatives=[]){
        if(location.origin!=='https://mira5-gdt.telecentro.net.ar'||location.pathname!=='/stats_frontend.php')throw Error('Abrí Estadísticas de MIRA5.');
        if(window.__vienaOnmsiMira)throw Error('MIRA5 está finalizando otra lectura.');
        const abort=new AbortController(),holder={token,cancel:()=>abort.abort()},timer=setTimeout(()=>abort.abort(),25000);window.__vienaOnmsiMira=holder;
        let verified=false,relationPending=false;const physical=[];
        const get=(r,k)=>r?.[k]??k.split('.').reduce((v,p)=>v?.[p],r);
        try{
            const el=document.getElementById('gridStatsNodosCmts'),$=window.jQuery;if(!el?.grid||!$)throw Error('Abrí Estadísticas de MIRA5 e iniciá sesión.');
            const p=$(el).jqGrid('getGridParam'),base=new URL(p.url,location.href),n=p.prmNames;
            if(base.origin!==location.origin||base.pathname!=='/controller_grid_mira_gral.php'||base.searchParams.get('coll')!=='statsNodosCmts'||String(p.mtype).toUpperCase()!=='GET'||!n?.page||!n.rows||!n.search)throw Error('No se pudo verificar la grilla MIRA5.');
            const query=async(field,exact=name)=>{
                const all=[],seen=new Set();let expected;
                for(let page=1;page<=50;page++){
                    const u=new URL(base);for(const key of ['defaultFilter','filters','page','rows','sidx','sord','_search',...Object.values(n)].filter(k=>typeof k==='string'))u.searchParams.delete(key);
                    u.searchParams.set('oper','grid');u.searchParams.set(n.page,page);u.searchParams.set(n.rows,'100');u.searchParams.set(n.search,'true');u.searchParams.set(n.filter||'filters',JSON.stringify({groupOp:'AND',rules:[{field,op:'eq',data:exact}]}));if(n.sort)u.searchParams.set(n.sort,'nodoCmts');if(n.order)u.searchParams.set(n.order,'asc');
                    const rt=setTimeout(()=>abort.abort(),12000);let d;
                    try{const r=await fetch(u.href,{credentials:'same-origin',cache:'no-store',redirect:'manual',signal:abort.signal});if(!r.ok||r.type==='opaqueredirect'||r.redirected)throw Error('Revisá la sesión de MIRA5.');d=await r.json();}finally{clearTimeout(rt);}
                    const count=Number(d.records),total=Number(d.total),rows=d.rows===null&&count===0?[]:d.rows;
                    if(d.noses||!Number.isSafeInteger(count)||count<0||count>5000||Number(d.page)!==page||!Array.isArray(rows)||total!==Math.max(1,Math.ceil(count/100))&&!(count===0&&total===0)||rows.length!==Math.min(100,count-all.length)||expected!==undefined&&count!==expected)throw Error('MIRA5 devolvió una lectura incompleta.');
                    expected=count;for(const row of rows){const id=String(get(row,'nodoCmts')||'');if(!id||seen.has(id)||String(get(row,field)||'').trim().toUpperCase()!==exact)throw Error('Identidad MIRA5 no verificada.');seen.add(id);all.push(row);}
                    if(page>=total)return all;
                }throw Error('MIRA5 excede el límite de páginas.');
            };
            let rows=await query('nodo');if(!rows.length)rows=await query('nodoCmts');
            if(!rows.length)for(const candidate of alternatives){rows=await query('nodo',candidate);if(rows.length){relationPending=true;break;}}
            if(!rows.length)throw Error('MIRA5 no reconoce este nombre exacto como nodo o CMTS.');
            for(const row of rows){const v=String(get(row,'nodo')||'').trim().toUpperCase();if(!/^[A-Z0-9]{1,32}$/.test(v))throw Error('Nodo físico no verificado.');physical.push(v);}verified=true;
            const branches=rows.map(r=>{const raw=get(r,'cmStatus.cmUpPercent'),up=raw===null||raw===undefined||String(raw).trim()===''?NaN:Number(String(raw).replace(',','.')),total=Number(get(r,'cmStatus.cmTot'));if(!Number.isFinite(up)||up<0||up>100||!Number.isFinite(total)||total<=0)throw Error('Poleo sin monitoreo verificable.');return {node:String(get(r,'nodo')),cmts:String(get(r,'nodoCmts')),up,total};});
            return {complete:true,verified:true,relationPending,physical:[...new Set(physical)],branches};
        }catch(e){return {complete:false,verified,relationPending,physical:[...new Set(physical)],message:abort.signal.aborted?'La lectura MIRA5 se detuvo o venció.':e.message};}
        finally{clearTimeout(timer);if(window.__vienaOnmsiMira===holder)delete window.__vienaOnmsiMira;}
    }
    chrome.runtime.onMessage.addListener((m,s,reply)=>{
        if(!String(m?.type||'').startsWith('ONMSI_103_'))return;
        if(String(m.type).startsWith('ONMSI_103_NATIVE_'))return;
        if(!allowed(s)||!/^[a-f0-9]{32}$/.test(m.token||'')){reply({ok:false,message:'Contexto ONMSi no autorizado.'});return;}
        if(m.type==='ONMSI_103_TRACKING_ROW'){
            const a=m.alarm;
            if(!a||!/^\d{1,12}$/.test(a.id)||VienaOnmsi.fields.some(([,k])=>typeof a[k]!=='string'||a[k].length>4000)||!/^\d{6}FO\d+$/i.test(m.ticket||'')||typeof m.state!=='string'||!m.state.trim()||m.state.length>100){reply({ok:false,message:'El ticket y su estado deben estar confirmados en la consulta.'});return;}
            void chrome.storage.local.get('viena_usuario').then(stored=>{
                const operator=String(stored.viena_usuario||'');reply({ok:true,data:{text:VienaOnmsiPrepare.tracking({...a,operator,ticket:m.ticket,state:m.state},'row'),operatorAvailable:Boolean(operator)}});
            }).catch(()=>reply({ok:false,message:'No se pudo preparar la fila. Reintentá la copia.'}));return true;
        }
        if(m.type==='ONMSI_103_VIEW_CLOSE'){void closeViewer(s.tab.id,m.token);const pending=jobs.get(s.tab.id+':ONMSI_103_VIEW');if(pending?.token===m.token){pending.cancelled=true;if(pending.moica)void chrome.scripting.executeScript({target:{tabId:pending.moica},world:'MAIN',func:t=>{if(window.__vienaOnmsiMoica?.token===t)window.__vienaOnmsiMoica.cancel();if(window.__vienaOnmsiViewer?.token===t)window.__vienaOnmsiViewer.cancel();},args:[m.token]}).catch(()=>{});}reply({ok:true});return;}
        if(m.type==='ONMSI_103_CANCEL'){
            closeViewer(s.tab.id,m.token);
            for(const job of jobs.values())if(job.owner===s.tab.id&&job.token===m.token){job.cancelled=true;if(job.detail)void chrome.tabs.remove(job.detail).catch(()=>{});if(job.moica)void chrome.scripting.executeScript({target:{tabId:job.moica},world:'MAIN',func:t=>{if(window.__vienaOnmsiMoica?.token===t)window.__vienaOnmsiMoica.cancel();},args:[m.token]}).catch(()=>{});if(job.mira)void chrome.scripting.executeScript({target:{tabId:job.mira},world:'MAIN',func:t=>{if(window.__vienaOnmsiMira?.token===t)window.__vienaOnmsiMira.cancel();},args:[m.token]}).catch(()=>{});}reply({ok:true});return;
        }
        if(!['ONMSI_103_DETAIL','ONMSI_103_MIRA','ONMSI_103_MOICA','ONMSI_103_VIEW','ONMSI_103_VIEW_NAV','ONMSI_103_CREATE'].includes(m.type)){reply({ok:false,message:'Operación desconocida.'});return;}
        const key=s.tab.id+':'+m.type;if(jobs.has(key)){reply({ok:false,message:'La consulta anterior está finalizando.'});return;}
        const job={owner:s.tab.id,token:m.token,cancelled:false};jobs.set(key,job);
        const check=()=>{if(job.cancelled)throw Error('Consulta detenida.');};
        void(async()=>{
            if(m.type==='ONMSI_103_VIEW_NAV'){
                if(!/^\d{1,6}$/.test(m.action||''))throw Error('Acción del visor inválida.');const v=await viewerFor(s.tab.id,m.token);if(!v)throw Error('El visor ya no está disponible. Volvé a abrir el ticket.');
                const r=await chrome.scripting.executeScript({target:{tabId:v.tab},world:'MAIN',func:(t,a)=>window.__vienaOnmsiViewer?.token===t?window.__vienaOnmsiViewer.navigate(a):{complete:false,message:'El visor venció. Volvé a abrirlo.'},args:[m.token,m.action]});check();return r[0]?.result||{complete:false,message:'MOICA no devolvió la pestaña.'};
            }
            if(m.type==='ONMSI_103_DETAIL'){
                if(!/^\d{1,12}$/.test(m.id||''))throw Error('ID inválido.');
                const url='http://onmsi.telecentro.net.ar/app.jsp#alarm_detail?id='+m.id,t=await chrome.tabs.create({url,active:false});job.detail=t.id;
                try{for(let i=0;i<100;i++){check();try{const a=(await chrome.scripting.executeScript({target:{tabId:t.id},func:id=>location.hash==='#alarm_detail?id='+id?globalThis.VienaOnmsi?.detail(document,id):null,args:[m.id]}))[0]?.result;if(a)return a;}catch(e){check();}await pause(250);}throw Error('No se pudo leer el detalle; revisá la sesión ONMSi.');}
                finally{await chrome.tabs.remove(t.id).catch(()=>{});}
            }
            if(m.type==='ONMSI_103_MIRA'){
                const scope=VienaOnmsi.scope(m.origin,VienaNodeTech);if(scope.kind!=='hfc'||!scope.nodes.some(n=>n.name===m.node))throw Error('Este Origin requiere revisión manual.');
                const tabs=await chrome.tabs.query({url:'https://mira5-gdt.telecentro.net.ar/*'}),tab=tabs.find(t=>!t.discarded&&new URL(t.url).pathname==='/stats_frontend.php');if(!tab)throw Error('Abrí Estadísticas de MIRA5 e iniciá sesión.');job.mira=tab.id;
                const r=await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:mira,args:[m.node,m.token,VienaOnmsi.aliases(m.node,VienaNodeTech)]});check();if(!r[0]?.result)throw Error('MIRA5 no devolvió una lectura.');
                for(const [k,v] of identities)if(Date.now()-v.at>120000)identities.delete(k);
                if(r[0].result.verified)identities.set(s.tab.id+':'+m.token+':'+m.node,{at:Date.now(),origin:m.origin,physical:r[0].result.physical,relationPending:Boolean(r[0].result.relationPending)});return r[0].result;
            }
            if(m.type==='ONMSI_103_MOICA'||m.type==='ONMSI_103_VIEW'){
                const view=m.type==='ONMSI_103_VIEW';
                const viewportWidth=m.viewportWidth===undefined?1000:m.viewportWidth;if(view&&(!Number.isInteger(viewportWidth)||viewportWidth<240||viewportWidth>4096))throw Error('Ancho del visor inválido.');
                const scope=VienaOnmsi.scope(m.origin,VienaNodeTech),candidate=scope.nodes.find(n=>n.name===m.parent),identity=identities.get(s.tab.id+':'+m.token+':'+m.parent);
                if(view?!/^\d{6}FO\d+$/i.test(m.ticket||''):!candidate||!/^[A-Z0-9]{1,32}$/.test(m.node)||!(candidate.registered&&m.node===m.parent||identity?.origin===m.origin&&Date.now()-identity.at<120000&&(m.node===m.parent||identity.physical.includes(m.node)||candidate.technology.toUpperCase()==='VCCAP'&&identity.physical.includes(m.parent)&&VienaOnmsi.aliases(m.parent,VienaNodeTech).includes(m.node))))throw Error('Identidad no confirmada para buscar en MOICA.');
                const tabs=await chrome.tabs.query({url:'https://moica2.telecentro.net.ar/*'}),tab=tabs.find(t=>!t.discarded&&new URL(t.url).pathname==='/buscarTicket.php');if(!tab)throw Error('Abrí Buscar Ticket de MOICA e iniciá sesión.');job.moica=tab.id;
                if(view){const prior=viewers.get(s.tab.id);if(prior)await closeViewer(s.tab.id,prior.token);}check();
                const r=await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:VienaOnmsiMoica.query,args:[view?m.ticket:m.node,m.token,view,s.tab.id,viewportWidth]});check();if(!r[0]?.result)throw Error('MOICA no devolvió una lectura.');if(view&&r[0].result.complete)viewers.set(s.tab.id,{tab:tab.id,token:m.token});return view?r[0].result:{...r[0].result,matchedName:m.node,candidateSearch:Boolean(m.node!==m.parent&&(identity?.relationPending||!identity?.physical.includes(m.node)))};
            }
            if(creating)throw Error('Ya se está preparando un ticket.');
            const recipe=VienaOnmsiPrepare.recipe(m.kind),a=m.alarm;if(!a||!/^\d{1,12}$/.test(a.id)||VienaOnmsi.fields.some(([,k])=>typeof a[k]!=='string'||a[k].length>4000))throw Error('Alarma incompleta.');
            creating=true;try{
                const url='https://moica2.telecentro.net.ar/viewCrearTktManual.php',tabs=await chrome.tabs.query({url:'https://moica2.telecentro.net.ar/*'});let tab=tabs.find(t=>!t.discarded&&new URL(t.url).pathname==='/viewCrearTktManual.php');
                if(tab){await chrome.tabs.update(tab.id,{active:true});await chrome.windows.update(tab.windowId,{focused:true});}else tab=await chrome.tabs.create({url,active:true});
                for(let i=0;i<100;i++){check();const t=await chrome.tabs.get(tab.id);if(t.status==='complete'&&t.url===url)break;await pause(150);}
                const t=await chrome.tabs.get(tab.id);if(t.status!=='complete'||t.url!==url)throw Error('Crear ticket no terminó de cargar. Revisá la sesión.');
                const results=await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:VienaOnmsiPrepare.prepare,args:[recipe,{id:a.id,message:VienaOnmsi.copy(a)},m.token]});const result=results[0]?.result;if(!result?.ok)throw Error(result?.message||'No se pudo completar el formulario.');
                const stored=await chrome.storage.local.get('viena_usuario').catch(()=>({}));
                await chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:VienaOnmsiPrepare.tracking,args:[{origin:a.origin,specificProblem:a.specificProblem,severity:a.severity,operator:String(stored.viena_usuario||''),message:VienaOnmsi.copy(a)}]});return result;
            }finally{creating=false;}
        })().then(data=>reply({ok:true,data})).catch(e=>reply({ok:false,message:e.message||'No se pudo completar la operación.'})).finally(()=>{if(jobs.get(key)===job)jobs.delete(key);});return true;
    });
    chrome.tabs.onRemoved.addListener(id=>{const v=viewers.get(id);if(v)closeViewer(id,v.token);for(const [owner,record] of viewers)if(record.tab===id)viewers.delete(owner);for(const j of jobs.values())if(j.owner===id)j.cancelled=true;});
})();
