(() => {
    'use strict';
    const path='node-background.html',scriptId='viena-node-hidden-reader-v1';
    let creating;
    async function ensure() {
        if(creating)return creating;
        creating=(async()=>{
            const scripts=await chrome.scripting.getRegisteredContentScripts({ids:[scriptId]});
            if(!scripts.length)await chrome.scripting.registerContentScripts([{id:scriptId,
                matches:['https://mira5-gdt.telecentro.net.ar/stats_frontend.php*','https://mira5-gdt.telecentro.net.ar/','https://mira5-gdt.telecentro.net.ar/index.php*','https://fuentes.telecentro.net.ar/webs/home.php*','https://grafana-telemetria.telecentro.net.ar/d/*'],
                js:['js/71-node-status.js','js/77-node-hidden-bridge.js'],world:'MAIN',allFrames:true,runAt:'document_idle',persistAcrossSessions:false}]);
            const contexts=await chrome.runtime.getContexts({contextTypes:['OFFSCREEN_DOCUMENT'],documentUrls:[chrome.runtime.getURL(path)]});
            if(!contexts.length)await chrome.offscreen.createDocument({url:path,reasons:['DOM_SCRAPING'],justification:'Consultar el resumen de nodos con los lectores nativos sin abrir pestañas del operador.'});
        })();
        try{await creating;}finally{creating=null;}
    }
    globalThis.VienaNodeBackground={async read(kind,node,cos=''){
        if(kind==='grafana'){
            if(!globalThis.VienaGrafanaApi)throw Error('El lector de Grafana no está disponible. Recargá la extensión.');
            return VienaGrafanaApi.read(node,cos);
        }
        await ensure();
        const target=kind==='mira'?'mira-stats':kind==='grafana'?'grafana-vccap':'fuentes';
        const result=await chrome.runtime.sendMessage({type:'VIENA_NODE_HIDDEN_READ',kind,node,cos,url:DESTINATION_CONFIGS[target].url});
        if(!result?.ok)throw Error(result?.message||'No se pudo consultar la plataforma oculta.');
        return result.data;
    }};
})();
