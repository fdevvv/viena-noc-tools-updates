/* MOICA native contracts: external dump 2026-10-29, asociarTkt/emanciparTicket. */
(() => {
 'use strict';
 const validId=v=>typeof v==='string'&&/^[a-f0-9]{24}$/i.test(v);
 const validNumber=v=>typeof v==='string'&&/^\d{6}[A-Z]{2}\d+$/.test(v);
 function listedFieldTask(read){
  const rawNumber=read('last_field_task.ticketNumber'),rawState=read('last_field_task.status');
  if(rawNumber==null||rawState==null)return{active:false,label:'Campo: sin información en listado'};
  const number=String(rawNumber).trim(),state=String(rawState).trim().toUpperCase().replace(/\s+/g,' ').replace(/^ENCURSO$/,'EN CURSO').replace(/^ENVIAJE$/,'EN VIAJE');
  if(number.length>100||state.length>100||/[\u0000-\u001f<>]/.test(number+state))return{active:false,label:'Campo: información no verificable en listado'};
  if(!number&&!state)return{active:false,label:'Campo: sin tarea informada en listado'};
  if(!number||!state)return{active:false,label:'Campo: '+(number||'sin número')+' · '+(state||'sin estado')+' (listado)'};
  return{active:['EN CURSO','AGENDADA','INICIADA','EN VIAJE'].includes(state),label:'Campo: '+number+' · '+state+' (listado)'};
 }
 function createRunner(io){
  let busy=false;const plans=new WeakSet();
  const check=()=>{if(!io.active())throw Error('La bandeja cambió o se detuvo el proceso. Volvé a revisar la selección.');};
  function identity(t){if(!t||!validId(t.id)||!validId(t.queue)||!validNumber(t.number)||typeof t.parent!=='string'||t.parent&&!validNumber(t.parent))throw Error('No se pudo verificar la identidad o el padre del ticket.');return t;}
  const equal=(a,b)=>a.id===b.id&&a.number===b.number&&a.queue===b.queue&&a.parent===b.parent;
  async function targetChain(number,children,allowPromotion=false){
   const seen=new Set();let current=number,target,detachRequired=false;
   for(let depth=0;current;depth++){
    check();if(depth>=30||seen.has(current))throw Error('El nuevo padre tiene una cadena circular o no verificable.');
    if(children.some(t=>t.number===current)){if(!allowPromotion)throw Error('El nuevo padre produciría una asociación circular.');detachRequired=true;}
    seen.add(current);const t=identity(await io.lookup(current));if(t.number!==current)throw Error('El padre consultado no coincide con el solicitado.');if(!target)target=t;current=t.parent;
   }
   return{...target,detachRequired};
  }
  return{
   async prepare(tickets,number,reason){
    if(busy)throw Error('Hay una gestión en curso.');busy=true;
    try{
     check();number=String(number||'').trim().toUpperCase();reason=String(reason||'').trim();
     if(!validNumber(number)||!reason||reason.length>4000||!Array.isArray(tickets)||!tickets.length||tickets.length>100)throw Error('Seleccioná entre 1 y 100 tickets, un padre válido y un motivo de hasta 4000 caracteres.');
     const rows=[],ids=new Set();for(const item of tickets){identity(item);if(ids.has(item.id)||item.number===number)throw Error('La selección contiene duplicados o el nuevo padre.');ids.add(item.id);}
     const target=await targetChain(number,tickets,true);
     if(target.detachRequired&&!io.allowed(target,true))throw Error('No tenés permisos para emancipar primero el nuevo padre.');
     for(const item of tickets){check();const t=identity(await io.read(item));if(t.id!==item.id||t.number!==item.number||t.queue!==item.queue)throw Error('Un ticket cambió de identidad o bandeja. Volvé a seleccionarlo.');if(t.parent!==number&&!io.allowed(t,!!t.parent))throw Error('No tenés permisos para cambiar el padre de '+t.number+'.');rows.push({...t});}
     check();const plan={rows,target,reason,created:Date.now()};plans.add(plan);return plan;
    }finally{busy=false;}
   },
   async commit(plan){
    if(busy||!plans.has(plan)||Date.now()-plan.created>120000)throw Error('La revisión venció o ya fue utilizada. Volvé a revisar los tickets.');
    plans.delete(plan);busy=true;const results=plan.rows.map(t=>({number:t.number,state:'pending',message:'Pendiente'}));
    try{
     check();let target=await targetChain(plan.target.number,plan.rows,true);if(!equal(target,plan.target)||target.detachRequired!==plan.target.detachRequired)throw Error('El nuevo padre cambió desde la revisión.');
     // Preflight every child before the first write, then again immediately before its pair.
     for(const t of plan.rows){check();if(!equal(identity(await io.read(t)),t))throw Error('Un ticket cambió desde la revisión. Revisá nuevamente.');}
     if(target.detachRequired){
      // A selected ancestor can become a child only after the target is detached.
      for(const t of plan.rows)if(t.parent!==target.number&&!io.allowed(t,!!t.parent))throw Error('No se pudieron verificar todos los permisos antes de emancipar el nuevo padre.');
      if(!io.allowed(target,true))throw Error('No tenés permisos para emancipar el nuevo padre.');
      check();if(!equal(identity(await io.read(target)),target))throw Error('El nuevo padre cambió antes de emanciparlo.');
      const status={number:target.number,role:'target',state:'pending',message:'Preparando nuevo padre'};results.push(status);
      try{
       await io.write('EMANCIPAR-TKT',{idTicket:target.id,idColaTkt:target.queue,motivoEmanciparTkt:plan.reason});
       const detached=identity(await io.read(target));if(detached.id!==target.id||detached.number!==target.number||detached.queue!==target.queue||detached.parent!=='')throw Error('No se confirmó la emancipación del nuevo padre.');
       target={...detached,detachRequired:false};status.state='target_ready';status.message='Nuevo padre emancipado y verificado';io.progress?.(results);
      }catch(e){status.state='uncertain';status.message='No se pudo confirmar la emancipación del nuevo padre. '+e.message+' No se modificaron los hijos; revisá el destino antes de repetir.';io.progress?.(results);return results;}
     }
     for(let i=0;i<plan.rows.length;i++){
      const t=plan.rows[i],r=results[i];let wrote=false,emancipated=false;
      try{
       check();const now=identity(await io.read(t));if(!equal(now,t))throw Error('El ticket cambió desde la revisión.');
       if(t.parent===target.number){r.state='unchanged';r.message='Ya asociado al padre indicado';io.progress?.(results);continue;}
       if(!io.allowed(t,!!t.parent))throw Error('Permisos de asociación o emancipación no disponibles.');
       await targetChain(target.number,plan.rows);check();
       if(t.parent){
        wrote=true;await io.write('EMANCIPAR-TKT',{idTicket:t.id,idColaTkt:t.queue,motivoEmanciparTkt:plan.reason});
        const detached=identity(await io.read(t));if(detached.id!==t.id||detached.number!==t.number||detached.queue!==t.queue||detached.parent!=='')throw Error('No se confirmó la emancipación.');emancipated=true;
       }
       // Complete this pair even if Stop was requested while emancipating; Stop affects the next ticket.
       wrote=true;await io.write('ASOCIAR-TKT',{idTicket:t.id,idColaTkt:t.queue,nroTicketPadre:target.number,motivoAsociarPadreTkt:plan.reason});
       const linked=identity(await io.read(t));if(linked.id!==t.id||linked.number!==t.number||linked.queue!==t.queue||linked.parent!==target.number)throw Error('No se confirmó el nuevo padre.');
       r.state='associated';r.message='Asociado a '+target.number;
      }catch(e){r.state=wrote?'uncertain':'blocked';r.message=(emancipated?'Emancipación confirmada; asociación pendiente de verificar. ':'')+e.message+(wrote?' Revisá el ticket antes de repetir.':'');io.progress?.(results);break;}
      io.progress?.(results);
     }
     return results;
    }finally{busy=false;}
   }
  };
 }
 if(typeof module==='object'&&module.exports){module.exports={createRunner,listedFieldTask};return;}
 if(location.origin!=='https://moica2.telecentro.net.ar'||location.pathname!=='/home.php'||new URL(location.href).searchParams.get('standalone')==='1'||window.__vienaMoicaParent)return;
 window.__vienaMoicaParent=true;
 let grid=null,fingerprint='',dialog,root,list,parentInput,reasonInput,status,review,stop,close,runner=null,acting=false,stopped=false,rows=[],results=null;
 const buttons=new Map(),$=()=>window.jQuery;
 const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
 const visible=n=>!!n?.isConnected&&n.getClientRects().length>0;
 function currentGrid(){return ['grid_TktsSector_Todos','grid_TktsSector'].map(id=>document.getElementById(id)).find(n=>n?.grid&&visible(document.getElementById('gview_'+n.id)));}
 function stamp(g){return JSON.stringify([g?.id,$()(g).jqGrid('getGridParam','url'),window.sectorSelected]);}
 function active(){return !stopped&&currentGrid()===grid&&stamp(grid)===fingerprint;}
 function post(data){return new Promise((resolve,reject)=>{$().ajax({url:'scripts/ajaxTickets2.php',method:'POST',dataType:'json',timeout:20000,data,
  success:r=>{if(!r||Object.hasOwn(r,'noses')||r.error!=='')reject(Error(typeof r?.error==='string'&&r.error?r.error:'MOICA no confirmó la operación. Revisá la sesión.'));else resolve(r);},
  error:()=>reject(Error('La respuesta de MOICA no pudo confirmarse.'))});});}
 function record(d){
  const id=d?._id?.$oid??d?._id,queue=d?.estado_actual?.cola??d?.['estado_actual.cola'],number=d?.nroTkt;
  if(!validId(id)||!validId(queue)||!validNumber(number)||!Object.hasOwn(d,'ticketPadre'))throw Error('MOICA no devolvió identidad, bandeja y padre verificables.');
  const parent=d.ticketPadre===null?'':d.ticketPadre;if(typeof parent!=='string'||parent&&!validNumber(parent))throw Error('El padre actual no pudo verificarse.');return{id,queue,number,parent};
 }
 async function read(t){return record((await post({accion:'GET-TKT',idTicket:t.id})).data);}
 async function lookup(number,identities){
  if(!validNumber(number))throw Error('El número del padre no es válido.');
  // Native showTktPadre resolves a number independently of tray/grid filters.
  const resolvedId=identities.get(number)??(await post({accion:'GET-ID-TKT',nroTicket:number})).data;
  if(!validId(resolvedId))throw Error('MOICA no devolvió una identidad válida para el padre.');
  // Reuse only a validated ID within this action. State/parent are always read fresh.
  const t=await read({id:resolvedId});
  if(t.id!==resolvedId||t.number!==number)throw Error('El padre consultado no coincide con el solicitado.');
  identities.set(number,t.id);
  return t;
 }
 function allowed(t,detach){const p=window.arrSectores?.find(c=>c.id===t.queue)?.atrPermiso;return p?.Asociar==='1'&&(!detach||p.Emancipar==='1');}
 function paint(){
  list.replaceChildren();for(const t of rows){
   const card=el('div',null,'ticket'),label=el('label',null,'choice'),box=el('input'),isParent=t.number===parentInput.value.trim().toUpperCase();
   box.type='checkbox';box.checked=t.selected&&!isParent;box.disabled=acting||!!results||isParent;box.setAttribute('aria-label','Seleccionar '+t.number+' como hijo');
   box.onchange=()=>{t.selected=box.checked;invalidate();};const text=el('span',null,'ticket-text'),number=el('strong',t.number,'ticket-number');text.append(number,document.createTextNode(' — '),el('span',t.problem||'Problema sin información en el listado','problem'));label.append(box,text);card.append(label);
   const parentState=el('span',t.verified?'Padre verificado: '+(t.parent||'sin padre'):t.parentKnown?'Padre en listado: '+(t.parent||'sin padre'):'Padre: se comprueba al aplicar','parent-state'),metadata=el('div',null,'ticket-meta'),taskState=el('span',t.fieldTask.label,'task-state');taskState.dataset.active=String(t.fieldTask.active);card.classList.toggle('field-active',t.fieldTask.active);metadata.append(parentState,taskState);card.append(metadata);
   const use=el('button',isParent?'Es el nuevo padre':'Usar como padre','use-parent');use.type='button';use.disabled=acting||!!results||isParent;use.setAttribute('aria-label','Usar '+t.number+' como nuevo padre');use.onclick=()=>{parentInput.value=t.number;excludeParent();};card.append(use);
   if(results){const r=results.find(r=>r.number===t.number);if(r)card.append(el('strong',r.message,'result '+r.state));}list.append(card);
  }
 }
 function excludeParent(){const number=parentInput.value.trim().toUpperCase();for(const t of rows)if(t.number===number)t.selected=false;invalidate();paint();}
 function invalidate(){review.hidden=false;}
 function busy(value){acting=value;review.disabled=value;parentInput.disabled=value||!!results;reasonInput.disabled=value||!!results;close.disabled=value;stop.hidden=!value;paint();}
 function ensure(){
  if(dialog)return;const host=el('div');host.id='viena-moica-parent';document.body.append(host);root=host.attachShadow({mode:'open'});const style=el('style');style.textContent=':host{color-scheme:light dark}dialog{box-sizing:border-box;width:min(760px,94vw);max-height:90vh;overflow:auto;border:1px solid #69849c;border-radius:14px;padding:24px;background:#f6f9fc;color:#172f45;font:15px/1.5 Arial}dialog::backdrop{background:#081a30b0}h2{margin:0 0 8px}label{display:block;margin:12px 0}input[type=text],textarea{box-sizing:border-box;display:block;width:100%;padding:10px;border:1px solid #91a6ba;border-radius:6px;font:inherit;background:#fff;color:#172f45}.ticket{padding:10px;border:1px solid #c8d6e2;border-radius:7px}.ticket input{margin-right:9px}.result{display:block;margin-left:25px}.associated,.unchanged{color:#166534}.uncertain,.blocked{color:#a52222}button{padding:10px 16px;margin:6px 8px 0 0;border:1px solid #7c96ac;border-radius:7px;cursor:pointer;font:inherit;background:#fff;color:#173e60}button.primary{background:#14629d;color:white}button:disabled{opacity:.55;cursor:default}[hidden]{display:none!important}.actions{display:flex;flex-wrap:wrap}p{overflow-wrap:anywhere}#status{white-space:pre-wrap}@media(prefers-color-scheme:dark){dialog{background:#172737;color:#e6eef6}.ticket{border-color:#52667a}input[type=text],textarea,button{background:#233a50;color:#fff}.associated,.unchanged{color:#86efac}.uncertain,.blocked{color:#fca5a5}}';style.textContent+=' .ticket-meta{grid-column:1 / -1;display:flex;flex-wrap:wrap;gap:2px 10px;margin:2px 0 0 19px;font-size:11px}.ticket-meta .parent-state{margin:0}.task-state{font-size:11px}.task-state[data-active=true]{font-weight:600;color:#08765d}.ticket.field-active{border-color:#318b7b;border-left-width:3px}@media(prefers-color-scheme:dark){.task-state[data-active=true]{color:#86efac}} .ticket-list{max-height:min(34vh,300px);overflow:auto;overscroll-behavior:contain;padding-right:4px}.ticket{display:grid;grid-template-columns:minmax(0,1fr) auto;column-gap:8px;padding:6px 8px;margin:5px 0;font-size:12px;line-height:1.35}.choice{display:flex;align-items:center;gap:6px;margin:0;min-width:0;font-size:12px}.choice input{flex-shrink:0;margin:0}.ticket-text{min-width:0;overflow-wrap:anywhere}.ticket-number{font-weight:600;white-space:nowrap}.parent-state{grid-column:1 / -1;font-size:11px;opacity:.75;margin:2px 0 0 19px}.use-parent{grid-column:2;grid-row:1;align-self:center;margin:0;font-size:11px;line-height:1.3;padding:5px 7px;white-space:nowrap}.ticket .result{grid-column:1 / -1;margin:3px 0 0 19px;font-size:11px}';root.append(style);
  dialog=el('dialog');dialog.setAttribute('aria-labelledby','title');const title=el('h2','Cambiar padre de tickets');title.id='title';dialog.append(title,el('p','Seleccioná los tickets, indicá el nuevo padre y el motivo. Cambiar padre desasocia y asocia en un solo paso.'));
  list=el('div',null,'ticket-list');list.tabIndex=0;list.setAttribute('aria-label','Tickets disponibles para cambiar padre');dialog.append(list);const parentLabel=el('label','Nuevo padre');parentInput=el('input');parentInput.type='text';parentInput.maxLength=40;parentInput.autocomplete='off';parentLabel.append(parentInput);const reasonLabel=el('label','Motivo para emancipar y asociar');reasonInput=el('textarea');reasonInput.rows=3;reasonInput.maxLength=4000;reasonLabel.append(reasonInput);dialog.append(parentLabel,reasonLabel);
  status=el('p');status.id='status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');dialog.append(status);const actions=el('div',null,'actions');review=el('button','Cambiar padre','primary');stop=el('button','Detener después del ticket actual');stop.hidden=true;close=el('button','Cerrar');actions.append(review,stop,close);dialog.append(actions);root.append(dialog);
  parentInput.oninput=excludeParent;reasonInput.oninput=invalidate;close.onclick=()=>dialog.close();dialog.addEventListener('cancel',e=>{if(acting)e.preventDefault();});stop.onclick=()=>{stopped=true;stop.disabled=true;status.textContent='Se completará el ticket actual y se detendrá el resto. No repitas gestiones pendientes sin verificar.';};
  review.onclick=async()=>{if(acting)return;busy(true);status.textContent='Validando el cambio de padre...';const identities=new Map();try{stopped=false;runner=createRunner({active,allowed,lookup:number=>lookup(number,identities),read,write:(accion,data)=>post({accion,...data}),progress:r=>{results=r;for(const result of r){if(['associated','unchanged','target_ready'].includes(result.state)){const t=rows.find(t=>t.number===result.number);if(t){t.parent=result.state==='target_ready'?'':parentInput.value.trim().toUpperCase();t.verified=true;}}}paint();}});const reviewed=await runner.prepare(rows.filter(t=>t.selected),parentInput.value,reasonInput.value);for(const t of rows){const fresh=reviewed.rows.find(r=>r.id===t.id);if(fresh){t.parent=fresh.parent;t.verified=true;}}paint();status.textContent='Desasociando y asociando los tickets...';results=await runner.commit(reviewed);paint();const children=results.filter(r=>r.role!=='target'),ok=children.filter(r=>['associated','unchanged'].includes(r.state)).length;status.textContent=ok+' de '+children.length+' tickets confirmados con el nuevo padre. '+(ok===children.length?'Cambio finalizado.':'Revisá los resultados pendientes antes de repetir.');const targetStatus=results.find(r=>r.role==='target');if(targetStatus)status.textContent+=' '+targetStatus.message;}catch(e){status.textContent=e.message;}finally{identities.clear();busy(false);if(results){review.hidden=true;refresh();}}};
 }
 function refresh(){
  try{
   if(currentGrid()!==grid||stamp(grid)!==fingerprint){status.textContent+=' El listado cambió; actualizalo desde la bandeja actual.';return;}
   // Trace25: clear only Nro Ticket, resolved by the native column identity, never nth-of-type.
   const header=document.getElementById('gview_'+grid.id),input=header?.querySelector('[id="gs_'+grid.id+'_nroTkt"], [id="gs_nroTkt"]'),clear=input?.closest('th')?.querySelector('a.clearsearchclass');
   if(input?.value&&clear)clear.click();else $()(grid).trigger('reloadGrid',[{current:true}]);
   status.textContent+=' Listado actualizado.';
  }catch(_){status.textContent+=' No se pudo actualizar el listado; recargalo desde MOICA.';}
 }
 async function open(g){
  if(acting)return;ensure();grid=g;fingerprint=stamp(g);results=null;stopped=false;stop.disabled=false;invalidate();review.hidden=false;parentInput.disabled=reasonInput.disabled=false;rows=[];status.textContent='';
  try{const checks=[...g.querySelectorAll('input.jsMultipleSector')];for(const box of checks){const number=[...box.classList].find(c=>c.startsWith('tkt-'))?.slice(4),queue=[...box.classList].find(c=>c.startsWith('cola-'))?.slice(5);if(!validId(box.id)||!validId(queue)||!validNumber(number))throw Error('La selección nativa no pudo verificarse.');const row=box.closest('tr'),problem=row?.querySelector('[aria-describedby="'+g.id+'_problemas"]')?.textContent.trim()||'',parentCell=row?.querySelector('[aria-describedby="'+g.id+'_ticketPadre"]'),parent=parentCell?.textContent.trim()||'',parentKnown=!!parentCell&&(!parent||validNumber(parent));const fieldTask=listedFieldTask(key=>row?.querySelector('[aria-describedby="'+g.id+'_'+key+'"]')?.textContent);rows.push({id:box.id,number,queue,parent:parentKnown?parent:'',parentKnown,problem,fieldTask,selected:box.checked});}if(!rows.length)throw Error('No hay tickets cargados en esta página de la bandeja.');excludeParent();status.textContent='Tickets de la página cargada. El padre del listado se comprueba nuevamente al aplicar.';}catch(e){status.textContent=e.message;}dialog.showModal();
 }
 function mount(){
  if(!$())return;
  for(const id of ['grid_TktsSector','grid_TktsSector_Todos']){const g=document.getElementById(id),caption=document.querySelector('#gview_'+id+' .ui-jqgrid-titlebar');if(!g?.grid||!caption)continue;let b=buttons.get(id);if(!b?.isConnected){b=el('button','Cambiar padre','btn btn-primary btn-xs');b.id='viena-parent-'+id;b.type='button';b.style.cssText='display:inline-block;vertical-align:middle;margin:0 0 0 10px;padding:4px 12px;font-size:14px;line-height:1.3;float:none';caption.append(b);b.onclick=e=>{e.stopPropagation();void open(g);};buttons.set(id,b);$()(g).on('jqGridLoadComplete.vienaParent jqGridGridComplete.vienaParent',mount);}const po=document.getElementById('viena-gec13-po-button');if(po?.parentElement===caption&&po.nextElementSibling!==b)po.insertAdjacentElement('afterend',b);}
 }
 // Existing PO context signal follows queue/grid changes; no global observer or polling.
 window.addEventListener('message',e=>{if(e.source===window&&e.origin===location.origin&&e.data?.type==='VIENA_GEC13_CONTEXT')mount();});
 document.addEventListener('click',e=>{if(e.target.closest?.('#TAB-LIST-COLAS'))setTimeout(mount,0);});
 mount();
})();
