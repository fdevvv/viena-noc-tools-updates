(() => {
 'use strict';
 const journalKey='viena_gec13_po_actions_v1';let owner=null,reading=false,serial=Promise.resolve();
 const validSender=sender=>{try{return sender.id===chrome.runtime.id&&sender.frameId===0&&Number.isInteger(sender.tab?.id)&&new URL(sender.tab.url).origin==='https://moica2.telecentro.net.ar'&&new URL(sender.tab.url).pathname==='/home.php';}catch(_){return false;}};
 const token=t=>typeof t==='string'&&/^[a-zA-Z0-9-]{10,100}$/.test(t);
 const access=(msg,sender)=>owner?.tab===sender.tab.id&&owner.token===msg.token&&owner.until>Date.now();
 chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(!['VIENA_GEC13_BEGIN','VIENA_GEC13_END','VIENA_GEC13_READ','VIENA_GEC13_RESERVE','VIENA_GEC13_FINISH','VIENA_GEC13_RESOLVE'].includes(msg?.type))return;
  if(!validSender(sender)||!token(msg.token)){reply({ok:false,message:'Consulta no autorizada.'});return;}
  if(msg.type==='VIENA_GEC13_BEGIN'){if(reading||owner&&owner.until>Date.now()&&(owner.tab!==sender.tab.id||owner.token!==msg.token)){reply({ok:false,message:'Hay un análisis de PO en curso. Esperá o detenelo desde esa pestaña.'});return;}owner={tab:sender.tab.id,token:msg.token,until:Date.now()+120000};reply({ok:true});return;}
  if(msg.type==='VIENA_GEC13_END'){if(access(msg,sender))owner=null;reply({ok:true});return;}
  if(msg.type==='VIENA_GEC13_READ'){
   if(!access(msg,sender)){reply({ok:false,stopped:true,message:'El análisis se interrumpió. Volvé a iniciarlo.'});return;}
   if(reading){reply({ok:false,message:'El lector está finalizando una consulta anterior. Reintentá en unos segundos.'});return;}
   if(!['optico','rphy','grafana'].includes(msg.kind)||!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(msg.node)||typeof msg.cos!=='string'||msg.cos.length>100||/[\r\n]/.test(msg.cos)){reply({ok:false,message:'Nodo o plataforma inválidos.'});return;}
   reading=true;owner.until=Date.now()+120000;
   void(async()=>{let timer;try{const snapshot=await Promise.race([VienaNodeBackground.read(msg.kind,msg.node,msg.cos),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('La lectura de potencia venció.')),80000)})]);if(!access(msg,sender)){reply({ok:false,stopped:true,message:'Análisis detenido.'});return;}if(snapshot?.pending||snapshot?.needsSession||snapshot?.unsupported||snapshot?.failure)throw Error('Revisá el acceso a la plataforma y reintentá la lectura.');let data=snapshot;if(msg.kind==='grafana'){if(!snapshot?.href||new URL(snapshot.href).searchParams.get('var-cluster')!==msg.cos)throw Error('Grafana cambió de COS durante la lectura.');data=VienaNodeStatus.grafana(snapshot.text,snapshot.href,msg.node);}reply({ok:true,data,readAt:Date.now()});}catch(e){reply({ok:false,message:e.message||'No se pudo consultar la potencia.'});}finally{clearTimeout(timer);reading=false;}})();return true;
  }
  if(!Array.isArray(msg.ids)||!msg.ids.length||msg.ids.length>200||new Set(msg.ids).size!==msg.ids.length||msg.ids.some(id=>!/^[a-f0-9]{24}$/i.test(id))){reply({ok:false,message:'Selección inválida.'});return;}
  const work=async()=>{
   const saved=await chrome.storage.local.get(journalKey),journal=saved[journalKey]||{};
   if(msg.type==='VIENA_GEC13_RESERVE'){
    if(!['50','34'].includes(msg.action))return{ok:false,message:'Acción inválida.'};
    if(msg.ids.some(id=>journal[id]))return{ok:false,uncertain:true,message:'Hay una gestión previa sin confirmar. Revisá los tickets antes de volver a gestionarlos.'};
    const audit=await globalThis.VienaGecShift.reserve(msg);
    for(const id of msg.ids)journal[id]={token:msg.token,tab:sender.tab.id,action:msg.action,at:Date.now(),audit:audit?.find(t=>t.id===id)||null};
   }else if(msg.type==='VIENA_GEC13_FINISH'){
    if(msg.confirmed!==true)return{ok:true};
    const finished=msg.ids.filter(id=>journal[id]?.token===msg.token&&journal[id]?.tab===sender.tab.id);
    const entries=finished.map(id=>journal[id]);
    for(const id of finished)delete journal[id];
    await globalThis.VienaGecShift.finish(entries,msg.derived===true,extra=>chrome.storage.local.set({[journalKey]:journal,...extra}));return{ok:true};
   }else if(msg.type==='VIENA_GEC13_RESOLVE'){
    // Explicit operator acknowledgement. Never expire an unresolved write.
    if(msg.reviewed!==true)return{ok:false,message:'Confirmá que revisaste los tickets en MOICA.'};for(const id of msg.ids)delete journal[id];
   }
   await chrome.storage.local.set({[journalKey]:journal});return{ok:true};
  };
  const next=serial.then(work);serial=next.catch(()=>{});next.then(reply).catch(()=>reply({ok:false,message:'No se pudo guardar la confirmación. No se realizó la gestión.'}));return true;
 });
 chrome.tabs.onRemoved?.addListener(id=>{if(owner?.tab===id)owner=null;});
})();

// Separate service: no changes to Metrics, updater, startup or existing journal semantics.
(() => {
 'use strict';
 const configKey='viena_gec13_counter_config_v1',outboxKey='viena_gec13_counter_outbox_v1',cacheKey='viena_gec13_counter_cache_v1',protocol='viena-gec13-counter-v1';
 let serial=Promise.resolve(),inFlight=null;
 const queue=fn=>{const p=serial.then(fn);serial=p.catch(()=>{});return p;};
 const senderOK=s=>{try{return s.id===chrome.runtime.id&&s.frameId===0&&Number.isInteger(s.tab?.id)&&new URL(s.tab.url).origin==='https://moica2.telecentro.net.ar'&&new URL(s.tab.url).pathname==='/home.php';}catch(_){return false;}};
 const endpoint=s=>typeof s==='string'&&/^https:\/\/script\.google\.com\/macros\/s\/[a-zA-Z0-9_-]+\/exec$/.test(s);
 const field=(r,k)=>r?.[k]??k.split('.').reduce((v,p)=>v?.[p],r);
 async function remote(config,op,events){
  const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),8000);
  try{
   const response=await fetch(config.endpoint,{method:'POST',cache:'no-store',credentials:'omit',headers:{'Content-Type':'text/plain;charset=UTF-8'},body:JSON.stringify({protocol,key:config.key,op,...(events?{events}:{} )}),signal:abort.signal});
   if(!response.ok)throw Error('remote_http');const data=await response.json(),s=data?.summary;
   if(data?.ok!==true||data.protocol!==protocol||!s||!/^\d{4}-\d{2}-\d{2}$/.test(s.date)||!Number.isSafeInteger(s.serverAt)||!Array.isArray(s.items)||s.items.length>500||![s.total,s.morning,s.afternoon,s.review].every(n=>Number.isSafeInteger(n)&&n>=0)||![null,'07–15','15–23'].includes(s.shift)||![null,10].includes(s.target)||![null,5].includes(s.shiftTarget)||!Array.isArray(data.ack))throw Error('invalid_counter_response');
   if(events&&(!events.every(e=>data.ack.includes(e.eventId))||data.ack.some(id=>!events.some(e=>e.eventId===id))))throw Error('incomplete_ack');
   return data;
  }finally{clearTimeout(timer);}
 }
 async function verify(item,tabId){
   // Existing scripting permission, same-origin read in the operator's current MOICA tab.
   // Worker CSP intentionally does not include MOICA; do not widen it for this counter.
   const results=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},world:'ISOLATED',func:async id=>{
    if(location.origin!=='https://moica2.telecentro.net.ar'||location.pathname!=='/home.php')return null;
    const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),6000);
    try{const response=await fetch('/scripts/ajaxTickets2.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:new URLSearchParams({accion:'GET-TKT',idTicket:id}),signal:abort.signal});if(!response.ok||response.redirected)return null;return await response.json();}catch(_){return null;}finally{clearTimeout(timer);}
   },args:[item.ticketId]});
   const data=results?.[0]?.result,r=data?.data;
   if(data?.error||data?.noses||(r?._id?.$oid??r?._id)!==item.ticketId||r?.nroTkt!==item.number||field(r,'estado_actual.cola')!==item.target)throw Error('destination_unverified');
   const nodes=Array.isArray(r.nodoRef)?r.nodoRef:[r.nodoRef];if(!nodes.some(n=>typeof n==='string'&&n.trim()===item.node))throw Error('node_unverified');return true;
 }
 async function run(tabId){
  const saved=await chrome.storage.local.get([configKey,outboxKey]),config=saved[configKey];
  if(!config||!endpoint(config.endpoint)||!config.key)return;
  // Bounded work per refresh; each read and write has a timeout. Never repeats a derivation.
  const pending=Object.values(saved[outboxKey]||{}).sort((a,b)=>Number(b.verified)-Number(a.verified)||(a.lastAttempt||0)-(b.lastAttempt||0)).slice(0,5);
  for(const item of pending){
   if(!item.verified){let verified=false;try{verified=await verify(item,tabId);}catch(_){}await queue(async()=>{const s=await chrome.storage.local.get(outboxKey),box=s[outboxKey]||{};if(box[item.eventId])Object.assign(box[item.eventId],{verified,lastAttempt:Date.now()});await chrome.storage.local.set({[outboxKey]:box});});if(!verified)continue;item.verified=true;}
   const event={eventId:item.eventId,ticketId:item.ticketId,number:item.number,node:item.node,destination:item.destination,operator:item.operator,confirmedAt:item.confirmedAt};
   const data=await remote(config,'APPEND',[event]);
   await queue(async()=>{const s=await chrome.storage.local.get(outboxKey),box=s[outboxKey]||{};delete box[item.eventId];await chrome.storage.local.set({[outboxKey]:box,[cacheKey]:data.summary});});
  }
  const data=await remote(config,'SUMMARY');await chrome.storage.local.set({[cacheKey]:data.summary});
 }
 function sync(tabId){if(!inFlight)inFlight=run(tabId).finally(()=>{inFlight=null;});return inFlight;}
 async function state(error=false){const s=await chrome.storage.local.get([configKey,outboxKey,cacheKey]),items=Object.values(s[outboxKey]||{});return{ok:true,configured:!!s[configKey],endpoint:s[configKey]?.endpoint||'',pending:items.length,unverified:items.filter(x=>!x.verified).length,summary:s[cacheKey]||null,offline:error};}
 globalThis.VienaGecShift={
  reserve:async msg=>{
   if(!Array.isArray(msg.tickets)||msg.tickets.length!==msg.ids.length||!msg.target||!/^[a-f0-9]{24}$/.test(msg.target))return null;
   if(msg.tickets.some(t=>!msg.ids.includes(t.id)||typeof t.number!=='string'||!/^[A-Z0-9-]{5,50}$/.test(t.number)||typeof t.node!=='string'||!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(t.node)))return null;
   const user=String((await chrome.storage.local.get('viena_usuario')).viena_usuario||'').trim().toLowerCase();
   return msg.tickets.map(t=>({...t,operator:/^[a-zA-Z0-9][a-zA-Z0-9._@-]{0,99}$/.test(user)?user:'sin_detectar',target:msg.target,eventId:msg.token+':'+t.id,destination:msg.action}));
  },
  finish:(entries,derived,persist)=>queue(async()=>{
   if(!derived)return persist({});const s=await chrome.storage.local.get(outboxKey),box=s[outboxKey]||{};
   for(const entry of entries){const a=entry.audit;if(a&&!box[a.eventId])box[a.eventId]={eventId:a.eventId,ticketId:a.id,number:a.number,node:a.node,destination:a.destination,operator:a.operator,target:a.target,confirmedAt:Date.now(),verified:false};}
   // Returned in the SAME storage.set as journal completion: no lost gap on worker suspension.
   await persist({[outboxKey]:box});
  })
 };
 chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(!['VIENA_GEC13_COUNTER_STATUS','VIENA_GEC13_COUNTER_CONFIG'].includes(msg?.type))return;
  if(!senderOK(sender)){reply({ok:false,message:'Consulta no autorizada.'});return;}
  void(async()=>{
   try{
    if(msg.type==='VIENA_GEC13_COUNTER_CONFIG'){
     const prior=(await chrome.storage.local.get(configKey))[configKey],key=msg.key||prior?.key;
     if(!endpoint(msg.endpoint)||typeof key!=='string'||!/^[a-zA-Z0-9_-]{32,200}$/.test(key))throw Error('invalid_config');
     if(inFlight)throw Error('sync_in_progress');
     const config={endpoint:msg.endpoint,key},data=await remote(config,'SUMMARY');
     await queue(async()=>{const saved=await chrome.storage.local.get([outboxKey,configKey]);if(saved[configKey]?.endpoint&&saved[configKey].endpoint!==config.endpoint&&Object.keys(saved[outboxKey]||{}).length)throw Error('pending_destination_change');await chrome.storage.local.set({[configKey]:config,[cacheKey]:data.summary});});
    }
    await sync(sender.tab.id);reply(await state());
   }catch(_){try{reply({...await state(true),message:'No se pudo sincronizar el registro. Los pendientes se conservan.'});}catch(_){reply({ok:false,message:'No se pudo consultar el registro.'});}}
  })();return true;
 });
})();
