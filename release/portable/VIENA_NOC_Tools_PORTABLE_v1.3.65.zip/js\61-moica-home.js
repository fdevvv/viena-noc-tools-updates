(function(){
'use strict';
if(window.__VIENA_MOICA_HOME_NAV__) return;
window.__VIENA_MOICA_HOME_NAV__=true;

const BUSCAR_PATH='/buscarTicket.php';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitFor(fn,timeout=12000,step=100){
  const start=Date.now();
  while(Date.now()-start<timeout){
    const value=fn();
    if(value) return value;
    await sleep(step);
  }
  return null;
}
function click(el){
  if(!el) return false;
  el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,view:window}));
  el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,view:window}));
  el.click();
  return true;
}

chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg?.type==='VIENA_MOICA_GEE_RUN'){
    if(location.pathname!=='/home.php'||window!==top){sendResponse({ok:false,code:'wrong_page',mensaje:'Abrí el inicio de MOICA2 para consultar el nodo.'});return;}
    const token=crypto.randomUUID();let timer;
    const finish=result=>{clearTimeout(timer);window.removeEventListener('message',receive);window.removeEventListener('pagehide',navigating);sendResponse(result);};
    const receive=event=>{if(event.source===window&&event.origin===location.origin&&event.data?.type==='VIENA_MOICA_GEE_RESULT'&&event.data.token===token)finish(event.data.result);};
    const navigating=()=>finish({ok:false,phase:'navigating'});
    window.addEventListener('message',receive);window.addEventListener('pagehide',navigating,{once:true});
    timer=setTimeout(()=>finish({ok:false,code:'receiver_timeout',mensaje:'MOICA2 no respondió a tiempo. Revisá la sesión y reintentá.'}),msg.sector==='GED'?60000:42000);
    window.postMessage({type:'VIENA_MOICA_GEE_REQUEST',token,nodo:msg.nodo,sector:msg.sector,reuseAnalysis:msg.reuseAnalysis===true},location.origin);
    return true;
  }
  if(msg?.type!=='VIENA_MOICA_NAVIGATE') return;
  (async()=>{
    if(location.pathname.includes(BUSCAR_PATH)) return {ok:true,already:true};
    const link=await waitFor(()=>{
      return document.querySelector('a[href="/buscarTicket.php"], a[href$="/buscarTicket.php"], a[href*="buscarTicket.php"]');
    },12000,100);
    if(!link) return {ok:false,code:'buscar_link_not_found'};
    click(link);
    return {ok:true,navigated:true};
  })().then(sendResponse).catch(error=>sendResponse({ok:false,code:'error',detail:String(error?.message||error)}));
  return true;
});
})();
