(function () {
    'use strict';
    const unique = values => [...new Set(values)];
    const streetKey = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/\s+/g, ' ').trim();
    function parseCuadras(text) {
        const nodes = unique([...String(text).matchAll(/^\s*NODO\s+CMTS\s*:\s*([A-Z0-9]+)\s*$/gim)].map(match => match[1].toUpperCase()));
        const rows = [], invalid = [], seen = new Set();
        let inCuadras = false;
        for (const line of String(text).split(/\r?\n/)) {
            if (/^\s*CUADRAS\s*:\s*$/i.test(line)) { inCuadras = true; continue; }
            if (/^\s*[^:]+:/.test(line)) { inCuadras = false; continue; }
            // Anchored address lines exclude operational headings and power thresholds.
            const match = line.match(/^\s*(?:[-•]\s*)?([^:\n]+?)\s+(\d+)\s*[-–—]\s*(\d+)\s*$/);
            if (!match) {
                if (line.trim() && (inCuadras || /^\s*(?:[-•]\s*)?[^:]+\s+\d+\s*[-–—]\s*\S+/.test(line))) invalid.push(line.trim());
                continue;
            }
            if (!/[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/.test(match[1])) { if (inCuadras) invalid.push(line.trim()); continue; }
            const street = streetKey(match[1]), start = Number(match[2]), end = Number(match[3]);
            const first = Math.floor(start / 100) * 100, limit = Math.ceil(end / 100) * 100;
            if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || end <= start || limit - first > 10000) { invalid.push(line.trim()); continue; }
            const key = `${street}|${first}|${limit}`;
            if (seen.has(key)) continue; seen.add(key);
            const blocks = []; for (let block = first; block < limit; block += 100) blocks.push(block);
            rows.push({ street, start, end, blocks, label: `${street} ${start} - ${end}` });
        }
        return { node: nodes.length === 1 ? nodes[0] : '', rows, invalid };
    }
    function matchCuadras(node, row, options) {
        const items = [], covered = new Set(), labels = new Set();
        for (const item of options) {
            const match = String(item.label || '').match(/^\[([A-Z0-9]+)\]\s+(.+?)\s+(\d+)-(\d+)\s+\(CM:\s*\d+\)\s*-\s*(Par|Impar|Ambas)$/i);
            if (!match || match[1].toUpperCase() !== node || streetKey(match[2]) !== row.street || item.nodo_valido !== true || item.idCalle == null) continue;
            const block = Number(match[4]) - 100;
            if (Number(match[3]) !== block + 1 || !row.blocks.includes(block)) continue;
            covered.add(block);
            if (!labels.has(item.label)) { labels.add(item.label); items.push(item); }
        }
        return { items, missing: row.blocks.filter(block => !covered.has(block)) };
    }
    function recognize(text, base) {
        text = String(text || '');
        const known = token => base.has(token) ||
            (/^[A-Z0-9]+[LR]$/.test(token) && ['Legacy', 'VCCAP', 'RPHY'].includes(base.get(token.slice(0, -1)))) ||
            // Two-letter CMTS branches remain candidates: loadNodes requires an exact native match.
            (/^[A-Z0-9]+[LR][A-D]$/.test(token) && ['Legacy', 'VCCAP', 'RPHY'].includes(base.get(token.slice(0, -2))));
        const tokens = [], upper = text.toUpperCase();
        const matches = [];
        let longestKnown = base.maxNodeLength ? base.maxNodeLength + 2 : 0;
        for (const match of upper.matchAll(/[A-Z0-9_]+(?:[.:-][A-Z0-9_]+)*/g)) {
            if (known(match[0])) matches.push(match);
            else {
                const parts = [...match[0].matchAll(/[A-Z0-9]+/g)];
                if (parts.length > 1 && !longestKnown && typeof base.keys === 'function') for (const node of base.keys()) longestKnown = Math.max(longestKnown, node.length + 2);
                for (let i = 0; i < parts.length; i++) {
                    let end = i;
                    // Preserve the longest exact base ID before interpreting its punctuation as separators.
                    for (let j = i + 1; j < parts.length; j++) {
                        const candidate = match[0].slice(parts[i].index, parts[j].index + parts[j][0].length);
                        if (candidate.length > longestKnown) break;
                        if (known(candidate)) end = j;
                    }
                    const part = [match[0].slice(parts[i].index, parts[end].index + parts[end][0].length)];
                    part.index = match.index + parts[i].index; matches.push(part); i = end;
                }
            }
        }
        let previousToken = null, context = '';
        for (const match of matches) {
            let token = match[0];
            const joined = previousToken && /^[ \t]*[,/|;._:\\-][ \t]*$/.test(upper.slice(previousToken.index + previousToken[0].length, match.index));
            if (joined && context && /^[A-Z]{1,3}$/.test(token)) {
                const suffix = context.match(/[A-Z]+$/)?.[0] || '';
                if (token.length <= suffix.length) token = context.slice(0, -token.length) + token;
            }
            tokens.push(token);
            context = known(token) ? token : '';
            previousToken = match;
        }
        const nodes = unique(tokens.filter(known));
        // Exclude address occurrences, not their values: the same number may be a valid ID elsewhere.
        const addresses = [...text.matchAll(/\bDIRECCI[OÓ]N[ \t]*:[ \t]*(?:\r?\n[ \t]*)?[^\r\n;|]*/gi)].map(match => {
            const nextLabel = match[0].search(/\b(?:ID[ \t]+EDIFICIO|ID[ \t]+CLIENTE|ID[ \t]+FUENTE|FUENTE[ \t]+ID|EDIFICIO|CLIENTE|FUENTE|ID)[ \t]*[:#=]/i);
            return [match.index, match.index + (nextLabel < 0 ? match[0].length : nextLabel)];
        });
        const inAddress = index => addresses.some(([start, end]) => index >= start && index < end);
        const buildings = [], clients = [], labeled = new Set();
        const sourceMatches = [...text.matchAll(/\b(?:ID[ \t]+FUENTE|FUENTE[ \t]+ID|FUENTE)\b[ \t]*(?:\([ \t]*(?:ID[ \t]+FUENTE[ \t]*)?)?[:#=\-]?[ \t]*(?:\r?\n[ \t]*)?(\d+)\b/gi)].filter(match => !inAddress(match.index));
        const sources = unique(sourceMatches.map(match => {
            labeled.add(match.index + match[0].lastIndexOf(match[1]));
            return match[1];
        }));
        const labels = /\b(ID[ \t]+EDIFICIO|ID[ \t]+CLIENTE|CLIENTE|EDIFICIO|ID)\b[ \t]*[:#=\-]?[ \t]*(?:\r?\n[ \t]*)?(\d+)\b/gi;
        for (const match of text.matchAll(labels)) {
            if (inAddress(match.index) || sourceMatches.some(source => match.index >= source.index && match.index < source.index + source[0].length)) continue;
            const id = match[2];
            (/CLIENTE/i.test(match[1]) ? clients : buildings).push(id);
            labeled.add(match.index + match[0].lastIndexOf(id));
        }
        const numbers = unique([...text.matchAll(/\b\d{4,}\b/g)].filter(match => !labeled.has(match.index) && !inAddress(match.index)).map(match => match[0]));
        const unknownNodes = unique(tokens.filter(token => /^[A-Z]+\d+[A-Z0-9]*$/.test(token) && !nodes.includes(token)));
        return { nodes, buildings: unique(buildings), clients: unique(clients), sources, numbers, unknownNodes };
    }
    function plan(requested, options) {
        const wanted = unique(requested), sides = unique(options.filter(value => value && value !== 'COMPLETO'));
        if (!wanted.length || !sides.length || wanted.some(value => !sides.includes(value))) {
            throw new Error('Los nodos solicitados no coinciden con las opciones actuales de MOICA.');
        }
        return sides.length === wanted.length && options.includes('COMPLETO') ? ['COMPLETO'] : wanted;
    }
    if (typeof module === 'object' && module.exports) { module.exports = { recognize, plan, parseCuadras, matchCuadras }; return; }
    globalThis.VienaMoicaZoneParsing = Object.freeze({ recognize, plan });
    const MANUAL_MOICA = location.hostname === 'moica2.telecentro.net.ar' && location.pathname === '/viewCrearTktManual.php';
    if (!MANUAL_MOICA || globalThis.__VIENA_MOICA_ZONE_LOADER__) return;
    const message = document.getElementById('TKT-MSG-ADD');
    if (!message || !globalThis.VienaNodeTech || typeof globalThis.jQuery !== 'function') return;
    globalThis.__VIENA_MOICA_ZONE_LOADER__ = true;
    const $ = globalThis.jQuery;
    const byId = id => document.getElementById(id);
    const ui = document.createElement('div');
    ui.id = 'viena-moica-zones';
    ui.setAttribute('data-viena-macro-ui', '');
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'btn btn-primary';
    const bulk = document.createElement('button');
    bulk.type = 'button'; bulk.className = 'btn btn-default'; bulk.textContent = 'Pegar nodos';
    const hint = document.createElement('span'); hint.setAttribute('role', 'status');
    const label = message.parentElement?.querySelector('.input-group-addon');
    if (!label) return;
    ui.append(button, hint); label.append(ui);
    const style = document.createElement('style');
    style.textContent = `#viena-moica-zones{display:flex;flex-direction:column;align-items:center;gap:4px;margin-top:8px;width:52px;white-space:normal}#viena-moica-zones button{width:52px;padding:4px 2px;font-size:11px;white-space:normal;line-height:1.2}#viena-moica-zones span{font-size:10px;overflow-wrap:anywhere}#viena-moica-zone-review{box-sizing:border-box;width:min(560px,calc(100vw - 24px));max-height:85vh;overflow:auto;border:1px solid #b8c7d9;border-radius:10px;padding:18px;background:#fff;color:#24324a;font:14px/1.5 Arial,sans-serif}#viena-moica-zone-review::backdrop{background:rgba(15,35,60,.45)}#viena-moica-zone-review textarea,#viena-moica-zone-review select{width:100%;box-sizing:border-box;margin:8px 0}#viena-moica-zone-review textarea{min-height:110px}#viena-moica-zone-review .zone-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}#viena-moica-zone-review [hidden]{display:none!important}#viena-moica-zone-review button{white-space:normal}#viena-moica-zone-review pre{white-space:pre-wrap;overflow-wrap:anywhere;background:inherit;color:inherit;max-height:28vh;overflow:auto}#viena-moica-zone-review:focus-visible,#viena-moica-zone-review button:focus-visible{outline:2px solid #1769aa;outline-offset:2px}@media(prefers-color-scheme:dark){#viena-moica-zone-review{background:#16243a;color:#e5edf7;border-color:#526780}#viena-moica-zone-review select,#viena-moica-zone-review textarea{background:#20324c;color:#e5edf7}}`;
    document.head.append(style);
    style.textContent += '#viena-moica-zone-review .zone-error{border:2px solid #a65300;border-radius:6px;padding:12px;margin:12px 0;background:#fff3df;color:#653000;font-weight:bold;white-space:pre-wrap;overflow-wrap:anywhere}@media(prefers-color-scheme:dark){#viena-moica-zone-review .zone-error{background:#382913;color:#ffe0a3;border-color:#e5a343}}';
    style.textContent += '#viena-moica-zone-review .zone-unrecognized{border:2px solid #a65300;border-radius:6px;padding:10px;margin:10px 0;background:#fff3df;color:#653000;overflow-wrap:anywhere}#viena-moica-zone-review .zone-unrecognized strong{display:block;font-size:15px}#viena-moica-zone-review .zone-unrecognized p{max-height:12vh;overflow:auto;margin:6px 0;font-weight:bold}@media(prefers-color-scheme:dark){#viena-moica-zone-review .zone-unrecognized{background:#382913;color:#ffe0a3;border-color:#e5a343}}';
    let active = false, cancelled = false, scheduled = false;
    let dialog, picker, technology, preview, status, runButton, input, snapshot, previous, returnFocus, usePasted, selectAll;
    const live = () => recognize(message.value, globalThis.VienaNodeTech);
    function update() {
        const found = live();
        const cuadras = parseCuadras(message.value);
        button.textContent = found.sources.length ? (found.sources.length === 1 ? 'Cargar Fuente' : 'Cargar Fuentes') : cuadras.node && (cuadras.rows.length || cuadras.invalid.length) ? 'Cargar Cuadras' : found.buildings.length ? 'Cargar Edificio' : found.clients.length ? 'Cargar Cliente' : found.nodes.length ? (found.nodes.length === 1 ? 'Cargar Zona' : 'Cargar Zonas') : found.numbers.length ? 'Elegir Cliente / Edificio' : 'Cargar Zona';
        button.disabled = active;
        bulk.disabled = active;
        hint.textContent = found.nodes.length ? `${found.nodes.length} nodo${found.nodes.length === 1 ? '' : 's'} único${found.nodes.length === 1 ? '' : 's'}` : '';
    }
    message.addEventListener('input', () => {
        if (scheduled) return; scheduled = true;
        queueMicrotask(() => { scheduled = false; update(); });
    });
    message.addEventListener('change', update);
    function check() {
        if (cancelled) throw new Error('Carga cancelada. Las zonas del ticket se conservan.');
        if (!message.isConnected || message.value !== snapshot) throw new Error('El mensaje cambió. Revisá los datos antes de volver a cargar.');
        if (byId('TKT-ZONA-JSON-ADD')?.value !== previous.json || byId('TKT-ZONA-TIPO-ADD')?.value !== previous.type) {
            throw new Error('Las zonas del ticket cambiaron durante la carga.');
        }
    }
    async function wait(predicate, label, timeout = 8000) {
        const start = performance.now();
        while (true) {
            check();
            const result = predicate(); if (result) return result;
            if (performance.now() - start >= timeout) throw new Error(`Tiempo agotado: ${label}. Podés volver a intentar cuando termine la consulta.`);
            await new Promise(resolve => setTimeout(resolve, 30));
        }
    }
    async function idle() {
        await wait(() => {
            document.dispatchEvent(new Event('viena:moica-request-status'));
            return $.active === 0 && document.documentElement.getAttribute('data-viena-moica-modal-pending') === '0';
        }, 'esperar a MOICA');
    }
    const visible = element => element && element.isConnected && getComputedStyle(element).display !== 'none' && element.getClientRects().length;
    function clickNative(modal, handler) {
        check();
        const matches = [...modal.querySelectorAll('button[onclick],input[onclick]')].filter(element =>
            (element.getAttribute('onclick') || '').trim() === `${handler}()` && !element.disabled && visible(element));
        if (matches.length !== 1) throw new Error('No se encontró un control nativo único para continuar.');
        matches[0].click();
    }
    async function openNative(type) {
        const select = byId('TKT-ZONA-TIPO-SELECT');
        if (!select || ![...select.options].some(option => option.value === type)) throw new Error(`La zona ${picker.selectedOptions[0].textContent} no está disponible para cargar en este ticket.`);
        // showModalZona first resets the ticket's zones. Open the same native
        // modal directly so unsuccessful searches leave the existing ticket intact.
        const open = { NODO: globalThis.showModalByNodo, EDIFICIO: globalThis.showModalByEdificio, CLIENTE: globalThis.showModalByCliente, CUADRA: globalThis.showModalByCuadra, FUENTE: globalThis.showModalByFuente }[type];
        if (typeof open !== 'function') throw new Error('La selección nativa no está disponible.');
        open();
        const modal = byId(`MO-ZONA-${type}`);
        await wait(() => visible(modal) && modal.classList.contains('in'), 'abrir selección');
        await idle();
        return modal;
    }
    async function suggestions(element, term) {
        check(); await idle();
        const widget = $(element).autocomplete('instance');
        if (!widget || typeof widget.options.source !== 'function') throw new Error('La búsqueda nativa no está lista.');
        let done = false, items;
        widget.options.source.call(element, { term }, result => { if (!done) { items = result; done = true; } });
        try {
            await wait(() => done, `buscar ${term}`); await idle();
            if (!Array.isArray(items)) throw new Error('MOICA no devolvió sugerencias válidas.');
            return { widget, items };
        } finally { done = true; }
    }
    function chooseSuggestion(element, widget, item) {
        check();
        element.value = item.value || item.label;
        widget._trigger('select', new Event('autocompleteselect'), { item });
    }
    async function loadNodes(modal, requested) {
        const element = byId('TKT-NODO-autocom-ADD'), select = byId('TKT-NODO-CMTS-ADD');
        if (!element || !select) throw new Error('No están disponibles los controles de nodos.');
        const remaining = new Set(requested), groups = [];
        while (remaining.size) {
            const node = remaining.values().next().value;
            let found;
            for (let length = node.length; length >= 4 && !found; length--) {
                status.textContent = `Buscando ${node}…`;
                const result = await suggestions(element, node.slice(0, length));
                const matches = result.items.filter(item => Array.isArray(item.nodoCmts) && (item.nodoCmts.includes(node) || item.label === node && item.tipoAcceso === 'FTTH' && item.nodoCmts.length === 0));
                if (matches.length > 1) throw new Error(`La búsqueda de ${node} es ambigua.`);
                if (matches.length === 1) found = { ...result, item: matches[0] };
            }
            if (!found) throw new Error(`MOICA no encontró el nodo exacto ${node}.`);
            const wholeNode = found.item.label === node && found.item.tipoAcceso === 'FTTH' && found.item.nodoCmts.length === 0;
            const wanted = wholeNode ? [node] : [...remaining].filter(value => found.item.nodoCmts.includes(value));
            chooseSuggestion(element, found.widget, found.item); await idle();
            const options = [...select.options].map(option => option.value);
            const selections = wholeNode ? (options.filter(Boolean).length === 1 && options.includes('COMPLETO') ? ['COMPLETO'] : []) : plan(wanted, options);
            if (!selections.length) throw new Error('El nodo FTTH no ofrece una selecci?n completa ?nica.');
            if (unique(found.item.nodoCmts).length !== options.filter(value => value && value !== 'COMPLETO').length ||
                found.item.nodoCmts.some(value => !options.includes(value))) throw new Error('La sugerencia y el selector de MOICA no coinciden.');
            groups.push({ ...found, wanted, selections, wholeNode }); wanted.forEach(value => remaining.delete(value));
        }
        for (const group of groups) {
            for (const value of group.selections) {
                chooseSuggestion(element, group.widget, group.item); await idle();
                const options = [...select.options].map(option => option.value);
                if (group.wholeNode ? options.filter(Boolean).length !== 1 || !options.includes('COMPLETO') : JSON.stringify(plan(group.wanted, options)) !== JSON.stringify(group.selections)) throw new Error('Las opciones del grupo cambiaron.');
                select.value = value; select.dispatchEvent(new Event('change', { bubbles: true }));
                status.textContent = `Agregando ${group.wanted.join(', ')}…`;
                clickNative(modal, 'addNodoSeleccionado'); await idle();
                const expected = value === 'COMPLETO' ? group.item.label : value;
                if (![...byId('TKT-NODO-LISTA').querySelectorAll('input')].some(input => input.value === expected)) throw new Error('MOICA no agregó la selección esperada.');
            }
        }
        return groups;
    }
    async function loadBuildings(modal, ids) {
        const radio = byId('RADIO-ID-EDIFICIO'), element = byId('TKT-EDIFICIO-ID-autocom-ADD');
        if (!radio || !element) throw new Error('La búsqueda de edificio no está disponible.');
        const selected = [];
        for (const id of ids) {
            radio.click();
            if (element.readOnly) throw new Error('MOICA no habilitó la búsqueda por ID de edificio.');
            status.textContent = `Buscando edificio ${id}…`;
            const result = await suggestions(element, id);
            const matches = result.items.filter(item => String(item.idEdificioCRM) === id && (!technology.value || new RegExp(' - ' + technology.value + '\\]').test(item.label)));
            if (matches.length !== 1) throw new Error(`No hay un edificio único con ID ${id}.`);
            chooseSuggestion(element, result.widget, matches[0]); await idle();
            selected.push(matches[0]);
            if (![...byId('TKT-EDIFICIO-LISTA').querySelectorAll('input')].some(input => input.value === matches[0].label)) throw new Error('MOICA no agregó el edificio esperado.');
        }
        return selected;
    }
    async function loadSources(ids) {
        const element = byId('TKT-FUENTE-autocom-ADD'), list = byId('TKT-FUENTE-LISTA');
        if (!element || !list) throw new Error('La búsqueda de fuentes no está disponible.');
        const selected = [];
        for (const id of ids) {
            status.textContent = `Buscando fuente ${id}…`;
            const result = await suggestions(element, id);
            const matches = result.items.filter(item => item && typeof item.value === 'object' && item.value && String(item.value.idFuente) === id);
            if (!matches.length) throw new Error(`MOICA no encontró la fuente con ID ${id}.`);
            if (matches.length !== 1) throw new Error(`La búsqueda de la fuente ${id} es ambigua.`);
            const source = matches[0].value;
            if (typeof source.nodo !== 'string' || !source.nodo) throw new Error(`La fuente ${id} no tiene un nodo válido.`);
            const count = list.querySelectorAll('input').length;
            chooseSuggestion(element, result.widget, matches[0]); await idle();
            const label = source.nodo + (source.datos?.nodoSecundario ? ' | ' + source.datos.nodoSecundario : '');
            if (list.querySelectorAll('input').length !== count + 1 || ![...list.querySelectorAll('input')].some(input => input.value === label)) throw new Error(`MOICA no agregó la fuente ${id} esperada.`);
            selected.push(source);
        }
        return selected;
    }
    async function loadClients(modal, ids, results) {
        const element = byId('TKT-ZONA-ID-CLIENTE');
        if (!element) throw new Error('La búsqueda de cliente no está disponible.');
        for (const id of ids) {
            const result = results.find(item => item.id === id);
            try {
                element.value = id; element.dispatchEvent(new Event('input', { bubbles: true }));
                const count = byId('TKT-CLIENTE-LISTA').querySelectorAll('input').length;
                status.textContent = `Buscando cliente ${id}…`;
                clickNative(modal, 'buscarDireccionCliente'); await idle();
                const error = byId('DIV-MSG-ZONA-CLIENTE');
                if (visible(error) && error.textContent.trim()) throw new Error(error.textContent.trim());
                if (byId('TKT-CLIENTE-LISTA').querySelectorAll('input').length !== count + 1) throw new Error(`MOICA no agregó el cliente ${id}.`);
                result.detail = 'Encontrado; no cargado en el ticket porque la operación se detuvo.';
            } catch (error) {
                result.detail = `No cargado en el ticket: ${error.message}`;
                throw error;
            }
        }
    }
    async function loadCuadras(modal, ids) {
        const request = parseCuadras(snapshot);
        if (!request.node || request.invalid.length) throw new Error(`Revisá el nodo CMTS y las cuadras inválidas: ${request.invalid.join('; ')}`);
        const rows = request.rows.filter(row => ids.includes(row.label));
        const nodeInput = byId('TKT-CUADRA-NODO-autocom-ADD'), addressInput = byId('TKT-CUADRA-autocom-ADD');
        if (!nodeInput || !addressInput) throw new Error('La búsqueda nativa de cuadras no está disponible.');
        let found;
        for (let length = request.node.length; length >= 4 && !found; length--) {
            const result = await suggestions(nodeInput, request.node.slice(0, length));
            const matches = result.items.filter(item => item.label === request.node || Array.isArray(item.nodoCmts) && item.nodoCmts.includes(request.node));
            const exact = matches.filter(item => item.label === request.node);
            const candidates = exact.length ? exact : matches;
            if (candidates.length > 1) throw new Error(`La búsqueda del nodo ${request.node} es ambigua.`);
            if (candidates.length === 1) found = { ...result, item: candidates[0] };
        }
        if (!found) throw new Error(`MOICA no encontró el nodo ${request.node} para buscar cuadras.`);
        const selectNode = async () => {
            chooseSuggestion(nodeInput, found.widget, found.item); await idle();
            if (byId('TKT-CUADRA-NODO-ADD')?.value !== found.item.label || addressInput.readOnly) throw new Error('MOICA no habilitó la búsqueda de cuadras del nodo seleccionado.');
        };
        const selected = [], missing = [];
        for (const row of rows) {
            await selectNode(); status.textContent = `Buscando ${row.label} en ${request.node}…`;
            const result = await suggestions(addressInput, row.street);
            const matched = matchCuadras(request.node, row, result.items);
            missing.push(...matched.missing.map(block => `${row.street} ${block} - ${block + 100}`));
            for (const item of matched.items) if (!selected.some(value => value.label === item.label)) selected.push(item);
        }
        if (missing.length) throw new Error(`No se encontraron cuadras de ${request.node}: ${missing.join('; ')}.`);
        if (selected.length > 100) throw new Error('La selección supera 100 cuadras. Reducí los rangos y volvé a intentar.');
        for (const item of selected) {
            await selectNode(); status.textContent = `Agregando ${item.label}…`;
            const widget = $(addressInput).autocomplete('instance');
            chooseSuggestion(addressInput, widget, item); await idle();
            if (![...byId('TKT-CUADRA-LISTA').querySelectorAll('input')].some(input => input.value === item.label)) throw new Error(`MOICA no agregó ${item.label}.`);
        }
        return selected;
    }
    function readZones() {
        const type = byId('TKT-ZONA-TIPO-ADD'), json = byId('TKT-ZONA-JSON-ADD'), result = byId('TKT-ZONA-DIV');
        if (!type || !json || !result) throw new Error('No se puede verificar la zona del ticket.');
        return { type: type.value, json: json.value, html: result.innerHTML,
            selectDisplay: byId('TKT-ZONA-TIPO')?.style.display,
            resetDisplay: byId('TKT-ZONA-TIPO-NO')?.style.display,
            required: byId('TKT-ZONA-TIPO-SELECT')?.required };
    }
    function candidates() {
        const found = recognize(usePasted ? input.value : snapshot, globalThis.VienaNodeTech);
        const type = picker.value;
        if (type === 'CUADRA') { const request = parseCuadras(snapshot); return { labeled: request.node ? request.rows.map(row => row.label) : [], numbers: [], unknownNodes: [] }; }
        if (type === 'FUENTE') return { labeled: found.sources, numbers: [], unknownNodes: [] };
        const labeled = type === 'NODO' ? found.nodes : type === 'EDIFICIO' ? found.buildings : found.clients;
        return { labeled, numbers: type && type !== 'NODO' ? found.numbers : [], unknownNodes: type === 'NODO' ? found.unknownNodes : [] };
    }
    function selectedIds() {
        return [...preview.querySelectorAll('input:checked')].map(element => element.value);
    }
    async function execute() {
        if (active) return;
        let modal, committed = false, finalAttempt = false;
        const type = picker.value, ids = selectedIds();
        const clientResults = type === 'CLIENTE' ? ids.map(id => ({ id, detail: 'No cargado: no consultado porque la operación se detuvo.' })) : [];
        if (!type || !ids.length) { status.textContent = 'Elegí el tipo y revisá los identificadores.'; return; }
        if (ids.length > 100) { status.textContent = 'Cargá hasta 100 identificadores por operación.'; return; }
        if (document.querySelector('#viena-ticket-macro-recording:not([hidden]),#viena-ticket-macro-playback:not([hidden])')) { status.textContent = 'Terminá la grabación o reproducción de macros antes de cargar zonas.'; return; }
        active = true; cancelled = false; update();
        status.classList.remove('zone-error'); status.setAttribute('role', 'status');
        document.documentElement.setAttribute('data-viena-moica-zone-loading', '1');
        runButton.disabled = true; picker.disabled = true; technology.disabled = true; input.disabled = true;
        selectAll.disabled = true;
        preview.querySelectorAll('input').forEach(element => { element.disabled = true; });
        try {
            check(); await idle();
            if (type === 'CUADRA' && previous.json && previous.json !== '[]') throw new Error('Eliminá las zonas anteriores y volvé a cargar el conjunto completo de cuadras.');
            const targetModal = byId(`MO-ZONA-${type}`);
            if (targetModal?.classList.contains('in')) throw new Error('Cerrá la selección nativa abierta antes de cargar zonas.');
            modal = targetModal;
            await openNative(type);
            const groups = type === 'NODO' ? await loadNodes(modal, ids) : null;
            const buildings = type === 'EDIFICIO' ? await loadBuildings(modal, ids) : null;
            const sources = type === 'FUENTE' ? await loadSources(ids) : null;
            if (type === 'CLIENTE') await loadClients(modal, ids, clientResults);
            const cuadras = type === 'CUADRA' ? await loadCuadras(modal, ids) : null;
            check();
            finalAttempt = true;
            clickNative(modal, type === 'FUENTE' ? 'seleccionarFuentes' : type === 'CUADRA' ? 'seleccionarCuadras' : type === 'NODO' ? 'seleccionarNodos' : type === 'EDIFICIO' ? 'seleccionarEdificios' : 'seleccionarClientes');
            const readback = readZones();
            const zones = JSON.parse(readback.json);
            if (readback.type !== type || !Array.isArray(zones) || !zones.length || !byId('TKT-ZONA-DIV').querySelector('input')) throw new Error('No se pudo confirmar la carga en el ticket.');
            if (type === 'NODO') {
                const expected = groups.flatMap(group => group.selections.map(side => ({ crm: group.item.label, side })));
                if (zones.length !== expected.length || expected.some(value => !zones.some(zone => zone.nodo_crm === value.crm && zone.nodo_cmts === value.side))) throw new Error('Las zonas cargadas no coinciden con los nodos solicitados.');
            } else if (cuadras) {
                if (zones.length !== cuadras.length || cuadras.some(item => !zones.some(zone => zone.label === item.label && String(zone.idCalle) === String(item.idCalle) && zone.nodo_valido === true))) throw new Error('Las cuadras cargadas no coinciden con la selección solicitada.');
            } else if (sources) {
                if (zones.length !== sources.length || sources.some(source => !zones.some(zone => String(zone.idFuente) === String(source.idFuente) && JSON.stringify(zone) === JSON.stringify(source)))) throw new Error('Las fuentes cargadas no coinciden con los IDs y datos solicitados.');
            } else if (zones.length !== ids.length || ids.some(id => !zones.some(zone => String(type === 'EDIFICIO' ? zone.idEdificioCRM : zone.idcliente) === id))) throw new Error('Las zonas cargadas no coinciden con los IDs solicitados.');
            if (buildings && buildings.some(item => !zones.some(zone => String(zone.idEdificioCRM) === String(item.idEdificioCRM) && zone.nodo === item.nodo && zone.label === item.label))) throw new Error('La tecnología del edificio cargado no coincide con la selección.');
            committed = true; status.textContent = 'Zonas cargadas y verificadas. Revisá el ticket antes de crearlo.';
            hint.textContent = status.textContent;
        } catch (error) {
            if (finalAttempt && !committed && previous) {
                // Restore only after our final click changed the ticket, never overwrite a user's concurrent edit.
                if (modal) {
                    byId('TKT-ZONA-TIPO-ADD').value = previous.type;
                    byId('TKT-ZONA-JSON-ADD').value = previous.json;
                    byId('TKT-ZONA-DIV').innerHTML = previous.html;
                    byId('TKT-ZONA-TIPO').style.display = previous.selectDisplay;
                    byId('TKT-ZONA-TIPO-NO').style.display = previous.resetDisplay;
                    byId('TKT-ZONA-TIPO-SELECT').required = previous.required;
                }
            }
            status.textContent = `${error.message} No se confirmó una carga parcial.`;
            if (clientResults.length) {
                if (finalAttempt) clientResults.forEach(item => { item.detail = 'Resultado no confirmado; no se conserva la carga. Las zonas anteriores se restauraron.'; });
                status.textContent += '\n' + clientResults.map(item => `Cliente ${item.id}: ${item.detail}`).join('\n');
            }
            status.classList.add('zone-error'); status.setAttribute('role', 'alert');
        } finally {
            try { if (modal) {
                const closingStart = performance.now();
                document.dispatchEvent(new Event('viena:moica-request-status'));
                while (document.documentElement.getAttribute('data-viena-moica-modal-pending') !== '0' && performance.now() - closingStart < 1000) {
                    document.dispatchEvent(new Event('viena:moica-request-status'));
                    await new Promise(resolve => setTimeout(resolve, 30));
                }
                if ($(modal).data('bs.modal')?.isShown) await new Promise(resolve => {
                    let timer; const done = () => { clearTimeout(timer); $(modal).off('hidden.bs.modal', done); resolve(); };
                    $(modal).one('hidden.bs.modal', done); timer = setTimeout(done, 1000);
                    $(modal).modal('hide'); if (!modal.classList.contains('in') && getComputedStyle(modal).display === 'none') done();
                });
            } }
            catch (_) { status.textContent += ' MOICA no pudo cerrar la selección nativa.'; }
            active = false; runButton.disabled = committed; picker.disabled = committed; technology.disabled = committed; input.disabled = committed;
            document.documentElement.removeAttribute('data-viena-moica-zone-loading');
            preview.querySelectorAll('input').forEach(element => { element.disabled = committed; });
            selectAll.disabled = committed || !preview.querySelector('input');
            update();
            if (committed) { hint.textContent = 'Cargado'; dialog.close(); }
        }
    }
    function review(useBulk) {
        if (active) return;
        if (dialog?.open) { dialog.focus(); return; }
        dialog?.remove();
        snapshot = message.value; previous = readZones(); returnFocus = document.activeElement;
        usePasted = useBulk;
        bulk.textContent = useBulk ? 'Ocultar Pegar nodos' : 'Pegar nodos';
        bulk.setAttribute('aria-expanded', String(useBulk)); bulk.setAttribute('aria-controls', 'viena-moica-zone-paste');
        dialog = document.createElement('dialog'); dialog.id = 'viena-moica-zone-review'; dialog.setAttribute('data-viena-macro-ui', '');
        const title = document.createElement('h4'); title.textContent = 'Cargar zonas desde el mensaje';
        input = document.createElement('textarea'); input.id = 'viena-moica-zone-paste'; input.value = snapshot; input.hidden = !useBulk; input.maxLength = 100000; input.setAttribute('aria-label', 'Nodos o identificadores para cargar');
        picker = document.createElement('select'); picker.setAttribute('aria-label', 'Tipo de zona a cargar');
        for (const [value, label] of [['', 'Elegir tipo de zona'], ['NODO', 'Nodos'], ['EDIFICIO', 'Edificio'], ['CLIENTE', 'Cliente'], ['CUADRA', 'Cuadras'], ['FUENTE', 'Fuente']]) {
            const option = document.createElement('option'); option.value = value; option.textContent = label; picker.append(option);
        }
        const found = live();
        const cuadras = parseCuadras(snapshot);
        picker.value = found.sources.length ? 'FUENTE' : cuadras.node && (cuadras.rows.length || cuadras.invalid.length) ? 'CUADRA' : found.buildings.length ? 'EDIFICIO' : found.clients.length ? 'CLIENTE' : found.nodes.length ? 'NODO' : '';
        if (useBulk) picker.value = 'NODO';
        technology = document.createElement('select'); technology.setAttribute('aria-label', 'Tecnología del edificio');
        for (const [value, text] of [['', 'Elegir tecnología del edificio'], ['HFC', 'Edificio HFC'], ['FTTH', 'Edificio FTTH']]) { const option = document.createElement('option'); option.value = value; option.textContent = text; technology.append(option); }
        const technologies = unique(found.nodes.map(node => globalThis.VienaNodeTech.get(node) === 'GPON' ? 'FTTH' : 'HFC'));
        technology.value = technologies.length === 1 ? technologies[0] : '';
        preview = document.createElement('div');
        preview.style.maxHeight = '28vh'; preview.style.overflow = 'auto';
        selectAll = document.createElement('button'); selectAll.type = 'button'; selectAll.className = 'btn btn-default zone-select-all'; selectAll.textContent = 'Seleccionar todos';
        selectAll.onclick = () => {
            if (active || picker.value !== 'CLIENTE') return;
            preview.querySelectorAll('input:not(:disabled)').forEach(element => { element.checked = true; });
            runButton.disabled = !selectedIds().length;
        };
        const unknown = document.createElement('div'); unknown.className = 'zone-unrecognized'; unknown.setAttribute('role', 'alert'); unknown.hidden = true;
        const unknownTitle = document.createElement('strong');
        const unknownIds = document.createElement('p');
        const unknownHelp = document.createElement('span'); unknownHelp.textContent = 'Estos nodos no se cargarán. Revisá los identificadores antes de confirmar.';
        unknown.append(unknownTitle, unknownIds, unknownHelp);
        status = document.createElement('p'); status.setAttribute('role', 'status');
        const warning = document.createElement('p');
        warning.textContent = previous.json && previous.json !== '[]' ? 'El ticket ya tiene zonas. Confirmar esta carga reemplazará esas zonas por la lista revisada. Cancelar las conserva.' : 'Sólo se cargan zonas. El ticket no se crea ni se envía. Los números sin etiqueta necesitan que elijas Cliente o Edificio.';
        const actions = document.createElement('div'); actions.className = 'zone-actions';
        runButton = document.createElement('button'); runButton.type = 'button'; runButton.className = 'btn btn-primary'; runButton.textContent = previous.json && previous.json !== '[]' ? 'Confirmar reemplazo y cargar' : 'Confirmar y cargar';
        const close = document.createElement('button'); close.type = 'button'; close.className = 'btn btn-default'; close.textContent = 'Cancelar';
        close.onclick = () => { if (active) { cancelled = true; status.textContent = 'Cancelando…'; } else dialog.close(); };
        runButton.onclick = execute;
        const refresh = () => {
            const found = candidates(); technology.hidden = picker.value !== 'EDIFICIO'; preview.replaceChildren();
            selectAll.hidden = picker.value !== 'CLIENTE';
            warning.textContent = previous.json && previous.json !== '[]' ? 'El ticket ya tiene zonas. Confirmar esta carga reemplazará esas zonas por la lista revisada. Cancelar las conserva.' : 'Sólo se cargan zonas. El ticket no se crea ni se envía. Los números sin etiqueta necesitan que elijas Cliente o Edificio.';
            if (picker.value === 'CUADRA') {
                warning.textContent = 'Cuadras del nodo CMTS indicado en el mensaje. Para ampliar la carga, eliminá antes las zonas anteriores y cargá el conjunto completo.';
                const request = parseCuadras(snapshot);
                if (request.invalid.length) { const invalid = document.createElement('p'); invalid.textContent = `Cuadras inválidas: ${request.invalid.join('; ')}`; preview.append(invalid); }
            }
            const values = unique([...found.labeled, ...found.numbers]);
            if (!values.length && !preview.childNodes.length) preview.textContent = 'Sin identificadores para este tipo.';
            for (const value of values) {
                const label = document.createElement('label'); label.style.display = 'block';
                const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.value = value;
                checkbox.checked = found.labeled.includes(value);
                checkbox.onchange = () => { runButton.disabled = active || !picker.value || !selectedIds().length; };
                label.append(checkbox, document.createTextNode(` ${value}${checkbox.checked ? '' : ' — sin etiqueta: seleccionar sólo si es un ID'}`));
                preview.append(label);
            }
            unknown.hidden = !found.unknownNodes.length;
            unknownTitle.textContent = `${found.unknownNodes.length} nodo${found.unknownNodes.length === 1 ? '' : 's'} no reconocido${found.unknownNodes.length === 1 ? '' : 's'}`;
            unknownIds.textContent = found.unknownNodes.join(', ');
            runButton.disabled = active || !picker.value || !selectedIds().length;
            selectAll.disabled = active || !values.length;
        };
        input.addEventListener('input', refresh); picker.addEventListener('change', () => {
            if (active) return;
            status.textContent = ''; status.classList.remove('zone-error'); status.setAttribute('role', 'status');
            refresh();
        });
        dialog.addEventListener('cancel', event => { if (active) { event.preventDefault(); cancelled = true; } });
        const reviewDialog = dialog, savedFocus = returnFocus;
        dialog.addEventListener('close', () => { reviewDialog.remove(); if (!dialog.open) savedFocus?.focus(); });
        actions.append(runButton, close); dialog.append(title, bulk, input, picker, technology, unknown, selectAll, preview, warning, status, actions); document.body.append(dialog);
        refresh(); dialog.showModal();
    }
    button.onclick = () => review(false); bulk.onclick = () => {
        if (active) return;
        input.hidden = !input.hidden;
        if (!input.hidden && !usePasted) { usePasted = true; picker.value = 'NODO'; input.dispatchEvent(new Event('input')); }
        bulk.textContent = input.hidden ? 'Pegar nodos' : 'Ocultar Pegar nodos';
        bulk.setAttribute('aria-expanded', String(!input.hidden));
        if (input.hidden) bulk.focus(); else input.focus();
    }; update();
})();
