(() => {
    'use strict';
    if(window===window.top||window.__vienaHiddenNodeBridge)return;
    const parentOrigin=location.ancestorOrigins?.[0];
    if(!parentOrigin?.startsWith('chrome-extension://'))return;
    window.__vienaHiddenNodeBridge=true;
    const {port1,port2}=new MessageChannel();
    let active=null,completed=null;
    port1.onmessage=({data:msg})=>{
        if(msg?.parentOrigin!==parentOrigin||typeof msg.id!=='string'||msg.id.length>100)return;
        if(msg.type==='VIENA_NODE_HIDDEN_CANCEL'){if(active===msg.id)window.__vienaNodeOpticalCancel?.();return;}
        if(msg.type!=='VIENA_NODE_HIDDEN_QUERY')return;
        if(!['mira','fuente','optico','rphy','grafana'].includes(msg.kind)||!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(msg.node)||typeof msg.cos!=='string'||msg.cos.length>100||/[\r\n]/.test(msg.cos))return;
        const send=result=>port1.postMessage({type:'VIENA_NODE_HIDDEN_RESULT',id:msg.id,result});
        if(completed?.id===msg.id){send(completed.result);return;}
        if(active)return;
        active=msg.id;
        void(async()=>{
            try{
                // Same native landing action already used by js/10-bridge.js.
                if(msg.kind==='mira'&&location.hostname==='mira5-gdt.telecentro.net.ar'&&['/','/index.php'].includes(location.pathname)){
                    const button=[...document.querySelectorAll('button')].find(b=>b.isConnected&&!b.disabled&&String(b.textContent).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().includes('ESTADISTICAS'));
                    if(button){button.click();return;}
                }
                let data;
                const deadline=Date.now()+(msg.kind==='grafana'?65000:32000);
                do{
                    if(!globalThis.VienaNodeStatus)break;
                    data=msg.kind==='grafana'?await VienaNodeStatus.readGrafanaBackground(msg.node,msg.cos,msg.id):await VienaNodeStatus.readSource(msg.kind,msg.node);
                    if(!data?.pending&&!data?.unsupported)break;
                    await new Promise(resolve=>setTimeout(resolve,300));
                }while(Date.now()<deadline);
                const result=data?{ok:true,data}:{ok:false,message:'La plataforma no terminó de cargar. Revisá el acceso y volvé a Actualizar.'};
                completed={id:msg.id,result};send(result);
            }catch(_){const result={ok:false,message:'No se pudo consultar la plataforma oculta; revisá el acceso.'};completed={id:msg.id,result};send(result);}
            finally{active=null;}
        })();
    };
    window.parent.postMessage({type:'VIENA_NODE_HIDDEN_READY'},parentOrigin,[port2]);
})();
