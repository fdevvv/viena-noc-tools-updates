(() => {
    'use strict';
    if (location.origin !== 'https://moica2.telecentro.net.ar' || location.pathname !== '/home.php' || globalThis.VienaMoicaGee) return;
    const SECTORS = { GEE:'DARS - NOC - RED - GEE', GEC:'DARS - NOC - RED - GEC', GED:'DARS - NOC - RED - GED' };
    const validNode = value => /^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(value);
    let busy = false, sectorAttempt = 0, disposed = false, readonlyRequest = null;
    window.addEventListener('pagehide', () => { disposed = true; readonlyRequest?.abort(); }, { once:true });
    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
    async function idle(grid) {
        const end = Date.now() + 12000;
        while (grid.grid?.hDiv?.loading) {
            if (disposed || Date.now() >= end) throw Error('MOICA sigue cargando. Esperá a que termine y reintentá.');
            await pause(100);
        }
        if (disposed || !grid.isConnected) throw Error('La pantalla cambió. Reintentá desde el ticket.');
    }
    function nativeLoad(grid, action) {
        return new Promise((resolve, reject) => {
            const $grid = window.jQuery(grid);
            let timer;
            const finish = error => {
                clearTimeout(timer); $grid.off('.vienaGee');
                error ? reject(error) : resolve();
            };
            $grid.one('jqGridLoadComplete.vienaGee', (_event, data) => {
                if (disposed || !data || typeof data !== 'object' || data.noses || !Array.isArray(data.rows)) {
                    finish(Error('No se pudo validar la respuesta. Revisá la sesión y reintentá.')); return;
                }
                finish();
            });
            $grid.one('jqGridLoadError.vienaGee', () => finish(Error('No se pudo consultar MOICA2. Revisá la sesión o la conexión.')));
            timer = setTimeout(() => finish(Error('La consulta tardó demasiado. Esperá a que termine MOICA y reintentá.')), 12000);
            try { action(); } catch (error) { finish(error); }
        });
    }
    function gedRows(rows, nodo, details = new Map()) {
        const groups = { Directa:new Map(), Retorno:new Map() };
        const text = value => { const el = document.createElement('template'); el.innerHTML = String(value || ''); return el.content.textContent.replace(/\s+/g,' ').trim(); };
        for (const row of rows) {
            const nodes = text(row.nodoRef).toUpperCase().split(/[\s|,;]+/);
            const ticket = text(row.nroTkt).toUpperCase();
            if (!nodes.includes(nodo) || !/^\d{6}[A-Z]{2}\d+$/.test(ticket)) continue;
            const problem = text(row.problemas);
            const cmts = text(row.nodoCMTSRef).toUpperCase().split(/[\s|,;]+/);
            const validCmts = cmts.length && cmts.every(validNode) ? cmts : [''];
            const add = (group, key) => {
                if (!group.has(ticket)) group.set(ticket,new Set());
                for (const value of validCmts) group.get(ticket).add(value);
                const identity = key + ':' + ticket, previous = details.get(identity);
                const state = text(row['estado_actual.estado']), created = text(row['creado.lastEvent_ts']);
                if (!previous) details.set(identity,{node:nodo,group:key,number:ticket,problem,state,created,cmts:validCmts.filter(Boolean)});
                else {
                    previous.cmts = previous.cmts.length && !validCmts.includes('') ? [...new Set([...previous.cmts,...validCmts])] : [];
                    if (previous.problem !== problem && !previous.problem.split(' | ').includes(problem)) previous.problem += ' | ' + problem;
                    if (previous.state !== state) previous.state = '';
                    if (previous.created !== created) previous.created = '';
                }
            };
            if (/\bDirecta\s*-\s*Post Fec(?:\s+(?:OFDM|QAM)\s*-\s*Repitencia de Alarmas)?\b/i.test(problem)) add(groups.Directa,'Directa');
            if (/\bRetorno\s*-\s*(?:US apagados|Post Fec(?:\s+(?:OFDM|QAM)\s*-\s*Repitencia de Alarmas)?)\b/i.test(problem)) add(groups.Retorno,'Retorno');
        }
        return groups;
    }
    function gedCreated(value) {
        // Same seconds/local-time contract as native fechaTsToString.
        if (!/^[0-9]+$/.test(String(value)) || Number(value) <= 0) return '';
        const date = new Date(Number(value) * 1000), pad = number => String(number).padStart(2,'0');
        if (!Number.isFinite(date.getTime())) return '';
        return [pad(date.getDate()),pad(date.getMonth()+1),date.getFullYear()].join('-') + ' ' + [pad(date.getHours()),pad(date.getMinutes()),pad(date.getSeconds())].join(':');
    }
    async function analyzeGed(grid, nodo, deadline, details = new Map()) {
        const $grid = window.jQuery(grid), param = key => $grid.jqGrid('getGridParam',key);
        const original = Number(param('page')), last = Number(param('lastpage')), records = Number(param('records'));
        const signature = JSON.stringify(param('postData')?.filters), url = param('url');
        const groups = { Directa:new Map(), Retorno:new Map() }, seen = new Set();
        let scanned = 0, complete = false, restored = true;
        const unchanged = () => !disposed && grid.isConnected && param('url') === url && JSON.stringify(param('postData')?.filters) === signature;
        const read = () => {
            const rows = $grid.jqGrid('getRowData');
            if (!Array.isArray(rows)) throw Error('listado no disponible');
            if (rows.some(row => !['nodoRef','nroTkt','problemas'].every(key => Object.hasOwn(row,key)))) throw Error('columnas no disponibles');
            scanned += rows.length;
            const found = gedRows(rows,nodo,details);
            for (const key of Object.keys(groups)) for (const [ticket, cmts] of found[key]) {
                if (!groups[key].has(ticket)) groups[key].set(ticket,new Set());
                for (const value of cmts) groups[key].get(ticket).add(value);
            }
            seen.add(Number(param('page')));
        };
        try {
            if (!Number.isInteger(original) || original < 1 || !Number.isInteger(last) || last < 0 || !Number.isInteger(records) || records < 0) throw Error('paginación no verificable');
            read();
            for (let page = 1; page <= last; page++) {
                if (seen.has(page)) continue;
                if (!unchanged() || Date.now() >= deadline) break;
                await idle(grid);
                await nativeLoad(grid, () => $grid.trigger('reloadGrid',[{page}]));
                if (!unchanged() || Number(param('page')) !== page || Number(param('records')) !== records || Number(param('lastpage')) !== last) throw Error('el listado cambió');
                read();
            }
            complete = unchanged() && scanned === records && (last === 0 || seen.size === last);
        } catch (_) { complete = false; }
        finally {
            if (unchanged() && Number(param('page')) !== original) {
                try { await idle(grid); await nativeLoad(grid, () => $grid.trigger('reloadGrid',[{page:original}])); }
                catch (_) { restored = false; }
            }
        }
        return gedReport(groups,scanned,complete,restored);
    }
    function gedReport(groups, scanned, complete, restored = true) {
        const count = tickets => tickets.size + ' ticket' + (tickets.size === 1 ? '' : 's') + ' (' + [...tickets].join(', ') + ')';
        const details = Object.entries(groups).map(([key, tickets]) => {
            const byCmts = new Map();
            for (const [ticket, values] of tickets) {
                const signature = values.has('') ? '' : [...values].sort().join(' / ');
                if (!byCmts.has(signature)) byCmts.set(signature,new Set());
                byCmts.get(signature).add(ticket);
            }
            const known = [...byCmts.keys()].filter(Boolean);
            const parts = known.length > 1 ? [known.some(value => value.includes(' / ')) ? 'Combinaciones de Nodos CMTS distintas' : 'Nodos CMTS distintos'] : [];
            for (const [cmts, numbers] of byCmts) {
                const label = !cmts ? 'Nodo CMTS sin informar' : cmts.includes(' / ') ? (numbers.size > 1 ? 'Mismos Nodos CMTS ' : 'Nodos CMTS ') + cmts : (numbers.size > 1 ? 'Mismo Nodo CMTS ' : 'Nodo CMTS ') + cmts;
                parts.push(label + ': ' + count(numbers));
            }
            return key + ': ' + tickets.size + ' ticket' + (tickets.size === 1 ? '' : 's') + (tickets.size > 1 ? ' coincidentes (' + [...tickets.keys()].join(', ') + ')' : '') + (parts.length ? ' — ' + parts.join(' · ') : '');
        });
        return (complete ? 'Análisis completo' : 'Análisis parcial: no permite descartar más coincidencias') + ' · ' + scanned + ' filas revisadas · ' + details.join(' · ') + (restored ? '' : ' · No se pudo restaurar la página anterior.');
    }
    async function readGedFieldTasks(ticket, deadline) {
        const failure = (message,fatal = false) => Object.assign(Error(message),{gedFieldFatal:fatal});
        const grid = document.getElementById('grid_TktsTarea'), $ = window.jQuery;
        if (disposed || Date.now() >= deadline || !/^\d{6}[A-Z]{2}\d+$/i.test(ticket) || !grid?.grid || !grid.isConnected || !$?.ajax || !$.jgrid?.getAccessor) throw failure('Listado de tareas no disponible',true);
        const param = key => $(grid).jqGrid('getGridParam',key), names = param('prmNames'), size = Number(param('rowNum'));
        const url = new URL(param('url'),location.href);
        if (url.origin !== location.origin || url.pathname !== '/grids/gridController.php' || url.searchParams.get('coll') !== 'ApiMoicaTask' || param('mtype') !== 'GET' || !names?.page || !names.rows || !names.search || !Number.isSafeInteger(size) || size < 1) throw failure('Consulta de tareas no verificable',true);
        url.searchParams.set('defaultFilter',JSON.stringify({nroTkt:ticket}));
        const tasks = [], seen = new Set(); let expectedRecords, expectedTotal, scanned = 0;
        for (let page = 1; ; page++) {
            if (disposed || !grid.isConnected || Date.now() >= deadline) throw failure('Consulta de tareas interrumpida',true);
            const data = {oper:'grid',[names.page]:page,[names.rows]:size,[names.search]:false};
            if (names.sort) data[names.sort] = 'ticketNumber';
            if (names.order) data[names.order] = 'asc';
            const timeout = Math.min(12000,deadline-Date.now());
            const response = await new Promise((resolve,reject) => {
                let settled = false, request, timer;
                const finish = (error,result) => { if (settled) return; settled = true; clearTimeout(timer); if (readonlyRequest === request) readonlyRequest = null; error ? reject(error) : resolve(result); };
                timer = setTimeout(() => { finish(failure('Tiempo de tareas agotado',true)); request?.abort(); },timeout);
                try { request = $.ajax({url:url.href,type:'GET',dataType:'json',data,timeout,success:result=>finish(null,result),error:()=>finish(failure('No se pudo consultar tareas',true))}); if (!settled) readonlyRequest = request; }
                catch (_) { finish(failure('No se pudo consultar tareas',true)); }
            });
            if (disposed || Date.now() >= deadline || !response || response.noses || !Array.isArray(response.rows)) throw failure('Respuesta de tareas no verificable',true);
            const records = Number(response.records), total = Number(response.total);
            if (!/^\d+$/.test(String(response.records)) || !/^\d+$/.test(String(response.total)) || !Number.isSafeInteger(records) || !Number.isSafeInteger(total) || Number(response.page) !== page || !(total === Math.ceil(records/size) || records === 0 && total === 1) || response.rows.length > size || (page > 1 && (records !== expectedRecords || total !== expectedTotal))) throw failure('Paginación de tareas no verificable');
            expectedRecords = records; expectedTotal = total;
            for (const row of response.rows) {
                const get = key => String($.jgrid.getAccessor(row,key) || '').trim();
                const number = get('ticketNumber'), type = get('taskTypification.taskType.name').toUpperCase(), state = get('status').toUpperCase();
                if (!number || seen.has(number)) throw failure('Identidad de tarea no verificable');
                seen.add(number);
                if (type === 'TAREA INTERNA') continue;
                if (type !== 'TAREA DE CAMPO') throw failure('Tipo de tarea no verificable');
                if (['AGENDADA','ASIGNADA','INICIADA','EN CURSO','EN VIAJE'].includes(state)) tasks.push({number,state});
                else if (!['COMPLETADA','CANCELADA'].includes(state)) throw failure('Estado de tarea no verificable');
            }
            scanned += response.rows.length;
            if (page >= total) { if (scanned !== records) throw failure('Listado de tareas incompleto'); return tasks; }
            if (!response.rows.length) throw failure('Página de tareas incompleta');
        }
    }
    async function hydrateGedFieldTasks(details, deadline, publish = () => {}) {
        const tickets = new Map();
        for (const row of details.values()) {
            row.fieldTasks = []; row.fieldTasksState = 'pending';
            if (!tickets.has(row.number)) tickets.set(row.number,[]);
            tickets.get(row.number).push(row);
        }
        publish();
        try {
            for (const [ticket,rows] of tickets) {
                if (disposed || Date.now() >= deadline) break;
                try { const tasks = await readGedFieldTasks(ticket,deadline); for (const row of rows) { row.fieldTasks = tasks; row.fieldTasksState = 'complete'; } }
                catch (error) { for (const row of rows) row.fieldTasksState = 'unavailable'; if (error.gedFieldFatal) break; }
                publish();
            }
        } finally {
            for (const row of details.values()) if (row.fieldTasksState === 'pending') row.fieldTasksState = 'unavailable';
            publish();
        }
    }
    async function runReadonlyGed(value, progress = () => {}) {
        const nodo = String(value || '').trim().toUpperCase();
        if (!validNode(nodo)) return {ok:false,code:'invalid_node',mensaje:'Nodo inválido para analizar GED.'};
        if (busy) return {ok:false,code:'busy',mensaje:'Hay un análisis GED en curso.'};
        if (disposed) return {ok:false,code:'page_changed',mensaje:'La consulta GED se canceló.'};
        const grid = document.getElementById('grid_TktsSector_Todos');
        if (!grid?.grid || !window.jQuery?.ajax) return {ok:false,phase:'waiting'};
        const options = [...document.querySelectorAll('#sectors option')].filter(option => option.value.trim() === SECTORS.GED);
        if (options.length !== 1 || !options[0].getAttribute('dataid')) return {ok:false,code:'sector_unavailable',mensaje:'El sector GED no está disponible en esta sesión de MOICA2.'};
        busy = true;
        const groups = {Directa:new Map(),Retorno:new Map()}, details = new Map(), deadline = Date.now() + 35000;
        let scanned = 0, expectedRecords, expectedTotal, complete = false;
        try {
            await idle(grid);
            const $grid = window.jQuery(grid), param = key => $grid.jqGrid('getGridParam',key);
            const url = new URL(param('url'),location.href), names = param('prmNames');
            if (url.origin !== location.origin || url.pathname !== '/grids/gridController.php' || url.searchParams.get('coll') !== 'moicaTickets' || param('mtype') !== 'GET' || !names?.page || !names.rows || !names.filter || !names.search) throw Error('No se pudo verificar la consulta nativa de GED.');
            const filter = JSON.parse(url.searchParams.get('defaultFilter') || 'null');
            if (!filter || !Object.hasOwn(filter,'estado_actual.cola')) throw Error('No se pudo verificar el sector de la consulta GED.');
            filter['estado_actual.cola'] = options[0].getAttribute('dataid');
            url.searchParams.set('defaultFilter',JSON.stringify(filter));
            const rowNum = Number(param('rowNum'));
            if (!Number.isInteger(rowNum) || rowNum < 1) throw Error('No se pudo verificar la paginación de GED.');
            const data = {...param('postData'),[names.rows]:rowNum,[names.search]:true,[names.filter]:JSON.stringify({groupOp:'AND',rules:[{field:'nodoRef',op:'cn',data:nodo}]})};
            if (names.sort) data[names.sort] = '_id';
            if (names.order) data[names.order] = 'asc';
            for (let page = 1; !disposed && Date.now() < deadline; page++) {
                data[names.page] = page;
                const response = await new Promise((resolve,reject) => {
                    const timer = setTimeout(() => { readonlyRequest?.abort(); reject(Error('MOICA2 tardó demasiado. Reintentá el análisis GED.')); },12000);
                    readonlyRequest = window.jQuery.ajax({url:url.href,type:'GET',dataType:'json',data:{...data},timeout:12000,success:result=>{clearTimeout(timer);resolve(result);},error:()=>{clearTimeout(timer);reject(Error('No se pudo consultar GED. Revisá la sesión de MOICA2 y reintentá.'));}});
                });
                readonlyRequest = null;
                if (disposed) throw Error('La consulta GED se canceló.');
                if (!response || response.noses || !Array.isArray(response.rows)) throw Error('No se pudo validar GED. Revisá la sesión de MOICA2.');
                const records = Number(response.records), total = Number(response.total);
                if (!/^\d+$/.test(String(response.records)) || !/^\d+$/.test(String(response.total)) || !Number.isSafeInteger(records) || records < 0 || !Number.isSafeInteger(total) || total < 0 || Number(response.page) !== page || (page > 1 && (records !== expectedRecords || total !== expectedTotal))) throw Error('El listado GED cambió durante el análisis.');
                expectedRecords = records; expectedTotal = total;
                const normalized = response.rows.map(row => {
                    if (!row || typeof row.nroTkt !== 'string' || !Array.isArray(row.nodoRef) || !row.nodoRef.every(value=>typeof value==='string') || !Array.isArray(row.problemas) || !row.problemas.every(value=>typeof value?.nombre==='string') || (row.nodoCMTSRef != null && (!Array.isArray(row.nodoCMTSRef) || !row.nodoCMTSRef.every(value=>typeof value==='string')))) throw Error('No se pudieron verificar los datos de los tickets GED.');
                    return {nroTkt:row.nroTkt,nodoRef:row.nodoRef.join(' | '),nodoCMTSRef:(row.nodoCMTSRef || []).join(' | '),problemas:row.problemas.map(value=>value.nombre).join(', '),'estado_actual.estado':typeof row.estado_actual?.estado === 'string' ? row.estado_actual.estado : '', 'creado.lastEvent_ts':gedCreated(row.creado?.lastEvent_ts)};
                });
                const found = gedRows(normalized,nodo,details);
                for (const key of Object.keys(groups)) for (const [ticket, cmts] of found[key]) {
                    if (!groups[key].has(ticket)) groups[key].set(ticket,new Set());
                    for (const value of cmts) groups[key].get(ticket).add(value);
                }
                scanned += normalized.length;
                if (page >= total) { complete = scanned === records; break; }
                if (!normalized.length) break;
            }
            const result = () => ({ok:true,nodo,analysis:gedReport(groups,scanned,complete),gedDetails:[...details.values()]});
            await hydrateGedFieldTasks(details,deadline,()=>{ if (!disposed) progress(result()); });
            return result();
        } catch (error) {
            for (const row of details.values()) if (row.fieldTasksState === undefined) { row.fieldTasks = []; row.fieldTasksState = 'unavailable'; }
            return scanned ? {ok:true,nodo,analysis:gedReport(groups,scanned,false),gedDetails:[...details.values()]} : {ok:false,code:'readonly_failed',mensaje:error.message || 'No se pudo analizar GED.'};
        } finally { readonlyRequest?.abort(); readonlyRequest = null; busy = false; }
    }
    async function analyzeGec(grid, nodo, deadline, sectorId, progress = () => {}, sector = 'GEC') {
        const tasksGrid = document.getElementById('grid_TktsTarea');
        const matches = new Map(), tickets = new Map(), issues = new Set();
        const signature = JSON.stringify(window.jQuery(grid).jqGrid('getGridParam','postData'));
        const isGec = sector === 'GEC';
        let reviewed = 0, request = null, complete = false;
        const current = () => !disposed && grid.isConnected && JSON.stringify(window.jQuery(grid).jqGrid('getGridParam','postData')) === signature;
        const value = (row,key) => window.jQuery.jgrid.getAccessor(row,key);
        const text = raw => typeof raw === 'string' ? raw.trim() : '';
        const failure = message => Object.assign(Error(message),{fieldIssue:message});
        const note = (message, ticket = '') => {
            if (isGec) issues.add((/^\d{6}[A-Z]{2}\d+$/i.test(ticket) ? 'Ticket ' + ticket + ' · ' : '') + message);
        };
        const references = raw => {
            if (!Array.isArray(raw) || !raw.every(node => typeof node === 'string')) return null;
            const refs = raw.map(node => isGec ? node.trim().replace(/,$/,'').trim() : node.trim());
            return !isGec || refs.every(node => validNode(node.toUpperCase()) && node.toUpperCase() !== 'VARIOS') ? refs : null;
        };
        const report = (heading, empty = '') => {
            const lines = [...matches.values()].map(task => 'Ticket ' + task.ticket + ' · Campo ' + task.number + ' · CMTS: ' + task.cmts + ' · ' + task.state);
            if (empty && issues.size) lines.push(...issues);
            return heading + ' · ' + reviewed + '/' + tickets.size + ' tickets revisados' + (lines.length ? '\n' + lines.join('\n') : empty);
        };
        const publish = () => { if (current() && Date.now() < deadline) progress(report('Analizando tareas de campo')); };
        const pages = async (target, coll, filter, read) => {
            if (!target?.grid || !window.jQuery.ajax || !window.jQuery.jgrid?.getAccessor) throw failure('El listado de MOICA no está disponible.');
            const param = key => window.jQuery(target).jqGrid('getGridParam',key);
            const url = new URL(param('url'),location.href), names = param('prmNames');
            const tasks = coll === 'ApiMoicaTask';
            if (url.origin !== location.origin || url.pathname !== '/grids/gridController.php' || url.searchParams.get('coll') !== coll || param('mtype') !== 'GET' || !names?.page || !names.rows || !names.search || (!names.filter && !(tasks && isGec))) throw failure('No se pudo validar el listado de MOICA.');
            if (filter) url.searchParams.set('defaultFilter',JSON.stringify(filter));
            if (sectorId && coll === 'moicaTickets') {
                const base = JSON.parse(url.searchParams.get('defaultFilter') || 'null');
                if (!base || !Object.hasOwn(base,'estado_actual.cola')) throw failure('No se pudo verificar el sector GEC.');
                base['estado_actual.cola'] = sectorId;
                url.searchParams.set('defaultFilter',JSON.stringify(base));
            }
            const rowNum = Number(param('rowNum'));
            if (!Number.isSafeInteger(rowNum) || rowNum < 1) throw failure('No se pudo validar la paginación de MOICA.');
            const data = filter ? {oper:'grid',[names.search]:false} : {...param('postData')};
            if (!filter) {
                data[names.search] = true;
                data[names.filter] = JSON.stringify({groupOp:'AND',rules:[{field:'nodoRef',op:'cn',data:nodo}]});
            }
            data[names.rows] = rowNum;
            // Equal task titles cannot provide a stable order between pages.
            if (names.sort) data[names.sort] = tasks && isGec ? 'ticketNumber' : param('sortname');
            if (names.order) data[names.order] = tasks && isGec ? 'asc' : param('sortorder');
            let expectedRecords, expectedTotal, scanned = 0;
            for (let page = 1; ; page++) {
                if (!current() || Date.now() >= deadline) throw failure('La revisión se interrumpió antes de terminar.');
                const timeout = Math.min(12000,deadline-Date.now());
                data[names.page] = page;
                const response = await new Promise((resolve,reject) => {
                    let settled = false, timer;
                    const finish = (error,result) => { if (settled) return; settled = true; clearTimeout(timer); error ? reject(error) : resolve(result); };
                    timer = setTimeout(() => { finish(failure('MOICA tardó demasiado en responder.')); request?.abort(); },timeout);
                    try {
                        request = window.jQuery.ajax({url:url.href,type:'GET',dataType:'json',data:{...data},timeout,success:result=>finish(null,result),error:(xhr,status)=>finish(failure(status === 'timeout' ? 'MOICA tardó demasiado en responder.' : [401,403].includes(xhr?.status) ? 'MOICA rechazó el acceso a esta consulta.' : 'MOICA no devolvió el listado solicitado.'))});
                        readonlyRequest = request;
                    } catch (error) { finish(error); }
                });
                request = readonlyRequest = null;
                if (!current() || Date.now() >= deadline) throw failure('La revisión se interrumpió antes de terminar.');
                if (response?.noses) throw failure('La sesión de MOICA venció.');
                const nativeEmpty = isGec && page === 1 && response?.rows === null && String(response.page) === '1' && String(response.records) === '0' && ['0','1'].includes(String(response.total));
                const rows = nativeEmpty ? [] : response?.rows;
                if (!Array.isArray(rows)) throw failure('MOICA no devolvió un listado verificable.');
                const records = Number(response.records), total = Number(response.total);
                if (!/^\d+$/.test(String(response.records)) || !/^\d+$/.test(String(response.total)) || !Number.isSafeInteger(records) || !Number.isSafeInteger(total) || Number(response.page) !== page || (records > 0 && total < 1) || (records === 0 && total > 1) || (page > 1 && (records !== expectedRecords || total !== expectedTotal))) throw failure('La paginación de MOICA cambió o no coincide.');
                expectedRecords = records; expectedTotal = total;
                for (const row of rows) read(row);
                scanned += rows.length;
                if (page >= total) { if (scanned !== records) throw failure('MOICA devolvió un listado incompleto.'); break; }
                if (!rows.length) throw failure('MOICA devolvió una página vacía antes de terminar.');
            }
        };
        try {
            // Read the filtered native list privately: no modal, page or filter mutations.
            let listComplete = true;
            const seenTickets = new Set();
            try {
                await pages(grid,'moicaTickets',null,row => {
                    const ticket = text(value(row,'nroTkt')), nodeRefs = references(value(row,'nodoRef'));
                    if (!ticket || seenTickets.has(ticket)) throw failure('MOICA devolvió un ticket sin identificar o repetido.');
                    seenTickets.add(ticket);
                    if (!nodeRefs) {
                        if (!isGec) throw Error('Ticket no verificable');
                        listComplete = false;
                        note('MOICA no informó las referencias del nodo.',ticket);
                        return;
                    }
                    if (!nodeRefs.some(node=>node.toUpperCase() === nodo)) return;
                    const cmtsRefs = references(value(row,'nodoCMTSRef'));
                    tickets.set(ticket,[...new Set(cmtsRefs?.filter(Boolean))].join(' | ') || 'No informado');
                });
            } catch (error) {
                if (!isGec) throw error;
                listComplete = false;
                note('Filtro Nodo: ' + (error?.fieldIssue || 'No se pudo verificar el listado.'));
            }
            publish();
            for (const [ticket,cmts] of tickets) {
                if (!current() || Date.now() >= deadline) { note('La revisión se interrumpió antes de terminar.'); break; }
                const seenTasks = new Set();
                let issue = '';
                try {
                    await pages(tasksGrid,'ApiMoicaTask',{nroTkt:ticket},row => {
                        const number = text(value(row,'ticketNumber')), type = text(value(row,'taskTypification.taskType.name')).toUpperCase();
                        const rawState = text(value(row,'status')).toUpperCase();
                        const state = isGec ? rawState.replace(/\s+/g,' ').replace(/^ENCURSO$/,'EN CURSO').replace(/^ENVIAJE$/,'EN VIAJE').replace(/^PENDIENTE DE AGENDAMIENTO$/,'PENDIENTE AGENDAMIENTO') : rawState;
                        if (isGec && type === 'TAREA INTERNA') return;
                        if (!number || seenTasks.has(number)) throw failure(number ? 'MOICA devolvió una tarea repetida.' : 'MOICA devolvió una tarea sin número.');
                        seenTasks.add(number);
                        if (type === 'TAREA INTERNA') return;
                        if (type === 'TAREA DE CAMPO' && ['COMPLETADA','CANCELADA'].includes(state)) return;
                        const active = ['ASIGNADA','AGENDADA','INICIADA','EN VIAJE'].includes(state) || isGec && ['EN CURSO','SUSPENDIDA','PENDIENTE AGENDAMIENTO'].includes(state);
                        if (type === 'TAREA DE CAMPO' && active) matches.set(ticket+'|'+number,{ticket,number,state,cmts});
                        else if (isGec) {
                            const stateLabel = /^[A-ZÁÉÍÓÚÜÑ -]{1,40}$/.test(state) ? ' (' + state + ')' : '';
                            issue ||= type === 'TAREA DE CAMPO' ? 'Estado de campo sin reconocer' + stateLabel + '.' : 'MOICA no informó un tipo de tarea reconocible.';
                        }
                        else throw Error('Tipo o estado de tarea no verificable');
                    });
                    if (issue) note(issue,ticket);
                    else reviewed++;
                } catch (error) {
                    request?.abort(); request = readonlyRequest = null;
                    if (!isGec) throw error;
                    note(error?.fieldIssue || 'No se pudo verificar la tarea de campo.',ticket);
                }
                publish();
            }
            complete = current() && listComplete && reviewed === tickets.size;
        } catch (error) { note(error?.fieldIssue || 'No se pudo verificar el listado de GEC.'); }
        finally { request?.abort(); readonlyRequest = null; }
        return report('Tareas de campo · ' + (complete ? 'Revisión completa' : 'Revisión parcial: no permite descartar otras tareas activas'),complete ? '\nSin tareas de campo activas.' : '\nNo se pudo completar la verificación de tareas.');
    }
    async function runReadonlyGec(value, sectorKey = 'GEC', progress = () => {}) {
        if (!['GEC','GEE'].includes(sectorKey)) return {ok:false,code:'invalid_sector',mensaje:'El sector solicitado no es válido.'};
        const nodo = String(value || '').trim().toUpperCase();
        if (!validNode(nodo)) return {ok:false,code:'invalid_node',mensaje:'Nodo inválido para analizar campo.'};
        if (busy) return {ok:false,code:'busy',mensaje:'Hay un análisis en curso.'};
        if (disposed) return {ok:false,code:'page_changed',mensaje:'La consulta de campo se canceló.'};
        const grid = document.getElementById('grid_TktsSector_Todos');
        if (!grid?.grid || !window.jQuery?.ajax) return {ok:false,phase:'waiting'};
        const options = [...document.querySelectorAll('#sectors option')].filter(option => option.value.trim() === SECTORS[sectorKey]);
        if (options.length !== 1 || !options[0].getAttribute('dataid')) return {ok:false,code:'sector_unavailable',mensaje:'El sector ' + sectorKey + ' no está disponible en esta sesión.'};
        busy = true;
        try { await idle(grid); return {ok:true,nodo,analysis:await analyzeGec(grid,nodo,Date.now()+35000,options[0].getAttribute('dataid'),analysis=>{ if (!disposed) progress({ok:true,nodo,analysis}); },sectorKey)}; }
        catch (_) { return {ok:false,code:'readonly_failed',mensaje:'No se pudo verificar campo. Revisá la sesión de MOICA2.'}; }
        finally { busy = false; }
    }
    async function run(value, sectorKey = 'GEE', reuseAnalysis = false) {
        if (!Object.hasOwn(SECTORS, sectorKey)) return { ok:false, code:'invalid_sector', mensaje:'El sector solicitado no es válido.' };
        const SECTOR = SECTORS[sectorKey];
        const nodo = String(value || '').trim().toUpperCase();
        if (!validNode(nodo)) return { ok:false, code:'invalid_node', mensaje:'El ticket debe tener un único Nodo válido.' };
        if (busy) return { ok:false, code:'busy', mensaje:'Hay una consulta de nodo en curso. Esperá a que termine.' };
        if (disposed) return { ok:false, code:'page_changed', mensaje:'La pantalla de MOICA cambió.' };
        const sector = document.getElementById('SECTOR-SELECT');
        const options = [...document.querySelectorAll('#sectors option')].filter(option => option.value.trim() === SECTOR);
        if (!sector || !window.jQuery?.fn?.jqGrid) return { ok:false, phase:'waiting' };
        if (options.length !== 1 || !options[0].getAttribute('dataid')) return { ok:false, code:'sector_unavailable', mensaje:'El sector ' + sectorKey + ' no está disponible para esta sesión.' };
        const selected = typeof sectorSelected === 'undefined' ? '' : String(sectorSelected);
        // Home also displays the current sector as the input's placeholder.
        // Reapplying that same selection fires CHANGE_DATA and reloads the page.
        const visibleSector = String(sector.value || sector.getAttribute('placeholder') || '').trim();
        if (selected !== options[0].getAttribute('dataid') && visibleSector !== SECTOR) {
            if (sectorAttempt && Date.now() - sectorAttempt > 15000) {
                sectorAttempt = 0;
                return { ok:false, code:'sector_timeout', mensaje:'No se pudo cambiar al sector ' + sectorKey + '. Revisá MOICA y reintentá.' };
            }
            if (!sectorAttempt) {
                sectorAttempt = Date.now();
                sector.focus(); sector.click(); sector.value = options[0].value;
                sector.dispatchEvent(new Event('input', { bubbles:true }));
                sector.dispatchEvent(new Event('change', { bubbles:true }));
            }
            return { ok:false, phase:'navigating' };
        }
        const grid = document.getElementById('grid_TktsSector_Todos');
        const view = document.getElementById('gview_grid_TktsSector_Todos');
        const all = document.getElementById('BT-LIST-TODOS');
        if (!grid?.grid || !view || !all) return { ok:false, phase:'waiting' };
        busy = true;
        const analysisDeadline = Date.now() + 35000;
        try {
            await idle(grid);
            if (reuseAnalysis === true && (sectorKey === 'GEC' || sectorKey === 'GED')) {
                const input = view.querySelector('input[id="gs_nodoRef"][name="nodoRef"]');
                const rules = JSON.parse(window.jQuery(grid).jqGrid('getGridParam','postData')?.filters || '{}').rules || [];
                const nodeRules = rules.filter(rule=>rule.field === 'nodoRef');
                if (input?.value === nodo && !input.disabled && input.getClientRects().length && nodeRules.length === 1 && nodeRules[0].data === nodo && document.getElementById('CONTENEDOR-GRID-HOME-TODO')?.classList.contains('active')) return {ok:true,nodo,reusedAnalysis:true};
            }
            await nativeLoad(grid, () => all.click());
            await idle(grid);
            // Both native grids use gs_nodoRef; scope strictly to Todo's header.
            const input = view.querySelector('input[id="gs_nodoRef"][name="nodoRef"]');
            if (!input || input.disabled || !input.getClientRects().length) throw Error('El filtro Nodo de Todo no está disponible.');
            const filters = window.jQuery(grid).jqGrid('getGridParam', 'postData')?.filters;
            const previous = filters ? JSON.parse(filters).rules?.some(rule => rule.field === 'nodoRef') : false;
            if (input.value || previous) {
                const clear = input.closest('tr')?.querySelector('a.clearsearchclass');
                if (!clear) throw Error('No se pudo limpiar el filtro de Nodo anterior.');
                await nativeLoad(grid, () => clear.click());
                await idle(grid);
                if (input.value) throw Error('MOICA no limpió el Nodo anterior.');
            }
            input.focus(); input.value = nodo;
            input.dispatchEvent(new Event('input', { bubbles:true }));
            await nativeLoad(grid, () => {
                for (const type of ['keydown','keypress','keyup']) input.dispatchEvent(new KeyboardEvent(type, { key:'Enter', code:'Enter', keyCode:13, charCode:type === 'keypress' ? 13 : 0, which:13, bubbles:true, cancelable:true }));
            });
            const applied = JSON.parse(window.jQuery(grid).jqGrid('getGridParam', 'postData')?.filters || '{}');
            const nodes = (applied.rules || []).filter(rule => rule.field === 'nodoRef');
            if (disposed || input.value !== nodo || nodes.length !== 1 || nodes[0].data !== nodo || !document.getElementById('CONTENEDOR-GRID-HOME-TODO')?.classList.contains('active')) throw Error('No se pudo confirmar el filtro ' + sectorKey + ' del nodo solicitado.');
            const reuse = reuseAnalysis === true && (sectorKey === 'GEC' || sectorKey === 'GED');
            const gedDetails = new Map();
            const analysis = reuse ? undefined : sectorKey === 'GED' ? await analyzeGed(grid,nodo,analysisDeadline,gedDetails) : sectorKey === 'GEC' ? await analyzeGec(grid,nodo,analysisDeadline) : undefined;
            if (!reuse && sectorKey === 'GED') await hydrateGedFieldTasks(gedDetails,analysisDeadline);
            return { ok:true, nodo, ...(reuse ? {reusedAnalysis:true} : {}), ...(analysis ? { analysis } : {}), ...(!reuse && sectorKey === 'GED' ? {gedDetails:[...gedDetails.values()]} : {}) };
        } catch (error) { return { ok:false, code:'search_failed', mensaje:error.message || 'No se pudo consultar MOICA2.' }; }
        finally { busy = false; }
    }
    globalThis.VienaMoicaGee = { run, runReadonlyGed, runReadonlyGec };
    window.addEventListener('message', event => {
        if (window !== top && event.source === parent && event.origin === 'https://viena.telecentro.net.ar' && /^[a-f0-9]{32}$/.test(event.data?.token || '')) {
            const { token, type, nodo, sector, reuseAnalysis } = event.data;
            const report = data => parent.postMessage({ type:'VIENA_MOICA_GEE_VIEWER_STATE', token, ...data }, event.origin);
            if (type === 'VIENA_MOICA_GEE_VIEWER_PING') report({ state:'ready' });
            if (type === 'VIENA_MOICA_GEE_VIEWER_RUN') void run(nodo,sector,reuseAnalysis===true).then(result => { if (!disposed) report({ state:'result', result }); }).catch(() => report({ state:'result', result:{ ok:false, code:'error', mensaje:'No se pudo consultar MOICA2.' } }));
            if (type === 'VIENA_MOICA_GED_AUTO_RUN') void runReadonlyGed(nodo,result=>report({state:'ged-progress',result})).then(result => { if (!disposed) report({state:'result',result}); }).catch(() => report({state:'result',result:{ok:false,code:'error',mensaje:'No se pudo analizar GED.'}}));
            if (type === 'VIENA_MOICA_GEC_AUTO_RUN') void runReadonlyGec(nodo,'GEC',result=>report({state:'field-progress',result})).then(result => { if (!disposed) report({state:'result',result}); }).catch(() => report({state:'result',result:{ok:false,code:'error',mensaje:'No se pudo analizar campo.'}}));
            if (type === 'VIENA_MOICA_GEE_AUTO_RUN') void runReadonlyGec(nodo,'GEE',result=>report({state:'field-progress',result})).then(result => { if (!disposed) report({state:'result',result}); }).catch(() => report({state:'result',result:{ok:false,code:'error',mensaje:'No se pudo analizar campo GEE.'}}));
            return;
        }
        if (event.source !== window || event.origin !== location.origin || event.data?.type !== 'VIENA_MOICA_GEE_REQUEST' || typeof event.data.token !== 'string') return;
        const { token, nodo, sector, reuseAnalysis } = event.data;
        void run(nodo,sector,reuseAnalysis===true).then(result => {
            if (!disposed) window.postMessage({ type:'VIENA_MOICA_GEE_RESULT', token, result }, location.origin);
        }).catch(() => window.postMessage({ type:'VIENA_MOICA_GEE_RESULT', token, result:{ ok:false, code:'error', mensaje:'No se pudo consultar MOICA2.' } }, location.origin));
    });
})();
