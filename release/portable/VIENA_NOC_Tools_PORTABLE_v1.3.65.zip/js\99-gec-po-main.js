(() => {
 'use strict';
 if(location.origin!=='https://moica2.telecentro.net.ar'||location.pathname!=='/home.php'||new URL(location.href).searchParams.get('standalone')==='1'||window.__vienaGecPoMain)return;
 window.__vienaGecPoMain=true;
 const api=globalThis.VienaGecPo,prepared=new Map();let scanRun=null,lastScan=null,managing=false,nativeEye=null,taskRun=null,searchUrl=null;
 const send=(id,ok,data)=>window.postMessage({type:'VIENA_GEC13_REPLY',id,ok,data},location.origin);
 const announce=()=>window.postMessage({type:'VIENA_GEC13_CONTEXT',data:context()},location.origin);
 function context(){
  try{const grid=document.getElementById('grid_TktsSector'),button=document.getElementById('BT-LIST-'+api.queue),$=window.jQuery,sector=document.getElementById('sectors');
   const sectorName=[...(sector?.options||[])].find(o=>o.getAttribute('dataid')===window.sectorSelected)?.value;
   if(!grid?.grid||!$||!button?.classList.contains('btn-primary')||!String(sectorName||'').trim().endsWith(' - GEC'))return{active:false};
   const p=k=>$(grid).jqGrid('getGridParam',k),url=new URL(p('url'),location.href),filter=JSON.parse(url.searchParams.get('defaultFilter')||'null');
   if(url.origin!==location.origin||url.pathname!=='/grids/gridController.php'||url.searchParams.get('coll')!=='moicaTickets'||url.searchParams.get('grid')!=='grid_TktsSector'||filter?.['estado_actual.cola']!==api.queue||String(p('mtype')).toUpperCase()!=='GET')return{active:false};
   const names=p('prmNames'),size=Number(p('rowNum')),fingerprint=JSON.stringify([url.href,names,size,sectorName]);
   return{active:true,fingerprint,url:url.href,names,size,sector:sectorName};
  }catch(_){return{active:false};}
 }
 const same=fingerprint=>{const c=context();return c.active&&c.fingerprint===fingerprint;};
 function stop(){scanRun?.abort.abort();taskRun?.abort();prepared.clear();if(nativeEye)window.jQuery(nativeEye.modal).modal('hide');}
 async function jsonGet(url,parent,format='json'){
  const abort=new AbortController();let expired=false;
  const cancel=()=>abort.abort(),timer=setTimeout(()=>{expired=true;cancel();},45000);
  parent?.addEventListener('abort',cancel,{once:true});
  try{
   if(parent?.aborted)throw Error('An\u00e1lisis detenido.');
   const r=await fetch(url,{credentials:'same-origin',cache:'no-store',redirect:'manual',signal:abort.signal});
   if(!r.ok||r.redirected||r.type==='opaqueredirect')throw Error('Revis\u00e1 el acceso a MOICA y reintent\u00e1.');
   if(format==='text'&&r.body?.getReader){
    const reader=r.body.getReader(),decoder=new TextDecoder();let tail='',scanned=0;
    try{for(;;){const chunk=await reader.read();if(chunk.done)return tail;scanned+=chunk.value.byteLength;
     if(scanned>32000000)throw Error('La p\u00e1gina de b\u00fasqueda excede el tama\u00f1o permitido.');
     tail=(tail+decoder.decode(chunk.value,{stream:true})).slice(-131072);
     const start=tail.search(/jQuery\(['"]#grid_TktsBuscar['"]\)\.jqGrid\(/);
     if(start>=0&&tail.slice(start).match(/"url"\s*:\s*("(?:\\.|[^"\\])*")/))return tail.slice(start);
    }}finally{void reader.cancel().catch(()=>{});}
   }
   const text=await r.text();
   if(format==='json'&&/^\s*</.test(text))throw Error('MOICA devolvi\u00f3 una p\u00e1gina en lugar de datos. Revis\u00e1 la sesi\u00f3n y reintent\u00e1.');
   if(text.length>8000000){
    const destination=new URL(url),diagnostic={characters:text.length,contentType:r.headers?.get?.('content-type')||'',path:destination.pathname,collection:destination.searchParams.get('coll'),grid:destination.searchParams.get('grid')};
    console.warn('[VIENA GEC13 respuesta grande]',diagnostic);
    throw Object.assign(Error('La respuesta excede el tama\u00f1o permitido.'),{code:'GEC_RESPONSE_TOO_LARGE',diagnostic});
   }
   if(format==='text')return text;
   let data;try{data=JSON.parse(text)}catch(_){throw Error('MOICA no devolvi\u00f3 una lectura verificable.');}
   if(data?.noses)throw Error('Inici\u00e1 sesi\u00f3n en MOICA y reintent\u00e1.');return data;
  }catch(e){if(parent?.aborted)throw Error('An\u00e1lisis detenido.');if(expired)throw Error('MOICA no respondi\u00f3 en 45 segundos. Revis\u00e1 la conexi\u00f3n y reintent\u00e1 la lectura.');throw e;}
  finally{clearTimeout(timer);parent?.removeEventListener('abort',cancel);}
 }
 async function tasksByNode(target,fingerprint){
  if(taskRun)throw Error('Hay una consulta de tareas en curso.');
  const abort=new AbortController();taskRun=abort;const deadline=Date.now()+90000;
  const active=()=>!abort.signal.aborted&&same(fingerprint)&&Date.now()<deadline;
  try{
   const c=context();if(!active())throw Error('La bandeja cambió.');
   if(!searchUrl){
    const html=await jsonGet(new URL('/buscarTicket.php',location.origin).href,abort.signal,'text');
    const start=html.search(/jQuery\(['"]#grid_TktsBuscar['"]\)\.jqGrid\(/),match=start<0?null:html.slice(start).match(/"url"\s*:\s*("(?:\\.|[^"\\])*")/);
    if(!match)throw Error('No se pudo verificar la búsqueda nativa por nodo.');
    const url=new URL(JSON.parse(match[1]),location.href);
    if(url.origin!==location.origin||url.pathname!=='/grids/gridController.php'||url.searchParams.get('grid')!=='grid_TktsBuscar'||url.searchParams.get('coll')!=='moicaTickets')throw Error('La búsqueda de nodo no está disponible.');
    searchUrl=url.href;
   }
   const grid=document.getElementById('grid_TktsTarea'),$=window.jQuery;
   if(!grid?.grid)throw Error('La tabla nativa de tareas no está disponible.');
   const taskUrl=new URL($(grid).jqGrid('getGridParam','url'),location.href),taskNames=$(grid).jqGrid('getGridParam','prmNames');
   if(taskUrl.origin!==location.origin||taskUrl.pathname!=='/grids/gridController.php'||taskUrl.searchParams.get('coll')!=='ApiMoicaTask'||String($(grid).jqGrid('getGridParam','mtype')).toUpperCase()!=='GET')throw Error('No se pudo verificar el lector de tareas.');
   async function pages(base,names,filter,sort,key,fields){
    if(!names?.page||!names.rows||!names.search)throw Error('No se verificó la paginación de tareas.');
    const url=new URL(base);
    if(url.searchParams.has('model')){
     const model=JSON.parse(url.searchParams.get('model'));
     if(!Array.isArray(model)||!fields.every(field=>model.some(column=>column.name===field)))throw Error('No se pudo verificar el modelo de la consulta.');
     url.searchParams.set('model',JSON.stringify(model.filter(column=>fields.includes(column.name))));
    }
    for(const k of [names.page,names.rows,names.search,names.sort,names.order,names.filter,'filters','searchField','searchString','searchOper','_search'].filter(Boolean))url.searchParams.delete(k);
    url.searchParams.set('defaultFilter',JSON.stringify(filter));url.searchParams.set('oper','grid');url.searchParams.set(names.search,'false');if(names.sort)url.searchParams.set(names.sort,sort);if(names.order)url.searchParams.set(names.order,'asc');
    for(const size of [100,25,5,1]){
     const all=[],seen=new Set();let count,total,page=1;url.searchParams.set(names.rows,String(size));
     try{for(;page<=50;page++){
     if(!active())throw Error('La búsqueda de tareas venció o la bandeja cambió.');url.searchParams.set(names.page,String(page));const data=await jsonGet(url.href,abort.signal);
     if(!active())throw Error('La búsqueda de tareas venció o la bandeja cambió.');
     const incomplete=()=>{const diagnostic={collection:url.searchParams.get('coll'),grid:url.searchParams.get('grid'),expectedPage:page,returnedPage:Number(data?.page),records:Number(data?.records),recordsType:typeof data?.records,total:Number(data?.total),rowKind:Array.isArray(data?.rows)?'array':data?.rows===null?'null':typeof data?.rows,rowCount:Array.isArray(data?.rows)?data.rows.length:null,requestedRows:size};console.warn('[VIENA GEC13 respuesta incompleta]',diagnostic);return Object.assign(Error('La búsqueda de tareas no está completa.'),{code:'GEC_PAGINATION_INVALID',diagnostic});};
     if(page===1&&Number(data?.page)===1&&String(data?.records)==='0'&&['0','1'].includes(String(data?.total))&&data?.rows===null)data.rows=[];
     if(page===1){count=Number(data?.records);total=Number(data?.total);if(!/^[0-9]+$/.test(String(data?.records))||!/^[0-9]+$/.test(String(data?.total))||!Number.isSafeInteger(count)||count<0||count>5000||!Number.isSafeInteger(total)||total<0||total!==Math.ceil(count/size)&&!(count===0&&total===1))throw incomplete();}
     if(!Array.isArray(data?.rows)||Number(data.page)!==page||Number(data.records)!==count||Number(data.total)!==total||data.rows.length!==Math.min(size,Math.max(0,count-(page-1)*size)))throw incomplete();
     for(const row of data.rows){const id=key(row);if(!id||seen.has(id))throw Error('Hay filas de tareas sin identidad verificable.');seen.add(id);all.push(row);}
     if(page>=total)return all;
     }
     throw Error('La búsqueda de tareas excede el límite.');
     }catch(error){
      const stage=url.searchParams.get('coll')==='ApiMoicaTask'?'Lectura de tareas':'Búsqueda de tickets del nodo';
      if(error.code==='GEC_RESPONSE_TOO_LARGE'&&size>1&&active()){
       console.warn('[VIENA GEC13 paginación reducida]',{stage,page,previousSize:size,nextSize:size===100?25:size===25?5:1,...error.diagnostic});continue;
      }
      throw Object.assign(Error(stage+': '+error.message),{code:error.code,diagnostic:{stage,page,size,...error.diagnostic}});
     }
    }
   }
   // Native arrays contain bare nodes; older records retain the display separator.
   const parentPattern='^[0-9]{6}(MR|MM|FO)[0-9]+$',parentNumber=new RegExp(parentPattern,'i');
   const parents=await pages(searchUrl,c.names,{nodoRef:{$elemMatch:{$in:[target,target+', ']}},'estado_actual.estado':'Abierto',nroTkt:{$regex:'MR|MM|FO',$options:'i'}},'_id',r=>{
    if(!parentNumber.test(String(r.nroTkt??''))||api.field(r,'estado_actual.estado')!=='Abierto')throw Error('La búsqueda devolvió un ticket fuera del alcance MR/MM/FO Abierto.');
    return api.id(r._id?.$oid??r._id);
   },['_id','nroTkt','nodoRef','estado_actual.estado']),items=new Map();
   const parentIds=new Set(parents.map(r=>api.id(r._id?.$oid??r._id)));
   if(!lastScan||!lastScan.rows.filter(r=>r.node===target&&parentNumber.test(r.number)&&r.state==='Abierto').every(r=>parentIds.has(r.id)))throw Error('La búsqueda del nodo no incluye todos los tickets conocidos. No se pudo verificar si está libre de tareas.');
   for(const parent of parents){
    const refs=String(Array.isArray(parent.nodoRef)?parent.nodoRef.join(','):parent.nodoRef??'').toUpperCase().split(/[\s,;|]+/).filter(Boolean),event=String(parent.nroTkt??'');
    if(!refs.includes(target)||!/^\d{6}[A-Z]{2}\d+$/i.test(event))throw Error('La identidad del nodo en la búsqueda no pudo verificarse.');
    const rows=await pages(taskUrl.href,taskNames,{nroTkt:event},'ticketNumber',r=>String(api.field(r,'ticketNumber')??'').trim(),['ticketNumber','status','taskTypification.name']);
    for(const task of api.duplicateTasks(rows,event,target)){const prior=items.get(task.number);if(prior&&(prior.state!==task.state||prior.kind!==task.kind))throw Error('La tarea cambió durante la lectura.');items.set(task.number,task);}
   }
   return{verified:true,items:[...items.values()],readAt:Date.now()};
  }finally{if(taskRun===abort)taskRun=null;}
 }
 async function noDuplicate(tickets,fingerprint){
  if(new Set(tickets.map(t=>t.node)).size!==tickets.length)throw Error('Seleccioná un solo ticket por nodo para evitar tareas duplicadas.');
  for(const t of tickets){const result=await tasksByNode(t.node,fingerprint);if(result.items.length)throw Error('Ya existe VFR/VXA en '+t.node+': '+result.items.map(x=>x.number+' ('+x.state+')').join(', '));}
 }
 function post(path,data){return new Promise((resolve,reject)=>{window.jQuery.ajax({url:path,method:'POST',dataType:'json',timeout:15000,data,success:r=>r?.noses?reject(Error('Iniciá sesión en MOICA.')):resolve(r),error:()=>reject(Error('No se pudo confirmar la respuesta de MOICA. Revisá el ticket antes de repetir la acción.'))});});}
 async function fresh(t){const data=await post('scripts/ajaxTickets2.php',{accion:'GET-TKT',idTicket:t.id});return api.safeEvent(data,t);}
 function destination(code){const matches=[...document.querySelectorAll('#TAB-LIST-COLAS .jsButtonList')].filter(b=>new RegExp('^'+code+'\\s*-').test(b.textContent.trim()));if(matches.length!==1)throw Error('No se pudo identificar la bandeja destino.');const b=matches[0],id=b.id.slice('BT-LIST-'.length);if(!api.id(id))throw Error('El destino no pudo verificarse.');return{id,nombre:b.textContent.replace(/\s*\([^)]*\)\s*$/,'').trim()};}
 async function permitted(subject,target,fingerprint){
  const roots=await post('scripts/ajaxHome.php',{accion:'GET_COLAS_DERIVACION_BY_ASUNTO_ID',asunto:subject}),deadline=Date.now()+30000;
  if(!Array.isArray(roots?.data)||roots.data.length>50)throw Error('No se pudieron verificar los permisos de derivación.');
  for(const root of roots.data){
   if(!same(fingerprint)||Date.now()>deadline)throw Error('La verificación de destino venció o la bandeja cambió.');
   if(root.id===target.id)return;
   if(!api.id(root.id))continue;
   const subs=await post('scripts/ajaxHome.php',{accion:'GET_SUBCOLAS_DERIVACION_ASUNTO_ID',cola:root.id,asunto:subject});
   if(!Array.isArray(subs?.data)||subs.data.length>100)throw Error('No se pudo verificar el destino autorizado.');
   for(const sub of subs.data){
    if(!same(fingerprint)||Date.now()>deadline)throw Error('La verificación de destino venció o la bandeja cambió.');
    if(sub.id===target.id)return;if(!api.id(sub.id))continue;
    const children=await post('scripts/ajaxTickets2.php',{accion:'GET-HIJOS-SECTOR',idSector:sub.id});
    if(children?.error||!Array.isArray(children?.data))throw Error('No se pudo verificar el destino autorizado.');
    if(children.data.some(c=>c.id===target.id))return;
   }
  }
  throw Error('La bandeja destino no está habilitada para este asunto.');
 }
 async function prepare(msg){
  if(!lastScan||!same(lastScan.fingerprint)||!Array.isArray(msg.ids)||!msg.ids.length||msg.ids.length>200||new Set(msg.ids).size!==msg.ids.length)throw Error('Volvé a analizar la bandeja antes de gestionar.');
  if(!['50','34'].includes(msg.action))throw Error('Acción no disponible.');
  const tickets=msg.ids.map(id=>lastScan.rows.find(r=>r.id===id));if(tickets.some(t=>!t?.node||String(t.tecnologia).toUpperCase()!=='LEGACY'))throw Error('Revisá la identidad de los tickets seleccionados.');
  if(['vfr','vxa'].includes(msg.action)&&tickets.length!==1)throw Error('Prepará una tarea por vez con el asistente de MOICA. Podés derivar varios tickets juntos.');
  const deadline=Date.now()+120000,events=[];for(const t of tickets){if(!same(lastScan.fingerprint)||Date.now()>deadline)throw Error('La preparación venció o la bandeja cambió.');events.push(await fresh(t));}
  await noDuplicate(tickets,lastScan.fingerprint);
  let target=null;
  if(['50','34'].includes(msg.action)){target=destination(msg.action);const subjects=[...new Set(events.map(e=>e.asunto?.id))];if(subjects.length!==1||!subjects[0])throw Error('Seleccioná tickets del mismo asunto para derivarlos juntos.');await permitted(subjects[0],target,lastScan.fingerprint);}
  else if(events[0].puedeCrearTarea!==true||typeof initCreacionTarea!=='function'||!document.getElementById('MO-TKT-TAREA'))throw Error('MOICA no habilita crear una tarea de campo para este ticket.');
  if(!same(lastScan.fingerprint))throw Error('La bandeja cambió.');
  prepared.clear();const token=crypto.randomUUID();prepared.set(token,{tickets,action:msg.action,target,fingerprint:lastScan.fingerprint,until:Date.now()+60000});
  return{token,action:msg.action,tickets: tickets.map(t=>({id:t.id,number:t.number,node:t.node})),target};
 }
 async function commit(msg){
  const plan=prepared.get(msg.token);prepared.delete(msg.token);
  if(!plan||Date.now()>plan.until||!same(plan.fingerprint))throw Error('La confirmación venció o la bandeja cambió; volvé a prepararla.');
  if(!navigator.userActivation?.isActive)throw Error('Confirmá la acción con un clic.');
  const deadline=Date.now()+120000,events=[];for(const t of plan.tickets){if(!same(plan.fingerprint)||Date.now()>deadline)throw Error('La confirmación venció o la bandeja cambió.');events.push(await fresh(t));}
  if(!same(plan.fingerprint))throw Error('La bandeja cambió.');
  if(plan.target){
   if(typeof msg.reservation!=='string'||msg.reservation.length<20)throw Error('La confirmación no está reservada.');
   const subjects=[...new Set(events.map(e=>e.asunto?.id))];if(subjects.length!==1)throw Error('Los asuntos cambiaron.');await permitted(subjects[0],plan.target,plan.fingerprint);
   await noDuplicate(plan.tickets,plan.fingerprint);
   if(!same(plan.fingerprint))throw Error('La bandeja cambió.');
   // This is the exact native MULTI-DERIVAR-TKT contract. Never retry a POST.
   msg.writeStarted=true;const result=await post('scripts/ajaxTickets2.php',{accion:'MULTI-DERIVAR-TKT',arrTickets:plan.tickets.map(t=>t.id),cola:plan.target});
   if(result?.error!=='')throw Error('MOICA no confirmó la derivación. Revisá los tickets antes de repetirla.');
   if(lastScan?.fingerprint===plan.fingerprint)lastScan.rows=lastScan.rows.filter(r=>!plan.tickets.some(t=>t.id===r.id));
   window.jQuery('#grid_TktsSector').trigger('reloadGrid',[{current:true}]);
   return{kind:'derived',ids:plan.tickets.map(t=>t.id),message:'Derivación confirmada por MOICA.'};
  }
  const event=events[0];if(event.puedeCrearTarea!==true||document.getElementById('MO-TKT-TAREA')?.classList.contains('in'))throw Error('Cerrá la tarea abierta o revisá los permisos antes de continuar.');
  initCreacionTarea(event,{func:()=>window.postMessage({type:'VIENA_GEC13_NATIVE_RETURN'},location.origin)},false);
  // Only prepare the existing wizard. Never click its create/send buttons.
  const label=document.getElementById('TITLE-MODAL-TAREA');if(label)label.append(document.createTextNode(' · Solicitada '+plan.action.toUpperCase()));
  return{kind:'wizard',message:'Asistente de '+plan.action.toUpperCase()+' preparado. Confirmá problema, tipificación y envío en MOICA.'};
 }
 window.addEventListener('message',event=>{
  const msg=event.data;if(event.source!==window||event.origin!==location.origin||msg?.type!=='VIENA_GEC13_REQUEST'||typeof msg.id!=='string'||msg.id.length>100)return;
  if(msg.op==='CONTEXT'){send(msg.id,true,context());return;}
  if(msg.op==='CANCEL'){stop();send(msg.id,true,{});return;}
  if(msg.op==='TASKS'){
   if(managing||!lastScan||!same(lastScan.fingerprint)||!lastScan.rows.some(r=>r.node===msg.node&&String(r.tecnologia).toUpperCase()==='LEGACY')){send(msg.id,false,{message:'Volvé a analizar antes de verificar tareas.'});return;}
   tasksByNode(msg.node,lastScan.fingerprint).then(data=>send(msg.id,true,data)).catch(e=>send(msg.id,false,{message:e.message}));return;
  }
  if(msg.op==='SCAN'){
   const c=context();if(!c.active||scanRun){send(msg.id,false,{message:'Esperá a que GEC-13 esté lista y reintentá.'});return;}
   const run={abort:new AbortController(),fingerprint:c.fingerprint};scanRun=run;lastScan=null;let progress={total:null,scanned:0};
   api.scan({...c,active:()=>!run.abort.signal.aborted&&same(c.fingerprint),read:url=>{window.postMessage({type:'VIENA_GEC13_PROGRESS',id:msg.id,data:{...progress,phase:'loading',page:Number(new URL(url).searchParams.get(c.names.page))}},location.origin);return jsonGet(url,run.abort.signal)},onProgress:p=>{progress=p;window.postMessage({type:'VIENA_GEC13_PROGRESS',id:msg.id,data:p},location.origin)}}).then(data=>{if(typeof globalThis.VienaNodeTech?.info!=='function')throw Error('La base de nodos no termin? de cargar. Recarg? MOICA y reintent?.');lastScan={...data,rows:data.rows.map(r=>({...r,...(r.node?globalThis.VienaNodeTech.info(r.node):{})})),fingerprint:c.fingerprint};send(msg.id,true,lastScan)}).catch(e=>send(msg.id,false,{message:e.name==='AbortError'?'Análisis detenido o lectura vencida.':e.message})).finally(()=>{if(scanRun===run)scanRun=null;});return;
  }
  if(msg.op==='EYE_CLOSE'){if(nativeEye){if(nativeEye.modal.classList.contains('in'))window.jQuery(nativeEye.modal).modal('hide');else{nativeEye.closeRequested=true;window.postMessage({type:'VIENA_GEC13_NATIVE_RETURN'},location.origin);}}send(msg.id,true,{});return;}
  if(msg.op==='EYE'){
   const t=lastScan?.rows.find(r=>r.id===msg.ticketId),modal=document.getElementById('MO-TKT-VER'),host=document.getElementById('viena-gec13-native-ticket');
   if(t&&same(lastScan.fingerprint)&&navigator.userActivation?.isActive&&typeof showModalVerTicket==='function'&&modal&&host&&!nativeEye&&!modal.classList.contains('in')){
    const marker=document.createComment('MOICA ticket original location');modal.before(marker);host.append(modal);nativeEye={modal,marker};
    const restore=()=>{if(!nativeEye)return;window.jQuery(modal).off('shown.bs.modal.vienaGecPo');marker.replaceWith(modal);nativeEye=null;window.postMessage({type:'VIENA_GEC13_NATIVE_RETURN'},location.origin);};
    window.jQuery(modal).one('hidden.bs.modal.vienaGecPo',restore);
    window.jQuery(modal).one('shown.bs.modal.vienaGecPo',()=>{if(nativeEye?.closeRequested)window.jQuery(modal).modal('hide');else window.postMessage({type:'VIENA_GEC13_NATIVE_READY'},location.origin);});
    try{showModalVerTicket(t.id);send(msg.id,true,{opened:true});}catch(e){window.jQuery(modal).off('hidden.bs.modal.vienaGecPo');restore();send(msg.id,false,{message:'No se pudo abrir el ticket. Reintentá desde el listado.'});}
   }else send(msg.id,false,{message:'Volvé a analizar la bandeja antes de abrir este ticket.'});return;
  }
  if(!['PREPARE','COMMIT'].includes(msg.op))return;
  if(managing){send(msg.id,false,{message:'Hay una gestión en curso.'});return;}managing=true;
  Promise.resolve().then(()=>msg.op==='PREPARE'?prepare(msg):commit(msg)).then(data=>send(msg.id,true,data)).catch(e=>send(msg.id,false,{message:e.message,writeStarted:msg.writeStarted===true})).finally(()=>{managing=false;});
 });
 let scheduled=false;
 const changed=()=>{if(scheduled)return;scheduled=true;setTimeout(()=>{scheduled=false;if(scanRun&&!same(scanRun.fingerprint))stop();if(lastScan&&!same(lastScan.fingerprint))lastScan=null;announce();},0);};
 document.addEventListener('click',e=>{if(e.target.closest?.('#TAB-LIST-COLAS'))changed();});document.addEventListener('change',e=>{if(e.target.closest?.('#SECTOR-SELECT'))changed();});
 if(window.jQuery)window.jQuery('#grid_TktsSector').on('jqGridLoadComplete.vienaGecPo jqGridGridComplete.vienaGecPo',changed);
 window.addEventListener('pagehide',stop);announce();
})();
