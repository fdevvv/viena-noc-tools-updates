(() => {
 'use strict';
 if(globalThis.VienaGecPo)return;
 const queue='693abab6be351b842531f3b2',origin='https://moica2.telecentro.net.ar';
 const field=(o,k)=>o?.[k]??k.split('.').reduce((v,p)=>v?.[p],o);
 const number=v=>{if(!['number','string'].includes(typeof v)||String(v).trim()==='')return null;const n=Number(String(v).replace(',','.'));return Number.isFinite(n)&&n!==-99?n:null;};
 const node=v=>{const list=(Array.isArray(v)?v:String(v??'').split(/[\s,;|]+/)).map(v=>String(v).trim().toUpperCase()).filter(Boolean),unique=[...new Set(list)];return unique.length===1&&/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(unique[0])&&!['VARIOS','SIN','NO'].includes(unique[0])?unique[0]:null;};
 const id=v=>typeof v==='string'&&/^[a-f0-9]{24}$/i.test(v)?v:null;
 function ticket(r){const key=id(r?._id?.$oid??r?._id),nr=String(r?.nroTkt??'').trim().toUpperCase();if(!key||!/^\d{6}[A-Z]{2}\d+$/.test(nr))throw Error('La identidad de un ticket no pudo verificarse.');return{id:key,number:nr,node:node(r.nodoRef),cmts:node(r.nodoCMTSRef),state:String(field(r,'estado_actual.estado')??''),subject:field(r,'asunto.id')??null};}
 function evaluate(technology,data,target){
  technology=String(technology||'').toUpperCase();
  const measurements=[],missing=[];
  const add=(label,raw,min,max)=>{const n=number(raw);if(n===null){missing.push(label+': sin lectura');return;}if(min===null){missing.push(label+': sin distancia SFP');measurements.push({label,value:n,min:null,max:null,deviation:null});return;}const deviation=n<min?min-n:max!==null&&n>max?n-max:0;measurements.push({label,value:n,min,max,deviation});};
  const rows=data?.rows;
  if(data?.partial)return{technology,status:'unknown',score:null,measurements,missing:['Respuesta parcial; no se clasifica.'],suggested:null};
  if(technology==='LEGACY'){
   if(!Array.isArray(rows)||!rows.length)return{technology,status:'unknown',score:null,measurements,missing:['Sin lectura de Óptico.'],suggested:null};
   for(const [index,r]of rows.entries()){
    if(node(field(r,'nodoAlimenta'))!==target){missing.push('Identidad óptica sin coincidencia exacta.');continue;}
    for(let channel=1;channel<=4;channel++){
     const rx=field(r,'info_poleo.tp_fnOpticalReceiverPower_'+channel),tx=field(r,'info_poleo.tp_fnReturnLaserOpticalPower_'+channel);
     if(number(rx)===null&&number(tx)===null)continue;
     const prefix='Óptico '+(index+1)+' · canal '+channel;add(prefix+' RX',rx,.8,1.2);add(prefix+' TX',tx,2,null);
    }
   }
  }else if(technology==='RPHY'){
   if(!Array.isArray(rows)||!rows.length)missing.push('Sin lectura de RPHY.');
   for(const [index,r]of (rows||[]).entries()){
    if(node(field(r,'nodoRPHY'))!==target){missing.push('Identidad RPHY sin coincidencia exacta.');continue;}
    const distance=number(field(r,'distanciaSFP')),range=({20:[-12,-1],40:[-16,-7],80:[-19,-7]})[distance];
    const prefix='Enlace '+(index+1)+(range?' · SFP '+distance+' km':'');
    for(const [end,rx,tx]of [['RPHY','poleo.RPDPower.rx','poleo.RPDPower.tx'],['Leaf','leaf.byLabelActivePorts.RxLanePower.bandwidthLabel','leaf.byLabelActivePorts.TxLanePower.bandwidthLabel']]){
     add(prefix+' · '+end+' RX',field(r,rx),range?.[0]??null,range?.[1]??null);add(prefix+' · '+end+' TX',field(r,tx),-1,3);
    }
   }
  }else if(technology==='VCCAP'){
   // Explicitly approved VCCAP limits, independent of SFP distance.
   for(const [label,rx,tx]of [['Hub',data?.hubRx,data?.hubTx],...(data?.ports||[]).map(p=>['RPD '+p.name,p.rx,p.tx])]){
    add(label+' RX',rx,-12,2);add(label+' TX',tx,-1,3);
   }
  }else missing.push('Tecnología sin clasificación disponible.');
  if(!measurements.length)missing.push('No hay mediciones verificables.');
  const classified=measurements.filter(m=>m.deviation!==null&&(technology!=='LEGACY'||m.label.endsWith(' · canal 1 RX'))),worst=classified.reduce((a,b)=>!a||b.deviation>a.deviation?b:a,null),partial=missing.length>0;
  const score=worst&&(technology==='LEGACY'||worst.deviation>0||!partial)?worst.deviation:null;
  const rx=technology==='LEGACY'?classified:[],high=rx.some(m=>m.value>1.2),low=rx.some(m=>m.value<.8);
  return{technology,status:partial?(measurements.length?'partial':'unknown'):score>0?'outside':'normal',score,measurements,missing:[...new Set(missing)],worst:worst?.deviation>0?worst:null,suggested:high&&!low?'VFR':low&&!high?'VXA':null};
 }
 function sort(rows,order){return [...rows].sort((a,b)=>{if(order==='alpha'||order==='reverse')return String(a.node||'').localeCompare(String(b.node||''))*(order==='reverse'?-1:1);const x=a.evaluation?.score??null,y=b.evaluation?.score??null;return x===null?(y===null?String(a.node||'').localeCompare(String(b.node||'')):1):y===null?-1:(x-y)*(order==='asc'?1:-1)||String(a.node||'').localeCompare(String(b.node||''));});}
 async function scan({url,names,size,active,read,onProgress=()=>{}}){
  const source=new URL(url,origin),filter=JSON.parse(source.searchParams.get('defaultFilter')||'null');
  if(source.origin!==origin||source.pathname!=='/grids/gridController.php'||source.searchParams.get('coll')!=='moicaTickets'||source.searchParams.get('grid')!=='grid_TktsSector'||filter?.['estado_actual.cola']!==queue)throw Error('La bandeja GEC-13 no está lista.');
  if(!names?.page||!names.rows||!names.search||!Number.isSafeInteger(size)||size<1||size>500)throw Error('No se verificó la paginación de la bandeja.');
  for(const key of [names.filter,'filters','searchField','searchString','searchOper',names.page,names.rows,names.search,names.sort,names.order,'_search'].filter(Boolean))source.searchParams.delete(key);
  source.searchParams.set('oper','grid');source.searchParams.set(names.rows,String(size));source.searchParams.set(names.search,'false');
  if(names.sort)source.searchParams.set(names.sort,'_id');if(names.order)source.searchParams.set(names.order,'asc');
  const rows=[],seen=new Set();let records,total;
  for(let page=1;page<1001;page++){
   if(!active())throw Error('Análisis detenido o la bandeja cambió.');source.searchParams.set(names.page,String(page));
   const data=await read(source.href);if(!active())throw Error('Análisis detenido o la bandeja cambió.');
   if(page===1){records=Number(data.records);total=Number(data.total);if(!Number.isSafeInteger(records)||records<0||records>10000||!Number.isSafeInteger(total)||total<0||total!==Math.ceil(records/size)&&!(records===0&&total===1))throw Error('No se pudo verificar la cantidad completa de tickets.');}
   if(Number(data.page)!==page||Number(data.records)!==records||Number(data.total)!==total||!Array.isArray(data.rows)||data.rows.length!==Math.min(size,Math.max(0,records-(page-1)*size)))throw Error('La página no está completa o la bandeja cambió; reintentá.');
   for(const raw of data.rows){const t=ticket(raw);if(seen.has(t.id)||field(raw,'estado_actual.cola')!==queue)throw Error('La identidad o bandeja de una fila no pudo verificarse.');seen.add(t.id);rows.push(t);}
   onProgress({page,total,scanned:rows.length,records});if(page>=total){if(rows.length!==records)throw Error('La lectura de la bandeja no está completa.');return{rows,records,pages:page,readAt:Date.now()};}
  }
  throw Error('La bandeja excede el límite de lectura.');
 }
 function safeEvent(response,ticket){const r=response?.data,key=id(r?._id?.$oid??r?._id);if(response?.error||key!==ticket.id||r?.nroTkt!==ticket.number||field(r,'estado_actual.cola')!==queue||node(r?.nodoRef)!==ticket.node||!['Abierto','En Curso','Pausado'].includes(field(r,'estado_actual.estado')))throw Error('El ticket cambió o ya no está disponible en GEC-13.');const rawCount=r.activeTaskTickets,count=Array.isArray(rawCount)?rawCount.length:typeof rawCount==='number'?rawCount:typeof rawCount==='string'&&/^(0|[1-9]\d*)$/.test(rawCount)?Number(rawCount):null;if(!Number.isSafeInteger(count)||count<0)throw Error('No se pudo verificar si existe una tarea activa.');if(count>0)throw Error('El ticket ya tiene una tarea activa; revisalo antes de gestionar.');return r;}
 function duplicateTasks(rows,event,target){
  const tasks=[];
  for(const r of rows){
   const number=String(field(r,'ticketNumber')??'').trim().toUpperCase(),name=String(field(r,'taskTypification.name')??'').trim().toUpperCase();
   if(!number||number.length>100||!name||/[\u0000-\u001f<>]/.test(number))throw Error('No se pudo verificar la identidad de una tarea.');
   const kinds=[...new Set([number,name].flatMap(s=>[...s.matchAll(/(?:^|[^A-Z])(VFR|VXA)(?=[^A-Z]|$)/g)].map(m=>m[1])))];
   if(!kinds.length)continue;if(kinds.length!==1)throw Error('La tarea tiene un tipo contradictorio.');
   const state=String(field(r,'status')??'').trim().toUpperCase().replace(/^ENCURSO$/,'EN CURSO');
   if(!['ASIGNADA','AGENDADA','INICIADA','EN CURSO','SUSPENDIDA','EN VIAJE','COMPLETADA','CANCELADA'].includes(state))throw Error('No se pudo verificar el estado de una VFR/VXA.');
   if(['INICIADA','AGENDADA','SUSPENDIDA','EN CURSO'].includes(state))tasks.push({number,state,kind:kinds[0],event,node:target});
  }
  return tasks;
 }
 globalThis.VienaGecPo=Object.freeze({queue,origin,field,number,node,id,ticket,evaluate,sort,scan,safeEvent,duplicateTasks});
})();
