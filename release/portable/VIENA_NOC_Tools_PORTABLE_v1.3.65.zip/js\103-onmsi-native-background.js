(() => {
    'use strict';
    const sessions=new Map(),MOICA='https://moica2.telecentro.net.ar',ONMSI='http://onmsi.telecentro.net.ar';
    // Runs only in the existing authenticated HTTPS MOICA tab. No operator DOM,
    // filters, cookies or storage are changed. Each request is issued once.
    async function nativeStore(op,a){
        if(location.origin!=='https://moica2.telecentro.net.ar'||location.pathname!=='/buscarTicket.php')return {ok:false,message:'Abrí Buscar Ticket de MOICA con sesión.'};
        let leases=window.__vienaOnmsiNativeLeases103;
        const end=lease=>{for(const c of lease.requests.values())c.abort();leases.delete(lease.token);};
        if(op==='begin'){
            if(window.__vienaOnmsiTaskCache103?.owner===a.owner)delete window.__vienaOnmsiTaskCache103;
            if(!leases)leases=window.__vienaOnmsiNativeLeases103=new Map();
            for(const lease of leases.values())if(lease.owner===a.owner)end(lease);
            leases.set(a.token,{token:a.token,owner:a.owner,ticket:a.ticket,document:null,seen:new Set(),requests:new Map()});return {ok:true};
        }
        const lease=leases?.get(a.token);if(!lease||lease.owner!==a.owner)return {ok:false,missing:true,message:'El visor perdió su sesión. Cerralo y volvé a abrirlo.'};
        if(op==='end'){end(lease);return {ok:true};}
        if(op==='register'){
            if(lease.document&&lease.document!==a.document)return {ok:false,message:'El visor pertenece a otro documento.'};
            lease.document=a.document;return {ok:true,ticket:lease.ticket};
        }
        if(lease.document!==a.document)return {ok:false,message:'Documento del visor no confirmado.'};
        if(op==='abort'){lease.requests.get(a.id)?.abort();return {ok:true};}
        const r=a.request;let url;
        try{url=new URL(r.url);if(url.origin!==location.origin||url.username||url.password||!['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'].includes(r.method)||!/^\d{1,10}$/.test(r.id))throw Error();}catch{return {ok:false,message:'Solicitud nativa inválida.'};}
        if(lease.seen.has(r.id))return {ok:false,message:'Solicitud repetida: no se volvió a enviar.'};
        if(lease.seen.size>=10000)return {ok:false,message:'Cerrá y volvé a abrir el visor antes de continuar.'};
        lease.seen.add(r.id);const abort=new AbortController();lease.requests.set(r.id,abort);const timer=setTimeout(()=>abort.abort(),65000);
        try{
            const decode=s=>{if(typeof s!=='string'||s.length>24000000)throw Error('Archivo demasiado grande para el visor.');return Uint8Array.from(atob(s),c=>c.charCodeAt(0));};
            const blob=v=>new Blob([decode(v.base64)],{type:v.type||'application/octet-stream'});
            let body;if(r.body?.kind==='text')body=r.body.value;
            else if(r.body?.kind==='form'){body=new FormData();for(const [k,v] of r.body.entries)if(typeof v==='string')body.append(k,v);else body.append(k,blob(v),v.name||'blob');}
            else if(r.body?.kind==='blob')body=blob(r.body);
            else if(r.body?.kind==='bytes')body=decode(r.body.base64);
            else if(r.body)throw Error('Formato de solicitud no compatible.');
            const headers=new Headers();for(const [k,v] of Object.entries(r.headers||{})){if(/^(cookie|origin|referer|host|connection|content-length|sec-)/i.test(k)||typeof v!=='string')throw Error('Cabecera no permitida.');headers.set(k,v);}
            const response=await fetch(url.href,{method:r.method,headers,body:['GET','HEAD'].includes(r.method)?undefined:body,credentials:'same-origin',cache:'no-store',redirect:'manual',signal:abort.signal});
            if(response.type==='opaqueredirect'||response.status>=300&&response.status<400)return {ok:false,message:'MOICA redirigió la solicitud. Revisá la sesión.'};
            const bytes=await response.arrayBuffer();if(bytes.byteLength>16000000)throw Error('Respuesta demasiado grande para el visor.');
            const mime=response.headers.get('content-type')||'',charset=/charset\s*=\s*([^;\s]+)/i.exec(mime)?.[1]?.replace(/["']/g,'')||'utf-8';let text;
            if(r.responseType==='blob'||r.responseType==='arraybuffer'){let raw='';const b=new Uint8Array(bytes);for(let i=0;i<b.length;i+=32768)raw+=String.fromCharCode(...b.subarray(i,i+32768));text=btoa(raw);}
            else{try{text=new TextDecoder(charset).decode(bytes);}catch{text=new TextDecoder().decode(bytes);}}
            let responseHeaders='';response.headers.forEach((v,k)=>{responseHeaders+=k+': '+v+'\r\n';});
            return {ok:true,status:response.status,statusText:response.statusText,headers:responseHeaders,text,mime,responseType:r.responseType||'text'};
        }catch(e){return {ok:false,message:abort.signal.aborted?'Solicitud detenida o vencida.':e.message||'MOICA no respondió.'};}
        finally{clearTimeout(timer);lease.requests.delete(r.id);}
    }
    if(typeof module==='object'&&module.exports){module.exports={nativeStore};return;}
    const top=s=>{try{const u=new URL(s.tab.url);return s.id===chrome.runtime.id&&s.frameId===0&&u.origin===ONMSI&&u.pathname==='/app.jsp';}catch{return false;}};
    const wrapper=s=>{try{const u=new URL(s.url);return s.id===chrome.runtime.id&&s.frameId>0&&s.documentId&&u.href.split('#')[0]===chrome.runtime.getURL('onmsi-viewer.html')&&new URL(s.tab.url).origin===ONMSI;}catch{return false;}};
    const run=async(tab,op,a)=>(await chrome.scripting.executeScript({target:{tabId:tab},world:'MAIN',func:nativeStore,args:[op,a]}))[0]?.result;
    async function find(m,s){
        const known=sessions.get(m.token);if(known?.owner===s.tab.id&&!known.cancelled)return known;
        const tabs=await chrome.tabs.query({url:MOICA+'/*'});
        for(const t of tabs.filter(t=>!t.discarded&&new URL(t.url).pathname==='/buscarTicket.php')){
            const r=await run(t.id,'register',{token:m.token,owner:s.tab.id,document:s.documentId}).catch(()=>null);
            if(r?.ok){const record={owner:s.tab.id,tab:t.id,ticket:r.ticket,document:s.documentId};sessions.set(m.token,record);return record;}
        }throw Error('El visor perdió su sesión. Cerralo y volvé a abrirlo.');
    }
    chrome.runtime.onMessage.addListener((m,s,reply)=>{
        if(!String(m?.type||'').startsWith('ONMSI_103_NATIVE_'))return;
        if(!/^[a-f0-9]{32}$/.test(m.token||'')||!(top(s)||wrapper(s))){reply({ok:false,message:'Contexto del visor no autorizado.'});return;}
        void(async()=>{
            if(m.type==='ONMSI_103_NATIVE_BEGIN'){
                if(!top(s)||!/^\d{6}FO\d+$/i.test(m.ticket||''))throw Error('Ticket o contexto inválido.');
                const old=sessions.get(m.token);if(old)throw Error('La apertura anterior sigue activa.');
                const record={owner:s.tab.id,ticket:m.ticket,cancelled:false};sessions.set(m.token,record);
                try{
                    const tabs=await chrome.tabs.query({url:MOICA+'/*'}),tab=tabs.find(t=>!t.discarded&&new URL(t.url).pathname==='/buscarTicket.php');if(!tab)throw Error('Abrí Buscar Ticket de MOICA e iniciá sesión.');record.tab=tab.id;
                    if(record.cancelled)throw Error('Visor cerrado.');const r=await run(tab.id,'begin',{token:m.token,owner:s.tab.id,ticket:m.ticket});if(!r?.ok)throw Error(r?.message||'MOICA no confirmó la sesión.');
                    if(record.cancelled){await run(tab.id,'end',{token:m.token,owner:s.tab.id});throw Error('Visor cerrado.');}
                    return {url:chrome.runtime.getURL('onmsi-viewer.html')+'#'+m.token};
                }catch(e){if(sessions.get(m.token)===record)sessions.delete(m.token);throw e;}
            }
            if(m.type==='ONMSI_103_NATIVE_END'){
                const record=sessions.get(m.token);if(record?.owner===s.tab.id){record.cancelled=true;sessions.delete(m.token);if(record.tab)await run(record.tab,'end',{token:m.token,owner:s.tab.id}).catch(()=>{});}
                else{const tabs=await chrome.tabs.query({url:MOICA+'/*'});for(const tab of tabs.filter(t=>!t.discarded&&new URL(t.url).pathname==='/buscarTicket.php'))await run(tab.id,'end',{token:m.token,owner:s.tab.id}).catch(()=>{});}return {};
            }
            if(!wrapper(s))throw Error('Solicitud reservada al marco del visor.');const record=await find(m,s);
            if(m.type==='ONMSI_103_NATIVE_REGISTER'){
                const r=await run(record.tab,'register',{token:m.token,owner:s.tab.id,document:s.documentId});if(!r?.ok)throw Error(r?.message||'Documento no confirmado.');record.document=s.documentId;return {ticket:r.ticket};
            }
            if(record.document!==s.documentId)throw Error('El documento del visor cambió.');
            const op=m.type==='ONMSI_103_NATIVE_HTTP'?'http':m.type==='ONMSI_103_NATIVE_ABORT'?'abort':null;if(!op)throw Error('Operación del visor desconocida.');
            return await run(record.tab,op,{token:m.token,owner:s.tab.id,document:s.documentId,request:m.request,id:m.id});
        })().then(data=>reply({ok:true,data})).catch(e=>reply({ok:false,message:e.message||'No se pudo completar el visor.'}));return true;
    });
    chrome.tabs.onRemoved.addListener(id=>{for(const [token,r] of sessions)if(r.owner===id||r.tab===id){sessions.delete(token);r.cancelled=true;if(r.tab!==id&&r.tab)void run(r.tab,'end',{token,owner:r.owner}).catch(()=>{});}});
})();
