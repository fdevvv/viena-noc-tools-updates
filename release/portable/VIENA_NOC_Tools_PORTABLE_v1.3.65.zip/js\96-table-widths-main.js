(() => {
  'use strict';
  if (globalThis.VienaTableWidths) return;
  const states = new WeakMap(), pending = new Map();
  let sequence = 0, scanTimer, drag, jquery;
  function request(op, table, columns) {
    return new Promise(resolve => {
      const id = String(++sequence);
      const timer = setTimeout(() => { pending.delete(id); resolve(null); }, 2500);
      pending.set(id, result => { clearTimeout(timer); resolve(result); });
      document.dispatchEvent(new CustomEvent('VIENA_TABLE_WIDTHS_REQUEST', {
        detail: JSON.stringify({id, op, table, columns})
      }));
    });
  }
  document.addEventListener('VIENA_TABLE_WIDTHS_RESPONSE', event => {
    try {
      const result = JSON.parse(event.detail), done = pending.get(result.id);
      if (done) { pending.delete(result.id); done(result.ok ? result.columns || {} : null); }
    } catch (_) { /* A page message cannot break native table controls. */ }
  });
  function descriptor(table) {
    const model = table.p?.colModel;
    if (table.grid && Array.isArray(model) && model.length <= 200 && table.id) {
      const rawNames = model.map(c => String(c.name));
      const counts = new Map(), occurrences = new Map();
      rawNames.forEach(name => counts.set(name, (counts.get(name) || 0) + 1));
      const names = rawNames.map((name, i) => {
        if (counts.get(name) === 1) return name; // Preserve existing unique-column preferences.
        const label = String(model[i].label ?? table.p.colNames?.[i] ?? '').replace(/<[^>]*>/g, '').trim();
        const identity = JSON.stringify([name, label]);
        const occurrence = occurrences.get(identity) || 0;
        occurrences.set(identity, occurrence + 1);
        return '@' + JSON.stringify([name, label, occurrence]);
      });
      if (new Set(names).size !== names.length) return null;
      return {kind: 'jqgrid', key: JSON.stringify(['jqgrid', table.id, [...names].sort()]), names,
        widths: () => model.map(c => Number(c.width))};
    }
    if (table.closest('.ui-jqgrid') || !table.tHead) return null;
    const headers = Array.from(table.tHead.rows).at(-1)?.cells;
    if (!headers?.length || headers.length > 200 || Array.from(headers).some(h => h.colSpan !== 1 || h.rowSpan !== 1)) return null;
    const names = Array.from(headers, (h, i) => h.getAttribute('data-field') || h.id ||
      h.textContent.trim().replace(/\s+/g, ' ').slice(0, 100));
    if (new Set(names).size !== names.length || !names.some(n => n.length > 2)) return null;
    const identity = table.id || table.closest('[id]')?.id || '';
    const key = JSON.stringify(['table', identity, [...names].sort()]);
    // Identical unnamed tables are ambiguous: never borrow another table's widths.
    if (!identity && Array.from(document.querySelectorAll('table')).filter(t => !t.id && t.tHead &&
        t.tHead.textContent === table.tHead.textContent).length > 1) return null;
    return {kind: 'table', key, names, headers: Array.from(headers),
      widths: () => Array.from(headers, h => h.getBoundingClientRect().width)};
  }
  function apply(table, state) {
    if (!table.isConnected || drag?.table === table || !state.columns || state.applying) return;
    const desc = descriptor(table);
    if (!desc || desc.key !== state.key) return;
    if (desc.kind === 'jqgrid') {
      const p = table.p, grid = table.grid;
      desc.names.forEach((name, i) => {
        const width = state.columns[name], col = p.colModel[i];
        if (Number.isFinite(width) && width >= 16 && width <= 4000 && !col.hidden && col.resizable !== false) {
          // Native proportional fitting must leave chosen widths alone. `fixed`
          // affects auto-fit only; native handles remain manually resizable.
          col.fixed = true;
          col.widthOrg = width;
        }
      });
      const $ = globalThis.jQuery;
      if (typeof $?.fn?.jqGrid?.setColWidth === 'function' && typeof grid.resizeColumn === 'function') {
        state.applying = true;
        const forceFit = p.forceFit;
        try {
          // Restore every saved member of a forceFit pair explicitly. The native
          // resize helper synchronizes grouped/frozen headers and body widths.
          p.forceFit = false;
          desc.names.forEach((name, i) => {
            const width = state.columns[name], col = p.colModel[i];
            if (Number.isFinite(width) && width >= 16 && width <= 4000 && !col.hidden &&
                col.resizable !== false && Math.abs(width - Number(col.width)) >= 0.5) {
              grid.headers[i].newWidth = width;
              grid.newWidth = p.tblwidth + width - grid.headers[i].width;
              grid.resizeColumn(i, true, false);
            }
          });
        } finally { p.forceFit = forceFit; state.applying = false; }
        return;
      }
      // An unknown frozen-pane implementation needs its own verified adapter.
      if (p.frozenColumns) return;
      let delta = 0;
      desc.names.forEach((name, i) => {
        const width = state.columns[name], col = p.colModel[i];
        if (!Number.isFinite(width) || width < 16 || width > 4000 || col.hidden || col.resizable === false) return;
        delta += width - Number(col.width);
        col.width = width;
        if (grid.headers?.[i]) {
          grid.headers[i].width = width;
          grid.headers[i].el.style.width = width + 'px';
        }
        const first = table.rows[0]?.cells[i];
        if (first) first.style.width = width + 'px';
        const group = grid.hDiv?.querySelector('tr.jqg-first-row-header')?.cells[i];
        if (group) group.style.width = width + 'px';
        const footer = grid.sDiv?.querySelector('tr')?.cells[i];
        if (footer) footer.style.width = width + 'px';
      });
      if (delta && Number.isFinite(p.tblwidth)) {
        p.tblwidth += delta;
        table.style.width = p.tblwidth + 'px';
        const head = grid.hDiv?.querySelector('table');
        if (head) head.style.width = p.tblwidth + 'px';
        const foot = grid.sDiv?.querySelector('table');
        if (foot) foot.style.width = p.tblwidth + 'px';
      }
    } else {
      desc.names.forEach((name, i) => {
        const width = state.columns[name];
        if (!Number.isFinite(width) || width < 16 || width > 4000) return;
        desc.headers[i].style.width = width + 'px';
        const col = table.querySelector('colgroup')?.children[i];
        if (col) col.style.width = width + 'px';
      });
    }
  }
  function bind(table) {
    const desc = descriptor(table);
    if (!desc || desc.key.length > 6000) return;
    let state = states.get(table);
    if (!state || state.key !== desc.key) {
      state = {key: desc.key, columns: null, revision: 0};
      states.set(table, state);
      const revision = state.revision;
      request('load', desc.key, desc.names).then(columns => {
        if (states.get(table) !== state || state.revision !== revision) return;
        if (columns === null) { states.delete(table); return; }
        state.columns = columns || {};
        apply(table, state);
      });
    } else apply(table, state);
    const $ = globalThis.jQuery;
    if (desc.kind === 'jqgrid' && $?.fn?.on && !state.bound) {
      state.bound = true;
      const layoutEvents = 'jqGridGridComplete.vienaWidths jqGridResizeStop.vienaWidths ' +
        'jqGridResetFrozenHeights.vienaWidths jqGridAfterSetGroupHeaders.vienaWidths';
      $(table).off(layoutEvents);
      $(table).on(layoutEvents, () => {
        // These native events finish layout within the current task. Restore
        // before the next paint instead of briefly showing normalized widths.
        if (!drag && !state.applying) apply(table, state);
      });
    }
  }
  function scan() {
    clearTimeout(scanTimer);
    document.querySelectorAll('table').forEach(bind);
    const $ = globalThis.jQuery;
    if ($?.fn?.on && jquery !== $) {
      jquery = $;
      $(document).on('ajaxComplete.vienaWidths', schedule);
    }
  }
  function schedule() { clearTimeout(scanTimer); scanTimer = setTimeout(scan, 60); }
  function start(event) {
    if (!event.isTrusted || event.button !== 0) return;
    const header = event.target.closest?.('th');
    if (!header) return;
    const box = header.closest('.ui-jqgrid');
    const table = box ? box.querySelector('table.ui-jqgrid-btable') : header.closest('table');
    if (!table) return;
    if (!event.target.closest('.ui-jqgrid-resize') &&
        !['col-resize', 'ew-resize'].includes(getComputedStyle(event.target).cursor)) return;
    bind(table);
    const desc = descriptor(table);
    if (desc) drag = {table, key: desc.key, before: desc.widths(), x: event.clientX};
  }
  function stop(event) {
    if (!drag || (event && !event.isTrusted)) return;
    const current = drag;
    // Native jqGrid finishes its mouseup handler before we read its model.
    setTimeout(() => {
      if (drag !== current) return;
      drag = null;
      const desc = descriptor(current.table), state = states.get(current.table);
      if (!desc || desc.key !== current.key || !state) return;
      const columns = {...(state.columns || {})};
      const patch = {};
      let changed = false;
      desc.widths().forEach((width, i) => {
        if (Number.isFinite(width) && width >= 16 && width <= 4000 && Math.abs(width - current.before[i]) >= 1) {
          columns[desc.names[i]] = Math.round(width * 100) / 100;
          patch[desc.names[i]] = columns[desc.names[i]];
          changed = true;
        }
      });
      if (!changed) return;
      state.revision++;
      state.columns = columns;
      apply(current.table, state);
      request('save', desc.key, patch);
    }, 0);
  }
  globalThis.VienaTableWidths = {scan};
  document.addEventListener('mousedown', start, true);
  document.addEventListener('mouseup', stop, true);
  document.addEventListener('click', schedule, {passive: true});
  window.addEventListener('pageshow', schedule);
  window.addEventListener('focus', schedule);
  // Bounded startup covers delayed library/grid initialization, without permanent polling.
  [0, 250, 1000, 3000, 10000].forEach(delay => setTimeout(scan, delay));
})();
