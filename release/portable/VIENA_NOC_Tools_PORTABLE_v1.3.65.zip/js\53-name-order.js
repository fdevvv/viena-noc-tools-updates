(function(root){
  'use strict';
  const clone = value => structuredClone(value);
  function apply(source, field, draft){
    if(!source || source.schema !== 1 || !Array.isArray(source[field])) throw Error('La biblioteca no es compatible. No se modificó.');
    const originals = new Map(source[field].map(item => [item.id,item]));
    const limit = field === 'macros' ? 60 : 150;
    if(originals.size !== source[field].length || draft.length !== originals.size || new Set(draft.map(item=>item.id)).size !== originals.size) throw Error('La biblioteca cambió. Actualizá antes de guardar.');
    const next = clone(source);
    next[field] = draft.map(item=>{
      const name = String(item.name || '').replace(/\s+/g,' ').trim();
      if(!originals.has(item.id) || !name || name.length > limit) throw Error('Revisá los nombres: entre 1 y ' + limit + ' caracteres.');
      return {...clone(originals.get(item.id)),name};
    });
    if(field==='macros' && next.macros.some(item=>originals.get(item.id).name!==item.name && next.macros.some(other=>other.id!==item.id && other.name.toLowerCase()===item.name.toLowerCase())))throw Error('Ya existe una macro con ese nombre.');
    return next;
  }
  const configs = [
    {id:'viena-templates',title:'Templates VIENA',field:'templates',prefix:'viena_create_task_templates_v1:'}
  ];
  const pendingWrites = new Map();
  function previewModel(template){
    return {hasNode:String(template.body||'').includes('{{NODO_CMTS}}'),body:String(template.body||''),fields:clone(template.fields||[])};
  }
  function initHome(){
    if(document.querySelector('[data-view=viena-templates]')) return;
    const style = document.createElement('style');style.textContent = `
      .name-order-layout{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:18px;margin-top:18px}
      .name-order-column,.name-order-preview{min-width:0;border:1px solid var(--line);border-radius:12px;padding:16px}
      .name-order-search{width:100%;box-sizing:border-box}.name-order-hint{color:var(--muted);margin:0 0 14px}
      .name-order-list{display:grid;gap:10px}.name-order-row{display:flex;gap:8px;align-items:center;min-width:0;padding:12px;border:1px solid var(--line);border-radius:10px}
      .name-order-row.is-selected{border-color:var(--blue);background:color-mix(in srgb,var(--blue) 12%,transparent)}
      .name-order-row label{flex:1;min-width:0}.name-order-row input{width:100%;box-sizing:border-box}.name-order-row .btn{flex:none;padding:8px}
      .name-order-number{font-weight:700}.name-order-row.drag-before{border-top:3px solid var(--blue)}.name-order-row.drag-after{border-bottom:3px solid var(--blue)}
      .name-order-drag{cursor:grab;touch-action:auto}.name-order-preview-head{display:flex;justify-content:space-between;gap:10px;align-items:center}.name-order-preview-head h2{margin:0}
      .name-order-badge{font-size:12px;color:var(--muted);border:1px solid var(--line);padding:6px 10px;border-radius:10px}
      .name-order-field{display:grid;grid-template-columns:minmax(100px,130px) minmax(0,1fr);gap:10px;padding:12px 0;border-top:1px solid var(--line);min-width:0;align-items:center}.name-order-options{display:flex;gap:12px;flex-wrap:wrap}
      .name-order-preview label.name-order-option{display:flex;flex-direction:row;align-items:center;gap:6px;overflow-wrap:anywhere;min-width:0;color:var(--text);font-size:12px;margin:0}
      .name-order-preview .name-order-option input{appearance:none;width:16px;height:16px;min-height:0;flex:0 0 16px;padding:0;margin:0;border:1px solid var(--muted);border-radius:4px;background:transparent}
      .name-order-preview .name-order-option input[type=radio]{border-radius:50%}.name-order-preview .name-order-option input:checked{border-color:var(--blue);background:var(--blue)}
      .name-order-preview .name-order-option input[type=radio]:checked{background:radial-gradient(circle,#fff 0 3px,var(--blue) 3.5px)}
      .name-order-preview .name-order-option input[type=checkbox]:checked:after{content:'✓';display:block;color:white;font-size:12px;text-align:center;line-height:14px}
      .name-order-preview input:disabled{opacity:1;color:var(--text);-webkit-text-fill-color:var(--text)}.name-order-preview input[type=text]{width:100%;box-sizing:border-box;min-width:0}
      .name-order-preview-body{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}.name-order-preview h3{overflow-wrap:anywhere}
      .name-order-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}.name-order-status{margin-top:12px;overflow-wrap:anywhere}
      @media(max-width:900px){.name-order-layout{grid-template-columns:minmax(0,1fr)}}
      @media(max-width:540px){.name-order-row{flex-wrap:wrap;padding:10px}.name-order-row label{flex-basis:calc(100% - 80px)}.name-order-column,.name-order-preview{padding:10px}.name-order-row .btn{padding:6px}.name-order-field{grid-template-columns:minmax(0,1fr)}}
    `;document.head.append(style);
    let anchor = document.querySelector('[data-section=personalization]');
    for(const config of configs){
      const node = (tag,text,className) => {const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(className)el.className=className;return el;};
      const nav=node('button',undefined,'nav-item');nav.type='button';nav.dataset.section=config.id;nav.append(node('span','✎'),document.createTextNode(config.title));anchor.after(nav);anchor=nav;
      const view=node('section',undefined,'view');view.dataset.view=config.id;
      const head=node('div',undefined,'page-head'),heading=node('div');heading.append(node('h1',config.title),node('p','Renombrá y ordená tus templates. El contenido se muestra sólo para consultar.'));head.append(heading);
      const panel=node('article',undefined,'panel'),list=node('div',undefined,'name-order-list'),status=node('div','Cargando…','name-order-status');status.setAttribute('role','status');
      const actions=node('div',undefined,'name-order-actions');
      const button=(title,action)=>{const b=node('button',title,'btn secondary');b.type='button';b.addEventListener('click',action);return b;};
      const search=node('input',undefined,'name-order-search');search.type='search';search.placeholder='Buscar template…';search.setAttribute('aria-label','Buscar template');
      const layout=node('div',undefined,'name-order-layout'),column=node('div',undefined,'name-order-column'),preview=node('aside',undefined,'name-order-preview');preview.setAttribute('aria-label','Vista previa del template');
      column.append(node('p','Arrastrá para ordenar · También podés usar las flechas','name-order-hint'),list);layout.append(column,preview);
      let baseline,key,user='',draft=[],busy=false,loading=false,ready=false,selected='',dragId='';
      search.addEventListener('input',render);
      const bounded=promise=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('La operación tardó demasiado. Volvé a intentarlo.')),8000);Promise.resolve(promise).then(value=>{clearTimeout(timer);resolve(value);},error=>{clearTimeout(timer);reject(error);});});
      const dirty=()=>ready && JSON.stringify(draft)!==JSON.stringify(baseline[config.field].map(({id,name})=>({id,name})));
      const paintButtons=()=>{save.disabled=busy||loading||!dirty();cancel.disabled=busy||loading||!dirty();refresh.disabled=busy||loading;};
      function renderPreview(){
        preview.replaceChildren();
        const top=node('div',undefined,'name-order-preview-head');top.append(node('h2','Vista previa'),node('span','Sólo lectura','name-order-badge'));preview.append(top);
        const item=draft.find(t=>t.id===selected),original=baseline?.[config.field]?.find(t=>t.id===selected);
        if(!ready||!item||!original){preview.append(node('p','Seleccioná un template para ver sus opciones.'));return;}
        preview.append(node('h3',item.name),node('p','Así se muestra al usar el template.','name-order-hint'));
        const model=previewModel(original);
        const textField=(label,value,placeholder)=>{const row=node('div',undefined,'name-order-field'),control=node('input');control.type='text';control.disabled=true;control.value=value;control.placeholder=placeholder;control.setAttribute('aria-label',label);row.append(node('strong',label),control);return row;};
        if(model.hasNode)preview.append(textField('Nodo CMTS','','Nodo del ticket'));
        model.fields.forEach((field,index)=>{
          const defaults=field.defaults||[];
          if(field.type==='text'){preview.append(textField(field.label,defaults.join(', '),'Sin completar'));return;}
          const row=node('div',undefined,'name-order-field'),options=node('div',undefined,'name-order-options');row.append(node('strong',field.label),options);
          for(const option of field.options||[]){const label=node('label',undefined,'name-order-option'),control=node('input');control.type=field.type==='multi'?'checkbox':'radio';control.name=config.id+'-preview-'+index;control.disabled=true;control.checked=defaults.includes(option);label.append(control,node('span',option));options.append(label);}
          preview.append(row);
          if(field.otherOption&&defaults.includes(field.otherOption))preview.append(textField('Texto para «'+field.otherOption+'»','',field.otherPlaceholder||'Sin completar'));
        });
        if(!model.fields.length)preview.append(node('pre',model.body,'name-order-preview-body'));
        preview.append(node('p','Valores predeterminados del template. Vista de consulta.','name-order-hint'));
      }
      function moveItem(id,targetId,after){
        if(busy||loading||!ready||search.value.trim()||id===targetId)return;
        const from=draft.findIndex(t=>t.id===id);if(from<0||!draft.some(t=>t.id===targetId))return;
        const finishMotion=root.VienaBuildingTemplates?.captureMotion(list,'[data-item-id]','data-item-id');
        const item=draft.splice(from,1)[0],to=draft.findIndex(t=>t.id===targetId);draft.splice(to+(after?1:0),0,item);selected=id;render();
        list.querySelector('[data-item-id="'+CSS.escape(id)+'"] input')?.focus();
        finishMotion?.();
      }
      function render(){
        list.replaceChildren();
        if(!draft.length)list.append(node('p','Todavía no hay templates guardados.'));
        const query=search.value.trim().toLocaleLowerCase();let visible=0;
        draft.forEach((item,index)=>{
          if(query&&!item.name.toLocaleLowerCase().includes(query))return;visible++;
          const row=node('div',undefined,'name-order-row');row.dataset.itemId=item.id;
          row.classList.toggle('is-selected',item.id===selected);
          const handle=node('button','⠿','btn secondary name-order-drag');handle.type='button';handle.draggable=!busy&&!loading&&!query;handle.disabled=busy||loading||Boolean(query);handle.setAttribute('aria-label','Arrastrar '+item.name);handle.title=query?'Quitá la búsqueda para ordenar':'Arrastrar para ordenar';
          handle.addEventListener('dragstart',event=>{if(!handle.draggable){event.preventDefault();return;}dragId=item.id;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',item.id);});
          handle.addEventListener('dragend',()=>{dragId='';list.querySelectorAll('.drag-before,.drag-after').forEach(el=>el.classList.remove('drag-before','drag-after'));});
          row.addEventListener('dragover',event=>{if(!dragId||busy||loading||query)return;event.preventDefault();list.querySelectorAll('.drag-before,.drag-after').forEach(el=>el.classList.remove('drag-before','drag-after'));row.classList.add(event.clientY>row.getBoundingClientRect().top+row.getBoundingClientRect().height/2?'drag-after':'drag-before');});
          row.addEventListener('drop',event=>{if(!dragId)return;event.preventDefault();const after=event.clientY>row.getBoundingClientRect().top+row.getBoundingClientRect().height/2;moveItem(dragId,item.id,after);dragId='';});
          row.append(handle,node('span',String(index+1).padStart(2,'0'),'name-order-number'));
          const label=node('label'),input=node('input');input.type='text';input.value=item.name;input.maxLength=config.field==='macros'?60:150;input.setAttribute('aria-label','Nombre de '+item.name);
          input.disabled=busy||loading;
          if(config.field==='macros'){const original=baseline.macros.find(m=>m.id===item.id),folder=baseline.folders?.find(f=>f.id===original.folderId);label.append(node('small',folder?.name||'Sin carpeta'));}
          input.addEventListener('focus',()=>{selected=item.id;list.querySelectorAll('[data-item-id]').forEach(el=>el.classList.toggle('is-selected',el.dataset.itemId===selected));renderPreview();});
          input.addEventListener('input',()=>{item.name=input.value;renderPreview();paintButtons();});label.append(input);row.append(label);
          const select=button('◉',()=>{selected=item.id;render();});select.disabled=busy||loading;select.setAttribute('aria-label','Ver '+item.name);select.setAttribute('aria-pressed',String(item.id===selected));row.append(select);
          for(const [delta,title] of [[-1,'↑ Subir'],[1,'↓ Bajar']]){
            let target=index+delta;
            if(config.field==='macros'){const folder=baseline.macros.find(m=>m.id===item.id).folderId||'';while(target>=0&&target<draft.length&&(baseline.macros.find(m=>m.id===draft[target].id).folderId||'')!==folder)target+=delta;}
            const move=button(title,()=>moveItem(item.id,draft[target].id,delta>0));move.disabled=busy||loading||Boolean(query)||target<0||target>=draft.length;move.setAttribute('aria-label',title+' '+item.name);row.append(move);
          }
          list.append(row);
        });if(draft.length&&!visible)list.append(node('p','No hay templates que coincidan con la búsqueda.'));renderPreview();paintButtons();
      }
      async function load(){
        if(busy||loading)return;
        if(dirty()){status.textContent='Guardá o cancelá tus cambios antes de actualizar.';return;}
        loading=true;paintButtons();status.textContent='Cargando…';
        try{
          const operator=(await bounded(chrome.storage.local.get('viena_usuario'))).viena_usuario;
          user=String(operator||'').replace(/\s+/g,' ').trim().toLowerCase();
          if(config.prefix&&!user)throw Error('Abrí VIENA para detectar tu usuario y volvé a actualizar.');
          key=config.key||config.prefix+encodeURIComponent(user);
          const value=(await bounded(chrome.storage.local.get(key)))[key];
          baseline=value===undefined?{schema:1,[config.field]:[]}:clone(value);
          draft=(baseline[config.field]||[]).map(({id,name})=>({id,name}));apply(baseline,config.field,draft);ready=true;if(!draft.some(t=>t.id===selected))selected=draft[0]?.id||'';render();status.textContent='';
        }catch(error){ready=false;status.textContent=error.message;}
        finally{loading=false;render();}
      }
      const refresh=button('Actualizar',()=>void load());
      const cancel=button('Cancelar',()=>{if(busy||loading||!ready)return;draft=baseline[config.field].map(({id,name})=>({id,name}));render();status.textContent='Cambios descartados.';});
      const save=button('Guardar cambios',async()=>{
        if(busy||loading||!dirty())return;busy=true;paintButtons();list.querySelectorAll('input,button').forEach(el=>el.disabled=true);status.textContent='Guardando…';
        try{
          if(pendingWrites.has(key))throw Error('El guardado anterior sigue pendiente. Conservamos tu borrador; volvé a intentarlo cuando termine.');
          const current=(await bounded(chrome.storage.local.get(key)))[key];
          if(JSON.stringify(current)!==JSON.stringify(baseline))throw Error('La biblioteca cambió en otra ventana. Cancelá y actualizá para conservar esos cambios.');
          if(config.prefix){const live=String((await bounded(chrome.storage.local.get('viena_usuario'))).viena_usuario||'').replace(/\s+/g,' ').trim().toLowerCase();if(live!==user)throw Error('Cambió el usuario. Cancelá y actualizá antes de guardar.');}
          const next=apply(current,config.field,draft);if(config.field==='templates')next.revision=crypto.randomUUID();
          const write=Promise.resolve(chrome.storage.local.set({[key]:next}));pendingWrites.set(key,write);
          await bounded(write.finally(()=>{if(pendingWrites.get(key)===write)pendingWrites.delete(key);}));
          const verified=(await bounded(chrome.storage.local.get(key)))[key];if(JSON.stringify(verified)!==JSON.stringify(next))throw Error('No se pudo verificar el guardado. Actualizá para revisar la biblioteca.');
          baseline=clone(verified);draft=baseline[config.field].map(({id,name})=>({id,name}));status.textContent='Nombres y orden guardados.';
        }catch(error){status.textContent=error.message;}
        finally{busy=false;render();}
      });save.className='btn primary';actions.append(refresh,cancel,save);panel.append(search,layout,status,actions);view.append(head,panel);document.querySelector('main.content').append(view);void load();
    }
  }
  const api={apply,initHome,configs,previewModel};if(typeof module==='object'&&module.exports)module.exports=api;else root.VienaNameOrder=api;
})(globalThis);
