(() => {
    'use strict';
    const VIENA = 'https://viena.telecentro.net.ar', INFO = 'https://i3.telecentro.net.ar';
    function ticketClient(title, node, message, hfcRelated = false, typification = '') {
        if (!/^TICKET\s*:\s*\d{6}[A-Z]{2,3}\d+$/i.test(title) || !node) return '';
        const taskType = String(typification).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
        if (!/^TICKET\s*:\s*\d{6}(?:PD|EP)\d+$/i.test(title) &&
            !(hfcRelated && /^(?:\(efs\) )?escalamiento field service - diagnostico$/.test(taskType))) return '';
        const clients = [...new Set(Array.from(String(message).matchAll(/(?:(?:n(?:[°º]|ro\.?)?|n[uú]mero|num\.?|id)\s*(?:de\s*)?cliente|cliente)\s*:?\s*([0-9]+)\b/gi), m => m[1]))];
        return clients.length === 1 ? clients[0] : '';
    }
    if (typeof module === 'object' && module.exports) { module.exports = { ticketClient }; return; }
    // Isolated-world receiver: native DOM actions confirmed by UI_TRACE17/19.
    if (location.origin === INFO && location.pathname === '/info.php' && parent !== window) {
        let run = null, timer, lastToken = '';
        const visible = el => el && el.getClientRects().length && !el.disabled;
        function stop() { clearTimeout(timer); run = null; }
        window.addEventListener('pagehide', stop, { once: true });
        window.addEventListener('message', event => {
            const data = event.data;
            if (event.origin !== VIENA || event.source !== parent || data?.type !== 'VIENA_INFOCALL_RUN' || !/^[a-f0-9]{32}$/.test(data.token) || !/^\d+$/.test(data.client) || run || lastToken === data.token) return;
            lastToken = data.token;
            run = { token:data.token, client:data.client, searched:data.searched === true, deadline:Date.now()+60000, opened:false, all:false };
            check();
        });
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape' && lastToken) {
                event.preventDefault(); event.stopPropagation();
                parent.postMessage({type:'VIENA_INFOCALL_STATE',token:lastToken,state:'close'},VIENA);
            }
        },true);
        parent.postMessage({type:'VIENA_INFOCALL_READY'},VIENA);
        function report(state, message) { parent.postMessage({type:'VIENA_INFOCALL_STATE',token:run.token,state,message},VIENA); }
        function fail(message) { report('error',message); stop(); }
        function check() {
            if (!run) return;
            try {
                if (Date.now() >= run.deadline) { fail('Infocall3 tardó demasiado. Revisá la sesión y los diagnósticos.'); return; }
                const input = document.getElementById('buscaCli');
                if (!run.searched) {
                    const search = document.querySelector('#INFO-SEARCH-FORM button[type="submit"]');
                    if (visible(input) && visible(search)) {
                        Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,run.client);
                        input.dispatchEvent(new Event('input',{bubbles:true})); input.dispatchEvent(new Event('change',{bubbles:true}));
                        // Native form navigation reinjects this receiver. The parent retains only the search phase.
                        report('submitted');
                        timer = setTimeout(() => { if (run) { search.click(); } },0);
                        return;
                    }
                // Native results reset buscaCli. Continue only after this viewer's submitted
                // search/navigation; a nonempty different query must still stop the run.
                } else if (input && (!input.value.trim() || input.value.trim() === run.client)) {
                    if (!run.opened) {
                        const buttons = [...document.querySelectorAll('[id^="boton-diagnosticos-cm-"]')].filter(visible);
                        if (buttons.length > 1) { fail('Hay varios cablemódems. Revisá el cliente en Infocall3 antes de elegir.'); return; }
                        if (buttons.length === 1) { run.opened = true; buttons[0].click(); }
                    } else {
                        const modal = document.getElementById('DIAGNOSTICS-MO-INFO');
                        if (visible(modal)) {
                            const all = modal.querySelector('.diagnostics-run-all-btn');
                            if (!run.all && visible(all)) {
                                run.all = true; report('running','Ejecutando diagnósticos…'); all.click();
                                timer = setTimeout(check,150); return;
                            }
                            const tabs = [...modal.querySelectorAll('.diagnostics-tab-item')];
                            const tab = name => tabs.find(el => el.querySelector('.diagnostics-tab-link')?.textContent.trim() === name);
                            const success = name => !!tab(name)?.querySelector('.diagnostics-status-badge.is-success');
                            if (run.all && all && !all.disabled && success('IQ') && success('RDE') && modal.querySelector('.diag-summary-section-iq') && modal.querySelector('.diag-summary-section-rde')) {
                                tab('IQ').querySelector('.diagnostics-tab-link').click(); report('result'); stop(); return;
                            }
                        }
                    }
                } else if (input && input.value.trim() !== run.client) { fail('El cliente de Infocall3 cambió. Volvé a abrir el visor desde el ticket.'); return; }
                timer = setTimeout(check,150);
            } catch (_) { fail('No se pudo completar el diagnóstico. Revisá Infocall3 y reintentá.'); }
        }
        return;
    }
    if (location.origin !== VIENA || globalThis.VienaInfocallViewer) return;
    let active = null, button = null, network = null, outsideClose = false;
    const CLOSE_OUTSIDE_KEY = 'viena_infocall_viewer_close_outside_v1';
    let outsideChanged = false;
    const preferenceStorage = globalThis.chrome?.storage?.local;
    if (preferenceStorage) {
        void preferenceStorage.get(CLOSE_OUTSIDE_KEY).then(saved => {
            if (outsideChanged || typeof saved[CLOSE_OUTSIDE_KEY] !== 'boolean') return;
            outsideClose = saved[CLOSE_OUTSIDE_KEY];
            const input = active?.panel.querySelector('header label input');
            if (input) input.checked = outsideClose;
        }).catch(() => {});
    }
    function context() {
        const roots = [...document.querySelectorAll('.v-dialog__content--active')].filter(el => el.getClientRects().length && /^TICKET\s*:/i.test(el.querySelector('.v-toolbar__title')?.textContent.trim() || ''));
        if (roots.length !== 1) return null;
        const root = roots[0], identity = root.querySelector('.v-toolbar__title').textContent.trim();
        const field = name => [...root.querySelectorAll('.v-text-field__slot > label')].find(el => el.textContent.trim().toLowerCase() === name)?.closest('.v-input')?.querySelector('input[readonly], textarea[readonly]')?.value || '';
        const node = field('nodo').trim(), message = field('mensaje');
        const currentNetwork = network?.root === root && network.identity === identity ? network : null;
        if (currentNetwork?.ftth) return null;
        const client = ticketClient(identity,node,message,currentNetwork?.hfc,
            field('tipificación de la tarea') || field('tipificacion de la tarea'));
        return client ? {root,identity,client,node} : null;
    }
    function same(view) { const now = context(); return now && now.root === view.context.root && now.identity === view.context.identity && now.client === view.context.client && now.node === view.context.node; }
    function close(focus = true) {
        permissionView?.cancel();
        if (!active) return;
        const view = active; active = null; clearTimeout(view.timeout);
        window.removeEventListener('message',view.message); document.removeEventListener('keydown',view.key,true); document.removeEventListener('pointerdown',view.outside,true);
        view.frame.onload = null; view.frame.remove(); view.panel.remove();
        if (focus && view.focus?.isConnected) view.focus.focus({preventScroll:true});
    }
    function style() {
        if (document.getElementById('viena-infocall-style')) return;
        const style = document.createElement('style'); style.id = 'viena-infocall-style';
        style.textContent = '#viena-infocall-viewer{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:88vw;height:82vh;z-index:2147483646;display:flex;flex-direction:column;box-sizing:border-box;background:#fff;color:#252525;border:2px solid #c62828;border-radius:8px;box-shadow:0 8px 40px #0008;overflow:hidden;font:14px Arial}#viena-infocall-viewer header{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px;background:#c62828;color:#fff;flex:none}#viena-infocall-viewer header strong{flex:1;overflow-wrap:anywhere}#viena-infocall-viewer button{padding:7px 12px;border:1px solid #efb2b2;border-radius:4px;background:#fff;color:#252525;cursor:pointer}#viena-infocall-viewer .viewer-status{padding:8px 12px;flex:none}#viena-infocall-viewer iframe{width:100%;flex:1;min-height:0;border:0;background:#fff}#viena-infocall-viewer label{display:inline-flex;align-items:center;gap:6px;font-size:12px}#viena-infocall-viewer input{margin:0;width:15px;height:15px;accent-color:#c62828}.viena-infocall-button{padding:8px 12px;border:0;border-radius:5px;background:#c62828;color:#fff;cursor:pointer;font-weight:600}@media(max-width:600px){#viena-infocall-viewer{width:94vw;height:86vh}}';
        style.textContent += '@media(max-width:600px){#viena-infocall-viewer header strong,#viena-infocall-viewer header label{flex:0 0 100%}}';
        document.head.append(style);
    }
    function open(now, focus) {
        close(); globalThis.VienaMoicaViewer?.close(); style();
        const panel = document.createElement('section'); panel.id = 'viena-infocall-viewer'; panel.setAttribute('role','dialog'); panel.setAttribute('aria-modal','true'); panel.setAttribute('aria-label','Infocall3 - '+now.client);
        const header = document.createElement('header'), title = document.createElement('strong'), retry = document.createElement('button'), exit = document.createElement('button');
        title.textContent = 'Infocall3 - '+now.client; retry.textContent = 'Reintentar'; exit.textContent = 'Cerrar'; retry.type = exit.type = 'button';
        const label = document.createElement('label'), toggle = document.createElement('input'); toggle.type = 'checkbox'; toggle.checked = outsideClose;
        toggle.onchange = () => {
            outsideChanged = true;
            outsideClose = toggle.checked;
            toggle.title = '';
            if (preferenceStorage) void preferenceStorage.set({ [CLOSE_OUTSIDE_KEY]: outsideClose }).catch(() => {
                toggle.title = 'No se pudo guardar la opción. Volvé a marcar tu elección para reintentar.';
            });
        };
        label.append(toggle,document.createTextNode('Cerrar al hacer clic fuera'));
        header.append(title,label,retry,exit);
        const status = document.createElement('div'); status.className = 'viewer-status'; status.setAttribute('role','status');
        const frame = document.createElement('iframe'); frame.title = 'Diagnósticos Infocall3 - '+now.client; frame.referrerPolicy = 'origin';
        panel.append(header,status,frame);
        const view = {panel,frame,status,context:now,focus,searched:false,token:[...crypto.getRandomValues(new Uint8Array(16))].map(v=>v.toString(16).padStart(2,'0')).join('')};
        view.message = event => {
            if (active === view && same(view) && !view.done && event.origin === INFO && event.source === frame.contentWindow && event.data?.type === 'VIENA_INFOCALL_READY') { frame.onload(); return; }
            if (active !== view || !same(view) || event.origin !== INFO || event.source !== frame.contentWindow || event.data?.type !== 'VIENA_INFOCALL_STATE' || event.data.token !== view.token) return;
            if (event.data.state === 'close') { close(); return; }
            if (view.done) return;
            if (event.data.state === 'submitted') { view.searched = true; status.textContent = 'Buscando el cliente en Infocall3…'; }
            else if (event.data.state === 'running') status.textContent = event.data.message;
            else if (event.data.state === 'result' || event.data.state === 'error') {
                clearTimeout(view.timeout); view.done = true;
                status.textContent = event.data.state === 'result' ? 'Diagnósticos IQ y RDE ejecutados · Cliente '+now.client : event.data.message;
            }
        };
        view.key = event => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); } };
        view.outside = event => { if (outsideClose && !panel.contains(event.target)) close(false); };
        frame.onload = () => { if (active === view && same(view) && !view.done) frame.contentWindow.postMessage({type:'VIENA_INFOCALL_RUN',token:view.token,client:now.client,searched:view.searched},INFO); };
        retry.onclick = () => { if (same(view)) open(now,focus); else close(); }; exit.onclick = () => close();
        active = view; window.addEventListener('message',view.message); document.addEventListener('keydown',view.key,true); document.addEventListener('pointerdown',view.outside,true);
        status.textContent = 'Cargando Infocall3…';
        view.timeout = setTimeout(() => { if (active === view) { view.done = true; status.textContent = 'No se pudo completar la consulta. Revisá la sesión de Infocall3 y reintentá.'; frame.onload = null; frame.remove(); } },75000);
        document.body.append(panel); frame.src = INFO+'/info.php'; exit.focus({preventScroll:true});
    }
    let permissionView = null;
    function requestAccess(context) {
        if (permissionView) return permissionView.promise;
        const frame = document.createElement('iframe'), focus = document.activeElement;
        const token = [...crypto.getRandomValues(new Uint8Array(16))].map(v=>v.toString(16).padStart(2,'0')).join('');
        const origin = new URL(chrome.runtime.getURL('')).origin;
        frame.id = 'viena-infocall-permission'; frame.title = 'Permitir acceso a Infocall3';
        frame.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;border:0;z-index:2147483647;background:transparent;';
        let finish;
        const promise = new Promise(resolve => { finish = state => {
            clearTimeout(timer);window.removeEventListener('message',message);document.removeEventListener('keydown',key,true);frame.remove();permissionView=null;
            if (focus?.isConnected) focus.focus({preventScroll:true});
            if (state !== 'cancelled') globalThis.VienaPermissionUI?.toast(state === 'granted' ? 'Infocall3 habilitado.' : 'No se habilitó Infocall3. Podés volver a intentarlo.',state === 'granted' ? 'success' : 'warning');
            resolve(state === 'granted');
        }; });
        const message = event => {
            if (event.source !== frame.contentWindow || event.origin !== origin || event.data?.type !== 'VIENA_INFOCALL_PERMISSION' || event.data.token !== token) return;
            if (event.data.state === 'ready') {clearTimeout(timer);return;}
            if (['granted','denied','cancelled'].includes(event.data.state)) finish(event.data.state);
        };
        const key = event => {if(event.key === 'Escape'){event.preventDefault();event.stopPropagation();finish('cancelled');}};
        const timer = setTimeout(() => finish('denied'),10000);
        permissionView = {promise,context,cancel:() => finish('cancelled')};
        window.addEventListener('message',message);document.addEventListener('keydown',key,true);
        frame.src = chrome.runtime.getURL('permission.html')+'?token='+token;
        document.body.append(frame); return promise;
    }
    function refresh(hfc) {
        const root = [...document.querySelectorAll('.v-dialog__content--active')].find(el => el.getClientRects().length && /^TICKET\s*:/i.test(el.querySelector('.v-toolbar__title')?.textContent.trim() || ''));
        if (hfc !== undefined) network = root ? {root,identity:root.querySelector('.v-toolbar__title').textContent.trim(),hfc:hfc?.esHFC === true && hfc?.esFTTH !== true && /^(PD|EP)$/.test(hfc?.tipoRed || ''),ftth:hfc?.esFTTH === true} : null;
        if (active && !same(active)) close();
        if (permissionView && !same(permissionView)) permissionView.cancel();
        const now = context();
        if (!now) { button?.remove(); button = null; return; }
        const after = now.root.querySelector('.viena-moica-gee-button') || now.root.querySelector('.viena-moica-viewer-button');
        if (!after) return;
        if (!button || !now.root.contains(button)) {
            button?.remove(); button = document.createElement('button'); button.type = 'button'; button.className = 'viena-infocall-button';
            button.onmousedown = event => event.stopPropagation();
            button.onclick = async event => {
                event.preventDefault(); event.stopPropagation();
                const current = context(); if (!current || button.disabled) return;
                let optionalAccess = false;
                try { optionalAccess = chrome.runtime.getManifest().optional_host_permissions?.includes(INFO+'/*') === true; } catch (_) {}
                if (optionalAccess) {
                    button.disabled = true;
                    try {
                        const access = await chrome.runtime.sendMessage({type:'VIENA_INFOCALL_ACCESS',open:true});
                        if (!access?.ok && (access?.code !== 'permission_required' || !await requestAccess(current))) return;
                    } catch (_) { return; }
                    finally { button.disabled = false; }
                    const latest = context();
                    if (!latest || latest.root !== current.root || latest.identity !== current.identity || latest.client !== current.client || latest.node !== current.node) return;
                }
                open(current,button);
            };
        }
        const text = 'Infocall3 - '+now.client; if (button.textContent !== text) button.textContent = text;
        if (after.nextElementSibling !== button) after.after(button); style();
    }
    globalThis.VienaInfocallViewer = {refresh,close};
})();
