(() => {
    'use strict';
    const MOICA = 'https://moica2.telecentro.net.ar';
    const VIENA = 'https://viena.telecentro.net.ar';
    const validTicket = value => /^\d{6}[A-Z]{2}\d+$/i.test(value);
    const validNode = value => /^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(value);
    const defaultNodeStates = ['Abierto','Completado','En Curso','Pausado'];
    const activeNodeStates = ['Abierto','En Curso','Pausado'];
    const gieTask = number => /^\d{6}GIE\d+$/i.test(number);
    const sreTask = number => /^\d{6}SRE\d+$/i.test(number);
    const nodeTaskState = task => gieTask(task.number) ? typeof task.state === 'string' && task.state.length <= 100 && !/[\u0000-\u001f\u007f]/.test(task.state) : ['ASIGNADA','AGENDADA','INICIADA','EN CURSO','SUSPENDIDA','EN VIAJE','COMPLETADA','CANCELADA'].includes(task.state);
    function listedNodeTasks(read, ticket) {
        const tasks = [];
        for (const column of ['last_field_task','last_intern_task']) {
            const number = read(column + '.ticketNumber'), state = read(column + '.status').toUpperCase();
            const task = {number,state};
            if ((gieTask(number) || /^\d{6}EP\d+$/i.test(ticket) && sreTask(number)) && nodeTaskState(task)) {
                const previous = tasks.find(task=>task.number === number);
                if (previous && previous.state !== state) return [];
                if (!previous) tasks.push(task);
            }
        }
        return tasks;
    }
    function nodeTicketVisible(row, tasks = []) {
        if (tasks.some(task=>gieTask(task.number))) return true;
        return /^\d{6}(?:AT|RI|ME|MP|MT)\d+$/i.test(row.number) ? tasks.some(task=>task.state === 'INICIADA') : row.state === 'En Curso' || tasks.some(task=>['AGENDADA','INICIADA','ASIGNADA','SUSPENDIDA'].includes(task.state) || /^\d{6}EP\d+$/i.test(row.number) && sreTask(task.number) && task.state === 'EN CURSO');
    }
    async function readFieldTasks(ticket, current, deadline, track = () => {}, fo = false) {
        const started = Date.now(); let requestedPage = 0;
        const failure = (code,details = {}) => Object.assign(Error(code),{fieldDiagnostic:{code,page:requestedPage,elapsedMs:Date.now()-started,...details}});
        const grid = document.getElementById('grid_TktsTarea'), $ = window.jQuery;
        if (!validTicket(ticket) || !grid?.grid || !$?.ajax || !$.jgrid?.getAccessor) throw failure('task_grid_unavailable',{gridPresent:!!grid,gridReady:!!grid?.grid,ajaxAvailable:typeof $?.ajax === 'function',accessorAvailable:typeof $?.jgrid?.getAccessor === 'function'});
        const param = key => $(grid).jqGrid('getGridParam',key);
        const url = new URL(param('url'),location.href), names = param('prmNames'), size = Number(param('rowNum'));
        if (url.origin !== MOICA || url.pathname !== '/grids/gridController.php' || url.searchParams.get('coll') !== 'ApiMoicaTask' || param('mtype') !== 'GET' || !names?.page || !names.rows || !names.search || !Number.isSafeInteger(size) || size < 1) throw failure('task_contract_unverified',{originMatches:url.origin === MOICA,pathMatches:url.pathname === '/grids/gridController.php',collectionMatches:url.searchParams.get('coll') === 'ApiMoicaTask',methodIsGet:param('mtype') === 'GET',pageParam:!!names?.page,rowsParam:!!names?.rows,searchParam:!!names?.search,rowSizeValid:Number.isSafeInteger(size) && size > 0});
        url.searchParams.set('defaultFilter',JSON.stringify({nroTkt:ticket}));
        const tasks = [], seen = new Set(); let expected, total, scanned = 0;
        for (let page = 1; ; page++) {
            if (!current() || Date.now() >= deadline) throw failure(current() ? 'deadline_exceeded' : 'context_cancelled');
            requestedPage = page;
            const data = {oper:'grid',[names.page]:page,[names.rows]:size,[names.search]:false};
            // The native grid defaults to titulo; use the same unique identity
            // we validate below so equal/missing titles cannot reshuffle pages.
            if (names.sort) data[names.sort] = 'ticketNumber';
            if (names.order) data[names.order] = 'asc';
            const timeout = Math.min(12000,deadline-Date.now());
            const response = await new Promise((resolve,reject) => {
                let settled = false, request, timer;
                const finish = (error,result) => { if (settled) return; settled = true; clearTimeout(timer); track(null); error ? reject(error) : resolve(result); };
                timer = setTimeout(() => { finish(failure('request_timeout')); request?.abort(); },timeout);
                try { request = $.ajax({url:url.href,type:'GET',dataType:'json',data,timeout,success:r=>finish(null,r),error:(xhr,status)=>finish(failure('request_failed',{httpStatus:Number.isInteger(xhr?.status) ? xhr.status : 0,ajaxStatus:['timeout','abort','parsererror','error'].includes(status) ? status : 'other'}))}); if (!settled) track(request); }
                catch (error) { finish(error); }
            });
            if (!current() || Date.now() >= deadline) throw failure(current() ? 'deadline_exceeded' : 'context_cancelled');
            const emptyFo = fo && page === 1 && response?.rows === null && String(response.page) === '1' && String(response.records) === '0' && ['0','1'].includes(String(response.total));
            const rows = emptyFo ? [] : response?.rows;
            if (!response || response.noses || !Array.isArray(rows)) throw failure(response?.noses ? 'session_expired' : 'response_unverified',{rowsKind:Array.isArray(response?.rows) ? 'array' : response?.rows === null ? 'null' : typeof response?.rows});
            const records = Number(response.records), pages = Number(response.total);
            if (!/^\d+$/.test(String(response.records)) || !/^\d+$/.test(String(response.total)) || !Number.isSafeInteger(records) || !Number.isSafeInteger(pages) || Number(response.page) !== page || (records > 0 && pages < 1) || (records === 0 && pages > 1) || (page > 1 && (records !== expected || pages !== total))) throw failure('pagination_unverified');
            expected = records; total = pages;
            for (const row of rows) {
                const get = key => String($.jgrid.getAccessor(row,key) || '').trim();
                const number = get('ticketNumber'), type = get('taskTypification.taskType.name').toUpperCase(), state = get('status').toUpperCase();
                if (!number || seen.has(number)) throw failure(!number ? 'task_identity_missing' : 'task_identity_duplicate');
                seen.add(number);
                if (fo) {
                    if (!/^\d{6}[A-Z]{3}\d+$/i.test(number)) throw failure('task_identity_missing');
                    if (/^\d{6}(?:VAO|VXC|VXA)\d+$/i.test(number)) {
                        if (!['ASIGNADA','INICIADA','AGENDADA','EN CURSO','SUSPENDIDA','COMPLETADA','ABIERTO','ABIERTA','EN VIAJE','CANCELADA'].includes(state)) throw failure('task_state_unverified');
                        if (['INICIADA','AGENDADA','EN CURSO','SUSPENDIDA','COMPLETADA','ABIERTO','ABIERTA'].includes(state)) tasks.push({number,state});
                    }
                    continue;
                }
                const includedInternal = type === 'TAREA INTERNA' && (gieTask(number) || /^\d{6}EP\d+$/i.test(ticket) && sreTask(number));
                if (type === 'TAREA INTERNA' && !includedInternal) continue;
                if (type !== 'TAREA DE CAMPO' && !includedInternal || !nodeTaskState({number,state})) throw failure(type !== 'TAREA DE CAMPO' && !includedInternal ? 'task_type_unverified' : 'task_state_unverified');
                tasks.push({number,state});
            }
            scanned += rows.length;
            if (page >= total) { if (scanned !== records) throw failure('row_count_mismatch'); return tasks; }
            if (!rows.length) throw failure('empty_intermediate_page');
        }
    }
    function nodeSearchUrl(nativeUrl, node, visible = false, onmsi = false) {
        const url = new URL(nativeUrl, MOICA);
        if (!validNode(node) || url.origin !== MOICA || url.pathname !== '/grids/gridController.php' || url.searchParams.get('grid') !== 'grid_TktsBuscar') throw Error('Búsqueda no disponible.');
        const legacy = node + ', ';
        // MOICA stores both forms of the same exact reference.
        const nodeMatch = onmsi ? {$in:[node,legacy]} : {$eq:legacy};
        url.searchParams.set('defaultFilter', JSON.stringify({'estado_actual.estado':{$in:visible ? defaultNodeStates : activeNodeStates},nodoRef:{$elemMatch:nodeMatch}}));
        return url.href;
    }
    function validateNodePage(rows, metadata, page, visible = false) {
        const count = Number(metadata.records), last = Number(metadata.lastpage);
        if (metadata.records == null || metadata.records === '' || !Number.isSafeInteger(count) || count < 0 || Number(metadata.page) !== page || !(last === Math.ceil(count / 100) || count === 0 && last === 1) || rows.length !== Math.min(100, Math.max(0,count - (page - 1) * 100)) || rows.some(row => !validTicket(row.number) || !(visible ? defaultNodeStates : activeNodeStates).includes(row.state))) throw Error('La búsqueda no se recibió completa. Reintentá.');
        return rows;
    }
    function receiveNodeSearch(params) {
        const node = params.get('vienaNodeSearch'), token = params.get('vienaViewerSession');
        let referrer;
        try { referrer = new URL(document.referrer).origin; } catch (_) { return; }
        const onmsi=params.get('vienaOnmsi')==='1'&&(referrer==='http://onmsi.telecentro.net.ar'||referrer===MOICA&&params.get('vienaOnmsiRelay')==='1'),destination=onmsi?referrer:VIENA;
        if (parent === window || (!onmsi&&referrer !== VIENA) || !validNode(node) || !/^[a-f0-9]{32}$/.test(token || '')) return;
        const visible = params.get('vienaNodeVisible') === '1';
        let stopped = false, waitTimer, requestTimer, taskRequest, grid, page = 1, total = null, originalError, originalBefore, hooked = false;
        const results = [], seen = new Set(), deadline = Date.now() + 60000;
        const report = data => parent.postMessage({type:'VIENA_MOICA_NODE_RESULT',token,...data},destination);
        const cleanup = () => { clearTimeout(waitTimer); clearTimeout(requestTimer); grid?.off('.vienaNodeSearch'); if (hooked) { hooked = false; grid.jqGrid('setGridParam',{loadError:originalError,beforeProcessing:originalBefore}); } };
        const stop = () => { stopped = true; cleanup(); taskRequest?.abort(); taskRequest = null; grid?.off('.vienaNodeHighlight'); };
        const fail = () => { if (stopped) return; stop(); report({ok:false,message:'No se pudo completar la búsqueda. Revisá la sesión de MOICA2 y reintentá.'}); };
        window.addEventListener('pagehide',stop,{once:true});
        function readPage() {
            if (stopped) return;
            clearTimeout(requestTimer);
            try {
                const p = grid.jqGrid('getGridParam');
                const cell = (row, name) => row.querySelector('td[aria-describedby="grid_TktsBuscar_' + name + '"]')?.textContent.trim() || '';
                const rows = [...document.querySelectorAll('#grid_TktsBuscar tr.jqgrow')].map(row => ({number:cell(row,'nroTkt'),state:cell(row,'estado_actual.estado'),subject:cell(row,'asunto.titulo'),queue:cell(row,'estado_actual.colaCreacion'),problem:cell(row,'problemas'),listedTasks:listedNodeTasks(name=>cell(row,name),cell(row,'nroTkt'))}));
                validateNodePage(rows,p,page,visible||onmsi);
                if (total !== null && total !== Number(p.records)) throw Error('Resultados cambiaron.');
                total = Number(p.records);
                // Validate every native row, but omit IE from the automatic list and field checks.
                for (const row of rows) { if (seen.has(row.number)) throw Error('Página repetida.'); seen.add(row.number); if (onmsi ? /^\d{6}FO\d+$/i.test(row.number) : visible || !/^\d{6}(?:IE|MS|GV|RV|AA|MZ|ZT)\d+$/i.test(row.number)) results.push(row); }
                if (!visible && page < Number(p.lastpage)) { page++; waitTimer = setTimeout(request,0); return; }
                cleanup();
                report({ok:true,rows:visible ? [] : results,count:visible ? total : results.length});
                if (visible) stopped = true;
                else void verifyTasks();
            } catch (_) { fail(); }
        }
        async function verifyTasks() {
            try {
                if (onmsi) {
                    for (const row of results) {
                        if (stopped) return;
                        try {
                            const read=()=>readFieldTasks(row.number,()=>!stopped,deadline,r=>{taskRequest=r;},true);
                            const relay=referrer===MOICA&&params.get('vienaOnmsiRelay')==='1'?parent.__vienaOnmsiMoica:null;
                            const tasks=await (relay?.token===token&&typeof relay.readTasks==='function'?relay.readTasks(row.number,read):read());
                            if(!stopped)parent.postMessage({type:'VIENA_MOICA_NODE_TASKS',token,ticket:row.number,ok:true,tasks},destination);
                        } catch(error) {
                            if(!stopped)parent.postMessage({type:'VIENA_MOICA_NODE_TASKS',token,ticket:row.number,ok:false,diagnostic:error.fieldDiagnostic||{code:'unexpected_error'}},destination);
                            break;
                        }
                    }
                    return;
                }
                // These columns already expose the requested SRE/GIE state in
                // Buscar Ticket. Publish them before any detail request can fail.
                const listed = results.filter(row=>row.listedTasks.length && nodeTicketVisible({number:row.number,state:''},row.listedTasks));
                for (const row of listed) {
                    if (stopped) return;
                    parent.postMessage({type:'VIENA_MOICA_NODE_TASKS',token,ticket:row.number,ok:true,tasks:row.listedTasks,at:Date.now(),taskSource:'list',diagnostic:{code:'complete',elapsedMs:0}},VIENA);
                }
                for (const row of results) {
                    if (stopped) return;
                    if (listed.includes(row)) continue;
                    const started = Date.now();
                    try {
                        const tasks = await readFieldTasks(row.number,()=>!stopped,deadline,request=>{ taskRequest = request; });
                        if (!stopped) parent.postMessage({type:'VIENA_MOICA_NODE_TASKS',token,ticket:row.number,ok:true,tasks,at:Date.now(),diagnostic:{code:'complete',elapsedMs:Date.now()-started}},VIENA);
                    } catch (error) {
                        if (!stopped) parent.postMessage({type:'VIENA_MOICA_NODE_TASKS',token,ticket:row.number,ok:false,diagnostic:error?.fieldDiagnostic || {code:'unexpected_error',elapsedMs:Date.now()-started}},VIENA);
                        // A bad task list belongs to this ticket, not the whole node.
                        // Network/session/contract failures still stop to avoid fan-out.
                        if (!['task_identity_duplicate','task_identity_missing','task_type_unverified','task_state_unverified','pagination_unverified','row_count_mismatch','empty_intermediate_page'].includes(error?.fieldDiagnostic?.code)) break;
                    }
                }
            } finally {
                if (!stopped) parent.postMessage({type:'VIENA_MOICA_NODE_TASKS',token,done:true},destination);
                stop();
            }
        }
        function request() {
            if (stopped || Date.now() >= deadline) { fail(); return; }
            requestTimer = setTimeout(fail,Math.min(15000,deadline - Date.now()));
            grid.jqGrid('setGridParam',{page,rowNum:100,sortname:'_id',sortorder:'asc',datatype:'json'}).trigger('reloadGrid');
        }
        function ready() {
            if (stopped) return;
            if (Date.now() >= deadline) { fail(); return; }
            try {
                const $ = window.jQuery, element = document.getElementById('grid_TktsBuscar');
                if (!element?.grid || typeof $ !== 'function' || typeof $(element).jqGrid !== 'function' || element.grid.hDiv?.loading) { waitTimer = setTimeout(ready,150); return; }
                grid = $(element);
                if (visible) grid.on('jqGridGridComplete.vienaNodeHighlight',() => {
                    // Same state-cell treatment as resaltarEnCurso in the page's js/60.
                    for (const td of element.querySelectorAll('tr.jqgrow td[aria-describedby="grid_TktsBuscar_estado_actual.estado"]')) {
                        const en = String(td.textContent || '').replace(/\s+/g,' ').trim().toLowerCase() === 'en curso';
                        if (en) { td.style.setProperty('background-color','#fff3a3','important'); td.style.setProperty('font-weight','700','important'); td.dataset.vienaMoicaEnCurso = '1'; }
                        else if (td.dataset.vienaMoicaEnCurso === '1') { td.style.removeProperty('background-color'); td.style.removeProperty('font-weight'); delete td.dataset.vienaMoicaEnCurso; }
                    }
                });
                const p = grid.jqGrid('getGridParam');
                const url = nodeSearchUrl(p.url,node,visible||onmsi,onmsi);
                // The frame is private to this lookup; native search fields match its filter.
                const input = document.getElementById('TKT-BUSCAR-NODO-autocom');
                if (input) input.value = node + ', ';
                const states = document.getElementById('TKT-BUSCAR-ESTADO');
                if (states) { for (const option of states.options) option.selected = visible||onmsi ? defaultNodeStates.includes(option.value) : option.value === 'En Curso'; if (typeof $(states).selectpicker === 'function') $(states).selectpicker('refresh'); }
                window.findAnt = JSON.stringify(JSON.parse(new URL(url).searchParams.get('defaultFilter'))).slice(1,-1);
                originalError = p.loadError; originalBefore = p.beforeProcessing; hooked = true;
                grid.jqGrid('setGridParam',{url,loadError:function(...args) { try { originalError?.apply(this,args); } finally { fail(); } },beforeProcessing:function(data,...args) {
                    if (!data || data.records == null || data.records === '' || !Number.isSafeInteger(Number(data.records)) || Number(data.records) < 0 || Number(data.page) !== page || !Number.isSafeInteger(Number(data.total)) || !(Array.isArray(data.rows) || data.rows === null && Number(data.records) === 0)) { fail(); return false; }
                    return originalBefore?.call(this,data,...args);
                }});
                grid.on('jqGridGridComplete.vienaNodeSearch',readPage);
                request();
            } catch (_) { fail(); }
        }
        ready();
    }
    function references(root) {
        const found = [];
        for (const table of root.querySelectorAll('table')) {
            const columns = [...table.querySelectorAll('thead th')];
            const index = columns.findIndex(el => el.textContent.replace(/\s+/g, ' ').trim().toLowerCase() === 'nro evento');
            if (index < 0) continue;
            for (const row of table.querySelectorAll('tbody tr')) {
                const value = String(row.querySelectorAll('td')[index]?.textContent || '').trim().toUpperCase();
                if (validTicket(value) && !found.includes(value)) found.push(value);
            }
        }
        return found;
    }
    if (typeof module === 'object' && module.exports) { module.exports = { references, validTicket, nodeSearchUrl, validateNodePage, readFieldTasks, nodeTicketVisible, listedNodeTasks }; return; }
    // MAIN-world receiver runs only in the dedicated native MOICA child frame.
    if (location.origin === MOICA) {
        const params = new URL(location.href).searchParams;
        if (params.has('vienaNodeSearch')) { receiveNodeSearch(params); return; }
        const ticket = params.get('vienaViewerTicket') || '';
        const token = params.get('vienaViewerSession') || '';
        let referrer;
        try { referrer = new URL(document.referrer).origin; } catch (_) { return; }
        const viewerOrigin=params.get('vienaOnmsi')==='1'&&(referrer==='http://onmsi.telecentro.net.ar'||referrer===MOICA&&params.get('vienaOnmsiRelay')==='1')?referrer:VIENA;
        if (parent === window || referrer !== viewerOrigin || !validTicket(ticket) || !/^[a-f0-9]{32}$/.test(token)) return;
        let called = false, timer;
        const deadline = Date.now() + 15000;
        const report = state => parent.postMessage({ type: 'VIENA_MOICA_VIEWER', token, state }, viewerOrigin);
        function stop() { clearTimeout(timer); }
        window.addEventListener('pagehide', stop, { once: true });
        function check() {
            try {
                const modal = document.getElementById('MO-TKT-VER');
                const number = String(document.getElementById('TKT-VER-VISTA-NRO')?.textContent || '').toUpperCase();
                if (modal?.getClientRects().length && (number.match(/\b\d{6}[A-Z]{2}\d+\b/g) || []).includes(ticket.toUpperCase()) && document.getElementById('TKT-VER-ID')?.value) {
                    report('ready'); return;
                }
                if (!called && modal && typeof window.getIdTicketbyNro === 'function' && typeof window.jQuery === 'function') {
                    called = true;
                    // Original lookup/opening flow, including native read marking and permissions.
                    window.getIdTicketbyNro(ticket);
                }
                if (Date.now() >= deadline) { report('unavailable'); return; }
                timer = setTimeout(check, 150);
            } catch (_) { report('unavailable'); }
        }
        check();
        return;
    }
    if (location.origin !== VIENA || globalThis.VienaMoicaViewer) return;
    let active = null, button = null, resolving = false, geeButton = null, gecButton = null, gedButton = null, geeBusy = false, closeOutside = false;
    let gedAuto = null, gecAuto = null, geeAuto = null, nodeAuto = null;
    const normalizeGedTask = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
    const GED_TASKS = new Set(['HFC - Diagnostico de ruido en directa','HFC - Diagnóstico de Repitencia Fec Directa','HFC - Diagnostico de ruido en retorno','HFC - Diagnóstico de Repitencia de Ruido en Retorno'].map(normalizeGedTask));
    function gedTask(context) {
        const label = [...(context?.root.querySelectorAll('.v-text-field__slot > label') || [])].find(el => /^tipificaci[oó]n de la tarea$/i.test(el.textContent.replace(/\s+/g,' ').trim()));
        const value = label?.closest('.v-input')?.querySelector('.v-text-field__slot > input')?.value || '';
        return GED_TASKS.has(normalizeGedTask(value));
    }
    const GEC_TASK_CODES = new Set(['DCE','DCF','DSA','CSH','FEV','CSF','CHZ','CEH','DEF','SDH','EVT','CMH','DFF']);
    function gecTask(context) {
        const code = context?.identity.match(/^TICKET\s*:\s*\d{6}([A-Z]{3})\d+\s*$/i)?.[1]?.toUpperCase();
        return GEC_TASK_CODES.has(code);
    }
    function geeTask(context) {
        return /^TICKET\s*:\s*\d{6}EFS\d+\s*$/i.test(context?.identity || '');
    }
    const CLOSE_OUTSIDE_KEY = 'viena_moica_viewer_close_outside_v1';
    let outsideChanged = false;
    const preferenceStorage = globalThis.chrome?.storage?.local;
    if (preferenceStorage) {
        void preferenceStorage.get(CLOSE_OUTSIDE_KEY).then(saved => {
            if (outsideChanged || typeof saved[CLOSE_OUTSIDE_KEY] !== 'boolean') return;
            closeOutside = saved[CLOSE_OUTSIDE_KEY];
            const input = active?.panel.querySelector('.viewer-outside-toggle input');
            if (input) input.checked = closeOutside;
        }).catch(() => {});
    }
    const initialTabs = new WeakMap();
    let previousTabRoot = null;
    function eventsTab(context) {
        return [...context.root.querySelectorAll('.v-tabs a, .v-tabs .v-tab, [role="tab"], a, button')]
            .find(el => el.textContent.replace(/\s+/g, ' ').trim().toLowerCase() === 'eventos relacionados');
    }
    async function resolveContext(context) {
        const tab = eventsTab(context);
        if (tab && !tab.classList.contains('v-tab--active') && tab.getAttribute('aria-selected') !== 'true') tab.click();
        const deadline = Date.now() + 8000;
        while (true) {
            const next = ticketContext();
            if (!next || next.root !== context.root || next.identity !== context.identity) return null;
            if (next.tickets.length || !tab || Date.now() >= deadline) return next;
            await new Promise(resolve => setTimeout(resolve, 100));
        }
    }
    function ticketContext() {
        const roots = [...document.querySelectorAll('.v-dialog__content--active')]
            .filter(root => root.getClientRects().length && /^TICKET\s*:/i.test(root.querySelector('.v-toolbar__title')?.textContent.trim() || ''));
        if (roots.length !== 1) return null;
        const root = roots[0];
        return { root, identity: root.querySelector('.v-toolbar__title').textContent.trim(), tickets: references(root) };
    }
    function close(restoreFocus = true) {
        if (!active) return;
        const view = active; active = null;
        view.cleanup?.();
        clearTimeout(view.timeout);
        window.removeEventListener('message', view.message);
        document.removeEventListener('keydown', view.key, true);
        document.removeEventListener('pointerdown', view.outside, true);
        view.frame?.remove(); view.panel.remove();
        if (restoreFocus && view.focus?.isConnected) view.focus.focus({ preventScroll: true });
    }
    function outsideOption(view, header) {
        const label = document.createElement('label'); label.className = 'viewer-outside-toggle';
        const input = document.createElement('input'); input.type = 'checkbox'; input.checked = closeOutside;
        input.onchange = () => {
            outsideChanged = true;
            closeOutside = input.checked;
            input.title = '';
            if (preferenceStorage) void preferenceStorage.set({ [CLOSE_OUTSIDE_KEY]: closeOutside }).catch(() => {
                input.title = 'No se pudo guardar la opción. Volvé a marcar tu elección para reintentar.';
            });
        };
        label.append(input,document.createTextNode('Cerrar al hacer clic fuera'));
        header.insertBefore(label,header.querySelector('button'));
        view.outside = event => {
            if (active === view && closeOutside && !view.panel.contains(event.target)) close(false);
        };
        document.addEventListener('pointerdown',view.outside,true);
    }
    function sameContext(view) {
        const next = ticketContext();
        return next && next.root === view.context.root && next.identity === view.context.identity && JSON.stringify(next.tickets) === JSON.stringify(view.context.tickets);
    }
    function style() {
        if (document.getElementById('viena-moica-viewer-style')) return;
        const el = document.createElement('style'); el.id = 'viena-moica-viewer-style';
        el.textContent = `#viena-moica-viewer{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:88vw;height:82vh;z-index:2147483646;display:flex;flex-direction:column;box-sizing:border-box;background:#fff;color:#18354e;border:2px solid #225c91;border-radius:8px;box-shadow:0 8px 40px #0008;overflow:hidden;font:14px Arial}#viena-moica-viewer header{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:10px;background:#225c91;color:#fff;flex:none}#viena-moica-viewer header strong{flex:1}#viena-moica-viewer button{padding:7px 12px;border:1px solid #bbd0e1;border-radius:4px;background:#fff;color:#18354e;cursor:pointer}#viena-moica-viewer .viewer-status{padding:8px 12px;flex:none}#viena-moica-viewer iframe{width:100%;flex:1;min-height:0;border:0;background:#fff}#viena-moica-viewer form{display:flex;gap:8px;padding:12px;flex-wrap:wrap}#viena-moica-viewer input,#viena-moica-viewer select{padding:8px;max-width:100%;color:#18354e;background:#fff} .viena-moica-viewer-button{padding:8px 12px;border:0;border-radius:5px;background:#225c91;color:white;cursor:pointer;font-weight:600}@media(max-width:600px){#viena-moica-viewer{width:94vw;height:86vh}}`;
        document.head.append(el);
        el.textContent += '.viena-ged-report{white-space:pre-line}';
        el.textContent += '.viena-ged-report[data-details="true"]{max-height:min(52vh,520px);white-space:normal;font-weight:400}.ged-heading{display:block;font-size:14px}.ged-overview,.ged-cmts,.ged-empty{font-size:12px;margin:4px 0 9px}.ged-group{margin-top:13px}.ged-group-title{display:block;color:#235d96;margin-bottom:4px}.ged-group[data-group="Retorno"] .ged-group-title{color:#75459e}.ged-ticket{box-sizing:border-box;border:1px solid #cbdff4;border-left:4px solid #4385c6;border-radius:5px;background:#f5f9ff;color:#344a5e;padding:11px 12px;margin:8px 0;overflow-wrap:anywhere}.ged-group[data-group="Retorno"] .ged-ticket{border-color:#e1d4f0;border-left-color:#9465be;background:#faf6ff}.ged-ticket-header{display:grid;grid-template-columns:minmax(100px,1fr) auto auto;align-items:center;gap:9px 14px}.ged-ticket-number{color:#235d96}.ged-group[data-group="Retorno"] .ged-ticket-number{color:#75459e}.ged-ticket-state{font-size:11px;font-weight:700;padding:3px 8px;border-radius:4px;background:#e9edf2;color:#526375}.ged-ticket-state[data-in-progress="true"]{background:#ffedac;color:#795609}.ged-ticket-created{font-size:12px}.ged-ticket-problem{margin-top:9px;padding-top:8px;border-top:1px solid #dce8f5;font-size:13px}.ged-group[data-group="Retorno"] .ged-ticket-problem{border-top-color:#e9dff3}.ged-warning{margin-top:6px;font-weight:600}@media(max-width:1000px){.ged-ticket-header{grid-template-columns:minmax(90px,1fr) auto}.ged-ticket-created{grid-column:1/-1}}';
        el.textContent += 'html[data-viena-theme="dark"] .viena-ged-report[data-details="true"],.theme--dark .viena-ged-report[data-details="true"]{background:#263447;color:#e2e8f0;border-color:#64748b}html[data-viena-theme="dark"] .ged-ticket,.theme--dark .ged-ticket{background:#1d304a;color:#e2e8f0;border-color:#43648a;border-left-color:#74b4ef}html[data-viena-theme="dark"] .ged-group[data-group="Retorno"] .ged-ticket,.theme--dark .ged-group[data-group="Retorno"] .ged-ticket{background:#32253f;border-color:#66527b;border-left-color:#bd92e4}html[data-viena-theme="dark"] .ged-group-title,html[data-viena-theme="dark"] .ged-ticket-number,.theme--dark .ged-group-title,.theme--dark .ged-ticket-number{color:#a7d3ff}html[data-viena-theme="dark"] .ged-group[data-group="Retorno"] .ged-group-title,html[data-viena-theme="dark"] .ged-group[data-group="Retorno"] .ged-ticket-number,.theme--dark .ged-group[data-group="Retorno"] .ged-group-title,.theme--dark .ged-group[data-group="Retorno"] .ged-ticket-number{color:#d8b8f5}';
        el.textContent += '.viena-ged-report,#viena-moica-viewer .viewer-status.viena-ged-report{box-sizing:border-box;display:block;flex-basis:auto;width:100%;max-width:100%;max-height:24vh;overflow:auto;overflow-wrap:anywhere;margin:8px 0;padding:10px 12px;border:1px solid #93baf0;border-left:5px solid #2563eb;border-radius:7px;background:#e8f2ff;color:#173b64;font:600 13px/1.5 Arial}.viena-ged-report[data-state="matches"],#viena-moica-viewer .viewer-status.viena-ged-report[data-state="matches"]{background:#fff4d6;color:#713f12;border-color:#e6b65a;border-left-color:#d97706}.viena-ged-report[data-state="partial"],#viena-moica-viewer .viewer-status.viena-ged-report[data-state="partial"]{background:#fee2e2;color:#7f1d1d;border-color:#f1a5a5;border-left-color:#dc2626}';
        el.textContent += '#viena-moica-viewer .viewer-outside-toggle{display:inline-flex;align-items:center;gap:6px;font-size:12px;cursor:pointer}#viena-moica-viewer .viewer-outside-toggle input{width:15px;height:15px;min-width:15px;padding:0;margin:0;accent-color:#1976d2}';
        el.textContent += '.viena-node-progress button{padding:6px 10px;margin:3px 4px 3px 0;border:1px solid #8caecb;border-radius:5px;background:#fff;color:#18354e;font:600 12px Arial;cursor:pointer}.viena-node-progress button:hover{background:#dcebf8}.viena-node-progress button:focus-visible{outline:2px solid #1976d2;outline-offset:2px}.viena-node-progress button:disabled{opacity:.6;cursor:wait}.viena-node-progress summary{font-weight:600}';
        el.textContent += '.viena-node-progress .viena-node-field-task{overflow-wrap:anywhere}.viena-node-progress .viena-node-field-state{display:inline-block;padding:1px 5px;margin:1px 0;border:1px solid currentColor;border-radius:4px;font-size:11px;font-weight:700;line-height:1.5;white-space:nowrap;background:#dbeafe;color:#1e40af}.viena-node-progress .viena-node-field-state[data-state="AGENDADA"]{background:#ede9fe;color:#5b21b6}.viena-node-progress .viena-node-field-state:is([data-state="INICIADA"],[data-state="EN CURSO"]){background:#dcfce7;color:#166534}.viena-node-progress .viena-node-field-state[data-state="EN VIAJE"]{background:#cffafe;color:#155e75}.viena-node-progress .viena-node-field-state[data-state="CANCELADA"]{background:#fee2e2;color:#991b1b}.viena-node-progress .viena-node-field-state[data-state="SUSPENDIDA"]{background:#fef3c7;color:#92400e}.viena-node-progress .viena-node-field-state[data-state="COMPLETADA"]{background:#e2e8f0;color:#334155}';
        el.textContent += ':is(html[data-viena-theme="dark"],.theme--dark) .viena-node-progress .viena-node-field-state{background:#1e3a5f;color:#bfdbfe}:is(html[data-viena-theme="dark"],.theme--dark) .viena-node-progress .viena-node-field-state[data-state="AGENDADA"]{background:#3b285d;color:#ede9fe}:is(html[data-viena-theme="dark"],.theme--dark) .viena-node-progress .viena-node-field-state:is([data-state="INICIADA"],[data-state="EN CURSO"]){background:#143d2b;color:#bbf7d0}:is(html[data-viena-theme="dark"],.theme--dark) .viena-node-progress .viena-node-field-state[data-state="EN VIAJE"]{background:#16404b;color:#a5f3fc}:is(html[data-viena-theme="dark"],.theme--dark) .viena-node-progress .viena-node-field-state[data-state="CANCELADA"]{background:#54282e;color:#fecaca}:is(html[data-viena-theme="dark"],.theme--dark) .viena-node-progress .viena-node-field-state[data-state="SUSPENDIDA"]{background:#4a351b;color:#fde68a}:is(html[data-viena-theme="dark"],.theme--dark) .viena-node-progress .viena-node-field-state[data-state="COMPLETADA"]{background:#334155;color:#e2e8f0}';
        el.textContent += '.viena-node-progress [data-current-viena=true]{background:#d9f3e5;border-left:4px solid #218454;padding-left:8px!important}.viena-node-current-badge{display:block;color:#155b39;font-weight:700}.viena-node-current-badge[hidden]{display:none}';
        el.textContent += '.viena-ged-report[data-details="true"][data-state]{background:#fff;color:#334155}.ged-report-heading{background:#fff4d8;color:#75420d;margin:-10px -12px 10px;padding:10px 12px;border-bottom:1px solid #eddfbf}.ged-report-heading .ged-overview{margin-bottom:0}html[data-viena-theme="dark"] .ged-report-heading,.theme--dark .ged-report-heading{background:#3f3625;color:#fbe3ab;border-color:#665432}';
        el.textContent += '@media(max-width:400px){.ged-ticket-header{grid-template-columns:minmax(0,1fr)}.ged-ticket-number{white-space:nowrap}.ged-ticket-state{justify-self:start}}';
        el.textContent += '.ged-ticket[data-current-viena="true"]{outline:2px solid #218454;outline-offset:-2px}.ged-ticket-current{display:block;margin-top:8px;padding:4px 7px;border-radius:4px;background:#e1f5e9;color:#155b39;font-size:12px;font-weight:700}.ged-ticket-current[hidden]{display:none}html[data-viena-theme="dark"] .ged-ticket[data-current-viena="true"],.theme--dark .ged-ticket[data-current-viena="true"]{outline-color:#62c895}html[data-viena-theme="dark"] .ged-ticket-current,.theme--dark .ged-ticket-current{background:#17402e;color:#bbf7d0}';
        el.textContent += '.ged-field-tasks{margin-top:8px;font-size:12px;line-height:1.6}.ged-field-task{display:block;margin-top:4px;padding:3px 7px;border-radius:4px;background:#e4efff;color:#214f87}.ged-field-task[data-state="AGENDADA"]{background:#eee5fa;color:#694093}.ged-field-task[data-state="INICIADA"],.ged-field-task[data-state="EN CURSO"],.ged-field-task[data-state="EN VIAJE"]{background:#e1f5e9;color:#155b39}.ged-field-unverified{color:inherit;font-style:italic}html[data-viena-theme="dark"] .ged-field-task,.theme--dark .ged-field-task{background:#233f61;color:#c8e2ff}html[data-viena-theme="dark"] .ged-field-task[data-state="AGENDADA"],.theme--dark .ged-field-task[data-state="AGENDADA"]{background:#46305e;color:#ead7ff}html[data-viena-theme="dark"] .ged-field-task[data-state="INICIADA"],html[data-viena-theme="dark"] .ged-field-task[data-state="EN CURSO"],html[data-viena-theme="dark"] .ged-field-task[data-state="EN VIAJE"],.theme--dark .ged-field-task[data-state="INICIADA"],.theme--dark .ged-field-task[data-state="EN CURSO"],.theme--dark .ged-field-task[data-state="EN VIAJE"]{background:#17402e;color:#bbf7d0}';
        // Reports always follow the action row, regardless of asynchronous mount order.
        el.textContent += '.viena-ticket-tools-host .viena-node-progress{order:100}.viena-ticket-tools-host .viena-moica-gee-status{order:101}';
        el.textContent += '.viena-gec-report{box-sizing:border-box;display:block;width:100%;min-width:0;max-width:100%;margin:8px 0;padding:12px 14px;border:1px solid #cbd5e1;border-radius:8px;background:#f8fafc;color:#334155;font:13px/1.5 Arial;white-space:normal!important;overflow-wrap:anywhere}.viena-gec-report .gec-heading{display:block;margin-bottom:4px;font-weight:700;color:inherit}.viena-gec-report .gec-summary{display:block;font-size:12px;color:inherit}.viena-gec-report .gec-tasks{max-height:220px;overflow:auto;margin-top:8px}.viena-gec-report .gec-task{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap;padding:8px 0;border-top:1px solid #cbd5e1}.viena-gec-report .gec-task-label{min-width:0;flex:1 1 180px}.viena-gec-report .gec-state{padding:2px 8px;border:1px solid #93c5fd;border-radius:12px;background:#dbeafe;color:#1e40af;font-size:11px;font-weight:700;white-space:nowrap}.viena-gec-report .gec-state[data-state="AGENDADA"]{background:#ede9fe;color:#6d28d9;border-color:#c4b5fd}.viena-gec-report .gec-state[data-state="INICIADA"],.viena-gec-report .gec-state[data-state="EN VIAJE"]{background:#dcfce7;color:#166534;border-color:#86efac}.viena-gec-report[data-state="partial"]{border-color:#d99c36}.viena-gec-report[data-state="partial"] .gec-summary{color:#92400e}.viena-gec-report[data-state="loading"] .gec-summary{color:#475569}';
        el.textContent += 'html[data-viena-theme="dark"] .viena-gec-report,.theme--dark .viena-gec-report{background:#1e293b;color:#e2e8f0;border-color:#64748b}html[data-viena-theme="dark"] .viena-gec-report .gec-summary,.theme--dark .viena-gec-report .gec-summary{color:#cbd5e1}html[data-viena-theme="dark"] .viena-gec-report[data-state="partial"] .gec-summary,.theme--dark .viena-gec-report[data-state="partial"] .gec-summary{color:#fcd34d}';
        el.textContent += '.viena-gec-report .gec-state[data-state="EN CURSO"]{background:#dcfce7;color:#166534;border-color:#86efac}.viena-gec-report .gec-state[data-state="SUSPENDIDA"]{background:#fef3c7;color:#92400e;border-color:#fcd34d}.viena-gec-report .gec-state[data-state="PENDIENTE AGENDAMIENTO"]{background:#fef9c3;color:#713f12;border-color:#fde047}';
        el.textContent += '#viena-moica-viewer.viena-gee-node-choice{height:auto;max-height:86vh;width:min(520px,94vw)}#viena-moica-viewer.viena-gee-node-choice header strong{flex-basis:100%}';
        el.textContent += '#viena-moica-viewer .gee-node-options{display:grid;gap:10px;padding:4px 16px 16px;overflow:auto}#viena-moica-viewer .gee-node-options button{display:flex;align-items:center;justify-content:space-between;gap:16px;width:100%;min-height:52px;padding:12px 16px;border:1px solid #8caecb;border-radius:6px;background:#f0f6fb;color:#18354e;font:600 15px/1.4 Arial;text-align:left;white-space:normal;overflow-wrap:anywhere;cursor:pointer}#viena-moica-viewer .gee-node-options button span{font:400 13px/1.4 Arial;flex-shrink:0}#viena-moica-viewer .gee-node-options button:hover{background:#dcebf8;border-color:#225c91}#viena-moica-viewer .gee-node-options button:focus-visible{outline:3px solid #1976d2;outline-offset:2px}';
    }
    function load(view, ticket) {
        if (active !== view || !sameContext(view) || !validTicket(ticket)) return;
        clearTimeout(view.timeout); view.frame?.remove();
        view.token = [...crypto.getRandomValues(new Uint8Array(16))].map(v => v.toString(16).padStart(2, '0')).join('');
        const url = new URL('/buscarTicket.php', MOICA);
        url.searchParams.set('vienaViewerTicket', ticket);
        url.searchParams.set('vienaViewerSession', view.token);
        view.title.textContent = `Ver Ticket · ${ticket}`;
        view.status.textContent = 'Cargando el ticket en MOICA2…';
        const frame = document.createElement('iframe'); frame.title = `Ticket MOICA2 ${ticket}`;
        frame.referrerPolicy = 'origin'; frame.src = url.href;
        view.frame = frame; view.panel.append(frame);
        view.timeout = setTimeout(() => {
            if (active === view) view.status.textContent = 'No se pudo confirmar la apertura. Revisá la sesión, el número o los permisos en MOICA2. Podés reintentar.';
        }, 17000);
        view.ticket = ticket;
    }
    function open(context, focus, selectedTicket) {
        globalThis.VienaInfocallViewer?.close();
        close(); style();
        const panel = document.createElement('section'); panel.id = 'viena-moica-viewer';
        panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Ver Ticket MOICA2');
        const header = document.createElement('header'), title = document.createElement('strong'); title.textContent = 'Ver Ticket';
        const retry = document.createElement('button'); retry.type = 'button'; retry.textContent = 'Recargar';
        const exit = document.createElement('button'); exit.type = 'button'; exit.textContent = 'Cerrar'; exit.onclick = close;
        const status = document.createElement('div'); status.className = 'viewer-status'; status.setAttribute('role', 'status');
        header.append(title, retry, exit); panel.append(header, status);
        const view = { panel, title, status, context, focus, token:'', frame:null };
        const tickets = selectedTicket ? [selectedTicket] : context.tickets;
        active = view;
        outsideOption(view,header);
        view.message = event => {
            if (active !== view || event.origin !== MOICA || event.source !== view.frame?.contentWindow || event.data?.type !== 'VIENA_MOICA_VIEWER' || event.data.token !== view.token) return;
            if (!sameContext(view)) { close(); return; }
            if (!['ready','unavailable'].includes(event.data.state)) return;
            clearTimeout(view.timeout);
            status.textContent = event.data.state === 'ready' ? '' : 'MOICA2 no confirmó el ticket. Revisá sesión, número y permisos; podés reintentar.';
            status.hidden = event.data.state === 'ready';
        };
        view.key = event => { if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); close(); } };
        window.addEventListener('message', view.message);
        document.addEventListener('keydown', view.key, true);
        for (const type of ['mousedown','click','keydown']) panel.addEventListener(type, event => event.stopPropagation());
        retry.onclick = () => { if (view.ticket) { status.hidden = false; load(view, view.ticket); } };
        if (tickets.length > 1) {
            const select = document.createElement('select'); select.setAttribute('aria-label', 'Ticket MOICA2 relacionado');
            const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = 'Elegí el evento relacionado'; select.append(placeholder);
            for (const ticket of tickets) { const option = document.createElement('option'); option.value = ticket; option.textContent = ticket; select.append(option); }
            select.onchange = () => { if (select.value) { status.hidden = false; load(view, select.value); } };
            header.insertBefore(select, retry); status.textContent = 'Hay varios eventos relacionados. Elegí cuál consultar.';
        } else if (!tickets.length) {
            status.textContent = 'No se pudo obtener un Nro Evento válido. Revisá Eventos relacionados o consultá un número manualmente.';
            const form = document.createElement('form'), input = document.createElement('input'), search = document.createElement('button');
            input.setAttribute('aria-label', 'Número de ticket MOICA2'); input.placeholder = 'Número de ticket MOICA2'; input.required = true;
            search.type = 'submit'; search.textContent = 'Consultar'; form.append(input, search); panel.append(form);
            form.onsubmit = event => { event.preventDefault(); const ticket = input.value.trim().toUpperCase(); if (!validTicket(ticket)) { status.textContent = 'Revisá el formato del número de ticket.'; return; } status.hidden = false; load(view, ticket); };
        }
        document.body.append(panel); exit.focus({ preventScroll: true });
        if (tickets.length === 1) load(view, tickets[0]);
    }
    function contextNodes(context, sector) {
        const input = [...(context?.root.querySelectorAll('.v-text-field__slot > label') || [])]
            .find(label => label.textContent.trim() === 'Nodo')?.parentElement.querySelector('input[readonly]');
        const nodes = String(input?.value || '').toUpperCase().split('|').map(value => value.trim());
        if (!nodes.every(validNode)) return [];
        return [...new Set(sector === 'GEC' ? nodes.filter(node=>node !== 'VARIOS') : nodes)];
    }
    function contextNode(context) {
        const nodes = contextNodes(context);
        return nodes.length === 1 ? nodes[0] : '';
    }
    function searchNode(context) {
        const value = context?.root.querySelector('.viena-moica-nodo-action-btn')?.dataset.vienaMoicaNodo || '';
        return validNode(value) ? value : '';
    }
    function nodeContext(context, node) {
        const now = ticketContext();
        return now?.root === context.root && now.identity === context.identity && searchNode(now) === node;
    }
    function stopNodeAuto() {
        nodeAuto?.cleanup(); nodeAuto?.panel.remove(); nodeAuto = null;
    }
    function nodeFrame(node, token, visible = false) {
        const frame = document.createElement('iframe'); frame.title = 'MOICA · ' + node + ' · Buscar tickets'; frame.referrerPolicy = 'origin';
        if (!visible) { frame.hidden = true; frame.tabIndex = -1; frame.setAttribute('aria-hidden','true'); }
        const url = new URL('/buscarTicket.php',MOICA);
        url.searchParams.set('vienaNodeSearch',node); url.searchParams.set('vienaViewerSession',token);
        if (visible) url.searchParams.set('vienaNodeVisible','1');
        frame.src = url.href;
        return frame;
    }
    function openNodeSearch(node, focus) {
        const context = ticketContext();
        if (!context || !nodeContext(context,node)) return false;
        globalThis.VienaInfocallViewer?.close(); close(); style();
        const panel = document.createElement('section'); panel.id = 'viena-moica-viewer'; panel.setAttribute('role','dialog'); panel.setAttribute('aria-label','Buscar tickets en curso por nodo');
        const header = document.createElement('header'), title = document.createElement('strong'), exit = document.createElement('button'), retry = document.createElement('button');
        title.textContent = 'MOICA · ' + node + ' · Buscar tickets'; exit.type = retry.type = 'button'; exit.textContent = 'Cerrar'; retry.textContent = 'Recargar'; exit.onclick = () => close();
        const status = document.createElement('div'); status.className = 'viewer-status'; status.setAttribute('role','status');
        header.append(title,retry,exit); panel.append(header,status);
        const view = {kind:'node-search',node,context,focus,panel,status}; active = view;
        outsideOption(view,header);
        const run = () => {
            clearTimeout(view.timeout); view.frame?.remove();
            view.token = [...crypto.getRandomValues(new Uint8Array(16))].map(v=>v.toString(16).padStart(2,'0')).join('');
            view.frame = nodeFrame(node,view.token,true); panel.append(view.frame); status.textContent = 'Buscando tickets del nodo…';
            view.timeout = setTimeout(() => { status.textContent = 'MOICA2 no respondió a tiempo. Revisá la sesión y reintentá.'; },65000);
        };
        view.message = event => {
            if (event.origin !== MOICA || event.source !== view.frame?.contentWindow || event.data?.type !== 'VIENA_MOICA_NODE_RESULT' || event.data.token !== view.token || active !== view) return;
            if (!nodeContext(context,node)) { close(); return; }
            clearTimeout(view.timeout);
            status.textContent = event.data.ok ? event.data.count + ' tickets encontrados · Abierto, Completado, En Curso y Pausado.' : 'No se pudo completar la búsqueda. Revisá la sesión y reintentá.';
        };
        view.key = event => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); } };
        window.addEventListener('message',view.message); document.addEventListener('keydown',view.key,true);
        for (const type of ['mousedown','click','keydown']) panel.addEventListener(type,event=>event.stopPropagation());
        retry.onclick = run; document.body.append(panel); run(); exit.focus({preventScroll:true}); return true;
    }
    function markCurrentNodeTicket(state) {
        if (!nodeContext(state.context,state.node)) return;
        const related = new Set(ticketContext().tickets);
        const shown = state.shown || state.rows;
        const matches = shown.filter(row => related.has(row.number)).length;
        if (state.shown || state.rows.length) {
            const summary = state.panel.querySelector('summary');
            const text = 'MOICA · ' + state.node + ' · ' + shown.length + ' tickets · En Curso o con tarea de campo AGENDADA, INICIADA, ASIGNADA o SUSPENDIDA · EP con SRE activa; GIE en cualquier estado' + (matches ? ' · ' + matches + ' vinculado' + (matches === 1 ? '' : 's') + ' a VIENA' : '') + (state.verification ? ' · ' + state.verification : '');
            if (summary.textContent !== text) summary.textContent = text;
        }
        for (const item of state.panel.querySelectorAll('[data-node-ticket]')) {
            const current = related.has(item.dataset.nodeTicket);
            if (item.dataset.currentViena !== String(current)) item.dataset.currentViena = String(current);
            const badge = item.querySelector('.viena-node-current-badge');
            if (badge.hidden === current) badge.hidden = !current;
        }
    }
    function startNodeAuto(context, host) {
        const node = searchNode(context);
        if (nodeAuto && (!node || !nodeContext(nodeAuto.context,nodeAuto.node))) stopNodeAuto();
        if (!node || !host) return;
        host = globalThis.VienaTicketFields?.panelHost?.('moica',host) || host;
        if (nodeAuto) { if (nodeAuto.panel.parentElement !== host) host.append(nodeAuto.panel); markCurrentNodeTicket(nodeAuto); return; }
        const panel = document.createElement('details'); panel.className = 'viena-node-progress';
        panel.style.cssText = 'flex-basis:100%;width:100%;max-width:100%;box-sizing:border-box;border:1px solid #93baf0;border-radius:6px;padding:8px 12px;background:#e8f2ff;color:#173b64;font:13px/1.5 Arial';
        const summary = document.createElement('summary'); summary.style.cursor = 'pointer'; summary.textContent = 'MOICA · ' + node + ' · Buscando tickets…';
        const actions = document.createElement('div'), search = document.createElement('button'), retry = document.createElement('button'), list = document.createElement('div');
        search.type = retry.type = 'button'; search.textContent = 'Ver búsqueda en visor'; retry.textContent = 'Actualizar'; list.style.cssText = 'max-height:220px;overflow:auto;overflow-wrap:anywhere';
        actions.append(search,retry); panel.append(summary,actions,list); host.append(panel);
        const state = {context,node,panel,cleanup:()=>{},rows:[]}; nodeAuto = state;
        const valid = () => nodeAuto === state && nodeContext(context,node);
        search.onclick = event => { event.preventDefault(); event.stopPropagation(); if (valid()) openNodeSearch(node,search); };
        const run = () => {
            state.cleanup(); if (!valid()) return;
            state.rows = []; state.shown = null; state.reviewed = 0; state.verification = ''; list.replaceChildren(); retry.disabled = true;
            summary.textContent = 'MOICA · ' + node + ' · Buscando tickets…';
            const token = [...crypto.getRandomValues(new Uint8Array(16))].map(v=>v.toString(16).padStart(2,'0')).join('');
            const frame = nodeFrame(node,token), items = new Map(); let timer, received = false, incomplete = false;
            const cleanup = () => { clearTimeout(timer); window.removeEventListener('message',receive); frame.remove(); retry.disabled = false; };
            state.cleanup = cleanup;
            const finishTasks = () => {
                for (const item of items.values()) {
                    const field = item.querySelector('[data-field-pending]');
                    if (field) { incomplete = true; field.textContent = 'Tareas de campo: sin información confirmada en esta consulta'; delete field.dataset.fieldPending; }
                }
                state.verification = (incomplete ? 'Revisión parcial' : 'Revisión finalizada') + ' · ' + state.reviewed + '/' + state.rows.length + ' tickets revisados' + (incomplete ? ' · Información parcial de tareas de campo' : '');
                markCurrentNodeTicket(state); cleanup();
            };
            const failed = () => { if (received) { finishTasks(); return; } cleanup(); if (valid()) { summary.textContent = 'MOICA · ' + node + ' · No se pudo completar la búsqueda. Abrí la búsqueda o reintentá.'; panel.open = true; } };
            function receive(event) {
                if (!valid() || event.origin !== MOICA || event.source !== frame.contentWindow || !['VIENA_MOICA_NODE_RESULT','VIENA_MOICA_NODE_TASKS'].includes(event.data?.type) || event.data.token !== token) return;
                const data = event.data;
                if (data.type === 'VIENA_MOICA_NODE_TASKS') {
                    if (!received) return;
                    if (data.done) { finishTasks(); return; }
                    const item = items.get(data.ticket), field = item?.querySelector('.viena-node-field');
                    if (!field?.hasAttribute('data-field-pending')) return;
                    if (!data.ok || !Array.isArray(data.tasks) || !Number.isFinite(data.at) || data.at > Date.now()+1000 || data.tasks.some(task=>typeof task.number !== 'string' || !task.number || !nodeTaskState(task)) || new Set(data.tasks.map(task=>task.number)).size !== data.tasks.length) {
                        incomplete = true; field.textContent = 'Tareas de campo: sin información confirmada en esta consulta';
                    } else {
                        field.textContent = data.tasks.some(task=>gieTask(task.number) || sreTask(task.number)) ? 'Tareas: ' : 'Campo: ';
                        if (!data.tasks.length) field.append('Sin tareas de campo');
                        data.tasks.forEach((task,index) => {
                            if (index) field.append(' | ');
                            const label = document.createElement('span'), badge = document.createElement('span');
                            label.className = 'viena-node-field-task'; label.textContent = task.number + ' · ';
                            badge.className = 'viena-node-field-state'; badge.dataset.state = task.state; badge.textContent = task.state || 'Estado no informado';
                            label.append(badge);
                            if (['INICIADA','ASIGNADA','AGENDADA'].includes(task.state)) {
                                const taskLabel = gieTask(task.number) || sreTask(task.number) ? 'tarea' : 'tarea de campo';
                                const message = alarmFollowupMessage(node,data.ticket,task.number,task.state,taskLabel);
                                const copy = taskMessageButton(message,'viena-node-copy-message');
                                copy.setAttribute('aria-label','Copiar mensaje de la tarea ' + task.number);
                                label.append(' ',copy);
                            }
                            field.append(label);
                        });
                        field.append(' · Fuente: ' + (data.taskSource === 'list' ? 'Listado MOICA' : 'Tareas MOICA') + ' · Consulta ' + new Date(data.at).toLocaleTimeString('es-AR'));
                        const row = state.rows.find(row=>row.number === data.ticket);
                        if (row && !state.shown.includes(row) && nodeTicketVisible(row,data.tasks)) {
                            list.append(item); state.shown.push(row); panel.open = true;
                            if (data.tasks.some(task=>task.state === 'INICIADA') && row.state !== 'En Curso') { const warning = document.createElement('strong'); warning.style.display = 'block'; warning.textContent = 'Campo iniciado; el ticket conserva su estado informado. Revisar sincronización.'; field.append(warning); }
                        }
                    }
                    delete field.dataset.fieldPending; state.reviewed++;
                    state.verification = 'Verificando campo · ' + state.reviewed + '/' + state.rows.length + ' tickets revisados…' + (incomplete ? ' · Información parcial de tareas de campo' : '');
                    markCurrentNodeTicket(state); return;
                }
                if (received) return;
                if (!data.ok || !Array.isArray(data.rows) || data.rows.length !== data.count || data.rows.some(row=>!validTicket(row.number) || !activeNodeStates.includes(row.state)) || new Set(data.rows.map(row=>row.number)).size !== data.rows.length) { failed(); return; }
                received = true; state.rows = data.rows;
                state.shown = data.rows.filter(row=>nodeTicketVisible(row)); state.verification = 'Verificando campo · 0/' + data.count + ' tickets revisados…';
                panel.open = data.count > 0;
                for (const row of state.rows) {
                    const item = document.createElement('div'), label = document.createElement('span'), action = document.createElement('button');
                    item.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:6px 0;border-top:1px solid #bbd0e1';
                    label.style.cssText = 'flex:1;min-width:140px'; label.textContent = [row.number,row.subject,row.queue].filter(Boolean).join(' · ');
                    const problem = document.createElement('span'); problem.className = 'viena-node-problem'; problem.style.display = 'block';
                    problem.textContent = 'Problema: ' + (typeof row.problem === 'string' && row.problem.trim() ? row.problem.trim() : 'No informado'); label.append(problem);
                    const ticketState = document.createElement('span'); ticketState.style.display = 'block'; ticketState.textContent = 'Ticket MOICA: ' + row.state; label.append(ticketState);
                    const field = document.createElement('span'); field.className = 'viena-node-field'; field.style.display = 'block'; field.dataset.fieldPending = 'true'; field.textContent = 'Campo: verificando tareas…'; label.append(field);
                    item.dataset.nodeTicket = row.number;
                    const badge = document.createElement('span'); badge.className = 'viena-node-current-badge'; badge.textContent = 'Vinculado al ticket abierto en VIENA'; badge.hidden = true; label.append(badge);
                    action.type = 'button'; action.textContent = 'Ver ticket'; action.setAttribute('aria-label','Ver ticket ' + row.number);
                    action.onclick = event => { event.preventDefault(); event.stopPropagation(); if (valid() && state.rows.includes(row)) open(ticketContext(),action,row.number); };
                    item.append(label,action); items.set(row.number,item); if (state.shown.includes(row)) list.append(item);
                }
                markCurrentNodeTicket(state);
            }
            window.addEventListener('message',receive); timer = setTimeout(failed,65000); document.body.append(frame);
        };
        retry.onclick = event => { event.preventDefault(); event.stopPropagation(); run(); };
        run();
    }
    function chooseGee(context, focus, host, sector = 'GEE') {
        globalThis.VienaInfocallViewer?.close();
        close(); style();
        const nodes = contextNodes(context,sector);
        const panel = document.createElement('section'); panel.id = 'viena-moica-viewer';
        panel.className = 'viena-gee-node-choice';
        panel.setAttribute('role','dialog'); panel.setAttribute('aria-modal','true'); panel.setAttribute('aria-label','Elegir nodo para Ver ' + sector);
        const header = document.createElement('header'), title = document.createElement('strong'); title.textContent = 'Ver ' + sector;
        const exit = document.createElement('button'); exit.type = 'button'; exit.textContent = 'Cerrar'; exit.onclick = close;
        header.append(title,exit);
        const status = document.createElement('div'); status.className = 'viewer-status'; status.textContent = 'Seleccioná el nodo que querés consultar en ' + sector + '.';
        const options = document.createElement('div'); options.className = 'gee-node-options'; options.setAttribute('role','group'); options.setAttribute('aria-label','Nodo para consultar ' + sector);
        const view = { kind:'gee-choice', context, focus, panel, nodes, sector };
        view.key = event => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); } };
        for (const node of nodes) {
            const action = document.createElement('button'); action.type = 'button'; action.dataset.geeNode = node;
            const name = document.createElement('strong'), hint = document.createElement('span'); name.textContent = node; hint.textContent = 'Consultar ' + sector; action.append(name,hint);
            action.onclick = event => {
                event.preventDefault(); event.stopPropagation();
                if (active !== view || !sameContext(view) || JSON.stringify(contextNodes(ticketContext(),sector)) !== JSON.stringify(nodes)) { close(); return; }
                close(); void queryGee(context,node,focus,host,sector);
            };
            options.append(action);
        }
        panel.append(header,status,options);
        active = view; outsideOption(view,header); document.addEventListener('keydown',view.key,true);
        document.body.append(panel); options.querySelector('button')?.focus({preventScroll:true});
    }
    function validGedDetails(details) {
        return Array.isArray(details) && JSON.stringify(details).length <= 100000 && details.every(item => item && validNode(item.node) && ['Directa','Retorno'].includes(item.group) && validTicket(item.number) && ['problem','state','created'].every(key => typeof item[key] === 'string' && item[key].length <= 10000) && Array.isArray(item.cmts) && item.cmts.every(validNode) && validGedTasks(item));
    }
    function validGedTasks(item) {
        return item.fieldTasksState === undefined && item.fieldTasks === undefined || ['pending','complete','unavailable'].includes(item.fieldTasksState) && Array.isArray(item.fieldTasks) && item.fieldTasks.every(task=>task && typeof task.number === 'string' && task.number.trim() && task.number.length <= 200 && ['AGENDADA','ASIGNADA','INICIADA','EN CURSO','EN VIAJE'].includes(task.state)) && new Set(item.fieldTasks.map(task=>task.number)).size === item.fieldTasks.length;
    }
    function markCurrentGedTicket(status) {
        const context = ticketContext();
        if (!context) return;
        const marker = status.dataset.gedContext;
        if (marker ? marker !== JSON.stringify([context.identity,JSON.stringify(contextNodes(context))]) : active?.kind !== 'gee' || active.sector !== 'GED' || active.context.root !== context.root || active.context.identity !== context.identity || !active.panel.contains(status)) return;
        const related = new Set(context.tickets);
        for (const card of status.querySelectorAll('[data-ged-ticket]')) {
            const current = related.has(card.dataset.gedTicket.toUpperCase());
            if (card.dataset.currentViena !== String(current)) card.dataset.currentViena = String(current);
            const badge = card.querySelector('.ged-ticket-current');
            if (badge && badge.hidden === current) badge.hidden = !current;
        }
    }
    function highlightGedReport(status, analysis, details) {
        const usable = validGedDetails(details), signature = usable ? JSON.stringify(details) : '';
        const prefix = status.className.includes('viewer-status') ? status.textContent.match(/^GED filtrado por [A-Z0-9._-]+/)?.[0] : '';
        if (status.__vienaAnalysis === analysis && status.__vienaGedSignature === signature) { markCurrentGedTicket(status); return; }
        status.__vienaAnalysis = analysis;
        status.__vienaGedSignature = signature;
        status.classList.add('viena-ged-report');
        status.dataset.details = String(usable);
        status.textContent = prefix ? prefix + ' · ' + analysis : analysis;
        status.dataset.state = analysis.startsWith('Análisis parcial') ? 'partial' : [...analysis.matchAll(/(?:Directa|Retorno): (\d+) tickets?/g)].some(match => Number(match[1]) > 1) ? 'matches' : 'info';
        if (usable) {
            status.replaceChildren();
            const heading = document.createElement('strong'); heading.className = 'ged-heading';
            const count = new Set(details.map(item=>item.node + ':' + item.number)).size;
            const scanned = [...analysis.matchAll(/(\d+) filas revisadas/g)].reduce((sum,match)=>sum+Number(match[1]),0);
            heading.textContent = (prefix ? prefix + ' · ' : '') + (analysis.match(/^Análisis (?:completo|parcial) de \d+ nodos/)?.[0] || (analysis.startsWith('Análisis parcial') ? 'Análisis parcial' : 'Análisis completo')) + ' · ' + count + ' ticket' + (count === 1 ? '' : 's') + ' encontrado' + (count === 1 ? '' : 's');
            const summary = document.createElement('div'); summary.className = 'ged-overview';
            const ongoing = new Set(details.filter(item=>item.state.trim().toLowerCase() === 'en curso').map(item=>item.node + ':' + item.number)).size;
            summary.textContent = scanned + ' filas revisadas · ' + ongoing + ' ticket' + (ongoing === 1 ? '' : 's') + ' En Curso';
            const reportHeader = document.createElement('div'); reportHeader.className = 'ged-report-heading'; reportHeader.append(heading,summary); status.append(reportHeader);
            if (/parcial|no se pudo/i.test(analysis)) {
                const warning = document.createElement('div'); warning.className = 'ged-warning';
                warning.textContent = analysis.split('\n\n')[0]; status.append(warning);
            }
            const nodes = [...new Set(details.map(item=>item.node))];
            for (const node of nodes.length ? nodes : ['']) for (const group of ['Directa','Retorno']) {
                const rows = details.filter(item=>item.node === node && item.group === group);
                if (group === 'Retorno' && !rows.length) continue;
                const section = document.createElement('section'); section.className = 'ged-group'; section.dataset.group = group;
                const title = document.createElement('strong'); title.className = 'ged-group-title';
                title.textContent = group + ' · ' + rows.length + ' ticket' + (rows.length === 1 ? '' : 's') + (nodes.length > 1 ? ' · Nodo ' + node : ''); section.append(title);
                if (!rows.length) { const empty = document.createElement('div'); empty.className = 'ged-empty'; empty.textContent = 'Sin tickets coincidentes'; section.append(empty); }
                const byCmts = new Map();
                for (const row of rows) { const key = [...row.cmts].sort().join(' / '); if (!byCmts.has(key)) byCmts.set(key,[]); byCmts.get(key).push(row); }
                for (const [cmts,tickets] of byCmts) {
                    const label = document.createElement('div'); label.className = 'ged-cmts';
                    label.textContent = (tickets.length > 1 ? 'Mismo Nodo CMTS ' : 'Nodo CMTS ') + (cmts || 'sin informar') + ': ' + tickets.length + ' ticket' + (tickets.length === 1 ? '' : 's'); section.append(label);
                    for (const row of tickets) {
                        const card = document.createElement('article'); card.className = 'ged-ticket'; card.dataset.gedTicket = row.number;
                        const header = document.createElement('div'); header.className = 'ged-ticket-header';
                        const number = document.createElement('strong'); number.className = 'ged-ticket-number'; number.textContent = row.number;
                        const state = document.createElement('span'); state.className = 'ged-ticket-state'; state.textContent = row.state || 'Estado no informado';
                        if (row.state.trim().toLowerCase() === 'en curso') { card.dataset.inProgress = 'true'; state.dataset.inProgress = 'true'; }
                        const created = document.createElement('span'); created.className = 'ged-ticket-created'; created.textContent = 'Creado: ' + (row.created || 'No informado');
                        const problem = document.createElement('div'); problem.className = 'ged-ticket-problem'; problem.textContent = 'Problema: ' + (row.problem || 'No informado');
                        const current = document.createElement('span'); current.className = 'ged-ticket-current'; current.textContent = 'Vinculado al ticket abierto en VIENA'; current.hidden = true;
                        header.append(number,state,created); card.append(header,problem);
                        if (row.fieldTasksState !== undefined && (row.fieldTasksState !== 'complete' || row.fieldTasks.length)) {
                            const fields = document.createElement('div'); fields.className = 'ged-field-tasks';
                            if (row.fieldTasksState === 'complete') for (const task of row.fieldTasks) {
                                const line = document.createElement('div'); line.className = 'ged-field-task'; line.dataset.state = task.state;
                                line.textContent = 'Tarea de campo ' + task.state + ' → ' + task.number; fields.append(line);
                            } else {
                                fields.className += ' ged-field-unverified'; fields.textContent = row.fieldTasksState === 'pending' ? 'Tareas de campo: verificando…' : 'Tareas de campo: sin información confirmada en esta consulta';
                            }
                            card.append(fields);
                        }
                        card.append(current); section.append(card);
                    }
                }
                status.append(section);
            }
            markCurrentGedTicket(status); return;
        }
        status.textContent = status.textContent.replace(/(?: · | — )(?=(?:Nodo CMTS |Mismo Nodo CMTS |Nodos CMTS [A-Z0-9]|Mismos Nodos CMTS |Retorno:))/g,'\n');
    }
    function analysisSession(sector, context, analysis, gedDetails) {
        if (!['GEC','GED','GEE'].includes(sector)) return null;
        const storageKey = 'viena_moica_analysis_session_v1:' + sector;
        try {
            if (analysis === null) { sessionStorage.removeItem(storageKey); return null; }
            const user = String(globalThis.VienaUserConfig?.detectar?.() || globalThis.VienaUserConfig?.current || '').trim().toLowerCase();
            if (!/^[a-z][a-z0-9._-]{2,30}$/.test(user)) return null;
            const nodes = contextNodes(context,sector);
            const binding = JSON.stringify(sector === 'GEC' ? [user,context.identity,nodes,'Nodo'] : [user,context.identity,nodes]);
            const complete = text => typeof text === 'string' && text.length <= 100000 && /^(?:Análisis completo|Revisión completa|Tareas de campo · Revisión completa)/.test(text) && !/parcial|no se pudo/i.test(text);
            if (analysis !== undefined) {
                if (!complete(analysis)) { sessionStorage.removeItem(storageKey); return null; }
                const entry = {binding,at:Date.now(),analysis,...(sector === 'GED' && gedDetails !== undefined && validGedDetails(gedDetails) ? {gedDetails} : {})}; sessionStorage.setItem(storageKey,JSON.stringify(entry)); return entry;
            }
            const entry = JSON.parse(sessionStorage.getItem(storageKey) || 'null');
            return entry && entry.binding === binding && Number.isFinite(entry.at) && Date.now()-entry.at >= 0 && Date.now()-entry.at < 120000 && complete(entry.analysis) ? entry : null;
        } catch (_) { return null; }
    }
    function reportFreshness(status, sector, context, at, reused = false) {
        const existing = status.querySelector('.viena-analysis-freshness');
        if (existing && existing.dataset.at === String(at) && existing.dataset.reused === String(reused) && !existing.querySelector('button')?.disabled) return;
        existing?.remove();
        const footer = document.createElement('div'); footer.className = 'viena-analysis-freshness';
        footer.dataset.at = String(at); footer.dataset.reused = String(reused);
        footer.style.cssText = 'display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:8px;font:12px/1.5 Arial;white-space:normal';
        const stamp = document.createElement('span'); stamp.textContent = 'Consulta ' + new Date(at).toLocaleTimeString('es-AR') + (reused ? ' · Resultado conservado (máximo 2 min)' : '');
        const update = document.createElement('button'); update.type = 'button'; update.textContent = 'Actualizar'; update.style.cssText = 'padding:3px 9px;border:1px solid #94a3b8;border-radius:5px;background:transparent;color:inherit;font:inherit;cursor:pointer';
        update.onclick = event => {
            event.preventDefault(); event.stopPropagation();
            const now = ticketContext();
            if (now?.root !== context.root || now.identity !== context.identity || JSON.stringify(contextNodes(now,sector)) !== JSON.stringify(contextNodes(context,sector))) return;
            analysisSession(sector,context,null);
            update.disabled = true; update.textContent = 'Actualizando…'; status.dataset.refreshing = 'true';
            if (sector === 'GEC') { stopGecAuto(); gecAuto = null; } else if (sector === 'GEE') { stopGecAuto('GEE'); geeAuto = null; } else { stopGedAuto(); gedAuto = null; }
            refresh();
        };
        footer.append(stamp,update); status.append(footer);
    }
    function paintGecReport(status, analysis, sector = 'GEC') {
        status.__vienaAnalysis = analysis;
        status.classList.add('viena-gec-report');
        status.dataset.state = /parcial|no se pudo/i.test(analysis) ? 'partial' : analysis.startsWith('Analizando') ? 'loading' : 'complete';
        status.replaceChildren();
        const heading = document.createElement('strong'); heading.className = 'gec-heading'; heading.textContent = 'Tareas de campo · ' + sector;
        const summary = document.createElement('span'); summary.className = 'gec-summary';
        const lines = analysis.split('\n'); summary.textContent = lines.shift().replace(/^Tareas de campo · /,'');
        const tasks = document.createElement('div'); tasks.className = 'gec-tasks';
        const shownTasks = new Set();
        let node = '';
        try { const nodes = JSON.parse(JSON.parse(status.dataset[sector === 'GEE' ? 'geeContext' : 'gecContext'])[1]); if (nodes.length === 1) node = nodes[0]; } catch (_) {}
        for (const line of lines.filter(Boolean)) {
            if (/^Nodo /.test(line) || line.startsWith('Tareas de campo · ')) {
                if (line.startsWith('Nodo ')) node = line.slice(5).trim();
                const meta = document.createElement('span'); meta.className = 'gec-summary'; meta.style.display = 'block'; meta.textContent = line.replace(/^Tareas de campo · /,''); tasks.append(meta); continue;
            }
            const match = line.match(/^(Ticket .+ · Campo .+) · (ASIGNADA|AGENDADA|INICIADA|EN CURSO|EN VIAJE|SUSPENDIDA|PENDIENTE AGENDAMIENTO)$/);
            const reference = match?.[1].match(/^Ticket (\S+) · Campo (\S+)(?: · CMTS: (.+))?$/);
            if (sector === 'GEC' && reference) {
                const identity = JSON.stringify([reference[1],reference[2]]);
                if (shownTasks.has(identity)) continue;
                shownTasks.add(identity);
            }
            const row = document.createElement('div'); row.className = 'gec-task';
            const label = document.createElement('span'); label.className = 'gec-task-label'; label.textContent = reference ? 'Ticket ' + reference[1] + ' · Campo ' + reference[2] : match ? match[1] : line;
            if (reference) { const cmts = document.createElement('span'); cmts.className = 'gec-summary'; cmts.style.display = 'block'; cmts.textContent = 'Nodo CMTS: ' + (reference[3] || 'No informado'); label.append(cmts); }
            row.append(label);
            if (match) { const badge = document.createElement('span'); badge.className = 'gec-state'; badge.dataset.state = match[2]; badge.textContent = match[2]; row.append(badge); }
            if (sector === 'GEC' && node && reference && ['ASIGNADA','AGENDADA','INICIADA','EN VIAJE'].includes(match[2])) {
                const message = alarmFollowupMessage(node,reference[1],reference[2],match[2]);
                row.append(taskMessageButton(message,'gec-copy-message'));
            }
            tasks.append(row);
        }
        status.append(heading,summary); if (tasks.childElementCount) status.append(tasks);
    }
    function alarmFollowupMessage(node, ticket, task, state, taskLabel = 'tarea de campo') {
        return 'Se completa la presente alarma del nodo ' + node + ', cuya gestión continúa en el ticket ' + ticket + ' con la ' + taskLabel + ' ' + task + ' en estado ' + state + '. Se mantiene el seguimiento en dicho ticket.';
    }
    function taskMessageButton(message, className) {
        const copy = document.createElement('button'); copy.type = 'button'; copy.className = className; copy.textContent = 'Copiar mensaje'; copy.title = message;
        copy.style.cssText = 'padding:4px 9px;border:1px solid #94a3b8;border-radius:5px;background:transparent;color:inherit;font:inherit;cursor:pointer;max-width:100%;white-space:normal';
        copy.onclick = async event => {
            event.preventDefault(); event.stopPropagation(); if (copy.dataset.copying) return;
            copy.dataset.copying = 'true'; copy.textContent = 'Copiando…';
            try { copy.textContent = await copyGecMessage(message) ? 'Copiado' : 'Reintentar copia'; }
            catch (_) { copy.textContent = 'Reintentar copia'; }
            finally { delete copy.dataset.copying; }
        };
        return copy;
    }
    async function copyGecMessage(text) {
        let timeout;
        try {
            if (navigator.clipboard && window.isSecureContext) {
                await Promise.race([navigator.clipboard.writeText(text),new Promise((_, reject) => { timeout = setTimeout(() => reject(new Error('clipboard timeout')),3000); })]);
                return true;
            }
        } catch (_) {} finally { clearTimeout(timeout); }
        const focus = document.activeElement, selection = window.getSelection();
        const ranges = selection ? Array.from({length:selection.rangeCount},(_, i) => selection.getRangeAt(i).cloneRange()) : [];
        const textarea = document.createElement('textarea'); textarea.value = text; textarea.readOnly = true;
        textarea.style.cssText = 'position:fixed;left:-9999px;top:-9999px;opacity:0'; document.body.append(textarea);
        try { textarea.select(); return document.execCommand('copy'); }
        catch (_) { return false; }
        finally { textarea.remove(); focus?.focus?.({preventScroll:true}); if (selection) { selection.removeAllRanges(); ranges.forEach(range => selection.addRange(range)); } }
    }
    function stopGecAuto(sector = 'GEC') {
        const state = sector === 'GEE' ? geeAuto : gecAuto;
        if (!state) return;
        state.running = false; state.cleanup?.();
    }
    function startGecAuto(context, host, sector = 'GEC') {
        const nodes = contextNodes(context,sector), key = JSON.stringify(nodes);
        const task = sector === 'GEE' ? geeTask : gecTask, auto = sector === 'GEE' ? geeAuto : gecAuto;
        const contextKey = sector === 'GEE' ? 'geeContext' : 'gecContext';
        if (!host || !task(context) || !nodes.length) return;
        host = globalThis.VienaTicketFields?.panelHost?.(sector.toLowerCase(),host) || host;
        if (auto?.context.root === context.root && auto.context.identity === context.identity && auto.key === key) {
            if (!auto.suppressed && auto.status.parentElement !== host) host.append(auto.status);
            return;
        }
        stopGecAuto(sector);
        const frame = document.createElement('iframe'); frame.hidden = true; frame.setAttribute('aria-hidden','true'); frame.tabIndex = -1; frame.title = 'Campo ' + sector + ' en segundo plano'; frame.referrerPolicy = 'origin';
        const marker = JSON.stringify([context.identity,key]), previous = context.root.querySelector?.('[data-' + sector.toLowerCase() + '-context]');
        const status = previous?.dataset[contextKey] === marker ? previous : document.createElement('section');
        if (status !== previous) { status.className = 'viena-moica-gee-status'; status.setAttribute('role','status'); status.dataset[contextKey] = marker; }
        if (status.parentElement !== host) host.append(status);
        const state = {context,key,status,running:true,cleanup:null}, results = []; if (sector === 'GEE') geeAuto = state; else gecAuto = state;
        const cached = analysisSession(sector,context);
        if (cached) { state.running = false; if (status.__vienaAnalysis !== cached.analysis) paintGecReport(status,cached.analysis,sector); reportFreshness(status,sector,context,cached.at,true); return; }
        const token = [...crypto.getRandomValues(new Uint8Array(16))].map(v=>v.toString(16).padStart(2,'0')).join('');
        let index = 0, pending = false, pingTimer, deadline, progressAnalysis = '';
        const valid = () => { const now = ticketContext(); return (sector === 'GEE' ? geeAuto : gecAuto) === state && state.running && now?.root === context.root && now.identity === context.identity && task(now) && JSON.stringify(contextNodes(now,sector)) === key; };
        const cleanup = () => { clearTimeout(pingTimer); clearTimeout(deadline); frame.onload = null; window.removeEventListener('message',receive); frame.remove(); };
        state.cleanup = cleanup;
        const finish = analysis => { if (valid()) { if (status.__vienaAnalysis !== analysis) paintGecReport(status,analysis,sector); delete status.dataset.refreshing; const saved = analysisSession(sector,context,analysis); reportFreshness(status,sector,context,saved?.at || Date.now()); } state.running = false; cleanup(); };
        const ping = () => {
            if (!valid()) { state.running = false; cleanup(); return; }
            frame.contentWindow?.postMessage({type:'VIENA_MOICA_GEE_VIEWER_PING',token},MOICA);
            clearTimeout(pingTimer); pingTimer = setTimeout(ping,250);
        };
        function receive(event) {
            if (!valid() || event.origin !== MOICA || event.source !== frame.contentWindow || event.data?.type !== 'VIENA_MOICA_GEE_VIEWER_STATE' || event.data.token !== token) return;
            if (event.data.state === 'ready' && !pending) {
                clearTimeout(pingTimer); pending = true;
                if (!status.__vienaAnalysis) paintGecReport(status,'Analizando campo · Nodo ' + nodes[index] + ' (' + (index+1) + '/' + nodes.length + ')…',sector);
                frame.contentWindow.postMessage({type:sector === 'GEE' ? 'VIENA_MOICA_GEE_AUTO_RUN' : 'VIENA_MOICA_GEC_AUTO_RUN',token,nodo:nodes[index]},MOICA);
            } else if (event.data.state === 'field-progress' && pending) {
                const result = event.data.result;
                if (!result?.ok || result.nodo !== nodes[index] || typeof result.analysis !== 'string' || !result.analysis.startsWith('Analizando')) return;
                progressAnalysis = 'Nodo ' + nodes[index] + '\n' + result.analysis;
                if (status.dataset.refreshing === 'true') {
                    const update = status.querySelector('.viena-analysis-freshness button');
                    if (update) update.textContent = result.analysis.split('\n')[0];
                    return;
                }
                paintGecReport(status,'Analizando campo · ' + (index+1) + '/' + nodes.length + ' nodos\n' + [...results,progressAnalysis].join('\n'),sector);
            } else if (event.data.state === 'result') {
                pending = false; const result = event.data.result;
                if (result?.phase) { clearTimeout(pingTimer); pingTimer = setTimeout(ping,250); return; }
                if (!result?.ok || typeof result.analysis !== 'string') { finish('Revisión parcial · ' + (result?.mensaje || 'No se pudo consultar campo. Reintentá con Ver ' + sector + '.') + (results.length || progressAnalysis ? '\n' + [...results,progressAnalysis].filter(Boolean).join('\n') : '')); return; }
                progressAnalysis = ''; results.push('Nodo ' + nodes[index] + '\n' + result.analysis); index++;
                if (index < nodes.length) { ping(); return; }
                finish((results.some(value=>value.includes('Revisión parcial')) ? 'Revisión parcial' : 'Revisión completa') + ' · ' + nodes.length + ' nodo' + (nodes.length === 1 ? '' : 's') + '\n' + results.join('\n'));
            }
        }
        window.addEventListener('message',receive);
        deadline = setTimeout(()=>finish('Revisión parcial · MOICA2 no respondió a tiempo. Reintentá con Ver ' + sector + '.' + (results.length || progressAnalysis ? '\n' + [...results,progressAnalysis].filter(Boolean).join('\n') : '')),90000);
        frame.onload = () => { pending = false; ping(); };
        if (!status.__vienaAnalysis) paintGecReport(status,'Analizando campo en segundo plano…',sector); document.body.append(frame); frame.src = MOICA + '/home.php#';
    }
    function stopGedAuto() {
        if (!gedAuto) return;
        gedAuto.running = false; gedAuto.cleanup?.();
    }
    function startGedAuto(context, host) {
        const nodes = contextNodes(context), key = JSON.stringify(nodes);
        if (!host || !gedTask(context) || !nodes.length) return;
        host = globalThis.VienaTicketFields?.panelHost?.('ged',host) || host;
        if (gedAuto?.context.root === context.root && gedAuto.context.identity === context.identity && gedAuto.key === key) {
            if (!gedAuto.suppressed && gedAuto.status.parentElement !== host) host.append(gedAuto.status);
            return;
        }
        stopGedAuto();
        const frame = document.createElement('iframe'); frame.hidden = true; frame.setAttribute('aria-hidden','true'); frame.tabIndex = -1; frame.title = 'Análisis GED en segundo plano'; frame.referrerPolicy = 'origin';
        const marker = JSON.stringify([context.identity,key]), previous = context.root.querySelector?.('[data-ged-context]');
        const status = previous?.dataset.gedContext === marker ? previous : document.createElement('span');
        if (status !== previous) { status.className = 'viena-moica-gee-status'; status.setAttribute('role','status'); status.style.cssText = 'flex-basis:100%'; status.dataset.gedContext = marker; }
        if (status.parentElement !== host) host.append(status);
        const state = {context,key,status,running:true,cleanup:null}, results = [], gedDetails = [];
        let detailsComplete = true;
        gedAuto = state;
        const cached = analysisSession('GED',context);
        if (cached) { state.running = false; highlightGedReport(status,cached.analysis,cached.gedDetails); reportFreshness(status,'GED',context,cached.at,true); return; }
        const token = [...crypto.getRandomValues(new Uint8Array(16))].map(v=>v.toString(16).padStart(2,'0')).join('');
        let index = 0, pending = false, pingTimer, deadline;
        const valid = () => {
            const now = ticketContext();
            // Related events load lazily; GED belongs to this task/node, not that list.
            return gedAuto === state && state.running && now?.root === context.root && now.identity === context.identity && gedTask(now) && JSON.stringify(contextNodes(now)) === key;
        };
        const cleanup = () => { clearTimeout(pingTimer); clearTimeout(deadline); frame.onload = null; window.removeEventListener('message',receive); frame.remove(); };
        state.cleanup = cleanup;
        const paint = (analysis,details) => { if (status.__vienaAnalysis && analysis.startsWith('Analizando')) return; highlightGedReport(status,analysis,details); };
        const finish = analysis => { if (!valid()) { state.running = false; cleanup(); return; } const details = detailsComplete && results.length ? gedDetails : undefined; paint(analysis,details); delete status.dataset.refreshing; const saved = analysisSession('GED',context,analysis,details); reportFreshness(status,'GED',context,saved?.at || Date.now()); state.running = false; cleanup(); };
        const ping = () => {
            if (!valid()) { state.running = false; cleanup(); return; }
            frame.contentWindow?.postMessage({type:'VIENA_MOICA_GEE_VIEWER_PING',token},MOICA);
            clearTimeout(pingTimer); pingTimer = setTimeout(ping,250);
        };
        function receive(event) {
            if (!valid() || event.origin !== MOICA || event.source !== frame.contentWindow || event.data?.type !== 'VIENA_MOICA_GEE_VIEWER_STATE' || event.data.token !== token) return;
            if (event.data.state === 'ready' && !pending) {
                clearTimeout(pingTimer); pending = true;
                paint('Analizando GED · Nodo ' + nodes[index] + ' (' + (index + 1) + '/' + nodes.length + ')…');
                frame.contentWindow.postMessage({type:'VIENA_MOICA_GED_AUTO_RUN',token,nodo:nodes[index]},MOICA);
            } else if (event.data.state === 'ged-progress' && pending) {
                const result = event.data.result;
                if (detailsComplete && result?.ok && result.nodo === nodes[index] && typeof result.analysis === 'string' && validGedDetails(result.gedDetails) && result.gedDetails.every(item=>item.node === nodes[index])) {
                    const parts = [...results,nodes.length > 1 ? 'Nodo ' + nodes[index] + '\n' + result.analysis : result.analysis];
                    paint((nodes.length > 1 ? (parts.some(value=>value.includes('Análisis parcial')) ? 'Análisis parcial' : 'Análisis completo') + ' de ' + nodes.length + ' nodos\n\n' : '') + parts.join('\n\n'),[...gedDetails,...result.gedDetails]);
                }
            } else if (event.data.state === 'result') {
                pending = false;
                const result = event.data.result;
                if (result?.phase) { clearTimeout(pingTimer); pingTimer = setTimeout(ping,250); return; }
                if (!result?.ok || typeof result.analysis !== 'string') {
                    finish('Análisis parcial · ' + (result?.mensaje || 'No se pudo consultar GED. Revisá la sesión de MOICA2 y reintentá con Ver GED.') + (results.length ? '\n\n' + results.join('\n\n') : '')); return;
                }
                if (validGedDetails(result.gedDetails) && result.gedDetails.every(item=>item.node === nodes[index])) gedDetails.push(...result.gedDetails);
                else detailsComplete = false;
                results.push(nodes.length > 1 ? 'Nodo ' + nodes[index] + '\n' + result.analysis : result.analysis);
                index++;
                if (index < nodes.length) { ping(); return; }
                finish((nodes.length > 1 ? (results.some(value=>value.includes('Análisis parcial')) ? 'Análisis parcial' : 'Análisis completo') + ' de ' + nodes.length + ' nodos\n\n' : '') + results.join('\n\n'));
            }
        }
        window.addEventListener('message',receive);
        deadline = setTimeout(() => finish('Análisis parcial · MOICA2 no respondió a tiempo. Revisá su sesión y reintentá con Ver GED.' + (results.length ? '\n\n' + results.join('\n\n') : '')),90000);
        frame.onload = () => { pending = false; ping(); };
        paint('Analizando GED en segundo plano…');
        document.body.append(frame); frame.src = MOICA + '/home.php#';
    }
    async function queryGee(now, nodo, clicked, host, sector = 'GEE') {
        if (geeBusy || !sameContext({context:now}) || !contextNodes(ticketContext(),sector).includes(nodo) || (sector === 'GED' ? !gedTask(now) : sector === 'GEC' ? !gecTask(now) : !geeTask(now))) return;
        const cached = (sector === 'GEC' || sector === 'GED') ? analysisSession(sector,now) : null;
        if (cached && active?.kind === 'gee' && active.sector === sector && active.nodo === nodo && sameContext(active)) { active.panel.querySelector('header button')?.focus({preventScroll:true}); return; }
        const destination = () => sector === 'GED' || sector === 'GEC' ? globalThis.VienaTicketFields?.panelHost?.(sector.toLowerCase(),now.root.querySelector('.viena-ticket-tools-host .viena-mira5-action-wrap') || now.root.querySelector('.viena-ticket-tools-host') || host) || host : host;
        host = destination();
        if (sector === 'GED') { stopGedAuto(); if (gedAuto) gedAuto.suppressed = true; }
        if (sector === 'GEC') { stopGecAuto(); if (gecAuto) gecAuto.suppressed = true; }
        if (!cached && (sector === 'GEC' || sector === 'GED')) analysisSession(sector,now,null);
        const nodes = JSON.stringify(contextNodes(now,sector));
        const existingReport = (sector === 'GEC' || sector === 'GED') ? now.root.querySelector('[data-' + sector.toLowerCase() + '-context]') : null;
        const retained = existingReport?.dataset[sector === 'GEC' ? 'gecContext' : 'gedContext'] === JSON.stringify([now.identity,nodes]) ? existingReport : null;
        if (!retained) host.querySelector(sector === 'GEC' ? '[data-gec-context]' : '.viena-moica-gee-status:not([data-gec-context]):not([data-gee-context])')?.remove();
        geeBusy = true; clicked.disabled = true;
        let timer, failureMessage = 'No se pudo consultar ' + sector + '. Revisá MOICA2 y reintentá.';
        try {
            const result = await Promise.race([chrome.runtime.sendMessage({type:'VIENA_MOICA_GEE_SEARCH',nodo,sector,reuseAnalysis:!!cached}),new Promise((_,reject)=>{timer=setTimeout(()=>{failureMessage='La consulta ' + sector + ' tardó demasiado. Revisá MOICA2 y reintentá.';reject(Error(failureMessage));},65000);})]);
            if (!result?.ok) { failureMessage = result?.mensaje || failureMessage; throw Error(failureMessage); }
            const reused = cached && (result.reusedAnalysis || result.viewer) ? analysisSession(sector,now) : null;
            if (result.reusedAnalysis && !reused) { geeBusy = false; await queryGee(now,nodo,clicked,host,sector); return; }
            if (reused) { result.analysis = reused.analysis; result.gedDetails = reused.gedDetails; }
            if (result.viewer && sameContext({context:now}) && JSON.stringify(contextNodes(ticketContext(),sector)) === nodes) openGee(now,nodo,clicked,sector,!!reused);
            clicked.title = sector + ' filtrado por ' + nodo;
            if ((sector === 'GED' || sector === 'GEC') && result.analysis && sameContext({context:now}) && JSON.stringify(contextNodes(ticketContext(),sector)) === nodes) {
                host = destination();
                const status = retained || document.createElement('section'); if (!retained) { status.className = 'viena-moica-gee-status'; status.setAttribute('role','status'); status.dataset[sector === 'GED' ? 'gedContext' : 'gecContext'] = JSON.stringify([now.identity,nodes]); status.style.cssText = 'flex-basis:100%;white-space:pre-line'; } if (sector === 'GED') highlightGedReport(status,result.analysis,result.gedDetails); else if (status.__vienaAnalysis !== result.analysis) paintGecReport(status,result.analysis); if (reused || JSON.parse(nodes).length === 1) { const saved = reused || analysisSession(sector,now,result.analysis,result.gedDetails); reportFreshness(status,sector,now,saved?.at || Date.now(),!!reused); } if (status.parentElement !== host) host.append(status);
            }
        } catch (error) {
            if (clicked.isConnected && sameContext({context:now}) && JSON.stringify(contextNodes(ticketContext(),sector)) === nodes) {
                host = destination();
                let status = host.querySelector(sector === 'GEC' ? '[data-gec-context]' : '.viena-moica-gee-status:not([data-gec-context]):not([data-gee-context])');
                if (!status) { status = document.createElement('span'); status.className = 'viena-moica-gee-status'; status.setAttribute('role','status'); host.append(status); }
                if (sector === 'GED') status.dataset.gedContext = JSON.stringify([now.identity,nodes]);
                if (sector === 'GEC') { status.dataset.gecContext = JSON.stringify([now.identity,nodes]); paintGecReport(status,'Revisión parcial · ' + failureMessage); }
                else status.textContent = failureMessage;
            }
        } finally { clearTimeout(timer); geeBusy = false; clicked.disabled = false; if (geeButton) geeButton.disabled = false; if (gecButton) gecButton.disabled = false; if (gedButton) gedButton.disabled = false; }
    }
    function openGee(context, nodo, focus, sector = 'GEE', reuseAnalysis = false) {
        globalThis.VienaInfocallViewer?.close();
        close(); style();
        const panel = document.createElement('section'); panel.id = 'viena-moica-viewer';
        panel.setAttribute('role','dialog'); panel.setAttribute('aria-modal','true'); panel.setAttribute('aria-label','Ver ' + sector + ' - ' + nodo);
        const header = document.createElement('header'), title = document.createElement('strong'); title.textContent = 'Ver ' + sector + ' - ' + nodo;
        const retry = document.createElement('button'), exit = document.createElement('button');
        retry.type = exit.type = 'button'; retry.textContent = 'Reintentar'; exit.textContent = 'Cerrar';
        header.append(title,retry,exit);
        const status = document.createElement('div'); status.className = 'viewer-status'; status.setAttribute('role','status');
        const frame = document.createElement('iframe'); frame.title = sector + ' - ' + nodo; frame.referrerPolicy = 'origin';
        panel.append(header,status,frame);
        const view = { kind:'gee', nodo, context, focus, panel, frame, sector, token:[...crypto.getRandomValues(new Uint8Array(16))].map(v=>v.toString(16).padStart(2,'0')).join(''), timeout:null };
        let pingTimer, running = false, stopped = false;
        const valid = () => active === view && sameContext(view) && contextNodes(ticketContext(),sector).includes(nodo);
        const stop = () => { stopped = true; clearTimeout(pingTimer); clearTimeout(view.timeout); };
        const ping = () => {
            if (stopped || !valid()) return;
            frame.contentWindow?.postMessage({ type:'VIENA_MOICA_GEE_VIEWER_PING', token:view.token }, MOICA);
            clearTimeout(pingTimer); pingTimer = setTimeout(ping,250);
        };
        const start = () => {
            if (!valid()) return;
            stop(); stopped = false; running = false;
            status.classList.remove('viena-ged-report'); delete status.dataset.state;
            status.hidden = false; status.textContent = 'Cargando ' + sector + ' para el nodo ' + nodo + '…';
            view.timeout = setTimeout(() => { stop(); status.textContent = 'No se pudo completar la consulta. Revisá la sesión de MOICA2 y pulsá Reintentar.'; },60000);
            ping();
        };
        view.message = event => {
            if (!valid() || stopped || event.origin !== MOICA || event.source !== frame.contentWindow || event.data?.type !== 'VIENA_MOICA_GEE_VIEWER_STATE' || event.data.token !== view.token) return;
            if (event.data.state === 'ready' && !running) {
                clearTimeout(pingTimer); running = true;
                frame.contentWindow.postMessage({ type:'VIENA_MOICA_GEE_VIEWER_RUN', token:view.token, nodo, sector, reuseAnalysis:reuseAnalysis && !!analysisSession(sector,context) }, MOICA);
            } else if (event.data.state === 'result') {
                running = false;
                const result = event.data.result;
                if (result?.ok && result.reusedAnalysis) {
                    const cached = analysisSession(sector,context);
                    if (!cached) { reuseAnalysis = false; running = true; frame.contentWindow.postMessage({type:'VIENA_MOICA_GEE_VIEWER_RUN',token:view.token,nodo,sector},MOICA); return; }
                    result.analysis = cached.analysis; result.gedDetails = cached.gedDetails;
                }
                if (result?.ok) { stop(); status.textContent = sector + ' filtrado por ' + nodo + ((sector === 'GED' || sector === 'GEC') && result.analysis ? ' · ' + result.analysis : ''); if (sector === 'GEC') status.style.whiteSpace = 'pre-line'; if (sector === 'GED' && result.analysis) highlightGedReport(status,result.analysis,result.gedDetails); }
                else if (result?.phase) { clearTimeout(pingTimer); pingTimer = setTimeout(ping,250); }
                else { stop(); status.textContent = result?.mensaje || 'No se pudo consultar ' + sector + '. Revisá la sesión y reintentá.'; }
            }
        };
        view.key = event => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(); } };
        view.cleanup = () => { stop(); frame.onload = null; };
        frame.onload = () => { if (!stopped && valid()) { running = false; ping(); } };
        retry.onclick = start; exit.onclick = close;
        active = view; outsideOption(view,header); window.addEventListener('message',view.message); document.addEventListener('keydown',view.key,true);
        document.body.append(panel); frame.src = MOICA + '/home.php#'; exit.focus({preventScroll:true}); start();
    }
    function removeGecButton() {
        const wrapper = gecButton?.parentElement;
        if (wrapper?.classList.contains('viena-gec-header-action')) {
            wrapper.parentElement?.classList.remove('viena-ticket-gec-header');
            wrapper.remove();
        } else gecButton?.remove();
        gecButton = null;
    }
    function refreshGec(context, host) {
        const nodes = contextNodes(context,'GEC');
        if (!gecTask(context) || !nodes.length || !host) { removeGecButton(); return; }
        style();
        if (!gecButton || !context.root.contains(gecButton)) {
            removeGecButton();
            gecButton = document.createElement('button'); gecButton.type = 'button'; gecButton.className = 'viena-moica-viewer-button viena-moica-gec-button';
            gecButton.onmousedown = event => event.stopPropagation();
            gecButton.onclick = async event => {
                event.preventDefault(); event.stopPropagation();
                const now = ticketContext(); if (geeBusy || !gecTask(now)) return;
                const nodes = contextNodes(now,'GEC'), target = now.root.querySelector('.viena-ticket-tools-host .viena-mira5-action-wrap') || now.root.querySelector('.viena-ticket-tools-host') || host;
                if (nodes.length > 1) { chooseGee(now,gecButton,target,'GEC'); return; }
                if (nodes.length === 1) await queryGee(now,nodes[0],gecButton,target,'GEC');
            };
        }
        if (button.nextElementSibling !== gecButton) button.after(gecButton);
        const text = nodes.length === 1 ? 'Ver GEC - ' + nodes[0] : 'Ver GEC · Elegir nodo';
        if (gecButton.textContent !== text) gecButton.textContent = text;
        gecButton.disabled = geeBusy;
    }
    function refreshGed(context, host) {
        const nodes = contextNodes(context);
        if (!host || !nodes.length || !gedTask(context)) { gedButton?.remove(); gedButton = null; return; }
        if (!gedButton || !context.root.contains(gedButton)) {
            gedButton?.remove(); gedButton = document.createElement('button'); gedButton.type = 'button'; gedButton.className = 'viena-moica-viewer-button viena-moica-ged-button';
            gedButton.onmousedown = event => event.stopPropagation();
            gedButton.onclick = async event => {
                event.preventDefault(); event.stopPropagation();
                const now = ticketContext(); if (geeBusy || !gedTask(now)) return;
                const nodes = contextNodes(now), target = now.root.querySelector('.viena-ticket-tools-host .viena-mira5-action-wrap') || now.root.querySelector('.viena-ticket-tools-host');
                if (!target) return;
                if (nodes.length > 1) chooseGee(now,gedButton,target,'GED');
                else if (nodes.length === 1) await queryGee(now,nodes[0],gedButton,target,'GED');
            };
        }
        const anchor = gecButton || geeButton || button;
        if (anchor.nextElementSibling !== gedButton) anchor.after(gedButton);
        gedButton.textContent = nodes.length === 1 ? 'Ver GED - ' + nodes[0] : 'Ver GED · Elegir nodo'; gedButton.disabled = geeBusy;
    }
    function refresh() {
        if (nodeAuto && !nodeContext(nodeAuto.context,nodeAuto.node)) stopNodeAuto();
        if (active?.kind === 'node-search' && !nodeContext(active.context,active.node)) close();
        if (active && !sameContext(active)) close();
        if (active?.kind === 'gee' && !contextNodes(ticketContext(),active.sector).includes(active.nodo)) close();
        if (active?.kind === 'gee-choice' && JSON.stringify(contextNodes(ticketContext(),active.sector)) !== JSON.stringify(active.nodes)) close();
        const context = ticketContext();
        if (previousTabRoot && previousTabRoot !== context?.root && (context || !previousTabRoot.isConnected || !previousTabRoot.classList.contains('v-dialog__content--active') || !previousTabRoot.getClientRects().length)) {
            initialTabs.delete(previousTabRoot); previousTabRoot = null;
        }
        if (context) previousTabRoot = context.root;
        if (gedAuto && (!context || !gedTask(context) || gedAuto.context.root !== context.root || gedAuto.context.identity !== context.identity || gedAuto.key !== JSON.stringify(contextNodes(context)))) { stopGedAuto(); gedAuto = null; }
        if (gecAuto && (!context || !gecTask(context) || gecAuto.context.root !== context.root || gecAuto.context.identity !== context.identity || gecAuto.key !== JSON.stringify(contextNodes(context,'GEC')))) { stopGecAuto(); gecAuto = null; }
        if (geeAuto && (!context || !geeTask(context) || geeAuto.context.root !== context.root || geeAuto.context.identity !== context.identity || geeAuto.key !== JSON.stringify(contextNodes(context)))) { stopGecAuto('GEE'); geeAuto = null; }
        for (const status of document.querySelectorAll('.viena-moica-gee-status[data-ged-context]')) {
            if (!gedTask(context) || status.dataset.gedContext !== JSON.stringify([context?.identity,JSON.stringify(contextNodes(context))])) status.remove();
        }
        for (const status of document.querySelectorAll('.viena-moica-gee-status[data-gec-context]')) {
            if (!gecTask(context) || status.dataset.gecContext !== JSON.stringify([context?.identity,JSON.stringify(contextNodes(context,'GEC'))])) status.remove();
        }
        for (const status of document.querySelectorAll('.viena-moica-gee-status[data-gee-context]')) {
            if (!geeTask(context) || status.dataset.geeContext !== JSON.stringify([context?.identity,JSON.stringify(contextNodes(context))])) status.remove();
        }
        if (!context) { button?.remove(); button = null; geeButton?.remove(); geeButton = null; removeGecButton(); gedButton?.remove(); gedButton = null; return; }
        const toolsHost = context.root.querySelector('.viena-ticket-tools-host .viena-mira5-action-wrap') || context.root.querySelector('.viena-ticket-tools-host');
        const host = toolsHost || [...context.root.querySelectorAll('button')].find(el => /^(crear tarea|cambiar estado)$/i.test(el.textContent.trim()))?.closest('.row');
        if (!host) { geeButton?.remove(); geeButton = null; removeGecButton(); gedButton?.remove(); gedButton = null; return; }
        if (!button || !context.root.contains(button)) {
            button?.remove(); button = document.createElement('button'); button.type = 'button'; button.className = 'viena-moica-viewer-button'; button.textContent = 'Ver Ticket';
            button.onmousedown = event => event.stopPropagation();
            button.onclick = async event => {
                event.preventDefault(); event.stopPropagation();
                if (resolving) return;
                const context = ticketContext(); if (!context) return;
                resolving = true; const clicked = button; clicked.disabled = true;
                try { const next = await resolveContext(context); if (next) open(next, clicked); }
                finally { resolving = false; clicked.disabled = false; }
            };
        }
        style();
        startNodeAuto(context,toolsHost);
        if (button.parentElement !== host) host.append(button);
        refreshGec(context, toolsHost);
        const nodes = contextNodes(context);
        const node = contextNode(context);
        if (!toolsHost || !nodes.length || !geeTask(context)) { geeButton?.remove(); geeButton = null; }
        else {
            if (!geeButton || !context.root.contains(geeButton)) {
                geeButton?.remove(); geeButton = document.createElement('button');
                geeButton.type = 'button'; geeButton.className = 'viena-moica-viewer-button viena-moica-gee-button';
                geeButton.onmousedown = event => event.stopPropagation();
                geeButton.onclick = async event => {
                    event.preventDefault(); event.stopPropagation();
                    if (geeBusy) return;
                    const now = ticketContext();
                    if (!geeTask(now)) return;
                    const nodes = contextNodes(now);
                    if (nodes.length > 1) { chooseGee(now,geeButton,host); return; }
                    const nodo = contextNode(now);
                    if (!/^[A-Z0-9][A-Z0-9._-]{0,63}$/.test(nodo)) return;
                    await queryGee(now,nodo,geeButton,host);
                };
            }
            const text = node ? 'Ver GEE - ' + node : 'Ver GEE · Elegir nodo';
            if (geeButton.textContent !== text) geeButton.textContent = text;
            geeButton.disabled = geeBusy;
            if (button.nextElementSibling !== geeButton) button.after(geeButton);
        }
        // Analysis/report do not depend on mounting or showing the optional shortcut.
        startGedAuto(context,toolsHost || host);
        for (const report of context.root.querySelectorAll('.viena-ged-report')) markCurrentGedTicket(report);
        if (active?.kind === 'gee' && active.sector === 'GED') { const report = active.panel.querySelector('.viena-ged-report'); if (report) markCurrentGedTicket(report); }
        startGecAuto(context,toolsHost || host);
        startGecAuto(context,toolsHost || host,'GEE');
        refreshGed(context,toolsHost);
        // Select the native lazy section once per ticket; never fight later user tab changes.
        if (initialTabs.get(context.root) !== context.identity) {
            const tab = eventsTab(context);
            if (tab) {
                initialTabs.set(context.root, context.identity);
                if (!tab.classList.contains('v-tab--active') && tab.getAttribute('aria-selected') !== 'true') tab.click();
            }
        }
    }
    globalThis.VienaMoicaViewer = { refresh, close, openNodeSearch };
})();
