(function(root){
 'use strict';
 const KEY='viena_cws_guide_seen_v1',GUIDE='store-news-20261013-145';
 function create(storage){
  let queue=Promise.resolve();
  return sender=>{
   let allowed=false;try{const url=new URL(sender?.url);allowed=url.protocol==='https:'&&url.hostname==='viena.telecentro.net.ar'&&sender.frameId===0;}catch(_){}
   if(!allowed)return Promise.resolve(false);
   const task=queue.then(async()=>{if((await storage.get(KEY))[KEY]?.guide===GUIDE)return false;await storage.set({[KEY]:{guide:GUIDE,shownAt:new Date().toISOString()}});return true;});
   queue=task.catch(()=>{});return task;
  };
 }
 const api={KEY,GUIDE,create};
 if(typeof module==='object'&&module.exports)module.exports=api;
 else if(!root.document&&root.chrome?.runtime?.onMessage){
  const claim=create(root.chrome.storage.local);
  root.chrome.runtime.onMessage.addListener((message,sender,respond)=>{
   if(message?.type!=='VIENA_STORE_GUIDE_CLAIM'||sender?.id!==root.chrome.runtime.id)return false;
   claim(sender).then(show=>respond({ok:true,show}),()=>respond({ok:false,show:false}));return true;
  });
 }
})(globalThis);
