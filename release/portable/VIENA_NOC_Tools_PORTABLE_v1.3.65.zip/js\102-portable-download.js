(function (root) {
  'use strict';
  const channel = 'https://raw.githubusercontent.com/fdevvv/viena-noc-tools-updates/refs/heads/main/release/portable/';
  const extensionId = 'kncbbeclddielngolalkmlclfljgaoje';
  const parts = version => version.split('.').map(Number);
  const versionFormat = /^\d+\.\d+\.\d+$/;

  function parse(pointer, installed) {
    const version = String(pointer?.latest || '');
    if (!versionFormat.test(version) || !versionFormat.test(installed)) throw Error('Versión de GitHub inválida.');
    const latest = parts(version);
    const current = parts(installed);
    const difference = latest.map((part, i) => part - current[i]).find(part => part !== 0) || 0;
    if (difference <= 0) return { available: false, version };
    if (pointer.channel !== 'RELEASE' || pointer.distribution !== 'portable' || pointer.extension_id !== extensionId) {
      throw Error('La versión no corresponde a esta edición de VIENA.');
    }
    const url = channel + 'VIENA_NOC_Tools_PORTABLE_v' + version + '.zip';
    if (pointer.zip_url !== url || !/^[a-f0-9]{64}$/i.test(pointer.zip_sha256 || '')) {
      throw Error('GitHub todavía no ofrece un ZIP verificable para esta versión.');
    }
    return { available: true, version, url, sha256: pointer.zip_sha256.toLowerCase(), automatic: pointer.install_mode === 'automatic-zip' };
  }

  function create(fetcher, installed) {
    let pending;
    return {
      check() {
        if (pending) return pending;
        pending = (async () => {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), 6000);
          try {
            const response = await fetcher(channel + 'latest.json?_=' + Date.now(), { cache: 'no-store', signal: controller.signal });
            if (!response.ok) throw Error('No se pudo consultar GitHub (HTTP ' + response.status + ').');
            return parse(await response.json(), installed);
          } finally {
            clearTimeout(timer);
          }
        })();
        const release = () => { pending = null; };
        pending.then(release, release);
        return pending;
      },
    };
  }
  const api = { create, parse };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.VienaPortableDownload = api;
})(globalThis);
