(() => {
    'use strict';
    const p=new URL(location.href).searchParams,ticket=p.get('vienaOnmsiNativeTicket'),nonce=p.get('vienaOnmsiNativeNonce'),extension=p.get('vienaOnmsiNativeExtension');
    if(location.origin!=='https://moica2.telecentro.net.ar'||location.pathname!=='/buscarTicket.php'||parent===window||p.get('vienaOnmsiNative')!=='1'||!/^\d{6}FO\d+$/i.test(ticket||'')||!/^[a-f0-9]{32}$/.test(nonce||'')||!/^[a-p]{32}$/.test(extension||''))return;
    const origin='chrome-extension://'+extension,pending=new Map();let sequence=0,acked=false,opened=false,ready=false,watch,boot,timer,jq;
    const post=(type,data={})=>parent.postMessage({type,nonce,...data},origin);
    async function pack(v){
        if(v===undefined||v===null)return null;if(typeof v==='string')return {kind:'text',value:v};
        if(v instanceof FormData){const entries=[];for(const [k,value] of v.entries())entries.push([k,typeof value==='string'?value:await pack(value)]);return {kind:'form',entries};}
        let bytes;if(v instanceof Blob){if(v.size>16000000)throw Error('Archivo demasiado grande para el visor.');bytes=new Uint8Array(await v.arrayBuffer());}
        else if(v instanceof ArrayBuffer)bytes=new Uint8Array(v);else if(ArrayBuffer.isView(v))bytes=new Uint8Array(v.buffer,v.byteOffset,v.byteLength);else throw Error('Formato no compatible con el visor.');
        if(bytes.length>16000000)throw Error('Archivo demasiado grande para el visor.');let raw='';for(let i=0;i<bytes.length;i+=32768)raw+=String.fromCharCode(...bytes.subarray(i,i+32768));
        return {kind:v instanceof Blob?'blob':'bytes',base64:btoa(raw),type:v.type||'',name:v.name||'blob'};
    }
    function install(value){
        if(jq||typeof value?.ajaxTransport!=='function')return;jq=value;
        jq.ajaxTransport('+*',options=>{
            let u;try{u=new URL(options.url,location.href);if(u.origin!==location.origin)return;}catch{return;}
            let id;
            return {send(headers,complete){
                if(options.async===false){complete(0,'Solicitud síncrona no compatible con el visor.');post('ONMSI_NATIVE_ERROR',{message:'Esta acción usa una solicitud síncrona. No se envió.'});return;}
                id=String(++sequence);const timeout=setTimeout(()=>{if(pending.delete(id)){post('ONMSI_NATIVE_ABORT',{id});complete(0,'timeout');}},70000);pending.set(id,{complete,timeout});
                void(async()=>{try{const body=await pack(options.data);if(!pending.has(id))return;const h={...headers};if(!Object.keys(h).some(k=>k.toLowerCase()==='x-requested-with'))h['X-Requested-With']='XMLHttpRequest';post('ONMSI_NATIVE_HTTP',{request:{id,url:u.href,method:String(options.type||'GET').toUpperCase(),headers:h,body,responseType:options.xhrFields?.responseType}});}catch(e){const q=pending.get(id);if(q){pending.delete(id);clearTimeout(q.timeout);q.complete(0,e.message||'error');}}})();
            },abort(){const q=pending.get(id);if(q){pending.delete(id);clearTimeout(q.timeout);post('ONMSI_NATIVE_ABORT',{id});}}};
        });
    }
    if(typeof window.jQuery?.ajaxTransport==='function')install(window.jQuery);
    else{const prior=Object.getOwnPropertyDescriptor(window,'jQuery');if(!prior||prior.configurable){let value=prior?.value;Object.defineProperty(window,'jQuery',{configurable:true,enumerable:prior?.enumerable??true,get:()=>value,set(v){value=v;install(v);if(jq)Object.defineProperty(window,'jQuery',{value:v,writable:true,configurable:true,enumerable:true});}});}}
    window.addEventListener('message',e=>{
        const d=e.data;if(e.origin!==origin||e.source!==parent||d?.nonce!==nonce)return;
        if(d.type==='ONMSI_NATIVE_ACK'){acked=true;start();return;}
        if(d.type!=='ONMSI_NATIVE_RESPONSE')return;const q=pending.get(d.id);if(!q)return;pending.delete(d.id);clearTimeout(q.timeout);const r=d.result;
        if(!r?.ok){q.complete(0,r?.message||'error');return;}
        const responses={};if(r.responseType==='blob'||r.responseType==='arraybuffer'){const bytes=Uint8Array.from(atob(r.text),c=>c.charCodeAt(0));responses.binary=r.responseType==='blob'?new Blob([bytes],{type:r.mime}):bytes.buffer;}else responses.text=r.text;
        q.complete(r.status,r.statusText,responses,r.headers);
    });
    function check(){
        const modal=document.getElementById('MO-TKT-VER'),number=String(document.getElementById('TKT-VER-VISTA-NRO')?.textContent||'').toUpperCase();
        if(!ready&&modal?.getClientRects().length&&(number.match(/\b\d{6}[A-Z]{2}\d+\b/g)||[]).includes(ticket.toUpperCase())&&document.getElementById('TKT-VER-ID')?.value&&Number(jq?.active)===0){ready=true;clearTimeout(timer);watch?.disconnect();jq(document).off('ajaxStop.vienaOnmsiNative103',check);post('ONMSI_NATIVE_READY');}
    }
    function start(){
        if(opened||!acked)return;
        const modal=document.getElementById('MO-TKT-VER');if(!modal||!jq||typeof window.getIdTicketbyNro!=='function'){clearTimeout(boot);boot=setTimeout(start,100);return;}
        opened=true;
        watch=new MutationObserver(check);watch.observe(modal,{attributes:true,childList:true,characterData:true,subtree:true});jq(document).on('ajaxStop.vienaOnmsiNative103',check);
        jq(modal).on('hidden.bs.modal.vienaOnmsiNative103',e=>{if(e.target===modal&&Number(jq.active)===0&&!document.querySelector('.modal.in'))post('ONMSI_NATIVE_CLOSED');});
        window.getIdTicketbyNro(ticket);check();
    }
    window.addEventListener('pagehide',()=>{clearTimeout(timer);clearTimeout(boot);watch?.disconnect();if(jq)jq(document).off('ajaxStop.vienaOnmsiNative103',check);for(const [id,q] of pending){clearTimeout(q.timeout);post('ONMSI_NATIVE_ABORT',{id});}pending.clear();},{once:true});
    timer=setTimeout(()=>{clearTimeout(boot);watch?.disconnect();if(jq)jq(document).off('ajaxStop.vienaOnmsiNative103',check);post('ONMSI_NATIVE_ERROR',{message:'MOICA no confirmó la apertura. Revisá sesión y permisos.'});},25000);
    post('ONMSI_NATIVE_HELLO');
})();
