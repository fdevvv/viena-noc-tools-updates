(() => {
  'use strict';
  const $=id=>document.getElementById(id),api=globalThis.VienaInstallationTransfer;
  const manifest=chrome.runtime.getManifest();let selected=null,busy=false;
  $('identity').textContent=manifest.name+' · v'+manifest.version;
  function controls(){ $('export').disabled=busy;$('file').disabled=busy;$('accept').disabled=busy;$('restore').disabled=busy||!selected||!$('accept').checked; }
  function status(text,error=false){$('status').textContent=text;$('status').dataset.error=String(error);}
  async function run(action){if(busy)return;busy=true;controls();try{await action();}catch(e){status(String(e.message||e),true);}finally{busy=false;controls();}}
  $('accept').addEventListener('change',controls);
  $('export').addEventListener('click',()=>void run(async()=>{
    const [local,sync]=await Promise.all([chrome.storage.local.get(null),chrome.storage.sync.get(null)]);
    const backup=api.makeBackup(local,sync,chrome.runtime.id,manifest.version);
    const macros=api.summarizeMacros(backup);
    const url=URL.createObjectURL(new Blob([JSON.stringify(backup,null,2)],{type:'application/json'}));
    const a=document.createElement('a');a.href=url;a.download='VIENA_NOC_respaldo_instalacion.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    status('Respaldo preparado para descargar. Macros VIENA: '+macros.viena+' · MOICA: '+macros.moica+'. '+(macros.total?'Verificá el archivo descargado.':'Esta instalación no contiene macros guardadas; este archivo no recupera las macros de otra instalación.'));
  }));
  $('file').addEventListener('change',()=>void run(async()=>{
    selected=null;$('accept').checked=false;const file=$('file').files[0];if(!file)return;
    if(file.size>20*1024*1024)throw Error('El archivo supera el tamaño permitido.');
    selected=api.validate(JSON.parse(await file.text()));
    const macros=api.summarizeMacros(selected);
    $('preview').textContent='Respaldo v'+String(selected.version||'sin versión')+' · '+Object.keys(selected.local).length+' preferencias locales y '+Object.keys(selected.sync).length+' sincronizadas. Usuario: '+String(selected.local.viena_usuario||'sin configurar')+'. Macros VIENA: '+macros.viena+' · MOICA: '+macros.moica+'. '+(macros.total?'':'Este archivo no contiene macros para importar.');
    status('Revisá el respaldo y confirmá antes de restaurar.');
  }));
  $('restore').addEventListener('click',()=>void run(async()=>{
    if(!selected||!$('accept').checked)return;
    const macros=api.summarizeMacros(selected);
    const result=await chrome.runtime.sendMessage({type:'VIENA_CWS_RESTORE_MANUAL',backup:selected});
    if(!result?.ok)throw Error(result?.error||'No se pudo restaurar la configuración.');
    selected=null;$('accept').checked=false;
    status('Configuración restaurada y verificada. Macros VIENA: '+macros.viena+' · MOICA: '+macros.moica+'. '+(macros.total?'Reabrí el menú de macros en las páginas operativas para verlas.':'El archivo no incluía macros; no se importó ninguna.')+' Revisá tus herramientas antes de retirar la instalación original.');
  }));
})();
