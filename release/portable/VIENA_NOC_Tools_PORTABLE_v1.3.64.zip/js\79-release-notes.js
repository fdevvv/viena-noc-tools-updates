(()=>{'use strict';const history=[
  {
    "version": "1.3.64",
    "title": "Prueba de instalación automática por ZIP",
    "notes": [
      "Prueba de instalación automática por ZIP"
    ],
    "announcement": {
      "version": "1.3.64",
      "approved": true,
      "items": [
        {
          "title": "Prueba de instalación automática por ZIP",
          "text": "Prueba de instalación automática por ZIP"
        }
      ]
    }
  },
  {
    "version": "1.3.63",
    "title": "Instalación desde la carpeta vinculada",
    "notes": [
      "Instalación desde la carpeta vinculada"
    ],
    "announcement": {
      "version": "1.3.63",
      "approved": false,
      "items": []
    }
  },
  {
    "version": "1.3.62",
    "title": "Aviso de nueva versión dentro de VIENA",
    "notes": [
      "Aviso de nueva versión dentro de VIENA"
    ],
    "announcement": {
      "version": "1.3.62",
      "approved": false,
      "items": []
    }
  },
  {
    "version": "1.3.61",
    "title": "Prueba de actualización manual",
    "notes": [
      "Prueba de actualización manual"
    ],
    "announcement": {
      "version": "1.3.61",
      "approved": true,
      "items": [
        {
          "title": "Prueba de actualización manual",
          "text": "Prueba de actualización manual"
        }
      ]
    }
  },
  {
    "version": "1.3.60",
    "title": "Instalación manual por ZIP",
    "notes": [
      "VIENA avisa cuando hay una versión disponible para instalar manualmente."
    ],
    "announcement": {
      "version": "1.3.60",
      "approved": false,
      "items": []
    }
  },
  {
    "version": "1.3.59",
    "title": "Prueba de actualización automática",
    "notes": [
      "Prueba de actualización automática"
    ],
    "announcement": {
      "version": "1.3.59",
      "approved": true,
      "items": [
        {
          "title": "Prueba de actualización automática",
          "text": "Prueba de actualización automática"
        }
      ]
    }
  },
  {
    "version": "1.3.58",
    "title": "Actualización automática y mejoras operativas",
    "notes": [
      "Aviso previo e instalación automática de nuevas versiones.",
      "Mejoras en Fuentes, MIRA 5, ONMSi, GEC y MOICA."
    ],
    "announcement": {
      "version": "1.3.58",
      "approved": false,
      "items": []
    }
  },
  {
    "version": "1.3.57",
    "title": "Instalación por carpeta",
    "notes": [
      "Instalación por carpeta conservando la identidad de VIENA y sus datos.",
      "Actualizaciones verificadas desde una página independiente del panel.",
      "Acceso a las herramientas existentes de respaldo completo, macros, botones y plantillas."
    ],
    "announcement": {
      "approved": true,
      "version": "1.3.57",
      "items": [
        {
          "title": "Instalación por carpeta",
          "text": "Instalación por carpeta, conservación de tus datos y actualizaciones desde VIENA."
        }
      ]
    }
  },
  {
    "version": "1.3.54",
    "title": "Nuevas herramientas y mejoras",
    "notes": [
      "Analizar PO en GEC13: Revisá potencias Legacy, ordená por desvío y derivá los tickets seleccionados a GEC50 o GEC34, con verificación de tareas existentes.",
      "Contador de derivaciones: Consultá el avance del día y del turno, junto con el historial compartido.",
      "Cambiar padre en MOICA: Cambiá el padre de varios tickets desde la bandeja, con identificación de tareas de campo activas.",
      "Resumen MIRA5 más preciso: Reconoce el Nodo o SUB NODO indicado en el Mensaje cuando el campo CMTS está vacío.",
      "Acceso a Fuentes: Utiliza el ID FUENTE del ticket para seleccionar la fuente y abrir sus gráficos.",
      "Personalizar vista: Mejor distribución y lectura de las opciones GED.",
      "FTTH: los tickets con tipificación FTTH o SPLITTER abren GPON. Si el campo Nodo está vacío, se utiliza el Nodo explícito y único del Mensaje.",
      "Grafana: corrección de la consulta de potencia óptica cuando hay una o más pestañas de Grafana abiertas.",
      "MOICA: reconocimiento de ramas de nodo como RE17RD al cargar zonas desde el mensaje, con validación exacta en el selector nativo."
    ],
    "announcement": {
      "approved": true,
      "version": "1.3.54",
      "items": [
        {
          "title": "Analizar PO en GEC13",
          "text": "Revisá potencias Legacy, ordená por desvío y derivá los tickets seleccionados a GEC50 o GEC34, con verificación de tareas existentes."
        },
        {
          "title": "Contador de derivaciones",
          "text": "Consultá el avance del día y del turno, junto con el historial compartido."
        },
        {
          "title": "Cambiar padre en MOICA",
          "text": "Cambiá el padre de varios tickets desde la bandeja, con identificación de tareas de campo activas."
        },
        {
          "title": "Resumen MIRA5 más preciso",
          "text": "Reconoce el Nodo o SUB NODO indicado en el Mensaje cuando el campo CMTS está vacío."
        },
        {
          "title": "Acceso a Fuentes",
          "text": "Utiliza el ID FUENTE del ticket para seleccionar la fuente y abrir sus gráficos."
        },
        {
          "title": "Personalizar vista",
          "text": "Mejor distribución y lectura de las opciones GED."
        }
      ]
    }
  },
  {
    "version": "1.3.53",
    "title": "Mejoras en tablas e integraciones",
    "notes": [
      "Tablas: los anchos ajustados manualmente se conservan al volver a abrir la vista. Mejoras de estabilidad al cambiar de nodo y consultar frecuencias o gráficos en MIRA5.",
      "MOICA: mejoras en la detección de tareas SRE y GIE. Las GIE se muestran en cualquiera de sus estados.",
      "Resumen del nodo: correcciones en la identificación del contexto y en los accesos a Fuentes, Óptico y RPHY.",
      "MIRA5: en alarmas de nodo con US apagado, al usar «Solapa nueva» se abre directamente en US.",
      "Grafana y Fuentes: consulta de datos en Óptico y RPHY, y del COS en Grafana, sin necesidad de mantener abiertas sus pestañas."
    ],
    "announcement": {
      "approved": false,
      "version": "1.3.53",
      "items": []
    }
  },
  {
    "version": "1.3.52",
    "title": "Resumen del nodo y tareas de campo",
    "notes": [
      "Consultá el resumen del nodo con datos de MIRA5, Fuentes y Grafana, niveles, baterías, potencias y detalle por tecnología. Descargá una imagen del resumen.",
      "Las consultas del resumen preparan las plataformas en segundo plano y permiten reintentar después de iniciar sesión.",
      "Revisá las tareas de campo GEC, GEE y GED con su estado real; GEC y GEE muestran los resultados a medida que se analizan.",
      "Elegí la ubicación de los paneles. GEC y GED conservan resultados recientes al iniciar o completar la tarea y permiten actualizarlos.",
      "GED muestra problema, estado y fecha por ticket, marca el evento abierto en VIENA y oculta Retorno cuando no tiene tickets.",
      "La búsqueda automática MOICA muestra el avance de tickets revisados y las tareas de campo con sus estados diferenciados por color.",
      "La cabecera del ticket muestra las tareas de campo vigentes. La carpeta de notas y adjuntos se recuerda entre tickets y el aviso de nota conserva los selectores abiertos.",
      "Personalizá los filtros de Tareas internas y Tareas de campo: elegí cuáles mostrar y ordenalos arrastrando, con vista previa antes de aplicar o cancelar.",
      "Al reabrir un ticket, la vista comienza en Eventos. El desplegable de la cabecera permite consultar varias tareas de campo sin quedar tapado.",
      "MIRA5 reconoce el Nodo CMTS del ticket cuando coincide el nodo físico y distingue coincidencias exactas cuando hay varias filas del mismo Nodo CMTS.",
      "La Asignación RTN + CTN incluye RTN, CTN, NGT, NGC, CCH, RHP, NGS y NGP; las selecciones personalizadas existentes se conservan.",
      "Consultá el historial de versiones desde el popup, la vista completa o el aviso de novedades al entrar a VIENA."
    ],
    "announcement": {
      "approved": true,
      "version": "1.3.52",
      "items": [
        {
          "title": "El estado del nodo, en un solo lugar",
          "text": "Consultá datos de MIRA5, Fuentes y Grafana desde el ticket y descargá una imagen del resumen."
        },
        {
          "title": "Tareas de campo más claras",
          "text": "Revisá las tareas y sus estados en los paneles GEC, GEE y GED, con resultados que aparecen a medida que se analizan."
        },
        {
          "title": "Menos pasos para tus notas y adjuntos",
          "text": "La carpeta elegida se recuerda entre tickets y recargas."
        }
      ]
    }
  },
  {
    "version": "1.3.51",
    "title": "Mejoras de tareas, MOICA y Métricas",
    "notes": [
      "GEC y GEE visibles por defecto, con opción de ocultarlos desde Personalizar vista.",
      "Capturas multipágina sin recortes por diferencias de ancho; macros y carpeta usan datos del ticket actual.",
      "Listados MOICA disponibles también en Home; panel En Curso por nodo y coincidencia con el evento abierto.",
      "El panel de tickets MOICA muestra también el problema de cada ticket, conservando la coincidencia con VIENA.",
      "Botones separados de los paneles; búsqueda habitual con cuatro estados y visor opcional con resaltado En Curso.",
      "Seleccionar una fila de Métricas abre su gráfico y Visitas del nodo, conservando el scroll."
    ]
  },
  {
    "version": "1.3.50",
    "title": "GED, notas y capturas de edificios",
    "notes": [
      "GED automático por nodo y Nodo CMTS, con aviso independiente del botón y recuperación en primera apertura.",
      "Nota y adjuntos al crear tareas; imágenes por carpeta y nodo, botones y tipografía adaptables al zoom.",
      "Carpeta recordada para los gráficos de Estadísticas; orden por calle/cuadra y agrupación opcional por edificio.",
      "Scroll estable durante DS automático y desplazamiento independiente en la vista previa de cuadras.",
      "Fotografía completa del edificio, incluyendo páginas, copia y PNG con nodo, ID, dirección y fecha; carpeta configurable.",
      "Captura con autorización opcional al usarla, conservada entre recargas y pestañas; ventanas de permisos dentro de la página.",
      "Downstream permite Todos, Con ID y Sin ID; selector directo por edificio y encabezados separados.",
      "Al cambiar de calle o cuadra se restablece Mostrar todos; la selección se conserva dentro de la misma cuadra."
    ]
  },
  {
    "version": "1.3.49",
    "title": "Infocall, análisis MIRA y herramientas de operación",
    "notes": [
      "Infocall pide acceso sólo al usarlo y reconoce EFS Legacy; recuperación de conexión después de actualizar.",
      "MIRA compara frecuencias DS por CM y cuadra con visor nativo y período independiente de1,99 días.",
      "Templates MIRA compactos: cuadras agrupadas por calle y altura, niveles locales y lista única de frecuencias.",
      "PWR DS automático dentro de-10/+12 en PO/RX; selector de cuadras responsive y falla inicial editable.",
      "Consultas GEE/GEC por tarea y nodo, con elección explícita cuando hay varios nodos.",
      "Fuentes reúne acciones por tecnología y corrige la apertura del gráfico MT17A/MT17AA.",
      "Los editores permiten quitar motivos asociados con Guardar/Descartar.",
      "Visor ampliado opcional de tickets internos, con preferencia persistente y presentación centrada."
    ]
  },
  {
    "version": "1.3.48",
    "title": "Infocall y herramientas operativas",
    "notes": [
      "Infocall3 integrado en tickets HFC con cliente identificado y diagnósticos IQ/RDE; recuerda la opción de cerrar al hacer clic fuera.",
      "Copiar Nodo y Nodo CMTS en VIENA y encabezado de Fuentes.",
      "GPON reúne Nodo, Edificio y Cliente en su menú propio.",
      "MOICA carga Fuentes desde Mensaje y evita confundir alturas de dirección con IDs.",
      "MIRA reconoce INGRESS US y FEC DS; permite armar templates con cuadras seleccionadas del análisis.",
      "Ver Ticket incorpora cierre opcional al hacer clic fuera y recuerda la elección."
    ]
  },
  {
    "version": "1.3.47",
    "title": "Asignación y mejoras de MIRA",
    "notes": [
      "Asignar - usuario asigna el ticket elegido o el primero pendiente sin iniciar.",
      "Por solapas selecciona US/DS según el mensaje QAM/OFDM del ticket; Gráficos originales conserva su comportamiento habitual.",
      "MIRA agrega accesos de 2 a 7 días junto al filtro, conservando el ingreso manual.",
      "Se retira Ver plano de MIRA."
    ]
  },
  {
    "version": "1.3.46",
    "title": "Mejoras de MIRA y edición de tickets",
    "notes": [
      "MIRA conserva las historias consultadas al cambiar afectación y filtra CMs por niveles Bajo, Medio y Alto.",
      "La vista de gráficos respeta la carga nativa al cambiar de nodo.",
      "Ir a Cliente conserva el listado completo del Nodo CMTS y abre los gráficos del cliente seleccionado.",
      "Los menús del ticket se cierran al abrir otra acción; Crear tarea reinicia correctamente el contexto.",
      "Los editores de Edificio y Cuadras permiten probar opciones en la vista previa.",
      "Ver plano permite consultar el PDF HFC del nodo con la sesión de Planos. Esta opción se retiró en la versión 1.3.47."
    ]
  },
  {
    "version": "1.3.45",
    "title": "Análisis MIRA y herramientas operativas",
    "notes": [
      "Vistas de gráficos originales y por solapas, análisis FEC/CMs, descarga PNG y navegación con scroll estable.",
      "Indicadores de ticket y filtro personal, visor MOICA y botones de herramientas adaptables.",
      "Trasladá tu configuración anterior y consultá la guía de herramientas."
    ]
  },
  {
    "version": "1.3.44",
    "title": "Guía, respaldos y carga MOICA",
    "notes": [
      "Guía visual de herramientas y respaldo completo e individual de configuración.",
      "Carga MOICA con selección de clientes, separadores de nodos y recuperación del aviso al cambiar tipo."
    ]
  },
  {
    "version": "1.3.43",
    "title": "Instalación desde Chrome Web Store",
    "notes": [
      "Chrome administra las actualizaciones de la instalación de tienda.",
      "Traslado consentido de configuración anterior y respaldo manual, conservando preferencias."
    ]
  },
  {
    "version": "1.3.42",
    "title": "Más control para tu trabajo",
    "notes": [
      "Personalizá la vista del ticket: elegí qué campos y botones mostrar y ordenalos a tu gusto.",
      "Vista previa en el mismo ticket: revisá el resultado antes de aplicar o cancelar los cambios.",
      "Distribución adaptable al ancho de la pantalla, también en tickets completados.",
      "Popup más ancho para consultar las herramientas con mayor comodidad.",
      "Incluye las macros VIENA/MOICA, sus bibliotecas y el respaldo de macros de la 1.3.41.",
      "Incluye el editor, traslado y respaldo de botones personales y plantillas.",
      "Incluye la edición de Asignaciones y las mejoras de reemplazo de macros MOICA.",
      "Incluye la interfaz renovada y el modo claro y oscuro de la 1.3.41."
    ]
  },
  {
    "version": "1.3.41",
    "title": "Macros, plantillas y nueva interfaz",
    "notes": [
      "Nueva interfaz del panel y los editores, con modo claro y oscuro en Personalización.",
      "Macros en VIENA y tareas manuales de MOICA: grabar, reproducir, detener y corregir pasos.",
      "Bibliotecas con búsqueda, carpetas, renombrado y orden por arrastre; elegí la carpeta antes de grabar.",
      "Respaldo e importación de macros VIENA/MOICA y de botones personales con sus plantillas.",
      "Plantillas editables: mensajes y motivos propios, traslado entre botones y orden por arrastre.",
      "Asignaciones: crear, editar, sumar tipificaciones, quitar códigos y eliminar plantillas.",
      "MOICA reemplaza los problemas y el mensaje anteriores al ejecutar otra macro; revisá el resultado."
    ]
  },
  {
    "version": "1.3.40",
    "title": "Seguimiento compartido en Métricas y asignación",
    "notes": [
      "Métricas comparte la referencia de seguimiento entre operadores para usar el mismo punto de partida.",
      "Si los valores aumentan después de la marca, el nodo se muestra violeta y Ctrl + doble click reconoce los nuevos valores.",
      "El estado de sincronización se muestra en la cabecera y, si no está disponible, Métricas continúa en modo local.",
      "Asignar e Iniciar usa el ticket marcado cuando hay exactamente un checkbox seleccionado; sin selección mantiene el comportamiento anterior."
    ]
  },
  {
    "version": "1.3.39",
    "title": "Seguimiento en Métricas",
    "notes": [
      "Mejoras de sincronización y seguimiento de nodos en Métricas."
    ]
  },
  {
    "version": "1.3.38",
    "title": "Estado de actualización más preciso",
    "notes": [
      "El estado de actualización muestra con mayor precisión la versión disponible."
    ]
  },
  {
    "version": "1.3.37",
    "title": "Mejoras de estabilidad",
    "notes": [
      "Mejoras de estabilidad general y actualización de actividad."
    ]
  },
  {
    "version": "1.3.36",
    "title": "Menús de Completar Tarea más ordenados",
    "notes": [
      "Completar Tarea y los botones personales mantienen un solo menú desplegable abierto a la vez."
    ]
  }
];globalThis.VienaReleaseHistory=Object.freeze(history);globalThis.VienaReleaseNotes=history[0];})();
