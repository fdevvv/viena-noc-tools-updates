(() => {
  'use strict';
  const installed = chrome.runtime.getManifest().version;
  const client = VienaPortableDownload.create(fetch, installed);
  const $ = id => document.getElementById(id);
  $('identity').textContent = 'Versión instalada v' + installed;

  async function check() {
    if ($('check').disabled) return;
    $('check').disabled = true;
    $('available').hidden = true;
    $('status').dataset.error = 'false';
    $('status').textContent = 'Consultando GitHub…';
    try {
      const result = await client.check();
      $('status').textContent = result.available ? 'Disponible v' + result.version + '. Instalación manual.' :
        'No hay una versión posterior a v' + installed + ' en GitHub.';
      if (result.available) {
        $('download').href = result.url;
        $('checksum').textContent = result.sha256;
        $('available').hidden = false;
      }
    } catch (error) {
      $('status').dataset.error = 'true';
      $('status').textContent = error.name === 'AbortError' ? 'GitHub no respondió a tiempo. Podés reintentar.' : error.message;
    } finally {
      $('check').disabled = false;
    }
  }
  $('check').addEventListener('click', () => void check());
  if (new URLSearchParams(location.search).has('check')) void check();
})();
