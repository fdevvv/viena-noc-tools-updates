'use strict';
const VIENA_THEME_KEY='viena_ui_theme_v1';
const VIENA_THEME_PARAMS=new URLSearchParams(location.search);
const VIENA_THEME_STANDALONE=VIENA_THEME_PARAMS.get('standalone')==='1'||VIENA_THEME_PARAMS.get('macroBackup')==='1'||VIENA_THEME_PARAMS.get('templatesBackup')==='1'||VIENA_THEME_PARAMS.get('configBackup')==='1'||VIENA_THEME_PARAMS.get('buttonsBackup')==='1';
function vienaThemeNormalize(value){return value==='dark'?'dark':'light'}
function vienaThemePaint(root=document){if(VIENA_THEME_STANDALONE)return;const theme=vienaThemeNormalize(document.documentElement.dataset.vienaTheme);root.querySelectorAll('[data-viena-theme-choice]').forEach(button=>{const active=button.dataset.vienaThemeChoice===theme;button.classList.toggle('active',active);button.setAttribute('aria-pressed',active?'true':'false')})}
function vienaThemeApply(value){if(VIENA_THEME_STANDALONE)return 'light';const theme=vienaThemeNormalize(value);document.documentElement.dataset.vienaTheme=theme;vienaThemePaint();return theme}
async function vienaThemeSave(value){if(VIENA_THEME_STANDALONE)return;const theme=vienaThemeApply(value);try{await chrome.storage.local.set({[VIENA_THEME_KEY]:theme})}catch(_){}}
function vienaThemeBind(root=document){if(VIENA_THEME_STANDALONE)return;root.querySelectorAll('[data-viena-theme-choice]').forEach(button=>{if(button.dataset.vienaThemeBound==='1')return;button.dataset.vienaThemeBound='1';button.addEventListener('click',()=>{void vienaThemeSave(button.dataset.vienaThemeChoice)})});vienaThemePaint(root)}
globalThis.VienaTheme=Object.freeze({apply:vienaThemeApply,save:vienaThemeSave,bind:vienaThemeBind});
if(!VIENA_THEME_STANDALONE){chrome.storage.local.get([VIENA_THEME_KEY]).then(data=>vienaThemeApply(data?.[VIENA_THEME_KEY])).catch(()=>vienaThemeApply('light'));chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[VIENA_THEME_KEY])vienaThemeApply(changes[VIENA_THEME_KEY].newValue)});queueMicrotask(()=>vienaThemeBind(document))}
if (VIENA_THEME_PARAMS.get('macroBackup') === '1' || VIENA_THEME_PARAMS.get('templatesBackup') === '1' || VIENA_THEME_PARAMS.get('configBackup') === '1' || VIENA_THEME_PARAMS.get('buttonsBackup') === '1') {
  // Dedicated backup page is mounted by 48; popup and updater UI stay inactive.
} else if ((new URLSearchParams(location.search).get('full') === '1' || new URLSearchParams(location.search).get('standalone') === '1')) {
  globalThis.VienaHomeUI?.init?.();
} else {
const ASSIGN_KEY = 'viena_asignar_multiple_filtro';

const isStandaloneFolderContext = false;
const VIENA_POPUP_BUILD_ID = '1.3.61';
let runtimeBadgeState='CHECKING',updateBadgeAvailable=false,updateTargetChannel='RELEASE';
const currentBadgeHelp = document.getElementById('currentBadgeHelp');
const currentBadgeCode = document.getElementById('currentBadgeCode');
const currentBadgeText = document.getElementById('currentBadgeText');
const BADGE_HELP = {
  ON: { cls: 'on', text: '<b>ON — Activa.</b> La extensión y la pestaña operativa están sincronizadas.' },
  TAB: { cls: 'tab', text: '<b>TAB — Pestaña desactualizada.</b> Recargá la pestaña marcada como “Recargar”.' },
  RLD: { cls: 'rld', text: '<b>RLD — Extensión por recargar.</b> Chrome todavía está usando el runtime anterior; esperá la recarga automática o recargá manualmente si persiste.' },
  UPD: { cls: 'upd', text: '<b>UPD — Actualización disponible.</b> Hay una RELEASE más nueva para descargar.' },
  CHECKING: { cls: 'checking', text: '<b>Estado:</b> comprobando el runtime, las pestañas y el canal de actualización.' }
};

function renderCurrentBadgeHelp() {
  if (!currentBadgeHelp || !currentBadgeCode || !currentBadgeText) return;
  const code = runtimeBadgeState === 'RLD' || runtimeBadgeState === 'TAB'
    ? runtimeBadgeState
    : updateBadgeAvailable
      ? 'UPD'
      : runtimeBadgeState === 'ON' ? 'ON' : 'CHECKING';
  const info = BADGE_HELP[code] || BADGE_HELP.CHECKING;
  currentBadgeHelp.className = `status-context ${info.cls}`;
  currentBadgeCode.textContent = code === 'CHECKING' ? '…' : code;
  const updText = updateTargetChannel === 'DEV'
    ? '<b>UPD — Actualización DEV disponible.</b> Hay un build DEV más nuevo listo para instalar.'
    : BADGE_HELP.UPD.text;
  currentBadgeText.innerHTML = code === 'UPD' ? updText : info.text;
}

renderCurrentBadgeHelp();

const OPERATOR_RELEASE_HISTORY = globalThis.VienaReleaseHistory || (globalThis.VienaReleaseNotes ? [globalThis.VienaReleaseNotes] : []);

function renderOperatorReleaseHistory() {
  const list = document.getElementById('releaseHistoryList');
  if (!list) return;
  const installed = chrome.runtime.getManifest().version;
  const isDev = /DEV/i.test(String(chrome.runtime.getManifest().name || ''));
  list.replaceChildren();

  for (const release of OPERATOR_RELEASE_HISTORY) {
    const entry = document.createElement('div');
    entry.className = 'release-entry';

    const head = document.createElement('div');
    head.className = 'release-entry-head';
    const version = document.createElement('span');
    version.className = 'release-version';
    version.textContent = `v${release.version}`;
    head.appendChild(version);

    if (release.version === installed) {
      const tag = document.createElement('span');
      tag.className = 'release-tag current';
      tag.textContent = isDev ? 'DEV actual' : 'Actual';
      head.appendChild(tag);
    }

    const title = document.createElement('div');
    title.className = 'release-title';
    title.textContent = release.title;

    const notes = document.createElement('ul');
    notes.className = 'release-notes';
    for (const note of release.notes) {
      const li = document.createElement('li');
      li.textContent = note;
      notes.appendChild(li);
    }

    entry.append(head, title, notes);
    list.appendChild(entry);
  }
}

renderOperatorReleaseHistory();


document.getElementById('installedVersion').textContent='v1.3.61';
document.getElementById('latestVersion').textContent='Sin consultar';
document.getElementById('updateStatus').textContent='Las nuevas versiones se descargan desde GitHub.';
document.getElementById('updateNotes').textContent='';
function isDevRuntime(){return false;}
const userInput = document.getElementById('user');
const assignInput = document.getElementById('assignSurname');
const userStatus = document.getElementById('userStatus');
const assignStatus = document.getElementById('assignStatus');
const toast = document.getElementById('toast');
const toastText = document.getElementById('toastText');
const toastIcon = document.getElementById('toastIcon');
let toastTimer = 0;

function showToast(message, type = 'success') {
  if (toastTimer) clearTimeout(toastTimer);
  toast.className = `show ${type}`;
  toastText.textContent = message;
  toastIcon.textContent = type === 'success' ? '✓' : type === 'error' ? '!' : 'i';
  toastTimer = setTimeout(hideToast, 3200);
}
function hideToast() {
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = 0;
  toast.className = '';
}
document.getElementById('toastClose').addEventListener('click', hideToast);

async function refreshRegistrySyncStatus(force=false){
  const el=document.getElementById('registryStatus');
  const btn=document.getElementById('testRegistry');
  try{
    if(force){
      if(btn) btn.disabled=true;
      const hb=await chrome.runtime.sendMessage({type:'VIENA_INSTALL_REGISTRY_SYNC_NOW',reason:'popup'});
      if(!hb?.ok && !hb?.skipped) throw new Error(hb?.error||hb?.reason||'registro_fallido');
    }
    const st=await chrome.runtime.sendMessage({type:'VIENA_GET_INSTALL_REGISTRY_STATUS'});
    if(!st?.ok) throw new Error(st?.error||'status_failed');
    if(st.lastOk){
      const runtimeVersion=String(chrome.runtime.getManifest().version||'');
      let runtimeBuild='';
      try { runtimeBuild=String(VIENA_POPUP_BUILD_ID||''); } catch (_) {}
      const storedVersion=String(st.lastVersion||'');
      const storedBuild=String(st.lastBuild||'');
      const identityStale=(storedVersion && runtimeVersion && storedVersion!==runtimeVersion) || (storedBuild && runtimeBuild && storedBuild!==runtimeBuild);
      if(identityStale){
        el.textContent='Registro de instalación: sincronizando versión actual…';
        el.style.color='#72500e';
      }else{
        const mins=Math.max(0,Math.round((Date.now()-Number(st.lastOk))/60000));
        const who=st.lastUser||st.usuario||'sin usuario detectado';
        el.textContent=`Registro de instalación: OK · ${who} · hace ${mins} min · v${storedVersion||runtimeVersion}`;
        el.style.color='#1d6230';
      }
    }else if(st.lastError){
      const transient=String(st.lastError)==='timeout_temporal';
      el.textContent=transient?'Registro de instalación: reintentando automáticamente…':`Registro de instalación: error · ${st.lastError}`;
      el.style.color=transient?'#72500e':'#8d251d';
    }else{
      el.textContent='Registro de instalación: todavía sin registro confirmado.';
      el.style.color='#72500e';
    }
  }catch(e){
    if(el){const msg=String(e?.message||e);const transient=/timeout_temporal|aborted|abort/i.test(msg);el.textContent=transient?'Registro de instalación: reintentando automáticamente…':`Registro de instalación: error · ${msg}`;el.style.color=transient?'#72500e':'#8d251d';}
  }finally{if(btn) btn.disabled=false;}
}
const testRegistryBtn=document.getElementById('testRegistry');
if(testRegistryBtn) testRegistryBtn.addEventListener('click',async()=>{await refreshRegistrySyncStatus(true);});

function validSurname(value) {
  const v = String(value || '').trim();
  if (v.length < 2 || v.length > 50) return false;
  try { return /^[\p{L}\p{M}][\p{L}\p{M}'’.-]*(?:\s+[\p{L}\p{M}][\p{L}\p{M}'’.-]*)*$/u.test(v); }
  catch (_) { return /^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ'’.-]*(?:\s+[A-Za-zÁÉÍÓÚÜÑáéíóúüñ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ'’.-]*)*$/.test(v); }
}


async function refresh() {
  const local = await chrome.storage.local.get(['viena_usuario', 'viena_usuario_origen', ASSIGN_KEY]);
  let sync = {};
  try { sync = await chrome.storage.sync.get([ASSIGN_KEY]); } catch (_) {}

  userInput.value = local.viena_usuario || '';
  assignInput.value = String(local[ASSIGN_KEY] || sync[ASSIGN_KEY] || '').trim();

  const autoDetected = Boolean(local.viena_usuario && local.viena_usuario_origen === 'auto');
  userInput.readOnly = autoDetected;
  userInput.setAttribute('aria-readonly', autoDetected ? 'true' : 'false');
  const saveUserBtn = document.getElementById('saveUser');
  const userField = document.getElementById('vienaUserField');
  const userLabel = document.getElementById('userLabel');
  const userAutoPanel = document.getElementById('userAutoPanel');
  const userAutoValue = document.getElementById('userAutoValue');
  const userManualRow = document.getElementById('userManualRow');
  const userHint = document.getElementById('userHint');
  if (userField) userField.classList.toggle('auto-user', autoDetected);
  if (userLabel) userLabel.textContent = autoDetected ? '🔒 Usuario VIENA' : 'Usuario VIENA';
  if (userAutoPanel) userAutoPanel.hidden = !autoDetected;
  if (userAutoValue) userAutoValue.textContent = local.viena_usuario || '';
  if (userManualRow) { userManualRow.hidden = autoDetected; userManualRow.style.setProperty('display', autoDetected ? 'none' : '', autoDetected ? 'important' : ''); }
  if (userHint) {
    userHint.textContent = autoDetected
      ? ''
      : 'No pude detectarlo automáticamente. Ingresá tu propio usuario VIENA y guardalo.';
    userHint.style.display = autoDetected ? 'none' : '';
  }
  const brandVersionEl = document.querySelector('.header .version');
  if (brandVersionEl) { const channelLabel = isDevRuntime() ? 'DEV' : 'RELEASE'; brandVersionEl.textContent = `v${chrome.runtime.getManifest().version} ${channelLabel} · Manifest V3`; }
  if (saveUserBtn) {
    saveUserBtn.disabled = autoDetected;
    saveUserBtn.style.display = autoDetected ? 'none' : '';
    saveUserBtn.textContent = 'Guardar';
    saveUserBtn.title = 'Guardar Usuario VIENA manualmente';
  }
  if (local.viena_usuario) {
    userStatus.textContent = autoDetected
      ? 'Este usuario se obtiene de tu sesión de VIENA y no puede modificarse.'
      : 'Usuario VIENA configurado manualmente.';
  } else {
    userStatus.textContent = 'No pude detectar el usuario en VIENA. Ingresalo manualmente y guardalo.';
  }
  assignStatus.textContent = assignInput.value ? `Apellido configurado: ${assignInput.value}` : 'Falta configurar el apellido para las acciones de asignación.';
}

if (!isStandaloneFolderContext) {
  // FIX102: user/registry/update work starts only after the popup has painted.
  setTimeout(() => {
    void (async()=>{
      try { await chrome.runtime.sendMessage({type:'VIENA_DETECT_USER_NOW'}); } catch (_) {}
      try { await refresh(); } catch (_) {}
      try { await refreshRegistrySyncStatus(false); } catch (_) {}
      void chrome.runtime.sendMessage({type:'VIENA_INSTALL_REGISTRY_SYNC_NOW',reason:'popup_open'}).then(()=>setTimeout(()=>void refreshRegistrySyncStatus(false),1200)).catch(()=>{});
    })();
    // FIX105 CRITICAL: update checks are manual-only. Never start network/update discovery during popup boot.
  }, 180);
}

document.getElementById('saveUser').addEventListener('click', async () => {
  const state = await chrome.storage.local.get(['viena_usuario_origen']);
  if (state.viena_usuario_origen === 'auto') {
    showToast('El Usuario VIENA fue detectado automáticamente y está bloqueado.', 'warning');
    await refresh();
    return;
  }
  const v = userInput.value.trim().toLowerCase();
  if (!/^[a-z][a-z0-9._-]{2,30}$/i.test(v)) {
    showToast('Ingresá un usuario VIENA válido.', 'error');
    userInput.focus();
    return;
  }
  await chrome.storage.local.set({ viena_usuario: v, viena_usuario_origen: 'manual' });
  showToast('Usuario VIENA guardado.', 'success');
  await refresh();
});

document.getElementById('saveAssign').addEventListener('click', async () => {
  const v = assignInput.value.trim();
  if (!validSurname(v)) {
    showToast('Ingresá tu apellido, sin usuario de red ni números.', 'error');
    assignInput.focus();
    return;
  }
  await chrome.storage.local.set({ [ASSIGN_KEY]: v });
  try { await chrome.storage.sync.set({ [ASSIGN_KEY]: v }); } catch (_) {}
  showToast('Apellido para asignación guardado.', 'success');
  await refresh();
});


chrome.storage.onChanged.addListener((changes, area) => {
  if ((area === 'local' || area === 'sync') && (changes[ASSIGN_KEY] || changes.viena_usuario || changes.viena_usuario_origen)) void refresh();
});




const runtimePill = document.getElementById('runtimePill');
const runtimePillText = document.getElementById('runtimePillText');
const runtimeVersionText = document.getElementById('runtimeVersionText');
const runtimeAdvice = document.getElementById('runtimeAdvice');
const refreshRuntimeStatusBtn = document.getElementById('refreshRuntimeStatus');
const PLATFORM_LABELS = {
  viena: 'Viena',
  miraStats: 'Mira Estadisticas',
  miraCm: 'Mira CMs',
  gpon: 'Gpon',
  fuentes: 'Fuentes',
  moica2: 'Moica2',
  grafana: 'Grafana',
  metricas: 'Métricas'
};


// Favicons reales de plataforma. Mantiene el mismo mapa canónico y el mismo
// backend VIENA_GET_FAVICON_BYTES usado por los botones operativos de VIENA.
const POPUP_PLATFORM_ICON_PAGES = Object.freeze({
  viena: 'https://viena.telecentro.net.ar/',
  miraStats: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
  miraCm: 'https://mira5-gdt.telecentro.net.ar/stats_frontend.php',
  gpon: 'https://monitoreogpon.telecentro.net.ar/#/listOnts',
  fuentes: 'https://fuentes.telecentro.net.ar/webs/home.php',
  moica2: 'https://moica2.telecentro.net.ar/buscarTicket.php',
  grafana: 'https://grafana-telemetria.telecentro.net.ar/d/e1239f9e-a168-4843-963c-15681c84fe47/966718b3-44f9-56c1-9412-ccaf6599ff9e?orgId=1',
  metricas: 'https://metricas-gdt.telecentro.net.ar/nodos/home.php'
});
const POPUP_FAVICON_CACHE = new Map();
async function popupFaviconBlob(pageUrl) {
  if (!pageUrl || !chrome?.runtime?.sendMessage) return null;
  if (POPUP_FAVICON_CACHE.has(pageUrl)) return POPUP_FAVICON_CACHE.get(pageUrl);
  const request = (async () => {
    try {
      const result = await chrome.runtime.sendMessage({ type: 'VIENA_GET_FAVICON_BYTES', pageUrl });
      if (!result?.ok || !Array.isArray(result.bytes) || !result.bytes.length) return null;
      return new Blob([new Uint8Array(result.bytes)], { type: result.mime || 'image/png' });
    } catch (_) { return null; }
  })();
  POPUP_FAVICON_CACHE.set(pageUrl, request);
  return request;
}
async function renderPopupFavicon(canvas, pageUrl) {
  try {
    const blob = await popupFaviconBlob(pageUrl);
    if (!blob || !canvas?.isConnected) return false;
    const bitmap = await createImageBitmap(blob);
    if (!canvas.isConnected) { try { bitmap.close(); } catch (_) {} return false; }
    canvas.width = 16;
    canvas.height = 16;
    const ctx = canvas.getContext('2d');
    if (!ctx) return false;
    ctx.clearRect(0, 0, 16, 16);
    ctx.drawImage(bitmap, 0, 0, 16, 16);
    try { bitmap.close(); } catch (_) {}
    canvas.dataset.vienaIconReady = '1';
    return true;
  } catch (_) { return false; }
}
function renderPopupPlatformFavicons() {
  document.querySelectorAll('canvas.viena-platform-icon[data-platform]').forEach(canvas => {
    const pageUrl = POPUP_PLATFORM_ICON_PAGES[canvas.dataset.platform];
    if (pageUrl) void renderPopupFavicon(canvas, pageUrl);
  });
}
renderPopupPlatformFavicons();

const openFullViewBtn = document.getElementById('openFullView');
if (openFullViewBtn) {
  openFullViewBtn.addEventListener('click', async () => {
    try {
      // Abre la vista completa dedicada de VIENA NOC Tools.
      await chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?full=1#general') });
    } catch (error) {
      showToast(String(error?.message || error || 'No se pudo abrir la vista en pestaña.'), 'error');
    }
  });
}

function setRuntimePill(text, type = 'ok') {
  if (!runtimePill || !runtimePillText) return;
  runtimePillText.textContent = text;
  runtimePill.className = 'runtime-pill' + (type === 'warn' ? ' warn' : type === 'error' ? ' error' : '');
}

function setRuntimeAdvice(text = '', type = 'warn') {
  if (!runtimeAdvice) return;
  runtimeAdvice.textContent = text;
  runtimeAdvice.className = text ? `runtime-advice show ${type}` : 'runtime-advice';
}

async function runPlatformAction(key, action, button) {
  const label = PLATFORM_LABELS[key] || key;
  if (button) button.disabled = true;
  try {
    const result = await chrome.runtime.sendMessage({ type: 'VIENA_PLATFORM_ACTION', platform: key, action, background: true });
    if (!result?.ok) throw new Error(result?.detail || result?.code || 'No se pudo completar la acción.');
    showToast(action === 'open' ? `${label} abierto.` : `${label}: pestaña primaria recargada.`, 'success');
    await refreshRuntimeStatus();
  } catch (error) {
    showToast(`${label}: ${String(error?.message || error || 'error desconocido')}`, 'error');
  } finally {
    if (button?.isConnected) button.disabled = false;
  }
}

function renderPlatformState(key, state) {
  const el = document.getElementById(`st-${key}`);
  if (!el) return;
  el.replaceChildren();
  if (!state?.open) {
    el.className = 'platform-state closed';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'platform-action open';
    button.textContent = 'Abrir';
    button.title = `Abrir ${PLATFORM_LABELS[key] || key}`;
    button.addEventListener('click', () => void runPlatformAction(key, 'open', button));
    el.appendChild(button);
    return;
  }
  if (state.loading) {
    el.className = 'platform-state';
    el.textContent = 'Cargando…';
    return;
  }
  if (state.needsReload) {
    el.className = 'platform-state reload';
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'platform-action reload';
    button.textContent = 'Recargar';
    button.title = `Recargar la pestaña primaria de ${PLATFORM_LABELS[key] || key}`;
    button.addEventListener('click', () => void runPlatformAction(key, 'reload', button));
    el.appendChild(button);
    return;
  }
  el.textContent = state.tabs > 1 ? `Abierto (${state.tabs})` : 'Abierto';
  el.className = 'platform-state';
}

const VIENA_RUNTIME_STATUS_TIMEOUT_MS = 5000;

async function getOperationalStatusWithTimeout() {
  let timer = 0;
  try {
    return await Promise.race([
      chrome.runtime.sendMessage({ type: 'VIENA_GET_OPERATIONAL_STATUS' }),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Tiempo de espera agotado al comprobar el estado.')), VIENA_RUNTIME_STATUS_TIMEOUT_MS); })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function refreshRuntimeStatus({manual = false} = {}) {
  if (refreshRuntimeStatusBtn) refreshRuntimeStatusBtn.disabled = true;
  try {
    const result = await getOperationalStatusWithTimeout();
    if (!result?.ok) throw new Error(result?.detail || 'No se pudo consultar el estado.');
    const platforms = result.platforms || {};
    Object.keys(PLATFORM_LABELS).forEach(key => renderPlatformState(key, platforms[key]));
    if (runtimeVersionText) runtimeVersionText.textContent = `Runtime v${result.runtimeVersion} · build ${result.runtimeBuild}`;

    if (result.extensionNeedsReload) {
      runtimeBadgeState = 'RLD';
      renderCurrentBadgeHelp();
      setRuntimePill('Recargar extensión', 'error');
      setRuntimeAdvice('Detecté archivos de una build nueva. La extensión hará dos comprobaciones de estabilidad antes de recargarse sola. Si el estado persiste, recargala manualmente y después recargá las pestañas operativas marcadas.', 'error');
      if (manual) showToast('La extensión necesita recargarse en Chrome.', 'error');
      return;
    }

    const stale = Object.entries(platforms).filter(([,v]) => v?.open && v?.needsReload).map(([k]) => PLATFORM_LABELS[k] || k);
    if (stale.length) {
      runtimeBadgeState = 'TAB';
      renderCurrentBadgeHelp();
      setRuntimePill('Páginas desactualizadas', 'warn');
      setRuntimeAdvice(`Tocá “Recargar” en estas plataformas para cargar la versión actual en su pestaña primaria: ${stale.join(', ')}.`, 'warn');
      if (manual) showToast('Hay pestañas que necesitan recarga.', 'warning');
      return;
    }

    runtimeBadgeState = 'ON';
    renderCurrentBadgeHelp();
    setRuntimePill('Activa', 'ok');
    setRuntimeAdvice('');
    if (manual) showToast('Extensión y pestañas abiertas sincronizadas.', 'success');
  } catch (error) {
    runtimeBadgeState = 'CHECKING';
    renderCurrentBadgeHelp();
    setRuntimePill('Sin respuesta', 'error');
    setRuntimeAdvice(`No pude verificar el runtime: ${String(error?.message || error || 'error desconocido')}`, 'error');
    if (manual) showToast('No se pudo actualizar el estado.', 'error');
  } finally {
    if (refreshRuntimeStatusBtn) refreshRuntimeStatusBtn.disabled = false;
  }
}

if (refreshRuntimeStatusBtn) refreshRuntimeStatusBtn.addEventListener('click', () => void refreshRuntimeStatus({manual:true}));
if (!isStandaloneFolderContext) void refreshRuntimeStatus();


// Estado operativo en tiempo real mientras el popup permanece abierto.
// Abrir/Recargar desde el panel no activa la pestaña destino, por lo que el
// popup conserva el foco. Los eventos de tabs refrescan el estado sin exigir
// tocar manualmente "Actualizar estado".
let runtimeRefreshTimer = 0;
function scheduleRuntimeStatusRefresh(delay = 120) {
  if (runtimeRefreshTimer) clearTimeout(runtimeRefreshTimer);
  runtimeRefreshTimer = setTimeout(() => { runtimeRefreshTimer = 0; void refreshRuntimeStatus(); }, delay);
}
if (!isStandaloneFolderContext && chrome?.tabs) {
  chrome.tabs.onCreated.addListener(() => scheduleRuntimeStatusRefresh(120));
  chrome.tabs.onUpdated.addListener((_tabId, changeInfo) => {
    if (changeInfo.status || changeInfo.url) scheduleRuntimeStatusRefresh(changeInfo.status === 'complete' ? 80 : 140);
  });
  chrome.tabs.onRemoved.addListener(() => scheduleRuntimeStatusRefresh(80));
  chrome.tabs.onActivated.addListener(() => scheduleRuntimeStatusRefresh(80));
}


// Botones y plantillas: abrir la nueva vista completa directamente en Personalización.
const openButtonEditorBtn = document.getElementById('openButtonEditor');
const buttonEditorStatusEl = document.getElementById('buttonEditorStatus');
if (openButtonEditorBtn) {
  openButtonEditorBtn.addEventListener('click', async () => {
    openButtonEditorBtn.disabled = true;
    if (buttonEditorStatusEl) buttonEditorStatusEl.textContent = 'Abriendo editor…';
    try {
      const targetUrl = chrome.runtime.getURL('popup.html?full=1#personalization');
      const extensionPrefix = chrome.runtime.getURL('popup.html?full=1');
      const tabs = await chrome.tabs.query({});
      const existing = tabs.find(tab => tab?.id && String(tab.url || '').startsWith(extensionPrefix));
      if (existing?.id) {
        await chrome.tabs.update(existing.id, { active: true, url: targetUrl });
        if (existing.windowId != null) {
          try { await chrome.windows.update(existing.windowId, { focused: true }); } catch (_) {}
        }
      } else {
        let current = null;
        try {
          const active = await chrome.tabs.query({ active: true, currentWindow: true });
          current = active[0] || null;
        } catch (_) {}
        const options = { url: targetUrl, active: true };
        if (Number.isInteger(current?.index)) options.index = current.index + 1;
        await chrome.tabs.create(options);
      }
      if (buttonEditorStatusEl) buttonEditorStatusEl.textContent = '';
      window.close();
    } catch (error) {
      const msg = String(error?.message || error || 'No se pudo abrir el editor.');
      if (buttonEditorStatusEl) buttonEditorStatusEl.textContent = msg;
      showToast(msg, 'error');
      openButtonEditorBtn.disabled = false;
    }
  });
}


}


